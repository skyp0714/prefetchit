import json,subprocess,sys,time
from pathlib import Path
root=Path(__file__).parent
scripts=Path('/home/hnpark2/prefetchit/llvm_prefetchit/scripts/class_b')
for name in ['rpc_route','rpc_worker','rpc_staged']:
    command=['python3',str(scripts/'rpc_future_study.py'),'platform_smoke',str(root/('smoke_'+name+'.json'))]
    with (root/('smoke_'+name+'.log')).open('w') as output:
        subprocess.run(command,stdout=output,stderr=subprocess.STDOUT,check=True)
    assert json.loads((root/'smoke'/name/'result.json').read_text())['valid']
    print(json.dumps(dict(stage='smoke_complete',arm=name)),flush=True)
command=['python3',str(scripts/'temporal_path_campaign.py'),'campaign',str(root/'screen_spec.json')]
with (root/'screen.log').open('w') as output:
    subprocess.run(command,stdout=output,stderr=subprocess.STDOUT,check=True)
print(json.dumps(dict(stage='screen_complete',epoch=time.time())),flush=True)
