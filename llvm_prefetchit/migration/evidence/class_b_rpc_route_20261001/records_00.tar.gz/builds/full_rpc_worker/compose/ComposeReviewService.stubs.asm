
/storage/prefetchit/class_b_rpc_route_20261001/builds/full_rpc_worker/compose/call-stub-ptiy8_ui/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000356380 <pf_call_0>:
  356380:	0f 18 15 f9 a6 ed ff 	prefetcht1 -0x125907(%rip)        # 230a80 <pf_target_0_0>
  356387:	0f 18 15 32 3b d7 ff 	prefetcht1 -0x28c4ce(%rip)        # c9ec0 <pf_target_0_1>

000000000035638e <pf_jump_0>:
  35638e:	e9 4d c7 fe ff       	jmp    342ae0 <pf_callee_0>
