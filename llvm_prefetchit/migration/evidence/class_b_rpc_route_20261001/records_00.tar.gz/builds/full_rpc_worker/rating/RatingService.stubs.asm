
/storage/prefetchit/class_b_rpc_route_20261001/builds/full_rpc_worker/rating/call-stub-ytzd2slx/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000038f380 <pf_call_0>:
  38f380:	0f 18 15 59 4b cf ff 	prefetcht1 -0x30b4a7(%rip)        # 83ee0 <pf_target_0_0>
  38f387:	0f 18 15 e2 70 cc ff 	prefetcht1 -0x338f1e(%rip)        # 56470 <pf_target_0_1>
  38f38e:	0f 18 15 3b 3d cf ff 	prefetcht1 -0x30c2c5(%rip)        # 830d0 <pf_target_0_2>
  38f395:	0f 18 15 e4 66 cf ff 	prefetcht1 -0x30991c(%rip)        # 85a80 <pf_target_0_3>
  38f39c:	0f 18 15 59 73 cc ff 	prefetcht1 -0x338ca7(%rip)        # 566fc <pf_target_0_4>
  38f3a3:	0f 18 15 56 71 cc ff 	prefetcht1 -0x338eaa(%rip)        # 56500 <pf_target_0_5>
  38f3aa:	0f 18 15 6f 8a e6 ff 	prefetcht1 -0x197591(%rip)        # 1f7e20 <pf_target_0_6>

000000000038f3b1 <pf_jump_0>:
  38f3b1:	e9 1a 81 fe ff       	jmp    3774d0 <pf_callee_0>
  38f3b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  38f3bd:	00 00 00 

000000000038f3c0 <pf_call_1>:
  38f3c0:	0f 18 15 f4 5f d9 ff 	prefetcht1 -0x26a00c(%rip)        # 1253bb <pf_target_1_0>
  38f3c7:	0f 18 15 22 70 ca ff 	prefetcht1 -0x358fde(%rip)        # 363f0 <pf_target_1_1>
  38f3ce:	0f 18 15 9b 7f cc ff 	prefetcht1 -0x338065(%rip)        # 57370 <pf_target_1_2>

000000000038f3d5 <pf_jump_1>:
  38f3d5:	e9 96 81 fe ff       	jmp    377570 <pf_callee_1>
