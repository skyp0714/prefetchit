
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_worker/movie/call-stub-c384th9n/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000003c3380 <pf_call_0>:
  3c3380:	0f 18 15 b9 0b d1 ff 	prefetcht1 -0x2ef447(%rip)        # d3f40 <pf_target_0_0>
  3c3387:	0f 18 15 f2 33 ce ff 	prefetcht1 -0x31cc0e(%rip)        # a6780 <pf_target_0_1>

00000000003c338e <pf_jump_0>:
  3c338e:	e9 fd a1 fe ff       	jmp    3ad590 <pf_callee_0>
  3c3393:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  3c339a:	00 00 00 
  3c339d:	0f 1f 00             	nopl   (%rax)

00000000003c33a0 <pf_call_1>:
  3c33a0:	0f 18 15 99 0b d1 ff 	prefetcht1 -0x2ef467(%rip)        # d3f40 <pf_target_0_0>
  3c33a7:	0f 18 15 62 40 ce ff 	prefetcht1 -0x31bf9e(%rip)        # a7410 <pf_target_1_1>
  3c33ae:	0f 18 15 fb 34 eb ff 	prefetcht1 -0x14cb05(%rip)        # 2768b0 <pf_target_1_2>

00000000003c33b5 <pf_jump_1>:
  3c33b5:	e9 66 a2 fe ff       	jmp    3ad620 <pf_callee_1>
  3c33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000003c33c0 <pf_call_2>:
  3c33c0:	0f 18 15 e9 34 eb ff 	prefetcht1 -0x14cb17(%rip)        # 2768b0 <pf_target_1_2>
  3c33c7:	0f 18 15 72 0b d1 ff 	prefetcht1 -0x2ef48e(%rip)        # d3f40 <pf_target_0_0>
  3c33ce:	0f 18 15 eb 40 ce ff 	prefetcht1 -0x31bf15(%rip)        # a74c0 <pf_target_2_2>
  3c33d5:	0f 18 15 74 40 ce ff 	prefetcht1 -0x31bf8c(%rip)        # a7450 <pf_target_2_3>
  3c33dc:	0f 18 15 6d 36 d1 ff 	prefetcht1 -0x2ec993(%rip)        # d6a50 <pf_target_2_4>
  3c33e3:	0f 18 15 d5 54 d1 ff 	prefetcht1 -0x2eab2b(%rip)        # d88bf <pf_target_2_5>

00000000003c33ea <pf_jump_2>:
  3c33ea:	e9 81 a2 fe ff       	jmp    3ad670 <pf_callee_2>
