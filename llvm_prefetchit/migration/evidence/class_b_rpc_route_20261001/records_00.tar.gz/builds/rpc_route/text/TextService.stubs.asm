
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_route/text/call-stub-neunyjgy/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000116380 <pf_call_0>:
  116380:	0f 18 15 38 9e f4 ff 	prefetcht1 -0xb61c8(%rip)        # 601bf <pf_target_0_0>
  116387:	0f 18 15 a2 df f4 ff 	prefetcht1 -0xb205e(%rip)        # 64330 <pf_target_0_1>
  11638e:	0f 18 15 9b 7c f1 ff 	prefetcht1 -0xe8365(%rip)        # 2e030 <pf_target_0_2>
  116395:	0f 18 15 fe a0 f4 ff 	prefetcht1 -0xb5f02(%rip)        # 6049a <pf_target_0_3>
  11639c:	0f 18 15 1d a6 f1 ff 	prefetcht1 -0xe59e3(%rip)        # 309c0 <pf_target_0_4>
  1163a3:	0f 18 15 d5 69 f4 ff 	prefetcht1 -0xb962b(%rip)        # 5cd7f <pf_target_0_5>
  1163aa:	0f 18 15 bf 65 f4 ff 	prefetcht1 -0xb9a41(%rip)        # 5c970 <pf_target_0_6>
  1163b1:	0f 18 15 1e ae f1 ff 	prefetcht1 -0xe51e2(%rip)        # 311d6 <pf_target_0_7>

00000000001163b8 <pf_jump_0>:
  1163b8:	e9 d3 9d f4 ff       	jmp    60190 <pf_callee_0>
