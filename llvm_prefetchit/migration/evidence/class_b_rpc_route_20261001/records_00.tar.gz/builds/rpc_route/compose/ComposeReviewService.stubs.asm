
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_route/compose/call-stub-z4evhcmr/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000356380 <pf_call_0>:
  356380:	0f 18 15 f6 e6 d4 ff 	prefetcht1 -0x2b190a(%rip)        # a4a7d <pf_target_0_0>
  356387:	0f 18 15 38 eb d4 ff 	prefetcht1 -0x2b14c8(%rip)        # a4ec6 <pf_target_0_1>
  35638e:	0f 18 15 a6 e6 d4 ff 	prefetcht1 -0x2b195a(%rip)        # a4a3b <pf_target_0_2>
  356395:	0f 18 15 44 a5 f0 ff 	prefetcht1 -0xf5abc(%rip)        # 2608e0 <pf_target_0_3>
  35639c:	0f 18 15 18 90 d6 ff 	prefetcht1 -0x296fe8(%rip)        # bf3bb <pf_target_0_4>
  3563a3:	0f 18 15 c6 ce df ff 	prefetcht1 -0x20313a(%rip)        # 153270 <pf_target_0_5>
  3563aa:	0f 18 15 cd 26 d9 ff 	prefetcht1 -0x26d933(%rip)        # e8a7e <pf_target_0_6>

00000000003563b1 <pf_jump_0>:
  3563b1:	e9 fa ca fe ff       	jmp    342eb0 <pf_callee_0>
  3563b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  3563bd:	00 00 00 

00000000003563c0 <pf_call_1>:
  3563c0:	0f 18 15 69 5e d5 ff 	prefetcht1 -0x2aa197(%rip)        # ac230 <pf_target_1_0>
  3563c7:	0f 18 15 f8 02 d5 ff 	prefetcht1 -0x2afd08(%rip)        # a66c6 <pf_target_1_1>
  3563ce:	0f 18 15 2b fe d4 ff 	prefetcht1 -0x2b01d5(%rip)        # a6200 <pf_target_1_2>
  3563d5:	0f 18 15 9f 8f d6 ff 	prefetcht1 -0x297061(%rip)        # bf37b <pf_target_1_3>
  3563dc:	0f 18 15 1d 6a e9 ff 	prefetcht1 -0x1695e3(%rip)        # 1ece00 <pf_target_1_4>
  3563e3:	0f 18 15 94 60 d5 ff 	prefetcht1 -0x2a9f6c(%rip)        # ac47e <pf_target_1_5>
  3563ea:	0f 18 15 bf 6b d4 ff 	prefetcht1 -0x2b9441(%rip)        # 9cfb0 <pf_target_1_6>

00000000003563f1 <pf_jump_1>:
  3563f1:	e9 1a cb fe ff       	jmp    342f10 <pf_callee_1>
  3563f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  3563fd:	00 00 00 

0000000000356400 <pf_call_2>:
  356400:	0f 18 15 69 ce df ff 	prefetcht1 -0x203197(%rip)        # 153270 <pf_target_0_5>
  356407:	0f 18 15 6d 8f d6 ff 	prefetcht1 -0x297093(%rip)        # bf37b <pf_target_1_3>
  35640e:	0f 18 15 aa a1 e1 ff 	prefetcht1 -0x1e5e56(%rip)        # 1705bf <pf_target_2_2>
  356415:	0f 18 15 64 f1 db ff 	prefetcht1 -0x240e9c(%rip)        # 115580 <pf_target_2_3>
  35641c:	0f 18 15 8d bf e8 ff 	prefetcht1 -0x174073(%rip)        # 1e23b0 <pf_target_2_4>
  356423:	0f 18 15 4e bc d4 ff 	prefetcht1 -0x2b43b2(%rip)        # a2078 <pf_target_2_5>
  35642a:	0f 18 15 cc b2 d4 ff 	prefetcht1 -0x2b4d34(%rip)        # a16fd <pf_target_2_6>

0000000000356431 <pf_jump_2>:
  356431:	e9 6a cb fe ff       	jmp    342fa0 <pf_callee_2>
  356436:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  35643d:	00 00 00 

0000000000356440 <pf_call_3>:
  356440:	0f 18 15 b6 9a d4 ff 	prefetcht1 -0x2b654a(%rip)        # 9fefd <pf_target_3_0>
  356447:	0f 18 15 2d 8f d6 ff 	prefetcht1 -0x2970d3(%rip)        # bf37b <pf_target_1_3>
  35644e:	0f 18 15 29 37 d9 ff 	prefetcht1 -0x26c8d7(%rip)        # e9b7e <pf_target_3_2>
  356455:	0f 18 15 61 cd d8 ff 	prefetcht1 -0x27329f(%rip)        # e31bd <pf_target_3_3>
  35645c:	0f 18 15 5c ce df ff 	prefetcht1 -0x2031a4(%rip)        # 1532bf <pf_target_3_4>
  356463:	0f 18 15 06 ce df ff 	prefetcht1 -0x2031fa(%rip)        # 153270 <pf_target_0_5>
  35646a:	0f 18 15 0e a3 de ff 	prefetcht1 -0x215cf2(%rip)        # 14077f <pf_target_3_6>

0000000000356471 <pf_jump_3>:
  356471:	e9 ca ca fe ff       	jmp    342f40 <pf_callee_3>
  356476:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  35647d:	00 00 00 

0000000000356480 <pf_call_4>:
  356480:	0f 18 15 2f df d8 ff 	prefetcht1 -0x2720d1(%rip)        # e43b6 <pf_target_4_0>
  356487:	0f 18 15 e2 cd df ff 	prefetcht1 -0x20321e(%rip)        # 153270 <pf_target_0_5>
  35648e:	0f 18 15 a7 8e d6 ff 	prefetcht1 -0x297159(%rip)        # bf33c <pf_target_4_2>
  356495:	0f 18 15 1e cc d4 ff 	prefetcht1 -0x2b33e2(%rip)        # a30ba <pf_target_4_3>
  35649c:	0f 18 15 7c d0 d4 ff 	prefetcht1 -0x2b2f84(%rip)        # a351f <pf_target_4_4>
  3564a3:	0f 18 15 15 a1 e1 ff 	prefetcht1 -0x1e5eeb(%rip)        # 1705bf <pf_target_2_2>

00000000003564aa <pf_jump_4>:
  3564aa:	e9 c1 ca fe ff       	jmp    342f70 <pf_callee_4>
