
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_route/unique/call-stub-_g9b3li4/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000119380 <pf_call_0>:
  119380:	0f 18 15 76 ce f6 ff 	prefetcht1 -0x9318a(%rip)        # 861fd <pf_target_0_0>
  119387:	0f 18 15 22 d7 f2 ff 	prefetcht1 -0xd28de(%rip)        # 46ab0 <pf_target_0_1>
  11938e:	0f 18 15 2b 69 f4 ff 	prefetcht1 -0xb96d5(%rip)        # 5fcc0 <pf_target_0_2>
  119395:	0f 18 15 de 9a f4 ff 	prefetcht1 -0xb6522(%rip)        # 62e7a <pf_target_0_3>
  11939c:	0f 18 15 db 2b f3 ff 	prefetcht1 -0xcd425(%rip)        # 4bf7e <pf_target_0_4>
  1193a3:	0f 18 15 16 de f7 ff 	prefetcht1 -0x821ea(%rip)        # 971c0 <pf_target_0_5>
  1193aa:	0f 18 15 0c 9e f4 ff 	prefetcht1 -0xb61f4(%rip)        # 631bd <pf_target_0_6>

00000000001193b1 <pf_jump_0>:
  1193b1:	e9 0a a2 ff ff       	jmp    1135c0 <pf_callee_0>
