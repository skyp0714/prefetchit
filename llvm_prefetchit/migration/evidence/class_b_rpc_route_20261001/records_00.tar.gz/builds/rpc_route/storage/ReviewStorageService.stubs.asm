
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_route/storage/call-stub-8u_8jjts/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000111380 <pf_call_0>:
  111380:	0f 18 15 19 f8 f1 ff 	prefetcht1 -0xe07e7(%rip)        # 30ba0 <pf_target_0_0>
  111387:	0f 18 15 b0 fc f3 ff 	prefetcht1 -0xc0350(%rip)        # 5103e <pf_target_0_1>
  11138e:	0f 18 15 1b 5f f5 ff 	prefetcht1 -0xaa0e5(%rip)        # 672b0 <pf_target_0_2>
  111395:	0f 18 15 a1 73 f5 ff 	prefetcht1 -0xa8c5f(%rip)        # 6873d <pf_target_0_3>
  11139c:	0f 18 15 db 02 f4 ff 	prefetcht1 -0xbfd25(%rip)        # 5167e <pf_target_0_4>
  1113a3:	0f 18 15 c9 09 f4 ff 	prefetcht1 -0xbf637(%rip)        # 51d73 <pf_target_0_5>
  1113aa:	0f 18 15 2f 74 f3 ff 	prefetcht1 -0xc8bd1(%rip)        # 487e0 <pf_target_0_6>
  1113b1:	0f 18 15 e8 08 f4 ff 	prefetcht1 -0xbf718(%rip)        # 51ca0 <pf_target_0_7>

00000000001113b8 <pf_jump_0>:
  1113b8:	e9 33 73 f5 ff       	jmp    686f0 <pf_callee_0>
