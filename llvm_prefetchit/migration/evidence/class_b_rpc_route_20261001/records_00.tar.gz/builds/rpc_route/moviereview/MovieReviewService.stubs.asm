
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_route/moviereview/call-stub-z_md_r0p/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000001e2380 <pf_call_0>:
  1e2380:	0f 18 15 77 7e f5 ff 	prefetcht1 -0xa8189(%rip)        # 13a1fe <pf_target_0_0>
  1e2387:	0f 18 15 6b 2f e6 ff 	prefetcht1 -0x19d095(%rip)        # 452f9 <pf_target_0_1>
  1e238e:	0f 18 15 2b 15 e8 ff 	prefetcht1 -0x17ead5(%rip)        # 638c0 <pf_target_0_2>
  1e2395:	0f 18 15 54 b2 e4 ff 	prefetcht1 -0x1b4dac(%rip)        # 2d5f0 <pf_target_0_3>
  1e239c:	0f 18 15 17 0c e8 ff 	prefetcht1 -0x17f3e9(%rip)        # 62fba <pf_target_0_4>
  1e23a3:	0f 18 15 96 56 eb ff 	prefetcht1 -0x14a96a(%rip)        # 97a40 <pf_target_0_5>
  1e23aa:	0f 18 15 0f ce e6 ff 	prefetcht1 -0x1931f1(%rip)        # 4f1c0 <pf_target_0_6>
  1e23b1:	0f 18 15 38 e8 ef ff 	prefetcht1 -0x1017c8(%rip)        # e0bf0 <pf_target_0_7>

00000000001e23b8 <pf_jump_0>:
  1e23b8:	e9 43 05 ea ff       	jmp    82900 <pf_callee_0>
