
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_route/movie/call-stub-xm40wcs5/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000003c3380 <pf_call_0>:
  3c3380:	0f 18 15 b4 09 d1 ff 	prefetcht1 -0x2ef64c(%rip)        # d3d3b <pf_target_0_0>
  3c3387:	0f 18 15 70 86 d1 ff 	prefetcht1 -0x2e7990(%rip)        # db9fe <pf_target_0_1>
  3c338e:	0f 18 15 29 8f cf ff 	prefetcht1 -0x3070d7(%rip)        # bc2be <pf_target_0_2>
  3c3395:	0f 18 15 34 e1 cc ff 	prefetcht1 -0x331ecc(%rip)        # 914d0 <pf_target_0_3>
  3c339c:	0f 18 15 ad 36 d1 ff 	prefetcht1 -0x2ec953(%rip)        # d6a50 <pf_target_0_4>
  3c33a3:	0f 18 15 56 f4 cd ff 	prefetcht1 -0x320baa(%rip)        # a2800 <pf_target_0_5>
  3c33aa:	0f 18 15 5f f8 e6 ff 	prefetcht1 -0x1907a1(%rip)        # 232c10 <pf_target_0_6>
  3c33b1:	0f 18 15 06 4f ce ff 	prefetcht1 -0x31b0fa(%rip)        # a82be <pf_target_0_7>

00000000003c33b8 <pf_jump_0>:
  3c33b8:	e9 23 86 d1 ff       	jmp    db9e0 <pf_callee_0>
