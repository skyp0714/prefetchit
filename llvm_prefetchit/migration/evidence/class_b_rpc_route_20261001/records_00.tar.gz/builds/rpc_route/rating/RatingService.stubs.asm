
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_route/rating/call-stub-o5_fl5_l/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000038f380 <pf_call_0>:
  38f380:	0f 18 15 74 81 d7 ff 	prefetcht1 -0x287e8c(%rip)        # 1074fb <pf_target_0_0>
  38f387:	0f 18 15 a2 87 cd ff 	prefetcht1 -0x32785e(%rip)        # 67b30 <pf_target_0_1>
  38f38e:	0f 18 15 ab 95 cc ff 	prefetcht1 -0x336a55(%rip)        # 58940 <pf_target_0_2>
  38f395:	0f 18 15 a3 ac cf ff 	prefetcht1 -0x30535d(%rip)        # 8a03f <pf_target_0_3>
  38f39c:	0f 18 15 9b ed cf ff 	prefetcht1 -0x301265(%rip)        # 8e13e <pf_target_0_4>
  38f3a3:	0f 18 15 54 c9 cf ff 	prefetcht1 -0x3036ac(%rip)        # 8bcfe <pf_target_0_5>
  38f3aa:	0f 18 15 2e 56 cc ff 	prefetcht1 -0x33a9d2(%rip)        # 549df <pf_target_0_6>

000000000038f3b1 <pf_jump_0>:
  38f3b1:	e9 7a 85 fe ff       	jmp    377930 <pf_callee_0>
