
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_route/userreview/call-stub-jl3g7mm0/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000001e2380 <pf_call_0>:
  1e2380:	0f 18 15 d9 75 e8 ff 	prefetcht1 -0x178a27(%rip)        # 69960 <pf_target_0_0>
  1e2387:	0f 18 15 31 d4 e6 ff 	prefetcht1 -0x192bcf(%rip)        # 4f7bf <pf_target_0_1>
  1e238e:	0f 18 15 aa f9 e8 ff 	prefetcht1 -0x170656(%rip)        # 71d3f <pf_target_0_2>
  1e2395:	0f 18 15 23 e4 e6 ff 	prefetcht1 -0x191bdd(%rip)        # 507bf <pf_target_0_3>
  1e239c:	0f 18 15 ad 76 e8 ff 	prefetcht1 -0x178953(%rip)        # 69a50 <pf_target_0_4>
  1e23a3:	0f 18 15 50 7d e8 ff 	prefetcht1 -0x1782b0(%rip)        # 6a0fa <pf_target_0_5>
  1e23aa:	0f 18 15 0d 0b ea ff 	prefetcht1 -0x15f4f3(%rip)        # 82ebe <pf_target_0_6>
  1e23b1:	0f 18 15 fe 0e ea ff 	prefetcht1 -0x15f102(%rip)        # 832b6 <pf_target_0_7>

00000000001e23b8 <pf_jump_0>:
  1e23b8:	e9 e3 0a ea ff       	jmp    82ea0 <pf_callee_0>
