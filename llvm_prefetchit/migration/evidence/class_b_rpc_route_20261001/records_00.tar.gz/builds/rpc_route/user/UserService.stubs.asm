
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_route/user/call-stub-i1tvo5ck/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000145380 <pf_call_0>:
  145380:	0f 18 15 75 a7 f6 ff 	prefetcht1 -0x9588b(%rip)        # afafc <pf_target_0_0>
  145387:	0f 18 15 32 c5 ef ff 	prefetcht1 -0x103ace(%rip)        # 418c0 <pf_target_0_1>
  14538e:	0f 18 15 8b 9d f6 ff 	prefetcht1 -0x96275(%rip)        # af120 <pf_target_0_2>
  145395:	0f 18 15 c4 16 ef ff 	prefetcht1 -0x10e93c(%rip)        # 36a60 <pf_target_0_3>
  14539c:	0f 18 15 33 e2 ef ff 	prefetcht1 -0x101dcd(%rip)        # 435d6 <pf_target_0_4>
  1453a3:	0f 18 15 d4 08 f1 ff 	prefetcht1 -0xef72c(%rip)        # 55c7e <pf_target_0_5>
  1453aa:	0f 18 15 6f d6 f0 ff 	prefetcht1 -0xf2991(%rip)        # 52a20 <pf_target_0_6>

00000000001453b1 <pf_jump_0>:
  1453b1:	e9 4a a2 ff ff       	jmp    13f600 <pf_callee_0>
