
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_staged/text/call-stub-fls_dcdy/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000116380 <pf_call_0>:
  116380:	0f 18 15 38 9e f4 ff 	prefetcht1 -0xb61c8(%rip)        # 601bf <pf_target_0_0>
  116387:	0f 18 15 a2 df f4 ff 	prefetcht1 -0xb205e(%rip)        # 64330 <pf_target_0_1>
  11638e:	0f 18 15 05 a1 f4 ff 	prefetcht1 -0xb5efb(%rip)        # 6049a <pf_target_0_2>
  116395:	0f 18 15 e3 69 f4 ff 	prefetcht1 -0xb961d(%rip)        # 5cd7f <pf_target_0_3>
  11639c:	0f 18 15 cd 65 f4 ff 	prefetcht1 -0xb9a33(%rip)        # 5c970 <pf_target_0_4>
  1163a3:	0f 18 15 50 9f f4 ff 	prefetcht1 -0xb60b0(%rip)        # 602fa <pf_target_0_5>
  1163aa:	0f 18 15 d2 35 f3 ff 	prefetcht1 -0xcca2e(%rip)        # 49983 <pf_target_0_6>
  1163b1:	0f 18 15 05 bb f4 ff 	prefetcht1 -0xb44fb(%rip)        # 61ebd <pf_target_0_7>

00000000001163b8 <pf_jump_0>:
  1163b8:	e9 d3 9d f4 ff       	jmp    60190 <pf_callee_0>
