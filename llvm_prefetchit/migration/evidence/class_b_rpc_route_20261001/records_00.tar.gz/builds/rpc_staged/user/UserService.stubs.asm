
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_staged/user/call-stub-bqzlxtyb/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000145380 <pf_call_0>:
  145380:	0f 18 15 79 41 f4 ff 	prefetcht1 -0xbbe87(%rip)        # 89500 <pf_target_0_0>
  145387:	0f 18 15 b0 49 f4 ff 	prefetcht1 -0xbb650(%rip)        # 89d3e <pf_target_0_1>
  14538e:	0f 18 15 68 9d f3 ff 	prefetcht1 -0xc6298(%rip)        # 7f0fd <pf_target_0_2>
  145395:	0f 18 15 2a 6c f1 ff 	prefetcht1 -0xe93d6(%rip)        # 5bfc6 <pf_target_0_3>
  14539c:	0f 18 15 cd 3e ee ff 	prefetcht1 -0x11c133(%rip)        # 29270 <pf_target_0_4>
  1453a3:	0f 18 15 96 28 f3 ff 	prefetcht1 -0xcd76a(%rip)        # 77c40 <pf_target_0_5>
  1453aa:	0f 18 15 ef 4a f4 ff 	prefetcht1 -0xbb511(%rip)        # 89ea0 <pf_target_0_6>

00000000001453b1 <pf_jump_0>:
  1453b1:	e9 4a a2 ff ff       	jmp    13f600 <pf_callee_0>
  1453b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1453bd:	00 00 00 

00000000001453c0 <pf_call_1>:
  1453c0:	0f 18 15 35 a7 f6 ff 	prefetcht1 -0x958cb(%rip)        # afafc <pf_target_1_0>
  1453c7:	0f 18 15 f2 c4 ef ff 	prefetcht1 -0x103b0e(%rip)        # 418c0 <pf_target_1_1>

00000000001453ce <pf_jump_1>:
  1453ce:	e9 6d 9f ff ff       	jmp    13f340 <pf_callee_1>
