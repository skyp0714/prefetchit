
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_staged/movie/call-stub-96d3qd29/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000003c3380 <pf_call_0>:
  3c3380:	0f 18 15 77 86 d1 ff 	prefetcht1 -0x2e7989(%rip)        # db9fe <pf_target_0_0>
  3c3387:	0f 18 15 c2 36 d1 ff 	prefetcht1 -0x2ec93e(%rip)        # d6a50 <pf_target_0_1>
  3c338e:	0f 18 15 eb 37 ee ff 	prefetcht1 -0x11c815(%rip)        # 2a6b80 <pf_target_0_2>
  3c3395:	0f 18 15 23 80 d9 ff 	prefetcht1 -0x267fdd(%rip)        # 15b3bf <pf_target_0_3>
  3c339c:	0f 18 15 3d 30 d1 ff 	prefetcht1 -0x2ecfc3(%rip)        # d63e0 <pf_target_0_4>
  3c33a3:	0f 18 15 93 ba d9 ff 	prefetcht1 -0x26456d(%rip)        # 15ee3d <pf_target_0_5>
  3c33aa:	0f 18 15 2f 4e e6 ff 	prefetcht1 -0x19b1d1(%rip)        # 2281e0 <pf_target_0_6>
  3c33b1:	0f 18 15 48 2c d1 ff 	prefetcht1 -0x2ed3b8(%rip)        # d6000 <pf_target_0_7>

00000000003c33b8 <pf_jump_0>:
  3c33b8:	e9 23 86 d1 ff       	jmp    db9e0 <pf_callee_0>
  3c33bd:	0f 1f 00             	nopl   (%rax)

00000000003c33c0 <pf_call_1>:
  3c33c0:	0f 18 15 74 09 d1 ff 	prefetcht1 -0x2ef68c(%rip)        # d3d3b <pf_target_1_0>
  3c33c7:	0f 18 15 f0 8e cf ff 	prefetcht1 -0x307110(%rip)        # bc2be <pf_target_1_1>
  3c33ce:	0f 18 15 fb e0 cc ff 	prefetcht1 -0x331f05(%rip)        # 914d0 <pf_target_1_2>
  3c33d5:	0f 18 15 24 f4 cd ff 	prefetcht1 -0x320bdc(%rip)        # a2800 <pf_target_1_3>

00000000003c33dc <pf_jump_1>:
  3c33dc:	e9 9f 9f fe ff       	jmp    3ad380 <pf_callee_1>
  3c33e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  3c33e8:	00 00 00 
  3c33eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000003c33f0 <pf_call_2>:
  3c33f0:	0f 18 15 49 0b d1 ff 	prefetcht1 -0x2ef4b7(%rip)        # d3f40 <pf_target_2_0>
  3c33f7:	0f 18 15 82 33 ce ff 	prefetcht1 -0x31cc7e(%rip)        # a6780 <pf_target_2_1>

00000000003c33fe <pf_jump_2>:
  3c33fe:	e9 8d a1 fe ff       	jmp    3ad590 <pf_callee_2>
  3c3403:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  3c340a:	00 00 00 
  3c340d:	0f 1f 00             	nopl   (%rax)

00000000003c3410 <pf_call_3>:
  3c3410:	0f 18 15 29 0b d1 ff 	prefetcht1 -0x2ef4d7(%rip)        # d3f40 <pf_target_2_0>
  3c3417:	0f 18 15 f2 3f ce ff 	prefetcht1 -0x31c00e(%rip)        # a7410 <pf_target_3_1>
  3c341e:	0f 18 15 8b 34 eb ff 	prefetcht1 -0x14cb75(%rip)        # 2768b0 <pf_target_3_2>

00000000003c3425 <pf_jump_3>:
  3c3425:	e9 f6 a1 fe ff       	jmp    3ad620 <pf_callee_3>
  3c342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000003c3430 <pf_call_4>:
  3c3430:	0f 18 15 79 34 eb ff 	prefetcht1 -0x14cb87(%rip)        # 2768b0 <pf_target_3_2>
  3c3437:	0f 18 15 02 0b d1 ff 	prefetcht1 -0x2ef4fe(%rip)        # d3f40 <pf_target_2_0>
  3c343e:	0f 18 15 7b 40 ce ff 	prefetcht1 -0x31bf85(%rip)        # a74c0 <pf_target_4_2>
  3c3445:	0f 18 15 04 40 ce ff 	prefetcht1 -0x31bffc(%rip)        # a7450 <pf_target_4_3>
  3c344c:	0f 18 15 fd 35 d1 ff 	prefetcht1 -0x2eca03(%rip)        # d6a50 <pf_target_0_1>
  3c3453:	0f 18 15 65 54 d1 ff 	prefetcht1 -0x2eab9b(%rip)        # d88bf <pf_target_4_5>

00000000003c345a <pf_jump_4>:
  3c345a:	e9 11 a2 fe ff       	jmp    3ad670 <pf_callee_4>
