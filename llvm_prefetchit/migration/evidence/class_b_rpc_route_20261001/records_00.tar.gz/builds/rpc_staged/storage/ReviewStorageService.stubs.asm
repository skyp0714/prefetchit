
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_staged/storage/call-stub-dolsg4ib/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000111380 <pf_call_0>:
  111380:	0f 18 15 29 5f f5 ff 	prefetcht1 -0xaa0d7(%rip)        # 672b0 <pf_target_0_0>
  111387:	0f 18 15 af 73 f5 ff 	prefetcht1 -0xa8c51(%rip)        # 6873d <pf_target_0_1>
  11138e:	0f 18 15 e9 02 f4 ff 	prefetcht1 -0xbfd17(%rip)        # 5167e <pf_target_0_2>
  111395:	0f 18 15 d7 09 f4 ff 	prefetcht1 -0xbf629(%rip)        # 51d73 <pf_target_0_3>
  11139c:	0f 18 15 db db f5 ff 	prefetcht1 -0xa2425(%rip)        # 6ef7e <pf_target_0_4>
  1113a3:	0f 18 15 66 4b f6 ff 	prefetcht1 -0x9b49a(%rip)        # 75f10 <pf_target_0_5>
  1113aa:	0f 18 15 49 73 f5 ff 	prefetcht1 -0xa8cb7(%rip)        # 686fa <pf_target_0_6>
  1113b1:	0f 18 15 f8 fe f5 ff 	prefetcht1 -0xa0108(%rip)        # 712b0 <pf_target_0_7>

00000000001113b8 <pf_jump_0>:
  1113b8:	e9 33 73 f5 ff       	jmp    686f0 <pf_callee_0>
  1113bd:	0f 1f 00             	nopl   (%rax)

00000000001113c0 <pf_call_1>:
  1113c0:	0f 18 15 d9 f7 f1 ff 	prefetcht1 -0xe0827(%rip)        # 30ba0 <pf_target_1_0>
  1113c7:	0f 18 15 12 74 f3 ff 	prefetcht1 -0xc8bee(%rip)        # 487e0 <pf_target_1_1>

00000000001113ce <pf_jump_1>:
  1113ce:	e9 6d 9f ff ff       	jmp    10b340 <pf_callee_1>
