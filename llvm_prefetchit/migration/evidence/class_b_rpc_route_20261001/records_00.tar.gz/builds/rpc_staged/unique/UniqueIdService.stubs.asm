
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_staged/unique/call-stub-kyhobpis/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000119380 <pf_call_0>:
  119380:	0f 18 15 f3 9a f4 ff 	prefetcht1 -0xb650d(%rip)        # 62e7a <pf_target_0_0>
  119387:	0f 18 15 f0 2b f3 ff 	prefetcht1 -0xcd410(%rip)        # 4bf7e <pf_target_0_1>
  11938e:	0f 18 15 28 9e f4 ff 	prefetcht1 -0xb61d8(%rip)        # 631bd <pf_target_0_2>
  119395:	0f 18 15 24 69 f4 ff 	prefetcht1 -0xb96dc(%rip)        # 5fcc0 <pf_target_0_3>
  11939c:	0f 18 15 d0 32 f3 ff 	prefetcht1 -0xccd30(%rip)        # 4c673 <pf_target_0_4>
  1193a3:	0f 18 15 26 5e f4 ff 	prefetcht1 -0xba1da(%rip)        # 5f1d0 <pf_target_0_5>
  1193aa:	0f 18 15 a0 2c f3 ff 	prefetcht1 -0xcd360(%rip)        # 4c051 <pf_target_0_6>

00000000001193b1 <pf_jump_0>:
  1193b1:	e9 0a a2 ff ff       	jmp    1135c0 <pf_callee_0>
  1193b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1193bd:	00 00 00 

00000000001193c0 <pf_call_1>:
  1193c0:	0f 18 15 36 ce f6 ff 	prefetcht1 -0x931ca(%rip)        # 861fd <pf_target_1_0>

00000000001193c7 <pf_jump_1>:
  1193c7:	e9 74 9f ff ff       	jmp    113340 <pf_callee_1>
