
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_staged/userreview/call-stub-sq0ps4cc/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000001e2380 <pf_call_0>:
  1e2380:	0f 18 15 b8 f9 e8 ff 	prefetcht1 -0x170648(%rip)        # 71d3f <pf_target_0_0>
  1e2387:	0f 18 15 c2 76 e8 ff 	prefetcht1 -0x17893e(%rip)        # 69a50 <pf_target_0_1>
  1e238e:	0f 18 15 29 0b ea ff 	prefetcht1 -0x15f4d7(%rip)        # 82ebe <pf_target_0_2>
  1e2395:	0f 18 15 1a 0f ea ff 	prefetcht1 -0x15f0e6(%rip)        # 832b6 <pf_target_0_3>
  1e239c:	0f 18 15 5b 75 ea ff 	prefetcht1 -0x158aa5(%rip)        # 898fe <pf_target_0_4>
  1e23a3:	0f 18 15 95 0e ea ff 	prefetcht1 -0x15f16b(%rip)        # 8323f <pf_target_0_5>
  1e23aa:	0f 18 15 0f 5b eb ff 	prefetcht1 -0x14a4f1(%rip)        # 97ec0 <pf_target_0_6>
  1e23b1:	0f 18 15 86 6f e8 ff 	prefetcht1 -0x17907a(%rip)        # 6933e <pf_target_0_7>

00000000001e23b8 <pf_jump_0>:
  1e23b8:	e9 e3 0a ea ff       	jmp    82ea0 <pf_callee_0>
  1e23bd:	0f 1f 00             	nopl   (%rax)

00000000001e23c0 <pf_call_1>:
  1e23c0:	0f 18 15 99 75 e8 ff 	prefetcht1 -0x178a67(%rip)        # 69960 <pf_target_1_0>
  1e23c7:	0f 18 15 f1 d3 e6 ff 	prefetcht1 -0x192c0f(%rip)        # 4f7bf <pf_target_1_1>
  1e23ce:	0f 18 15 ea e3 e6 ff 	prefetcht1 -0x191c16(%rip)        # 507bf <pf_target_1_2>

00000000001e23d5 <pf_jump_1>:
  1e23d5:	e9 66 4f ff ff       	jmp    1d7340 <pf_callee_1>
