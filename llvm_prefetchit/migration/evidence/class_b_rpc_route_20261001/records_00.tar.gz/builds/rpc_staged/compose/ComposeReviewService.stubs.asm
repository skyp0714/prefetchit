
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_staged/compose/call-stub-sv3u0evy/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000356380 <pf_call_0>:
  356380:	0f 18 15 f7 26 d9 ff 	prefetcht1 -0x26d909(%rip)        # e8a7e <pf_target_0_0>
  356387:	0f 18 15 f2 f1 db ff 	prefetcht1 -0x240e0e(%rip)        # 115580 <pf_target_0_1>
  35638e:	0f 18 15 b0 25 d9 ff 	prefetcht1 -0x26da50(%rip)        # e8945 <pf_target_0_2>
  356395:	0f 18 15 22 aa f0 ff 	prefetcht1 -0xf55de(%rip)        # 260dbe <pf_target_0_3>

000000000035639c <pf_jump_0>:
  35639c:	e9 0f cb fe ff       	jmp    342eb0 <pf_callee_0>
  3563a1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  3563a8:	00 00 00 
  3563ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000003563b0 <pf_call_1>:
  3563b0:	0f 18 15 c6 e6 d4 ff 	prefetcht1 -0x2b193a(%rip)        # a4a7d <pf_target_1_0>
  3563b7:	0f 18 15 08 eb d4 ff 	prefetcht1 -0x2b14f8(%rip)        # a4ec6 <pf_target_1_1>
  3563be:	0f 18 15 76 e6 d4 ff 	prefetcht1 -0x2b198a(%rip)        # a4a3b <pf_target_1_2>
  3563c5:	0f 18 15 ef 8f d6 ff 	prefetcht1 -0x297011(%rip)        # bf3bb <pf_target_1_3>

00000000003563cc <pf_jump_1>:
  3563cc:	e9 6f c2 fe ff       	jmp    342640 <pf_callee_1>
  3563d1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  3563d8:	00 00 00 
  3563db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000003563e0 <pf_call_2>:
  3563e0:	0f 18 15 e0 87 d9 ff 	prefetcht1 -0x267820(%rip)        # eebc7 <pf_target_2_0>
  3563e7:	0f 18 15 d2 36 dc ff 	prefetcht1 -0x23c92e(%rip)        # 119ac0 <pf_target_2_1>
  3563ee:	0f 18 15 7b 5d d7 ff 	prefetcht1 -0x28a285(%rip)        # cc170 <pf_target_2_2>

00000000003563f5 <pf_jump_2>:
  3563f5:	e9 16 cb fe ff       	jmp    342f10 <pf_callee_2>
  3563fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000356400 <pf_call_3>:
  356400:	0f 18 15 29 5e d5 ff 	prefetcht1 -0x2aa1d7(%rip)        # ac230 <pf_target_3_0>
  356407:	0f 18 15 b8 02 d5 ff 	prefetcht1 -0x2afd48(%rip)        # a66c6 <pf_target_3_1>
  35640e:	0f 18 15 eb fd d4 ff 	prefetcht1 -0x2b0215(%rip)        # a6200 <pf_target_3_2>
  356415:	0f 18 15 e4 69 e9 ff 	prefetcht1 -0x16961c(%rip)        # 1ece00 <pf_target_3_3>

000000000035641c <pf_jump_3>:
  35641c:	e9 ff c2 fe ff       	jmp    342720 <pf_callee_3>
  356421:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  356428:	00 00 00 
  35642b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000356430 <pf_call_4>:
  356430:	0f 18 15 49 f1 db ff 	prefetcht1 -0x240eb7(%rip)        # 115580 <pf_target_0_1>
  356437:	0f 18 15 40 48 d9 ff 	prefetcht1 -0x26b7c0(%rip)        # eac7e <pf_target_4_1>
  35643e:	0f 18 15 2b 5d d7 ff 	prefetcht1 -0x28a2d5(%rip)        # cc170 <pf_target_2_2>
  356445:	0f 18 15 a4 65 d7 ff 	prefetcht1 -0x289a5c(%rip)        # cc9f0 <pf_target_4_3>

000000000035644c <pf_jump_4>:
  35644c:	e9 4f cb fe ff       	jmp    342fa0 <pf_callee_4>
  356451:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  356458:	00 00 00 
  35645b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000356460 <pf_call_5>:
  356460:	0f 18 15 09 ce df ff 	prefetcht1 -0x2031f7(%rip)        # 153270 <pf_target_5_0>
  356467:	0f 18 15 51 a1 e1 ff 	prefetcht1 -0x1e5eaf(%rip)        # 1705bf <pf_target_5_1>
  35646e:	0f 18 15 03 bc d4 ff 	prefetcht1 -0x2b43fd(%rip)        # a2078 <pf_target_5_2>
  356475:	0f 18 15 81 b2 d4 ff 	prefetcht1 -0x2b4d7f(%rip)        # a16fd <pf_target_5_3>

000000000035647c <pf_jump_5>:
  35647c:	e9 8f c0 fe ff       	jmp    342510 <pf_callee_5>
  356481:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  356488:	00 00 00 
  35648b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000356490 <pf_call_6>:
  356490:	0f 18 15 e7 36 d9 ff 	prefetcht1 -0x26c919(%rip)        # e9b7e <pf_target_6_0>
  356497:	0f 18 15 1f cd d8 ff 	prefetcht1 -0x2732e1(%rip)        # e31bd <pf_target_6_1>
  35649e:	0f 18 15 cb 5c d7 ff 	prefetcht1 -0x28a335(%rip)        # cc170 <pf_target_2_2>
  3564a5:	0f 18 15 d4 f0 db ff 	prefetcht1 -0x240f2c(%rip)        # 115580 <pf_target_0_1>

00000000003564ac <pf_jump_6>:
  3564ac:	e9 8f ca fe ff       	jmp    342f40 <pf_callee_6>
  3564b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  3564b8:	00 00 00 
  3564bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000003564c0 <pf_call_7>:
  3564c0:	0f 18 15 36 9a d4 ff 	prefetcht1 -0x2b65ca(%rip)        # 9fefd <pf_target_7_0>
  3564c7:	0f 18 15 f1 cd df ff 	prefetcht1 -0x20320f(%rip)        # 1532bf <pf_target_7_1>
  3564ce:	0f 18 15 9b cd df ff 	prefetcht1 -0x203265(%rip)        # 153270 <pf_target_5_0>
  3564d5:	0f 18 15 a3 a2 de ff 	prefetcht1 -0x215d5d(%rip)        # 14077f <pf_target_7_3>

00000000003564dc <pf_jump_7>:
  3564dc:	e9 7f bf fe ff       	jmp    342460 <pf_callee_7>
  3564e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  3564e8:	00 00 00 
  3564eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000003564f0 <pf_call_8>:
  3564f0:	0f 18 15 bf de d8 ff 	prefetcht1 -0x272141(%rip)        # e43b6 <pf_target_8_0>

00000000003564f7 <pf_jump_8>:
  3564f7:	e9 74 ca fe ff       	jmp    342f70 <pf_callee_8>
  3564fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000356500 <pf_call_9>:
  356500:	0f 18 15 69 cd df ff 	prefetcht1 -0x203297(%rip)        # 153270 <pf_target_5_0>
  356507:	0f 18 15 ac cb d4 ff 	prefetcht1 -0x2b3454(%rip)        # a30ba <pf_target_9_1>
  35650e:	0f 18 15 0a d0 d4 ff 	prefetcht1 -0x2b2ff6(%rip)        # a351f <pf_target_9_2>
  356515:	0f 18 15 a3 a0 e1 ff 	prefetcht1 -0x1e5f5d(%rip)        # 1705bf <pf_target_5_1>

000000000035651c <pf_jump_9>:
  35651c:	e9 7f c0 fe ff       	jmp    3425a0 <pf_callee_9>
  356521:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  356528:	00 00 00 
  35652b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000356530 <pf_call_10>:
  356530:	0f 18 15 49 a5 ed ff 	prefetcht1 -0x125ab7(%rip)        # 230a80 <pf_target_10_0>
  356537:	0f 18 15 82 39 d7 ff 	prefetcht1 -0x28c67e(%rip)        # c9ec0 <pf_target_10_1>

000000000035653e <pf_jump_10>:
  35653e:	e9 fd c2 fe ff       	jmp    342840 <pf_callee_10>
