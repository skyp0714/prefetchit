
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_staged/moviereview/call-stub-q2bg4bmi/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000001e2380 <pf_call_0>:
  1e2380:	0f 18 15 b9 56 eb ff 	prefetcht1 -0x14a947(%rip)        # 97a40 <pf_target_0_0>
  1e2387:	0f 18 15 88 09 ea ff 	prefetcht1 -0x15f678(%rip)        # 82d16 <pf_target_0_1>
  1e238e:	0f 18 15 a8 05 ea ff 	prefetcht1 -0x15fa58(%rip)        # 8293d <pf_target_0_2>
  1e2395:	0f 18 15 d4 70 e8 ff 	prefetcht1 -0x178f2c(%rip)        # 69470 <pf_target_0_3>
  1e239c:	0f 18 15 1c 79 ea ff 	prefetcht1 -0x1586e4(%rip)        # 89cbf <pf_target_0_4>
  1e23a3:	0f 18 15 f5 08 ea ff 	prefetcht1 -0x15f70b(%rip)        # 82c9f <pf_target_0_5>
  1e23aa:	0f 18 15 6f ae e4 ff 	prefetcht1 -0x1b5191(%rip)        # 2d220 <pf_target_0_6>

00000000001e23b1 <pf_jump_0>:
  1e23b1:	e9 4a 05 ea ff       	jmp    82900 <pf_callee_0>
  1e23b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1e23bd:	00 00 00 

00000000001e23c0 <pf_call_1>:
  1e23c0:	0f 18 15 37 7e f5 ff 	prefetcht1 -0xa81c9(%rip)        # 13a1fe <pf_target_1_0>
  1e23c7:	0f 18 15 2b 2f e6 ff 	prefetcht1 -0x19d0d5(%rip)        # 452f9 <pf_target_1_1>
  1e23ce:	0f 18 15 eb 14 e8 ff 	prefetcht1 -0x17eb15(%rip)        # 638c0 <pf_target_1_2>

00000000001e23d5 <pf_jump_1>:
  1e23d5:	e9 66 4f ff ff       	jmp    1d7340 <pf_callee_1>
