
/storage/prefetchit/class_b_rpc_route_20261001/builds/rpc_staged/rating/call-stub-3vk5rdgt/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000038f380 <pf_call_0>:
  38f380:	0f 18 15 b8 ac cf ff 	prefetcht1 -0x305348(%rip)        # 8a03f <pf_target_0_0>
  38f387:	0f 18 15 b0 ed cf ff 	prefetcht1 -0x301250(%rip)        # 8e13e <pf_target_0_1>
  38f38e:	0f 18 15 69 c9 cf ff 	prefetcht1 -0x303697(%rip)        # 8bcfe <pf_target_0_2>
  38f395:	0f 18 15 e2 6c cf ff 	prefetcht1 -0x30931e(%rip)        # 8607e <pf_target_0_3>
  38f39c:	0f 18 15 c1 02 d3 ff 	prefetcht1 -0x2cfd3f(%rip)        # bf664 <pf_target_0_4>
  38f3a3:	0f 18 15 d6 66 cf ff 	prefetcht1 -0x30992a(%rip)        # 85a80 <pf_target_0_5>
  38f3aa:	0f 18 15 cf 15 d2 ff 	prefetcht1 -0x2dea31(%rip)        # b0980 <pf_target_0_6>

000000000038f3b1 <pf_jump_0>:
  38f3b1:	e9 7a 85 fe ff       	jmp    377930 <pf_callee_0>
  38f3b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  38f3bd:	00 00 00 

000000000038f3c0 <pf_call_1>:
  38f3c0:	0f 18 15 69 87 cd ff 	prefetcht1 -0x327897(%rip)        # 67b30 <pf_target_1_0>
  38f3c7:	0f 18 15 72 95 cc ff 	prefetcht1 -0x336a8e(%rip)        # 58940 <pf_target_1_1>
  38f3ce:	0f 18 15 0a 56 cc ff 	prefetcht1 -0x33a9f6(%rip)        # 549df <pf_target_1_2>

000000000038f3d5 <pf_jump_1>:
  38f3d5:	e9 a6 7f fe ff       	jmp    377380 <pf_callee_1>
  38f3da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000038f3e0 <pf_call_2>:
  38f3e0:	0f 18 15 f9 4a cf ff 	prefetcht1 -0x30b507(%rip)        # 83ee0 <pf_target_2_0>
  38f3e7:	0f 18 15 82 70 cc ff 	prefetcht1 -0x338f7e(%rip)        # 56470 <pf_target_2_1>
  38f3ee:	0f 18 15 db 3c cf ff 	prefetcht1 -0x30c325(%rip)        # 830d0 <pf_target_2_2>
  38f3f5:	0f 18 15 84 66 cf ff 	prefetcht1 -0x30997c(%rip)        # 85a80 <pf_target_0_5>
  38f3fc:	0f 18 15 f9 72 cc ff 	prefetcht1 -0x338d07(%rip)        # 566fc <pf_target_2_4>
  38f403:	0f 18 15 f6 70 cc ff 	prefetcht1 -0x338f0a(%rip)        # 56500 <pf_target_2_5>
  38f40a:	0f 18 15 0f 8a e6 ff 	prefetcht1 -0x1975f1(%rip)        # 1f7e20 <pf_target_2_6>

000000000038f411 <pf_jump_2>:
  38f411:	e9 8a 80 fe ff       	jmp    3774a0 <pf_callee_2>
  38f416:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  38f41d:	00 00 00 

000000000038f420 <pf_call_3>:
  38f420:	0f 18 15 94 5f d9 ff 	prefetcht1 -0x26a06c(%rip)        # 1253bb <pf_target_3_0>
  38f427:	0f 18 15 c2 6f ca ff 	prefetcht1 -0x35903e(%rip)        # 363f0 <pf_target_3_1>
  38f42e:	0f 18 15 3b 7f cc ff 	prefetcht1 -0x3380c5(%rip)        # 57370 <pf_target_3_2>

000000000038f435 <pf_jump_3>:
  38f435:	e9 e6 80 fe ff       	jmp    377520 <pf_callee_3>
