import json,subprocess,time
from pathlib import Path
r=Path(__file__).parent;s=Path('/home/hnpark2/prefetchit/llvm_prefetchit/scripts/class_b')
with (r/'smoke_rpc_worker_it0.log').open('w') as f:subprocess.run(['python3',str(s/'rpc_future_study.py'),'platform_smoke',str(r/'smoke_rpc_worker_it0.json')],stdout=f,stderr=subprocess.STDOUT,check=True)
assert json.loads((r/'smoke/rpc_worker_it0/result.json').read_text())['valid']
print('IT0 smoke passed',flush=True)
with (r/'screen2.log').open('w') as f:subprocess.run(['python3',str(s/'temporal_path_campaign.py'),'campaign',str(r/'screen2_spec.json')],stdout=f,stderr=subprocess.STDOUT,check=True)
print('screen2 complete',flush=True)
