import json,subprocess,sys
from pathlib import Path
sys.path.insert(0,'/home/hnpark2/prefetchit/llvm_prefetchit/scripts/class_b')
import dense_build as b
from e2e_lbr import remove_generated
r=Path('/storage/prefetchit/class_b_temporal_20261001');repo=Path('/home/hnpark2/prefetchit')
assert json.loads((r/'screen1/complete.json').read_text())['valid']
assert json.loads((r/'screen1/evaluation.json').read_text())['complete']
b.space(r);dest=r/'tests_alignment';log=r/'tests_alignment.log'
files=['test_got_call_stub.py','test_call_stub_prefetch.py','test_temporal_path_refine.py','test_temporal_path_residual.py']
command=[str(repo/'profiling/.venv/bin/python'),'-m','pytest','-q',*[str(repo/'llvm_prefetchit/tests'/name) for name in files],'--basetemp='+str(dest)]
b.save(r/'tests_alignment_protocol.json',dict(command=command,builder_sha256=b.sha(repo/'llvm_prefetchit/tools/call_stub_prefetch.py'),tests={name:b.sha(repo/'llvm_prefetchit/tests'/name) for name in files}))
try:
 with log.open('w') as stream:run=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
 b.save(r/'tests_alignment_result.json',dict(valid=run.returncode==0,returncode=run.returncode,log=log.read_text()))
finally:
 paths=[]
 for path in dest.rglob('*'):
  if path.is_file() and not path.is_symlink():
   with path.open('rb') as stream:magic=stream.read(4)
   if magic==b'\x7fELF':paths.append(path)
 if paths:remove_generated(paths,r/'tests_alignment_cleanup.json','Native ABI/layout validation completed; fixture sources, exact patches, settings and binary hashes retained.')
assert run.returncode==0
