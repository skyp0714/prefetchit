
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_native_it0/54771f7236ce5ab22b131b8381b31d23e0a8b2b45695d559a9c47f572e2c3859/UniqueIdService:     file format elf64-x86-64


Disassembly of section .text.prefetch_calls:

0000000000113340 <.text.prefetch_calls>:
  113340:	0f 18 3d b9 2e f3 ff                            	prefetchit0 -0xcd147(%rip)        # 46200 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0x60>
  113347:	0f 18 3d d2 85 f3 ff                            	prefetchit0 -0xc7a2e(%rip)        # 4b920 <_ZNK13media_service13TextMapReader10ForeachKeyESt8functionIFN11opentracing2v28expectedIvSt10error_codeEENS3_11string_viewES7_EE>
  11334e:	0f 18 3d 4b 2e f3 ff                            	prefetchit0 -0xcd1b5(%rip)        # 461a0 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_>
  113355:	0f 18 3d b4 38 f3 ff                            	prefetchit0 -0xcc74c(%rip)        # 46c10 <_ZNSt17_Function_handlerIFN11opentracing2v28expectedIvSt10error_codeEENS1_11string_viewES5_EZNK13jaegertracing11propagation10PropagatorIRKNS1_13TextMapReaderERKNS1_13TextMapWriterEE7extractESC_EUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESO_E_E9_M_invokeERKSt9_Any_dataOS5_SU_>
  11335c:	0f 18 3d e4 2e f3 ff                            	prefetchit0 -0xcd11c(%rip)        # 46247 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0xa7>
  113363:	0f 18 3d 16 86 f3 ff                            	prefetchit0 -0xc79ea(%rip)        # 4b980 <_ZNK13media_service13TextMapReader10ForeachKeyESt8functionIFN11opentracing2v28expectedIvSt10error_codeEENS3_11string_viewES7_EE+0x60>
  11336a:	0f 18 3d d0 85 f3 ff                            	prefetchit0 -0xc7a30(%rip)        # 4b941 <_ZNK13media_service13TextMapReader10ForeachKeyESt8functionIFN11opentracing2v28expectedIvSt10error_codeEENS3_11string_viewES7_EE+0x21>
  113371:	41 53                                           	push   %r11
  113373:	4c 8b 1d 2e de ff ff                            	mov    -0x21d2(%rip),%r11        # 1111a8 <_ZN11opentracing2v26Tracer6GlobalEv@Base>
  11337a:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  113382:	41 5b                                           	pop    %r11
  113384:	e9 c7 3f f1 ff                                  	jmp    27350 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  113389:	0f 1f 80 00 00 00 00                            	nopl   0x0(%rax)
  113390:	0f 18 3d a9 02 f2 ff                            	prefetchit0 -0xdfd57(%rip)        # 33640 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  113397:	0f 18 3d a3 90 f3 ff                            	prefetchit0 -0xc6f5d(%rip)        # 4c441 <_ZNSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS2_11SpanContextEESaIS7_EE17_M_realloc_insertIJRKS3_RKS6_EEEvN9__gnu_cxx17__normal_iteratorIPS7_S9_EEDpOT_+0x41>
  11339e:	41 53                                           	push   %r11
  1133a0:	4c 8b 1d 41 dd ff ff                            	mov    -0x22bf(%rip),%r11        # 1110e8 <_Znwm@GLIBCXX_3.4>
  1133a7:	41 0f 18 93 b0 06 00 00                         	prefetcht1 0x6b0(%r11)
  1133af:	41 0f 18 93 d2 06 00 00                         	prefetcht1 0x6d2(%r11)
  1133b7:	4c 8b 1d 0a e1 ff ff                            	mov    -0x1ef6(%rip),%r11        # 1114c8 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1133be:	41 0f 18 93 10 5d fe ff                         	prefetcht1 -0x1a2f0(%r11)
  1133c6:	41 0f 18 93 c5 1f 00 00                         	prefetcht1 0x1fc5(%r11)
  1133ce:	41 5b                                           	pop    %r11
  1133d0:	e9 7b 3f f1 ff                                  	jmp    27350 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  1133d5:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1133df:	90                                              	nop
  1133e0:	41 53                                           	push   %r11
  1133e2:	4c 8b 1d df e0 ff ff                            	mov    -0x1f21(%rip),%r11        # 1114c8 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1133e9:	41 0f 18 93 50 79 00 00                         	prefetcht1 0x7950(%r11)
  1133f1:	4c 8b 1d 88 e3 ff ff                            	mov    -0x1c78(%rip),%r11        # 111780 <_ZNSt7__cxx1119basic_ostringstreamIcSt11char_traitsIcESaIcEEC1Ev@GLIBCXX_3.4.26>
  1133f8:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  113400:	41 0f 18 93 34 00 00 00                         	prefetcht1 0x34(%r11)
  113408:	41 5b                                           	pop    %r11
  11340a:	e9 41 3f f1 ff                                  	jmp    27350 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  11340f:	90                                              	nop
  113410:	41 53                                           	push   %r11
  113412:	4c 8b 1d c7 dd ff ff                            	mov    -0x2239(%rip),%r11        # 1111e0 <_ZNSt7__cxx1118basic_stringstreamIcSt11char_traitsIcESaIcEEC1Ev@GLIBCXX_3.4.26>
  113419:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  113421:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
  113429:	41 5b                                           	pop    %r11
  11342b:	e9 10 3f f1 ff                                  	jmp    27340 <pthread_mutex_lock@plt>
  113430:	41 53                                           	push   %r11
  113432:	4c 8b 1d 8f e3 ff ff                            	mov    -0x1c71(%rip),%r11        # 1117c8 <_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l@GLIBCXX_3.4.9>
  113439:	41 0f 18 93 20 23 ff ff                         	prefetcht1 -0xdce0(%r11)
  113441:	41 5b                                           	pop    %r11
  113443:	e9 98 40 f1 ff                                  	jmp    274e0 <_ZNSo9_M_insertIlEERSoT_@plt>
  113448:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  113450:	41 53                                           	push   %r11
  113452:	4c 8b 1d 37 e1 ff ff                            	mov    -0x1ec9(%rip),%r11        # 111590 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm@GLIBCXX_3.4.21>
  113459:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  113461:	41 0f 18 93 22 00 00 00                         	prefetcht1 0x22(%r11)
  113469:	41 5b                                           	pop    %r11
  11346b:	e9 c0 42 f1 ff                                  	jmp    27730 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@plt>
  113470:	41 53                                           	push   %r11
  113472:	4c 8b 1d df e1 ff ff                            	mov    -0x1e21(%rip),%r11        # 111658 <strtoul@GLIBC_2.2.5>
  113479:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  113481:	41 5b                                           	pop    %r11
  113483:	e9 78 4b f1 ff                                  	jmp    28000 <__errno_location@plt>
  113488:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  113490:	41 53                                           	push   %r11
  113492:	4c 8b 1d bf e1 ff ff                            	mov    -0x1e41(%rip),%r11        # 111658 <strtoul@GLIBC_2.2.5>
  113499:	41 0f 18 93 50 05 00 00                         	prefetcht1 0x550(%r11)
  1134a1:	41 0f 18 93 60 05 00 00                         	prefetcht1 0x560(%r11)
  1134a9:	41 5b                                           	pop    %r11
  1134ab:	e9 00 48 f1 ff                                  	jmp    27cb0 <strtoul@plt>
  1134b0:	0f 18 3d 89 ce f7 ff                            	prefetchit0 -0x83177(%rip)        # 90340 <_ZN5boost3log12v2s_mt_posix4core14implementation15get_thread_dataEv>
  1134b7:	0f 18 3d 82 8c f7 ff                            	prefetchit0 -0x8737e(%rip)        # 8c140 <_ZNK5boost3log12v2s_mt_posix4core19get_logging_enabledEv+0x10>
  1134be:	0f 18 3d 0b 96 f7 ff                            	prefetchit0 -0x869f5(%rip)        # 8cad0 <_ZN5boost3log12v2s_mt_posix4core11open_recordERKNS1_13attribute_setE>
  1134c5:	0f 18 3d 44 c0 fb ff                            	prefetchit0 -0x43fbc(%rip)        # cf510 <_ZN5boost13thread_detail17enter_once_regionERNS_9once_flagE>
  1134cc:	0f 18 3d 2d 96 f7 ff                            	prefetchit0 -0x869d3(%rip)        # 8cb00 <_ZN5boost3log12v2s_mt_posix4core11open_recordERKNS1_13attribute_setE+0x30>
  1134d3:	0f 18 3d c6 3c f8 ff                            	prefetchit0 -0x7c33a(%rip)        # 971a0 <_ZN5boost3log12v2s_mt_posix7sources3aux18get_severity_levelEv>
  1134da:	0f 18 3d 1f 3d f8 ff                            	prefetchit0 -0x7c2e1(%rip)        # 97200 <_ZN5boost3log12v2s_mt_posix7sources3aux18get_severity_levelEv+0x60>
  1134e1:	0f 18 3d f8 2c f7 ff                            	prefetchit0 -0x8d308(%rip)        # 861e0 <_ZN5boost3log12v2s_mt_posix19attribute_value_setC1ERKNS1_13attribute_setES5_S5_m>
  1134e8:	e9 f3 68 f9 ff                                  	jmp    a9de0 <_ZN5boost3log12v2s_mt_posix7trivial6logger3getEv>
  1134ed:	0f 1f 00                                        	nopl   (%rax)
  1134f0:	0f 18 3d 4d 16 fb ff                            	prefetchit0 -0x4e9b3(%rip)        # c4b44 <_ZN5boost6detail23get_current_thread_dataEv+0x14>
  1134f7:	0f 18 3d 52 1b fb ff                            	prefetchit0 -0x4e4ae(%rip)        # c5050 <_ZN5boost6detail12get_tss_dataEPKv>
  1134fe:	0f 18 3d 8b 67 f9 ff                            	prefetchit0 -0x69875(%rip)        # a9c90 <_ZNK5boost3log12v2s_mt_posix3aux20thread_specific_base11get_contentEv>
  113505:	0f 18 3d 24 16 fb ff                            	prefetchit0 -0x4e9dc(%rip)        # c4b30 <_ZN5boost6detail23get_current_thread_dataEv>
  11350c:	0f 18 3d 1d 8c f7 ff                            	prefetchit0 -0x873e3(%rip)        # 8c130 <_ZNK5boost3log12v2s_mt_posix4core19get_logging_enabledEv>
  113513:	41 53                                           	push   %r11
  113515:	4c 8b 1d bc de ff ff                            	mov    -0x2144(%rip),%r11        # 1113d8 <pthread_rwlock_rdlock@GLIBC_2.34>
  11351c:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  113524:	4c 8b 1d 25 e3 ff ff                            	mov    -0x1cdb(%rip),%r11        # 111850 <pthread_getspecific@GLIBC_2.34>
  11352b:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  113533:	41 0f 18 93 20 00 00 00                         	prefetcht1 0x20(%r11)
  11353b:	41 5b                                           	pop    %r11
  11353d:	e9 be f3 f1 ff                                  	jmp    32900 <_ZN5boost3log12v2s_mt_posix7sources22basic_composite_loggerIcNS2_18severity_logger_mtINS1_7trivial14severity_levelEEENS2_18multi_thread_modelINS1_3aux14light_rw_mutexEEENS2_8featuresIJNS2_8severityIS6_EEEEEE11open_recordINS_9parameter3aux25tagged_argument_list_of_1INSJ_15tagged_argumentINS1_8keywords3tag8severityEKS6_EEEEEENS1_6recordERKT_>
  113542:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  11354c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  113550:	0f 18 3d 69 b9 f4 ff                            	prefetchit0 -0xb4697(%rip)        # 5eec0 <_ZN13media_service12ThriftClientINS_26ComposeReviewServiceClientEE7ConnectEv>
  113557:	0f 18 3d 18 09 f2 ff                            	prefetchit0 -0xdf6e8(%rip)        # 33e76 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_26ComposeReviewServiceClientEEEE3PopEv+0x706>
  11355e:	0f 18 3d cb 9d f5 ff                            	prefetchit0 -0xa6235(%rip)        # 6d330 <_ZN13media_service26ComposeReviewServiceClient14UploadUniqueIdEllRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES7_St4lessIS7_ESaISt4pairIKS7_S7_EEE>
  113565:	e9 06 02 f2 ff                                  	jmp    33770 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_26ComposeReviewServiceClientEEEE3PopEv>
  11356a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  113570:	0f 18 3d d9 b9 f4 ff                            	prefetchit0 -0xb4627(%rip)        # 5ef50 <_ZN13media_service12ThriftClientINS_26ComposeReviewServiceClientEE9KeepAliveEv>
  113577:	41 53                                           	push   %r11
  113579:	4c 8b 1d d0 de ff ff                            	mov    -0x2130(%rip),%r11        # 111450 <_ZNSt18condition_variable10notify_oneEv@GLIBCXX_3.4.11>
  113580:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  113588:	4c 8b 1d 39 df ff ff                            	mov    -0x20c7(%rip),%r11        # 1114c8 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  11358f:	41 0f 18 93 41 ad ff ff                         	prefetcht1 -0x52bf(%r11)
  113597:	41 5b                                           	pop    %r11
  113599:	e9 32 0d f2 ff                                  	jmp    342d0 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_26ComposeReviewServiceClientEEEE4PushEPS3_>
  11359e:	66 90                                           	xchg   %ax,%ax
  1135a0:	41 53                                           	push   %r11
  1135a2:	4c 8b 1d f7 da ff ff                            	mov    -0x2509(%rip),%r11        # 1110a0 <_ZdlPvm@CXXABI_1.3.9>
  1135a9:	41 0f 18 93 50 1b ff ff                         	prefetcht1 -0xe4b0(%r11)
  1135b1:	4c 8b 1d a8 df ff ff                            	mov    -0x2058(%rip),%r11        # 111560 <_ZNSt8ios_baseD2Ev@GLIBCXX_3.4>
  1135b8:	41 0f 18 93 61 ff ff ff                         	prefetcht1 -0x9f(%r11)
  1135c0:	4c 8b 1d 19 e2 ff ff                            	mov    -0x1de7(%rip),%r11        # 1117e0 <_ZNSt6localeD1Ev@GLIBCXX_3.4>
  1135c7:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1135cf:	41 5b                                           	pop    %r11
  1135d1:	e9 ca 8f f3 ff                                  	jmp    4c5a0 <_ZNSt6vectorIN11opentracing2v29LogRecordESaIS2_EED2Ev>
  1135d6:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1135e0:	41 53                                           	push   %r11
  1135e2:	4c 8b 1d b7 da ff ff                            	mov    -0x2549(%rip),%r11        # 1110a0 <_ZdlPvm@CXXABI_1.3.9>
  1135e9:	41 0f 18 93 30 41 ff ff                         	prefetcht1 -0xbed0(%r11)
  1135f1:	41 5b                                           	pop    %r11
  1135f3:	e9 48 3b f1 ff                                  	jmp    27140 <_ZdlPvm@plt>
  1135f8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  113600:	41 53                                           	push   %r11
  113602:	4c 8b 1d bf de ff ff                            	mov    -0x2141(%rip),%r11        # 1114c8 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  113609:	41 0f 18 93 41 f5 ff ff                         	prefetcht1 -0xabf(%r11)
  113611:	41 5b                                           	pop    %r11
  113613:	e9 a8 49 f1 ff                                  	jmp    27fc0 <_ZNSt6localeD1Ev@plt>
  113618:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  113620:	0f 18 3d da 15 f5 ff                            	prefetchit0 -0xaea26(%rip)        # 64c01 <_ZN13media_service24UniqueIdServiceProcessor22process_UploadUniqueIdEiPN6apache6thrift8protocol9TProtocolES5_Pv+0x281>
  113627:	e9 44 90 f3 ff                                  	jmp    4c670 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  11362c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  113630:	0f 18 3d c9 d2 f3 ff                            	prefetchit0 -0xc2d37(%rip)        # 50900 <_ZN5boost3log12v2s_mt_posix3aux14light_functionIFbRKNS1_19attribute_value_setEEE4implINS_7phoenix5actorINS_5proto7exprns_10basic_exprINSC_6tagns_3tag13greater_equalENSC_7argsns_5list2INS1_11expressions15attribute_actorINS1_7trivial14severity_levelENS1_16fallback_to_noneENSM_3tag8severityESB_EENSB_INSE_INSG_8terminalENSI_4termISN_EELl0EEEEEEELl2EEEEEE11invoke_implEPvS6_>
  113637:	e9 64 3b f8 ff                                  	jmp    971a0 <_ZN5boost3log12v2s_mt_posix7sources3aux18get_severity_levelEv>
  11363c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  113640:	41 53                                           	push   %r11
  113642:	4c 8b 1d 57 dd ff ff                            	mov    -0x22a9(%rip),%r11        # 1113a0 <_ZNSo9_M_insertImEERSoT_@GLIBCXX_3.4.9>
  113649:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  113651:	4c 8b 1d 70 e1 ff ff                            	mov    -0x1e90(%rip),%r11        # 1117c8 <_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l@GLIBCXX_3.4.9>
  113658:	41 0f 18 93 31 26 ff ff                         	prefetcht1 -0xd9cf(%r11)
  113660:	41 0f 18 93 10 29 ff ff                         	prefetcht1 -0xd6f0(%r11)
  113668:	41 0f 18 93 a0 f5 ff ff                         	prefetcht1 -0xa60(%r11)
  113670:	41 0f 18 93 b0 f5 ff ff                         	prefetcht1 -0xa50(%r11)
  113678:	4c 8b 1d 19 e2 ff ff                            	mov    -0x1de7(%rip),%r11        # 111898 <_ZNSt9basic_iosIcSt11char_traitsIcEE5clearESt12_Ios_Iostate@GLIBCXX_3.4>
  11367f:	41 0f 18 93 80 d7 00 00                         	prefetcht1 0xd780(%r11)
  113687:	41 5b                                           	pop    %r11
  113689:	e9 32 4d f3 ff                                  	jmp    483c0 <_ZNK13jaegertracing11SpanContext5printISoEEvRT_>
  11368e:	66 90                                           	xchg   %ax,%ax
  113690:	41 53                                           	push   %r11
  113692:	4c 8b 1d a7 dc ff ff                            	mov    -0x2359(%rip),%r11        # 111340 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode@GLIBCXX_3.4.21>
  113699:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1136a1:	41 0f 18 93 11 00 00 00                         	prefetcht1 0x11(%r11)
  1136a9:	41 5b                                           	pop    %r11
  1136ab:	e9 90 43 f1 ff                                  	jmp    27a40 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@plt>
  1136b0:	0f 18 3d 49 31 f3 ff                            	prefetchit0 -0xcceb7(%rip)        # 46800 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE11decodeValueERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  1136b7:	e9 34 3a f1 ff                                  	jmp    270f0 <memcpy@plt>
  1136bc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1136c0:	0f 18 3d b9 31 f3 ff                            	prefetchit0 -0xcce47(%rip)        # 46880 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE12normalizeKeyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  1136c7:	e9 f4 35 f3 ff                                  	jmp    46cc0 <_ZSt13__invoke_implIN11opentracing2v28expectedIvSt10error_codeEERZNK13jaegertracing11propagation10PropagatorIRKNS1_13TextMapReaderERKNS1_13TextMapWriterEE7extractESA_EUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESM_E_JNS1_11string_viewESP_EET_St14__invoke_otherOT0_DpOT1_>
  1136cc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1136d0:	0f 18 3d c9 4a f3 ff                            	prefetchit0 -0xcb537(%rip)        # 481a0 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_>
  1136d7:	e9 64 3a f1 ff                                  	jmp    27140 <_ZdlPvm@plt>
  1136dc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1136e0:	0f 18 3d 79 47 f1 ff                            	prefetchit0 -0xeb887(%rip)        # 27e60 <_ZSt18_Rb_tree_incrementPKSt18_Rb_tree_node_base@plt>
  1136e7:	41 53                                           	push   %r11
  1136e9:	4c 8b 1d 40 e0 ff ff                            	mov    -0x1fc0(%rip),%r11        # 111730 <_ZSt18_Rb_tree_incrementPKSt18_Rb_tree_node_base@GLIBCXX_3.4>
  1136f0:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1136f8:	41 5b                                           	pop    %r11
  1136fa:	e9 41 3a f1 ff                                  	jmp    27140 <_ZdlPvm@plt>
  1136ff:	90                                              	nop
  113700:	41 53                                           	push   %r11
  113702:	4c 8b 1d 8f e1 ff ff                            	mov    -0x1e71(%rip),%r11        # 111898 <_ZNSt9basic_iosIcSt11char_traitsIcEE5clearESt12_Ios_Iostate@GLIBCXX_3.4>
  113709:	41 0f 18 93 c0 2d 00 00                         	prefetcht1 0x2dc0(%r11)
  113711:	41 0f 18 93 80 35 00 00                         	prefetcht1 0x3580(%r11)
  113719:	41 5b                                           	pop    %r11
  11371b:	e9 70 42 f1 ff                                  	jmp    27990 <_ZN13jaegertracing11SpanContext10fromStreamERSi@plt>
  113720:	0f 18 3d 19 f9 f2 ff                            	prefetchit0 -0xd06e7(%rip)        # 43040 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  113727:	0f 18 3d e2 3f f3 ff                            	prefetchit0 -0xcc01e(%rip)        # 47710 <_ZN13jaegertracingeqERKNS_11SpanContextES2_>
  11372e:	e9 0d 45 f3 ff                                  	jmp    47c40 <_ZN13jaegertracing11SpanContext4swapERS0_>
  113733:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  11373d:	0f 1f 00                                        	nopl   (%rax)
  113740:	41 53                                           	push   %r11
  113742:	4c 8b 1d 57 d9 ff ff                            	mov    -0x26a9(%rip),%r11        # 1110a0 <_ZdlPvm@CXXABI_1.3.9>
  113749:	41 0f 18 93 90 37 ff ff                         	prefetcht1 -0xc870(%r11)
  113751:	4c 8b 1d 08 de ff ff                            	mov    -0x21f8(%rip),%r11        # 111560 <_ZNSt8ios_baseD2Ev@GLIBCXX_3.4>
  113758:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  113760:	41 5b                                           	pop    %r11
  113762:	e9 d9 39 f1 ff                                  	jmp    27140 <_ZdlPvm@plt>
  113767:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  113770:	0f 18 3d 49 48 f1 ff                            	prefetchit0 -0xeb7b7(%rip)        # 27fc0 <_ZNSt6localeD1Ev@plt>
  113777:	e9 64 3b f1 ff                                  	jmp    272e0 <pthread_mutex_unlock@plt>
  11377c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  113780:	0f 18 3d 79 2d f5 ff                            	prefetchit0 -0xad287(%rip)        # 66500 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv>
  113787:	e9 b4 39 f1 ff                                  	jmp    27140 <_ZdlPvm@plt>
  11378c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  113790:	0f 18 3d e0 2d f5 ff                            	prefetchit0 -0xad220(%rip)        # 66577 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x77>
  113797:	0f 18 3d c7 10 f5 ff                            	prefetchit0 -0xaef39(%rip)        # 64865 <_ZN13media_service24UniqueIdServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x515>
  11379e:	0f 18 3d 0b c5 f4 ff                            	prefetchit0 -0xb3af5(%rip)        # 5fcb0 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE17writeMessageBeginERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  1137a5:	0f 18 3d ea 0c f5 ff                            	prefetchit0 -0xaf316(%rip)        # 64496 <_ZN13media_service24UniqueIdServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x146>
  1137ac:	e9 bf 8e f3 ff                                  	jmp    4c670 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  1137b1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1137bb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1137c0:	0f 18 3d e9 96 f3 ff                            	prefetchit0 -0xc6917(%rip)        # 4ceb0 <_ZN5boost3log12v2s_mt_posix3aux27single_type_dispatcher_base12get_callbackEPNS1_15type_dispatcherENS_9typeindex14stl_type_indexE>
  1137c7:	0f 18 3d 32 6c f9 ff                            	prefetchit0 -0x693ce(%rip)        # aa400 <_ZN5boost3log12v2s_mt_posix7sources3aux14severity_levelINS1_7trivial14severity_levelEE4impl8dispatchERNS1_15type_dispatcherE>
  1137ce:	0f 18 3d eb 96 f3 ff                            	prefetchit0 -0xc6915(%rip)        # 4cec0 <_ZN5boost3log12v2s_mt_posix3aux27single_type_dispatcher_base12get_callbackEPNS1_15type_dispatcherENS_9typeindex14stl_type_indexE+0x10>
  1137d5:	e9 a6 d1 f3 ff                                  	jmp    50980 <_ZNK5boost3log12v2s_mt_posix15value_extractorINS1_7trivial14severity_levelENS1_16fallback_to_noneENS3_3tag8severityEEclERKNS1_14attribute_nameERKNS1_19attribute_value_setE>
  1137da:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1137e0:	0f 18 3d 49 3f f1 ff                            	prefetchit0 -0xec0b7(%rip)        # 27730 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@plt>
  1137e7:	0f 18 3d 8f 0b f5 ff                            	prefetchit0 -0xaf471(%rip)        # 6437d <_ZN13media_service24UniqueIdServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x2d>
  1137ee:	0f 18 3d 0b 49 f1 ff                            	prefetchit0 -0xeb6f5(%rip)        # 28100 <memcmp@plt>
  1137f5:	0f 18 3d 84 0b f5 ff                            	prefetchit0 -0xaf47c(%rip)        # 64380 <_ZN13media_service24UniqueIdServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x30>
  1137fc:	0f 18 3d 49 2d f5 ff                            	prefetchit0 -0xad2b7(%rip)        # 6654c <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x4c>
  113803:	0f 18 3d 36 46 f1 ff                            	prefetchit0 -0xeb9ca(%rip)        # 27e40 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc@plt>
  11380a:	0f 18 3d fe 9d f5 ff                            	prefetchit0 -0xa6202(%rip)        # 6d60f <_ZN13media_service26ComposeReviewServiceClient19recv_UploadUniqueIdEv+0x4f>
  113811:	41 53                                           	push   %r11
  113813:	4c 8b 1d 06 df ff ff                            	mov    -0x20fa(%rip),%r11        # 111720 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc@GLIBCXX_3.4.21>
  11381a:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  113822:	41 5b                                           	pop    %r11
  113824:	e9 57 c9 f4 ff                                  	jmp    60180 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE14readStringBodyINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEEjRT_i>
  113829:	0f 1f 80 00 00 00 00                            	nopl   0x0(%rax)
  113830:	0f 18 3d 09 35 f5 ff                            	prefetchit0 -0xacaf7(%rip)        # 66d40 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE22_M_emplace_hint_uniqueIJRKSt21piecewise_construct_tSt5tupleIJRS7_EESJ_IJEEEEESt17_Rb_tree_iteratorIS8_ESt23_Rb_tree_const_iteratorIS8_EDpOT_>
  113837:	41 53                                           	push   %r11
  113839:	4c 8b 1d 58 db ff ff                            	mov    -0x24a8(%rip),%r11        # 111398 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@GLIBCXX_3.4.21>
  113840:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
  113848:	41 5b                                           	pop    %r11
  11384a:	e9 e1 3e f1 ff                                  	jmp    27730 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@plt>
  11384f:	90                                              	nop
  113850:	0f 18 3d 95 8e f3 ff                            	prefetchit0 -0xc716b(%rip)        # 4c6ec <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E+0x7c>
  113857:	e9 14 8e f3 ff                                  	jmp    4c670 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  11385c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  113860:	0f 18 3d 19 11 f5 ff                            	prefetchit0 -0xaeee7(%rip)        # 64980 <_ZN13media_service24UniqueIdServiceProcessor22process_UploadUniqueIdEiPN6apache6thrift8protocol9TProtocolES5_Pv>
  113867:	0f 18 3d f2 bd f4 ff                            	prefetchit0 -0xb420e(%rip)        # 5f660 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE20readStructBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  11386e:	0f 18 3d fb f5 f4 ff                            	prefetchit0 -0xb0a05(%rip)        # 62e70 <_ZN13media_service35UniqueIdService_UploadUniqueId_args4readEPN6apache6thrift8protocol9TProtocolE>
  113875:	0f 18 3d 47 f6 f4 ff                            	prefetchit0 -0xb09b9(%rip)        # 62ec3 <_ZN13media_service35UniqueIdService_UploadUniqueId_args4readEPN6apache6thrift8protocol9TProtocolE+0x53>
  11387c:	e9 7f 48 f1 ff                                  	jmp    28100 <memcmp@plt>
  113881:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  11388b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  113890:	0f 18 3d c9 c1 f4 ff                            	prefetchit0 -0xb3e37(%rip)        # 5fa60 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE12readI64_virtERl>
  113897:	e9 d4 f5 f4 ff                                  	jmp    62e70 <_ZN13media_service35UniqueIdService_UploadUniqueId_args4readEPN6apache6thrift8protocol9TProtocolE>
  11389c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1138a0:	0f 18 3d e9 47 f1 ff                            	prefetchit0 -0xeb817(%rip)        # 28090 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_@plt>
  1138a7:	0f 18 3d 24 89 f3 ff                            	prefetchit0 -0xc76dc(%rip)        # 4c1d2 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_+0x262>
  1138ae:	0f 18 3d bb 86 f3 ff                            	prefetchit0 -0xc7945(%rip)        # 4bf70 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_>
  1138b5:	41 53                                           	push   %r11
  1138b7:	4c 8b 1d 8a df ff ff                            	mov    -0x2076(%rip),%r11        # 111848 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_@GLIBCXX_3.4>
  1138be:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1138c6:	41 5b                                           	pop    %r11
  1138c8:	e9 03 39 f1 ff                                  	jmp    271d0 <_Znwm@plt>
  1138cd:	0f 1f 00                                        	nopl   (%rax)
  1138d0:	0f 18 3d ab 72 f5 ff                            	prefetchit0 -0xa8d55(%rip)        # 6ab82 <_ZN13media_service43ComposeReviewService_UploadUniqueId_presult4readEPN6apache6thrift8protocol9TProtocolE+0x52>
  1138d7:	0f 18 3d 52 72 f5 ff                            	prefetchit0 -0xa8dae(%rip)        # 6ab30 <_ZN13media_service43ComposeReviewService_UploadUniqueId_presult4readEPN6apache6thrift8protocol9TProtocolE>
  1138de:	0f 18 3d 7b bd f4 ff                            	prefetchit0 -0xb4285(%rip)        # 5f660 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE20readStructBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  1138e5:	41 53                                           	push   %r11
  1138e7:	4c 8b 1d b2 d7 ff ff                            	mov    -0x284e(%rip),%r11        # 1110a0 <_ZdlPvm@CXXABI_1.3.9>
  1138ee:	41 0f 18 93 90 2f ff ff                         	prefetcht1 -0xd070(%r11)
  1138f6:	41 0f 18 93 e0 48 ff ff                         	prefetcht1 -0xb720(%r11)
  1138fe:	41 5b                                           	pop    %r11
  113900:	e9 3b 45 f1 ff                                  	jmp    27e40 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc@plt>
  113905:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  11390f:	90                                              	nop
  113910:	0f 18 3d 07 c3 f1 ff                            	prefetchit0 -0xe3cf9(%rip)        # 2fc1e <_ZN13media_service15UniqueIdHandler14UploadUniqueIdElRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES7_St4lessIS7_ESaISt4pairIKS7_S7_EEE+0xb1e>
  113917:	41 53                                           	push   %r11
  113919:	4c 8b 1d 48 d7 ff ff                            	mov    -0x28b8(%rip),%r11        # 111068 <_ZNSt9exceptionD2Ev@GLIBCXX_3.4>
  113920:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  113928:	41 5b                                           	pop    %r11
  11392a:	e9 51 7e f6 ff                                  	jmp    7b780 <_ZN13media_service16ServiceExceptionD1Ev>
  11392f:	90                                              	nop
  113930:	0f 18 3d ca 2c f7 ff                            	prefetchit0 -0x8d336(%rip)        # 86601 <_ZNK5boost3log12v2s_mt_posix19attribute_value_set4findENS1_14attribute_nameE+0x81>
  113937:	e9 f4 44 f1 ff                                  	jmp    27e30 <malloc@plt>
  11393c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  113940:	41 53                                           	push   %r11
  113942:	4c 8b 1d 7f dd ff ff                            	mov    -0x2281(%rip),%r11        # 1116c8 <pthread_rwlock_unlock@GLIBC_2.34>
  113949:	41 0f 18 93 31 00 00 00                         	prefetcht1 0x31(%r11)
  113951:	41 5b                                           	pop    %r11
  113953:	e9 38 63 f9 ff                                  	jmp    a9c90 <_ZNK5boost3log12v2s_mt_posix3aux20thread_specific_base11get_contentEv>
