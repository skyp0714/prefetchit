
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_native_it0/3a547e47cb945f83448ecdee31f23d2428e3c700ce96af34c177300d9909e209/MovieReviewService:     file format elf64-x86-64


Disassembly of section .text.prefetch_calls:

00000000001d7340 <.text.prefetch_calls>:
  1d7340:	0f 18 3d b9 13 e9 ff                            	prefetchit0 -0x16ec47(%rip)        # 68700 <_ZNK13media_service13TextMapReader10ForeachKeyESt8functionIFN11opentracing2v28expectedIvSt10error_codeEENS3_11string_viewES7_EE>
  1d7347:	0f 18 3d 62 bc e8 ff                            	prefetchit0 -0x17439e(%rip)        # 62fb0 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_>
  1d734e:	0f 18 3d af bc e8 ff                            	prefetchit0 -0x174351(%rip)        # 63004 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0x54>
  1d7355:	0f 18 3d 25 bd e8 ff                            	prefetchit0 -0x1742db(%rip)        # 63081 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0xd1>
  1d735c:	0f 18 3d 5f bd e8 ff                            	prefetchit0 -0x1742a1(%rip)        # 630c2 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0x112>
  1d7363:	41 53                                           	push   %r11
  1d7365:	4c 8b 1d 54 e2 ff ff                            	mov    -0x1dac(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d736c:	41 0f 18 93 b0 65 fe ff                         	prefetcht1 -0x19a50(%r11)
  1d7374:	41 5b                                           	pop    %r11
  1d7376:	e9 a5 60 e5 ff                                  	jmp    2d420 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  1d737b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1d7380:	0f 18 3d 19 7e e7 ff                            	prefetchit0 -0x1881e7(%rip)        # 4f1a0 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  1d7387:	e9 94 60 e5 ff                                  	jmp    2d420 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  1d738c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7390:	41 53                                           	push   %r11
  1d7392:	4c 8b 1d 77 dd ff ff                            	mov    -0x2289(%rip),%r11        # 1d5110 <_Znwm@GLIBCXX_3.4>
  1d7399:	41 0f 18 93 b0 06 00 00                         	prefetcht1 0x6b0(%r11)
  1d73a1:	4c 8b 1d 18 e2 ff ff                            	mov    -0x1de8(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d73a8:	41 0f 18 93 c5 1f 00 00                         	prefetcht1 0x1fc5(%r11)
  1d73b0:	41 5b                                           	pop    %r11
  1d73b2:	e9 e9 7d e7 ff                                  	jmp    4f1a0 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  1d73b7:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  1d73c0:	41 53                                           	push   %r11
  1d73c2:	4c 8b 1d f7 e1 ff ff                            	mov    -0x1e09(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d73c9:	41 0f 18 93 50 79 00 00                         	prefetcht1 0x7950(%r11)
  1d73d1:	41 5b                                           	pop    %r11
  1d73d3:	e9 48 60 e5 ff                                  	jmp    2d420 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  1d73d8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d73e0:	41 53                                           	push   %r11
  1d73e2:	4c 8b 1d 0f df ff ff                            	mov    -0x20f1(%rip),%r11        # 1d52f8 <bson_destroy@Base>
  1d73e9:	41 0f 18 93 00 d7 00 00                         	prefetcht1 0xd700(%r11)
  1d73f1:	41 5b                                           	pop    %r11
  1d73f3:	e9 48 69 e5 ff                                  	jmp    2dd40 <mongoc_client_get_collection@plt>
  1d73f8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d7400:	41 53                                           	push   %r11
  1d7402:	4c 8b 1d bf dd ff ff                            	mov    -0x2241(%rip),%r11        # 1d51c8 <bson_append_utf8@Base>
  1d7409:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7411:	41 0f 18 93 80 00 00 00                         	prefetcht1 0x80(%r11)
  1d7419:	4c 8b 1d a8 e4 ff ff                            	mov    -0x1b58(%rip),%r11        # 1d58c8 <bcon_new@Base>
  1d7420:	41 0f 18 93 b0 1c 00 00                         	prefetcht1 0x1cb0(%r11)
  1d7428:	41 0f 18 93 d1 1c 00 00                         	prefetcht1 0x1cd1(%r11)
  1d7430:	41 5b                                           	pop    %r11
  1d7432:	e9 d9 6d e5 ff                                  	jmp    2e210 <bson_new@plt>
  1d7437:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  1d7440:	0f 18 3d 49 6d e5 ff                            	prefetchit0 -0x1a92b7(%rip)        # 2e190 <bcon_new@plt>
  1d7447:	41 53                                           	push   %r11
  1d7449:	4c 8b 1d 78 e4 ff ff                            	mov    -0x1b88(%rip),%r11        # 1d58c8 <bcon_new@Base>
  1d7450:	41 0f 18 93 b0 fe ff ff                         	prefetcht1 -0x150(%r11)
  1d7458:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7460:	41 0f 18 93 13 00 00 00                         	prefetcht1 0x13(%r11)
  1d7468:	41 5b                                           	pop    %r11
  1d746a:	e9 21 5c e5 ff                                  	jmp    2d090 <bson_bcon_magic@plt>
  1d746f:	90                                              	nop
  1d7470:	0f 18 3d 29 7d e7 ff                            	prefetchit0 -0x1882d7(%rip)        # 4f1a0 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  1d7477:	0f 18 3d 02 1d e9 ff                            	prefetchit0 -0x16e2fe(%rip)        # 69180 <_ZNK11opentracing2v213SpanReference5ApplyERNS0_16StartSpanOptionsE>
  1d747e:	e9 9d 5f e5 ff                                  	jmp    2d420 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  1d7483:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d748d:	0f 1f 00                                        	nopl   (%rax)
  1d7490:	41 53                                           	push   %r11
  1d7492:	4c 8b 1d 77 dc ff ff                            	mov    -0x2389(%rip),%r11        # 1d5110 <_Znwm@GLIBCXX_3.4>
  1d7499:	41 0f 18 93 b0 06 00 00                         	prefetcht1 0x6b0(%r11)
  1d74a1:	4c 8b 1d 18 e1 ff ff                            	mov    -0x1ee8(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d74a8:	41 0f 18 93 60 1d 00 00                         	prefetcht1 0x1d60(%r11)
  1d74b0:	41 0f 18 93 c5 1f 00 00                         	prefetcht1 0x1fc5(%r11)
  1d74b8:	41 5b                                           	pop    %r11
  1d74ba:	e9 e1 7c e7 ff                                  	jmp    4f1a0 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  1d74bf:	90                                              	nop
  1d74c0:	41 53                                           	push   %r11
  1d74c2:	4c 8b 1d 4f dd ff ff                            	mov    -0x22b1(%rip),%r11        # 1d5218 <pthread_once@GLIBC_2.34>
  1d74c9:	41 0f 18 93 83 c5 00 00                         	prefetcht1 0xc583(%r11)
  1d74d1:	41 5b                                           	pop    %r11
  1d74d3:	e9 a8 67 e5 ff                                  	jmp    2dc80 <mongoc_collection_find_and_modify@plt>
  1d74d8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d74e0:	41 53                                           	push   %r11
  1d74e2:	4c 8b 1d d7 e0 ff ff                            	mov    -0x1f29(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d74e9:	41 0f 18 93 20 6f fe ff                         	prefetcht1 -0x190e0(%r11)
  1d74f1:	41 0f 18 93 10 ad ff ff                         	prefetcht1 -0x52f0(%r11)
  1d74f9:	41 0f 18 93 41 ad ff ff                         	prefetcht1 -0x52bf(%r11)
  1d7501:	4c 8b 1d 10 e4 ff ff                            	mov    -0x1bf0(%rip),%r11        # 1d5918 <_ZNSt6chrono3_V212steady_clock3nowEv@GLIBCXX_3.4.19>
  1d7508:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7510:	41 5b                                           	pop    %r11
  1d7512:	e9 19 6d e5 ff                                  	jmp    2e230 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
  1d7517:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  1d7520:	41 53                                           	push   %r11
  1d7522:	4c 8b 1d 97 e0 ff ff                            	mov    -0x1f69(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d7529:	41 0f 18 93 30 f5 ff ff                         	prefetcht1 -0xad0(%r11)
  1d7531:	41 0f 18 93 41 f5 ff ff                         	prefetcht1 -0xabf(%r11)
  1d7539:	41 5b                                           	pop    %r11
  1d753b:	e9 b0 60 e5 ff                                  	jmp    2d5f0 <bson_destroy@plt>
  1d7540:	41 53                                           	push   %r11
  1d7542:	4c 8b 1d 2f db ff ff                            	mov    -0x24d1(%rip),%r11        # 1d5078 <mongoc_cursor_destroy@Base>
  1d7549:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7551:	4c 8b 1d c8 e0 ff ff                            	mov    -0x1f38(%rip),%r11        # 1d5620 <mongoc_cursor_next@Base>
  1d7558:	41 0f 18 93 00 2e 00 00                         	prefetcht1 0x2e00(%r11)
  1d7560:	41 0f 18 93 10 2e 00 00                         	prefetcht1 0x2e10(%r11)
  1d7568:	41 5b                                           	pop    %r11
  1d756a:	e9 81 60 e5 ff                                  	jmp    2d5f0 <bson_destroy@plt>
  1d756f:	90                                              	nop
  1d7570:	41 53                                           	push   %r11
  1d7572:	4c 8b 1d 9f dc ff ff                            	mov    -0x2361(%rip),%r11        # 1d5218 <pthread_once@GLIBC_2.34>
  1d7579:	41 0f 18 93 83 c5 00 00                         	prefetcht1 0xc583(%r11)
  1d7581:	41 5b                                           	pop    %r11
  1d7583:	e9 a8 5a e5 ff                                  	jmp    2d030 <mongoc_client_pool_push@plt>
  1d7588:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d7590:	0f 18 3d e9 1b e9 ff                            	prefetchit0 -0x16e417(%rip)        # 69180 <_ZNK11opentracing2v213SpanReference5ApplyERNS0_16StartSpanOptionsE>
  1d7597:	0f 18 3d 02 7c e7 ff                            	prefetchit0 -0x1883fe(%rip)        # 4f1a0 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  1d759e:	e9 7d 5e e5 ff                                  	jmp    2d420 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  1d75a3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d75ad:	0f 1f 00                                        	nopl   (%rax)
  1d75b0:	41 53                                           	push   %r11
  1d75b2:	4c 8b 1d 57 db ff ff                            	mov    -0x24a9(%rip),%r11        # 1d5110 <_Znwm@GLIBCXX_3.4>
  1d75b9:	41 0f 18 93 b0 06 00 00                         	prefetcht1 0x6b0(%r11)
  1d75c1:	41 5b                                           	pop    %r11
  1d75c3:	e9 d8 7b e7 ff                                  	jmp    4f1a0 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  1d75c8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d75d0:	0f 18 3d c9 79 f3 ff                            	prefetchit0 -0xc8637(%rip)        # 10efa0 <_ZN9cpp_redis6client8exec_cmdERKSt8functionIFRS0_RKS1_IFvRNS_5replyEEEEE>
  1d75d7:	0f 18 3d e8 79 f3 ff                            	prefetchit0 -0xc8618(%rip)        # 10efc6 <_ZN9cpp_redis6client8exec_cmdERKSt8functionIFRS0_RKS1_IFvRNS_5replyEEEEE+0x26>
  1d75de:	0f 18 3d 0b 96 f0 ff                            	prefetchit0 -0xf69f5(%rip)        # e0bf0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.constprop.0>
  1d75e5:	e9 76 9e f4 ff                                  	jmp    121460 <_ZN9cpp_redis6client5zcardERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  1d75ea:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1d75f0:	0f 18 3d b9 f9 f5 ff                            	prefetchit0 -0xa0647(%rip)        # 136fb0 <_ZN9cpp_redis6client10try_commitEv>
  1d75f7:	0f 18 3d 04 ef f6 ff                            	prefetchit0 -0x910fc(%rip)        # 146502 <_ZN9cpp_redis7network10tcp_client11async_writeERNS0_16tcp_client_iface13write_requestE+0x12>
  1d75fe:	0f 18 3d bd f9 f5 ff                            	prefetchit0 -0xa0643(%rip)        # 136fc2 <_ZN9cpp_redis6client10try_commitEv+0x12>
  1d7605:	0f 18 3d e4 ee f6 ff                            	prefetchit0 -0x9111c(%rip)        # 1464f0 <_ZN9cpp_redis7network10tcp_client11async_writeERNS0_16tcp_client_iface13write_requestE>
  1d760c:	e9 ff f9 f5 ff                                  	jmp    137010 <_ZN9cpp_redis6client11sync_commitEv>
  1d7611:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d761b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1d7620:	0f 18 3d 89 22 e9 ff                            	prefetchit0 -0x16dd77(%rip)        # 698b0 <_ZNSt20__uninitialized_copyILb0EE13__uninit_copyIN9__gnu_cxx17__normal_iteratorIPKN9cpp_redis5replyESt6vectorIS5_SaIS5_EEEEPS5_EET0_T_SE_SD_>
  1d7627:	0f 18 3d c2 24 e9 ff                            	prefetchit0 -0x16db3e(%rip)        # 69af0 <_ZN9cpp_redis5replyC2ERKS0_>
  1d762e:	0f 18 3d 1b 79 e9 ff                            	prefetchit0 -0x1686e5(%rip)        # 6ef50 <_ZNSt13__future_base13_State_baseV217_M_complete_asyncEv>
  1d7635:	0f 18 3d c5 24 e9 ff                            	prefetchit0 -0x16db3b(%rip)        # 69b01 <_ZN9cpp_redis5replyC2ERKS0_+0x11>
  1d763c:	0f 18 3d 8d 1f f6 ff                            	prefetchit0 -0x9e073(%rip)        # 1395d0 <_ZNSt23_Sp_counted_ptr_inplaceINSt13__future_base13_State_baseV2ESaIS1_ELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv>
  1d7643:	0f 18 3d a6 2b f6 ff                            	prefetchit0 -0x9d45a(%rip)        # 13a1f0 <_ZNSt13__future_base7_ResultIN9cpp_redis5replyEE10_M_destroyEv>
  1d764a:	41 53                                           	push   %r11
  1d764c:	4c 8b 1d 0d db ff ff                            	mov    -0x24f3(%rip),%r11        # 1d5160 <_ZNSt13__future_base12_Result_baseD2Ev@GLIBCXX_3.4.15>
  1d7653:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d765b:	41 5b                                           	pop    %r11
  1d765d:	e9 8e 6b e9 ff                                  	jmp    6e1f0 <_ZNKSt14__basic_futureIN9cpp_redis5replyEE13_M_get_resultEv>
  1d7662:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d766c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7670:	0f 18 3d d9 1c f6 ff                            	prefetchit0 -0x9e327(%rip)        # 139350 <_ZNSt23_Sp_counted_ptr_inplaceINSt13__future_base13_State_baseV2ESaIS1_ELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv>
  1d7677:	e9 74 24 e9 ff                                  	jmp    69af0 <_ZN9cpp_redis5replyC2ERKS0_>
  1d767c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7680:	0f 18 3d 7f ed e6 ff                            	prefetchit0 -0x191281(%rip)        # 46406 <_ZN13media_service18MovieReviewHandler17UploadMovieReviewElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEllRKSt3mapIS6_S6_St4lessIS6_ESaISt4pairIS7_S6_EEE+0x1176>
  1d7687:	0f 18 3d 42 8b e7 ff                            	prefetchit0 -0x1874be(%rip)        # 501d0 <_ZN13media_service10ClientPoolINS_11RedisClientEE4PushEPS1_>
  1d768e:	0f 18 3d 5b 45 f6 ff                            	prefetchit0 -0x9baa5(%rip)        # 13bbf0 <_ZNK9cpp_redis5reply2okEv>
  1d7695:	e9 86 5b e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d769a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1d76a0:	0f 18 3d 89 6b e5 ff                            	prefetchit0 -0x1a9477(%rip)        # 2e230 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
  1d76a7:	e9 44 45 f6 ff                                  	jmp    13bbf0 <_ZNK9cpp_redis5reply2okEv>
  1d76ac:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d76b0:	41 53                                           	push   %r11
  1d76b2:	4c 8b 1d 07 df ff ff                            	mov    -0x20f9(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d76b9:	41 0f 18 93 5a b4 ff ff                         	prefetcht1 -0x4ba6(%r11)
  1d76c1:	41 5b                                           	pop    %r11
  1d76c3:	e9 68 6b e5 ff                                  	jmp    2e230 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
  1d76c8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d76d0:	0f 18 3d 89 9d f4 ff                            	prefetchit0 -0xb6277(%rip)        # 121460 <_ZN9cpp_redis6client5zcardERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  1d76d7:	0f 18 3d a2 9d f4 ff                            	prefetchit0 -0xb625e(%rip)        # 121480 <_ZN9cpp_redis6client5zcardERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE+0x20>
  1d76de:	41 53                                           	push   %r11
  1d76e0:	4c 8b 1d 31 de ff ff                            	mov    -0x21cf(%rip),%r11        # 1d5518 <mongoc_collection_find_with_opts@Base>
  1d76e7:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d76ef:	41 0f 18 93 32 00 00 00                         	prefetcht1 0x32(%r11)
  1d76f7:	4c 8b 1d 42 df ff ff                            	mov    -0x20be(%rip),%r11        # 1d5640 <mongoc_collection_find_and_modify@Base>
  1d76fe:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7706:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
  1d770e:	41 5b                                           	pop    %r11
  1d7710:	e9 6b 5a e5 ff                                  	jmp    2d180 <_ZdlPvm@plt>
  1d7715:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d771f:	90                                              	nop
  1d7720:	0f 18 3d d9 cc f6 ff                            	prefetchit0 -0x93327(%rip)        # 144400 <_ZNK9cpp_redis7network16redis_connection12is_connectedEv>
  1d7727:	0f 18 3d 62 e9 f6 ff                            	prefetchit0 -0x9169e(%rip)        # 146090 <_ZNK9cpp_redis7network10tcp_client12is_connectedEv>
  1d772e:	0f 18 3d 3b da e6 ff                            	prefetchit0 -0x1925c5(%rip)        # 45170 <_ZN13media_service11RedisClient7ConnectEv>
  1d7735:	0f 18 3d c4 5b f1 ff                            	prefetchit0 -0xea43c(%rip)        # ed300 <_ZNK9cpp_redis6client12is_connectedEv>
  1d773c:	0f 18 3d fd 50 f7 ff                            	prefetchit0 -0x8af03(%rip)        # 14c840 <_ZNK7tacopie10tcp_client12is_connectedEv>
  1d7743:	0f 18 3d fd 87 e7 ff                            	prefetchit0 -0x187803(%rip)        # 4ff47 <_ZN13media_service10ClientPoolINS_11RedisClientEE3PopEv+0xb07>
  1d774a:	41 53                                           	push   %r11
  1d774c:	4c 8b 1d bd da ff ff                            	mov    -0x2543(%rip),%r11        # 1d5210 <_ZN11opentracing2v26Tracer6GlobalEv@Base>
  1d7753:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d775b:	41 5b                                           	pop    %r11
  1d775d:	e9 ae 5c e5 ff                                  	jmp    2d410 <pthread_mutex_lock@plt>
  1d7762:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d776c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7770:	41 53                                           	push   %r11
  1d7772:	4c 8b 1d 47 de ff ff                            	mov    -0x21b9(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d7779:	41 0f 18 93 60 62 fe ff                         	prefetcht1 -0x19da0(%r11)
  1d7781:	41 0f 18 93 00 6a 00 00                         	prefetcht1 0x6a00(%r11)
  1d7789:	41 5b                                           	pop    %r11
  1d778b:	e9 c0 86 e8 ff                                  	jmp    5fe50 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  1d7790:	41 53                                           	push   %r11
  1d7792:	4c 8b 1d 87 e1 ff ff                            	mov    -0x1e79(%rip),%r11        # 1d5920 <_ZNSt7__cxx1119basic_ostringstreamIcSt11char_traitsIcESaIcEEC1Ev@GLIBCXX_3.4.26>
  1d7799:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d77a1:	41 0f 18 93 34 00 00 00                         	prefetcht1 0x34(%r11)
  1d77a9:	41 5b                                           	pop    %r11
  1d77ab:	e9 90 6a e5 ff                                  	jmp    2e240 <_ZNSt7__cxx1119basic_ostringstreamIcSt11char_traitsIcESaIcEEC1Ev@plt>
  1d77b0:	41 53                                           	push   %r11
  1d77b2:	4c 8b 1d 9f dc ff ff                            	mov    -0x2361(%rip),%r11        # 1d5458 <_ZNSo9_M_insertImEERSoT_@GLIBCXX_3.4.9>
  1d77b9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d77c1:	4c 8b 1d b8 e1 ff ff                            	mov    -0x1e48(%rip),%r11        # 1d5980 <_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l@GLIBCXX_3.4.9>
  1d77c8:	41 0f 18 93 20 26 ff ff                         	prefetcht1 -0xd9e0(%r11)
  1d77d0:	41 0f 18 93 31 26 ff ff                         	prefetcht1 -0xd9cf(%r11)
  1d77d8:	41 0f 18 93 10 29 ff ff                         	prefetcht1 -0xd6f0(%r11)
  1d77e0:	41 0f 18 93 a0 f5 ff ff                         	prefetcht1 -0xa60(%r11)
  1d77e8:	41 0f 18 93 b0 f5 ff ff                         	prefetcht1 -0xa50(%r11)
  1d77f0:	41 5b                                           	pop    %r11
  1d77f2:	e9 d9 d9 e8 ff                                  	jmp    651d0 <_ZNK13jaegertracing11SpanContext5printISoEEvRT_>
  1d77f7:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  1d7800:	41 53                                           	push   %r11
  1d7802:	4c 8b 1d 07 de ff ff                            	mov    -0x21f9(%rip),%r11        # 1d5610 <mongoc_client_pool_pop@Base>
  1d7809:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7811:	41 5b                                           	pop    %r11
  1d7813:	e9 18 6b e5 ff                                  	jmp    2e330 <_ZNSt6localeD1Ev@plt>
  1d7818:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d7820:	41 53                                           	push   %r11
  1d7822:	4c 8b 1d 6f e1 ff ff                            	mov    -0x1e91(%rip),%r11        # 1d5998 <_ZNSt6localeD1Ev@GLIBCXX_3.4>
  1d7829:	41 0f 18 93 f3 f0 ff ff                         	prefetcht1 -0xf0d(%r11)
  1d7831:	41 5b                                           	pop    %r11
  1d7833:	e9 f8 58 e5 ff                                  	jmp    2d130 <memcpy@plt>
  1d7838:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d7840:	0f 18 3d c9 bd e8 ff                            	prefetchit0 -0x174237(%rip)        # 63610 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE11decodeValueERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  1d7847:	0f 18 3d 92 5f e5 ff                            	prefetchit0 -0x1aa06e(%rip)        # 2d7e0 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode@plt>
  1d784e:	41 53                                           	push   %r11
  1d7850:	4c 8b 1d 99 db ff ff                            	mov    -0x2467(%rip),%r11        # 1d53f0 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode@GLIBCXX_3.4.21>
  1d7857:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d785f:	41 0f 18 93 11 00 00 00                         	prefetcht1 0x11(%r11)
  1d7867:	41 5b                                           	pop    %r11
  1d7869:	e9 c2 58 e5 ff                                  	jmp    2d130 <memcpy@plt>
  1d786e:	66 90                                           	xchg   %ax,%ax
  1d7870:	0f 18 3d 39 d7 e8 ff                            	prefetchit0 -0x1728c7(%rip)        # 64fb0 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_>
  1d7877:	e9 04 59 e5 ff                                  	jmp    2d180 <_ZdlPvm@plt>
  1d787c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7880:	0f 18 3d 09 be e8 ff                            	prefetchit0 -0x1741f7(%rip)        # 63690 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE12normalizeKeyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  1d7887:	e9 d4 63 e5 ff                                  	jmp    2dc60 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@plt>
  1d788c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7890:	0f 18 3d b9 68 e5 ff                            	prefetchit0 -0x1a9747(%rip)        # 2e150 <_ZSt18_Rb_tree_incrementPKSt18_Rb_tree_node_base@plt>
  1d7897:	41 53                                           	push   %r11
  1d7899:	4c 8b 1d 08 e0 ff ff                            	mov    -0x1ff8(%rip),%r11        # 1d58a8 <_ZSt18_Rb_tree_incrementPKSt18_Rb_tree_node_base@GLIBCXX_3.4>
  1d78a0:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d78a8:	41 5b                                           	pop    %r11
  1d78aa:	e9 d1 58 e5 ff                                  	jmp    2d180 <_ZdlPvm@plt>
  1d78af:	90                                              	nop
  1d78b0:	41 53                                           	push   %r11
  1d78b2:	4c 8b 1d 07 dd ff ff                            	mov    -0x22f9(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d78b9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d78c1:	41 0f 18 93 44 00 00 00                         	prefetcht1 0x44(%r11)
  1d78c9:	41 0f 18 93 88 00 00 00                         	prefetcht1 0x88(%r11)
  1d78d1:	41 0f 18 93 c0 16 00 00                         	prefetcht1 0x16c0(%r11)
  1d78d9:	41 0f 18 93 00 17 00 00                         	prefetcht1 0x1700(%r11)
  1d78e1:	4c 8b 1d 98 e0 ff ff                            	mov    -0x1f68(%rip),%r11        # 1d5980 <_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l@GLIBCXX_3.4.9>
  1d78e8:	41 0f 18 93 b0 3e fe ff                         	prefetcht1 -0x1c150(%r11)
  1d78f0:	41 5b                                           	pop    %r11
  1d78f2:	e9 89 62 e5 ff                                  	jmp    2db80 <_ZN13jaegertracing11SpanContext10fromStreamERSi@plt>
  1d78f7:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  1d7900:	0f 18 3d 19 cc e8 ff                            	prefetchit0 -0x1733e7(%rip)        # 64520 <_ZN13jaegertracingeqERKNS_11SpanContextES2_>
  1d7907:	0f 18 3d 42 85 e8 ff                            	prefetchit0 -0x177abe(%rip)        # 5fe50 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  1d790e:	41 53                                           	push   %r11
  1d7910:	4c 8b 1d f9 e1 ff ff                            	mov    -0x1e07(%rip),%r11        # 1d5b10 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_@GLIBCXX_3.4.21>
  1d7917:	41 0f 18 93 63 02 00 00                         	prefetcht1 0x263(%r11)
  1d791f:	41 5b                                           	pop    %r11
  1d7921:	e9 2a d1 e8 ff                                  	jmp    64a50 <_ZN13jaegertracing11SpanContext4swapERS0_>
  1d7926:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7930:	0f 18 3d f9 69 e5 ff                            	prefetchit0 -0x1a9607(%rip)        # 2e330 <_ZNSt6localeD1Ev@plt>
  1d7937:	41 53                                           	push   %r11
  1d7939:	4c 8b 1d 88 db ff ff                            	mov    -0x2478(%rip),%r11        # 1d54c8 <_ZdlPv@GLIBCXX_3.4>
  1d7940:	41 0f 18 93 a0 37 ff ff                         	prefetcht1 -0xc860(%r11)
  1d7948:	4c 8b 1d 29 dd ff ff                            	mov    -0x22d7(%rip),%r11        # 1d5678 <_ZNSt8ios_baseD2Ev@GLIBCXX_3.4>
  1d794f:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7957:	41 5b                                           	pop    %r11
  1d7959:	e9 f2 84 e8 ff                                  	jmp    5fe50 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  1d795e:	66 90                                           	xchg   %ax,%ax
  1d7960:	41 53                                           	push   %r11
  1d7962:	4c 8b 1d a7 d7 ff ff                            	mov    -0x2859(%rip),%r11        # 1d5110 <_Znwm@GLIBCXX_3.4>
  1d7969:	41 0f 18 93 d2 06 00 00                         	prefetcht1 0x6d2(%r11)
  1d7971:	4c 8b 1d 48 dc ff ff                            	mov    -0x23b8(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d7978:	41 0f 18 93 10 5d fe ff                         	prefetcht1 -0x1a2f0(%r11)
  1d7980:	41 0f 18 93 81 1d 00 00                         	prefetcht1 0x1d81(%r11)
  1d7988:	41 0f 18 93 90 31 00 00                         	prefetcht1 0x3190(%r11)
  1d7990:	41 0f 18 93 c0 31 00 00                         	prefetcht1 0x31c0(%r11)
  1d7998:	41 5b                                           	pop    %r11
  1d799a:	e9 41 18 e9 ff                                  	jmp    691e0 <_ZNSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS2_11SpanContextEESaIS7_EE17_M_realloc_insertIJRKS3_RKS6_EEEvN9__gnu_cxx17__normal_iteratorIPS7_S9_EEDpOT_>
  1d799f:	90                                              	nop
  1d79a0:	0f 18 3d 19 95 e9 ff                            	prefetchit0 -0x166ae7(%rip)        # 70ec0 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE22writeMessageBegin_virtERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  1d79a7:	0f 18 3d f2 9f e9 ff                            	prefetchit0 -0x16600e(%rip)        # 719a0 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE17writeMessageBeginERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  1d79ae:	0f 18 3d 22 1b eb ff                            	prefetchit0 -0x14e4de(%rip)        # 894d7 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x77>
  1d79b5:	0f 18 3d 04 a0 e9 ff                            	prefetchit0 -0x165ffc(%rip)        # 719c0 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE17writeMessageBeginERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi+0x20>
  1d79bc:	e9 bf 57 e5 ff                                  	jmp    2d180 <_ZdlPvm@plt>
  1d79c1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d79cb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1d79d0:	0f 18 3d f8 ec ea ff                            	prefetchit0 -0x151308(%rip)        # 866cf <_ZN13media_service27MovieReviewServiceProcessor25process_UploadMovieReviewEiPN6apache6thrift8protocol9TProtocolES5_Pv+0x2cf>
  1d79d7:	e9 94 1a e9 ff                                  	jmp    69470 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  1d79dc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d79e0:	0f 18 3d fe e8 ea ff                            	prefetchit0 -0x151702(%rip)        # 862e5 <_ZN13media_service27MovieReviewServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x515>
  1d79e7:	0f 18 3d 28 e5 ea ff                            	prefetchit0 -0x151ad8(%rip)        # 85f16 <_ZN13media_service27MovieReviewServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x146>
  1d79ee:	e9 8d 57 e5 ff                                  	jmp    2d180 <_ZdlPvm@plt>
  1d79f3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d79fd:	0f 1f 00                                        	nopl   (%rax)
  1d7a00:	0f 18 3d 49 9d e9 ff                            	prefetchit0 -0x1662b7(%rip)        # 71750 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE12readI64_virtERl>
  1d7a07:	e9 94 5e e5 ff                                  	jmp    2d8a0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@plt>
  1d7a0c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7a10:	0f 18 3d 89 5e e5 ff                            	prefetchit0 -0x1aa177(%rip)        # 2d8a0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@plt>
  1d7a17:	41 53                                           	push   %r11
  1d7a19:	4c 8b 1d a8 da ff ff                            	mov    -0x2558(%rip),%r11        # 1d54c8 <_ZdlPv@GLIBCXX_3.4>
  1d7a20:	41 0f 18 93 c0 53 ff ff                         	prefetcht1 -0xac40(%r11)
  1d7a28:	41 5b                                           	pop    %r11
  1d7a2a:	e9 41 a4 e9 ff                                  	jmp    71e70 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE14readStringBodyINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEEjRT_i>
  1d7a2f:	90                                              	nop
  1d7a30:	0f 18 3d 69 22 eb ff                            	prefetchit0 -0x14dd97(%rip)        # 89ca0 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE22_M_emplace_hint_uniqueIJRKSt21piecewise_construct_tSt5tupleIJRS7_EESJ_IJEEEEESt17_Rb_tree_iteratorIS8_ESt23_Rb_tree_const_iteratorIS8_EDpOT_>
  1d7a37:	e9 64 5e e5 ff                                  	jmp    2d8a0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@plt>
  1d7a3c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7a40:	0f 18 3d 09 13 e9 ff                            	prefetchit0 -0x16ecf7(%rip)        # 68d50 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_>
  1d7a47:	0f 18 3d 12 6a e5 ff                            	prefetchit0 -0x1a95ee(%rip)        # 2e460 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_@plt>
  1d7a4e:	41 53                                           	push   %r11
  1d7a50:	4c 8b 1d d9 df ff ff                            	mov    -0x2027(%rip),%r11        # 1d5a30 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_@GLIBCXX_3.4>
  1d7a57:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7a5f:	41 0f 18 93 a8 02 00 00                         	prefetcht1 0x2a8(%r11)
  1d7a67:	41 5b                                           	pop    %r11
  1d7a69:	e9 32 22 eb ff                                  	jmp    89ca0 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE22_M_emplace_hint_uniqueIJRKSt21piecewise_construct_tSt5tupleIJRS7_EESJ_IJEEEEESt17_Rb_tree_iteratorIS8_ESt23_Rb_tree_const_iteratorIS8_EDpOT_>
  1d7a6e:	66 90                                           	xchg   %ax,%ax
  1d7a70:	0f 18 3d 89 e9 ea ff                            	prefetchit0 -0x151677(%rip)        # 86400 <_ZN13media_service27MovieReviewServiceProcessor25process_UploadMovieReviewEiPN6apache6thrift8protocol9TProtocolES5_Pv>
  1d7a77:	e9 64 6a e5 ff                                  	jmp    2e4e0 <memcmp@plt>
  1d7a7c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7a80:	0f 18 3d c9 98 e9 ff                            	prefetchit0 -0x166737(%rip)        # 71350 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE20readStructBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  1d7a87:	0f 18 3d 72 ae ea ff                            	prefetchit0 -0x15518e(%rip)        # 82900 <_ZN13media_service41MovieReviewService_UploadMovieReview_args4readEPN6apache6thrift8protocol9TProtocolE>
  1d7a8e:	e9 4d 6a e5 ff                                  	jmp    2e4e0 <memcmp@plt>
  1d7a93:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7a9d:	0f 1f 00                                        	nopl   (%rax)
  1d7aa0:	0f 18 3d 89 98 e9 ff                            	prefetchit0 -0x166777(%rip)        # 71330 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE21readMessageBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERNS1_12TMessageTypeERi>
  1d7aa7:	0f 18 3d b2 19 eb ff                            	prefetchit0 -0x14e64e(%rip)        # 89460 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv>
  1d7aae:	0f 18 3d ce 19 eb ff                            	prefetchit0 -0x14e632(%rip)        # 89483 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x23>
  1d7ab5:	e9 c6 56 e5 ff                                  	jmp    2d180 <_ZdlPvm@plt>
  1d7aba:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1d7ac0:	0f 18 3d d9 5c f1 ff                            	prefetchit0 -0xea327(%rip)        # ed7a0 <_ZNK9cpp_redis6client15is_reconnectingEv>
  1d7ac7:	0f 18 3d 42 f5 f5 ff                            	prefetchit0 -0xa0abe(%rip)        # 137010 <_ZN9cpp_redis6client11sync_commitEv>
  1d7ace:	e9 bd 5e e5 ff                                  	jmp    2d990 <_ZdlPv@plt>
  1d7ad3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7add:	0f 1f 00                                        	nopl   (%rax)
  1d7ae0:	0f 18 3d b9 d1 f6 ff                            	prefetchit0 -0x92e47(%rip)        # 144ca0 <_ZN9cpp_redis7network16redis_connection4sendERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS8_EE>
  1d7ae7:	0f 18 3d d8 d1 f6 ff                            	prefetchit0 -0x92e28(%rip)        # 144cc6 <_ZN9cpp_redis7network16redis_connection4sendERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS8_EE+0x26>
  1d7aee:	0f 18 3d fb 67 f1 ff                            	prefetchit0 -0xe9805(%rip)        # ee2f0 <_ZN9cpp_redis6client4sendERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS7_EERKSt8functionIFvRNS_5replyEEE>
  1d7af5:	e9 26 57 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7afa:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1d7b00:	0f 18 3d 88 d0 f6 ff                            	prefetchit0 -0x92f78(%rip)        # 144b8f <_ZN9cpp_redis7network16redis_connection13build_commandERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS8_EE+0x77f>
  1d7b07:	0f 18 3d 62 5f e5 ff                            	prefetchit0 -0x1aa09e(%rip)        # 2da70 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructEmc@plt>
  1d7b0e:	41 53                                           	push   %r11
  1d7b10:	4c 8b 1d 21 da ff ff                            	mov    -0x25df(%rip),%r11        # 1d5538 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructEmc@GLIBCXX_3.4.21>
  1d7b17:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7b1f:	41 0f 18 93 14 00 00 00                         	prefetcht1 0x14(%r11)
  1d7b27:	41 5b                                           	pop    %r11
  1d7b29:	e9 02 56 e5 ff                                  	jmp    2d130 <memcpy@plt>
  1d7b2e:	66 90                                           	xchg   %ax,%ax
  1d7b30:	0f 18 3d c9 02 f5 ff                            	prefetchit0 -0xafd37(%rip)        # 127e00 <_ZNSt17_Function_handlerIFvRN9cpp_redis5replyEEZNS0_6client8exec_cmdERKSt8functionIFRS4_RKS5_IS3_EEEEUlS2_E_E10_M_managerERSt9_Any_dataRKSG_St18_Manager_operation>
  1d7b37:	e9 d4 58 e5 ff                                  	jmp    2d410 <pthread_mutex_lock@plt>
  1d7b3c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7b40:	0f 18 3d b9 16 f6 ff                            	prefetchit0 -0x9e947(%rip)        # 139200 <_ZZNSt9once_flag18_Prepare_executionC4IZSt9call_onceIMNSt13__future_base13_State_baseV2EFvPSt8functionIFSt10unique_ptrINS3_12_Result_baseENS7_8_DeleterEEvEEPbEJPS4_SC_SD_EEvRS_OT_DpOT0_EUlvE_EERSI_ENUlvE_4_FUNEv>
  1d7b47:	0f 18 3d 12 83 f0 ff                            	prefetchit0 -0xf7cee(%rip)        # dfe60 <_ZNSt17_Function_handlerIFvRN9cpp_redis5replyEEZNS0_6client8exec_cmdERKSt8functionIFRS4_RKS5_IS3_EEEEUlS2_E_E9_M_invokeERKSt9_Any_dataS2_>
  1d7b4e:	0f 18 3d 2e 83 f0 ff                            	prefetchit0 -0xf7cd2(%rip)        # dfe83 <_ZNSt17_Function_handlerIFvRN9cpp_redis5replyEEZNS0_6client8exec_cmdERKSt8functionIFRS4_RKS5_IS3_EEEEUlS2_E_E9_M_invokeERKSt9_Any_dataS2_+0x23>
  1d7b55:	41 53                                           	push   %r11
  1d7b57:	4c 8b 1d 6a d9 ff ff                            	mov    -0x2696(%rip),%r11        # 1d54c8 <_ZdlPv@GLIBCXX_3.4>
  1d7b5e:	41 0f 18 93 10 34 ff ff                         	prefetcht1 -0xcbf0(%r11)
  1d7b66:	41 5b                                           	pop    %r11
  1d7b68:	e9 23 5e e5 ff                                  	jmp    2d990 <_ZdlPv@plt>
  1d7b6d:	0f 1f 00                                        	nopl   (%rax)
  1d7b70:	0f 18 3d 09 77 e9 ff                            	prefetchit0 -0x1688f7(%rip)        # 6f280 <_ZNSt13__future_base13_State_baseV29_M_do_setEPSt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEPb>
  1d7b77:	41 53                                           	push   %r11
  1d7b79:	4c 8b 1d f8 da ff ff                            	mov    -0x2508(%rip),%r11        # 1d5678 <_ZNSt8ios_baseD2Ev@GLIBCXX_3.4>
  1d7b80:	41 0f 18 93 70 03 00 00                         	prefetcht1 0x370(%r11)
  1d7b88:	41 5b                                           	pop    %r11
  1d7b8a:	e9 11 58 e5 ff                                  	jmp    2d3a0 <pthread_mutex_unlock@plt>
  1d7b8f:	90                                              	nop
  1d7b90:	0f 18 3d 19 27 f6 ff                            	prefetchit0 -0x9d8e7(%rip)        # 13a2b0 <_ZNSt23_Sp_counted_ptr_inplaceISt7promiseIN9cpp_redis5replyEESaIS3_ELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv>
  1d7b97:	0f 18 3d 68 27 f6 ff                            	prefetchit0 -0x9d898(%rip)        # 13a306 <_ZNSt23_Sp_counted_ptr_inplaceISt7promiseIN9cpp_redis5replyEESaIS3_ELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv+0x56>
  1d7b9e:	0f 18 3d 60 29 f6 ff                            	prefetchit0 -0x9d6a0(%rip)        # 13a505 <_ZNSt23_Sp_counted_ptr_inplaceISt7promiseIN9cpp_redis5replyEESaIS3_ELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv+0x255>
  1d7ba5:	0f 18 3d 15 27 f6 ff                            	prefetchit0 -0x9d8eb(%rip)        # 13a2c1 <_ZNSt23_Sp_counted_ptr_inplaceISt7promiseIN9cpp_redis5replyEESaIS3_ELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv+0x11>
  1d7bac:	0f 18 3d 3d 29 f6 ff                            	prefetchit0 -0x9d6c3(%rip)        # 13a4f0 <_ZNSt23_Sp_counted_ptr_inplaceISt7promiseIN9cpp_redis5replyEESaIS3_ELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv+0x240>
  1d7bb3:	41 53                                           	push   %r11
  1d7bb5:	4c 8b 1d 4c d6 ff ff                            	mov    -0x29b4(%rip),%r11        # 1d5208 <pthread_mutex_lock@GLIBC_2.2.5>
  1d7bbc:	41 0f 18 93 12 af ff ff                         	prefetcht1 -0x50ee(%r11)
  1d7bc4:	4c 8b 1d fd d8 ff ff                            	mov    -0x2703(%rip),%r11        # 1d54c8 <_ZdlPv@GLIBCXX_3.4>
  1d7bcb:	41 0f 18 93 70 53 ff ff                         	prefetcht1 -0xac90(%r11)
  1d7bd3:	41 5b                                           	pop    %r11
  1d7bd5:	e9 36 58 e5 ff                                  	jmp    2d410 <pthread_mutex_lock@plt>
  1d7bda:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1d7be0:	0f 18 3d 31 cf f6 ff                            	prefetchit0 -0x930cf(%rip)        # 144b18 <_ZN9cpp_redis7network16redis_connection13build_commandERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS8_EE+0x708>
  1d7be7:	41 53                                           	push   %r11
  1d7be9:	4c 8b 1d c8 da ff ff                            	mov    -0x2538(%rip),%r11        # 1d56b8 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm@GLIBCXX_3.4.21>
  1d7bf0:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7bf8:	41 0f 18 93 22 00 00 00                         	prefetcht1 0x22(%r11)
  1d7c00:	41 5b                                           	pop    %r11
  1d7c02:	e9 99 d0 f6 ff                                  	jmp    144ca0 <_ZN9cpp_redis7network16redis_connection4sendERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS8_EE>
  1d7c07:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  1d7c10:	0f 18 3d 69 6a e5 ff                            	prefetchit0 -0x1a9597(%rip)        # 2e680 <_ZNSt13__future_base12_Result_baseC2Ev@plt>
  1d7c17:	41 53                                           	push   %r11
  1d7c19:	4c 8b 1d 20 df ff ff                            	mov    -0x20e0(%rip),%r11        # 1d5b40 <_ZNSt13__future_base12_Result_baseC2Ev@GLIBCXX_3.4.15>
  1d7c20:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7c28:	41 5b                                           	pop    %r11
  1d7c2a:	e9 f1 55 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7c2f:	90                                              	nop
  1d7c30:	0f 18 3d 39 9f f2 ff                            	prefetchit0 -0xd60c7(%rip)        # 101b70 <_ZN9cpp_redis6client5zcardERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKSt8functionIFvRNS_5replyEEE>
  1d7c37:	0f 18 3d 44 9f f2 ff                            	prefetchit0 -0xd60bc(%rip)        # 101b82 <_ZN9cpp_redis6client5zcardERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKSt8functionIFvRNS_5replyEEE+0x12>
  1d7c3e:	0f 18 3d 7e a0 f2 ff                            	prefetchit0 -0xd5f82(%rip)        # 101cc3 <_ZNSt17_Function_handlerIFRN9cpp_redis6clientERKSt8functionIFvRNS0_5replyEEEEZNS1_5zcardERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEUlS9_E_E9_M_invokeERKSt9_Any_dataS9_+0x13>
  1d7c45:	0f 18 3d 75 9f f2 ff                            	prefetchit0 -0xd608b(%rip)        # 101bc1 <_ZN9cpp_redis6client5zcardERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKSt8functionIFvRNS_5replyEEE+0x51>
  1d7c4c:	0f 18 3d 5d a0 f2 ff                            	prefetchit0 -0xd5fa3(%rip)        # 101cb0 <_ZNSt17_Function_handlerIFRN9cpp_redis6clientERKSt8functionIFvRNS0_5replyEEEEZNS1_5zcardERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEUlS9_E_E9_M_invokeERKSt9_Any_dataS9_>
  1d7c53:	e9 c8 55 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7c58:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d7c60:	0f 18 3d 99 40 f1 ff                            	prefetchit0 -0xebf67(%rip)        # ebd00 <_ZNSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS5_EEC2ESt16initializer_listIS5_ERKS6_.constprop.3>
  1d7c67:	e9 14 6a e5 ff                                  	jmp    2e680 <_ZNSt13__future_base12_Result_baseC2Ev@plt>
  1d7c6c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7c70:	0f 18 3d d9 bf f0 ff                            	prefetchit0 -0xf4027(%rip)        # e3c50 <_ZNSt17_Function_handlerIFRN9cpp_redis6clientERKSt8functionIFvRNS0_5replyEEEEZNS1_5zcardERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEUlS9_E_E10_M_managerERSt9_Any_dataRKSL_St18_Manager_operation>
  1d7c77:	0f 18 3d 03 c0 f0 ff                            	prefetchit0 -0xf3ffd(%rip)        # e3c81 <_ZNSt17_Function_handlerIFRN9cpp_redis6clientERKSt8functionIFvRNS0_5replyEEEEZNS1_5zcardERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEUlS9_E_E10_M_managerERSt9_Any_dataRKSL_St18_Manager_operation+0x31>
  1d7c7e:	e9 cd 2a f6 ff                                  	jmp    13a750 <_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv>
  1d7c83:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7c8d:	0f 1f 00                                        	nopl   (%rax)
  1d7c90:	0f 18 3d c9 5f f7 ff                            	prefetchit0 -0x8a037(%rip)        # 14dc60 <_ZN7tacopie10tcp_client11async_writeERKNS0_13write_requestE>
  1d7c97:	0f 18 3d e2 5f f7 ff                            	prefetchit0 -0x8a01e(%rip)        # 14dc80 <_ZN7tacopie10tcp_client11async_writeERKNS0_13write_requestE+0x20>
  1d7c9e:	e9 bd d0 f6 ff                                  	jmp    144d60 <_ZN9cpp_redis7network16redis_connection6commitEv>
  1d7ca3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7cad:	0f 1f 00                                        	nopl   (%rax)
  1d7cb0:	41 53                                           	push   %r11
  1d7cb2:	4c 8b 1d 17 d5 ff ff                            	mov    -0x2ae9(%rip),%r11        # 1d51d0 <pthread_mutex_unlock@GLIBC_2.2.5>
  1d7cb9:	41 0f 18 93 e0 fe ff ff                         	prefetcht1 -0x120(%r11)
  1d7cc1:	4c 8b 1d 40 d5 ff ff                            	mov    -0x2ac0(%rip),%r11        # 1d5208 <pthread_mutex_lock@GLIBC_2.2.5>
  1d7cc8:	41 0f 18 93 40 91 ff ff                         	prefetcht1 -0x6ec0(%r11)
  1d7cd0:	41 0f 18 93 50 91 ff ff                         	prefetcht1 -0x6eb0(%r11)
  1d7cd8:	41 0f 18 93 e0 ba ff ff                         	prefetcht1 -0x4520(%r11)
  1d7ce0:	41 0f 18 93 11 bb ff ff                         	prefetcht1 -0x44ef(%r11)
  1d7ce8:	4c 8b 1d d9 d7 ff ff                            	mov    -0x2827(%rip),%r11        # 1d54c8 <_ZdlPv@GLIBCXX_3.4>
  1d7cef:	41 0f 18 93 60 47 ff ff                         	prefetcht1 -0xb8a0(%r11)
  1d7cf7:	41 5b                                           	pop    %r11
  1d7cf9:	e9 12 57 e5 ff                                  	jmp    2d410 <pthread_mutex_lock@plt>
  1d7cfe:	66 90                                           	xchg   %ax,%ax
  1d7d00:	0f 18 3d e9 64 e9 ff                            	prefetchit0 -0x169b17(%rip)        # 6e1f0 <_ZNKSt14__basic_futureIN9cpp_redis5replyEE13_M_get_resultEv>
  1d7d07:	0f 18 3d f4 64 e9 ff                            	prefetchit0 -0x169b0c(%rip)        # 6e202 <_ZNKSt14__basic_futureIN9cpp_redis5replyEE13_M_get_resultEv+0x12>
  1d7d0e:	0f 18 3d 02 e0 e6 ff                            	prefetchit0 -0x191ffe(%rip)        # 45d17 <_ZN13media_service18MovieReviewHandler17UploadMovieReviewElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEllRKSt3mapIS6_S6_St4lessIS6_ESaISt4pairIS7_S6_EEE+0xa87>
  1d7d15:	e9 86 56 e5 ff                                  	jmp    2d3a0 <pthread_mutex_unlock@plt>
  1d7d1a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1d7d20:	0f 18 3d d9 00 f5 ff                            	prefetchit0 -0xaff27(%rip)        # 127e00 <_ZNSt17_Function_handlerIFvRN9cpp_redis5replyEEZNS0_6client8exec_cmdERKSt8functionIFRS4_RKS5_IS3_EEEEUlS2_E_E10_M_managerERSt9_Any_dataRKSG_St18_Manager_operation>
  1d7d27:	e9 04 54 e5 ff                                  	jmp    2d130 <memcpy@plt>
  1d7d2c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7d30:	0f 18 3d 19 eb f6 ff                            	prefetchit0 -0x914e7(%rip)        # 146850 <_ZNK9cpp_redis8builders13reply_builder15reply_availableEv>
  1d7d37:	0f 18 3d 42 eb f6 ff                            	prefetchit0 -0x914be(%rip)        # 146880 <_ZNK9cpp_redis8builders13reply_builder15reply_availableEv+0x30>
  1d7d3e:	e9 ad 8e f0 ff                                  	jmp    e0bf0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.constprop.0>
  1d7d43:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7d4d:	0f 1f 00                                        	nopl   (%rax)
  1d7d50:	0f 18 3d 33 cd f6 ff                            	prefetchit0 -0x932cd(%rip)        # 144a8a <_ZN9cpp_redis7network16redis_connection13build_commandERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS8_EE+0x67a>
  1d7d57:	e9 44 5b e5 ff                                  	jmp    2d8a0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@plt>
  1d7d5c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7d60:	41 53                                           	push   %r11
  1d7d62:	4c 8b 1d 5f d7 ff ff                            	mov    -0x28a1(%rip),%r11        # 1d54c8 <_ZdlPv@GLIBCXX_3.4>
  1d7d69:	41 0f 18 93 c0 53 ff ff                         	prefetcht1 -0xac40(%r11)
  1d7d71:	41 5b                                           	pop    %r11
  1d7d73:	e9 f8 5f e5 ff                                  	jmp    2dd70 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm@plt>
  1d7d78:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d7d80:	41 53                                           	push   %r11
  1d7d82:	4c 8b 1d a7 d8 ff ff                            	mov    -0x2759(%rip),%r11        # 1d5630 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@GLIBCXX_3.4.21>
  1d7d89:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7d91:	41 5b                                           	pop    %r11
  1d7d93:	e9 d8 5f e5 ff                                  	jmp    2dd70 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm@plt>
  1d7d98:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d7da0:	0f 18 3d e9 1d f6 ff                            	prefetchit0 -0x9e217(%rip)        # 139b90 <_ZNSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS5_EEC1ERKS7_>
  1d7da7:	0f 18 3d 12 1e f6 ff                            	prefetchit0 -0x9e1ee(%rip)        # 139bc0 <_ZNSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS5_EEC1ERKS7_+0x30>
  1d7dae:	e9 dd 5b e5 ff                                  	jmp    2d990 <_ZdlPv@plt>
  1d7db3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7dbd:	0f 1f 00                                        	nopl   (%rax)
  1d7dc0:	0f 18 3d 49 3d f6 ff                            	prefetchit0 -0x9c2b7(%rip)        # 13bb10 <_ZN9cpp_redis5replyC1Ev>
  1d7dc7:	0f 18 3d c2 01 f7 ff                            	prefetchit0 -0x8fe3e(%rip)        # 147f90 <_ZN9cpp_redis8builders14create_builderEc>
  1d7dce:	0f 18 3d 9b f9 f6 ff                            	prefetchit0 -0x90665(%rip)        # 147770 <_ZN9cpp_redis8builders13reply_builder11build_replyEv>
  1d7dd5:	0f 18 3d e4 01 f7 ff                            	prefetchit0 -0x8fe1c(%rip)        # 147fc0 <_ZN9cpp_redis8builders14create_builderEc+0x30>
  1d7ddc:	0f 18 3d 8d 5f e5 ff                            	prefetchit0 -0x1aa073(%rip)        # 2dd70 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm@plt>
  1d7de3:	0f 18 3d 56 11 f7 ff                            	prefetchit0 -0x8eeaa(%rip)        # 148f40 <_ZN9cpp_redis8builders15integer_builderC1Ev>
  1d7dea:	0f 18 3d 7f 63 e5 ff                            	prefetchit0 -0x1a9c81(%rip)        # 2e170 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE8_M_eraseEmm@plt>
  1d7df1:	0f 18 3d 8d f9 f6 ff                            	prefetchit0 -0x90673(%rip)        # 147785 <_ZN9cpp_redis8builders13reply_builder11build_replyEv+0x15>
  1d7df8:	e9 f3 fc f6 ff                                  	jmp    147af0 <_ZN9cpp_redis8builders13reply_builderlsERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  1d7dfd:	0f 1f 00                                        	nopl   (%rax)
  1d7e00:	0f 18 3d 7b 14 f6 ff                            	prefetchit0 -0x9eb85(%rip)        # 139282 <_ZNSt17_Function_handlerIFvRN9cpp_redis7network16redis_connectionERNS0_5replyEESt5_BindIFMNS0_6clientEFvS3_S5_EPS8_St12_PlaceholderILi1EESC_ILi2EEEEE9_M_invokeERKSt9_Any_dataS3_S5_+0x12>
  1d7e07:	0f 18 3d 42 4e f1 ff                            	prefetchit0 -0xeb1be(%rip)        # ecc50 <_ZN9cpp_redis6client26connection_receive_handlerERNS_7network16redis_connectionERNS_5replyE>
  1d7e0e:	0f 18 3d 5b 14 f6 ff                            	prefetchit0 -0x9eba5(%rip)        # 139270 <_ZNSt17_Function_handlerIFvRN9cpp_redis7network16redis_connectionERNS0_5replyEESt5_BindIFMNS0_6clientEFvS3_S5_EPS8_St12_PlaceholderILi1EESC_ILi2EEEEE9_M_invokeERKSt9_Any_dataS3_S5_>
  1d7e15:	0f 18 3d 68 4e f1 ff                            	prefetchit0 -0xeb198(%rip)        # ecc84 <_ZN9cpp_redis6client26connection_receive_handlerERNS_7network16redis_connectionERNS_5replyE+0x34>
  1d7e1c:	e9 8f ea f6 ff                                  	jmp    1468b0 <_ZNK9cpp_redis8builders13reply_builder9get_frontEv>
  1d7e21:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7e2b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1d7e30:	0f 18 3d e9 78 f7 ff                            	prefetchit0 -0x88717(%rip)        # 14f720 <_ZNK7tacopie10tcp_socket6get_fdEv>
  1d7e37:	0f 18 3d b2 41 f7 ff                            	prefetchit0 -0x8be4e(%rip)        # 14bff0 <_ZNSt8__detail9_Map_baseIiSt4pairIKiN7tacopie10io_service14tracked_socketEESaIS6_ENS_10_Select1stESt8equal_toIiESt4hashIiENS_18_Mod_range_hashingENS_20_Default_ranged_hashENS_20_Prime_rehash_policyENS_17_Hashtable_traitsILb0ELb0ELb1EEELb1EEixEOi>
  1d7e3e:	e9 4d 5b e5 ff                                  	jmp    2d990 <_ZdlPv@plt>
  1d7e43:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7e4d:	0f 1f 00                                        	nopl   (%rax)
  1d7e50:	0f 18 3d f9 df f6 ff                            	prefetchit0 -0x92007(%rip)        # 145e50 <_ZNSt17_Function_handlerIFvRN9cpp_redis7network16tcp_client_iface11read_resultEESt5_BindIFMNS1_16redis_connectionEFvRKS3_EPS7_St12_PlaceholderILi1EEEEE10_M_managerERSt9_Any_dataRKSI_St18_Manager_operation>
  1d7e57:	0f 18 3d 42 79 f7 ff                            	prefetchit0 -0x886be(%rip)        # 14f7a0 <_ZN7tacopie10tcp_socket4recvEm>
  1d7e5e:	0f 18 3d 0b 73 f7 ff                            	prefetchit0 -0x88cf5(%rip)        # 14f170 <_ZN7tacopie10tcp_socket17check_or_set_typeENS0_4typeE>
  1d7e65:	e9 b6 53 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7e6a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1d7e70:	0f 18 3d c9 49 f7 ff                            	prefetchit0 -0x8b637(%rip)        # 14c840 <_ZNK7tacopie10tcp_client12is_connectedEv>
  1d7e77:	e9 a4 53 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7e7c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7e80:	0f 18 3d f9 38 f7 ff                            	prefetchit0 -0x8c707(%rip)        # 14b780 <_ZN7tacopie10io_service15set_wr_callbackERKNS_10tcp_socketERKSt8functionIFviEE>
  1d7e87:	0f 18 3d 92 78 f7 ff                            	prefetchit0 -0x8876e(%rip)        # 14f720 <_ZNK7tacopie10tcp_socket6get_fdEv>
  1d7e8e:	e9 8d 53 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7e93:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7e9d:	0f 1f 00                                        	nopl   (%rax)
  1d7ea0:	0f 18 3d 79 0f f7 ff                            	prefetchit0 -0x8f087(%rip)        # 148e20 <_ZN9cpp_redis8builders15integer_builderlsERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  1d7ea7:	41 53                                           	push   %r11
  1d7ea9:	4c 8b 1d 18 d4 ff ff                            	mov    -0x2be8(%rip),%r11        # 1d52c8 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4findEPKcmm@GLIBCXX_3.4.21>
  1d7eb0:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7eb8:	4c 8b 1d 09 d6 ff ff                            	mov    -0x29f7(%rip),%r11        # 1d54c8 <_ZdlPv@GLIBCXX_3.4>
  1d7ebf:	41 0f 18 93 c0 3e ff ff                         	prefetcht1 -0xc140(%r11)
  1d7ec7:	4c 8b 1d 8a d7 ff ff                            	mov    -0x2876(%rip),%r11        # 1d5658 <bcmp@GLIBC_2.2.5>
  1d7ece:	41 0f 18 93 00 fd ff ff                         	prefetcht1 -0x300(%r11)
  1d7ed6:	41 5b                                           	pop    %r11
  1d7ed8:	e9 b3 00 f7 ff                                  	jmp    147f90 <_ZN9cpp_redis8builders14create_builderEc>
  1d7edd:	0f 1f 00                                        	nopl   (%rax)
  1d7ee0:	41 53                                           	push   %r11
  1d7ee2:	4c 8b 1d df d5 ff ff                            	mov    -0x2a21(%rip),%r11        # 1d54c8 <_ZdlPv@GLIBCXX_3.4>
  1d7ee9:	41 0f 18 93 f0 48 ff ff                         	prefetcht1 -0xb710(%r11)
  1d7ef1:	41 5b                                           	pop    %r11
  1d7ef3:	e9 78 62 e5 ff                                  	jmp    2e170 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE8_M_eraseEmm@plt>
  1d7ef8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d7f00:	0f 18 3d 28 f9 f6 ff                            	prefetchit0 -0x906d8(%rip)        # 14782f <_ZN9cpp_redis8builders13reply_builder11build_replyEv+0xbf>
  1d7f07:	e9 64 5e e5 ff                                  	jmp    2dd70 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm@plt>
  1d7f0c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7f10:	0f 18 3d 5f db f6 ff                            	prefetchit0 -0x924a1(%rip)        # 145a76 <_ZN9cpp_redis7network16redis_connection26tcp_client_receive_handlerERKNS0_16tcp_client_iface11read_resultE+0x5b6>
  1d7f17:	e9 54 f8 f6 ff                                  	jmp    147770 <_ZN9cpp_redis8builders13reply_builder11build_replyEv>
  1d7f1c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7f20:	0f 18 3d c9 8c f0 ff                            	prefetchit0 -0xf7337(%rip)        # e0bf0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.constprop.0>
  1d7f27:	0f 18 3d 52 38 f6 ff                            	prefetchit0 -0x9c7ae(%rip)        # 13b780 <_ZN9cpp_redis5replyC1ERKS0_+0x3c0>
  1d7f2e:	e9 6d 3c f6 ff                                  	jmp    13bba0 <_ZN9cpp_redis5reply3setEl>
  1d7f33:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7f3d:	0f 1f 00                                        	nopl   (%rax)
  1d7f40:	0f 18 3d fd 59 f7 ff                            	prefetchit0 -0x8a603(%rip)        # 14d944 <_ZN7tacopie10tcp_client17on_read_availableEi+0x34>
  1d7f47:	0f 18 3d c2 59 f7 ff                            	prefetchit0 -0x8a63e(%rip)        # 14d910 <_ZN7tacopie10tcp_client17on_read_availableEi>
  1d7f4e:	0f 18 3d ec 42 f7 ff                            	prefetchit0 -0x8bd14(%rip)        # 14c241 <_ZN7tacopie10tcp_client12process_readERNS0_11read_resultE+0x21>
  1d7f55:	0f 18 3d 44 5f f7 ff                            	prefetchit0 -0x8a0bc(%rip)        # 14dea0 <_ZNSt17_Function_handlerIFviESt5_BindIFMN7tacopie10tcp_clientEFviEPS3_St12_PlaceholderILi1EEEEE9_M_invokeERKSt9_Any_dataOi>
  1d7f5c:	41 53                                           	push   %r11
  1d7f5e:	4c 8b 1d c3 d5 ff ff                            	mov    -0x2a3d(%rip),%r11        # 1d5528 <_ZNSt18condition_variable10notify_oneEv@GLIBCXX_3.4.11>
  1d7f65:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7f6d:	41 5b                                           	pop    %r11
  1d7f6f:	e9 ac 52 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7f74:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7f7e:	66 90                                           	xchg   %ax,%ax
  1d7f80:	0f 18 3d 3a 45 f7 ff                            	prefetchit0 -0x8bac6(%rip)        # 14c4c1 <_ZN7tacopie10tcp_client13process_writeERNS0_12write_resultE+0x11>
  1d7f87:	0f 18 3d 72 5a f7 ff                            	prefetchit0 -0x8a58e(%rip)        # 14da00 <_ZN7tacopie10tcp_client18on_write_availableEi>
  1d7f8e:	0f 18 3d 0b 5f f7 ff                            	prefetchit0 -0x8a0f5(%rip)        # 14dea0 <_ZNSt17_Function_handlerIFviESt5_BindIFMN7tacopie10tcp_clientEFviEPS3_St12_PlaceholderILi1EEEEE9_M_invokeERKSt9_Any_dataOi>
  1d7f95:	0f 18 3d c4 2f f7 ff                            	prefetchit0 -0x8d03c(%rip)        # 14af60 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_wr_eventERKiRNS2_14tracked_socketEEUlvE_E9_M_invokeERKSt9_Any_data>
  1d7f9c:	0f 18 3d 0d 45 f7 ff                            	prefetchit0 -0x8baf3(%rip)        # 14c4b0 <_ZN7tacopie10tcp_client13process_writeERNS0_12write_resultE>
  1d7fa3:	e9 78 52 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7fa8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d7fb0:	0f 18 3d cc 84 f7 ff                            	prefetchit0 -0x87b34(%rip)        # 150483 <_ZN7tacopie5utils11thread_pool8add_taskERKSt8functionIFvvEE+0x23>
  1d7fb7:	0f 18 3d a2 84 f7 ff                            	prefetchit0 -0x87b5e(%rip)        # 150460 <_ZN7tacopie5utils11thread_pool8add_taskERKSt8functionIFvvEE>
  1d7fbe:	e9 5d 52 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7fc3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7fcd:	0f 1f 00                                        	nopl   (%rax)
  1d7fd0:	0f 18 3d 59 85 f7 ff                            	prefetchit0 -0x87aa7(%rip)        # 150530 <_ZN7tacopie5utils11thread_poollsERKSt8functionIFvvEE>
  1d7fd7:	0f 18 3d 82 84 f7 ff                            	prefetchit0 -0x87b7e(%rip)        # 150460 <_ZN7tacopie5utils11thread_pool8add_taskERKSt8functionIFvvEE>
  1d7fde:	e9 3d 52 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7fe3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7fed:	0f 1f 00                                        	nopl   (%rax)
  1d7ff0:	0f 18 3d 59 21 f7 ff                            	prefetchit0 -0x8dea7(%rip)        # 14a150 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_wr_eventERKiRNS2_14tracked_socketEEUlvE_E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation>
  1d7ff7:	e9 34 85 f7 ff                                  	jmp    150530 <_ZN7tacopie5utils11thread_poollsERKSt8functionIFvvEE>
  1d7ffc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d8000:	0f 18 3d 69 24 f7 ff                            	prefetchit0 -0x8db97(%rip)        # 14a470 <_ZN7tacopie10io_service16process_rd_eventERKiRNS0_14tracked_socketE>
  1d8007:	e9 24 59 e5 ff                                  	jmp    2d930 <__fdelt_chk@plt>
  1d800c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d8010:	0f 18 3d 59 26 f7 ff                            	prefetchit0 -0x8d9a7(%rip)        # 14a670 <_ZN7tacopie10io_service16process_wr_eventERKiRNS0_14tracked_socketE>
  1d8017:	e9 14 59 e5 ff                                  	jmp    2d930 <__fdelt_chk@plt>
  1d801c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d8020:	0f 18 3d 9d 24 f7 ff                            	prefetchit0 -0x8db63(%rip)        # 14a4c4 <_ZN7tacopie10io_service16process_rd_eventERKiRNS0_14tracked_socketE+0x54>
  1d8027:	0f 18 3d 53 26 f7 ff                            	prefetchit0 -0x8d9ad(%rip)        # 14a681 <_ZN7tacopie10io_service16process_wr_eventERKiRNS0_14tracked_socketE+0x11>
  1d802e:	41 53                                           	push   %r11
  1d8030:	4c 8b 1d 61 d4 ff ff                            	mov    -0x2b9f(%rip),%r11        # 1d5498 <__fdelt_chk@GLIBC_2.15>
  1d8037:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d803f:	4c 8b 1d aa d6 ff ff                            	mov    -0x2956(%rip),%r11        # 1d56f0 <read@GLIBC_2.2.5>
  1d8046:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d804e:	41 5b                                           	pop    %r11
  1d8050:	e9 db 58 e5 ff                                  	jmp    2d930 <__fdelt_chk@plt>
  1d8055:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d805f:	90                                              	nop
  1d8060:	0f 18 3d a9 5e f7 ff                            	prefetchit0 -0x8a157(%rip)        # 14df10 <_ZNSt17_Function_handlerIFviESt5_BindIFMN7tacopie10tcp_clientEFviEPS3_St12_PlaceholderILi1EEEEE10_M_managerERSt9_Any_dataRKSC_St18_Manager_operation>
  1d8067:	e9 04 26 f7 ff                                  	jmp    14a670 <_ZN7tacopie10io_service16process_wr_eventERKiRNS0_14tracked_socketE>
  1d806c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d8070:	41 53                                           	push   %r11
  1d8072:	4c 8b 1d 17 d0 ff ff                            	mov    -0x2fe9(%rip),%r11        # 1d5090 <select@GLIBC_2.2.5>
  1d8079:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d8081:	41 5b                                           	pop    %r11
  1d8083:	e9 48 8a f7 ff                                  	jmp    150ad0 <_ZNK7tacopie9self_pipe11get_read_fdEv>
  1d8088:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d8090:	41 53                                           	push   %r11
  1d8092:	4c 8b 1d f7 cf ff ff                            	mov    -0x3009(%rip),%r11        # 1d5090 <select@GLIBC_2.2.5>
  1d8099:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
  1d80a1:	41 5b                                           	pop    %r11
  1d80a3:	e9 88 58 e5 ff                                  	jmp    2d930 <__fdelt_chk@plt>
  1d80a8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d80b0:	41 53                                           	push   %r11
  1d80b2:	4c 8b 1d d7 cf ff ff                            	mov    -0x3029(%rip),%r11        # 1d5090 <select@GLIBC_2.2.5>
  1d80b9:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
  1d80c1:	41 5b                                           	pop    %r11
  1d80c3:	e9 58 50 e5 ff                                  	jmp    2d120 <select@plt>
  1d80c8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d80d0:	0f 18 3d f9 89 f7 ff                            	prefetchit0 -0x87607(%rip)        # 150ad0 <_ZNK7tacopie9self_pipe11get_read_fdEv>
  1d80d7:	0f 18 3d 52 58 e5 ff                            	prefetchit0 -0x1aa7ae(%rip)        # 2d930 <__fdelt_chk@plt>
  1d80de:	0f 18 3d 2b 53 e5 ff                            	prefetchit0 -0x1aacd5(%rip)        # 2d410 <pthread_mutex_lock@plt>
  1d80e5:	41 53                                           	push   %r11
  1d80e7:	4c 8b 1d aa d3 ff ff                            	mov    -0x2c56(%rip),%r11        # 1d5498 <__fdelt_chk@GLIBC_2.15>
  1d80ee:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d80f6:	41 5b                                           	pop    %r11
  1d80f8:	e9 13 2b f7 ff                                  	jmp    14ac10 <_ZN7tacopie10io_service14process_eventsEv>
  1d80fd:	0f 1f 00                                        	nopl   (%rax)
  1d8100:	0f 18 3d 39 67 f7 ff                            	prefetchit0 -0x898c7(%rip)        # 14e840 <_ZNSt5dequeIN7tacopie10tcp_client12read_requestESaIS2_EE16_M_push_back_auxIJRKS2_EEEvDpOT_>
  1d8107:	e9 e4 89 f7 ff                                  	jmp    150af0 <_ZN7tacopie9self_pipe6notifyEv>
  1d810c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d8110:	0f 18 3d d9 3e f7 ff                            	prefetchit0 -0x8c127(%rip)        # 14bff0 <_ZNSt8__detail9_Map_baseIiSt4pairIKiN7tacopie10io_service14tracked_socketEESaIS6_ENS_10_Select1stESt8equal_toIiESt4hashIiENS_18_Mod_range_hashingENS_20_Default_ranged_hashENS_20_Prime_rehash_policyENS_17_Hashtable_traitsILb0ELb0ELb1EEELb1EEixEOi>
  1d8117:	0f 18 3d d2 89 f7 ff                            	prefetchit0 -0x8762e(%rip)        # 150af0 <_ZN7tacopie9self_pipe6notifyEv>
  1d811e:	e9 ed 52 e5 ff                                  	jmp    2d410 <pthread_mutex_lock@plt>
  1d8123:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d812d:	0f 1f 00                                        	nopl   (%rax)
  1d8130:	0f 18 3d 79 d9 f6 ff                            	prefetchit0 -0x92687(%rip)        # 145ab0 <_ZN9cpp_redis7network16redis_connection26tcp_client_receive_handlerERKNS0_16tcp_client_iface11read_resultE+0x5f0>
  1d8137:	0f 18 3d 83 d9 f6 ff                            	prefetchit0 -0x9267d(%rip)        # 145ac1 <_ZN9cpp_redis7network16redis_connection26tcp_client_receive_handlerERKNS0_16tcp_client_iface11read_resultE+0x601>
  1d813e:	0f 18 3d 4b dc f6 ff                            	prefetchit0 -0x923b5(%rip)        # 145d90 <_ZNSt17_Function_handlerIFvRN9cpp_redis7network16tcp_client_iface11read_resultEESt5_BindIFMNS1_16redis_connectionEFvRKS3_EPS7_St12_PlaceholderILi1EEEEE9_M_invokeERKSt9_Any_dataS4_>
  1d8145:	0f 18 3d a4 f9 f6 ff                            	prefetchit0 -0x9065c(%rip)        # 147af0 <_ZN9cpp_redis8builders13reply_builderlsERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  1d814c:	0f 18 3d 6d d3 f6 ff                            	prefetchit0 -0x92c93(%rip)        # 1454c0 <_ZN9cpp_redis7network16redis_connection26tcp_client_receive_handlerERKNS0_16tcp_client_iface11read_resultE>
  1d8153:	41 53                                           	push   %r11
  1d8155:	4c 8b 1d 5c d5 ff ff                            	mov    -0x2aa4(%rip),%r11        # 1d56b8 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm@GLIBCXX_3.4.21>
  1d815c:	41 0f 18 93 22 00 00 00                         	prefetcht1 0x22(%r11)
  1d8164:	41 5b                                           	pop    %r11
  1d8166:	e9 35 52 e5 ff                                  	jmp    2d3a0 <pthread_mutex_unlock@plt>
  1d816b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1d8170:	0f 18 3d 49 70 f7 ff                            	prefetchit0 -0x88fb7(%rip)        # 14f1c0 <_ZN7tacopie10tcp_socket4sendERKSt6vectorIcSaIcEEm>
  1d8177:	0f 18 3d f2 6f f7 ff                            	prefetchit0 -0x8900e(%rip)        # 14f170 <_ZN7tacopie10tcp_socket17check_or_set_typeENS0_4typeE>
  1d817e:	0f 18 3d eb 8a f7 ff                            	prefetchit0 -0x87515(%rip)        # 150c70 <_ZN7tacopie10tcp_socket26create_socket_if_necessaryEv>
  1d8185:	0f 18 3d fb 8a f7 ff                            	prefetchit0 -0x87505(%rip)        # 150c87 <_ZN7tacopie10tcp_socket26create_socket_if_necessaryEv+0x17>
  1d818c:	e9 7f 52 e5 ff                                  	jmp    2d410 <pthread_mutex_lock@plt>
  1d8191:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d819b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1d81a0:	0f 18 3d 19 36 f7 ff                            	prefetchit0 -0x8c9e7(%rip)        # 14b7c0 <_ZN7tacopie10io_service15set_wr_callbackERKNS_10tcp_socketERKSt8functionIFviEE+0x40>
  1d81a7:	e9 e4 57 e5 ff                                  	jmp    2d990 <_ZdlPv@plt>
  1d81ac:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d81b0:	0f 18 3d 49 de f6 ff                            	prefetchit0 -0x921b7(%rip)        # 146000 <_ZNSt17_Function_handlerIFvRN7tacopie10tcp_client12write_resultEEZN9cpp_redis7network10tcp_client11async_writeERNS6_16tcp_client_iface13write_requestEEUlS3_E_E9_M_invokeERKSt9_Any_dataS3_>
  1d81b7:	e9 e4 51 e5 ff                                  	jmp    2d3a0 <pthread_mutex_unlock@plt>
  1d81bc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d81c0:	41 53                                           	push   %r11
  1d81c2:	4c 8b 1d 0f d8 ff ff                            	mov    -0x27f1(%rip),%r11        # 1d59d8 <write@GLIBC_2.2.5>
  1d81c9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d81d1:	41 5b                                           	pop    %r11
  1d81d3:	e9 a8 35 f7 ff                                  	jmp    14b780 <_ZN7tacopie10io_service15set_wr_callbackERKNS_10tcp_socketERKSt8functionIFviEE>
  1d81d8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d81e0:	0f 18 3d 79 1e f7 ff                            	prefetchit0 -0x8e187(%rip)        # 14a060 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_rd_eventERKiRNS2_14tracked_socketEEUlvE_E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation>
  1d81e7:	e9 34 50 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d81ec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d81f0:	41 53                                           	push   %r11
  1d81f2:	4c 8b 1d 0f d0 ff ff                            	mov    -0x2ff1(%rip),%r11        # 1d5208 <pthread_mutex_lock@GLIBC_2.2.5>
  1d81f9:	41 0f 18 93 40 b9 ff ff                         	prefetcht1 -0x46c0(%r11)
  1d8201:	41 0f 18 93 50 b9 ff ff                         	prefetcht1 -0x46b0(%r11)
  1d8209:	4c 8b 1d b8 d2 ff ff                            	mov    -0x2d48(%rip),%r11        # 1d54c8 <_ZdlPv@GLIBCXX_3.4>
  1d8210:	41 0f 18 93 60 47 ff ff                         	prefetcht1 -0xb8a0(%r11)
  1d8218:	41 5b                                           	pop    %r11
  1d821a:	e9 f1 51 e5 ff                                  	jmp    2d410 <pthread_mutex_lock@plt>
  1d821f:	90                                              	nop
  1d8220:	0f 18 3d 39 1e f7 ff                            	prefetchit0 -0x8e1c7(%rip)        # 14a060 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_rd_eventERKiRNS2_14tracked_socketEEUlvE_E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation>
  1d8227:	0f 18 3d 22 1f f7 ff                            	prefetchit0 -0x8e0de(%rip)        # 14a150 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_wr_eventERKiRNS2_14tracked_socketEEUlvE_E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation>
  1d822e:	0f 18 3d db 5c f7 ff                            	prefetchit0 -0x8a325(%rip)        # 14df10 <_ZNSt17_Function_handlerIFviESt5_BindIFMN7tacopie10tcp_clientEFviEPS3_St12_PlaceholderILi1EEEEE10_M_managerERSt9_Any_dataRKSC_St18_Manager_operation>
  1d8235:	e9 16 7c f7 ff                                  	jmp    14fe50 <_ZNK7tacopie5utils11thread_pool11should_stopEv>
  1d823a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1d8240:	0f 18 3d 19 1e f7 ff                            	prefetchit0 -0x8e1e7(%rip)        # 14a060 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_rd_eventERKiRNS2_14tracked_socketEEUlvE_E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation>
  1d8247:	e9 c4 51 e5 ff                                  	jmp    2d410 <pthread_mutex_lock@plt>
