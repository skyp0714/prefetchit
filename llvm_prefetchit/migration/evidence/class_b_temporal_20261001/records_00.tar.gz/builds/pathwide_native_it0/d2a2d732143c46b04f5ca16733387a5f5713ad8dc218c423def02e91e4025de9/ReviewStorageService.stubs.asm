
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_native_it0/d2a2d732143c46b04f5ca16733387a5f5713ad8dc218c423def02e91e4025de9/ReviewStorageService:     file format elf64-x86-64


Disassembly of section .text.prefetch_calls:

000000000010b340 <.text.prefetch_calls>:
  10b340:	0f 18 3d bc 06 f4 ff                            	prefetchit0 -0xbf944(%rip)        # 4ba03 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0xc3>
  10b347:	0f 18 3d f5 06 f4 ff                            	prefetchit0 -0xbf90b(%rip)        # 4ba43 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0x103>
  10b34e:	0f 18 3d 5b 10 f4 ff                            	prefetchit0 -0xbefa5(%rip)        # 4c3b0 <_ZNSt17_Function_handlerIFN11opentracing2v28expectedIvSt10error_codeEENS1_11string_viewES5_EZNK13jaegertracing11propagation10PropagatorIRKNS1_13TextMapReaderERKNS1_13TextMapWriterEE7extractESC_EUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESO_E_E9_M_invokeERKSt9_Any_dataOS5_SU_>
  10b355:	0f 18 3d c4 5c f4 ff                            	prefetchit0 -0xba33c(%rip)        # 51020 <_ZNK13media_service13TextMapReader10ForeachKeyESt8functionIFN11opentracing2v28expectedIvSt10error_codeEENS3_11string_viewES7_EE>
  10b35c:	0f 18 3d dd 05 f4 ff                            	prefetchit0 -0xbfa23(%rip)        # 4b940 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_>
  10b363:	0f 18 3d 16 5d f4 ff                            	prefetchit0 -0xba2ea(%rip)        # 51080 <_ZNK13media_service13TextMapReader10ForeachKeyESt8functionIFN11opentracing2v28expectedIvSt10error_codeEENS3_11string_viewES7_EE+0x60>
  10b36a:	41 53                                           	push   %r11
  10b36c:	4c 8b 1d ad de ff ff                            	mov    -0x2153(%rip),%r11        # 109220 <_ZN11opentracing2v26Tracer6GlobalEv@Base>
  10b373:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  10b37b:	4c 8b 1d 2e e2 ff ff                            	mov    -0x1dd2(%rip),%r11        # 1095b0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  10b382:	41 0f 18 93 60 69 00 00                         	prefetcht1 0x6960(%r11)
  10b38a:	41 5b                                           	pop    %r11
  10b38c:	e9 af c0 f1 ff                                  	jmp    27440 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  10b391:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  10b39b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  10b3a0:	0f 18 3d 69 e2 f2 ff                            	prefetchit0 -0xd1d97(%rip)        # 39610 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  10b3a7:	e9 94 c0 f1 ff                                  	jmp    27440 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  10b3ac:	0f 1f 40 00                                     	nopl   0x0(%rax)
  10b3b0:	41 53                                           	push   %r11
  10b3b2:	4c 8b 1d 77 dd ff ff                            	mov    -0x2289(%rip),%r11        # 109130 <_Znwm@GLIBCXX_3.4>
  10b3b9:	41 0f 18 93 b0 06 00 00                         	prefetcht1 0x6b0(%r11)
  10b3c1:	4c 8b 1d e8 e1 ff ff                            	mov    -0x1e18(%rip),%r11        # 1095b0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  10b3c8:	41 0f 18 93 c5 1f 00 00                         	prefetcht1 0x1fc5(%r11)
  10b3d0:	41 0f 18 93 c0 31 00 00                         	prefetcht1 0x31c0(%r11)
  10b3d8:	41 5b                                           	pop    %r11
  10b3da:	e9 31 e2 f2 ff                                  	jmp    39610 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  10b3df:	90                                              	nop
  10b3e0:	41 53                                           	push   %r11
  10b3e2:	4c 8b 1d c7 e1 ff ff                            	mov    -0x1e39(%rip),%r11        # 1095b0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  10b3e9:	41 0f 18 93 50 79 00 00                         	prefetcht1 0x7950(%r11)
  10b3f1:	4c 8b 1d b8 e4 ff ff                            	mov    -0x1b48(%rip),%r11        # 1098b0 <_ZNSt7__cxx1119basic_ostringstreamIcSt11char_traitsIcESaIcEEC1Ev@GLIBCXX_3.4.26>
  10b3f8:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  10b400:	41 0f 18 93 34 00 00 00                         	prefetcht1 0x34(%r11)
  10b408:	41 5b                                           	pop    %r11
  10b40a:	e9 31 c0 f1 ff                                  	jmp    27440 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  10b40f:	90                                              	nop
  10b410:	41 53                                           	push   %r11
  10b412:	4c 8b 1d df de ff ff                            	mov    -0x2121(%rip),%r11        # 1092f8 <bson_destroy@Base>
  10b419:	41 0f 18 93 d0 d7 00 00                         	prefetcht1 0xd7d0(%r11)
  10b421:	41 5b                                           	pop    %r11
  10b423:	e9 c8 c7 f1 ff                                  	jmp    27bf0 <mongoc_client_pool_pop@plt>
  10b428:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  10b430:	41 53                                           	push   %r11
  10b432:	4c 8b 1d 9f dd ff ff                            	mov    -0x2261(%rip),%r11        # 1091d8 <pthread_mutex_unlock@GLIBC_2.2.5>
  10b439:	41 0f 18 93 d3 ca 00 00                         	prefetcht1 0xcad3(%r11)
  10b441:	4c 8b 1d b0 de ff ff                            	mov    -0x2150(%rip),%r11        # 1092f8 <bson_destroy@Base>
  10b448:	41 0f 18 93 00 d7 00 00                         	prefetcht1 0xd700(%r11)
  10b450:	41 5b                                           	pop    %r11
  10b452:	e9 99 c8 f1 ff                                  	jmp    27cf0 <mongoc_client_get_collection@plt>
  10b457:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  10b460:	41 53                                           	push   %r11
  10b462:	4c 8b 1d 7f e3 ff ff                            	mov    -0x1c81(%rip),%r11        # 1097e8 <bson_append_int32@Base>
  10b469:	41 0f 18 93 e0 99 ff ff                         	prefetcht1 -0x6620(%r11)
  10b471:	41 5b                                           	pop    %r11
  10b473:	e9 c8 cc f1 ff                                  	jmp    28140 <bson_new@plt>
  10b478:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  10b480:	41 53                                           	push   %r11
  10b482:	4c 8b 1d 47 dd ff ff                            	mov    -0x22b9(%rip),%r11        # 1091d0 <bson_append_utf8@Base>
  10b489:	41 0f 18 93 3a 00 00 00                         	prefetcht1 0x3a(%r11)
  10b491:	41 0f 18 93 80 00 00 00                         	prefetcht1 0x80(%r11)
  10b499:	4c 8b 1d 48 e3 ff ff                            	mov    -0x1cb8(%rip),%r11        # 1097e8 <bson_append_int32@Base>
  10b4a0:	41 0f 18 93 70 e9 ff ff                         	prefetcht1 -0x1690(%r11)
  10b4a8:	41 0f 18 93 91 e9 ff ff                         	prefetcht1 -0x166f(%r11)
  10b4b0:	41 5b                                           	pop    %r11
  10b4b2:	e9 c9 c1 f1 ff                                  	jmp    27680 <strlen@plt>
  10b4b7:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  10b4c0:	41 53                                           	push   %r11
  10b4c2:	4c 8b 1d 1f e3 ff ff                            	mov    -0x1ce1(%rip),%r11        # 1097e8 <bson_append_int32@Base>
  10b4c9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  10b4d1:	41 0f 18 93 15 00 00 00                         	prefetcht1 0x15(%r11)
  10b4d9:	41 0f 18 93 53 00 00 00                         	prefetcht1 0x53(%r11)
  10b4e1:	41 5b                                           	pop    %r11
  10b4e3:	e9 e8 ca f1 ff                                  	jmp    27fd0 <bson_append_int32@plt>
  10b4e8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  10b4f0:	41 53                                           	push   %r11
  10b4f2:	4c 8b 1d ff dd ff ff                            	mov    -0x2201(%rip),%r11        # 1092f8 <bson_destroy@Base>
  10b4f9:	41 0f 18 93 b0 04 00 00                         	prefetcht1 0x4b0(%r11)
  10b501:	41 0f 18 93 e0 26 00 00                         	prefetcht1 0x26e0(%r11)
  10b509:	41 0f 18 93 80 53 00 00                         	prefetcht1 0x5380(%r11)
  10b511:	4c 8b 1d 30 e0 ff ff                            	mov    -0x1fd0(%rip),%r11        # 109548 <mongoc_collection_insert_one@Base>
  10b518:	41 0f 18 93 b0 89 01 00                         	prefetcht1 0x189b0(%r11)
  10b520:	41 0f 18 93 b0 57 03 00                         	prefetcht1 0x357b0(%r11)
  10b528:	41 0f 18 93 30 5a 03 00                         	prefetcht1 0x35a30(%r11)
  10b530:	4c 8b 1d 41 e1 ff ff                            	mov    -0x1ebf(%rip),%r11        # 109678 <mongoc_client_get_collection@Base>
  10b537:	41 0f 18 93 60 50 ff ff                         	prefetcht1 -0xafa0(%r11)
  10b53f:	41 0f 18 93 60 76 ff ff                         	prefetcht1 -0x89a0(%r11)
  10b547:	41 5b                                           	pop    %r11
  10b549:	e9 42 c5 f1 ff                                  	jmp    27a90 <mongoc_collection_insert_one@plt>
  10b54e:	66 90                                           	xchg   %ax,%ax
  10b550:	41 53                                           	push   %r11
  10b552:	4c 8b 1d 57 e0 ff ff                            	mov    -0x1fa9(%rip),%r11        # 1095b0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  10b559:	41 0f 18 93 20 6f fe ff                         	prefetcht1 -0x190e0(%r11)
  10b561:	41 0f 18 93 5a b4 ff ff                         	prefetcht1 -0x4ba6(%r11)
  10b569:	41 5b                                           	pop    %r11
  10b56b:	e9 e0 cb f1 ff                                  	jmp    28150 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
  10b570:	0f 18 3d 79 c0 f1 ff                            	prefetchit0 -0xe3f87(%rip)        # 275f0 <bson_destroy@plt>
  10b577:	e9 24 67 f4 ff                                  	jmp    51ca0 <_ZNSt6vectorIN11opentracing2v29LogRecordESaIS2_EED2Ev>
  10b57c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  10b580:	41 53                                           	push   %r11
  10b582:	4c 8b 1d bf df ff ff                            	mov    -0x2041(%rip),%r11        # 109548 <mongoc_collection_insert_one@Base>
  10b589:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  10b591:	41 0f 18 93 f2 89 01 00                         	prefetcht1 0x189f2(%r11)
  10b599:	41 5b                                           	pop    %r11
  10b59b:	e9 10 bc f1 ff                                  	jmp    271b0 <_ZdlPvm@plt>
  10b5a0:	41 53                                           	push   %r11
  10b5a2:	4c 8b 1d af de ff ff                            	mov    -0x2151(%rip),%r11        # 109458 <_ZNSo9_M_insertImEERSoT_@GLIBCXX_3.4.9>
  10b5a9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  10b5b1:	4c 8b 1d 48 e3 ff ff                            	mov    -0x1cb8(%rip),%r11        # 109900 <_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l@GLIBCXX_3.4.9>
  10b5b8:	41 0f 18 93 70 e8 fe ff                         	prefetcht1 -0x11790(%r11)
  10b5c0:	41 0f 18 93 20 26 ff ff                         	prefetcht1 -0xd9e0(%r11)
  10b5c8:	41 0f 18 93 31 26 ff ff                         	prefetcht1 -0xd9cf(%r11)
  10b5d0:	41 0f 18 93 10 29 ff ff                         	prefetcht1 -0xd6f0(%r11)
  10b5d8:	41 0f 18 93 a0 f5 ff ff                         	prefetcht1 -0xa60(%r11)
  10b5e0:	41 0f 18 93 b0 f5 ff ff                         	prefetcht1 -0xa50(%r11)
  10b5e8:	41 5b                                           	pop    %r11
  10b5ea:	e9 41 25 f4 ff                                  	jmp    4db30 <_ZNK13jaegertracing11SpanContext5printISoEEvRT_>
  10b5ef:	90                                              	nop
  10b5f0:	41 53                                           	push   %r11
  10b5f2:	4c 8b 1d ff df ff ff                            	mov    -0x2001(%rip),%r11        # 1095f8 <mongoc_client_pool_pop@Base>
  10b5f9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  10b601:	41 5b                                           	pop    %r11
  10b603:	e9 28 cc f1 ff                                  	jmp    28230 <_ZNSt6localeD1Ev@plt>
  10b608:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  10b610:	41 53                                           	push   %r11
  10b612:	4c 8b 1d d7 dd ff ff                            	mov    -0x2229(%rip),%r11        # 1093f0 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode@GLIBCXX_3.4.21>
  10b619:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  10b621:	41 5b                                           	pop    %r11
  10b623:	e9 18 bb f1 ff                                  	jmp    27140 <memcpy@plt>
  10b628:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  10b630:	0f 18 3d a9 c1 f1 ff                            	prefetchit0 -0xe3e57(%rip)        # 277e0 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode@plt>
  10b637:	0f 18 3d 85 09 f4 ff                            	prefetchit0 -0xbf67b(%rip)        # 4bfc3 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE11decodeValueERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE+0x23>
  10b63e:	41 53                                           	push   %r11
  10b640:	4c 8b 1d a9 dd ff ff                            	mov    -0x2257(%rip),%r11        # 1093f0 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode@GLIBCXX_3.4.21>
  10b647:	41 0f 18 93 11 00 00 00                         	prefetcht1 0x11(%r11)
  10b64f:	41 5b                                           	pop    %r11
  10b651:	e9 ea ba f1 ff                                  	jmp    27140 <memcpy@plt>
  10b656:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  10b660:	0f 18 3d 89 be f1 ff                            	prefetchit0 -0xe4177(%rip)        # 274f0 <memset@plt>
  10b667:	0f 18 3d 1c d2 f3 ff                            	prefetchit0 -0xc2de4(%rip)        # 4888a <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev+0xaa>
  10b66e:	e9 6d d1 f3 ff                                  	jmp    487e0 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  10b673:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  10b67d:	0f 1f 00                                        	nopl   (%rax)
  10b680:	0f 18 3d 99 09 f4 ff                            	prefetchit0 -0xbf667(%rip)        # 4c020 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE12normalizeKeyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  10b687:	0f 18 3d b5 09 f4 ff                            	prefetchit0 -0xbf64b(%rip)        # 4c043 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE12normalizeKeyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE+0x23>
  10b68e:	e9 cd 0d f4 ff                                  	jmp    4c460 <_ZSt13__invoke_implIN11opentracing2v28expectedIvSt10error_codeEERZNK13jaegertracing11propagation10PropagatorIRKNS1_13TextMapReaderERKNS1_13TextMapWriterEE7extractESA_EUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESM_E_JNS1_11string_viewESP_EET_St14__invoke_otherOT0_DpOT1_>
  10b693:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  10b69d:	0f 1f 00                                        	nopl   (%rax)
  10b6a0:	0f 18 3d 69 22 f4 ff                            	prefetchit0 -0xbdd97(%rip)        # 4d910 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_>
  10b6a7:	e9 04 bb f1 ff                                  	jmp    271b0 <_ZdlPvm@plt>
  10b6ac:	0f 1f 40 00                                     	nopl   0x0(%rax)
  10b6b0:	0f 18 3d e9 08 f4 ff                            	prefetchit0 -0xbf717(%rip)        # 4bfa0 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE11decodeValueERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  10b6b7:	e9 84 ba f1 ff                                  	jmp    27140 <memcpy@plt>
  10b6bc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  10b6c0:	0f 18 3d d9 c9 f1 ff                            	prefetchit0 -0xe3627(%rip)        # 280a0 <_ZSt18_Rb_tree_incrementPKSt18_Rb_tree_node_base@plt>
  10b6c7:	e9 e4 ba f1 ff                                  	jmp    271b0 <_ZdlPvm@plt>
  10b6cc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  10b6d0:	41 53                                           	push   %r11
  10b6d2:	4c 8b 1d d7 de ff ff                            	mov    -0x2129(%rip),%r11        # 1095b0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  10b6d9:	41 0f 18 93 30 56 fe ff                         	prefetcht1 -0x1a9d0(%r11)
  10b6e1:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  10b6e9:	41 0f 18 93 44 00 00 00                         	prefetcht1 0x44(%r11)
  10b6f1:	41 0f 18 93 88 00 00 00                         	prefetcht1 0x88(%r11)
  10b6f9:	4c 8b 1d 00 e2 ff ff                            	mov    -0x1e00(%rip),%r11        # 109900 <_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l@GLIBCXX_3.4.9>
  10b700:	41 0f 18 93 b0 3e fe ff                         	prefetcht1 -0x1c150(%r11)
  10b708:	41 0f 18 93 40 46 fe ff                         	prefetcht1 -0x1b9c0(%r11)
  10b710:	41 0f 18 93 70 46 fe ff                         	prefetcht1 -0x1b990(%r11)
  10b718:	41 5b                                           	pop    %r11
  10b71a:	e9 41 c4 f1 ff                                  	jmp    27b60 <_ZN13jaegertracing11SpanContext10fromStreamERSi@plt>
  10b71f:	90                                              	nop
  10b720:	0f 18 3d 89 17 f4 ff                            	prefetchit0 -0xbe877(%rip)        # 4ceb0 <_ZN13jaegertracingeqERKNS_11SpanContextES2_>
  10b727:	0f 18 3d b2 d0 f3 ff                            	prefetchit0 -0xc2f4e(%rip)        # 487e0 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  10b72e:	e9 ad 1c f4 ff                                  	jmp    4d3e0 <_ZN13jaegertracing11SpanContext4swapERS0_>
  10b733:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  10b73d:	0f 1f 00                                        	nopl   (%rax)
  10b740:	0f 18 3d e9 ca f1 ff                            	prefetchit0 -0xe3517(%rip)        # 28230 <_ZNSt6localeD1Ev@plt>
  10b747:	41 53                                           	push   %r11
  10b749:	4c 8b 1d 88 d9 ff ff                            	mov    -0x2678(%rip),%r11        # 1090d8 <_ZdlPvm@CXXABI_1.3.9>
  10b750:	41 0f 18 93 90 37 ff ff                         	prefetcht1 -0xc870(%r11)
  10b758:	4c 8b 1d f9 de ff ff                            	mov    -0x2107(%rip),%r11        # 109658 <_ZNSt8ios_baseD2Ev@GLIBCXX_3.4>
  10b75f:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  10b767:	41 5b                                           	pop    %r11
  10b769:	e9 72 d0 f3 ff                                  	jmp    487e0 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  10b76e:	66 90                                           	xchg   %ax,%ax
  10b770:	0f 18 3d 19 5c f4 ff                            	prefetchit0 -0xba3e7(%rip)        # 51390 <_ZNSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES5_St4lessIS5_ESaISt4pairIKS5_S5_EEEixEOS5_>
  10b777:	e9 b4 c4 f1 ff                                  	jmp    27c30 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@plt>
  10b77c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  10b780:	0f 18 3d c9 cb f1 ff                            	prefetchit0 -0xe3437(%rip)        # 28350 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_@plt>
  10b787:	41 53                                           	push   %r11
  10b789:	4c 8b 1d 18 e2 ff ff                            	mov    -0x1de8(%rip),%r11        # 1099a8 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_@GLIBCXX_3.4>
  10b790:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  10b798:	41 0f 18 93 a8 02 00 00                         	prefetcht1 0x2a8(%r11)
  10b7a0:	41 5b                                           	pop    %r11
  10b7a2:	e9 a9 61 f4 ff                                  	jmp    51950 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE24_M_get_insert_unique_posERS7_>
  10b7a7:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  10b7b0:	0f 18 3d 89 c1 f5 ff                            	prefetchit0 -0xa3e77(%rip)        # 67940 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE17writeMessageBeginERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi+0x20>
  10b7b7:	0f 18 3d 62 c1 f5 ff                            	prefetchit0 -0xa3e9e(%rip)        # 67920 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE17writeMessageBeginERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  10b7be:	0f 18 3d 7b b6 f5 ff                            	prefetchit0 -0xa4985(%rip)        # 66e40 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE22writeMessageBegin_virtERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  10b7c5:	0f 18 3d 64 0b f6 ff                            	prefetchit0 -0x9f49c(%rip)        # 6c330 <_ZN13media_service29ReviewStorageServiceProcessor19process_StoreReviewEiPN6apache6thrift8protocol9TProtocolES5_Pv+0x330>
  10b7cc:	0f 18 3d ed 58 f6 ff                            	prefetchit0 -0x9a713(%rip)        # 710c0 <_ZN13media_service6ReviewD1Ev>
  10b7d3:	e9 d8 b9 f1 ff                                  	jmp    271b0 <_ZdlPvm@plt>
  10b7d8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  10b7e0:	0f 18 3d e9 be f5 ff                            	prefetchit0 -0xa4117(%rip)        # 676d0 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE12readI64_virtERl>
  10b7e7:	e9 b4 c0 f1 ff                                  	jmp    278a0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@plt>
  10b7ec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  10b7f0:	0f 18 3d a9 c0 f1 ff                            	prefetchit0 -0xe3f57(%rip)        # 278a0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@plt>
  10b7f7:	0f 18 3d ae 37 f6 ff                            	prefetchit0 -0x9c852(%rip)        # 6efac <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x4c>
  10b7fe:	0f 18 3d cb 01 f6 ff                            	prefetchit0 -0x9fe35(%rip)        # 6b9d0 <_ZN13media_service29ReviewStorageServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv>
  10b805:	0f 18 3d b4 cb f1 ff                            	prefetchit0 -0xe344c(%rip)        # 283c0 <memcmp@plt>
  10b80c:	41 53                                           	push   %r11
  10b80e:	4c 8b 1d 3b dc ff ff                            	mov    -0x23c5(%rip),%r11        # 109450 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@GLIBCXX_3.4.21>
  10b815:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
  10b81d:	41 5b                                           	pop    %r11
  10b81f:	e9 cc c5 f5 ff                                  	jmp    67df0 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE14readStringBodyINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEEjRT_i>
  10b824:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  10b82e:	66 90                                           	xchg   %ax,%ax
  10b830:	0f 18 3d 69 3f f6 ff                            	prefetchit0 -0x9c097(%rip)        # 6f7a0 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE22_M_emplace_hint_uniqueIJRKSt21piecewise_construct_tSt5tupleIJRS7_EESJ_IJEEEEESt17_Rb_tree_iteratorIS8_ESt23_Rb_tree_const_iteratorIS8_EDpOT_>
  10b837:	41 53                                           	push   %r11
  10b839:	4c 8b 1d 98 d8 ff ff                            	mov    -0x2768(%rip),%r11        # 1090d8 <_ZdlPvm@CXXABI_1.3.9>
  10b840:	41 0f 18 93 b0 53 ff ff                         	prefetcht1 -0xac50(%r11)
  10b848:	41 5b                                           	pop    %r11
  10b84a:	e9 51 c0 f1 ff                                  	jmp    278a0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@plt>
  10b84f:	90                                              	nop
  10b850:	0f 18 3d 19 5e f4 ff                            	prefetchit0 -0xba1e7(%rip)        # 51670 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_>
  10b857:	e9 44 3f f6 ff                                  	jmp    6f7a0 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE22_M_emplace_hint_uniqueIJRKSt21piecewise_construct_tSt5tupleIJRS7_EESJ_IJEEEEESt17_Rb_tree_iteratorIS8_ESt23_Rb_tree_const_iteratorIS8_EDpOT_>
  10b85c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  10b860:	0f 18 3d 69 ba f5 ff                            	prefetchit0 -0xa4597(%rip)        # 672d0 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE20readStructBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  10b867:	0f 18 3d 92 07 f6 ff                            	prefetchit0 -0x9f86e(%rip)        # 6c000 <_ZN13media_service29ReviewStorageServiceProcessor19process_StoreReviewEiPN6apache6thrift8protocol9TProtocolES5_Pv>
  10b86e:	0f 18 3d 7b ce f5 ff                            	prefetchit0 -0xa3185(%rip)        # 686f0 <_ZN13media_service37ReviewStorageService_StoreReview_args4readEPN6apache6thrift8protocol9TProtocolE>
  10b875:	e9 46 cb f1 ff                                  	jmp    283c0 <memcmp@plt>
  10b87a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  10b880:	41 53                                           	push   %r11
  10b882:	4c 8b 1d 07 d8 ff ff                            	mov    -0x27f9(%rip),%r11        # 109090 <_ZNSt9exceptionD2Ev@GLIBCXX_3.4>
  10b889:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  10b891:	41 5b                                           	pop    %r11
  10b893:	e9 78 a6 f6 ff                                  	jmp    75f10 <_ZN13media_service16ServiceExceptionD1Ev>
  10b898:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  10b8a0:	0f 18 3d 30 37 f6 ff                            	prefetchit0 -0x9c8d0(%rip)        # 6efd7 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x77>
  10b8a7:	0f 18 3d 37 06 f6 ff                            	prefetchit0 -0x9f9c9(%rip)        # 6bee5 <_ZN13media_service29ReviewStorageServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x515>
  10b8ae:	0f 18 3d ab 36 f6 ff                            	prefetchit0 -0x9c955(%rip)        # 6ef60 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv>
  10b8b5:	0f 18 3d 5a 02 f6 ff                            	prefetchit0 -0x9fda6(%rip)        # 6bb16 <_ZN13media_service29ReviewStorageServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x146>
  10b8bc:	e9 ff 57 f6 ff                                  	jmp    710c0 <_ZN13media_service6ReviewD1Ev>
