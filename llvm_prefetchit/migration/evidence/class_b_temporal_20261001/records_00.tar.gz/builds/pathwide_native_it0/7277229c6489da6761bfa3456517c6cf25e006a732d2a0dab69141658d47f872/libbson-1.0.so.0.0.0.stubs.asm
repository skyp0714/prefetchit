
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_native_it0/7277229c6489da6761bfa3456517c6cf25e006a732d2a0dab69141658d47f872/libbson-1.0.so.0.0.0:     file format elf64-x86-64


Disassembly of section .text.prefetch_calls:

00000000000422c0 <.text.prefetch_calls>:
   422c0:	0f 18 3d 3a 04 fd ff                            	prefetchit0 -0x2fbc6(%rip)        # 12701 <bson_append_document_end+0x31>
   422c7:	e9 a4 af fc ff                                  	jmp    d270 <bson_bcone_magic@plt>
   422cc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   422d0:	0f 18 3d c9 b9 fc ff                            	prefetchit0 -0x34637(%rip)        # dca0 <_bcon_append_tokenize+0x570>
   422d7:	0f 18 3d 63 10 fd ff                            	prefetchit0 -0x2ef9d(%rip)        # 13341 <bson_append_int64+0x31>
   422de:	0f 18 3d 2b 10 fd ff                            	prefetchit0 -0x2efd5(%rip)        # 13310 <bson_append_int64>
   422e5:	0f 18 3d 04 0f fd ff                            	prefetchit0 -0x2f0fc(%rip)        # 131f0 <bson_append_int32>
   422ec:	0f 18 3d 12 0f fd ff                            	prefetchit0 -0x2f0ee(%rip)        # 13205 <bson_append_int32+0x15>
   422f3:	e9 38 b4 fc ff                                  	jmp    d730 <_bcon_append_tokenize>
   422f8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   42300:	0f 18 3d 39 cd fc ff                            	prefetchit0 -0x332c7(%rip)        # f040 <bcon_append_ctx_va+0xb30>
   42307:	e9 a4 ad fc ff                                  	jmp    d0b0 <bson_append_document_end@plt>
   4230c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   42310:	0f 18 3d ed dd fc ff                            	prefetchit0 -0x32213(%rip)        # 10104 <_bson_grow+0x114>
   42317:	e9 f4 ad fc ff                                  	jmp    d110 <bson_append_document_begin@plt>
   4231c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   42320:	0f 18 3d e9 c1 fc ff                            	prefetchit0 -0x33e17(%rip)        # e510 <bcon_append_ctx_va>
   42327:	0f 18 3d 14 c2 fc ff                            	prefetchit0 -0x33dec(%rip)        # e542 <bcon_append_ctx_va+0x32>
   4232e:	e9 ad b1 fc ff                                  	jmp    d4e0 <bcon_append_ctx_init@plt>
   42333:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   4233d:	0f 1f 00                                        	nopl   (%rax)
   42340:	0f 18 3d d9 00 fd ff                            	prefetchit0 -0x2ff27(%rip)        # 12420 <bson_append_document_begin>
   42347:	0f 18 3d f2 00 fd ff                            	prefetchit0 -0x2ff0e(%rip)        # 12440 <bson_append_document_begin+0x20>
   4234e:	0f 18 3d 4b 02 fd ff                            	prefetchit0 -0x2fdb5(%rip)        # 125a0 <bson_append_document_begin+0x180>
   42355:	0f 18 3d 3c c6 fc ff                            	prefetchit0 -0x339c4(%rip)        # e998 <bcon_append_ctx_va+0x488>
   4235c:	e9 0f ac fc ff                                  	jmp    cf70 <bcon_append_ctx_va@plt>
   42361:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   4236b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
   42370:	0f 18 3d 89 06 fd ff                            	prefetchit0 -0x2f977(%rip)        # 12a00 <bson_append_bool>
   42377:	0f 18 3d c3 06 fd ff                            	prefetchit0 -0x2f93d(%rip)        # 12a41 <bson_append_bool+0x41>
   4237e:	0f 18 3d 9b a7 fc ff                            	prefetchit0 -0x35865(%rip)        # cb20 <bson_free@plt>
   42385:	e9 f6 ad fc ff                                  	jmp    d180 <memcpy@plt>
   4238a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   42390:	0f 18 3d 97 9e fd ff                            	prefetchit0 -0x26169(%rip)        # 1c22e <bson_iter_visit_all+0x76e>
   42397:	41 53                                           	push   %r11
   42399:	4c 8b 1d 28 8e ff ff                            	mov    -0x71d8(%rip),%r11        # 3b1c8 <strchr@GLIBC_2.2.5>
   423a0:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   423a8:	41 0f 18 93 22 00 00 00                         	prefetcht1 0x22(%r11)
   423b0:	41 5b                                           	pop    %r11
   423b2:	e9 09 ab fc ff                                  	jmp    cec0 <strchr@plt>
   423b7:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
   423c0:	0f 18 3d e1 f9 fc ff                            	prefetchit0 -0x3061f(%rip)        # 11da8 <_bson_append.constprop.2+0x248>
   423c7:	e9 24 dc fc ff                                  	jmp    fff0 <_bson_grow>
   423cc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   423d0:	0f 18 3d e9 0b fd ff                            	prefetchit0 -0x2f417(%rip)        # 12fc0 <bson_append_document>
   423d7:	0f 18 3d 63 06 fd ff                            	prefetchit0 -0x2f99d(%rip)        # 12a41 <bson_append_bool+0x41>
   423de:	0f 18 3d 1b 06 fd ff                            	prefetchit0 -0x2f9e5(%rip)        # 12a00 <bson_append_bool>
   423e5:	e9 96 ad fc ff                                  	jmp    d180 <memcpy@plt>
   423ea:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   423f0:	0f 18 3d 4b b4 fc ff                            	prefetchit0 -0x34bb5(%rip)        # d842 <_bcon_append_tokenize+0x112>
   423f7:	e9 84 ad fc ff                                  	jmp    d180 <memcpy@plt>
   423fc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   42400:	0f 18 3d 19 fe fd ff                            	prefetchit0 -0x201e7(%rip)        # 22220 <bson_uint32_to_string>
   42407:	0f 18 3d 32 fe fd ff                            	prefetchit0 -0x201ce(%rip)        # 22240 <bson_uint32_to_string+0x20>
   4240e:	e9 ad f9 fc ff                                  	jmp    11dc0 <_bson_append.constprop.1>
   42413:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   4241d:	0f 1f 00                                        	nopl   (%rax)
   42420:	0f 18 3d a9 fa fc ff                            	prefetchit0 -0x30557(%rip)        # 11ed0 <_bson_append.constprop.1+0x110>
   42427:	e9 94 f9 fc ff                                  	jmp    11dc0 <_bson_append.constprop.1>
   4242c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   42430:	0f 18 3d b9 db fc ff                            	prefetchit0 -0x32447(%rip)        # fff0 <_bson_grow>
   42437:	0f 18 3d c7 db fc ff                            	prefetchit0 -0x32439(%rip)        # 10005 <_bson_grow+0x15>
   4243e:	0f 18 3d cb 0e fd ff                            	prefetchit0 -0x2f135(%rip)        # 13310 <bson_append_int64>
   42445:	0f 18 3d 74 f9 fc ff                            	prefetchit0 -0x3068c(%rip)        # 11dc0 <_bson_append.constprop.1>
   4244c:	0f 18 3d 6d fe fd ff                            	prefetchit0 -0x20193(%rip)        # 222c0 <bson_malloc>
   42453:	0f 18 3d be fb fc ff                            	prefetchit0 -0x30442(%rip)        # 12018 <_bson_append.constprop.1+0x258>
   4245a:	0f 18 3d e0 0e fd ff                            	prefetchit0 -0x2f120(%rip)        # 13341 <bson_append_int64+0x31>
   42461:	e9 6a a7 fc ff                                  	jmp    cbd0 <bson_malloc@plt>
   42466:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   42470:	0f 18 3d e9 f6 fc ff                            	prefetchit0 -0x30917(%rip)        # 11b60 <_bson_append.constprop.2>
   42477:	0f 18 3d 03 f7 fc ff                            	prefetchit0 -0x308fd(%rip)        # 11b81 <_bson_append.constprop.2+0x21>
   4247e:	e9 0d b0 fc ff                                  	jmp    d490 <bson_init@plt>
   42483:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   4248d:	0f 1f 00                                        	nopl   (%rax)
   42490:	0f 18 3d 29 96 fd ff                            	prefetchit0 -0x269d7(%rip)        # 1bac0 <bson_iter_visit_all>
   42497:	0f 18 3d 12 77 fd ff                            	prefetchit0 -0x288ee(%rip)        # 19bb0 <_bson_iter_next_internal>
   4249e:	0f 18 3d 61 96 fd ff                            	prefetchit0 -0x2699f(%rip)        # 1bb06 <bson_iter_visit_all+0x46>
   424a5:	0f 18 3d 94 96 fd ff                            	prefetchit0 -0x2696c(%rip)        # 1bb40 <bson_iter_visit_all+0x80>
   424ac:	0f 18 3d 77 78 fd ff                            	prefetchit0 -0x28789(%rip)        # 19d2a <_bson_iter_next_internal+0x17a>
   424b3:	0f 18 3d 48 77 fd ff                            	prefetchit0 -0x288b8(%rip)        # 19c02 <_bson_iter_next_internal+0x52>
   424ba:	e9 e1 ad fc ff                                  	jmp    d2a0 <bson_iter_init@plt>
   424bf:	90                                              	nop
   424c0:	0f 18 3d c9 40 fe ff                            	prefetchit0 -0x1bf37(%rip)        # 26590 <bson_utf8_validate>
   424c7:	0f 18 3d 22 9e fd ff                            	prefetchit0 -0x261de(%rip)        # 1c2f0 <bson_iter_visit_all+0x830>
   424ce:	0f 18 3d ee 40 fe ff                            	prefetchit0 -0x1bf12(%rip)        # 265c3 <bson_utf8_validate+0x33>
   424d5:	0f 18 3d 64 a9 fc ff                            	prefetchit0 -0x3569c(%rip)        # ce40 <strlen@plt>
   424dc:	e9 bf ad fc ff                                  	jmp    d2a0 <bson_iter_init@plt>
   424e1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   424eb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
   424f0:	0f 18 3d 19 13 fd ff                            	prefetchit0 -0x2ece7(%rip)        # 13810 <bson_append_oid>
   424f7:	0f 18 3d 45 13 fd ff                            	prefetchit0 -0x2ecbb(%rip)        # 13843 <bson_append_oid+0x33>
   424fe:	e9 8d a8 fc ff                                  	jmp    cd90 <getpid@plt>
   42503:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   4250d:	0f 1f 00                                        	nopl   (%rax)
   42510:	0f 18 3d ab 54 fd ff                            	prefetchit0 -0x2ab55(%rip)        # 179c2 <_bson_context_set_oid_rand+0x12>
   42517:	41 53                                           	push   %r11
   42519:	4c 8b 1d 10 8c ff ff                            	mov    -0x73f0(%rip),%r11        # 3b130 <getpid@GLIBC_2.2.5>
   42520:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   42528:	41 5b                                           	pop    %r11
   4252a:	e9 91 b0 fc ff                                  	jmp    d5c0 <pthread_once@plt>
   4252f:	90                                              	nop
   42530:	0f 18 3d 59 92 fd ff                            	prefetchit0 -0x26da7(%rip)        # 1b790 <bson_iter_recurse>
   42537:	0f 18 3d 85 92 fd ff                            	prefetchit0 -0x26d7b(%rip)        # 1b7c3 <bson_iter_recurse+0x33>
   4253e:	41 53                                           	push   %r11
   42540:	4c 8b 1d 49 8b ff ff                            	mov    -0x74b7(%rip),%r11        # 3b090 <strncpy@GLIBC_2.2.5>
   42547:	41 0f 18 93 12 ff ff ff                         	prefetcht1 -0xee(%r11)
   4254f:	4c 8b 1d 42 8b ff ff                            	mov    -0x74be(%rip),%r11        # 3b098 <strncmp@GLIBC_2.2.5>
   42556:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   4255e:	41 0f 18 93 46 00 00 00                         	prefetcht1 0x46(%r11)
   42566:	41 5b                                           	pop    %r11
   42568:	e9 d3 a8 fc ff                                  	jmp    ce40 <strlen@plt>
   4256d:	0f 1f 00                                        	nopl   (%rax)
   42570:	41 53                                           	push   %r11
   42572:	4c 8b 1d 17 8b ff ff                            	mov    -0x74e9(%rip),%r11        # 3b090 <strncpy@GLIBC_2.2.5>
   42579:	41 0f 18 93 b0 fe ff ff                         	prefetcht1 -0x150(%r11)
   42581:	41 5b                                           	pop    %r11
   42583:	e9 d8 a8 fc ff                                  	jmp    ce60 <bson_iter_key@plt>
   42588:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   42590:	0f 18 3d 8b 77 fd ff                            	prefetchit0 -0x28875(%rip)        # 19d22 <_bson_iter_next_internal+0x172>
   42597:	0f 18 3d 22 85 fd ff                            	prefetchit0 -0x27ade(%rip)        # 1aac0 <bson_iter_as_bool>
   4259e:	0f 18 3d 7b a5 fc ff                            	prefetchit0 -0x35a85(%rip)        # cb20 <bson_free@plt>
   425a5:	41 53                                           	push   %r11
   425a7:	4c 8b 1d e2 8a ff ff                            	mov    -0x751e(%rip),%r11        # 3b090 <strncpy@GLIBC_2.2.5>
   425ae:	41 0f 18 93 82 fe ff ff                         	prefetcht1 -0x17e(%r11)
   425b6:	41 0f 18 93 f0 fe ff ff                         	prefetcht1 -0x110(%r11)
   425be:	41 0f 18 93 12 ff ff ff                         	prefetcht1 -0xee(%r11)
   425c6:	41 5b                                           	pop    %r11
   425c8:	e9 93 a6 fc ff                                  	jmp    cc60 <strncmp@plt>
   425cd:	0f 1f 00                                        	nopl   (%rax)
   425d0:	0f 18 3d e9 7c fd ff                            	prefetchit0 -0x28317(%rip)        # 1a2c0 <bson_iter_next>
   425d7:	e9 c4 ac fc ff                                  	jmp    d2a0 <bson_iter_init@plt>
   425dc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   425e0:	0f 18 3d e9 23 fe ff                            	prefetchit0 -0x1dc17(%rip)        # 249d0 <bson_strcasecmp>
   425e7:	e9 b4 ac fc ff                                  	jmp    d2a0 <bson_iter_init@plt>
   425ec:	0f 1f 40 00                                     	nopl   0x0(%rax)
   425f0:	0f 18 3d 49 83 fd ff                            	prefetchit0 -0x27cb7(%rip)        # 1a940 <bson_iter_double>
   425f7:	e9 a4 aa fc ff                                  	jmp    d0a0 <bson_iter_double@plt>
   425fc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   42600:	0f 18 3d 89 86 fd ff                            	prefetchit0 -0x27977(%rip)        # 1ac90 <bson_iter_as_int64>
   42607:	e9 74 af fc ff                                  	jmp    d580 <bson_iter_array@plt>
   4260c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   42610:	0f 18 3d 99 8f fd ff                            	prefetchit0 -0x27067(%rip)        # 1b5b0 <bson_iter_document>
   42617:	e9 04 ab fc ff                                  	jmp    d120 <bson_iter_document@plt>
   4261c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   42620:	0f 18 3d 29 ec fc ff                            	prefetchit0 -0x313d7(%rip)        # 11250 <_bson_iter_validate_utf8>
   42627:	0f 18 3d b2 88 fd ff                            	prefetchit0 -0x2774e(%rip)        # 1aee0 <bson_iter_utf8>
   4262e:	e9 ad a6 fc ff                                  	jmp    cce0 <bson_iter_utf8@plt>
   42633:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   4263d:	0f 1f 00                                        	nopl   (%rax)
   42640:	0f 18 3d 0e 42 fe ff                            	prefetchit0 -0x1bdf2(%rip)        # 26855 <bson_utf8_validate+0x2c5>
   42647:	e9 f4 a7 fc ff                                  	jmp    ce40 <strlen@plt>
   4264c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   42650:	0f 18 3d a9 e7 fc ff                            	prefetchit0 -0x31857(%rip)        # 10e00 <_bson_iter_validate_before>
   42657:	e9 24 ae fc ff                                  	jmp    d480 <bson_utf8_validate@plt>
   4265c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   42660:	0f 18 3d c9 54 fd ff                            	prefetchit0 -0x2ab37(%rip)        # 17b30 <bson_context_get_default>
   42667:	0f 18 3d 42 53 fd ff                            	prefetchit0 -0x2acbe(%rip)        # 179b0 <_bson_context_set_oid_rand>
   4266e:	e9 9d ab fc ff                                  	jmp    d210 <time@plt>
   42673:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   4267d:	0f 1f 00                                        	nopl   (%rax)
   42680:	0f 18 3d 99 3f fd ff                            	prefetchit0 -0x2c067(%rip)        # 16620 <bson_count_keys>
   42687:	0f 18 3d b3 3f fd ff                            	prefetchit0 -0x2c04d(%rip)        # 16641 <bson_count_keys+0x21>
   4268e:	41 53                                           	push   %r11
   42690:	4c 8b 1d b1 8e ff ff                            	mov    -0x714f(%rip),%r11        # 3b548 <pthread_once@GLIBC_2.34>
   42697:	41 0f 18 93 83 c5 00 00                         	prefetcht1 0xc583(%r11)
   4269f:	41 0f 18 93 04 c6 00 00                         	prefetcht1 0xc604(%r11)
   426a7:	41 5b                                           	pop    %r11
   426a9:	e9 22 af fc ff                                  	jmp    d5d0 <bson_malloc0@plt>
   426ae:	66 90                                           	xchg   %ax,%ax
   426b0:	0f 18 3d 49 7e fd ff                            	prefetchit0 -0x281b7(%rip)        # 1a500 <bson_iter_init_find+0x10>
   426b7:	0f 18 3d 52 7c fd ff                            	prefetchit0 -0x283ae(%rip)        # 1a310 <bson_iter_find_w_len>
   426be:	0f 18 3d 0b 2a fd ff                            	prefetchit0 -0x2d5f5(%rip)        # 150d0 <bson_get_data>
   426c5:	0f 18 3d 94 7d fd ff                            	prefetchit0 -0x2826c(%rip)        # 1a460 <bson_iter_find>
   426cc:	0f 18 3d cd 78 fd ff                            	prefetchit0 -0x28733(%rip)        # 19fa0 <bson_iter_init>
   426d3:	0f 18 3d 16 7e fd ff                            	prefetchit0 -0x281ea(%rip)        # 1a4f0 <bson_iter_init_find>
   426da:	0f 18 3d cf a8 fc ff                            	prefetchit0 -0x35731(%rip)        # cfb0 <bson_iter_find_w_len@plt>
   426e1:	0f 18 3d da 78 fd ff                            	prefetchit0 -0x28726(%rip)        # 19fc2 <bson_iter_init+0x22>
   426e8:	e9 63 a5 fc ff                                  	jmp    cc50 <strncpy@plt>
   426ed:	0f 1f 00                                        	nopl   (%rax)
   426f0:	41 53                                           	push   %r11
   426f2:	4c 8b 1d 2f 8d ff ff                            	mov    -0x72d1(%rip),%r11        # 3b428 <__vsnprintf_chk@GLIBC_2.3.4>
   426f9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   42701:	4c 8b 1d 40 8e ff ff                            	mov    -0x71c0(%rip),%r11        # 3b548 <pthread_once@GLIBC_2.34>
   42708:	41 0f 18 93 85 e4 fe ff                         	prefetcht1 -0x11b7b(%r11)
   42710:	41 5b                                           	pop    %r11
   42712:	e9 69 ac fc ff                                  	jmp    d380 <__vsnprintf_chk@plt>
   42717:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
   42720:	41 53                                           	push   %r11
   42722:	4c 8b 1d ff 8c ff ff                            	mov    -0x7301(%rip),%r11        # 3b428 <__vsnprintf_chk@GLIBC_2.3.4>
   42729:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   42731:	41 5b                                           	pop    %r11
   42733:	e9 98 ae fc ff                                  	jmp    d5d0 <bson_malloc0@plt>
   42738:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   42740:	41 53                                           	push   %r11
   42742:	4c 8b 1d ff 8d ff ff                            	mov    -0x7201(%rip),%r11        # 3b548 <pthread_once@GLIBC_2.34>
   42749:	41 0f 18 93 60 bf fd ff                         	prefetcht1 -0x240a0(%r11)
   42751:	41 0f 18 93 e8 ca fd ff                         	prefetcht1 -0x23518(%r11)
   42759:	41 0f 18 93 f7 cd fd ff                         	prefetcht1 -0x23209(%r11)
   42761:	41 0f 18 93 00 ce fd ff                         	prefetcht1 -0x23200(%r11)
   42769:	41 0f 18 93 30 e4 fe ff                         	prefetcht1 -0x11bd0(%r11)
   42771:	41 0f 18 93 40 e4 fe ff                         	prefetcht1 -0x11bc0(%r11)
   42779:	41 0f 18 93 42 46 ff ff                         	prefetcht1 -0xb9be(%r11)
   42781:	41 0f 18 93 90 46 ff ff                         	prefetcht1 -0xb970(%r11)
   42789:	41 5b                                           	pop    %r11
   4278b:	e9 90 ab fc ff                                  	jmp    d320 <bson_vsnprintf@plt>
   42790:	41 53                                           	push   %r11
   42792:	4c 8b 1d af 8d ff ff                            	mov    -0x7251(%rip),%r11        # 3b548 <pthread_once@GLIBC_2.34>
   42799:	41 0f 18 93 85 e4 fe ff                         	prefetcht1 -0x11b7b(%r11)
   427a1:	41 0f 18 93 42 46 ff ff                         	prefetcht1 -0xb9be(%r11)
   427a9:	41 5b                                           	pop    %r11
   427ab:	e9 70 ab fc ff                                  	jmp    d320 <bson_vsnprintf@plt>
