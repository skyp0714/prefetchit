
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_native_it0/d2314e24f46b0fa6b2487f55dad565070adb9b6a920cd0a5f64c7e6d767ac3e3/RatingService:     file format elf64-x86-64


Disassembly of section .text.prefetch_calls:

0000000000377380 <.text.prefetch_calls>:
  377380:	0f 18 3d 59 01 d9 ff                            	prefetchit0 -0x26fea7(%rip)        # 1074e0 <_ZNK13jaegertracing6Tracer7ExtractERKN11opentracing2v213TextMapReaderE>
  377387:	0f 18 3d f2 39 cf ff                            	prefetchit0 -0x30c60e(%rip)        # 6ad80 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0xf0>
  37738e:	0f 18 3d fb 38 cf ff                            	prefetchit0 -0x30c705(%rip)        # 6ac90 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_>
  377395:	0f 18 3d 67 39 cf ff                            	prefetchit0 -0x30c699(%rip)        # 6ad03 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0x73>
  37739c:	0f 18 3d a8 39 cf ff                            	prefetchit0 -0x30c658(%rip)        # 6ad4b <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0xbb>
  3773a3:	e9 68 3a dd ff                                  	jmp    14ae10 <_ZN11opentracing2v26Tracer6GlobalEv>
  3773a8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3773b0:	0f 18 3d 99 e5 d8 ff                            	prefetchit0 -0x271a67(%rip)        # 105950 <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE>
  3773b7:	0f 18 3d c2 e5 d8 ff                            	prefetchit0 -0x271a3e(%rip)        # 105980 <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE+0x30>
  3773be:	e9 5d 15 ce ff                                  	jmp    58920 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  3773c3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3773cd:	0f 1f 00                                        	nopl   (%rax)
  3773d0:	0f 18 3d 79 9c ee ff                            	prefetchit0 -0x116387(%rip)        # 261050 <_ZNSt7__cxx1119basic_ostringstreamIcSt11char_traitsIcESaIcEEC1Ev>
  3773d7:	0f 18 3d 52 fd d8 ff                            	prefetchit0 -0x2702ae(%rip)        # 107130 <_ZNK13jaegertracing6Tracer6InjectERKN11opentracing2v211SpanContextERKNS2_13TextMapWriterE>
  3773de:	e9 2d 3a dd ff                                  	jmp    14ae10 <_ZN11opentracing2v26Tracer6GlobalEv>
  3773e3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3773ed:	0f 1f 00                                        	nopl   (%rax)
  3773f0:	0f 18 3d 29 14 ec ff                            	prefetchit0 -0x13ebd7(%rip)        # 238820 <_ZNSt13__future_base12_Result_baseC1Ev>
  3773f7:	e9 74 2d e7 ff                                  	jmp    1ea170 <_Znwm>
  3773fc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377400:	0f 18 3d 39 48 ef ff                            	prefetchit0 -0x10b7c7(%rip)        # 26bc40 <_ZNSt6thread15_M_start_threadESt10unique_ptrINS_6_StateESt14default_deleteIS1_EEPFvvE>
  377407:	41 53                                           	push   %r11
  377409:	4c 8b 1d 30 8c ff ff                            	mov    -0x73d0(%rip),%r11        # 370040 <pthread_join@GLIBC_2.34>
  377410:	41 0f 18 93 10 f4 ff ff                         	prefetcht1 -0xbf0(%r11)
  377418:	41 0f 18 93 c0 f8 ff ff                         	prefetcht1 -0x740(%r11)
  377420:	41 0f 18 93 d3 f8 ff ff                         	prefetcht1 -0x72d(%r11)
  377428:	4c 8b 1d e1 91 ff ff                            	mov    -0x6e1f(%rip),%r11        # 370610 <pthread_cond_broadcast@GLIBC_2.3.2>
  37742f:	41 0f 18 93 00 f2 ff ff                         	prefetcht1 -0xe00(%r11)
  377437:	41 5b                                           	pop    %r11
  377439:	e9 32 2d e7 ff                                  	jmp    1ea170 <_Znwm>
  37743e:	66 90                                           	xchg   %ax,%ax
  377440:	0f 18 3d 79 ba d0 ff                            	prefetchit0 -0x2f4587(%rip)        # 82ec0 <_ZNSt13__future_base21_Async_state_commonV217_M_complete_asyncEv>
  377447:	0f 18 3d 92 47 ef ff                            	prefetchit0 -0x10b86e(%rip)        # 26bbe0 <_ZNSt6thread4joinEv>
  37744e:	e9 dd 9b cf ff                                  	jmp    71030 <_ZNKSt14__basic_futureIvE13_M_get_resultEv>
  377453:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37745d:	0f 1f 00                                        	nopl   (%rax)
  377460:	0f 18 3d 89 ef cb ff                            	prefetchit0 -0x341077(%rip)        # 363f0 <pthread_once@plt>
  377467:	e9 c4 9b cf ff                                  	jmp    71030 <_ZNKSt14__basic_futureIvE13_M_get_resultEv>
  37746c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377470:	0f 18 3d 79 35 dc ff                            	prefetchit0 -0x23ca87(%rip)        # 13a9f0 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE>
  377477:	0f 18 3d 84 35 dc ff                            	prefetchit0 -0x23ca7c(%rip)        # 13aa02 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE+0x12>
  37747e:	0f 18 3d 6b 56 dc ff                            	prefetchit0 -0x23a995(%rip)        # 13caf0 <_ZNSt11__copy_moveILb0ELb0ESt26random_access_iterator_tagE8__copy_mIPKN11opentracing2v29LogRecordESt20back_insert_iteratorISt6vectorIN13jaegertracing9LogRecordESaISB_EEEEET0_T_SG_SF_>
  377485:	0f 18 3d 04 f7 cb ff                            	prefetchit0 -0x3408fc(%rip)        # 36b90 <pthread_mutex_lock@plt>
  37748c:	e9 0f d7 e7 ff                                  	jmp    1f4ba0 <_ZNSt6chrono3_V212steady_clock3nowEv>
  377491:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37749b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3774a0:	0f 18 3d e9 da d0 ff                            	prefetchit0 -0x2f2517(%rip)        # 84f90 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE22writeMessageBegin_virtERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  3774a7:	0f 18 3d c2 e5 d0 ff                            	prefetchit0 -0x2f1a3e(%rip)        # 85a70 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE17writeMessageBeginERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  3774ae:	0f 18 3d f3 4a d1 ff                            	prefetchit0 -0x2eb50d(%rip)        # 8bfa8 <_ZN13media_service22RatingServiceProcessor20process_UploadRatingEiPN6apache6thrift8protocol9TProtocolES5_Pv+0x2c8>
  3774b5:	0f 18 3d c4 91 d3 ff                            	prefetchit0 -0x2c6e3c(%rip)        # b0680 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE10write_virtEPKhj>
  3774bc:	e9 0f 9e cf ff                                  	jmp    712d0 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  3774c1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3774cb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3774d0:	0f 18 3d 19 ef cb ff                            	prefetchit0 -0x3410e7(%rip)        # 363f0 <pthread_once@plt>
  3774d7:	e9 f4 bb d0 ff                                  	jmp    830d0 <_ZNSt13__future_base13_State_baseV213_M_set_resultESt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEb>
  3774dc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3774e0:	0f 18 3d 69 c2 d1 ff                            	prefetchit0 -0x2e3d97(%rip)        # 93750 <_ZN13media_service26ComposeReviewServiceClient12UploadRatingEliRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES7_St4lessIS7_ESaISt4pairIKS7_S7_EEE>
  3774e7:	0f 18 3d 82 e5 d0 ff                            	prefetchit0 -0x2f1a7e(%rip)        # 85a70 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE17writeMessageBeginERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  3774ee:	0f 18 3d 5b 2e d3 ff                            	prefetchit0 -0x2cd1a5(%rip)        # aa350 <_ZN6apache6thrift9transport7TSocket6isOpenEv>
  3774f5:	0f 18 3d 64 d7 d0 ff                            	prefetchit0 -0x2f289c(%rip)        # 84c60 <_ZN13media_service12ThriftClientINS_26ComposeReviewServiceClientEE7ConnectEv>
  3774fc:	0f 18 3d 8d 90 d3 ff                            	prefetchit0 -0x2c6f73(%rip)        # b0590 <_ZN6apache6thrift9transport16TFramedTransport6isOpenEv>
  377503:	0f 18 3d 86 da d0 ff                            	prefetchit0 -0x2f257a(%rip)        # 84f90 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE22writeMessageBegin_virtERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  37750a:	0f 18 3d 6f f7 cb ff                            	prefetchit0 -0x340891(%rip)        # 36c80 <pthread_mutex_unlock@plt>
  377511:	e9 6a be d0 ff                                  	jmp    83380 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_26ComposeReviewServiceClientEEEE3PopEv>
  377516:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377520:	0f 18 3d c9 d7 d0 ff                            	prefetchit0 -0x2f2837(%rip)        # 84cf0 <_ZN13media_service12ThriftClientINS_26ComposeReviewServiceClientEE9KeepAliveEv>
  377527:	0f 18 3d f6 ef cd ff                            	prefetchit0 -0x32100a(%rip)        # 56524 <_ZNSt13__future_base17_Async_state_implINSt6thread8_InvokerISt5tupleIJZN13media_service13RatingHandler12UploadRatingElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapISB_SB_St4lessISB_ESaISt4pairISC_SB_EEEE3$_0EEEEvE6_M_runEv+0x44>
  37752e:	0f 18 3d 32 bc d0 ff                            	prefetchit0 -0x2f43ce(%rip)        # 83167 <_ZNSt13__future_base13_State_baseV213_M_set_resultESt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEb+0x97>
  377535:	0f 18 3d 44 bc d0 ff                            	prefetchit0 -0x2f43bc(%rip)        # 83180 <_ZNSt13__future_base13_State_baseV213_M_set_resultESt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEb+0xb0>
  37753c:	0f 18 3d cd f4 cd ff                            	prefetchit0 -0x320b33(%rip)        # 56a10 <_ZNSt17_Function_handlerIFSt10unique_ptrINSt13__future_base12_Result_baseENS2_8_DeleterEEvENS1_12_Task_setterIS0_INS1_7_ResultIvEES3_ENSt6thread8_InvokerISt5tupleIJZN13media_service13RatingHandler12UploadRatingElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapISK_SK_St4lessISK_ESaISt4pairISL_SK_EEEE3$_0EEEEvEEE10_M_managerERSt9_Any_dataRKS11_St18_Manager_operation>
  377543:	e9 98 c9 d0 ff                                  	jmp    83ee0 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_26ComposeReviewServiceClientEEEE4PushEPS3_>
  377548:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  377550:	41 53                                           	push   %r11
  377552:	4c 8b 1d 37 8c ff ff                            	mov    -0x73c9(%rip),%r11        # 370190 <malloc@GLIBC_2.2.5>
  377559:	41 0f 18 93 22 c0 ff ff                         	prefetcht1 -0x3fde(%r11)
  377561:	41 5b                                           	pop    %r11
  377563:	e9 48 46 ef ff                                  	jmp    26bbb0 <_ZNSt6thread6_StateD1Ev>
  377568:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  377570:	0f 18 3d f9 c7 cd ff                            	prefetchit0 -0x323807(%rip)        # 53d70 <_ZN13media_service11RedisClient7ConnectEv>
  377577:	0f 18 3d 22 e6 e4 ff                            	prefetchit0 -0x1b19de(%rip)        # 1c5ba0 <_ZNK9cpp_redis7network16redis_connection12is_connectedEv>
  37757e:	0f 18 3d 7b f9 d0 ff                            	prefetchit0 -0x2f0685(%rip)        # 86f00 <_ZN13media_service10ClientPoolINS_11RedisClientEE3PopEv>
  377585:	0f 18 3d 58 01 d1 ff                            	prefetchit0 -0x2efea8(%rip)        # 876e4 <_ZN13media_service10ClientPoolINS_11RedisClientEE3PopEv+0x7e4>
  37758c:	0f 18 3d 9d 02 e5 ff                            	prefetchit0 -0x1afd63(%rip)        # 1c7830 <_ZNK9cpp_redis7network10tcp_client12is_connectedEv>
  377593:	e9 38 bb d0 ff                                  	jmp    830d0 <_ZNSt13__future_base13_State_baseV213_M_set_resultESt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEb>
  377598:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3775a0:	0f 18 3d d9 49 dc ff                            	prefetchit0 -0x23b627(%rip)        # 13bf80 <_ZNK13jaegertracing4Span7contextEv>
  3775a7:	0f 18 3d 59 04 d1 ff                            	prefetchit0 -0x2efba7(%rip)        # 87a07 <_ZN13media_service10ClientPoolINS_11RedisClientEE3PopEv+0xb07>
  3775ae:	e9 4d f9 d0 ff                                  	jmp    86f00 <_ZN13media_service10ClientPoolINS_11RedisClientEE3PopEv>
  3775b3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3775bd:	0f 1f 00                                        	nopl   (%rax)
  3775c0:	0f 18 3d c9 98 cf ff                            	prefetchit0 -0x306737(%rip)        # 70e90 <_ZNK11opentracing2v213SpanReference5ApplyERNS0_16StartSpanOptionsE>
  3775c7:	0f 18 3d 52 13 ce ff                            	prefetchit0 -0x31ecae(%rip)        # 58920 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  3775ce:	0f 18 3d 9b 2b e7 ff                            	prefetchit0 -0x18d465(%rip)        # 1ea170 <_Znwm>
  3775d5:	0f 18 3d 44 ed cb ff                            	prefetchit0 -0x3412bc(%rip)        # 36320 <malloc@plt>
  3775dc:	41 53                                           	push   %r11
  3775de:	4c 8b 1d ab 8b ff ff                            	mov    -0x7455(%rip),%r11        # 370190 <malloc@GLIBC_2.2.5>
  3775e5:	41 0f 18 93 f0 bf ff ff                         	prefetcht1 -0x4010(%r11)
  3775ed:	41 0f 18 93 22 c0 ff ff                         	prefetcht1 -0x3fde(%r11)
  3775f5:	41 5b                                           	pop    %r11
  3775f7:	e9 14 38 dd ff                                  	jmp    14ae10 <_ZN11opentracing2v26Tracer6GlobalEv>
  3775fc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377600:	0f 18 3d 59 14 ef ff                            	prefetchit0 -0x10eba7(%rip)        # 268a60 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm>
  377607:	e9 94 f6 cb ff                                  	jmp    36ca0 <memcpy@plt>
  37760c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377610:	0f 18 3d 19 b0 de ff                            	prefetchit0 -0x214fe7(%rip)        # 162630 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.constprop.0>
  377617:	e9 94 19 e2 ff                                  	jmp    198fb0 <_ZN9cpp_redis6client6incrbyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEi>
  37761c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377620:	0f 18 3d b9 7b df ff                            	prefetchit0 -0x208447(%rip)        # 16f1e0 <_ZNK9cpp_redis6client15is_reconnectingEv>
  377627:	0f 18 3d c2 13 e4 ff                            	prefetchit0 -0x1bec3e(%rip)        # 1b89f0 <_ZN9cpp_redis6client10try_commitEv>
  37762e:	e9 ad 0f e7 ff                                  	jmp    1e85e0 <_ZdlPvm>
  377633:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37763d:	0f 1f 00                                        	nopl   (%rax)
  377640:	0f 18 3d 49 42 dc ff                            	prefetchit0 -0x23bdb7(%rip)        # 13b890 <_ZN13jaegertracing4SpanD0Ev>
  377647:	0f 18 3d 92 04 d1 ff                            	prefetchit0 -0x2efb6e(%rip)        # 87ae0 <_ZN13media_service10ClientPoolINS_11RedisClientEE4PushEPS1_>
  37764e:	e9 ad 9b cf ff                                  	jmp    71200 <_ZNSt6vectorIN11opentracing2v29LogRecordESaIS2_EED2Ev>
  377653:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37765d:	0f 1f 00                                        	nopl   (%rax)
  377660:	41 53                                           	push   %r11
  377662:	4c 8b 1d ff 8b ff ff                            	mov    -0x7401(%rip),%r11        # 370268 <isupper@GLIBC_2.2.5>
  377669:	41 0f 18 93 10 bd 00 00                         	prefetcht1 0xbd10(%r11)
  377671:	41 5b                                           	pop    %r11
  377673:	e9 38 45 ef ff                                  	jmp    26bbb0 <_ZNSt6thread6_StateD1Ev>
  377678:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  377680:	0f 18 3d 89 8d cf ff                            	prefetchit0 -0x307277(%rip)        # 70410 <_ZNK13media_service13TextMapReader10ForeachKeyESt8functionIFN11opentracing2v28expectedIvSt10error_codeEENS3_11string_viewES7_EE>
  377687:	0f 18 3d 72 40 cf ff                            	prefetchit0 -0x30bf8e(%rip)        # 6b700 <_ZNSt17_Function_handlerIFN11opentracing2v28expectedIvSt10error_codeEENS1_11string_viewES5_EZNK13jaegertracing11propagation10PropagatorIRKNS1_13TextMapReaderERKNS1_13TextMapWriterEE7extractESC_EUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESO_E_E9_M_invokeERKSt9_Any_dataOS5_SU_>
  37768e:	0f 18 3d ad 8d cf ff                            	prefetchit0 -0x307253(%rip)        # 70442 <_ZNK13media_service13TextMapReader10ForeachKeyESt8functionIFN11opentracing2v28expectedIvSt10error_codeEENS3_11string_viewES7_EE+0x32>
  377695:	0f 18 3d e6 8d cf ff                            	prefetchit0 -0x30721a(%rip)        # 70482 <_ZNK13media_service13TextMapReader10ForeachKeyESt8functionIFN11opentracing2v28expectedIvSt10error_codeEENS3_11string_viewES7_EE+0x72>
  37769c:	e9 cf 2a e7 ff                                  	jmp    1ea170 <_Znwm>
  3776a1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3776ab:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3776b0:	0f 18 3d 4d 14 ee ff                            	prefetchit0 -0x11ebb3(%rip)        # 258b04 <_ZNSo9_M_insertImEERSoT_+0x24>
  3776b7:	0f 18 3d 22 14 ee ff                            	prefetchit0 -0x11ebde(%rip)        # 258ae0 <_ZNSo9_M_insertImEERSoT_>
  3776be:	0f 18 3d ab 2a ed ff                            	prefetchit0 -0x12d555(%rip)        # 24a170 <_ZNKSt11__use_cacheISt16__numpunct_cacheIcEEclERKSt6locale>
  3776c5:	0f 18 3d b5 2a ed ff                            	prefetchit0 -0x12d54b(%rip)        # 24a181 <_ZNKSt11__use_cacheISt16__numpunct_cacheIcEEclERKSt6locale+0x11>
  3776cc:	0f 18 3d 1d 29 ed ff                            	prefetchit0 -0x12d6e3(%rip)        # 249ff0 <_ZSt13__int_to_charIcmEiPT_T0_PKS0_St13_Ios_Fmtflagsb>
  3776d3:	0f 18 3d 66 03 ee ff                            	prefetchit0 -0x11fc9a(%rip)        # 257a40 <_ZNSo6sentryC1ERSo>
  3776da:	0f 18 3d 0f 32 ed ff                            	prefetchit0 -0x12cdf1(%rip)        # 24a8f0 <_ZNKSt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEE6do_putES3_RSt8ios_basecm>
  3776e1:	0f 18 3d 42 59 cf ff                            	prefetchit0 -0x30a6be(%rip)        # 6d02a <_ZNK13jaegertracing7TraceID5printISoEEvRT_+0xaa>
  3776e8:	e9 c3 57 cf ff                                  	jmp    6ceb0 <_ZNK13jaegertracing11SpanContext5printISoEEvRT_>
  3776ed:	0f 1f 00                                        	nopl   (%rax)
  3776f0:	0f 18 3d e9 7a e7 ff                            	prefetchit0 -0x188517(%rip)        # 1ef1e0 <_ZNSt6localeC1Ev>
  3776f7:	0f 18 3d 43 2d ec ff                            	prefetchit0 -0x13d2bd(%rip)        # 23a441 <_ZNSt8ios_baseC1Ev+0x41>
  3776fe:	0f 18 3d fb 2c ec ff                            	prefetchit0 -0x13d305(%rip)        # 23a400 <_ZNSt8ios_baseC1Ev>
  377705:	0f 18 3d 14 90 ee ff                            	prefetchit0 -0x116fec(%rip)        # 260720 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode>
  37770c:	0f 18 3d 8d 7a e7 ff                            	prefetchit0 -0x188573(%rip)        # 1ef1a0 <_ZNSt6locale13_S_initializeEv>
  377713:	0f 18 3d 28 90 ee ff                            	prefetchit0 -0x116fd8(%rip)        # 260742 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode+0x22>
  37771a:	e9 d1 0e ef ff                                  	jmp    2685f0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm>
  37771f:	90                                              	nop
  377720:	0f 18 3d 19 21 ec ff                            	prefetchit0 -0x13dee7(%rip)        # 239840 <_ZNSt9basic_iosIcSt11char_traitsIcEE4initEPSt15basic_streambufIcS1_E>
  377727:	0f 18 3d 72 df f0 ff                            	prefetchit0 -0xf208e(%rip)        # 2856a0 <_ZNSt8ios_base7_M_initEv>
  37772e:	0f 18 3d 90 df f0 ff                            	prefetchit0 -0xf2070(%rip)        # 2856c5 <_ZNSt8ios_base7_M_initEv+0x25>
  377735:	e9 66 f5 cb ff                                  	jmp    36ca0 <memcpy@plt>
  37773a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  377740:	0f 18 3d 09 2f ef ff                            	prefetchit0 -0x10d0f7(%rip)        # 26a650 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_>
  377747:	0f 18 3d f3 4f cf ff                            	prefetchit0 -0x30b00d(%rip)        # 6c741 <_ZN13jaegertracing11SpanContext4swapERS0_+0x11>
  37774e:	0f 18 3d 2c 50 cf ff                            	prefetchit0 -0x30afd4(%rip)        # 6c781 <_ZN13jaegertracing11SpanContext4swapERS0_+0x51>
  377755:	0f 18 3d d4 4f cf ff                            	prefetchit0 -0x30b02c(%rip)        # 6c730 <_ZN13jaegertracing11SpanContext4swapERS0_>
  37775c:	e9 2f 55 cf ff                                  	jmp    6cc90 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_>
  377761:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37776b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  377770:	0f 18 3d f9 3b cf ff                            	prefetchit0 -0x30c407(%rip)        # 6b370 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE12normalizeKeyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  377777:	0f 18 3d 02 3c cf ff                            	prefetchit0 -0x30c3fe(%rip)        # 6b380 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE12normalizeKeyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE+0x10>
  37777e:	e9 2d 40 cf ff                                  	jmp    6b7b0 <_ZSt13__invoke_implIN11opentracing2v28expectedIvSt10error_codeEERZNK13jaegertracing11propagation10PropagatorIRKNS1_13TextMapReaderERKNS1_13TextMapWriterEE7extractESA_EUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESM_E_JNS1_11string_viewESP_EET_St14__invoke_otherOT0_DpOT1_>
  377783:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37778d:	0f 1f 00                                        	nopl   (%rax)
  377790:	0f 18 3d 59 3b cf ff                            	prefetchit0 -0x30c4a7(%rip)        # 6b2f0 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE11decodeValueERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  377797:	e9 54 0e ef ff                                  	jmp    2685f0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm>
  37779c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3777a0:	0f 18 3d a9 d2 d8 ff                            	prefetchit0 -0x272d57(%rip)        # 104a50 <_ZN13jaegertracing7TraceID10fromStreamERSi>
  3777a7:	0f 18 3d 52 ce d8 ff                            	prefetchit0 -0x2731ae(%rip)        # 104600 <_ZN13jaegertracing5utils10HexParsing11readSegmentB5cxx11ERSimc>
  3777ae:	0f 18 3d 5b 4d ec ff                            	prefetchit0 -0x13b2a5(%rip)        # 23c510 <_ZNSi6sentryC1ERSib>
  3777b5:	0f 18 3d 34 55 ec ff                            	prefetchit0 -0x13aacc(%rip)        # 23ccf0 <_ZNSi3getERc>
  3777bc:	0f 18 3d 7f 4d ec ff                            	prefetchit0 -0x13b281(%rip)        # 23c542 <_ZNSi6sentryC1ERSib+0x32>
  3777c3:	e9 c8 c8 d8 ff                                  	jmp    104090 <_ZN13jaegertracing11SpanContext10fromStreamERSi>
  3777c8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3777d0:	0f 18 3d 79 2e ef ff                            	prefetchit0 -0x10d187(%rip)        # 26a650 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_>
  3777d7:	0f 18 3d 52 03 cf ff                            	prefetchit0 -0x30fcae(%rip)        # 67b30 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  3777de:	0f 18 3d 1b 4a cf ff                            	prefetchit0 -0x30b5e5(%rip)        # 6c200 <_ZN13jaegertracingeqERKNS_11SpanContextES2_>
  3777e5:	0f 18 3d d4 50 cf ff                            	prefetchit0 -0x30af2c(%rip)        # 6c8c0 <_ZNKSt8__detail9_EqualityINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS6_S6_ESaIS9_ENS_10_Select1stESt8equal_toIS6_ESt4hashIS6_ENS_18_Mod_range_hashingENS_20_Default_ranged_hashENS_20_Prime_rehash_policyENS_17_Hashtable_traitsILb1ELb0ELb1EEELb1EE8_M_equalERKSt10_HashtableIS6_S9_SA_SB_SD_SF_SG_SH_SI_SK_E>
  3777ec:	e9 3f 4f cf ff                                  	jmp    6c730 <_ZN13jaegertracing11SpanContext4swapERS0_>
  3777f1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3777fb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  377800:	0f 18 3d f9 2d ed ff                            	prefetchit0 -0x12d207(%rip)        # 24a600 <_ZNKSt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEE13_M_insert_intImEES3_S3_RSt8ios_basecT_>
  377807:	0f 18 3d 33 2e ed ff                            	prefetchit0 -0x12d1cd(%rip)        # 24a641 <_ZNKSt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEE13_M_insert_intImEES3_S3_RSt8ios_basecT_+0x41>
  37780e:	e9 6d 57 cf ff                                  	jmp    6cf80 <_ZNK13jaegertracing7TraceID5printISoEEvRT_>
  377813:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37781d:	0f 1f 00                                        	nopl   (%rax)
  377820:	0f 18 3d d9 db d0 ff                            	prefetchit0 -0x2f2427(%rip)        # 85400 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE21readMessageBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERNS1_12TMessageTypeERi>
  377827:	0f 18 3d c2 60 d1 ff                            	prefetchit0 -0x2e9f3e(%rip)        # 8d8f0 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv>
  37782e:	0f 18 3d 32 61 d1 ff                            	prefetchit0 -0x2e9ece(%rip)        # 8d967 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x77>
  377835:	0f 18 3d 04 7d d4 ff                            	prefetchit0 -0x2b82fc(%rip)        # bf540 <_ZN6apache6thrift6server16TConnectedClient3runEv+0x180>
  37783c:	0f 18 3d 2d 91 d3 ff                            	prefetchit0 -0x2c6ed3(%rip)        # b0970 <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj>
  377843:	e9 98 0d e7 ff                                  	jmp    1e85e0 <_ZdlPvm>
  377848:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  377850:	0f 18 3d 79 f6 d0 ff                            	prefetchit0 -0x2f0987(%rip)        # 86ed0 <_ZZNSt9once_flag18_Prepare_executionC1IZSt9call_onceIMSt6threadFvvEJPS3_EEvRS_OT_DpOT0_EUlvE_EERS8_ENUlvE_8__invokeEv>
  377857:	0f 18 3d a2 f6 ed ff                            	prefetchit0 -0x12095e(%rip)        # 256f00 <__once_proxy>
  37785e:	41 53                                           	push   %r11
  377860:	4c 8b 1d d9 87 ff ff                            	mov    -0x7827(%rip),%r11        # 370040 <pthread_join@GLIBC_2.34>
  377867:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  37786f:	41 5b                                           	pop    %r11
  377871:	e9 7a eb cb ff                                  	jmp    363f0 <pthread_once@plt>
  377876:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377880:	0f 18 3d 29 ec cb ff                            	prefetchit0 -0x3413d7(%rip)        # 364b0 <free@plt>
  377887:	0f 18 3d 32 b6 d0 ff                            	prefetchit0 -0x2f49ce(%rip)        # 82ec0 <_ZNSt13__future_base21_Async_state_commonV217_M_complete_asyncEv>
  37788e:	0f 18 3d 4b 0d e7 ff                            	prefetchit0 -0x18f2b5(%rip)        # 1e85e0 <_ZdlPvm>
  377895:	0f 18 3d 04 d3 e7 ff                            	prefetchit0 -0x182cfc(%rip)        # 1f4ba0 <_ZNSt6chrono3_V212steady_clock3nowEv>
  37789c:	e9 9f 0f ec ff                                  	jmp    238840 <_ZNSt13__future_base12_Result_baseD1Ev>
  3778a1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3778ab:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3778b0:	0f 18 3d 49 f6 ed ff                            	prefetchit0 -0x1209b7(%rip)        # 256f00 <__once_proxy>
  3778b7:	0f 18 3d 82 ba d0 ff                            	prefetchit0 -0x2f457e(%rip)        # 83340 <_ZZNSt9once_flag18_Prepare_executionC1IZSt9call_onceIMNSt13__future_base13_State_baseV2EFvPSt8functionIFSt10unique_ptrINS3_12_Result_baseENS7_8_DeleterEEvEEPbEJPS4_SC_SD_EEvRS_OT_DpOT0_EUlvE_EERSI_ENUlvE_8__invokeEv>
  3778be:	0f 18 3d cb f2 cb ff                            	prefetchit0 -0x340d35(%rip)        # 36b90 <pthread_mutex_lock@plt>
  3778c5:	e9 26 eb cb ff                                  	jmp    363f0 <pthread_once@plt>
  3778ca:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  3778d0:	0f 18 3d ad 42 ef ff                            	prefetchit0 -0x10bd53(%rip)        # 26bb84 <execute_native_thread_routine+0x14>
  3778d7:	e9 b4 f2 cb ff                                  	jmp    36b90 <pthread_mutex_lock@plt>
  3778dc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3778e0:	0f 18 3d 59 36 ef ff                            	prefetchit0 -0x10c9a7(%rip)        # 26af40 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc>
  3778e7:	0f 18 3d 55 60 d1 ff                            	prefetchit0 -0x2e9fab(%rip)        # 8d943 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x53>
  3778ee:	0f 18 3d 2a c1 d1 ff                            	prefetchit0 -0x2e3ed6(%rip)        # 93a1f <_ZN13media_service26ComposeReviewServiceClient17recv_UploadRatingEv+0x4f>
  3778f5:	0f 18 3d b4 3d d1 ff                            	prefetchit0 -0x2ec24c(%rip)        # 8b6b0 <_ZN13media_service22RatingServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv>
  3778fc:	0f 18 3d 39 60 d1 ff                            	prefetchit0 -0x2e9fc7(%rip)        # 8d93c <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x4c>
  377903:	e9 38 e6 d0 ff                                  	jmp    85f40 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE14readStringBodyINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEEjRT_i>
  377908:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  377910:	0f 18 3d 19 68 d1 ff                            	prefetchit0 -0x2e97e7(%rip)        # 8e130 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE22_M_emplace_hint_uniqueIJRKSt21piecewise_construct_tSt5tupleIJRS7_EESJ_IJEEEEESt17_Rb_tree_iteratorIS8_ESt23_Rb_tree_const_iteratorIS8_EDpOT_>
  377917:	0f 18 3d c2 f0 cb ff                            	prefetchit0 -0x340f3e(%rip)        # 369e0 <memcmp@plt>
  37791e:	41 53                                           	push   %r11
  377920:	4c 8b 1d c9 8b ff ff                            	mov    -0x7437(%rip),%r11        # 3704f0 <memcmp@GLIBC_2.2.5>
  377927:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  37792f:	41 5b                                           	pop    %r11
  377931:	e9 4a 20 ef ff                                  	jmp    269980 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm>
  377936:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377940:	0f 18 3d 99 66 e5 ff                            	prefetchit0 -0x1a9967(%rip)        # 1cdfe0 <_ZNK7tacopie10tcp_client12is_connectedEv>
  377947:	0f 18 3d c2 34 dd ff                            	prefetchit0 -0x22cb3e(%rip)        # 14ae10 <_ZN11opentracing2v26Tracer6GlobalEv>
  37794e:	0f 18 3d eb 73 df ff                            	prefetchit0 -0x208c15(%rip)        # 16ed40 <_ZNK9cpp_redis6client12is_connectedEv>
  377955:	e9 26 f3 cb ff                                  	jmp    36c80 <pthread_mutex_unlock@plt>
  37795a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  377960:	0f 18 3d 09 e7 d0 ff                            	prefetchit0 -0x2f18f7(%rip)        # 86070 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE12readMapBeginERNS1_5TTypeES8_Rj>
  377967:	e9 64 99 cf ff                                  	jmp    712d0 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  37796c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377970:	0f 18 3d e9 90 cf ff                            	prefetchit0 -0x306f17(%rip)        # 70a60 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_>
  377977:	0f 18 3d f2 27 e7 ff                            	prefetchit0 -0x18d80e(%rip)        # 1ea170 <_Znwm>
  37797e:	0f 18 3d 8b c9 e7 ff                            	prefetchit0 -0x183675(%rip)        # 1f4310 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_>
  377985:	0f 18 3d 37 cc e7 ff                            	prefetchit0 -0x1833c9(%rip)        # 1f45c3 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_+0x2b3>
  37798c:	0f 18 3d ee 27 e7 ff                            	prefetchit0 -0x18d812(%rip)        # 1ea181 <_Znwm+0x11>
  377993:	0f 18 3d 1e cc e7 ff                            	prefetchit0 -0x1833e2(%rip)        # 1f45b8 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_+0x2a8>
  37799a:	0f 18 3d a2 c9 e7 ff                            	prefetchit0 -0x18365e(%rip)        # 1f4343 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_+0x33>
  3779a1:	e9 8a 67 d1 ff                                  	jmp    8e130 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE22_M_emplace_hint_uniqueIJRKSt21piecewise_construct_tSt5tupleIJRS7_EESJ_IJEEEEESt17_Rb_tree_iteratorIS8_ESt23_Rb_tree_const_iteratorIS8_EDpOT_>
  3779a6:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3779b0:	0f 18 3d 29 43 d1 ff                            	prefetchit0 -0x2ebcd7(%rip)        # 8bce0 <_ZN13media_service22RatingServiceProcessor20process_UploadRatingEiPN6apache6thrift8protocol9TProtocolES5_Pv>
  3779b7:	0f 18 3d 62 da d0 ff                            	prefetchit0 -0x2f259e(%rip)        # 85420 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE20readStructBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  3779be:	0f 18 3d 4b 26 d1 ff                            	prefetchit0 -0x2ed9b5(%rip)        # 8a010 <_ZN13media_service31RatingService_UploadRating_args4readEPN6apache6thrift8protocol9TProtocolE>
  3779c5:	e9 16 f0 cb ff                                  	jmp    369e0 <memcmp@plt>
  3779ca:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  3779d0:	0f 18 3d 49 de d0 ff                            	prefetchit0 -0x2f21b7(%rip)        # 85820 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE12readI64_virtERl>
  3779d7:	e9 34 26 d1 ff                                  	jmp    8a010 <_ZN13media_service31RatingService_UploadRating_args4readEPN6apache6thrift8protocol9TProtocolE>
  3779dc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3779e0:	0f 18 3d c9 12 e7 ff                            	prefetchit0 -0x18ed37(%rip)        # 1e8cb0 <_ZNSt9exceptionD1Ev>
  3779e7:	e9 84 b1 d2 ff                                  	jmp    a2b70 <_ZN13media_service16ServiceExceptionD1Ev>
  3779ec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3779f0:	0f 18 3d ce 41 d1 ff                            	prefetchit0 -0x2ebe32(%rip)        # 8bbc5 <_ZN13media_service22RatingServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x515>
  3779f7:	0f 18 3d f8 3d d1 ff                            	prefetchit0 -0x2ec208(%rip)        # 8b7f6 <_ZN13media_service22RatingServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x146>
  3779fe:	e9 cd 98 cf ff                                  	jmp    712d0 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  377a03:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377a0d:	0f 1f 00                                        	nopl   (%rax)
  377a10:	0f 18 3d 49 10 ef ff                            	prefetchit0 -0x10efb7(%rip)        # 268a60 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm>
  377a17:	e9 44 90 cf ff                                  	jmp    70a60 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_>
  377a1c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377a20:	0f 18 3d 79 56 d3 ff                            	prefetchit0 -0x2ca987(%rip)        # ad0a0 <_ZN6apache6thrift9transport17TVirtualTransportINS1_7TSocketENS1_18TTransportDefaultsEE10write_virtEPKhj>
  377a27:	0f 18 3d c2 46 d3 ff                            	prefetchit0 -0x2cb93e(%rip)        # ac0f0 <_ZN6apache6thrift9transport7TSocket5writeEPKhj>
  377a2e:	0f 18 3d 4b 81 d3 ff                            	prefetchit0 -0x2c7eb5(%rip)        # afb80 <_ZN6apache6thrift9transport16TFramedTransport5flushEv>
  377a35:	e9 06 c7 e7 ff                                  	jmp    1f4140 <_ZSt18_Rb_tree_incrementPKSt18_Rb_tree_node_base>
  377a3a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  377a40:	0f 18 3d a9 87 d1 ff                            	prefetchit0 -0x2e7857(%rip)        # 901f0 <_ZN13media_service41ComposeReviewService_UploadRating_presult4readEPN6apache6thrift8protocol9TProtocolE>
  377a47:	0f 18 3d f5 c1 d1 ff                            	prefetchit0 -0x2e3e0b(%rip)        # 93c43 <_ZN13media_service26ComposeReviewServiceClient17recv_UploadRatingEv+0x273>
  377a4e:	0f 18 3d cb d9 d0 ff                            	prefetchit0 -0x2f2635(%rip)        # 85420 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE20readStructBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  377a55:	0f 18 3d 64 ea cb ff                            	prefetchit0 -0x34159c(%rip)        # 364c0 <strlen@plt>
  377a5c:	e9 df 34 ef ff                                  	jmp    26af40 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc>
  377a61:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377a6b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  377a70:	0f 18 3d f9 b0 d2 ff                            	prefetchit0 -0x2d4f07(%rip)        # a2b70 <_ZN13media_service16ServiceExceptionD1Ev>
  377a77:	e9 74 87 d1 ff                                  	jmp    901f0 <_ZN13media_service41ComposeReviewService_UploadRating_presult4readEPN6apache6thrift8protocol9TProtocolE>
  377a7c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377a80:	0f 18 3d 7a ec cd ff                            	prefetchit0 -0x321386(%rip)        # 56701 <_ZNSt17_Function_handlerIFSt10unique_ptrINSt13__future_base12_Result_baseENS2_8_DeleterEEvENS1_12_Task_setterIS0_INS1_7_ResultIvEES3_ENSt6thread8_InvokerISt5tupleIJZN13media_service13RatingHandler12UploadRatingElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapISK_SK_St4lessISK_ESaISt4pairISL_SK_EEEE3$_0EEEEvEEE9_M_invokeERKSt9_Any_data+0x51>
  377a87:	0f 18 3d 22 12 e7 ff                            	prefetchit0 -0x18edde(%rip)        # 1e8cb0 <_ZNSt9exceptionD1Ev>
  377a8e:	e9 dd b0 d2 ff                                  	jmp    a2b70 <_ZN13media_service16ServiceExceptionD1Ev>
  377a93:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377a9d:	0f 1f 00                                        	nopl   (%rax)
  377aa0:	0f 18 3d f9 f1 cb ff                            	prefetchit0 -0x340e07(%rip)        # 36ca0 <memcpy@plt>
  377aa7:	0f 18 3d bd 7d d3 ff                            	prefetchit0 -0x2c8243(%rip)        # af86b <_ZN6apache6thrift9transport16TFramedTransport9readFrameEv+0x3b>
  377aae:	0f 18 3d cb 7d d3 ff                            	prefetchit0 -0x2c8235(%rip)        # af880 <_ZN6apache6thrift9transport16TFramedTransport9readFrameEv+0x50>
  377ab5:	0f 18 3d e4 3f d3 ff                            	prefetchit0 -0x2cc01c(%rip)        # abaa0 <_ZN6apache6thrift9transport7TSocket4readEPhj>
  377abc:	0f 18 3d 34 7d d3 ff                            	prefetchit0 -0x2c82cc(%rip)        # af7f7 <_ZN6apache6thrift9transport16TFramedTransport8readSlowEPhj+0x47>
  377ac3:	0f 18 3d f6 3f d3 ff                            	prefetchit0 -0x2cc00a(%rip)        # abac0 <_ZN6apache6thrift9transport7TSocket4readEPhj+0x20>
  377aca:	0f 18 3d 8f eb cb ff                            	prefetchit0 -0x341471(%rip)        # 36660 <poll@plt>
  377ad1:	0f 18 3d 6c e2 d0 ff                            	prefetchit0 -0x2f1d94(%rip)        # 85d44 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE16readMessageBeginERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERNS1_12TMessageTypeERi+0xb4>
  377ad8:	e9 53 e8 cb ff                                  	jmp    36330 <recv@plt>
  377add:	0f 1f 00                                        	nopl   (%rax)
  377ae0:	0f 18 3d 89 55 d3 ff                            	prefetchit0 -0x2caa77(%rip)        # ad070 <_ZN6apache6thrift9transport17TVirtualTransportINS1_7TSocketENS1_18TTransportDefaultsEE9read_virtEPhj>
  377ae7:	0f 18 3d 82 b0 d2 ff                            	prefetchit0 -0x2d4f7e(%rip)        # a2b70 <_ZN13media_service16ServiceExceptionD1Ev>
  377aee:	0f 18 3d ab 3f d3 ff                            	prefetchit0 -0x2cc055(%rip)        # abaa0 <_ZN6apache6thrift9transport7TSocket4readEPhj>
  377af5:	0f 18 3d b4 7c d3 ff                            	prefetchit0 -0x2c834c(%rip)        # af7b0 <_ZN6apache6thrift9transport16TFramedTransport8readSlowEPhj>
  377afc:	0f 18 3d 7f b0 d2 ff                            	prefetchit0 -0x2d4f81(%rip)        # a2b82 <_ZN13media_service16ServiceExceptionD1Ev+0x12>
  377b03:	0f 18 3d b6 3f d3 ff                            	prefetchit0 -0x2cc04a(%rip)        # abac0 <_ZN6apache6thrift9transport7TSocket4readEPhj+0x20>
  377b0a:	e9 31 ee cb ff                                  	jmp    36940 <send@plt>
  377b0f:	90                                              	nop
  377b10:	0f 18 3d 29 8b d3 ff                            	prefetchit0 -0x2c74d7(%rip)        # b0640 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE12readAll_virtEPhj>
  377b17:	0f 18 3d 62 1e ef ff                            	prefetchit0 -0x10e19e(%rip)        # 269980 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm>
  377b1e:	0f 18 3d 97 e1 d0 ff                            	prefetchit0 -0x2f1e69(%rip)        # 85cbc <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE16readMessageBeginERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERNS1_12TMessageTypeERi+0x2c>
  377b25:	0f 18 3d 8e 8e d3 ff                            	prefetchit0 -0x2c7172(%rip)        # b09ba <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj+0x4a>
  377b2c:	0f 18 3d a3 8e d3 ff                            	prefetchit0 -0x2c715d(%rip)        # b09d6 <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj+0x66>
  377b33:	0f 18 3d 88 1e ef ff                            	prefetchit0 -0x10e178(%rip)        # 2699c2 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm+0x42>
  377b3a:	0f 18 3d 7f e1 d0 ff                            	prefetchit0 -0x2f1e81(%rip)        # 85cc0 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE16readMessageBeginERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERNS1_12TMessageTypeERi+0x30>
  377b41:	0f 18 3d b8 1e ef ff                            	prefetchit0 -0x10e148(%rip)        # 269a00 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm+0x80>
  377b48:	e9 53 f1 cb ff                                  	jmp    36ca0 <memcpy@plt>
  377b4d:	0f 1f 00                                        	nopl   (%rax)
  377b50:	0f 18 3d b9 32 dd ff                            	prefetchit0 -0x22cd47(%rip)        # 14ae10 <_ZN11opentracing2v26Tracer6GlobalEv>
  377b57:	0f 18 3d 92 dc d0 ff                            	prefetchit0 -0x2f236e(%rip)        # 857f0 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE12readI32_virtERi>
  377b5e:	0f 18 3d 81 28 d1 ff                            	prefetchit0 -0x2ed77f(%rip)        # 8a3e6 <_ZN13media_service31RatingService_UploadRating_args4readEPN6apache6thrift8protocol9TProtocolE+0x3d6>
  377b65:	0f 18 3d 19 c7 cd ff                            	prefetchit0 -0x3238e7(%rip)        # 54285 <_ZN13media_service13RatingHandler12UploadRatingElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapIS6_S6_St4lessIS6_ESaISt4pairIS7_S6_EEE+0x75>
  377b6c:	0f 18 3d cf c6 cd ff                            	prefetchit0 -0x323931(%rip)        # 54242 <_ZN13media_service13RatingHandler12UploadRatingElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapIS6_S6_St4lessIS6_ESaISt4pairIS7_S6_EEE+0x32>
  377b73:	0f 18 3d 59 97 cf ff                            	prefetchit0 -0x3068a7(%rip)        # 712d3 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E+0x3>
  377b7a:	e9 21 f1 cb ff                                  	jmp    36ca0 <memcpy@plt>
  377b7f:	90                                              	nop
  377b80:	0f 18 3d b9 ed cb ff                            	prefetchit0 -0x341247(%rip)        # 36940 <send@plt>
  377b87:	0f 18 3d 32 81 d1 ff                            	prefetchit0 -0x2e7ece(%rip)        # 8fcc0 <_ZNK13media_service39ComposeReviewService_UploadRating_pargs5writeEPN6apache6thrift8protocol9TProtocolE>
  377b8e:	0f 18 3d 0b 55 d3 ff                            	prefetchit0 -0x2caaf5(%rip)        # ad0a0 <_ZN6apache6thrift9transport17TVirtualTransportINS1_7TSocketENS1_18TTransportDefaultsEE10write_virtEPKhj>
  377b95:	0f 18 3d 74 80 d3 ff                            	prefetchit0 -0x2c7f8c(%rip)        # afc10 <_ZN6apache6thrift9transport16TFramedTransport8writeEndEv>
  377b9c:	0f 18 3d 4d 45 d3 ff                            	prefetchit0 -0x2cbab3(%rip)        # ac0f0 <_ZN6apache6thrift9transport7TSocket5writeEPKhj>
  377ba3:	0f 18 3d 86 d4 d0 ff                            	prefetchit0 -0x2f2b7a(%rip)        # 85030 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE19writeFieldStop_virtEv>
  377baa:	0f 18 3d 4f 45 d3 ff                            	prefetchit0 -0x2cbab1(%rip)        # ac100 <_ZN6apache6thrift9transport7TSocket5writeEPKhj+0x10>
  377bb1:	e9 ea f0 cb ff                                  	jmp    36ca0 <memcpy@plt>
  377bb6:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377bc0:	0f 18 3d bb 22 d9 ff                            	prefetchit0 -0x26dd45(%rip)        # 109e82 <_ZN13jaegertracing12UDPTransport6appendERKNS_4SpanE+0x7e2>
  377bc7:	e9 e4 e8 cb ff                                  	jmp    364b0 <free@plt>
  377bcc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377bd0:	0f 18 3d 29 23 d1 ff                            	prefetchit0 -0x2edcd7(%rip)        # 89f00 <_ZNSt15_Sp_counted_ptrIPN6apache6thrift8protocol9TProtocolELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv>
  377bd7:	0f 18 3d d2 6d db ff                            	prefetchit0 -0x24922e(%rip)        # 12e9b0 <_ZNK13jaegertracing6thrift7SpanRef5writeEPN6apache6thrift8protocol9TProtocolE>
  377bde:	e9 bd f0 cb ff                                  	jmp    36ca0 <memcpy@plt>
  377be3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377bed:	0f 1f 00                                        	nopl   (%rax)
  377bf0:	0f 18 3d b9 f6 ee ff                            	prefetchit0 -0x110947(%rip)        # 2672b0 <_ZNSt15basic_streambufIcSt11char_traitsIcEE5uflowEv>
  377bf7:	0f 18 3d c4 f6 ee ff                            	prefetchit0 -0x11093c(%rip)        # 2672c2 <_ZNSt15basic_streambufIcSt11char_traitsIcEE5uflowEv+0x12>
  377bfe:	e9 ed 50 ec ff                                  	jmp    23ccf0 <_ZNSi3getERc>
  377c03:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377c0d:	0f 1f 00                                        	nopl   (%rax)
  377c10:	0f 18 3d d9 5a ee ff                            	prefetchit0 -0x11a527(%rip)        # 25d6f0 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE9underflowEv>
  377c17:	e9 e4 c9 d8 ff                                  	jmp    104600 <_ZN13jaegertracing5utils10HexParsing11readSegmentB5cxx11ERSimc>
  377c1c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377c20:	0f 18 3d 69 50 cf ff                            	prefetchit0 -0x30af97(%rip)        # 6cc90 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_>
  377c27:	e9 54 11 ef ff                                  	jmp    268d80 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEaSEOS4_>
  377c2c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377c30:	0f 18 3d f9 4a cf ff                            	prefetchit0 -0x30b507(%rip)        # 6c730 <_ZN13jaegertracing11SpanContext4swapERS0_>
  377c37:	0f 18 3d 43 4b cf ff                            	prefetchit0 -0x30b4bd(%rip)        # 6c781 <_ZN13jaegertracing11SpanContext4swapERS0_+0x51>
  377c3e:	0f 18 3d fc 4a cf ff                            	prefetchit0 -0x30b504(%rip)        # 6c741 <_ZN13jaegertracing11SpanContext4swapERS0_+0x11>
  377c45:	e9 e6 13 ec ff                                  	jmp    239030 <_ZNSt9basic_iosIcSt11char_traitsIcEE5clearESt12_Ios_Iostate>
  377c4a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  377c50:	41 53                                           	push   %r11
  377c52:	4c 8b 1d 0f 86 ff ff                            	mov    -0x79f1(%rip),%r11        # 370268 <isupper@GLIBC_2.2.5>
  377c59:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  377c61:	41 5b                                           	pop    %r11
  377c63:	e9 88 09 ef ff                                  	jmp    2685f0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm>
  377c68:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  377c70:	0f 18 3d 49 16 d9 ff                            	prefetchit0 -0x26e9b7(%rip)        # 1092c0 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_>
  377c77:	0f 18 3d 12 50 cf ff                            	prefetchit0 -0x30afee(%rip)        # 6cc90 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_>
  377c7e:	0f 18 3d bc 16 d9 ff                            	prefetchit0 -0x26e944(%rip)        # 109341 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_+0x81>
  377c85:	0f 18 3d f6 26 e7 ff                            	prefetchit0 -0x18d90a(%rip)        # 1ea382 <_ZNK10__cxxabiv120__si_class_type_info12__do_dyncastElNS_17__class_type_info10__sub_kindEPKS1_PKvS4_S6_RNS1_16__dyncast_resultE+0x22>
  377c8c:	e9 bf dc d8 ff                                  	jmp    105950 <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE>
  377c91:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377c9b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  377ca0:	0f 18 3d d9 37 cf ff                            	prefetchit0 -0x30c827(%rip)        # 6b480 <_ZN13jaegertracing11SpanContextC2ERKNS_7TraceIDEmmhRKSt13unordered_mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESA_St4hashISA_ESt8equal_toISA_ESaISt4pairIKSA_SA_EEERSG_+0x50>
  377ca7:	0f 18 3d 82 37 cf ff                            	prefetchit0 -0x30c87e(%rip)        # 6b430 <_ZN13jaegertracing11SpanContextC2ERKNS_7TraceIDEmmhRKSt13unordered_mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESA_St4hashISA_ESt8equal_toISA_ESaISt4pairIKSA_SA_EEERSG_>
  377cae:	0f 18 3d 8c ff d8 ff                            	prefetchit0 -0x270074(%rip)        # 107c41 <_ZNSt23mersenne_twister_engineImLm64ELm312ELm156ELm31ELm13043109905998158313ELm29ELm6148914691236517205ELm17ELm8202884508482404352ELm37ELm18444473444759240704ELm43ELm6364136223846793005EEclEv+0x191>
  377cb5:	e9 f6 fd d8 ff                                  	jmp    107ab0 <_ZNSt23mersenne_twister_engineImLm64ELm312ELm156ELm31ELm13043109905998158313ELm29ELm6148914691236517205ELm17ELm8202884508482404352ELm37ELm18444473444759240704ELm43ELm6364136223846793005EEclEv>
  377cba:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  377cc0:	0f 18 3d 39 e5 cb ff                            	prefetchit0 -0x341ac7(%rip)        # 36200 <clock_gettime@plt>
  377cc7:	0f 18 3d 82 ce e7 ff                            	prefetchit0 -0x18317e(%rip)        # 1f4b50 <_ZNSt6chrono3_V212system_clock3nowEv>
  377cce:	e9 5d 4a cf ff                                  	jmp    6c730 <_ZN13jaegertracing11SpanContext4swapERS0_>
  377cd3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377cdd:	0f 1f 00                                        	nopl   (%rax)
  377ce0:	0f 18 3d 79 eb d8 ff                            	prefetchit0 -0x271487(%rip)        # 106860 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EE7reserveEm>
  377ce7:	e9 b4 ef cb ff                                  	jmp    36ca0 <memcpy@plt>
  377cec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377cf0:	0f 18 3d 29 0f d9 ff                            	prefetchit0 -0x26f0d7(%rip)        # 108c20 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EE15_M_range_insertIN9__gnu_cxx17__normal_iteratorIPKS1_S3_EEEEvNS6_IPS1_S3_EET_SC_St20forward_iterator_tag>
  377cf7:	0f 18 3d 6c 12 d9 ff                            	prefetchit0 -0x26ed94(%rip)        # 108f6a <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EE15_M_range_insertIN9__gnu_cxx17__normal_iteratorIPKS1_S3_EEEEvNS6_IPS1_S3_EET_SC_St20forward_iterator_tag+0x34a>
  377cfe:	0f 18 3d 74 ec d8 ff                            	prefetchit0 -0x27138c(%rip)        # 106979 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EE7reserveEm+0x119>
  377d05:	e9 96 df d8 ff                                  	jmp    105ca0 <_ZNK13jaegertracing6Tracer17startSpanInternalERKNS_11SpanContextERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKNSt6chrono10time_pointINSC_3_V212system_clockENSC_8durationIlSt5ratioILl1ELl1000000000EEEEEERKNSD_INSE_12steady_clockESJ_EERKSt6vectorINS_3TagESaISS_EERKSR_ISt4pairIS9_N11opentracing2v25ValueEESaIS11_EEbRKSR_INS_9ReferenceESaIS16_EE>
  377d0a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  377d10:	0f 18 3d 29 16 cf ff                            	prefetchit0 -0x30e9d7(%rip)        # 69340 <_ZNSt20__uninitialized_copyILb0EE13__uninit_copyIN9__gnu_cxx17__normal_iteratorIPKN13jaegertracing3TagESt6vectorIS5_SaIS5_EEEEPS5_EET0_T_SE_SD_>
  377d17:	0f 18 3d e4 16 cf ff                            	prefetchit0 -0x30e91c(%rip)        # 69402 <_ZNSt20__uninitialized_copyILb0EE13__uninit_copyIN9__gnu_cxx17__normal_iteratorIPKN13jaegertracing3TagESt6vectorIS5_SaIS5_EEEEPS5_EET0_T_SE_SD_+0xc2>
  377d1e:	0f 18 3d 5e 00 d9 ff                            	prefetchit0 -0x26ffa2(%rip)        # 107d83 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EEC2ERKS3_+0x13>
  377d25:	e9 76 ec d8 ff                                  	jmp    1069a0 <_ZN13jaegertracing4SpanC2ERKSt10shared_ptrIKNS_6TracerEERKNS_11SpanContextERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKNSt6chrono10time_pointINSI_3_V212system_clockENSI_8durationIlSt5ratioILl1ELl1000000000EEEEEERKNSJ_INSK_12steady_clockESP_EERKSt6vectorINS_3TagESaISY_EERKSX_INS_9ReferenceESaIS13_EE>
  377d2a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  377d30:	0f 18 3d e9 0b ce ff                            	prefetchit0 -0x31f417(%rip)        # 58920 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  377d37:	e9 34 24 e7 ff                                  	jmp    1ea170 <_Znwm>
  377d3c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377d40:	0f 18 3d f9 ad ce ff                            	prefetchit0 -0x315207(%rip)        # 62b40 <_ZN13jaegertracing7metrics11NullCounter3incEl>
  377d47:	0f 18 3d 12 15 cf ff                            	prefetchit0 -0x30eaee(%rip)        # 69260 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EED2Ev>
  377d4e:	0f 18 3d 2b 42 dc ff                            	prefetchit0 -0x23bdd5(%rip)        # 13bf80 <_ZNK13jaegertracing4Span7contextEv>
  377d55:	e9 c6 ca d8 ff                                  	jmp    104820 <_ZN13jaegertracing11SpanContextC2ERKS0_>
  377d5a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  377d60:	0f 18 3d 2c ff d8 ff                            	prefetchit0 -0x2700d4(%rip)        # 107c93 <_ZNSt12_Destroy_auxILb0EE9__destroyIPN13jaegertracing9ReferenceEEEvT_S5_+0x3>
  377d67:	0f 18 3d f4 ff d8 ff                            	prefetchit0 -0x27000c(%rip)        # 107d62 <_ZNSt12_Destroy_auxILb0EE9__destroyIPN13jaegertracing9ReferenceEEEvT_S5_+0xd2>
  377d6e:	e9 fd 23 e7 ff                                  	jmp    1ea170 <_Znwm>
  377d73:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377d7d:	0f 1f 00                                        	nopl   (%rax)
  377d80:	0f 18 3d 29 fd d8 ff                            	prefetchit0 -0x2702d7(%rip)        # 107ab0 <_ZNSt23mersenne_twister_engineImLm64ELm312ELm156ELm31ELm13043109905998158313ELm29ELm6148914691236517205ELm17ELm8202884508482404352ELm37ELm18444473444759240704ELm43ELm6364136223846793005EEclEv>
  377d87:	0f 18 3d 35 fd d8 ff                            	prefetchit0 -0x2702cb(%rip)        # 107ac3 <_ZNSt23mersenne_twister_engineImLm64ELm312ELm156ELm31ELm13043109905998158313ELm29ELm6148914691236517205ELm17ELm8202884508482404352ELm37ELm18444473444759240704ELm43ELm6364136223846793005EEclEv+0x13>
  377d8e:	0f 18 3d 9d fe d8 ff                            	prefetchit0 -0x270163(%rip)        # 107c32 <_ZNSt23mersenne_twister_engineImLm64ELm312ELm156ELm31ELm13043109905998158313ELm29ELm6148914691236517205ELm17ELm8202884508482404352ELm37ELm18444473444759240704ELm43ELm6364136223846793005EEclEv+0x182>
  377d95:	e9 f6 fe d8 ff                                  	jmp    107c90 <_ZNSt12_Destroy_auxILb0EE9__destroyIPN13jaegertracing9ReferenceEEEvT_S5_>
  377d9a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  377da0:	0f 18 3d 09 72 db ff                            	prefetchit0 -0x248df7(%rip)        # 12efb0 <_ZN13jaegertracing6thrift4Span17__set_traceIdHighEl>
  377da7:	0f 18 3d f2 2f d9 ff                            	prefetchit0 -0x26d00e(%rip)        # 10ada0 <_ZNSt6vectorIN13jaegertracing6thrift7SpanRefESaIS2_EE20_M_allocate_and_copyIPKS2_EEPS2_mT_S9_>
  377dae:	e9 6d 27 d9 ff                                  	jmp    10a520 <_ZNK13jaegertracing4Span6thriftEv>
  377db3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377dbd:	0f 1f 00                                        	nopl   (%rax)
  377dc0:	0f 18 3d 69 db d0 ff                            	prefetchit0 -0x2f2497(%rip)        # 85930 <_ZN6apache6thrift8protocol17TProtocolDefaultsC2ESt10shared_ptrINS0_9transport10TTransportEE>
  377dc7:	0f 18 3d 92 44 d9 ff                            	prefetchit0 -0x26bb6e(%rip)        # 10c260 <_ZN6apache6thrift8protocol17TCompactProtocolTINS0_9transport10TTransportEEC2ESt10shared_ptrIS4_Eii>
  377dce:	0f 18 3d 3a dc d0 ff                            	prefetchit0 -0x2f23c6(%rip)        # 85a0f <_ZN6apache6thrift8protocol17TProtocolDefaultsC2ESt10shared_ptrINS0_9transport10TTransportEE+0xdf>
  377dd5:	e9 96 23 e7 ff                                  	jmp    1ea170 <_Znwm>
  377dda:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  377de0:	0f 18 3d 69 89 d3 ff                            	prefetchit0 -0x2c7697(%rip)        # b0750 <_ZN6apache6thrift9transport13TMemoryBufferD0Ev>
  377de7:	e9 f4 16 d3 ff                                  	jmp    a94e0 <_ZN6apache6thrift8protocol16TProtocolFactoryD1Ev>
  377dec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377df0:	0f 18 3d 39 70 db ff                            	prefetchit0 -0x248fc7(%rip)        # 12ee30 <_ZN13jaegertracing6thrift4SpanD2Ev>
  377df7:	0f 18 3d 44 70 db ff                            	prefetchit0 -0x248fbc(%rip)        # 12ee42 <_ZN13jaegertracing6thrift4SpanD2Ev+0x12>
  377dfe:	e9 1d 71 db ff                                  	jmp    12ef20 <_ZN13jaegertracing6thrift4SpanD1Ev>
  377e03:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377e0d:	0f 1f 00                                        	nopl   (%rax)
  377e10:	0f 18 3d 69 68 db ff                            	prefetchit0 -0x249797(%rip)        # 12e680 <_ZN13jaegertracing6thrift7SpanRef13__set_refTypeENS0_11SpanRefType4typeE>
  377e17:	0f 18 3d e3 30 d9 ff                            	prefetchit0 -0x26cf1d(%rip)        # 10af01 <_ZNK13jaegertracing9Reference6thriftEv+0x51>
  377e1e:	e9 9d 71 db ff                                  	jmp    12efc0 <_ZN13jaegertracing6thrift4Span12__set_spanIdEl>
  377e23:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377e2d:	0f 1f 00                                        	nopl   (%rax)
  377e30:	0f 18 3d 22 2a d9 ff                            	prefetchit0 -0x26d5de(%rip)        # 10a859 <_ZNK13jaegertracing4Span6thriftEv+0x339>
  377e37:	e9 d4 71 db ff                                  	jmp    12f010 <_ZN13jaegertracing6thrift4Span11__set_flagsEi>
  377e3c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377e40:	0f 18 3d 09 a4 db ff                            	prefetchit0 -0x245bf7(%rip)        # 132250 <_ZNSt6vectorIN13jaegertracing6thrift3TagESaIS2_EEaSERKS4_>
  377e47:	0f 18 3d f2 71 db ff                            	prefetchit0 -0x248e0e(%rip)        # 12f040 <_ZN13jaegertracing6thrift4Span10__set_tagsERKSt6vectorINS0_3TagESaIS3_EE>
  377e4e:	e9 cd 71 db ff                                  	jmp    12f020 <_ZN13jaegertracing6thrift4Span15__set_startTimeEl>
  377e53:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377e5d:	0f 1f 00                                        	nopl   (%rax)
  377e60:	0f 18 3d b9 6d db ff                            	prefetchit0 -0x249247(%rip)        # 12ec20 <_ZN13jaegertracing6thrift7SpanRefC1ERKS1_>
  377e67:	0f 18 3d d2 6d db ff                            	prefetchit0 -0x24922e(%rip)        # 12ec40 <_ZN13jaegertracing6thrift7SpanRefC1ERKS1_+0x20>
  377e6e:	e9 fd 22 e7 ff                                  	jmp    1ea170 <_Znwm>
  377e73:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377e7d:	0f 1f 00                                        	nopl   (%rax)
  377e80:	0f 18 3d a9 a9 db ff                            	prefetchit0 -0x245657(%rip)        # 132830 <_ZNSt6vectorIN13jaegertracing6thrift7SpanRefESaIS2_EEaSERKS4_>
  377e87:	0f 18 3d b2 67 db ff                            	prefetchit0 -0x24984e(%rip)        # 12e640 <_ZN13jaegertracing6thrift7SpanRefD1Ev>
  377e8e:	e9 ed 67 db ff                                  	jmp    12e680 <_ZN13jaegertracing6thrift7SpanRef13__set_refTypeENS0_11SpanRefType4typeE>
  377e93:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377e9d:	0f 1f 00                                        	nopl   (%rax)
  377ea0:	0f 18 3d f9 89 d3 ff                            	prefetchit0 -0x2c7607(%rip)        # b08a0 <_ZN6apache6thrift9transport17TVirtualTransportINS1_13TMemoryBufferENS1_11TBufferBaseEE10write_virtEPKhj>
  377ea7:	0f 18 3d 22 4b d9 ff                            	prefetchit0 -0x26b4de(%rip)        # 10c9d0 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE13writeI64_virtEl>
  377eae:	0f 18 3d 4f 55 d9 ff                            	prefetchit0 -0x26aab1(%rip)        # 10d404 <_ZN6apache6thrift8protocol17TCompactProtocolTINS0_9transport10TTransportEE15writeFieldBeginEPKcNS1_5TTypeEs+0x34>
  377eb5:	e9 b6 22 e7 ff                                  	jmp    1ea170 <_Znwm>
  377eba:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  377ec0:	0f 18 3d 79 51 d9 ff                            	prefetchit0 -0x26ae87(%rip)        # 10d040 <_ZNSt11_Deque_baseIsSaIsEE17_M_initialize_mapEm>
  377ec7:	e9 24 45 d9 ff                                  	jmp    10c3f0 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEEC2ESt10shared_ptrIS5_E>
  377ecc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377ed0:	0f 18 3d 59 15 d3 ff                            	prefetchit0 -0x2ceaa7(%rip)        # a9430 <_ZN6apache6thrift8protocol9TProtocolD1Ev>
  377ed7:	e9 d4 e5 cb ff                                  	jmp    364b0 <free@plt>
  377edc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377ee0:	0f 18 3d 9d 41 d9 ff                            	prefetchit0 -0x26be63(%rip)        # 10c084 <_ZN6apache6thrift8protocol24TCompactProtocolFactoryTINS0_9transport10TTransportEE11getProtocolESt10shared_ptrIS4_E+0x1a4>
  377ee7:	e9 84 22 e7 ff                                  	jmp    1ea170 <_Znwm>
  377eec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377ef0:	0f 18 3d a9 7a db ff                            	prefetchit0 -0x248557(%rip)        # 12f9a0 <_ZNK13jaegertracing6thrift4Span5writeEPN6apache6thrift8protocol9TProtocolE>
  377ef7:	e9 34 52 d9 ff                                  	jmp    10d130 <_ZNSt11_Deque_baseIsSaIsEE15_M_create_nodesEPPsS3_>
  377efc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377f00:	0f 18 3d 89 39 dc ff                            	prefetchit0 -0x23c677(%rip)        # 13b890 <_ZN13jaegertracing4SpanD0Ev>
  377f07:	e9 24 ff e7 ff                                  	jmp    1f7e30 <_ZNSt18condition_variable10notify_oneEv>
  377f0c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377f10:	0f 18 3d 09 26 d9 ff                            	prefetchit0 -0x26d9f7(%rip)        # 10a520 <_ZNK13jaegertracing4Span6thriftEv>
  377f17:	0f 18 3d ed 1b d9 ff                            	prefetchit0 -0x26e413(%rip)        # 109b0b <_ZN13jaegertracing12UDPTransport6appendERKNS_4SpanE+0x46b>
  377f1e:	0f 18 3d 9e 17 d9 ff                            	prefetchit0 -0x26e862(%rip)        # 1096c3 <_ZN13jaegertracing12UDPTransport6appendERKNS_4SpanE+0x23>
  377f25:	e9 36 d9 da ff                                  	jmp    125860 <_ZN13jaegertracing9reporters14RemoteReporter8sendSpanERKNS_4SpanE>
  377f2a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  377f30:	41 53                                           	push   %r11
  377f32:	4c 8b 1d df 85 ff ff                            	mov    -0x7a21(%rip),%r11        # 370518 <pthread_cond_clockwait@GLIBC_2.34>
  377f39:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  377f41:	41 0f 18 93 23 00 00 00                         	prefetcht1 0x23(%r11)
  377f49:	41 0f 18 93 63 00 00 00                         	prefetcht1 0x63(%r11)
  377f51:	41 5b                                           	pop    %r11
  377f53:	e9 28 ed cb ff                                  	jmp    36c80 <pthread_mutex_unlock@plt>
  377f58:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  377f60:	0f 18 3d 79 d7 da ff                            	prefetchit0 -0x252887(%rip)        # 1256e0 <_ZN13jaegertracing9reporters14RemoteReporter10sweepQueueEv+0xb0>
  377f67:	0f 18 3d 22 4d cf ff                            	prefetchit0 -0x30b2de(%rip)        # 6cc90 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_>
  377f6e:	0f 18 3d ab c8 d8 ff                            	prefetchit0 -0x273755(%rip)        # 104820 <_ZN13jaegertracing11SpanContextC2ERKS0_>
  377f75:	e9 26 cc e7 ff                                  	jmp    1f4ba0 <_ZNSt6chrono3_V212steady_clock3nowEv>
  377f7a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  377f80:	0f 18 3d c9 26 ef ff                            	prefetchit0 -0x10d937(%rip)        # 26a650 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_>
  377f87:	0f 18 3d f3 47 cf ff                            	prefetchit0 -0x30b80d(%rip)        # 6c781 <_ZN13jaegertracing11SpanContext4swapERS0_+0x51>
  377f8e:	e9 7d db da ff                                  	jmp    125b10 <_ZN13jaegertracing4SpanC2ERKS0_>
  377f93:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377f9d:	0f 1f 00                                        	nopl   (%rax)
  377fa0:	0f 18 3d f9 16 d9 ff                            	prefetchit0 -0x26e907(%rip)        # 1096a0 <_ZN13jaegertracing12UDPTransport6appendERKNS_4SpanE>
  377fa7:	e9 24 06 e7 ff                                  	jmp    1e85d0 <_ZdlPv>
  377fac:	0f 1f 40 00                                     	nopl   0x0(%rax)
  377fb0:	0f 18 3d 79 47 cf ff                            	prefetchit0 -0x30b887(%rip)        # 6c730 <_ZN13jaegertracing11SpanContext4swapERS0_>
  377fb7:	0f 18 3d 52 e1 cb ff                            	prefetchit0 -0x341eae(%rip)        # 36110 <memset@plt>
  377fbe:	0f 18 3d 7e c8 d8 ff                            	prefetchit0 -0x273782(%rip)        # 104843 <_ZN13jaegertracing11SpanContextC2ERKS0_+0x23>
  377fc5:	e9 96 ec cb ff                                  	jmp    36c60 <pthread_mutex_trylock@plt>
  377fca:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  377fd0:	0f 18 3d 89 09 ef ff                            	prefetchit0 -0x10f677(%rip)        # 268960 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_assignERKS4_>
  377fd7:	0f 18 3d a2 09 ef ff                            	prefetchit0 -0x10f65e(%rip)        # 268980 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_assignERKS4_+0x20>
  377fde:	e9 2d e1 cb ff                                  	jmp    36110 <memset@plt>
  377fe3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  377fed:	0f 1f 00                                        	nopl   (%rax)
  377ff0:	0f 18 3d 49 e4 da ff                            	prefetchit0 -0x251bb7(%rip)        # 126440 <_ZNSt6vectorIN13jaegertracing9LogRecordESaIS1_EEaSERKS3_>
  377ff7:	0f 18 3d 42 eb da ff                            	prefetchit0 -0x2514be(%rip)        # 126b40 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE20_M_allocate_and_copyIN9__gnu_cxx17__normal_iteratorIPKS1_S3_EEEEPS1_mT_SB_>
  377ffe:	0f 18 3d 0b e1 d8 ff                            	prefetchit0 -0x271ef5(%rip)        # 106110 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EEaSERKS3_>
  378005:	0f 18 3d f5 e5 da ff                            	prefetchit0 -0x251a0b(%rip)        # 126601 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EEaSERKS3_+0x31>
  37800c:	0f 18 3d ae e5 da ff                            	prefetchit0 -0x251a52(%rip)        # 1265c1 <_ZNSt6vectorIN13jaegertracing9LogRecordESaIS1_EEaSERKS3_+0x181>
  378013:	e9 48 09 ef ff                                  	jmp    268960 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_assignERKS4_>
  378018:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  378020:	0f 18 3d db 29 dc ff                            	prefetchit0 -0x23d625(%rip)        # 13aa02 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE+0x12>
  378027:	0f 18 3d 02 fe e7 ff                            	prefetchit0 -0x1801fe(%rip)        # 1f7e30 <_ZNSt18condition_variable10notify_oneEv>
  37802e:	0f 18 3d bb 29 dc ff                            	prefetchit0 -0x23d645(%rip)        # 13a9f0 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE>
  378035:	e9 46 ec cb ff                                  	jmp    36c80 <pthread_mutex_unlock@plt>
  37803a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  378040:	0f 18 3d c0 b2 d0 ff                            	prefetchit0 -0x2f4d40(%rip)        # 83307 <_ZNSt13__future_base13_State_baseV29_M_do_setEPSt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEPb+0x17>
  378047:	0f 18 3d 36 3b ef ff                            	prefetchit0 -0x10c4ca(%rip)        # 26bb84 <execute_native_thread_routine+0x14>
  37804e:	0f 18 3d ff ea cd ff                            	prefetchit0 -0x321501(%rip)        # 56b54 <_ZNSt13__future_base17_Async_state_implINSt6thread8_InvokerISt5tupleIJZN13media_service13RatingHandler12UploadRatingElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapISB_SB_St4lessISB_ESaISt4pairISC_SB_EEEE3$_1EEEEvE6_M_runEv+0x44>
  378055:	0f 18 3d 44 35 cf ff                            	prefetchit0 -0x30cabc(%rip)        # 6b5a0 <_ZN13jaegertracing11SpanContextD0Ev>
  37805c:	0f 18 3d 04 b1 d0 ff                            	prefetchit0 -0x2f4efc(%rip)        # 83167 <_ZNSt13__future_base13_State_baseV213_M_set_resultESt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEb+0x97>
  378063:	e9 a8 e0 cb ff                                  	jmp    36110 <memset@plt>
  378068:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  378070:	0f 18 3d 1c fc d8 ff                            	prefetchit0 -0x2703e4(%rip)        # 107c93 <_ZNSt12_Destroy_auxILb0EE9__destroyIPN13jaegertracing9ReferenceEEEvT_S5_+0x3>
  378077:	0f 18 3d 04 eb da ff                            	prefetchit0 -0x2514fc(%rip)        # 126b82 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE20_M_allocate_and_copyIN9__gnu_cxx17__normal_iteratorIPKS1_S3_EEEEPS1_mT_SB_+0x42>
  37807e:	e9 bd ea da ff                                  	jmp    126b40 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE20_M_allocate_and_copyIN9__gnu_cxx17__normal_iteratorIPKS1_S3_EEEEPS1_mT_SB_>
  378083:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37808d:	0f 1f 00                                        	nopl   (%rax)
  378090:	0f 18 3d e9 ee da ff                            	prefetchit0 -0x251117(%rip)        # 126f80 <_ZNSt5dequeIN13jaegertracing4SpanESaIS1_EE16_M_push_back_auxIJRKS1_EEEvDpOT_+0xc0>
  378097:	e9 84 c7 d8 ff                                  	jmp    104820 <_ZN13jaegertracing11SpanContextC2ERKS0_>
  37809c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3780a0:	0f 18 3d 79 c7 d8 ff                            	prefetchit0 -0x273887(%rip)        # 104820 <_ZN13jaegertracing11SpanContextC2ERKS0_>
  3780a7:	0f 18 3d e2 4b cf ff                            	prefetchit0 -0x30b41e(%rip)        # 6cc90 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_>
  3780ae:	0f 18 3d 8c 46 cf ff                            	prefetchit0 -0x30b974(%rip)        # 6c741 <_ZN13jaegertracing11SpanContext4swapERS0_+0x11>
  3780b5:	0f 18 3d c7 c7 d8 ff                            	prefetchit0 -0x273839(%rip)        # 104883 <_ZN13jaegertracing11SpanContextC2ERKS0_+0x63>
  3780bc:	0f 18 3d 8d 25 ef ff                            	prefetchit0 -0x10da73(%rip)        # 26a650 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_>
  3780c3:	0f 18 3d b7 46 cf ff                            	prefetchit0 -0x30b949(%rip)        # 6c781 <_ZN13jaegertracing11SpanContext4swapERS0_+0x51>
  3780ca:	0f 18 3d f2 25 ef ff                            	prefetchit0 -0x10da0e(%rip)        # 26a6c3 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_+0x73>
  3780d1:	e9 3a da da ff                                  	jmp    125b10 <_ZN13jaegertracing4SpanC2ERKS0_>
  3780d6:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3780e0:	0f 18 3d 39 6e db ff                            	prefetchit0 -0x2491c7(%rip)        # 12ef20 <_ZN13jaegertracing6thrift4SpanD1Ev>
  3780e7:	0f 18 3d 54 6d db ff                            	prefetchit0 -0x2492ac(%rip)        # 12ee42 <_ZN13jaegertracing6thrift4SpanD2Ev+0x12>
  3780ee:	e9 3d a7 db ff                                  	jmp    132830 <_ZNSt6vectorIN13jaegertracing6thrift7SpanRefESaIS2_EEaSERKS4_>
  3780f3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3780fd:	0f 1f 00                                        	nopl   (%rax)
  378100:	0f 18 3d 59 11 cf ff                            	prefetchit0 -0x30eea7(%rip)        # 69260 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EED2Ev>
  378107:	e9 84 ea cb ff                                  	jmp    36b90 <pthread_mutex_lock@plt>
  37810c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  378110:	0f 18 3d a9 ed da ff                            	prefetchit0 -0x251257(%rip)        # 126ec0 <_ZNSt5dequeIN13jaegertracing4SpanESaIS1_EE16_M_push_back_auxIJRKS1_EEEvDpOT_>
  378117:	0f 18 3d 22 aa ce ff                            	prefetchit0 -0x3155de(%rip)        # 62b40 <_ZN13jaegertracing7metrics11NullCounter3incEl>
  37811e:	0f 18 3d 8b d2 da ff                            	prefetchit0 -0x252d75(%rip)        # 1253b0 <_ZN13jaegertracing9reporters14RemoteReporter6reportERKNS_4SpanE>
  378125:	0f 18 3d 54 3e dc ff                            	prefetchit0 -0x23c1ac(%rip)        # 13bf80 <_ZNK13jaegertracing4Span7contextEv>
  37812c:	0f 18 3d 3d 20 e7 ff                            	prefetchit0 -0x18dfc3(%rip)        # 1ea170 <_Znwm>
  378133:	0f 18 3d c8 ed da ff                            	prefetchit0 -0x251238(%rip)        # 126f02 <_ZNSt5dequeIN13jaegertracing4SpanESaIS1_EE16_M_push_back_auxIJRKS1_EEEvDpOT_+0x42>
  37813a:	e9 41 eb cb ff                                  	jmp    36c80 <pthread_mutex_unlock@plt>
  37813f:	90                                              	nop
  378140:	0f 18 3d 19 78 df ff                            	prefetchit0 -0x2087e7(%rip)        # 16f960 <_ZN9cpp_redis6client16unprotected_sendERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS7_EERKSt8functionIFvRNS_5replyEEE>
  378147:	0f 18 3d e2 7b df ff                            	prefetchit0 -0x20841e(%rip)        # 16fd30 <_ZN9cpp_redis6client4sendERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS7_EERKSt8functionIFvRNS_5replyEEE>
  37814e:	e9 4d eb cb ff                                  	jmp    36ca0 <memcpy@plt>
  378153:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37815d:	0f 1f 00                                        	nopl   (%rax)
  378160:	0f 18 3d d9 e2 e4 ff                            	prefetchit0 -0x1b1d27(%rip)        # 1c6440 <_ZN9cpp_redis7network16redis_connection4sendERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS8_EE>
  378167:	0f 18 3d c1 e1 e4 ff                            	prefetchit0 -0x1b1e3f(%rip)        # 1c632f <_ZN9cpp_redis7network16redis_connection13build_commandERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS8_EE+0x77f>
  37816e:	0f 18 3d cc e1 e4 ff                            	prefetchit0 -0x1b1e34(%rip)        # 1c6341 <_ZN9cpp_redis7network16redis_connection13build_commandERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS8_EE+0x791>
  378175:	e9 76 04 ef ff                                  	jmp    2685f0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm>
  37817a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  378180:	0f 18 3d 69 b1 d0 ff                            	prefetchit0 -0x2f4e97(%rip)        # 832f0 <_ZNSt13__future_base13_State_baseV29_M_do_setEPSt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEPb>
  378187:	e9 44 04 e7 ff                                  	jmp    1e85d0 <_ZdlPv>
  37818c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  378190:	0f 18 3d a9 2a e4 ff                            	prefetchit0 -0x1bd557(%rip)        # 1bac40 <_ZZNSt9once_flag18_Prepare_executionC4IZSt9call_onceIMNSt13__future_base13_State_baseV2EFvPSt8functionIFSt10unique_ptrINS3_12_Result_baseENS7_8_DeleterEEvEEPbEJPS4_SC_SD_EEvRS_OT_DpOT0_EUlvE_EERSI_ENUlvE_4_FUNEv>
  378197:	e9 e4 ea cb ff                                  	jmp    36c80 <pthread_mutex_unlock@plt>
  37819c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3781a0:	0f 18 3d 49 3b e4 ff                            	prefetchit0 -0x1bc4b7(%rip)        # 1bbcf0 <_ZNSt23_Sp_counted_ptr_inplaceISt7promiseIN9cpp_redis5replyEESaIS3_ELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv>
  3781a7:	0f 18 3d 53 3b e4 ff                            	prefetchit0 -0x1bc4ad(%rip)        # 1bbd01 <_ZNSt23_Sp_counted_ptr_inplaceISt7promiseIN9cpp_redis5replyEESaIS3_ELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv+0x11>
  3781ae:	41 53                                           	push   %r11
  3781b0:	4c 8b 1d 59 84 ff ff                            	mov    -0x7ba7(%rip),%r11        # 370610 <pthread_cond_broadcast@GLIBC_2.3.2>
  3781b7:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3781bf:	41 0f 18 93 12 00 00 00                         	prefetcht1 0x12(%r11)
  3781c7:	41 5b                                           	pop    %r11
  3781c9:	e9 c2 e9 cb ff                                  	jmp    36b90 <pthread_mutex_lock@plt>
  3781ce:	66 90                                           	xchg   %ax,%ax
  3781d0:	0f 18 3d 59 3a e4 ff                            	prefetchit0 -0x1bc5a7(%rip)        # 1bbc30 <_ZNSt13__future_base7_ResultIN9cpp_redis5replyEE10_M_destroyEv>
  3781d7:	e9 a4 ea cb ff                                  	jmp    36c80 <pthread_mutex_unlock@plt>
  3781dc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3781e0:	0f 18 3d 99 17 ef ff                            	prefetchit0 -0x10e867(%rip)        # 269980 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm>
  3781e7:	0f 18 3d ca e0 e4 ff                            	prefetchit0 -0x1b1f36(%rip)        # 1c62b8 <_ZN9cpp_redis7network16redis_connection13build_commandERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS8_EE+0x708>
  3781ee:	e9 4d e2 e4 ff                                  	jmp    1c6440 <_ZN9cpp_redis7network16redis_connection4sendERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS8_EE>
  3781f3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3781fd:	0f 1f 00                                        	nopl   (%rax)
  378200:	0f 18 3d e9 17 e0 ff                            	prefetchit0 -0x1fe817(%rip)        # 1799f0 <_ZN9cpp_redis6client6incrbyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt8functionIFvRNS_5replyEEE+0x250>
  378207:	e9 74 ea cb ff                                  	jmp    36c80 <pthread_mutex_unlock@plt>
  37820c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  378210:	0f 18 3d ab bc de ff                            	prefetchit0 -0x214355(%rip)        # 163ec2 <_ZNSt17_Function_handlerIFRN9cpp_redis6clientERKSt8functionIFvRNS0_5replyEEEEZNS1_4incrERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEUlS9_E_E10_M_managerERSt9_Any_dataRKSL_St18_Manager_operation+0x12>
  378217:	0f 18 3d 92 bc de ff                            	prefetchit0 -0x21436e(%rip)        # 163eb0 <_ZNSt17_Function_handlerIFRN9cpp_redis6clientERKSt8functionIFvRNS0_5replyEEEEZNS1_4incrERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEUlS9_E_E10_M_managerERSt9_Any_dataRKSL_St18_Manager_operation>
  37821e:	e9 ad 03 e7 ff                                  	jmp    1e85d0 <_ZdlPv>
  378223:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37822d:	0f 1f 00                                        	nopl   (%rax)
  378230:	0f 18 3d f6 16 e0 ff                            	prefetchit0 -0x1fe90a(%rip)        # 17992d <_ZN9cpp_redis6client6incrbyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt8functionIFvRNS_5replyEEE+0x18d>
  378237:	e9 f4 a3 de ff                                  	jmp    162630 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.constprop.0>
  37823c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  378240:	0f 18 3d 49 3f e4 ff                            	prefetchit0 -0x1bc0b7(%rip)        # 1bc190 <_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv>
  378247:	e9 84 03 e7 ff                                  	jmp    1e85d0 <_ZdlPv>
  37824c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  378250:	0f 18 3d 19 bd de ff                            	prefetchit0 -0x2142e7(%rip)        # 163f70 <_ZNSt17_Function_handlerIFRN9cpp_redis6clientERKSt8functionIFvRNS0_5replyEEEEZNS1_6incrbyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiEUlS9_E_E10_M_managerERSt9_Any_dataRKSL_St18_Manager_operation>
  378257:	0f 18 3d 24 bd de ff                            	prefetchit0 -0x2142dc(%rip)        # 163f82 <_ZNSt17_Function_handlerIFRN9cpp_redis6clientERKSt8functionIFvRNS0_5replyEEEEZNS1_6incrbyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiEUlS9_E_E10_M_managerERSt9_Any_dataRKSL_St18_Manager_operation+0x12>
  37825e:	e9 6d 03 e7 ff                                  	jmp    1e85d0 <_ZdlPv>
  378263:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37826d:	0f 1f 00                                        	nopl   (%rax)
  378270:	0f 18 3d e9 5a df ff                            	prefetchit0 -0x20a517(%rip)        # 16dd60 <_ZNSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS5_EEC2ESt16initializer_listIS5_ERKS6_.constprop.0>
  378277:	0f 18 3d 03 5b df ff                            	prefetchit0 -0x20a4fd(%rip)        # 16dd81 <_ZNSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS5_EEC2ESt16initializer_listIS5_ERKS6_.constprop.0+0x21>
  37827e:	e9 0d 04 ef ff                                  	jmp    268690 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructEmc>
  378283:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37828d:	0f 1f 00                                        	nopl   (%rax)
  378290:	0f 18 3d a9 13 e0 ff                            	prefetchit0 -0x1fec57(%rip)        # 179640 <_ZN9cpp_redis6client4incrERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKSt8functionIFvRNS_5replyEEE>
  378297:	0f 18 3d e7 13 e0 ff                            	prefetchit0 -0x1fec19(%rip)        # 179685 <_ZN9cpp_redis6client4incrERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKSt8functionIFvRNS_5replyEEE+0x45>
  37829e:	e9 cd 1e e7 ff                                  	jmp    1ea170 <_Znwm>
  3782a3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3782ad:	0f 1f 00                                        	nopl   (%rax)
  3782b0:	0f 18 3d 0f 15 e0 ff                            	prefetchit0 -0x1feaf1(%rip)        # 1797c6 <_ZN9cpp_redis6client6incrbyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt8functionIFvRNS_5replyEEE+0x26>
  3782b7:	0f 18 3d c6 17 e0 ff                            	prefetchit0 -0x1fe83a(%rip)        # 179a84 <_ZN9cpp_redis6client6incrbyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt8functionIFvRNS_5replyEEE+0x2e4>
  3782be:	0f 18 3d 7b 54 df ff                            	prefetchit0 -0x20ab85(%rip)        # 16d740 <_ZNSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS5_EEC2ESt16initializer_listIS5_ERKS6_.constprop.3>
  3782c5:	0f 18 3d d4 14 e0 ff                            	prefetchit0 -0x1feb2c(%rip)        # 1797a0 <_ZN9cpp_redis6client6incrbyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt8functionIFvRNS_5replyEEE>
  3782cc:	e9 9f 1e e7 ff                                  	jmp    1ea170 <_Znwm>
  3782d1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3782db:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3782e0:	0f 18 3d 69 07 e4 ff                            	prefetchit0 -0x1bf897(%rip)        # 1b8a50 <_ZN9cpp_redis6client11sync_commitEv>
  3782e7:	e9 e4 02 e7 ff                                  	jmp    1e85d0 <_ZdlPv>
  3782ec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3782f0:	0f 18 3d 0c ee e4 ff                            	prefetchit0 -0x1b11f4(%rip)        # 1c7103 <_ZN9cpp_redis7network16redis_connection26tcp_client_receive_handlerERKNS0_16tcp_client_iface11read_resultE+0x4a3>
  3782f7:	e9 d4 02 e7 ff                                  	jmp    1e85d0 <_ZdlPv>
  3782fc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  378300:	0f 18 3d 89 f9 e4 ff                            	prefetchit0 -0x1b0677(%rip)        # 1c7c90 <_ZN9cpp_redis7network10tcp_client11async_writeERNS0_16tcp_client_iface13write_requestE>
  378307:	0f 18 3d 3a fb e4 ff                            	prefetchit0 -0x1b04c6(%rip)        # 1c7e48 <_ZN9cpp_redis7network10tcp_client11async_writeERNS0_16tcp_client_iface13write_requestE+0x1b8>
  37830e:	e9 ed e1 e4 ff                                  	jmp    1c6500 <_ZN9cpp_redis7network16redis_connection6commitEv>
  378313:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37831d:	0f 1f 00                                        	nopl   (%rax)
  378320:	41 53                                           	push   %r11
  378322:	4c 8b 1d b7 81 ff ff                            	mov    -0x7e49(%rip),%r11        # 3704e0 <pthread_cond_wait@GLIBC_2.3.2>
  378329:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  378331:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
  378339:	41 5b                                           	pop    %r11
  37833b:	e9 50 e8 cb ff                                  	jmp    36b90 <pthread_mutex_lock@plt>
  378340:	0f 18 3d a9 26 dc ff                            	prefetchit0 -0x23d957(%rip)        # 13a9f0 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE>
  378347:	0f 18 3d a2 47 dc ff                            	prefetchit0 -0x23b85e(%rip)        # 13caf0 <_ZNSt11__copy_moveILb0ELb0ESt26random_access_iterator_tagE8__copy_mIPKN11opentracing2v29LogRecordESt20back_insert_iteratorISt6vectorIN13jaegertracing9LogRecordESaISB_EEEEET0_T_SG_SF_>
  37834e:	0f 18 3d 4b c8 e7 ff                            	prefetchit0 -0x1837b5(%rip)        # 1f4ba0 <_ZNSt6chrono3_V212steady_clock3nowEv>
  378355:	0f 18 3d 34 e8 cb ff                            	prefetchit0 -0x3417cc(%rip)        # 36b90 <pthread_mutex_lock@plt>
  37835c:	0f 18 3d 20 ed cd ff                            	prefetchit0 -0x3212e0(%rip)        # 57083 <_ZNSt17_Function_handlerIFSt10unique_ptrINSt13__future_base12_Result_baseENS2_8_DeleterEEvENS1_12_Task_setterIS0_INS1_7_ResultIvEES3_ENSt6thread8_InvokerISt5tupleIJZN13media_service13RatingHandler12UploadRatingElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapISK_SK_St4lessISK_ESaISt4pairISL_SK_EEEE3$_1EEEEvEEE9_M_invokeERKSt9_Any_data+0x3a3>
  378363:	0f 18 3d 98 26 dc ff                            	prefetchit0 -0x23d968(%rip)        # 13aa02 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE+0x12>
  37836a:	e9 11 e9 cb ff                                  	jmp    36c80 <pthread_mutex_unlock@plt>
  37836f:	90                                              	nop
  378370:	0f 18 3d 4a 76 df ff                            	prefetchit0 -0x2089b6(%rip)        # 16f9c1 <_ZN9cpp_redis6client16unprotected_sendERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS7_EERKSt8functionIFvRNS_5replyEEE+0x61>
  378377:	0f 18 3d c2 14 e3 ff                            	prefetchit0 -0x1ceb3e(%rip)        # 1a9840 <_ZNSt17_Function_handlerIFvRN9cpp_redis5replyEEZNS0_6client8exec_cmdERKSt8functionIFRS4_RKS5_IS3_EEEEUlS2_E_E10_M_managerERSt9_Any_dataRKSG_St18_Manager_operation>
  37837e:	e9 6d 02 ef ff                                  	jmp    2685f0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm>
  378383:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37838d:	0f 1f 00                                        	nopl   (%rax)
  378390:	0f 18 3d 6b 77 df ff                            	prefetchit0 -0x208895(%rip)        # 16fb02 <_ZN9cpp_redis6client16unprotected_sendERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS7_EERKSt8functionIFvRNS_5replyEEE+0x1a2>
  378397:	e9 04 e9 cb ff                                  	jmp    36ca0 <memcpy@plt>
  37839c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3783a0:	0f 18 3d 49 fc e4 ff                            	prefetchit0 -0x1b03b7(%rip)        # 1c7ff0 <_ZNK9cpp_redis8builders13reply_builder15reply_availableEv>
  3783a7:	0f 18 3d 54 fc e4 ff                            	prefetchit0 -0x1b03ac(%rip)        # 1c8002 <_ZNK9cpp_redis8builders13reply_builder15reply_availableEv+0x12>
  3783ae:	e9 7d a2 de ff                                  	jmp    162630 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.constprop.0>
  3783b3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3783bd:	0f 1f 00                                        	nopl   (%rax)
  3783c0:	0f 18 3d 63 de e4 ff                            	prefetchit0 -0x1b219d(%rip)        # 1c622a <_ZN9cpp_redis7network16redis_connection13build_commandERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS8_EE+0x67a>
  3783c7:	e9 c4 02 ef ff                                  	jmp    268690 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructEmc>
  3783cc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3783d0:	0f 18 3d f9 31 e4 ff                            	prefetchit0 -0x1bce07(%rip)        # 1bb5d0 <_ZNSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS5_EEC1ERKS7_>
  3783d7:	e9 f4 01 e7 ff                                  	jmp    1e85d0 <_ZdlPv>
  3783dc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3783e0:	0f 18 3d 19 70 e5 ff                            	prefetchit0 -0x1a8fe7(%rip)        # 1cf400 <_ZN7tacopie10tcp_client11async_writeERKNS0_13write_requestE>
  3783e7:	0f 18 3d 55 4b e5 ff                            	prefetchit0 -0x1ab4ab(%rip)        # 1ccf43 <_ZN7tacopie10io_service15set_wr_callbackERKNS_10tcp_socketERKSt8functionIFviEE+0x23>
  3783ee:	0f 18 3d 2b 4b e5 ff                            	prefetchit0 -0x1ab4d5(%rip)        # 1ccf20 <_ZN7tacopie10io_service15set_wr_callbackERKNS_10tcp_socketERKSt8functionIFviEE>
  3783f5:	e9 a6 e8 cb ff                                  	jmp    36ca0 <memcpy@plt>
  3783fa:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  378400:	0f 18 3d 09 fa e7 ff                            	prefetchit0 -0x1805f7(%rip)        # 1f7e10 <_ZNSt18condition_variable4waitERSt11unique_lockISt5mutexE>
  378407:	e9 c4 01 e7 ff                                  	jmp    1e85d0 <_ZdlPv>
  37840c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  378410:	0f 18 3d ab 4e e4 ff                            	prefetchit0 -0x1bb155(%rip)        # 1bd2c2 <_ZN9cpp_redis5replyC1Ev+0x12>
  378417:	0f 18 3d 12 13 e5 ff                            	prefetchit0 -0x1aecee(%rip)        # 1c9730 <_ZN9cpp_redis8builders14create_builderEc>
  37841e:	0f 18 3d 1d 0b e5 ff                            	prefetchit0 -0x1af4e3(%rip)        # 1c8f42 <_ZN9cpp_redis8builders13reply_builder11build_replyEv+0x32>
  378425:	0f 18 3d b4 22 e5 ff                            	prefetchit0 -0x1add4c(%rip)        # 1ca6e0 <_ZN9cpp_redis8builders15integer_builderC1Ev>
  37842c:	0f 18 3d 7d 07 ef ff                            	prefetchit0 -0x10f883(%rip)        # 268bb0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE8_M_eraseEmm>
  378433:	0f 18 3d d6 0a e5 ff                            	prefetchit0 -0x1af52a(%rip)        # 1c8f10 <_ZN9cpp_redis8builders13reply_builder11build_replyEv>
  37843a:	0f 18 3d 6f 4e e4 ff                            	prefetchit0 -0x1bb191(%rip)        # 1bd2b0 <_ZN9cpp_redis5replyC1Ev>
  378441:	0f 18 3d 58 1f ef ff                            	prefetchit0 -0x10e0a8(%rip)        # 26a3a0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm>
  378448:	e9 43 0e e5 ff                                  	jmp    1c9290 <_ZN9cpp_redis8builders13reply_builderlsERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  37844d:	0f 1f 00                                        	nopl   (%rax)
  378450:	0f 18 3d 39 62 df ff                            	prefetchit0 -0x209dc7(%rip)        # 16e690 <_ZN9cpp_redis6client26connection_receive_handlerERNS_7network16redis_connectionERNS_5replyE>
  378457:	0f 18 3d b8 ed e4 ff                            	prefetchit0 -0x1b1248(%rip)        # 1c7216 <_ZN9cpp_redis7network16redis_connection26tcp_client_receive_handlerERKNS0_16tcp_client_iface11read_resultE+0x5b6>
  37845e:	0f 18 3d 5f 62 df ff                            	prefetchit0 -0x209da1(%rip)        # 16e6c4 <_ZN9cpp_redis6client26connection_receive_handlerERNS_7network16redis_connectionERNS_5replyE+0x34>
  378465:	0f 18 3d 96 62 df ff                            	prefetchit0 -0x209d6a(%rip)        # 16e702 <_ZN9cpp_redis6client26connection_receive_handlerERNS_7network16redis_connectionERNS_5replyE+0x72>
  37846c:	0f 18 3d 11 63 df ff                            	prefetchit0 -0x209cef(%rip)        # 16e784 <_ZN9cpp_redis6client26connection_receive_handlerERNS_7network16redis_connectionERNS_5replyE+0xf4>
  378473:	0f 18 3d c6 13 e3 ff                            	prefetchit0 -0x1cec3a(%rip)        # 1a9840 <_ZNSt17_Function_handlerIFvRN9cpp_redis5replyEEZNS0_6client8exec_cmdERKSt8functionIFRS4_RKS5_IS3_EEEEUlS2_E_E10_M_managerERSt9_Any_dataRKSG_St18_Manager_operation>
  37847a:	0f 18 3d 2f 28 e4 ff                            	prefetchit0 -0x1bd7d1(%rip)        # 1bacb0 <_ZNSt17_Function_handlerIFvRN9cpp_redis7network16redis_connectionERNS0_5replyEESt5_BindIFMNS0_6clientEFvS3_S5_EPS8_St12_PlaceholderILi1EESC_ILi2EEEEE9_M_invokeERKSt9_Any_dataS3_S5_>
  378481:	0f 18 3d 3a 28 e4 ff                            	prefetchit0 -0x1bd7c6(%rip)        # 1bacc2 <_ZNSt17_Function_handlerIFvRN9cpp_redis7network16redis_connectionERNS0_5replyEESt5_BindIFMNS0_6clientEFvS3_S5_EPS8_St12_PlaceholderILi1EESC_ILi2EEEEE9_M_invokeERKSt9_Any_dataS3_S5_+0x12>
  378488:	e9 c3 fb e4 ff                                  	jmp    1c8050 <_ZNK9cpp_redis8builders13reply_builder9get_frontEv>
  37848d:	0f 1f 00                                        	nopl   (%rax)
  378490:	0f 18 3d 49 49 e5 ff                            	prefetchit0 -0x1ab6b7(%rip)        # 1ccde0 <_ZN7tacopie10io_service15set_rd_callbackERKNS_10tcp_socketERKSt8functionIFviEE>
  378497:	0f 18 3d 22 8a e5 ff                            	prefetchit0 -0x1a75de(%rip)        # 1d0ec0 <_ZNK7tacopie10tcp_socket6get_fdEv>
  37849e:	e9 2d 01 e7 ff                                  	jmp    1e85d0 <_ZdlPv>
  3784a3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3784ad:	0f 1f 00                                        	nopl   (%rax)
  3784b0:	0f 18 3d 59 84 e5 ff                            	prefetchit0 -0x1a7ba7(%rip)        # 1d0910 <_ZN7tacopie10tcp_socket17check_or_set_typeENS0_4typeE>
  3784b7:	e9 b4 1c e7 ff                                  	jmp    1ea170 <_Znwm>
  3784bc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3784c0:	0f 18 3d 49 84 e5 ff                            	prefetchit0 -0x1a7bb7(%rip)        # 1d0910 <_ZN7tacopie10tcp_socket17check_or_set_typeENS0_4typeE>
  3784c7:	0f 18 3d 72 8a e5 ff                            	prefetchit0 -0x1a758e(%rip)        # 1d0f40 <_ZN7tacopie10tcp_socket4recvEm>
  3784ce:	e9 9d 1c e7 ff                                  	jmp    1ea170 <_Znwm>
  3784d3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3784dd:	0f 1f 00                                        	nopl   (%rax)
  3784e0:	0f 18 3d db 52 e5 ff                            	prefetchit0 -0x1aad25(%rip)        # 1cd7c2 <_ZNSt8__detail9_Map_baseIiSt4pairIKiN7tacopie10io_service14tracked_socketEESaIS6_ENS_10_Select1stESt8equal_toIiESt4hashIiENS_18_Mod_range_hashingENS_20_Default_ranged_hashENS_20_Prime_rehash_policyENS_17_Hashtable_traitsILb0ELb0ELb1EEELb1EEixEOi+0x32>
  3784e7:	0f 18 3d d2 89 e5 ff                            	prefetchit0 -0x1a762e(%rip)        # 1d0ec0 <_ZNK7tacopie10tcp_socket6get_fdEv>
  3784ee:	0f 18 3d 9b 52 e5 ff                            	prefetchit0 -0x1aad65(%rip)        # 1cd790 <_ZNSt8__detail9_Map_baseIiSt4pairIKiN7tacopie10io_service14tracked_socketEESaIS6_ENS_10_Select1stESt8equal_toIiESt4hashIiENS_18_Mod_range_hashingENS_20_Default_ranged_hashENS_20_Prime_rehash_policyENS_17_Hashtable_traitsILb0ELb0ELb1EEELb1EEixEOi>
  3784f5:	e9 76 1c e7 ff                                  	jmp    1ea170 <_Znwm>
  3784fa:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  378500:	0f 18 3d 29 a1 de ff                            	prefetchit0 -0x215ed7(%rip)        # 162630 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.constprop.0>
  378507:	0f 18 3d 33 a1 de ff                            	prefetchit0 -0x215ecd(%rip)        # 162641 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.constprop.0+0x11>
  37850e:	e9 4d 46 e4 ff                                  	jmp    1bcb60 <_ZN9cpp_redis5replyC1ERKS0_>
  378513:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37851d:	0f 1f 00                                        	nopl   (%rax)
  378520:	0f 18 3d 79 22 ef ff                            	prefetchit0 -0x10dd87(%rip)        # 26a7a0 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4findEPKcmm>
  378527:	0f 18 3d d3 22 ef ff                            	prefetchit0 -0x10dd2d(%rip)        # 26a801 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4findEPKcmm+0x61>
  37852e:	0f 18 3d 8b 20 e5 ff                            	prefetchit0 -0x1adf75(%rip)        # 1ca5c0 <_ZN9cpp_redis8builders15integer_builderlsERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  378535:	41 53                                           	push   %r11
  378537:	4c 8b 1d ba 7b ff ff                            	mov    -0x8446(%rip),%r11        # 3700f8 <memchr@GLIBC_2.2.5>
  37853e:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  378546:	41 5b                                           	pop    %r11
  378548:	e9 e3 11 e5 ff                                  	jmp    1c9730 <_ZN9cpp_redis8builders14create_builderEc>
  37854d:	0f 1f 00                                        	nopl   (%rax)
  378550:	0f 18 3d 09 46 e4 ff                            	prefetchit0 -0x1bb9f7(%rip)        # 1bcb60 <_ZN9cpp_redis5replyC1ERKS0_>
  378557:	0f 18 3d c2 49 e4 ff                            	prefetchit0 -0x1bb63e(%rip)        # 1bcf20 <_ZN9cpp_redis5replyC1ERKS0_+0x3c0>
  37855e:	e9 dd 4d e4 ff                                  	jmp    1bd340 <_ZN9cpp_redis5reply3setEl>
  378563:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37856d:	0f 1f 00                                        	nopl   (%rax)
  378570:	0f 18 3d 39 6b e5 ff                            	prefetchit0 -0x1a94c7(%rip)        # 1cf0b0 <_ZN7tacopie10tcp_client17on_read_availableEi>
  378577:	0f 18 3d 84 40 e5 ff                            	prefetchit0 -0x1abf7c(%rip)        # 1cc602 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_rd_eventERKiRNS2_14tracked_socketEEUlvE_E9_M_invokeERKSt9_Any_data+0x22>
  37857e:	0f 18 3d 3b 6b e5 ff                            	prefetchit0 -0x1a94c5(%rip)        # 1cf0c0 <_ZN7tacopie10tcp_client17on_read_availableEi+0x10>
  378585:	e9 e6 1b e7 ff                                  	jmp    1ea170 <_Znwm>
  37858a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  378590:	0f 18 3d 49 f3 e4 ff                            	prefetchit0 -0x1b0cb7(%rip)        # 1c78e0 <_ZNSt17_Function_handlerIFvRN7tacopie10tcp_client12write_resultEEZN9cpp_redis7network10tcp_client11async_writeERNS6_16tcp_client_iface13write_requestEEUlS3_E_E10_M_managerERSt9_Any_dataRKSD_St18_Manager_operation>
  378597:	0f 18 3d 62 41 e5 ff                            	prefetchit0 -0x1abe9e(%rip)        # 1cc700 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_wr_eventERKiRNS2_14tracked_socketEEUlvE_E9_M_invokeERKSt9_Any_data>
  37859e:	0f 18 3d ab 56 e5 ff                            	prefetchit0 -0x1aa955(%rip)        # 1cdc50 <_ZN7tacopie10tcp_client13process_writeERNS0_12write_resultE>
  3785a5:	0f 18 3d f4 6b e5 ff                            	prefetchit0 -0x1a940c(%rip)        # 1cf1a0 <_ZN7tacopie10tcp_client18on_write_availableEi>
  3785ac:	0f 18 3d 8d 70 e5 ff                            	prefetchit0 -0x1a8f73(%rip)        # 1cf640 <_ZNSt17_Function_handlerIFviESt5_BindIFMN7tacopie10tcp_clientEFviEPS3_St12_PlaceholderILi1EEEEE9_M_invokeERKSt9_Any_dataOi>
  3785b3:	0f 18 3d 16 00 e7 ff                            	prefetchit0 -0x18ffea(%rip)        # 1e85d0 <_ZdlPv>
  3785ba:	e9 b1 1b e7 ff                                  	jmp    1ea170 <_Znwm>
  3785bf:	90                                              	nop
  3785c0:	0f 18 3d 29 33 e5 ff                            	prefetchit0 -0x1accd7(%rip)        # 1cb8f0 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_wr_eventERKiRNS2_14tracked_socketEEUlvE_E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation>
  3785c7:	e9 a4 1b e7 ff                                  	jmp    1ea170 <_Znwm>
  3785cc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3785d0:	0f 18 3d 99 9c e5 ff                            	prefetchit0 -0x1a6367(%rip)        # 1d2270 <_ZNK7tacopie9self_pipe11get_read_fdEv>
  3785d7:	0f 18 3d 63 38 e5 ff                            	prefetchit0 -0x1ac79d(%rip)        # 1cbe41 <_ZN7tacopie10io_service16process_wr_eventERKiRNS0_14tracked_socketE+0x31>
  3785de:	0f 18 3d 1b e7 cb ff                            	prefetchit0 -0x3418e5(%rip)        # 36d00 <__fdelt_chk@plt>
  3785e5:	41 53                                           	push   %r11
  3785e7:	4c 8b 1d 92 7b ff ff                            	mov    -0x846e(%rip),%r11        # 370180 <read@GLIBC_2.2.5>
  3785ee:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3785f6:	4c 8b 1d 83 80 ff ff                            	mov    -0x7f7d(%rip),%r11        # 370680 <__fdelt_chk@GLIBC_2.15>
  3785fd:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  378605:	41 5b                                           	pop    %r11
  378607:	e9 84 e5 cb ff                                  	jmp    36b90 <pthread_mutex_lock@plt>
  37860c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  378610:	0f 18 3d 99 45 e5 ff                            	prefetchit0 -0x1aba67(%rip)        # 1ccbb0 <_ZN7tacopie10io_service4pollEv+0x20>
  378617:	0f 18 3d f2 37 e5 ff                            	prefetchit0 -0x1ac80e(%rip)        # 1cbe10 <_ZN7tacopie10io_service16process_wr_eventERKiRNS0_14tracked_socketE>
  37861e:	0f 18 3d eb 35 e5 ff                            	prefetchit0 -0x1aca15(%rip)        # 1cbc10 <_ZN7tacopie10io_service16process_rd_eventERKiRNS0_14tracked_socketE>
  378625:	0f 18 3d 84 70 e5 ff                            	prefetchit0 -0x1a8f7c(%rip)        # 1cf6b0 <_ZNSt17_Function_handlerIFviESt5_BindIFMN7tacopie10tcp_clientEFviEPS3_St12_PlaceholderILi1EEEEE10_M_managerERSt9_Any_dataRKSC_St18_Manager_operation>
  37862c:	0f 18 3d 0e 38 e5 ff                            	prefetchit0 -0x1ac7f2(%rip)        # 1cbe41 <_ZN7tacopie10io_service16process_wr_eventERKiRNS0_14tracked_socketE+0x31>
  378633:	0f 18 3d 87 70 e5 ff                            	prefetchit0 -0x1a8f79(%rip)        # 1cf6c1 <_ZNSt17_Function_handlerIFviESt5_BindIFMN7tacopie10tcp_clientEFviEPS3_St12_PlaceholderILi1EEEEE10_M_managerERSt9_Any_dataRKSC_St18_Manager_operation+0x11>
  37863a:	e9 c1 e6 cb ff                                  	jmp    36d00 <__fdelt_chk@plt>
  37863f:	90                                              	nop
  378640:	0f 18 3d c9 35 e5 ff                            	prefetchit0 -0x1aca37(%rip)        # 1cbc10 <_ZN7tacopie10io_service16process_rd_eventERKiRNS0_14tracked_socketE>
  378647:	e9 b4 e6 cb ff                                  	jmp    36d00 <__fdelt_chk@plt>
  37864c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  378650:	0f 18 3d 19 1b e7 ff                            	prefetchit0 -0x18e4e7(%rip)        # 1ea170 <_Znwm>
  378657:	0f 18 3d 23 1b e7 ff                            	prefetchit0 -0x18e4dd(%rip)        # 1ea181 <_Znwm+0x11>
  37865e:	e9 ad 35 e5 ff                                  	jmp    1cbc10 <_ZN7tacopie10io_service16process_rd_eventERKiRNS0_14tracked_socketE>
  378663:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37866d:	0f 1f 00                                        	nopl   (%rax)
  378670:	0f 18 3d a9 db cb ff                            	prefetchit0 -0x342457(%rip)        # 36220 <select@plt>
  378677:	41 53                                           	push   %r11
  378679:	4c 8b 1d 90 7a ff ff                            	mov    -0x8570(%rip),%r11        # 370110 <select@GLIBC_2.2.5>
  378680:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  378688:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
  378690:	41 5b                                           	pop    %r11
  378692:	e9 d9 9b e5 ff                                  	jmp    1d2270 <_ZNK7tacopie9self_pipe11get_read_fdEv>
  378697:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  3786a0:	41 53                                           	push   %r11
  3786a2:	4c 8b 1d 67 7a ff ff                            	mov    -0x8599(%rip),%r11        # 370110 <select@GLIBC_2.2.5>
  3786a9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3786b1:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
  3786b9:	41 5b                                           	pop    %r11
  3786bb:	e9 40 e6 cb ff                                  	jmp    36d00 <__fdelt_chk@plt>
  3786c0:	0f 18 3d c9 e4 cb ff                            	prefetchit0 -0x341b37(%rip)        # 36b90 <pthread_mutex_lock@plt>
  3786c7:	e9 e4 3c e5 ff                                  	jmp    1cc3b0 <_ZN7tacopie10io_service14process_eventsEv>
  3786cc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3786d0:	0f 18 3d c9 f0 e4 ff                            	prefetchit0 -0x1b0f37(%rip)        # 1c77a0 <_ZNSt17_Function_handlerIFvRN7tacopie10tcp_client12write_resultEEZN9cpp_redis7network10tcp_client11async_writeERNS6_16tcp_client_iface13write_requestEEUlS3_E_E9_M_invokeERKSt9_Any_dataS3_>
  3786d7:	e9 b4 9b e5 ff                                  	jmp    1d2290 <_ZN7tacopie9self_pipe6notifyEv>
  3786dc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3786e0:	0f 18 3d 09 ef e4 ff                            	prefetchit0 -0x1b10f7(%rip)        # 1c75f0 <_ZNSt17_Function_handlerIFvRN9cpp_redis7network16tcp_client_iface11read_resultEESt5_BindIFMNS1_16redis_connectionEFvRKS3_EPS7_St12_PlaceholderILi1EEEEE10_M_managerERSt9_Any_dataRKSI_St18_Manager_operation>
  3786e7:	e9 a4 e4 cb ff                                  	jmp    36b90 <pthread_mutex_lock@plt>
  3786ec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3786f0:	0f 18 3d 99 0b e5 ff                            	prefetchit0 -0x1af467(%rip)        # 1c9290 <_ZN9cpp_redis8builders13reply_builderlsERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  3786f7:	0f 18 3d 44 ee e4 ff                            	prefetchit0 -0x1b11bc(%rip)        # 1c7542 <_ZNSt17_Function_handlerIFvRN9cpp_redis7network16tcp_client_iface11read_resultEESt5_BindIFMNS1_16redis_connectionEFvRKS3_EPS7_St12_PlaceholderILi1EEEEE9_M_invokeERKSt9_Any_dataS4_+0x12>
  3786fe:	0f 18 3d 5b e5 e4 ff                            	prefetchit0 -0x1b1aa5(%rip)        # 1c6c60 <_ZN9cpp_redis7network16redis_connection26tcp_client_receive_handlerERKNS0_16tcp_client_iface11read_resultE>
  378705:	0f 18 3d 74 eb e4 ff                            	prefetchit0 -0x1b148c(%rip)        # 1c7280 <_ZN9cpp_redis7network16redis_connection26tcp_client_receive_handlerERKNS0_16tcp_client_iface11read_resultE+0x620>
  37870c:	0f 18 3d 1d ee e4 ff                            	prefetchit0 -0x1b11e3(%rip)        # 1c7530 <_ZNSt17_Function_handlerIFvRN9cpp_redis7network16tcp_client_iface11read_resultEESt5_BindIFMNS1_16redis_connectionEFvRKS3_EPS7_St12_PlaceholderILi1EEEEE9_M_invokeERKSt9_Any_dataS4_>
  378713:	e9 68 e5 cb ff                                  	jmp    36c80 <pthread_mutex_unlock@plt>
  378718:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  378720:	0f 18 3d 39 82 e5 ff                            	prefetchit0 -0x1a7dc7(%rip)        # 1d0960 <_ZN7tacopie10tcp_socket4sendERKSt6vectorIcSaIcEEm>
  378727:	0f 18 3d 52 82 e5 ff                            	prefetchit0 -0x1a7dae(%rip)        # 1d0980 <_ZN7tacopie10tcp_socket4sendERKSt6vectorIcSaIcEEm+0x20>
  37872e:	e9 5d e4 cb ff                                  	jmp    36b90 <pthread_mutex_lock@plt>
  378733:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37873d:	0f 1f 00                                        	nopl   (%rax)
  378740:	0f 18 3d 49 50 e5 ff                            	prefetchit0 -0x1aafb7(%rip)        # 1cd790 <_ZNSt8__detail9_Map_baseIiSt4pairIKiN7tacopie10io_service14tracked_socketEESaIS6_ENS_10_Select1stESt8equal_toIiESt4hashIiENS_18_Mod_range_hashingENS_20_Default_ranged_hashENS_20_Prime_rehash_policyENS_17_Hashtable_traitsILb0ELb0ELb1EEELb1EEixEOi>
  378747:	e9 84 fe e6 ff                                  	jmp    1e85d0 <_ZdlPv>
  37874c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  378750:	0f 18 3d 79 95 e5 ff                            	prefetchit0 -0x1a6a87(%rip)        # 1d1cd0 <_ZN7tacopie5utils11thread_poollsERKSt8functionIFvvEE>
  378757:	e9 14 1a e7 ff                                  	jmp    1ea170 <_Znwm>
  37875c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  378760:	41 53                                           	push   %r11
  378762:	4c 8b 1d 77 7d ff ff                            	mov    -0x8289(%rip),%r11        # 3704e0 <pthread_cond_wait@GLIBC_2.3.2>
  378769:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  378771:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
  378779:	41 0f 18 93 a0 01 00 00                         	prefetcht1 0x1a0(%r11)
  378781:	41 5b                                           	pop    %r11
  378783:	e9 08 e4 cb ff                                  	jmp    36b90 <pthread_mutex_lock@plt>
  378788:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  378790:	0f 18 3d 6b 31 e5 ff                            	prefetchit0 -0x1ace95(%rip)        # 1cb902 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_wr_eventERKiRNS2_14tracked_socketEEUlvE_E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation+0x12>
  378797:	0f 18 3d 12 6f e5 ff                            	prefetchit0 -0x1a90ee(%rip)        # 1cf6b0 <_ZNSt17_Function_handlerIFviESt5_BindIFMN7tacopie10tcp_clientEFviEPS3_St12_PlaceholderILi1EEEEE10_M_managerERSt9_Any_dataRKSC_St18_Manager_operation>
  37879e:	0f 18 3d cb 19 e7 ff                            	prefetchit0 -0x18e635(%rip)        # 1ea170 <_Znwm>
  3787a5:	0f 18 3d 15 6f e5 ff                            	prefetchit0 -0x1a90eb(%rip)        # 1cf6c1 <_ZNSt17_Function_handlerIFviESt5_BindIFMN7tacopie10tcp_clientEFviEPS3_St12_PlaceholderILi1EEEEE10_M_managerERSt9_Any_dataRKSC_St18_Manager_operation+0x11>
  3787ac:	e9 3f 8e e5 ff                                  	jmp    1d15f0 <_ZNK7tacopie5utils11thread_pool11should_stopEv>
  3787b1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3787bb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3787c0:	0f 18 3d 29 31 e5 ff                            	prefetchit0 -0x1aced7(%rip)        # 1cb8f0 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_wr_eventERKiRNS2_14tracked_socketEEUlvE_E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation>
  3787c7:	0f 18 3d 32 30 e5 ff                            	prefetchit0 -0x1acfce(%rip)        # 1cb800 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_rd_eventERKiRNS2_14tracked_socketEEUlvE_E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation>
  3787ce:	0f 18 3d 5b f6 e7 ff                            	prefetchit0 -0x1809a5(%rip)        # 1f7e30 <_ZNSt18condition_variable10notify_oneEv>
  3787d5:	e9 b6 e3 cb ff                                  	jmp    36b90 <pthread_mutex_lock@plt>
  3787da:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  3787e0:	0f 18 3d 29 9c e5 ff                            	prefetchit0 -0x1a63d7(%rip)        # 1d2410 <_ZN7tacopie10tcp_socket26create_socket_if_necessaryEv>
  3787e7:	0f 18 3d 42 f6 e7 ff                            	prefetchit0 -0x1809be(%rip)        # 1f7e30 <_ZNSt18condition_variable10notify_oneEv>
  3787ee:	e9 2d db cb ff                                  	jmp    36320 <malloc@plt>
  3787f3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3787fd:	0f 1f 00                                        	nopl   (%rax)
  378800:	41 53                                           	push   %r11
  378802:	4c 8b 1d 37 7e ff ff                            	mov    -0x81c9(%rip),%r11        # 370640 <pthread_mutex_unlock@GLIBC_2.2.5>
  378809:	41 0f 18 93 e0 fe ff ff                         	prefetcht1 -0x120(%r11)
  378811:	41 5b                                           	pop    %r11
  378813:	e9 a8 e1 cb ff                                  	jmp    369c0 <pthread_cond_wait@plt>
  378818:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  378820:	0f 18 3d 79 b7 ec ff                            	prefetchit0 -0x134887(%rip)        # 243fa0 <_ZSt9has_facetISt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEEEbRKSt6locale>
  378827:	e9 a4 dd ec ff                                  	jmp    2465d0 <_ZSt9use_facetISt5ctypeIcEERKT_RKSt6locale>
  37882c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  378830:	0f 18 3d 79 b6 ec ff                            	prefetchit0 -0x134987(%rip)        # 243eb0 <_ZSt9use_facetISt7num_getIcSt19istreambuf_iteratorIcSt11char_traitsIcEEEERKT_RKSt6locale>
  378837:	e9 c4 b6 ec ff                                  	jmp    243f00 <_ZSt9use_facetISt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEEERKT_RKSt6locale>
  37883c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  378840:	0f 18 3d 49 b8 d8 ff                            	prefetchit0 -0x2747b7(%rip)        # 104090 <_ZN13jaegertracing11SpanContext10fromStreamERSi>
  378847:	e9 74 50 e7 ff                                  	jmp    1ed8c0 <_ZNKSt6locale2id5_M_idEv>
  37884c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  378850:	0f 18 3d 49 68 ee ff                            	prefetchit0 -0x1197b7(%rip)        # 25f0a0 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8overflowEi>
  378857:	0f 18 3d 62 68 ee ff                            	prefetchit0 -0x11979e(%rip)        # 25f0c0 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8overflowEi+0x20>
  37885e:	0f 18 3d ab 62 ee ff                            	prefetchit0 -0x119d55(%rip)        # 25eb10 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8_M_pbumpEPcS5_l>
  378865:	0f 18 3d a4 e9 ee ff                            	prefetchit0 -0x11165c(%rip)        # 267210 <_ZNSt15basic_streambufIcSt11char_traitsIcEE6xsputnEPKcl>
  37886c:	e9 7f 17 ed ff                                  	jmp    249ff0 <_ZSt13__int_to_charIcmEiPT_T0_PKS0_St13_Ios_Fmtflagsb>
  378871:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37887b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  378880:	0f 18 3d 59 f9 ed ff                            	prefetchit0 -0x1206a7(%rip)        # 2581e0 <_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l>
  378887:	e9 f4 10 ef ff                                  	jmp    269980 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm>
  37888c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  378890:	0f 18 3d 59 4d e7 ff                            	prefetchit0 -0x18b2a7(%rip)        # 1ed5f0 <_ZNSt6localeaSERKS_>
  378897:	0f 18 3d 62 4d e7 ff                            	prefetchit0 -0x18b29e(%rip)        # 1ed600 <_ZNSt6localeaSERKS_+0x10>
  37889e:	e9 5d 1b ec ff                                  	jmp    23a400 <_ZNSt8ios_baseC1Ev>
  3788a3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3788ad:	0f 1f 00                                        	nopl   (%rax)
  3788b0:	0f 18 3d 19 0b ec ff                            	prefetchit0 -0x13f4e7(%rip)        # 2393d0 <_ZNSt9basic_iosIcSt11char_traitsIcEE15_M_cache_localeERKSt6locale>
  3788b7:	0f 18 3d 02 fe ec ff                            	prefetchit0 -0x1301fe(%rip)        # 2486c0 <_ZSt9has_facetISt5ctypeIcEEbRKSt6locale>
  3788be:	0f 18 3d 9b 1e e7 ff                            	prefetchit0 -0x18e165(%rip)        # 1ea760 <_ZNK10__cxxabiv121__vmi_class_type_info12__do_dyncastElNS_17__class_type_info10__sub_kindEPKS1_PKvS4_S6_RNS1_16__dyncast_resultE>
  3788c5:	0f 18 3d e4 23 e7 ff                            	prefetchit0 -0x18dc1c(%rip)        # 1eacb0 <_ZNK10__cxxabiv121__vmi_class_type_info12__do_dyncastElNS_17__class_type_info10__sub_kindEPKS1_PKvS4_S6_RNS1_16__dyncast_resultE+0x550>
  3788cc:	0f 18 3d ee 1e e7 ff                            	prefetchit0 -0x18e112(%rip)        # 1ea7c1 <_ZNK10__cxxabiv121__vmi_class_type_info12__do_dyncastElNS_17__class_type_info10__sub_kindEPKS1_PKvS4_S6_RNS1_16__dyncast_resultE+0x61>
  3788d3:	41 53                                           	push   %r11
  3788d5:	4c 8b 1d ac 7b ff ff                            	mov    -0x8454(%rip),%r11        # 370488 <strcmp@GLIBC_2.2.5>
  3788dc:	41 0f 18 93 a4 03 00 00                         	prefetcht1 0x3a4(%r11)
  3788e4:	41 5b                                           	pop    %r11
  3788e6:	e9 55 0f ec ff                                  	jmp    239840 <_ZNSt9basic_iosIcSt11char_traitsIcEE4initEPSt15basic_streambufIcS1_E>
  3788eb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3788f0:	0f 18 3d a9 64 ee ff                            	prefetchit0 -0x119b57(%rip)        # 25eda0 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE7_M_syncEPcmm>
  3788f7:	0f 18 3d c4 64 ee ff                            	prefetchit0 -0x119b3c(%rip)        # 25edc2 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE7_M_syncEPcmm+0x22>
  3788fe:	e9 dd 68 e7 ff                                  	jmp    1ef1e0 <_ZNSt6localeC1Ev>
  378903:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37890d:	0f 1f 00                                        	nopl   (%rax)
  378910:	0f 18 3d a9 50 ec ff                            	prefetchit0 -0x13af57(%rip)        # 23d9c0 <_ZNSi7putbackEc+0x20>
  378917:	0f 18 3d 82 50 ec ff                            	prefetchit0 -0x13af7e(%rip)        # 23d9a0 <_ZNSi7putbackEc>
  37891e:	e9 7d e3 cb ff                                  	jmp    36ca0 <memcpy@plt>
  378923:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37892d:	0f 1f 00                                        	nopl   (%rax)
  378930:	0f 18 3d 79 06 e2 ff                            	prefetchit0 -0x1df987(%rip)        # 198fb0 <_ZN9cpp_redis6client6incrbyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEi>
  378937:	0f 18 3d f2 9c de ff                            	prefetchit0 -0x21630e(%rip)        # 162630 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.constprop.0>
  37893e:	e9 5d e3 cb ff                                  	jmp    36ca0 <memcpy@plt>
  378943:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  37894d:	0f 1f 00                                        	nopl   (%rax)
  378950:	0f 18 3d 29 05 e2 ff                            	prefetchit0 -0x1dfad7(%rip)        # 198e80 <_ZN9cpp_redis6client4incrERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE+0x10>
  378957:	e9 04 01 ef ff                                  	jmp    268a60 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm>
  37895c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  378960:	0f 18 3d 49 1c e5 ff                            	prefetchit0 -0x1ae3b7(%rip)        # 1ca5b0 <_ZNK9cpp_redis8builders15integer_builder11reply_readyEv>
  378967:	e9 84 d8 cb ff                                  	jmp    361f0 <memchr@plt>
