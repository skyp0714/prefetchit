
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_native_it0/1dbfa7f16b813e7a1a18eb57cf17538bf1d051e27aeccaec8ffadd8fce258b07/MovieIdService:     file format elf64-x86-64


Disassembly of section .text.prefetch_calls:

00000000003ad380 <.text.prefetch_calls>:
  3ad380:	0f 18 3d 29 3d d1 ff                            	prefetchit0 -0x2ec2d7(%rip)        # c10b0 <_ZNK13media_service13TextMapReader10ForeachKeyESt8functionIFN11opentracing2v28expectedIvSt10error_codeEENS3_11string_viewES7_EE>
  3ad387:	0f 18 3d 12 e6 d0 ff                            	prefetchit0 -0x2f19ee(%rip)        # bb9a0 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_>
  3ad38e:	0f 18 3d 7b f0 d0 ff                            	prefetchit0 -0x2f0f85(%rip)        # bc410 <_ZNSt17_Function_handlerIFN11opentracing2v28expectedIvSt10error_codeEENS1_11string_viewES5_EZNK13jaegertracing11propagation10PropagatorIRKNS1_13TextMapReaderERKNS1_13TextMapWriterEE7extractESC_EUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESO_E_E9_M_invokeERKSt9_Any_dataOS5_SU_>
  3ad395:	0f 18 3d e4 93 e0 ff                            	prefetchit0 -0x1f6c1c(%rip)        # 1b6780 <_ZNK13jaegertracing6Tracer7ExtractERKN11opentracing2v213TextMapReaderE>
  3ad39c:	e9 0f cd e4 ff                                  	jmp    1fa0b0 <_ZN11opentracing2v26Tracer6GlobalEv>
  3ad3a1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ad3ab:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3ad3b0:	0f 18 3d 39 78 e0 ff                            	prefetchit0 -0x1f87c7(%rip)        # 1b4bf0 <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE>
  3ad3b7:	0f 18 3d 43 78 e0 ff                            	prefetchit0 -0x1f87bd(%rip)        # 1b4c01 <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE+0x11>
  3ad3be:	0f 18 3d d5 78 e0 ff                            	prefetchit0 -0x1f872b(%rip)        # 1b4c9a <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE+0xaa>
  3ad3c5:	e9 e6 cc e4 ff                                  	jmp    1fa0b0 <_ZN11opentracing2v26Tracer6GlobalEv>
  3ad3ca:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  3ad3d0:	0f 18 3d aa 1d ef ff                            	prefetchit0 -0x10e256(%rip)        # 29f181 <_ZNSt7__cxx1119basic_ostringstreamIcSt11char_traitsIcESaIcEEC1Ev+0x11>
  3ad3d7:	0f 18 3d f2 8f e0 ff                            	prefetchit0 -0x1f700e(%rip)        # 1b63d0 <_ZNK13jaegertracing6Tracer6InjectERKN11opentracing2v211SpanContextERKNS2_13TextMapWriterE>
  3ad3de:	0f 18 3d 8b 1d ef ff                            	prefetchit0 -0x10e275(%rip)        # 29f170 <_ZNSt7__cxx1119basic_ostringstreamIcSt11char_traitsIcESaIcEEC1Ev>
  3ad3e5:	e9 c6 cc e4 ff                                  	jmp    1fa0b0 <_ZN11opentracing2v26Tracer6GlobalEv>
  3ad3ea:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  3ad3f0:	41 53                                           	push   %r11
  3ad3f2:	4c 8b 1d e7 1f ff ff                            	mov    -0xe019(%rip),%r11        # 39f3e0 <memcached_pool_pop@Base>
  3ad3f9:	41 0f 18 93 a0 f0 ff ff                         	prefetcht1 -0xf60(%r11)
  3ad401:	41 0f 18 93 80 f1 ff ff                         	prefetcht1 -0xe80(%r11)
  3ad409:	41 0f 18 93 20 f3 ff ff                         	prefetcht1 -0xce0(%r11)
  3ad411:	41 5b                                           	pop    %r11
  3ad413:	e9 a8 43 ce ff                                  	jmp    917c0 <memcached_pool_pop@plt>
  3ad418:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3ad420:	41 53                                           	push   %r11
  3ad422:	4c 8b 1d 9f 21 ff ff                            	mov    -0xde61(%rip),%r11        # 39f5c8 <memcached_get@Base>
  3ad429:	41 0f 18 93 c0 fc ff ff                         	prefetcht1 -0x340(%r11)
  3ad431:	41 0f 18 93 d3 fc ff ff                         	prefetcht1 -0x32d(%r11)
  3ad439:	41 0f 18 93 11 fd ff ff                         	prefetcht1 -0x2ef(%r11)
  3ad441:	41 5b                                           	pop    %r11
  3ad443:	e9 48 47 ce ff                                  	jmp    91b90 <memcached_get@plt>
  3ad448:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3ad450:	0f 18 3d 39 c8 e3 ff                            	prefetchit0 -0x1c37c7(%rip)        # 1e9c90 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE>
  3ad457:	0f 18 3d 32 e9 e3 ff                            	prefetchit0 -0x1c16ce(%rip)        # 1ebd90 <_ZNSt11__copy_moveILb0ELb0ESt26random_access_iterator_tagE8__copy_mIPKN11opentracing2v29LogRecordESt20back_insert_iteratorISt6vectorIN13jaegertracing9LogRecordESaISB_EEEEET0_T_SG_SF_>
  3ad45e:	e9 ad 57 e8 ff                                  	jmp    232c10 <_ZNSt6chrono3_V212steady_clock3nowEv>
  3ad463:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ad46d:	0f 1f 00                                        	nopl   (%rax)
  3ad470:	0f 18 3d 29 bc de ff                            	prefetchit0 -0x2143d7(%rip)        # 1990a0 <_ZN5boost3log12v2s_mt_posix7trivial6logger3getEv>
  3ad477:	0f 18 3d 76 bc de ff                            	prefetchit0 -0x21438a(%rip)        # 1990f4 <_ZN5boost3log12v2s_mt_posix7trivial6logger3getEv+0x54>
  3ad47e:	e9 ad 48 d1 ff                                  	jmp    c1d30 <_ZNSt6vectorIN11opentracing2v29LogRecordESaIS2_EED2Ev>
  3ad483:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ad48d:	0f 1f 00                                        	nopl   (%rax)
  3ad490:	0f 18 3d 59 47 e6 ff                            	prefetchit0 -0x19b8a7(%rip)        # 211bf0 <_ZN5boost6detail12get_tss_dataEPKv>
  3ad497:	0f 18 3d 62 22 dd ff                            	prefetchit0 -0x22dd9e(%rip)        # 17f700 <_ZN5boost3log12v2s_mt_posix4core14implementation15get_thread_dataEv>
  3ad49e:	0f 18 3d ab ba de ff                            	prefetchit0 -0x214555(%rip)        # 198f50 <_ZNK5boost3log12v2s_mt_posix3aux20thread_specific_base11get_contentEv>
  3ad4a5:	0f 18 3d 04 ae cf ff                            	prefetchit0 -0x3051fc(%rip)        # a82b0 <_ZN5boost3log12v2s_mt_posix7sources22basic_composite_loggerIcNS2_18severity_logger_mtINS1_7trivial14severity_levelEEENS2_18multi_thread_modelINS1_3aux14light_rw_mutexEEENS2_8featuresIJNS2_8severityIS6_EEEEEE11open_recordINS_9parameter3aux25tagged_argument_list_of_1INSJ_15tagged_argumentINS1_8keywords3tag8severityEKS6_EEEEEENS1_6recordERKT_>
  3ad4ac:	0f 18 3d 3d e0 dc ff                            	prefetchit0 -0x231fc3(%rip)        # 17b4f0 <_ZNK5boost3log12v2s_mt_posix4core19get_logging_enabledEv>
  3ad4b3:	0f 18 3d a6 90 dd ff                            	prefetchit0 -0x226f5a(%rip)        # 186560 <_ZN5boost3log12v2s_mt_posix7sources3aux18get_severity_levelEv>
  3ad4ba:	0f 18 3d bf 90 dd ff                            	prefetchit0 -0x226f41(%rip)        # 186580 <_ZN5boost3log12v2s_mt_posix7sources3aux18get_severity_levelEv+0x20>
  3ad4c1:	0f 18 3d 08 42 e6 ff                            	prefetchit0 -0x19bdf8(%rip)        # 2116d0 <_ZN5boost6detail23get_current_thread_dataEv>
  3ad4c8:	e9 73 3b ce ff                                  	jmp    91040 <memcached_pool_push@plt>
  3ad4cd:	0f 1f 00                                        	nopl   (%rax)
  3ad4d0:	0f 18 3d c9 80 dc ff                            	prefetchit0 -0x237f37(%rip)        # 1755a0 <_ZN5boost3log12v2s_mt_posix19attribute_value_setC1ERKNS1_13attribute_setES5_S5_m>
  3ad4d7:	0f 18 3d b2 e9 dc ff                            	prefetchit0 -0x23164e(%rip)        # 17be90 <_ZN5boost3log12v2s_mt_posix4core11open_recordERKNS1_13attribute_setE>
  3ad4de:	0f 18 3d cb eb e6 ff                            	prefetchit0 -0x191435(%rip)        # 21c0b0 <_ZN5boost13thread_detail17enter_once_regionERNS_9once_flagE>
  3ad4e5:	0f 18 3d d6 80 dc ff                            	prefetchit0 -0x237f2a(%rip)        # 1755c2 <_ZN5boost3log12v2s_mt_posix19attribute_value_setC1ERKNS1_13attribute_setES5_S5_m+0x22>
  3ad4ec:	0f 18 3d cd 90 dd ff                            	prefetchit0 -0x226f33(%rip)        # 1865c0 <_ZN5boost3log12v2s_mt_posix7sources3aux18get_severity_levelEv+0x60>
  3ad4f3:	0f 18 3d 06 e0 dc ff                            	prefetchit0 -0x231ffa(%rip)        # 17b500 <_ZNK5boost3log12v2s_mt_posix4core19get_logging_enabledEv+0x10>
  3ad4fa:	41 53                                           	push   %r11
  3ad4fc:	4c 8b 1d d5 24 ff ff                            	mov    -0xdb2b(%rip),%r11        # 39f9d8 <pthread_getspecific@GLIBC_2.34>
  3ad503:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3ad50b:	41 0f 18 93 20 00 00 00                         	prefetcht1 0x20(%r11)
  3ad513:	41 5b                                           	pop    %r11
  3ad515:	e9 86 bb de ff                                  	jmp    1990a0 <_ZN5boost3log12v2s_mt_posix7trivial6logger3getEv>
  3ad51a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  3ad520:	41 53                                           	push   %r11
  3ad522:	4c 8b 1d 7f 1f ff ff                            	mov    -0xe081(%rip),%r11        # 39f4a8 <pthread_rwlock_rdlock@GLIBC_2.34>
  3ad529:	41 0f 18 93 39 00 00 00                         	prefetcht1 0x39(%r11)
  3ad531:	41 5b                                           	pop    %r11
  3ad533:	e9 78 ad cf ff                                  	jmp    a82b0 <_ZN5boost3log12v2s_mt_posix7sources22basic_composite_loggerIcNS2_18severity_logger_mtINS1_7trivial14severity_levelEEENS2_18multi_thread_modelINS1_3aux14light_rw_mutexEEENS2_8featuresIJNS2_8severityIS6_EEEEEE11open_recordINS_9parameter3aux25tagged_argument_list_of_1INSJ_15tagged_argumentINS1_8keywords3tag8severityEKS6_EEEEEENS1_6recordERKT_>
  3ad538:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3ad540:	0f 18 3d 49 93 ec ff                            	prefetchit0 -0x136cb7(%rip)        # 276890 <_ZNSt13__future_base12_Result_baseC1Ev>
  3ad547:	e9 ac 50 ce ff                                  	jmp    925f8 <free@plt>
  3ad54c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ad550:	0f 18 3d 09 c8 ef ff                            	prefetchit0 -0x1037f7(%rip)        # 2a9d60 <_ZNSt6thread15_M_start_threadESt10unique_ptrINS_6_StateESt14default_deleteIS1_EEPFvvE>
  3ad557:	41 53                                           	push   %r11
  3ad559:	4c 8b 1d 48 21 ff ff                            	mov    -0xdeb8(%rip),%r11        # 39f6a8 <pthread_cond_signal@GLIBC_2.3.2>
  3ad560:	41 0f 18 93 d0 ed ff ff                         	prefetcht1 -0x1230(%r11)
  3ad568:	4c 8b 1d 69 24 ff ff                            	mov    -0xdb97(%rip),%r11        # 39f9d8 <pthread_getspecific@GLIBC_2.34>
  3ad56f:	41 0f 18 93 50 f9 ff ff                         	prefetcht1 -0x6b0(%r11)
  3ad577:	41 0f 18 93 63 f9 ff ff                         	prefetcht1 -0x69d(%r11)
  3ad57f:	41 5b                                           	pop    %r11
  3ad581:	e9 5a ac e7 ff                                  	jmp    2281e0 <_Znwm>
  3ad586:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ad590:	41 53                                           	push   %r11
  3ad592:	4c 8b 1d 3f 24 ff ff                            	mov    -0xdbc1(%rip),%r11        # 39f9d8 <pthread_getspecific@GLIBC_2.34>
  3ad599:	41 0f 18 93 a0 f4 ff ff                         	prefetcht1 -0xb60(%r11)
  3ad5a1:	41 5b                                           	pop    %r11
  3ad5a3:	e9 38 ac e7 ff                                  	jmp    2281e0 <_Znwm>
  3ad5a8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3ad5b0:	0f 18 3d ca 67 d2 ff                            	prefetchit0 -0x2d9836(%rip)        # d3d81 <_ZNSt13__future_base21_Async_state_commonV217_M_complete_asyncEv+0x51>
  3ad5b7:	0f 18 3d 92 6d d2 ff                            	prefetchit0 -0x2d926e(%rip)        # d4350 <_ZZNSt9once_flag18_Prepare_executionC1IZSt9call_onceIMSt6threadFvvEJPS3_EEvRS_OT_DpOT0_EUlvE_EERS8_ENUlvE_8__invokeEv>
  3ad5be:	0f 18 3d 3b c7 ef ff                            	prefetchit0 -0x1038c5(%rip)        # 2a9d00 <_ZNSt6thread4joinEv>
  3ad5c5:	0f 18 3d 54 7a ee ff                            	prefetchit0 -0x1185ac(%rip)        # 295020 <__once_proxy>
  3ad5cc:	0f 18 3d 5d 67 d2 ff                            	prefetchit0 -0x2d98a3(%rip)        # d3d30 <_ZNSt13__future_base21_Async_state_commonV217_M_complete_asyncEv>
  3ad5d3:	e9 28 48 d1 ff                                  	jmp    c1e00 <_ZNKSt14__basic_futureIvE13_M_get_resultEv>
  3ad5d8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3ad5e0:	0f 18 3d 69 6d d2 ff                            	prefetchit0 -0x2d9297(%rip)        # d4350 <_ZZNSt9once_flag18_Prepare_executionC1IZSt9call_onceIMSt6threadFvvEJPS3_EEvRS_OT_DpOT0_EUlvE_EERS8_ENUlvE_8__invokeEv>
  3ad5e7:	0f 18 3d 32 7a ee ff                            	prefetchit0 -0x1185ce(%rip)        # 295020 <__once_proxy>
  3ad5ee:	0f 18 3d 3b 67 d2 ff                            	prefetchit0 -0x2d98c5(%rip)        # d3d30 <_ZNSt13__future_base21_Async_state_commonV217_M_complete_asyncEv>
  3ad5f5:	e9 06 48 d1 ff                                  	jmp    c1e00 <_ZNKSt14__basic_futureIvE13_M_get_resultEv>
  3ad5fa:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  3ad600:	0f 18 3d 19 7a ee ff                            	prefetchit0 -0x1185e7(%rip)        # 295020 <__once_proxy>
  3ad607:	0f 18 3d e2 3e ce ff                            	prefetchit0 -0x31c11e(%rip)        # 914f0 <pthread_once@plt>
  3ad60e:	0f 18 3d 1b 67 d2 ff                            	prefetchit0 -0x2d98e5(%rip)        # d3d30 <_ZNSt13__future_base21_Async_state_commonV217_M_complete_asyncEv>
  3ad615:	0f 18 3d 34 6d d2 ff                            	prefetchit0 -0x2d92cc(%rip)        # d4350 <_ZZNSt9once_flag18_Prepare_executionC1IZSt9call_onceIMSt6threadFvvEJPS3_EEvRS_OT_DpOT0_EUlvE_EERS8_ENUlvE_8__invokeEv>
  3ad61c:	e9 df 47 d1 ff                                  	jmp    c1e00 <_ZNKSt14__basic_futureIvE13_M_get_resultEv>
  3ad621:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ad62b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3ad630:	0f 18 3d f9 d4 e3 ff                            	prefetchit0 -0x1c2b07(%rip)        # 1eab30 <_ZN13jaegertracing4SpanD0Ev>
  3ad637:	0f 18 3d 72 7b e2 ff                            	prefetchit0 -0x1d848e(%rip)        # 1d51b0 <_ZN13jaegertracing4SpanD2Ev>
  3ad63e:	e9 ed 46 d1 ff                                  	jmp    c1d30 <_ZNSt6vectorIN11opentracing2v29LogRecordESaIS2_EED2Ev>
  3ad643:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ad64d:	0f 1f 00                                        	nopl   (%rax)
  3ad650:	0f 18 3d c1 1a d3 ff                            	prefetchit0 -0x2ce53f(%rip)        # df118 <_ZN13media_service23MovieIdServiceProcessor21process_UploadMovieIdEiPN6apache6thrift8protocol9TProtocolES5_Pv+0x2c8>
  3ad657:	0f 18 3d 12 89 d2 ff                            	prefetchit0 -0x2d76ee(%rip)        # d5f70 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE22writeMessageBegin_virtERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  3ad65e:	0f 18 3d 1b 94 d2 ff                            	prefetchit0 -0x2d6be5(%rip)        # d6a80 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE17writeMessageBeginERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi+0x30>
  3ad665:	0f 18 3d b4 22 db ff                            	prefetchit0 -0x24dd4c(%rip)        # 15f920 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE10write_virtEPKhj>
  3ad66c:	e9 5f 49 d1 ff                                  	jmp    c1fd0 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  3ad671:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ad67b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3ad680:	0f 18 3d 29 ca e4 ff                            	prefetchit0 -0x1b35d7(%rip)        # 1fa0b0 <_ZN11opentracing2v26Tracer6GlobalEv>
  3ad687:	0f 18 3d 32 41 ce ff                            	prefetchit0 -0x31bece(%rip)        # 917c0 <memcached_pool_pop@plt>
  3ad68e:	0f 18 3d 8b 79 ee ff                            	prefetchit0 -0x118675(%rip)        # 295020 <__once_proxy>
  3ad695:	0f 18 3d 54 3e ce ff                            	prefetchit0 -0x31c1ac(%rip)        # 914f0 <pthread_once@plt>
  3ad69c:	0f 18 3d 1f 6b d2 ff                            	prefetchit0 -0x2d94e1(%rip)        # d41c2 <_ZZNSt9once_flag18_Prepare_executionC1IZSt9call_onceIMNSt13__future_base13_State_baseV2EFvPSt8functionIFSt10unique_ptrINS3_12_Result_baseENS7_8_DeleterEEvEEPbEJPS4_SC_SD_EEvRS_OT_DpOT0_EUlvE_EERSI_ENUlvE_8__invokeEv+0x12>
  3ad6a3:	0f 18 3d a6 92 cf ff                            	prefetchit0 -0x306d5a(%rip)        # a6950 <_ZNSt17_Function_handlerIFSt10unique_ptrINSt13__future_base12_Result_baseENS2_8_DeleterEEvENS1_12_Task_setterIS0_INS1_7_ResultIvEES3_ENSt6thread8_InvokerISt5tupleIJZN13media_service14MovieIdHandler13UploadMovieIdElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapISK_SK_St4lessISK_ESaISt4pairISL_SK_EEEE3$_0EEEEvEEE9_M_invokeERKSt9_Any_data>
  3ad6aa:	e9 91 68 d2 ff                                  	jmp    d3f40 <_ZNSt13__future_base13_State_baseV213_M_set_resultESt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEb>
  3ad6af:	90                                              	nop
  3ad6b0:	0f 18 3d 19 c0 cf ff                            	prefetchit0 -0x303fe7(%rip)        # a96d0 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  3ad6b7:	0f 18 3d 72 44 d1 ff                            	prefetchit0 -0x2ebb8e(%rip)        # c1b30 <_ZNK11opentracing2v213SpanReference5ApplyERNS0_16StartSpanOptionsE>
  3ad6be:	0f 18 3d 9b 3d ce ff                            	prefetchit0 -0x31c265(%rip)        # 91460 <pthread_mutex_unlock@plt>
  3ad6c5:	0f 18 3d 54 db e3 ff                            	prefetchit0 -0x1c24ac(%rip)        # 1eb220 <_ZNK13jaegertracing4Span7contextEv>
  3ad6cc:	e9 ef 40 ce ff                                  	jmp    917c0 <memcached_pool_pop@plt>
  3ad6d1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ad6db:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3ad6e0:	0f 18 3d f9 aa e7 ff                            	prefetchit0 -0x185507(%rip)        # 2281e0 <_Znwm>
  3ad6e7:	0f 18 3d 1a 4f ce ff                            	prefetchit0 -0x31b0e6(%rip)        # 92608 <malloc@plt>
  3ad6ee:	41 53                                           	push   %r11
  3ad6f0:	4c 8b 1d 39 17 ff ff                            	mov    -0xe8c7(%rip),%r11        # 39ee30 <malloc@GLIBC_2.2.5>
  3ad6f7:	41 0f 18 93 f0 bf ff ff                         	prefetcht1 -0x4010(%r11)
  3ad6ff:	41 0f 18 93 22 c0 ff ff                         	prefetcht1 -0x3fde(%r11)
  3ad707:	41 5b                                           	pop    %r11
  3ad709:	e9 a2 c9 e4 ff                                  	jmp    1fa0b0 <_ZN11opentracing2v26Tracer6GlobalEv>
  3ad70e:	66 90                                           	xchg   %ax,%ax
  3ad710:	41 53                                           	push   %r11
  3ad712:	4c 8b 1d 1f 1e ff ff                            	mov    -0xe1e1(%rip),%r11        # 39f538 <memcached_set@Base>
  3ad719:	41 0f 18 93 30 fb ff ff                         	prefetcht1 -0x4d0(%r11)
  3ad721:	41 5b                                           	pop    %r11
  3ad723:	e9 48 43 ce ff                                  	jmp    91a70 <memcached_set@plt>
  3ad728:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3ad730:	0f 18 3d f9 d3 e3 ff                            	prefetchit0 -0x1c2c07(%rip)        # 1eab30 <_ZN13jaegertracing4SpanD0Ev>
  3ad737:	e9 f4 45 d1 ff                                  	jmp    c1d30 <_ZNSt6vectorIN11opentracing2v29LogRecordESaIS2_EED2Ev>
  3ad73c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ad740:	41 53                                           	push   %r11
  3ad742:	4c 8b 1d 5f 1f ff ff                            	mov    -0xe0a1(%rip),%r11        # 39f6a8 <pthread_cond_signal@GLIBC_2.3.2>
  3ad749:	41 0f 18 93 e0 e3 ff ff                         	prefetcht1 -0x1c20(%r11)
  3ad751:	4c 8b 1d 58 21 ff ff                            	mov    -0xdea8(%rip),%r11        # 39f8b0 <isupper@GLIBC_2.2.5>
  3ad758:	41 0f 18 93 10 bd 00 00                         	prefetcht1 0xbd10(%r11)
  3ad760:	41 5b                                           	pop    %r11
  3ad762:	e9 69 c5 ef ff                                  	jmp    2a9cd0 <_ZNSt6thread6_StateD1Ev>
  3ad767:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  3ad770:	0f 18 3d b9 20 db ff                            	prefetchit0 -0x24df47(%rip)        # 15f830 <_ZN6apache6thrift9transport16TFramedTransport6isOpenEv>
  3ad777:	0f 18 3d e2 84 d2 ff                            	prefetchit0 -0x2d7b1e(%rip)        # d5c60 <_ZN13media_service12ThriftClientINS_26ComposeReviewServiceClientEE7ConnectEv>
  3ad77e:	0f 18 3d db 3c ce ff                            	prefetchit0 -0x31c325(%rip)        # 91460 <pthread_mutex_unlock@plt>
  3ad785:	0f 18 3d f8 98 cf ff                            	prefetchit0 -0x306708(%rip)        # a7084 <_ZNSt17_Function_handlerIFSt10unique_ptrINSt13__future_base12_Result_baseENS2_8_DeleterEEvENS1_12_Task_setterIS0_INS1_7_ResultIvEES3_ENSt6thread8_InvokerISt5tupleIJZN13media_service14MovieIdHandler13UploadMovieIdElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapISK_SK_St4lessISK_ESaISt4pairISL_SK_EEEE3$_1EEEEvEEE9_M_invokeERKSt9_Any_data+0x24>
  3ad78c:	0f 18 3d 5d be da ff                            	prefetchit0 -0x2541a3(%rip)        # 1595f0 <_ZN6apache6thrift9transport7TSocket6isOpenEv>
  3ad793:	e9 a8 67 d2 ff                                  	jmp    d3f40 <_ZNSt13__future_base13_State_baseV213_M_set_resultESt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEb>
  3ad798:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3ad7a0:	0f 18 3d 2d 97 cf ff                            	prefetchit0 -0x3068d3(%rip)        # a6ed4 <_ZNSt13__future_base17_Async_state_implINSt6thread8_InvokerISt5tupleIJZN13media_service14MovieIdHandler13UploadMovieIdElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapISB_SB_St4lessISB_ESaISt4pairISC_SB_EEEE3$_1EEEEvE6_M_runEv+0x44>
  3ad7a7:	0f 18 3d f2 86 e8 ff                            	prefetchit0 -0x17790e(%rip)        # 235ea0 <_ZNSt18condition_variable10notify_oneEv>
  3ad7ae:	0f 18 3d 0b 9c cf ff                            	prefetchit0 -0x3063f5(%rip)        # a73c0 <_ZNSt17_Function_handlerIFSt10unique_ptrINSt13__future_base12_Result_baseENS2_8_DeleterEEvENS1_12_Task_setterIS0_INS1_7_ResultIvEES3_ENSt6thread8_InvokerISt5tupleIJZN13media_service14MovieIdHandler13UploadMovieIdElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapISK_SK_St4lessISK_ESaISt4pairISL_SK_EEEE3$_1EEEEvEEE10_M_managerERSt9_Any_dataRKS11_St18_Manager_operation>
  3ad7b5:	e9 26 77 d2 ff                                  	jmp    d4ee0 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_26ComposeReviewServiceClientEEEE4PushEPS3_>
  3ad7ba:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  3ad7c0:	0f 18 3d 89 a5 d2 ff                            	prefetchit0 -0x2d5a77(%rip)        # d7d50 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_19RatingServiceClientEEEE3PopEv>
  3ad7c7:	0f 18 3d 22 3d ce ff                            	prefetchit0 -0x31c2de(%rip)        # 914f0 <pthread_once@plt>
  3ad7ce:	e9 6d 67 d2 ff                                  	jmp    d3f40 <_ZNSt13__future_base13_State_baseV213_M_set_resultESt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEb>
  3ad7d3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ad7dd:	0f 1f 00                                        	nopl   (%rax)
  3ad7e0:	0f 18 3d 29 61 d3 ff                            	prefetchit0 -0x2c9ed7(%rip)        # e3910 <_ZN13media_service19RatingServiceClient12UploadRatingElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapIS6_S6_St4lessIS6_ESaISt4pairIS7_S6_EEE>
  3ad7e7:	0f 18 3d 42 bc d2 ff                            	prefetchit0 -0x2d43be(%rip)        # d9430 <_ZN13media_service12ThriftClientINS_19RatingServiceClientEE7ConnectEv>
  3ad7ee:	0f 18 3d 3b 20 db ff                            	prefetchit0 -0x24dfc5(%rip)        # 15f830 <_ZN6apache6thrift9transport16TFramedTransport6isOpenEv>
  3ad7f5:	0f 18 3d f4 bd da ff                            	prefetchit0 -0x25420c(%rip)        # 1595f0 <_ZN6apache6thrift9transport7TSocket6isOpenEv>
  3ad7fc:	0f 18 3d 7d 92 d2 ff                            	prefetchit0 -0x2d6d83(%rip)        # d6a80 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE17writeMessageBeginERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi+0x30>
  3ad803:	0f 18 3d 4c ac d2 ff                            	prefetchit0 -0x2d53b4(%rip)        # d8456 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_19RatingServiceClientEEEE3PopEv+0x706>
  3ad80a:	e9 41 a5 d2 ff                                  	jmp    d7d50 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_19RatingServiceClientEEEE3PopEv>
  3ad80f:	90                                              	nop
  3ad810:	0f 18 3d a9 bc d2 ff                            	prefetchit0 -0x2d4357(%rip)        # d94c0 <_ZN13media_service12ThriftClientINS_19RatingServiceClientEE9KeepAliveEv>
  3ad817:	0f 18 3d 32 45 ce ff                            	prefetchit0 -0x31bace(%rip)        # 91d50 <pthread_cond_signal@plt>
  3ad81e:	0f 18 3d cb a1 cf ff                            	prefetchit0 -0x305e35(%rip)        # a79f0 <_ZNSt17_Function_handlerIFSt10unique_ptrINSt13__future_base12_Result_baseENS2_8_DeleterEEvENS1_12_Task_setterIS0_INS1_7_ResultIvEES3_ENSt6thread8_InvokerISt5tupleIJZN13media_service14MovieIdHandler13UploadMovieIdElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapISK_SK_St4lessISK_ESaISt4pairISL_SK_EEEE3$_2EEEEvEEE10_M_managerERSt9_Any_dataRKS11_St18_Manager_operation>
  3ad825:	0f 18 3d 74 86 e8 ff                            	prefetchit0 -0x17798c(%rip)        # 235ea0 <_ZNSt18condition_variable10notify_oneEv>
  3ad82c:	0f 18 3d a4 67 d2 ff                            	prefetchit0 -0x2d985c(%rip)        # d3fd7 <_ZNSt13__future_base13_State_baseV213_M_set_resultESt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEb+0x97>
  3ad833:	0f 18 3d ca 9c cf ff                            	prefetchit0 -0x306336(%rip)        # a7504 <_ZNSt13__future_base17_Async_state_implINSt6thread8_InvokerISt5tupleIJZN13media_service14MovieIdHandler13UploadMovieIdElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapISB_SB_St4lessISB_ESaISt4pairISC_SB_EEEE3$_2EEEEvE6_M_runEv+0x44>
  3ad83a:	0f 18 3d 36 69 d2 ff                            	prefetchit0 -0x2d96ca(%rip)        # d4177 <_ZNSt13__future_base13_State_baseV29_M_do_setEPSt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEPb+0x17>
  3ad841:	e9 6a b0 d2 ff                                  	jmp    d88b0 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_19RatingServiceClientEEEE4PushEPS3_>
  3ad846:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ad850:	41 53                                           	push   %r11
  3ad852:	4c 8b 1d d7 15 ff ff                            	mov    -0xea29(%rip),%r11        # 39ee30 <malloc@GLIBC_2.2.5>
  3ad859:	41 0f 18 93 22 c0 ff ff                         	prefetcht1 -0x3fde(%r11)
  3ad861:	41 5b                                           	pop    %r11
  3ad863:	e9 68 c4 ef ff                                  	jmp    2a9cd0 <_ZNSt6thread6_StateD1Ev>
  3ad868:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3ad870:	0f 18 3d e9 89 d1 ff                            	prefetchit0 -0x2e7617(%rip)        # c6260 <_ZN5boost3log12v2s_mt_posix3aux14light_functionIFbRKNS1_19attribute_value_setEEE4implINS_7phoenix5actorINS_5proto7exprns_10basic_exprINSC_6tagns_3tag13greater_equalENSC_7argsns_5list2INS1_11expressions15attribute_actorINS1_7trivial14severity_levelENS1_16fallback_to_noneENSM_3tag8severityESB_EENSB_INSE_INSG_8terminalENSI_4termISN_EELl0EEEEEEELl2EEEEEE11invoke_implEPvS6_>
  3ad877:	e9 e4 8c dd ff                                  	jmp    186560 <_ZN5boost3log12v2s_mt_posix7sources3aux18get_severity_levelEv>
  3ad87c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ad880:	0f 18 3d fc 80 dc ff                            	prefetchit0 -0x237f04(%rip)        # 175983 <_ZNK5boost3log12v2s_mt_posix19attribute_value_set4findENS1_14attribute_nameE+0x43>
  3ad887:	0f 18 3d b2 80 dc ff                            	prefetchit0 -0x237f4e(%rip)        # 175940 <_ZNK5boost3log12v2s_mt_posix19attribute_value_set4findENS1_14attribute_nameE>
  3ad88e:	e9 fd e5 dc ff                                  	jmp    17be90 <_ZN5boost3log12v2s_mt_posix4core11open_recordERKNS1_13attribute_setE>
  3ad893:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ad89d:	0f 1f 00                                        	nopl   (%rax)
  3ad8a0:	0f 18 3d e9 a9 ed ff                            	prefetchit0 -0x125617(%rip)        # 288290 <_ZNKSt11__use_cacheISt16__numpunct_cacheIcEEclERKSt6locale>
  3ad8a7:	0f 18 3d d3 82 ee ff                            	prefetchit0 -0x117d2d(%rip)        # 295b81 <_ZNSo6sentryC1ERSo+0x21>
  3ad8ae:	0f 18 3d 6b ae ed ff                            	prefetchit0 -0x125195(%rip)        # 288720 <_ZNKSt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEE13_M_insert_intImEES3_S3_RSt8ios_basecT_>
  3ad8b5:	0f 18 3d 54 b1 ed ff                            	prefetchit0 -0x124eac(%rip)        # 288a10 <_ZNKSt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEE6do_putES3_RSt8ios_basecm>
  3ad8bc:	0f 18 3d 9d 82 ee ff                            	prefetchit0 -0x117d63(%rip)        # 295b60 <_ZNSo6sentryC1ERSo>
  3ad8c3:	0f 18 3d 36 93 ee ff                            	prefetchit0 -0x116cca(%rip)        # 296c00 <_ZNSo9_M_insertImEERSoT_>
  3ad8ca:	e9 f1 02 d1 ff                                  	jmp    bdbc0 <_ZNK13jaegertracing11SpanContext5printISoEEvRT_>
  3ad8cf:	90                                              	nop
  3ad8d0:	41 53                                           	push   %r11
  3ad8d2:	4c 8b 1d 07 1b ff ff                            	mov    -0xe4f9(%rip),%r11        # 39f3e0 <memcached_pool_pop@Base>
  3ad8d9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3ad8e1:	41 0f 18 93 22 00 00 00                         	prefetcht1 0x22(%r11)
  3ad8e9:	41 5b                                           	pop    %r11
  3ad8eb:	e9 60 8d e7 ff                                  	jmp    226650 <_ZdlPvm>
  3ad8f0:	0f 18 3d 19 f9 e7 ff                            	prefetchit0 -0x1806e7(%rip)        # 22d210 <_ZNSt6locale13_S_initializeEv>
  3ad8f7:	0f 18 3d 52 f9 e7 ff                            	prefetchit0 -0x1806ae(%rip)        # 22d250 <_ZNSt6localeC1Ev>
  3ad8fe:	0f 18 3d 5b a0 ec ff                            	prefetchit0 -0x135fa5(%rip)        # 277960 <_ZNSt9basic_iosIcSt11char_traitsIcEE4initEPSt15basic_streambufIcS1_E>
  3ad905:	0f 18 3d 14 ac ec ff                            	prefetchit0 -0x1353ec(%rip)        # 278520 <_ZNSt8ios_baseC1Ev>
  3ad90c:	0f 18 3d ad 5e f1 ff                            	prefetchit0 -0xea153(%rip)        # 2c37c0 <_ZNSt8ios_base7_M_initEv>
  3ad913:	e9 38 38 ce ff                                  	jmp    91150 <memcpy@plt>
  3ad918:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3ad920:	0f 18 3d 1f ac ec ff                            	prefetchit0 -0x1353e1(%rip)        # 278546 <_ZNSt8ios_baseC1Ev+0x26>
  3ad927:	0f 18 3d d2 e6 d0 ff                            	prefetchit0 -0x2f192e(%rip)        # bc000 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE11decodeValueERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  3ad92e:	0f 18 3d 0b 0f ef ff                            	prefetchit0 -0x10f0f5(%rip)        # 29e840 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode>
  3ad935:	0f 18 3d 84 43 ce ff                            	prefetchit0 -0x31bc7c(%rip)        # 91cc0 <bcmp@plt>
  3ad93c:	e9 0f 38 ce ff                                  	jmp    91150 <memcpy@plt>
  3ad941:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ad94b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3ad950:	0f 18 3d ae 46 d1 ff                            	prefetchit0 -0x2eb952(%rip)        # c2005 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E+0x35>
  3ad957:	e9 e4 ae d0 ff                                  	jmp    b8840 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  3ad95c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ad960:	0f 18 3d 19 e7 d0 ff                            	prefetchit0 -0x2f18e7(%rip)        # bc080 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE12normalizeKeyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  3ad967:	e9 54 eb d0 ff                                  	jmp    bc4c0 <_ZSt13__invoke_implIN11opentracing2v28expectedIvSt10error_codeEERZNK13jaegertracing11propagation10PropagatorIRKNS1_13TextMapReaderERKNS1_13TextMapWriterEE7extractESA_EUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESM_E_JNS1_11string_viewESP_EET_St14__invoke_otherOT0_DpOT1_>
  3ad96c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ad970:	0f 18 3d e9 dc e7 ff                            	prefetchit0 -0x182317(%rip)        # 22b660 <_ZNSt6localeaSERKS_>
  3ad977:	0f 18 3d 02 dd e7 ff                            	prefetchit0 -0x1822fe(%rip)        # 22b680 <_ZNSt6localeaSERKS_+0x20>
  3ad97e:	e9 bd 0e ef ff                                  	jmp    29e840 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode>
  3ad983:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ad98d:	0f 1f 00                                        	nopl   (%rax)
  3ad990:	0f 18 3d 79 d4 ec ff                            	prefetchit0 -0x132b87(%rip)        # 27ae10 <_ZNSi3getERc>
  3ad997:	0f 18 3d 02 5f e0 ff                            	prefetchit0 -0x1fa0fe(%rip)        # 1b38a0 <_ZN13jaegertracing5utils10HexParsing11readSegmentB5cxx11ERSimc>
  3ad99e:	0f 18 3d 8b cc ec ff                            	prefetchit0 -0x133375(%rip)        # 27a630 <_ZNSi6sentryC1ERSib>
  3ad9a5:	0f 18 3d 44 63 e0 ff                            	prefetchit0 -0x1f9cbc(%rip)        # 1b3cf0 <_ZN13jaegertracing7TraceID10fromStreamERSi>
  3ad9ac:	0f 18 3d 8e d4 ec ff                            	prefetchit0 -0x132b72(%rip)        # 27ae41 <_ZNSi3getERc+0x31>
  3ad9b3:	e9 78 59 e0 ff                                  	jmp    1b3330 <_ZN13jaegertracing11SpanContext10fromStreamERSi>
  3ad9b8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3ad9c0:	0f 18 3d 49 f5 d0 ff                            	prefetchit0 -0x2f0ab7(%rip)        # bcf10 <_ZN13jaegertracingeqERKNS_11SpanContextES2_>
  3ad9c7:	0f 18 3d 72 ae d0 ff                            	prefetchit0 -0x2f518e(%rip)        # b8840 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  3ad9ce:	0f 18 3d 9b ad ef ff                            	prefetchit0 -0x105265(%rip)        # 2a8770 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_>
  3ad9d5:	0f 18 3d f4 fb d0 ff                            	prefetchit0 -0x2f040c(%rip)        # bd5d0 <_ZNKSt8__detail9_EqualityINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS6_S6_ESaIS9_ENS_10_Select1stESt8equal_toIS6_ESt4hashIS6_ENS_18_Mod_range_hashingENS_20_Default_ranged_hashENS_20_Prime_rehash_policyENS_17_Hashtable_traitsILb1ELb0ELb1EEELb1EE8_M_equalERKSt10_HashtableIS6_S9_SA_SB_SD_SF_SG_SH_SI_SK_E>
  3ad9dc:	e9 5f fa d0 ff                                  	jmp    bd440 <_ZN13jaegertracing11SpanContext4swapERS0_>
  3ad9e1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ad9eb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3ad9f0:	0f 18 3d 99 ad ec ff                            	prefetchit0 -0x135267(%rip)        # 278790 <_ZNSt8ios_base17_M_call_callbacksENS_5eventE>
  3ad9f7:	0f 18 3d 42 ae ec ff                            	prefetchit0 -0x1351be(%rip)        # 278840 <_ZNSt8ios_baseD1Ev>
  3ad9fe:	e9 3d ae d0 ff                                  	jmp    b8840 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  3ada03:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ada0d:	0f 1f 00                                        	nopl   (%rax)
  3ada10:	0f 18 3d 09 3a d1 ff                            	prefetchit0 -0x2ec5f7(%rip)        # c1420 <_ZNSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES5_St4lessIS5_ESaISt4pairIKS5_S5_EEEixEOS5_>
  3ada17:	e9 f4 8c ef ff                                  	jmp    2a6710 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm>
  3ada1c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ada20:	0f 18 3d 01 4c e8 ff                            	prefetchit0 -0x17b3ff(%rip)        # 232628 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_+0x2a8>
  3ada27:	0f 18 3d 52 91 ef ff                            	prefetchit0 -0x106eae(%rip)        # 2a6b80 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm>
  3ada2e:	e9 ad 3f d1 ff                                  	jmp    c19e0 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE24_M_get_insert_unique_posERS7_>
  3ada33:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ada3d:	0f 1f 00                                        	nopl   (%rax)
  3ada40:	0f 18 3d 70 42 d3 ff                            	prefetchit0 -0x2cbd90(%rip)        # e1cb7 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x77>
  3ada47:	0f 18 3d 18 0f d3 ff                            	prefetchit0 -0x2cf0e8(%rip)        # de966 <_ZN13media_service23MovieIdServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x146>
  3ada4e:	0f 18 3d ec 12 d3 ff                            	prefetchit0 -0x2ced14(%rip)        # ded41 <_ZN13media_service23MovieIdServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x521>
  3ada55:	0f 18 3d a8 0e dc ff                            	prefetchit0 -0x23f158(%rip)        # 16e904 <_ZN6apache6thrift6server16TConnectedClient3runEv+0x2a4>
  3ada5c:	0f 18 3d d2 12 d3 ff                            	prefetchit0 -0x2ced2e(%rip)        # ded35 <_ZN13media_service23MovieIdServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x515>
  3ada63:	0f 18 3d 76 0d dc ff                            	prefetchit0 -0x23f28a(%rip)        # 16e7e0 <_ZN6apache6thrift6server16TConnectedClient3runEv+0x180>
  3ada6a:	0f 18 3d cf 41 d3 ff                            	prefetchit0 -0x2cbe31(%rip)        # e1c40 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv>
  3ada71:	0f 18 3d 68 1e db ff                            	prefetchit0 -0x24e198(%rip)        # 15f8e0 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE12readAll_virtEPhj>
  3ada78:	e9 d3 8b e7 ff                                  	jmp    226650 <_ZdlPvm>
  3ada7d:	0f 1f 00                                        	nopl   (%rax)
  3ada80:	0f 18 3d 39 bc de ff                            	prefetchit0 -0x2143c7(%rip)        # 1996c0 <_ZN5boost3log12v2s_mt_posix7sources3aux14severity_levelINS1_7trivial14severity_levelEE4impl8dispatchERNS1_15type_dispatcherE>
  3ada87:	0f 18 3d 82 4d d1 ff                            	prefetchit0 -0x2eb27e(%rip)        # c2810 <_ZN5boost3log12v2s_mt_posix3aux27single_type_dispatcher_base12get_callbackEPNS1_15type_dispatcherENS_9typeindex14stl_type_indexE>
  3ada8e:	e9 4d 88 d1 ff                                  	jmp    c62e0 <_ZNK5boost3log12v2s_mt_posix15value_extractorINS1_7trivial14severity_levelENS1_16fallback_to_noneENS3_3tag8severityEEclERKNS1_14attribute_nameERKNS1_19attribute_value_setE>
  3ada93:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ada9d:	0f 1f 00                                        	nopl   (%rax)
  3adaa0:	0f 18 3d 6c 51 cf ff                            	prefetchit0 -0x30ae94(%rip)        # a2c13 <_ZN13media_service14MovieIdHandler13UploadMovieIdElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapIS6_S6_St4lessIS6_ESaISt4pairIS7_S6_EEE+0x19d3>
  3adaa7:	0f 18 3d 4a 4b ce ff                            	prefetchit0 -0x31b4b6(%rip)        # 925f8 <free@plt>
  3adaae:	e9 fd 8d ec ff                                  	jmp    2768b0 <_ZNSt13__future_base12_Result_baseD1Ev>
  3adab3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3adabd:	0f 1f 00                                        	nopl   (%rax)
  3adac0:	0f 18 3d 59 75 ee ff                            	prefetchit0 -0x118aa7(%rip)        # 295020 <__once_proxy>
  3adac7:	e9 24 3a ce ff                                  	jmp    914f0 <pthread_once@plt>
  3adacc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3adad0:	0f 18 3d a9 8f d2 ff                            	prefetchit0 -0x2d7057(%rip)        # d6a80 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE17writeMessageBeginERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi+0x30>
  3adad7:	0f 18 3d 72 36 ce ff                            	prefetchit0 -0x31c98e(%rip)        # 91150 <memcpy@plt>
  3adade:	0f 18 3d ab ee d3 ff                            	prefetchit0 -0x2c1155(%rip)        # ec990 <_ZN13media_service26ComposeReviewServiceClient13UploadMovieIdElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKSt3mapIS6_S6_St4lessIS6_ESaISt4pairIS7_S6_EEE>
  3adae5:	e9 e6 39 ce ff                                  	jmp    914d0 <pthread_mutex_lock@plt>
  3adaea:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  3adaf0:	41 53                                           	push   %r11
  3adaf2:	4c 8b 1d 37 13 ff ff                            	mov    -0xecc9(%rip),%r11        # 39ee30 <malloc@GLIBC_2.2.5>
  3adaf9:	41 0f 18 93 22 c0 ff ff                         	prefetcht1 -0x3fde(%r11)
  3adb01:	41 5b                                           	pop    %r11
  3adb03:	e9 98 83 e8 ff                                  	jmp    235ea0 <_ZNSt18condition_variable10notify_oneEv>
  3adb08:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3adb10:	0f 18 3d e9 8c d2 ff                            	prefetchit0 -0x2d7317(%rip)        # d6800 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE12readI64_virtERl>
  3adb17:	0f 18 3d b2 da d4 ff                            	prefetchit0 -0x2b254e(%rip)        # fb5d0 <_ZN13media_service16ServiceExceptionD1Ev>
  3adb1e:	e9 7d 9f ef ff                                  	jmp    2a7aa0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm>
  3adb23:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3adb2d:	0f 1f 00                                        	nopl   (%rax)
  3adb30:	0f 18 3d 29 b5 ef ff                            	prefetchit0 -0x104ad7(%rip)        # 2a9060 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc>
  3adb37:	0f 18 3d e2 0c d3 ff                            	prefetchit0 -0x2cf31e(%rip)        # de820 <_ZN13media_service23MovieIdServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv>
  3adb3e:	0f 18 3d 47 41 d3 ff                            	prefetchit0 -0x2cbeb9(%rip)        # e1c8c <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x4c>
  3adb45:	0f 18 3d 34 0d d3 ff                            	prefetchit0 -0x2cf2cc(%rip)        # de880 <_ZN13media_service23MovieIdServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x60>
  3adb4c:	0f 18 3d 9c 60 d3 ff                            	prefetchit0 -0x2c9f64(%rip)        # e3bef <_ZN13media_service19RatingServiceClient17recv_UploadRatingEv+0x4f>
  3adb53:	e9 c8 93 d2 ff                                  	jmp    d6f20 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE14readStringBodyINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEEjRT_i>
  3adb58:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3adb60:	0f 18 3d 19 49 d3 ff                            	prefetchit0 -0x2cb6e7(%rip)        # e2480 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE22_M_emplace_hint_uniqueIJRKSt21piecewise_construct_tSt5tupleIJRS7_EESJ_IJEEEEESt17_Rb_tree_iteratorIS8_ESt23_Rb_tree_const_iteratorIS8_EDpOT_>
  3adb67:	41 53                                           	push   %r11
  3adb69:	4c 8b 1d 98 1e ff ff                            	mov    -0xe168(%rip),%r11        # 39fa08 <memcmp@GLIBC_2.2.5>
  3adb70:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3adb78:	41 5b                                           	pop    %r11
  3adb7a:	e9 21 9f ef ff                                  	jmp    2a7aa0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm>
  3adb7f:	90                                              	nop
  3adb80:	0f 18 3d fc 65 d2 ff                            	prefetchit0 -0x2d9a04(%rip)        # d4183 <_ZNSt13__future_base13_State_baseV29_M_do_setEPSt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEPb+0x23>
  3adb87:	e9 d4 38 ce ff                                  	jmp    91460 <pthread_mutex_unlock@plt>
  3adb8c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3adb90:	0f 18 3d b9 94 d2 ff                            	prefetchit0 -0x2d6b47(%rip)        # d7050 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE12readMapBeginERNS1_5TTypeES8_Rj>
  3adb97:	e9 34 44 d1 ff                                  	jmp    c1fd0 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  3adb9c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3adba0:	0f 18 3d d9 47 e8 ff                            	prefetchit0 -0x17b827(%rip)        # 232380 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_>
  3adba7:	0f 18 3d 52 3b d1 ff                            	prefetchit0 -0x2ec4ae(%rip)        # c1700 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_>
  3adbae:	e9 cd 48 d3 ff                                  	jmp    e2480 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE22_M_emplace_hint_uniqueIJRKSt21piecewise_construct_tSt5tupleIJRS7_EESJ_IJEEEEESt17_Rb_tree_iteratorIS8_ESt23_Rb_tree_const_iteratorIS8_EDpOT_>
  3adbb3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3adbbd:	0f 1f 00                                        	nopl   (%rax)
  3adbc0:	0f 18 3d 89 12 d3 ff                            	prefetchit0 -0x2ced77(%rip)        # dee50 <_ZN13media_service23MovieIdServiceProcessor21process_UploadMovieIdEiPN6apache6thrift8protocol9TProtocolES5_Pv>
  3adbc7:	0f 18 3d 12 de d2 ff                            	prefetchit0 -0x2d21ee(%rip)        # db9e0 <_ZN13media_service33MovieIdService_UploadMovieId_args4readEPN6apache6thrift8protocol9TProtocolE>
  3adbce:	0f 18 3d 2b 88 d2 ff                            	prefetchit0 -0x2d77d5(%rip)        # d6400 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE20readStructBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  3adbd5:	e9 36 48 ce ff                                  	jmp    92410 <memcmp@plt>
  3adbda:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  3adbe0:	0f 18 3d 7f 0d d3 ff                            	prefetchit0 -0x2cf281(%rip)        # de966 <_ZN13media_service23MovieIdServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x146>
  3adbe7:	e9 e4 43 d1 ff                                  	jmp    c1fd0 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  3adbec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3adbf0:	0f 18 3d 59 0e db ff                            	prefetchit0 -0x24f1a7(%rip)        # 15ea50 <_ZN6apache6thrift9transport16TFramedTransport8readSlowEPhj>
  3adbf7:	e9 54 8a e7 ff                                  	jmp    226650 <_ZdlPvm>
  3adbfc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3adc00:	0f 18 3d 89 d7 da ff                            	prefetchit0 -0x252877(%rip)        # 15b390 <_ZN6apache6thrift9transport7TSocket5writeEPKhj>
  3adc07:	0f 18 3d 32 e7 da ff                            	prefetchit0 -0x2518ce(%rip)        # 15c340 <_ZN6apache6thrift9transport17TVirtualTransportINS1_7TSocketENS1_18TTransportDefaultsEE10write_virtEPKhj>
  3adc0e:	0f 18 3d 9b 12 db ff                            	prefetchit0 -0x24ed65(%rip)        # 15eeb0 <_ZN6apache6thrift9transport16TFramedTransport8writeEndEv>
  3adc15:	0f 18 3d a9 d7 da ff                            	prefetchit0 -0x252857(%rip)        # 15b3c5 <_ZN6apache6thrift9transport7TSocket5writeEPKhj+0x35>
  3adc1c:	0f 18 3d fd 11 db ff                            	prefetchit0 -0x24ee03(%rip)        # 15ee20 <_ZN6apache6thrift9transport16TFramedTransport5flushEv>
  3adc23:	e9 88 45 e8 ff                                  	jmp    2321b0 <_ZSt18_Rb_tree_incrementPKSt18_Rb_tree_node_base>
  3adc28:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3adc30:	0f 18 3d 39 83 d2 ff                            	prefetchit0 -0x2d7cc7(%rip)        # d5f70 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE22writeMessageBegin_virtERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  3adc37:	0f 18 3d 12 35 ce ff                            	prefetchit0 -0x31caee(%rip)        # 91150 <memcpy@plt>
  3adc3e:	e9 ed 5c d3 ff                                  	jmp    e3930 <_ZN13media_service19RatingServiceClient17send_UploadRatingElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapIS6_S6_St4lessIS6_ESaISt4pairIS7_S6_EEE>
  3adc43:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3adc4d:	0f 1f 00                                        	nopl   (%rax)
  3adc50:	0f 18 3d e9 85 d2 ff                            	prefetchit0 -0x2d7a17(%rip)        # d6240 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE13writeI64_virtEl>
  3adc57:	e9 84 55 d3 ff                                  	jmp    e31e0 <_ZNK13media_service32RatingService_UploadRating_pargs5writeEPN6apache6thrift8protocol9TProtocolE>
  3adc5c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3adc60:	0f 18 3d e9 5a d3 ff                            	prefetchit0 -0x2ca517(%rip)        # e3750 <_ZN13media_service34RatingService_UploadRating_presult4readEPN6apache6thrift8protocol9TProtocolE>
  3adc67:	0f 18 3d 15 5b d3 ff                            	prefetchit0 -0x2ca4eb(%rip)        # e3783 <_ZN13media_service34RatingService_UploadRating_presult4readEPN6apache6thrift8protocol9TProtocolE+0x33>
  3adc6e:	0f 18 3d 9b 3a ce ff                            	prefetchit0 -0x31c565(%rip)        # 91710 <strlen@plt>
  3adc75:	e9 e6 b3 ef ff                                  	jmp    2a9060 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc>
  3adc7a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  3adc80:	0f 18 3d 59 9a cf ff                            	prefetchit0 -0x3065a7(%rip)        # a76e0 <_ZNSt17_Function_handlerIFSt10unique_ptrINSt13__future_base12_Result_baseENS2_8_DeleterEEvENS1_12_Task_setterIS0_INS1_7_ResultIvEES3_ENSt6thread8_InvokerISt5tupleIJZN13media_service14MovieIdHandler13UploadMovieIdElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapISK_SK_St4lessISK_ESaISt4pairISL_SK_EEEE3$_2EEEEvEEE9_M_invokeERKSt9_Any_data+0x50>
  3adc87:	0f 18 3d 92 90 e7 ff                            	prefetchit0 -0x186f6e(%rip)        # 226d20 <_ZNSt9exceptionD1Ev>
  3adc8e:	0f 18 3d 1b ac d2 ff                            	prefetchit0 -0x2d53e5(%rip)        # d88b0 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_19RatingServiceClientEEEE4PushEPS3_>
  3adc95:	e9 36 d9 d4 ff                                  	jmp    fb5d0 <_ZN13media_service16ServiceExceptionD1Ev>
  3adc9a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  3adca0:	0f 18 3d 99 e6 da ff                            	prefetchit0 -0x251967(%rip)        # 15c340 <_ZN6apache6thrift9transport17TVirtualTransportINS1_7TSocketENS1_18TTransportDefaultsEE10write_virtEPKhj>
  3adca7:	0f 18 3d e2 d6 da ff                            	prefetchit0 -0x25291e(%rip)        # 15b390 <_ZN6apache6thrift9transport7TSocket5writeEPKhj>
  3adcae:	0f 18 3d fb 11 db ff                            	prefetchit0 -0x24ee05(%rip)        # 15eeb0 <_ZN6apache6thrift9transport16TFramedTransport8writeEndEv>
  3adcb5:	0f 18 3d 64 11 db ff                            	prefetchit0 -0x24ee9c(%rip)        # 15ee20 <_ZN6apache6thrift9transport16TFramedTransport5flushEv>
  3adcbc:	e9 ef 44 e8 ff                                  	jmp    2321b0 <_ZSt18_Rb_tree_incrementPKSt18_Rb_tree_node_base>
  3adcc1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3adccb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3adcd0:	0f 18 3d 19 be d3 ff                            	prefetchit0 -0x2c41e7(%rip)        # e9af0 <_ZN13media_service42ComposeReviewService_UploadMovieId_presult4readEPN6apache6thrift8protocol9TProtocolE>
  3adcd7:	0f 18 3d 32 3a ce ff                            	prefetchit0 -0x31c5ce(%rip)        # 91710 <strlen@plt>
  3adcde:	0f 18 3d 1e be d3 ff                            	prefetchit0 -0x2c41e2(%rip)        # e9b03 <_ZN13media_service42ComposeReviewService_UploadMovieId_presult4readEPN6apache6thrift8protocol9TProtocolE+0x13>
  3adce5:	0f 18 3d 56 be d3 ff                            	prefetchit0 -0x2c41aa(%rip)        # e9b42 <_ZN13media_service42ComposeReviewService_UploadMovieId_presult4readEPN6apache6thrift8protocol9TProtocolE+0x52>
  3adcec:	e9 6f b3 ef ff                                  	jmp    2a9060 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc>
  3adcf1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3adcfb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3add00:	0f 18 3d a3 93 cf ff                            	prefetchit0 -0x306c5d(%rip)        # a70aa <_ZNSt17_Function_handlerIFSt10unique_ptrINSt13__future_base12_Result_baseENS2_8_DeleterEEvENS1_12_Task_setterIS0_INS1_7_ResultIvEES3_ENSt6thread8_InvokerISt5tupleIJZN13media_service14MovieIdHandler13UploadMovieIdElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapISK_SK_St4lessISK_ESaISt4pairISL_SK_EEEE3$_1EEEEvEEE9_M_invokeERKSt9_Any_data+0x4a>
  3add07:	0f 18 3d d2 71 d2 ff                            	prefetchit0 -0x2d8e2e(%rip)        # d4ee0 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_26ComposeReviewServiceClientEEEE4PushEPS3_>
  3add0e:	0f 18 3d 0b 90 e7 ff                            	prefetchit0 -0x186ff5(%rip)        # 226d20 <_ZNSt9exceptionD1Ev>
  3add15:	e9 b6 d8 d4 ff                                  	jmp    fb5d0 <_ZN13media_service16ServiceExceptionD1Ev>
  3add1a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  3add20:	0f 18 3d 70 0d db ff                            	prefetchit0 -0x24f290(%rip)        # 15ea97 <_ZN6apache6thrift9transport16TFramedTransport8readSlowEPhj+0x47>
  3add27:	0f 18 3d 12 d0 da ff                            	prefetchit0 -0x252fee(%rip)        # 15ad40 <_ZN6apache6thrift9transport7TSocket4readEPhj>
  3add2e:	0f 18 3d d6 0d db ff                            	prefetchit0 -0x24f22a(%rip)        # 15eb0b <_ZN6apache6thrift9transport16TFramedTransport9readFrameEv+0x3b>
  3add35:	0f 18 3d 14 34 ce ff                            	prefetchit0 -0x31cbec(%rip)        # 91150 <memcpy@plt>
  3add3c:	0f 18 3d bd e7 da ff                            	prefetchit0 -0x251843(%rip)        # 15c500 <_ZN6apache6thrift9transport7readAllINS1_7TSocketEEEjRT_Phj+0x10>
  3add43:	0f 18 3d 16 38 ce ff                            	prefetchit0 -0x31c7ea(%rip)        # 91560 <poll@plt>
  3add4a:	0f 18 3d cf e5 da ff                            	prefetchit0 -0x251a31(%rip)        # 15c320 <_ZN6apache6thrift9transport17TVirtualTransportINS1_7TSocketENS1_18TTransportDefaultsEE12readAll_virtEPhj>
  3add51:	0f 18 3d 98 e7 da ff                            	prefetchit0 -0x251868(%rip)        # 15c4f0 <_ZN6apache6thrift9transport7readAllINS1_7TSocketEEEjRT_Phj>
  3add58:	e9 13 44 ce ff                                  	jmp    92170 <recv@plt>
  3add5d:	0f 1f 00                                        	nopl   (%rax)
  3add60:	0f 18 3d e9 0c db ff                            	prefetchit0 -0x24f317(%rip)        # 15ea50 <_ZN6apache6thrift9transport16TFramedTransport8readSlowEPhj>
  3add67:	0f 18 3d d2 cf da ff                            	prefetchit0 -0x25302e(%rip)        # 15ad40 <_ZN6apache6thrift9transport7TSocket4readEPhj>
  3add6e:	0f 18 3d 9b e5 da ff                            	prefetchit0 -0x251a65(%rip)        # 15c310 <_ZN6apache6thrift9transport17TVirtualTransportINS1_7TSocketENS1_18TTransportDefaultsEE9read_virtEPhj>
  3add75:	0f 18 3d 94 1e db ff                            	prefetchit0 -0x24e16c(%rip)        # 15fc10 <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj>
  3add7c:	0f 18 3d c0 1e db ff                            	prefetchit0 -0x24e140(%rip)        # 15fc43 <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj+0x33>
  3add83:	e9 a8 38 ce ff                                  	jmp    91630 <send@plt>
  3add88:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3add90:	0f 18 3d 09 9d ef ff                            	prefetchit0 -0x1062f7(%rip)        # 2a7aa0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm>
  3add97:	0f 18 3d fe 8e d2 ff                            	prefetchit0 -0x2d7102(%rip)        # d6c9c <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE16readMessageBeginERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERNS1_12TMessageTypeERi+0x2c>
  3add9e:	0f 18 3d 1d 9d ef ff                            	prefetchit0 -0x1062e3(%rip)        # 2a7ac2 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm+0x22>
  3adda5:	0f 18 3d 34 1b db ff                            	prefetchit0 -0x24e4cc(%rip)        # 15f8e0 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE12readAll_virtEPhj>
  3addac:	0f 18 3d c3 1e db ff                            	prefetchit0 -0x24e13d(%rip)        # 15fc76 <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj+0x66>
  3addb3:	0f 18 3d 17 1f db ff                            	prefetchit0 -0x24e0e9(%rip)        # 15fcd1 <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj+0xc1>
  3addba:	0f 18 3d 2f 9e ef ff                            	prefetchit0 -0x1061d1(%rip)        # 2a7bf0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm+0x150>
  3addc1:	e9 8a 33 ce ff                                  	jmp    91150 <memcpy@plt>
  3addc6:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3addd0:	0f 18 3d d9 c2 e4 ff                            	prefetchit0 -0x1b3d27(%rip)        # 1fa0b0 <_ZN11opentracing2v26Tracer6GlobalEv>
  3addd7:	0f 18 3d 62 34 cf ff                            	prefetchit0 -0x30cb9e(%rip)        # a1240 <_ZN13media_service14MovieIdHandler13UploadMovieIdElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapIS6_S6_St4lessIS6_ESaISt4pairIS7_S6_EEE>
  3addde:	0f 18 3d ee 41 d1 ff                            	prefetchit0 -0x2ebe12(%rip)        # c1fd3 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E+0x3>
  3adde5:	0f 18 3d e4 89 d2 ff                            	prefetchit0 -0x2d761c(%rip)        # d67d0 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE12readI32_virtERi>
  3addec:	0f 18 3d cd c2 e4 ff                            	prefetchit0 -0x1b3d33(%rip)        # 1fa0c0 <_ZN11opentracing2v26Tracer6GlobalEv+0x10>
  3addf3:	0f 18 3d c9 df d2 ff                            	prefetchit0 -0x2d2037(%rip)        # dbdc3 <_ZN13media_service33MovieIdService_UploadMovieId_args4readEPN6apache6thrift8protocol9TProtocolE+0x3e3>
  3addfa:	0f 18 3d 85 34 cf ff                            	prefetchit0 -0x30cb7b(%rip)        # a1286 <_ZN13media_service14MovieIdHandler13UploadMovieIdElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapIS6_S6_St4lessIS6_ESaISt4pairIS7_S6_EEE+0x46>
  3ade01:	0f 18 3d c1 34 cf ff                            	prefetchit0 -0x30cb3f(%rip)        # a12c9 <_ZN13media_service14MovieIdHandler13UploadMovieIdElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapIS6_S6_St4lessIS6_ESaISt4pairIS7_S6_EEE+0x89>
  3ade08:	e9 43 33 ce ff                                  	jmp    91150 <memcpy@plt>
  3ade0d:	0f 1f 00                                        	nopl   (%rax)
  3ade10:	0f 18 3d b9 b7 d3 ff                            	prefetchit0 -0x2c4847(%rip)        # e95d0 <_ZNK13media_service40ComposeReviewService_UploadMovieId_pargs5writeEPN6apache6thrift8protocol9TProtocolE>
  3ade17:	0f 18 3d c2 53 d3 ff                            	prefetchit0 -0x2cac3e(%rip)        # e31e0 <_ZNK13media_service32RatingService_UploadRating_pargs5writeEPN6apache6thrift8protocol9TProtocolE>
  3ade1e:	0f 18 3d 6b d5 da ff                            	prefetchit0 -0x252a95(%rip)        # 15b390 <_ZN6apache6thrift9transport7TSocket5writeEPKhj>
  3ade25:	0f 18 3d f4 0f db ff                            	prefetchit0 -0x24f00c(%rip)        # 15ee20 <_ZN6apache6thrift9transport16TFramedTransport5flushEv>
  3ade2c:	0f 18 3d dd 83 d2 ff                            	prefetchit0 -0x2d7c23(%rip)        # d6210 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE13writeI32_virtEi>
  3ade33:	0f 18 3d 76 10 db ff                            	prefetchit0 -0x24ef8a(%rip)        # 15eeb0 <_ZN6apache6thrift9transport16TFramedTransport8writeEndEv>
  3ade3a:	0f 18 3d 4f 81 d2 ff                            	prefetchit0 -0x2d7eb1(%rip)        # d5f90 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE21writeStructBegin_virtEPKc>
  3ade41:	e9 0a 33 ce ff                                  	jmp    91150 <memcpy@plt>
  3ade46:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ade50:	0f 18 3d 69 d6 e0 ff                            	prefetchit0 -0x1f2997(%rip)        # 1bb4c0 <_ZNSt15_Sp_counted_ptrIPN6apache6thrift9transport13TMemoryBufferELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv>
  3ade57:	e9 9c 47 ce ff                                  	jmp    925f8 <free@plt>
  3ade5c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ade60:	0f 18 3d e9 fd e2 ff                            	prefetchit0 -0x1d0217(%rip)        # 1ddc50 <_ZNK13jaegertracing6thrift7SpanRef5writeEPN6apache6thrift8protocol9TProtocolE>
  3ade67:	0f 18 3d 93 11 e3 ff                            	prefetchit0 -0x1cee6d(%rip)        # 1df001 <_ZNK13jaegertracing6thrift4Span5writeEPN6apache6thrift8protocol9TProtocolE+0x3c1>
  3ade6e:	0f 18 3d 5b da d2 ff                            	prefetchit0 -0x2d25a5(%rip)        # db8d0 <_ZNSt15_Sp_counted_ptrIPN6apache6thrift8protocol9TProtocolELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv>
  3ade75:	0f 18 3d 87 d9 e0 ff                            	prefetchit0 -0x1f2679(%rip)        # 1bb803 <_ZN6apache6thrift8protocol17TCompactProtocolTINS0_9transport10TTransportEED0Ev+0x13>
  3ade7c:	0f 18 3d 4d db e0 ff                            	prefetchit0 -0x1f24b3(%rip)        # 1bb9d0 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE19writeListBegin_virtENS1_5TTypeEj>
  3ade83:	0f 18 3d 77 db e0 ff                            	prefetchit0 -0x1f2489(%rip)        # 1bba01 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE19writeListBegin_virtENS1_5TTypeEj+0x31>
  3ade8a:	0f 18 3d 7f dd e0 ff                            	prefetchit0 -0x1f2281(%rip)        # 1bbc10 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE13writeI32_virtEi>
  3ade91:	e9 ba 32 ce ff                                  	jmp    91150 <memcpy@plt>
  3ade96:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3adea0:	41 53                                           	push   %r11
  3adea2:	4c 8b 1d 6f 19 ff ff                            	mov    -0xe691(%rip),%r11        # 39f818 <pthread_rwlock_unlock@GLIBC_2.34>
  3adea9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3adeb1:	41 0f 18 93 31 00 00 00                         	prefetcht1 0x31(%r11)
  3adeb9:	41 5b                                           	pop    %r11
  3adebb:	e9 10 78 dc ff                                  	jmp    1756d0 <_ZN5boost3log12v2s_mt_posix19attribute_value_setD1Ev>
  3adec0:	0f 18 3d 79 f5 d0 ff                            	prefetchit0 -0x2f0a87(%rip)        # bd440 <_ZN13jaegertracing11SpanContext4swapERS0_>
  3adec7:	e9 d4 36 ce ff                                  	jmp    915a0 <memset@plt>
  3adecc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3aded0:	0f 18 3d f9 74 ef ff                            	prefetchit0 -0x108b07(%rip)        # 2a53d0 <_ZNSt15basic_streambufIcSt11char_traitsIcEE5uflowEv>
  3aded7:	e9 34 cf ec ff                                  	jmp    27ae10 <_ZNSi3getERc>
  3adedc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3adee0:	0f 18 3d 29 d9 ee ff                            	prefetchit0 -0x1126d7(%rip)        # 29b810 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE9underflowEv>
  3adee7:	e9 b4 59 e0 ff                                  	jmp    1b38a0 <_ZN13jaegertracing5utils10HexParsing11readSegmentB5cxx11ERSimc>
  3adeec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3adef0:	0f 18 3d a9 fa d0 ff                            	prefetchit0 -0x2f0557(%rip)        # bd9a0 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_>
  3adef7:	e9 a4 8f ef ff                                  	jmp    2a6ea0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEaSEOS4_>
  3adefc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3adf00:	0f 18 3d b9 db ec ff                            	prefetchit0 -0x132447(%rip)        # 27bac0 <_ZNSi7putbackEc>
  3adf07:	e9 04 cf ec ff                                  	jmp    27ae10 <_ZNSi3getERc>
  3adf0c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3adf10:	0f 18 3d 69 a8 ef ff                            	prefetchit0 -0x105797(%rip)        # 2a8780 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_+0x10>
  3adf17:	e9 84 fa d0 ff                                  	jmp    bd9a0 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_>
  3adf1c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3adf20:	0f 18 3d 19 e2 d0 ff                            	prefetchit0 -0x2f1de7(%rip)        # bc140 <_ZN13jaegertracing11SpanContextC2ERKNS_7TraceIDEmmhRKSt13unordered_mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESA_St4hashISA_ESt8equal_toISA_ESaISt4pairIKSA_SA_EEERSG_>
  3adf27:	0f 18 3d 52 e2 d0 ff                            	prefetchit0 -0x2f1dae(%rip)        # bc180 <_ZN13jaegertracing11SpanContextC2ERKNS_7TraceIDEmmhRKSt13unordered_mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESA_St4hashISA_ESt8equal_toISA_ESaISt4pairIKSA_SA_EEERSG_+0x40>
  3adf2e:	e9 9d 35 ce ff                                  	jmp    914d0 <pthread_mutex_lock@plt>
  3adf33:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3adf3d:	0f 1f 00                                        	nopl   (%rax)
  3adf40:	0f 18 3d f9 f4 d0 ff                            	prefetchit0 -0x2f0b07(%rip)        # bd440 <_ZN13jaegertracing11SpanContext4swapERS0_>
  3adf47:	e9 f4 e1 d0 ff                                  	jmp    bc140 <_ZN13jaegertracing11SpanContextC2ERKNS_7TraceIDEmmhRKSt13unordered_mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESA_St4hashISA_ESt8equal_toISA_ESaISt4pairIKSA_SA_EEERSG_>
  3adf4c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3adf50:	0f 18 3d 69 4c e8 ff                            	prefetchit0 -0x17b397(%rip)        # 232bc0 <_ZNSt6chrono3_V212system_clock3nowEv>
  3adf57:	0f 18 3d 12 a8 ef ff                            	prefetchit0 -0x1057ee(%rip)        # 2a8770 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_>
  3adf5e:	0f 18 3d db 68 e0 ff                            	prefetchit0 -0x1f9725(%rip)        # 1b4840 <_ZNK13jaegertracing6Tracer20StartSpanWithOptionsEN11opentracing2v211string_viewERKNS2_16StartSpanOptionsE+0x8b0>
  3adf65:	0f 18 3d 14 a8 ef ff                            	prefetchit0 -0x1057ec(%rip)        # 2a8780 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_+0x10>
  3adf6c:	e9 cf f4 d0 ff                                  	jmp    bd440 <_ZN13jaegertracing11SpanContext4swapERS0_>
  3adf71:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3adf7b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3adf80:	0f 18 3d f9 68 e0 ff                            	prefetchit0 -0x1f9707(%rip)        # 1b4880 <_ZNK13jaegertracing6Tracer20StartSpanWithOptionsEN11opentracing2v211string_viewERKNS2_16StartSpanOptionsE+0x8f0>
  3adf87:	e9 14 36 ce ff                                  	jmp    915a0 <memset@plt>
  3adf8c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3adf90:	0f 18 3d 29 9f e0 ff                            	prefetchit0 -0x1f60d7(%rip)        # 1b7ec0 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EE15_M_range_insertIN9__gnu_cxx17__normal_iteratorIPKS1_S3_EEEEvNS6_IPS1_S3_EET_SC_St20forward_iterator_tag>
  3adf97:	0f 18 3d 62 7b e0 ff                            	prefetchit0 -0x1f849e(%rip)        # 1b5b00 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EE7reserveEm>
  3adf9e:	0f 18 3d 65 a2 e0 ff                            	prefetchit0 -0x1f5d9b(%rip)        # 1b820a <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EE15_M_range_insertIN9__gnu_cxx17__normal_iteratorIPKS1_S3_EEEEvNS6_IPS1_S3_EET_SC_St20forward_iterator_tag+0x34a>
  3adfa5:	0f 18 3d 86 71 e0 ff                            	prefetchit0 -0x1f8e7a(%rip)        # 1b5132 <_ZNK13jaegertracing6Tracer17startSpanInternalERKNS_11SpanContextERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKNSt6chrono10time_pointINSC_3_V212system_clockENSC_8durationIlSt5ratioILl1ELl1000000000EEEEEERKNSD_INSE_12steady_clockESJ_EERKSt6vectorINS_3TagESaISS_EERKSR_ISt4pairIS9_N11opentracing2v25ValueEESaIS11_EEbRKSR_INS_9ReferenceESaIS16_EE+0x1f2>
  3adfac:	0f 18 3d 90 7b e0 ff                            	prefetchit0 -0x1f8470(%rip)        # 1b5b43 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EE7reserveEm+0x43>
  3adfb3:	e9 98 31 ce ff                                  	jmp    91150 <memcpy@plt>
  3adfb8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3adfc0:	41 53                                           	push   %r11
  3adfc2:	4c 8b 1d 6f 15 ff ff                            	mov    -0xea91(%rip),%r11        # 39f538 <memcached_set@Base>
  3adfc9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3adfd1:	4c 8b 1d f0 15 ff ff                            	mov    -0xea10(%rip),%r11        # 39f5c8 <memcached_get@Base>
  3adfd8:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3adfe0:	41 5b                                           	pop    %r11
  3adfe2:	e9 59 86 e7 ff                                  	jmp    226640 <_ZdlPv>
  3adfe7:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  3adff0:	0f 18 3d 69 a5 e0 ff                            	prefetchit0 -0x1f5a97(%rip)        # 1b8560 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_>
  3adff7:	0f 18 3d c6 a5 e0 ff                            	prefetchit0 -0x1f5a3a(%rip)        # 1b85c4 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_+0x64>
  3adffe:	0f 18 3d 9b f9 d0 ff                            	prefetchit0 -0x2f0665(%rip)        # bd9a0 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_>
  3ae005:	0f 18 3d f4 86 e7 ff                            	prefetchit0 -0x18790c(%rip)        # 226700 <__dynamic_cast+0x90>
  3ae00c:	e9 5f 86 e7 ff                                  	jmp    226670 <__dynamic_cast>
  3ae011:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ae01b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3ae020:	0f 18 3d 0c 8f e0 ff                            	prefetchit0 -0x1f70f4(%rip)        # 1b6f33 <_ZNSt12_Destroy_auxILb0EE9__destroyIPN13jaegertracing9ReferenceEEEvT_S5_+0x3>
  3ae027:	e9 34 a5 e0 ff                                  	jmp    1b8560 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_>
  3ae02c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae030:	0f 18 3d 19 c0 d0 ff                            	prefetchit0 -0x2f3fe7(%rip)        # ba050 <_ZNSt20__uninitialized_copyILb0EE13__uninit_copyIN9__gnu_cxx17__normal_iteratorIPKN13jaegertracing3TagESt6vectorIS5_SaIS5_EEEEPS5_EET0_T_SE_SD_>
  3ae037:	e9 04 7c e0 ff                                  	jmp    1b5c40 <_ZN13jaegertracing4SpanC2ERKSt10shared_ptrIKNS_6TracerEERKNS_11SpanContextERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKNSt6chrono10time_pointINSI_3_V212system_clockENSI_8durationIlSt5ratioILl1ELl1000000000EEEEEERKNSJ_INSK_12steady_clockESP_EERKSt6vectorINS_3TagESaISY_EERKSX_INS_9ReferenceESaIS13_EE>
  3ae03c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae040:	0f 18 3d bd 7d e0 ff                            	prefetchit0 -0x1f8243(%rip)        # 1b5e04 <_ZN13jaegertracing4SpanC2ERKSt10shared_ptrIKNS_6TracerEERKNS_11SpanContextERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKNSt6chrono10time_pointINSI_3_V212system_clockENSI_8durationIlSt5ratioILl1ELl1000000000EEEEEERKNSJ_INSK_12steady_clockESP_EERKSt6vectorINS_3TagESaISY_EERKSX_INS_9ReferenceESaIS13_EE+0x1c4>
  3ae047:	e9 74 5a e0 ff                                  	jmp    1b3ac0 <_ZN13jaegertracing11SpanContextC2ERKS0_>
  3ae04c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae050:	0f 18 3d 79 b6 cf ff                            	prefetchit0 -0x304987(%rip)        # a96d0 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  3ae057:	e9 84 a1 e7 ff                                  	jmp    2281e0 <_Znwm>
  3ae05c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae060:	0f 18 3d b9 d1 e3 ff                            	prefetchit0 -0x1c2e47(%rip)        # 1eb220 <_ZNK13jaegertracing4Span7contextEv>
  3ae067:	e9 74 a1 e7 ff                                  	jmp    2281e0 <_Znwm>
  3ae06c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae070:	0f 18 3d d9 57 d0 ff                            	prefetchit0 -0x2fa827(%rip)        # b3850 <_ZN13jaegertracing7metrics11NullCounter3incEl>
  3ae077:	0f 18 3d f2 be d0 ff                            	prefetchit0 -0x2f410e(%rip)        # b9f70 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EED2Ev>
  3ae07e:	e9 3d 5a e0 ff                                  	jmp    1b3ac0 <_ZN13jaegertracing11SpanContextC2ERKS0_>
  3ae083:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ae08d:	0f 1f 00                                        	nopl   (%rax)
  3ae090:	0f 18 3d b9 8c e0 ff                            	prefetchit0 -0x1f7347(%rip)        # 1b6d50 <_ZNSt23mersenne_twister_engineImLm64ELm312ELm156ELm31ELm13043109905998158313ELm29ELm6148914691236517205ELm17ELm8202884508482404352ELm37ELm18444473444759240704ELm43ELm6364136223846793005EEclEv>
  3ae097:	0f 18 3d a9 6d e0 ff                            	prefetchit0 -0x1f9257(%rip)        # 1b4e47 <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE+0x257>
  3ae09e:	0f 18 3d 8e 8e e0 ff                            	prefetchit0 -0x1f7172(%rip)        # 1b6f33 <_ZNSt12_Destroy_auxILb0EE9__destroyIPN13jaegertracing9ReferenceEEEvT_S5_+0x3>
  3ae0a5:	0f 18 3d 56 8f e0 ff                            	prefetchit0 -0x1f70aa(%rip)        # 1b7002 <_ZNSt12_Destroy_auxILb0EE9__destroyIPN13jaegertracing9ReferenceEEEvT_S5_+0xd2>
  3ae0ac:	e9 0f 5a e0 ff                                  	jmp    1b3ac0 <_ZN13jaegertracing11SpanContextC2ERKS0_>
  3ae0b1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ae0bb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3ae0c0:	0f 18 3d b9 d0 e0 ff                            	prefetchit0 -0x1f2f47(%rip)        # 1bb180 <_ZN6apache6thrift8protocol24TCompactProtocolFactoryTINS0_9transport10TTransportEE11getProtocolESt10shared_ptrIS4_E>
  3ae0c7:	0f 18 3d 32 d4 e0 ff                            	prefetchit0 -0x1f2bce(%rip)        # 1bb500 <_ZN6apache6thrift8protocol17TCompactProtocolTINS0_9transport10TTransportEEC2ESt10shared_ptrIS4_Eii>
  3ae0ce:	e9 0d a1 e7 ff                                  	jmp    2281e0 <_Znwm>
  3ae0d3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ae0dd:	0f 1f 00                                        	nopl   (%rax)
  3ae0e0:	0f 18 3d 09 19 db ff                            	prefetchit0 -0x24e6f7(%rip)        # 15f9f0 <_ZN6apache6thrift9transport13TMemoryBufferD0Ev>
  3ae0e7:	e9 94 a6 da ff                                  	jmp    158780 <_ZN6apache6thrift8protocol16TProtocolFactoryD1Ev>
  3ae0ec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae0f0:	0f 18 3d d9 ff e2 ff                            	prefetchit0 -0x1d0027(%rip)        # 1de0d0 <_ZN13jaegertracing6thrift4SpanD2Ev>
  3ae0f7:	e9 c4 00 e3 ff                                  	jmp    1de1c0 <_ZN13jaegertracing6thrift4SpanD1Ev>
  3ae0fc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae100:	0f 18 3d 49 01 e3 ff                            	prefetchit0 -0x1cfeb7(%rip)        # 1de250 <_ZN13jaegertracing6thrift4Span17__set_traceIdHighEl>
  3ae107:	e9 c4 33 ce ff                                  	jmp    914d0 <pthread_mutex_lock@plt>
  3ae10c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae110:	0f 18 3d 29 bf e0 ff                            	prefetchit0 -0x1f40d7(%rip)        # 1ba040 <_ZNSt6vectorIN13jaegertracing6thrift7SpanRefESaIS2_EE20_M_allocate_and_copyIPKS2_EEPS2_mT_S9_>
  3ae117:	e9 24 01 e3 ff                                  	jmp    1de240 <_ZN13jaegertracing6thrift4Span16__set_traceIdLowEl>
  3ae11c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae120:	0f 18 3d f9 f7 e2 ff                            	prefetchit0 -0x1d0807(%rip)        # 1dd920 <_ZN13jaegertracing6thrift7SpanRef13__set_refTypeENS0_11SpanRefType4typeE>
  3ae127:	e9 34 01 e3 ff                                  	jmp    1de260 <_ZN13jaegertracing6thrift4Span12__set_spanIdEl>
  3ae12c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae130:	0f 18 3d 09 f8 e2 ff                            	prefetchit0 -0x1d07f7(%rip)        # 1dd940 <_ZN13jaegertracing6thrift7SpanRef17__set_traceIdHighEl>
  3ae137:	e9 44 01 e3 ff                                  	jmp    1de280 <_ZN13jaegertracing6thrift4Span19__set_operationNameERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  3ae13c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae140:	0f 18 3d 79 fd e2 ff                            	prefetchit0 -0x1d0287(%rip)        # 1ddec0 <_ZN13jaegertracing6thrift7SpanRefC1ERKS1_>
  3ae147:	0f 18 3d 92 f7 e2 ff                            	prefetchit0 -0x1d086e(%rip)        # 1dd8e0 <_ZN13jaegertracing6thrift7SpanRefD1Ev>
  3ae14e:	e9 ed be e0 ff                                  	jmp    1ba040 <_ZNSt6vectorIN13jaegertracing6thrift7SpanRefESaIS2_EE20_M_allocate_and_copyIPKS2_EEPS2_mT_S9_>
  3ae153:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ae15d:	0f 1f 00                                        	nopl   (%rax)
  3ae160:	0f 18 3d 89 33 e3 ff                            	prefetchit0 -0x1ccc77(%rip)        # 1e14f0 <_ZNSt6vectorIN13jaegertracing6thrift3TagESaIS2_EEaSERKS4_>
  3ae167:	0f 18 3d 26 34 e3 ff                            	prefetchit0 -0x1ccbda(%rip)        # 1e1594 <_ZNSt6vectorIN13jaegertracing6thrift3TagESaIS2_EEaSERKS4_+0xa4>
  3ae16e:	0f 18 3d 1a 36 e3 ff                            	prefetchit0 -0x1cc9e6(%rip)        # 1e178f <_ZNSt6vectorIN13jaegertracing6thrift3TagESaIS2_EEaSERKS4_+0x29f>
  3ae175:	0f 18 3d 47 3c e3 ff                            	prefetchit0 -0x1cc3b9(%rip)        # 1e1dc3 <_ZNSt6vectorIN13jaegertracing6thrift3LogESaIS2_EEaSERKS4_+0xa3>
  3ae17c:	e9 3f 01 e3 ff                                  	jmp    1de2c0 <_ZN13jaegertracing6thrift4Span15__set_startTimeEl>
  3ae181:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ae18b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3ae190:	0f 18 3d 49 f7 e2 ff                            	prefetchit0 -0x1d08b7(%rip)        # 1dd8e0 <_ZN13jaegertracing6thrift7SpanRefD1Ev>
  3ae197:	0f 18 3d 32 39 e3 ff                            	prefetchit0 -0x1cc6ce(%rip)        # 1e1ad0 <_ZNSt6vectorIN13jaegertracing6thrift7SpanRefESaIS2_EEaSERKS4_>
  3ae19e:	e9 7d f7 e2 ff                                  	jmp    1dd920 <_ZN13jaegertracing6thrift7SpanRef13__set_refTypeENS0_11SpanRefType4typeE>
  3ae1a3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ae1ad:	0f 1f 00                                        	nopl   (%rax)
  3ae1b0:	0f 18 3d 29 e1 e0 ff                            	prefetchit0 -0x1f1ed7(%rip)        # 1bc2e0 <_ZNSt11_Deque_baseIsSaIsEE17_M_initialize_mapEm>
  3ae1b7:	0f 18 3d 52 87 d2 ff                            	prefetchit0 -0x2d78ae(%rip)        # d6910 <_ZN6apache6thrift8protocol17TProtocolDefaultsC2ESt10shared_ptrINS0_9transport10TTransportEE>
  3ae1be:	0f 18 3d 3d e1 e0 ff                            	prefetchit0 -0x1f1ec3(%rip)        # 1bc302 <_ZNSt11_Deque_baseIsSaIsEE17_M_initialize_mapEm+0x22>
  3ae1c5:	0f 18 3d 34 88 d2 ff                            	prefetchit0 -0x2d77cc(%rip)        # d6a00 <_ZN6apache6thrift8protocol17TProtocolDefaultsC2ESt10shared_ptrINS0_9transport10TTransportEE+0xf0>
  3ae1cc:	0f 18 3d 1c 88 d2 ff                            	prefetchit0 -0x2d77e4(%rip)        # d69ef <_ZN6apache6thrift8protocol17TProtocolDefaultsC2ESt10shared_ptrINS0_9transport10TTransportEE+0xdf>
  3ae1d3:	e9 08 a0 e7 ff                                  	jmp    2281e0 <_Znwm>
  3ae1d8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3ae1e0:	0f 18 3d 59 19 db ff                            	prefetchit0 -0x24e6a7(%rip)        # 15fb40 <_ZN6apache6thrift9transport17TVirtualTransportINS1_13TMemoryBufferENS1_11TBufferBaseEE10write_virtEPKhj>
  3ae1e7:	0f 18 3d 82 da e0 ff                            	prefetchit0 -0x1f257e(%rip)        # 1bbc70 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE13writeI64_virtEl>
  3ae1ee:	0f 18 3d 8b da e0 ff                            	prefetchit0 -0x1f2575(%rip)        # 1bbc80 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE13writeI64_virtEl+0x10>
  3ae1f5:	e9 e6 9f e7 ff                                  	jmp    2281e0 <_Znwm>
  3ae1fa:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  3ae200:	0f 18 3d c9 a4 da ff                            	prefetchit0 -0x255b37(%rip)        # 1586d0 <_ZN6apache6thrift8protocol9TProtocolD1Ev>
  3ae207:	e9 34 84 e7 ff                                  	jmp    226640 <_ZdlPv>
  3ae20c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae210:	0f 18 3d 99 d2 e0 ff                            	prefetchit0 -0x1f2d67(%rip)        # 1bb4b0 <_ZNSt15_Sp_counted_ptrIPN6apache6thrift9transport13TMemoryBufferELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv>
  3ae217:	e9 b4 a4 da ff                                  	jmp    1586d0 <_ZN6apache6thrift8protocol9TProtocolD1Ev>
  3ae21c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae220:	0f 18 3d de d0 e0 ff                            	prefetchit0 -0x1f2f22(%rip)        # 1bb305 <_ZN6apache6thrift8protocol24TCompactProtocolFactoryTINS0_9transport10TTransportEE11getProtocolESt10shared_ptrIS4_E+0x185>
  3ae227:	e9 b4 9f e7 ff                                  	jmp    2281e0 <_Znwm>
  3ae22c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae230:	0f 18 3d 09 0a e3 ff                            	prefetchit0 -0x1cf5f7(%rip)        # 1dec40 <_ZNK13jaegertracing6thrift4Span5writeEPN6apache6thrift8protocol9TProtocolE>
  3ae237:	0f 18 3d 52 d6 e0 ff                            	prefetchit0 -0x1f29ae(%rip)        # 1bb890 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE21writeStructBegin_virtEPKc>
  3ae23e:	e9 9d 9f e7 ff                                  	jmp    2281e0 <_Znwm>
  3ae243:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ae24d:	0f 1f 00                                        	nopl   (%rax)
  3ae250:	0f 18 3d f9 3a ce ff                            	prefetchit0 -0x31c507(%rip)        # 91d50 <pthread_cond_signal@plt>
  3ae257:	0f 18 3d 88 3b d1 ff                            	prefetchit0 -0x2ec478(%rip)        # c1de6 <_ZNSt6vectorIN11opentracing2v29LogRecordESaIS2_EED2Ev+0xb6>
  3ae25e:	0f 18 3d cb 3a d1 ff                            	prefetchit0 -0x2ec535(%rip)        # c1d30 <_ZNSt6vectorIN11opentracing2v29LogRecordESaIS2_EED2Ev>
  3ae265:	0f 18 3d d7 3a d1 ff                            	prefetchit0 -0x2ec529(%rip)        # c1d43 <_ZNSt6vectorIN11opentracing2v29LogRecordESaIS2_EED2Ev+0x13>
  3ae26c:	41 53                                           	push   %r11
  3ae26e:	4c 8b 1d 33 14 ff ff                            	mov    -0xebcd(%rip),%r11        # 39f6a8 <pthread_cond_signal@GLIBC_2.3.2>
  3ae275:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3ae27d:	41 5b                                           	pop    %r11
  3ae27f:	e9 dc 31 ce ff                                  	jmp    91460 <pthread_mutex_unlock@plt>
  3ae284:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ae28e:	66 90                                           	xchg   %ax,%ax
  3ae290:	0f 18 3d 2e 6f e2 ff                            	prefetchit0 -0x1d90d2(%rip)        # 1d51c5 <_ZN13jaegertracing4SpanD2Ev+0x15>
  3ae297:	e9 04 7c e8 ff                                  	jmp    235ea0 <_ZNSt18condition_variable10notify_oneEv>
  3ae29c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae2a0:	0f 18 3d 99 66 e2 ff                            	prefetchit0 -0x1d9967(%rip)        # 1d4940 <_ZN13jaegertracing9reporters14RemoteReporter10sweepQueueEv+0x70>
  3ae2a7:	e9 b4 31 ce ff                                  	jmp    91460 <pthread_mutex_unlock@plt>
  3ae2ac:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae2b0:	41 53                                           	push   %r11
  3ae2b2:	4c 8b 1d 87 17 ff ff                            	mov    -0xe879(%rip),%r11        # 39fa40 <pthread_cond_clockwait@GLIBC_2.34>
  3ae2b9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3ae2c1:	41 0f 18 93 63 00 00 00                         	prefetcht1 0x63(%r11)
  3ae2c9:	41 5b                                           	pop    %r11
  3ae2cb:	e9 00 32 ce ff                                  	jmp    914d0 <pthread_mutex_lock@plt>
  3ae2d0:	0f 18 3d 49 33 ce ff                            	prefetchit0 -0x31ccb7(%rip)        # 91620 <clock_gettime@plt>
  3ae2d7:	0f 18 3d f2 31 ce ff                            	prefetchit0 -0x31ce0e(%rip)        # 914d0 <pthread_mutex_lock@plt>
  3ae2de:	0f 18 3d 4b 35 ce ff                            	prefetchit0 -0x31cab5(%rip)        # 91830 <pthread_mutex_trylock@plt>
  3ae2e5:	0f 18 3d d4 57 e0 ff                            	prefetchit0 -0x1fa82c(%rip)        # 1b3ac0 <_ZN13jaegertracing11SpanContextC2ERKS0_>
  3ae2ec:	e9 1f 49 e8 ff                                  	jmp    232c10 <_ZNSt6chrono3_V212steady_clock3nowEv>
  3ae2f1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ae2fb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3ae300:	0f 18 3d 39 a6 e0 ff                            	prefetchit0 -0x1f59c7(%rip)        # 1b8940 <_ZN13jaegertracing12UDPTransport6appendERKNS_4SpanE>
  3ae307:	0f 18 3d b2 b4 e0 ff                            	prefetchit0 -0x1f4b4e(%rip)        # 1b97c0 <_ZNK13jaegertracing4Span6thriftEv>
  3ae30e:	0f 18 3d 96 aa e0 ff                            	prefetchit0 -0x1f556a(%rip)        # 1b8dab <_ZN13jaegertracing12UDPTransport6appendERKNS_4SpanE+0x46b>
  3ae315:	e9 26 83 e7 ff                                  	jmp    226640 <_ZdlPv>
  3ae31a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  3ae320:	0f 18 3d 19 f1 d0 ff                            	prefetchit0 -0x2f0ee7(%rip)        # bd440 <_ZN13jaegertracing11SpanContext4swapERS0_>
  3ae327:	e9 04 35 ce ff                                  	jmp    91830 <pthread_mutex_trylock@plt>
  3ae32c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae330:	0f 18 3d 39 a4 ef ff                            	prefetchit0 -0x105bc7(%rip)        # 2a8770 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_>
  3ae337:	0f 18 3d 1a 88 ef ff                            	prefetchit0 -0x1077e6(%rip)        # 2a6b58 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_assignERKS4_+0xd8>
  3ae33e:	0f 18 3d bd 6c e2 ff                            	prefetchit0 -0x1d9343(%rip)        # 1d5002 <_ZN13jaegertracing4SpanC2ERKS0_+0x252>
  3ae345:	0f 18 3d b4 87 ef ff                            	prefetchit0 -0x10784c(%rip)        # 2a6b00 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_assignERKS4_+0x80>
  3ae34c:	e9 6f 57 e0 ff                                  	jmp    1b3ac0 <_ZN13jaegertracing11SpanContextC2ERKS0_>
  3ae351:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ae35b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3ae360:	0f 18 3d 5a 70 e0 ff                            	prefetchit0 -0x1f8fa6(%rip)        # 1b53c1 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EEaSERKS3_+0x11>
  3ae367:	e9 d4 f0 d0 ff                                  	jmp    bd440 <_ZN13jaegertracing11SpanContext4swapERS0_>
  3ae36c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae370:	0f 18 3d 69 7a e2 ff                            	prefetchit0 -0x1d8597(%rip)        # 1d5de0 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE20_M_allocate_and_copyIN9__gnu_cxx17__normal_iteratorIPKS1_S3_EEEEPS1_mT_SB_>
  3ae377:	0f 18 3d 62 73 e2 ff                            	prefetchit0 -0x1d8c9e(%rip)        # 1d56e0 <_ZNSt6vectorIN13jaegertracing9LogRecordESaIS1_EEaSERKS3_>
  3ae37e:	0f 18 3d fb 86 ef ff                            	prefetchit0 -0x107905(%rip)        # 2a6a80 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_assignERKS4_>
  3ae385:	0f 18 3d 24 70 e0 ff                            	prefetchit0 -0x1f8fdc(%rip)        # 1b53b0 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EEaSERKS3_>
  3ae38c:	0f 18 3d 6e 73 e2 ff                            	prefetchit0 -0x1d8c92(%rip)        # 1d5701 <_ZNSt6vectorIN13jaegertracing9LogRecordESaIS1_EEaSERKS3_+0x21>
  3ae393:	0f 18 3d b6 2d ce ff                            	prefetchit0 -0x31d24a(%rip)        # 91150 <memcpy@plt>
  3ae39a:	0f 18 3d 1b 72 e0 ff                            	prefetchit0 -0x1f8de5(%rip)        # 1b55bc <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EEaSERKS3_+0x20c>
  3ae3a1:	0f 18 3d 58 7a e2 ff                            	prefetchit0 -0x1d85a8(%rip)        # 1d5e00 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE20_M_allocate_and_copyIN9__gnu_cxx17__normal_iteratorIPKS1_S3_EEEEPS1_mT_SB_+0x20>
  3ae3a8:	e9 f3 31 ce ff                                  	jmp    915a0 <memset@plt>
  3ae3ad:	0f 1f 00                                        	nopl   (%rax)
  3ae3b0:	0f 18 3d 0b 72 e0 ff                            	prefetchit0 -0x1f8df5(%rip)        # 1b55c2 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EEaSERKS3_+0x212>
  3ae3b7:	e9 c4 86 ef ff                                  	jmp    2a6a80 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_assignERKS4_>
  3ae3bc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae3c0:	0f 18 3d d9 7a e8 ff                            	prefetchit0 -0x178527(%rip)        # 235ea0 <_ZNSt18condition_variable10notify_oneEv>
  3ae3c7:	0f 18 3d c2 b8 e3 ff                            	prefetchit0 -0x1c473e(%rip)        # 1e9c90 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE>
  3ae3ce:	0f 18 3d db 6d e2 ff                            	prefetchit0 -0x1d9225(%rip)        # 1d51b0 <_ZN13jaegertracing4SpanD2Ev>
  3ae3d5:	0f 18 3d 26 6e e2 ff                            	prefetchit0 -0x1d91da(%rip)        # 1d5202 <_ZN13jaegertracing4SpanD2Ev+0x52>
  3ae3dc:	0f 18 3d e2 6d e2 ff                            	prefetchit0 -0x1d921e(%rip)        # 1d51c5 <_ZN13jaegertracing4SpanD2Ev+0x15>
  3ae3e3:	e9 78 30 ce ff                                  	jmp    91460 <pthread_mutex_unlock@plt>
  3ae3e8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3ae3f0:	0f 18 3d b9 de d0 ff                            	prefetchit0 -0x2f2147(%rip)        # bc2b0 <_ZN13jaegertracing11SpanContextD0Ev>
  3ae3f7:	0f 18 3d 82 40 ce ff                            	prefetchit0 -0x31bf7e(%rip)        # 92480 <pthread_cond_clockwait@plt>
  3ae3fe:	e9 9d 31 ce ff                                  	jmp    915a0 <memset@plt>
  3ae403:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ae40d:	0f 1f 00                                        	nopl   (%rax)
  3ae410:	0f 18 3d 1c 8b e0 ff                            	prefetchit0 -0x1f74e4(%rip)        # 1b6f33 <_ZNSt12_Destroy_auxILb0EE9__destroyIPN13jaegertracing9ReferenceEEEvT_S5_+0x3>
  3ae417:	0f 18 3d 13 76 e2 ff                            	prefetchit0 -0x1d89ed(%rip)        # 1d5a31 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EEaSERKS3_+0x1c1>
  3ae41e:	0f 18 3d 1b 76 e2 ff                            	prefetchit0 -0x1d89e5(%rip)        # 1d5a40 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EEaSERKS3_+0x1d0>
  3ae425:	0f 18 3d b4 9d e7 ff                            	prefetchit0 -0x18624c(%rip)        # 2281e0 <_Znwm>
  3ae42c:	0f 18 3d cf 8b e0 ff                            	prefetchit0 -0x1f7431(%rip)        # 1b7002 <_ZNSt12_Destroy_auxILb0EE9__destroyIPN13jaegertracing9ReferenceEEEvT_S5_+0xd2>
  3ae433:	e9 a8 79 e2 ff                                  	jmp    1d5de0 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE20_M_allocate_and_copyIN9__gnu_cxx17__normal_iteratorIPKS1_S3_EEEEPS1_mT_SB_>
  3ae438:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3ae440:	0f 18 3d 79 56 e0 ff                            	prefetchit0 -0x1fa987(%rip)        # 1b3ac0 <_ZN13jaegertracing11SpanContextC2ERKS0_>
  3ae447:	0f 18 3d 52 f5 d0 ff                            	prefetchit0 -0x2f0aae(%rip)        # bd9a0 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_>
  3ae44e:	0f 18 3d 2d f0 d0 ff                            	prefetchit0 -0x2f0fd3(%rip)        # bd482 <_ZN13jaegertracing11SpanContext4swapERS0_+0x42>
  3ae455:	0f 18 3d 24 a3 ef ff                            	prefetchit0 -0x105cdc(%rip)        # 2a8780 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_+0x10>
  3ae45c:	0f 18 3d df 56 e0 ff                            	prefetchit0 -0x1fa921(%rip)        # 1b3b42 <_ZN13jaegertracing11SpanContextC2ERKS0_+0x82>
  3ae463:	e9 48 69 e2 ff                                  	jmp    1d4db0 <_ZN13jaegertracing4SpanC2ERKS0_>
  3ae468:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3ae470:	0f 18 3d 49 fd e2 ff                            	prefetchit0 -0x1d02b7(%rip)        # 1de1c0 <_ZN13jaegertracing6thrift4SpanD1Ev>
  3ae477:	e9 54 36 e3 ff                                  	jmp    1e1ad0 <_ZNSt6vectorIN13jaegertracing6thrift7SpanRefESaIS2_EEaSERKS4_>
  3ae47c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae480:	0f 18 3d e9 ba d0 ff                            	prefetchit0 -0x2f4517(%rip)        # b9f70 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EED2Ev>
  3ae487:	0f 18 3d f4 ba d0 ff                            	prefetchit0 -0x2f450c(%rip)        # b9f82 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EED2Ev+0x12>
  3ae48e:	e9 3d 30 ce ff                                  	jmp    914d0 <pthread_mutex_lock@plt>
  3ae493:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ae49d:	0f 1f 00                                        	nopl   (%rax)
  3ae4a0:	0f 18 3d a9 61 e2 ff                            	prefetchit0 -0x1d9e57(%rip)        # 1d4650 <_ZN13jaegertracing9reporters14RemoteReporter6reportERKNS_4SpanE>
  3ae4a7:	0f 18 3d b2 7c e2 ff                            	prefetchit0 -0x1d834e(%rip)        # 1d6160 <_ZNSt5dequeIN13jaegertracing4SpanESaIS1_EE16_M_push_back_auxIJRKS1_EEEvDpOT_>
  3ae4ae:	0f 18 3d 9b 53 d0 ff                            	prefetchit0 -0x2fac65(%rip)        # b3850 <_ZN13jaegertracing7metrics11NullCounter3incEl>
  3ae4b5:	0f 18 3d 04 7d e2 ff                            	prefetchit0 -0x1d82fc(%rip)        # 1d61c0 <_ZNSt5dequeIN13jaegertracing4SpanESaIS1_EE16_M_push_back_auxIJRKS1_EEEvDpOT_+0x60>
  3ae4bc:	0f 18 3d 5d cd e3 ff                            	prefetchit0 -0x1c32a3(%rip)        # 1eb220 <_ZNK13jaegertracing4Span7contextEv>
  3ae4c3:	0f 18 3d 16 9d e7 ff                            	prefetchit0 -0x1862ea(%rip)        # 2281e0 <_Znwm>
  3ae4ca:	0f 18 3d 37 41 ce ff                            	prefetchit0 -0x31bec9(%rip)        # 92608 <malloc@plt>
  3ae4d1:	e9 8a 2f ce ff                                  	jmp    91460 <pthread_mutex_unlock@plt>
  3ae4d6:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ae4e0:	0f 18 3d 1b 6d e2 ff                            	prefetchit0 -0x1d92e5(%rip)        # 1d5202 <_ZN13jaegertracing4SpanD2Ev+0x52>
  3ae4e7:	e9 c4 6c e2 ff                                  	jmp    1d51b0 <_ZN13jaegertracing4SpanD2Ev>
  3ae4ec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae4f0:	0f 18 3d d9 3a ed ff                            	prefetchit0 -0x12c527(%rip)        # 281fd0 <_ZSt9use_facetISt7num_getIcSt19istreambuf_iteratorIcSt11char_traitsIcEEEERKT_RKSt6locale>
  3ae4f7:	e9 74 81 e7 ff                                  	jmp    226670 <__dynamic_cast>
  3ae4fc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae500:	0f 18 3d 81 4e e0 ff                            	prefetchit0 -0x1fb17f(%rip)        # 1b3388 <_ZN13jaegertracing11SpanContext10fromStreamERSi+0x58>
  3ae507:	0f 18 3d b2 f6 d0 ff                            	prefetchit0 -0x2f094e(%rip)        # bdbc0 <_ZNK13jaegertracing11SpanContext5printISoEEvRT_>
  3ae50e:	0f 18 3d 1b 4e e0 ff                            	prefetchit0 -0x1fb1e5(%rip)        # 1b3330 <_ZN13jaegertracing11SpanContext10fromStreamERSi>
  3ae515:	0f 18 3d 25 4e e0 ff                            	prefetchit0 -0x1fb1db(%rip)        # 1b3341 <_ZN13jaegertracing11SpanContext10fromStreamERSi+0x11>
  3ae51c:	0f 18 3d a4 4e e0 ff                            	prefetchit0 -0x1fb15c(%rip)        # 1b33c7 <_ZN13jaegertracing11SpanContext10fromStreamERSi+0x97>
  3ae523:	e9 48 81 e7 ff                                  	jmp    226670 <__dynamic_cast>
  3ae528:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3ae530:	0f 18 3d b9 61 ed ff                            	prefetchit0 -0x129e47(%rip)        # 2846f0 <_ZSt9use_facetISt5ctypeIcEERKT_RKSt6locale>
  3ae537:	0f 18 3d 82 3b ed ff                            	prefetchit0 -0x12c47e(%rip)        # 2820c0 <_ZSt9has_facetISt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEEEbRKSt6locale>
  3ae53e:	e9 2d 81 e7 ff                                  	jmp    226670 <__dynamic_cast>
  3ae543:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ae54d:	0f 1f 00                                        	nopl   (%rax)
  3ae550:	0f 18 3d e5 6d ef ff                            	prefetchit0 -0x10921b(%rip)        # 2a533c <_ZNSt15basic_streambufIcSt11char_traitsIcEE6xsputnEPKcl+0xc>
  3ae557:	0f 18 3d 62 ec ee ff                            	prefetchit0 -0x11139e(%rip)        # 29d1c0 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8overflowEi>
  3ae55e:	0f 18 3d cb e6 ee ff                            	prefetchit0 -0x111935(%rip)        # 29cc30 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8_M_pbumpEPcS5_l>
  3ae565:	0f 18 3d d5 e6 ee ff                            	prefetchit0 -0x11192b(%rip)        # 29cc41 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8_M_pbumpEPcS5_l+0x11>
  3ae56c:	0f 18 3d ce 6d ef ff                            	prefetchit0 -0x109232(%rip)        # 2a5341 <_ZNSt15basic_streambufIcSt11char_traitsIcEE6xsputnEPKcl+0x11>
  3ae573:	0f 18 3d 88 ec ee ff                            	prefetchit0 -0x111378(%rip)        # 29d202 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8overflowEi+0x42>
  3ae57a:	e9 b1 d3 e7 ff                                  	jmp    22b930 <_ZNKSt6locale2id5_M_idEv>
  3ae57f:	90                                              	nop
  3ae580:	0f 18 3d 79 7d ee ff                            	prefetchit0 -0x118287(%rip)        # 296300 <_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l>
  3ae587:	e9 a4 e6 ee ff                                  	jmp    29cc30 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8_M_pbumpEPcS5_l>
  3ae58c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae590:	0f 18 3d 89 a7 e7 ff                            	prefetchit0 -0x185877(%rip)        # 228d20 <_ZNK10__cxxabiv121__vmi_class_type_info12__do_dyncastElNS_17__class_type_info10__sub_kindEPKS1_PKvS4_S6_RNS1_16__dyncast_resultE+0x550>
  3ae597:	0f 18 3d 42 82 ed ff                            	prefetchit0 -0x127dbe(%rip)        # 2867e0 <_ZSt9has_facetISt5ctypeIcEEbRKSt6locale>
  3ae59e:	0f 18 3d 2b a2 e7 ff                            	prefetchit0 -0x185dd5(%rip)        # 2287d0 <_ZNK10__cxxabiv121__vmi_class_type_info12__do_dyncastElNS_17__class_type_info10__sub_kindEPKS1_PKvS4_S6_RNS1_16__dyncast_resultE>
  3ae5a5:	0f 18 3d 57 8f ec ff                            	prefetchit0 -0x1370a9(%rip)        # 277503 <_ZNSt9basic_iosIcSt11char_traitsIcEE15_M_cache_localeERKSt6locale+0x13>
  3ae5ac:	0f 18 3d 3d 8f ec ff                            	prefetchit0 -0x1370c3(%rip)        # 2774f0 <_ZNSt9basic_iosIcSt11char_traitsIcEE15_M_cache_localeERKSt6locale>
  3ae5b3:	e9 a8 93 ec ff                                  	jmp    277960 <_ZNSt9basic_iosIcSt11char_traitsIcEE4initEPSt15basic_streambufIcS1_E>
  3ae5b8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3ae5c0:	0f 18 3d f9 e8 ee ff                            	prefetchit0 -0x111707(%rip)        # 29cec0 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE7_M_syncEPcmm>
  3ae5c7:	e9 84 ec e7 ff                                  	jmp    22d250 <_ZNSt6localeC1Ev>
  3ae5cc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae5d0:	41 53                                           	push   %r11
  3ae5d2:	4c 8b 1d af 0d ff ff                            	mov    -0xf251(%rip),%r11        # 39f388 <strlen@GLIBC_2.2.5>
  3ae5d9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3ae5e1:	41 5b                                           	pop    %r11
  3ae5e3:	e9 28 31 ce ff                                  	jmp    91710 <strlen@plt>
  3ae5e8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3ae5f0:	0f 18 3d 09 7e d2 ff                            	prefetchit0 -0x2d81f7(%rip)        # d6400 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE20readStructBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  3ae5f7:	0f 18 3d f2 7d d2 ff                            	prefetchit0 -0x2d820e(%rip)        # d63f0 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE19readMessageEnd_virtEv>
  3ae5fe:	e9 0d 3e ce ff                                  	jmp    92410 <memcmp@plt>
  3ae603:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3ae60d:	0f 1f 00                                        	nopl   (%rax)
  3ae610:	0f 18 3d f9 80 cf ff                            	prefetchit0 -0x307f07(%rip)        # a6710 <_ZNSt23_Sp_counted_ptr_inplaceINSt13__future_base17_Async_state_implINSt6thread8_InvokerISt5tupleIJZN13media_service14MovieIdHandler13UploadMovieIdElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiRKSt3mapISC_SC_St4lessISC_ESaISt4pairISD_SC_EEEE3$_0EEEEvEESaISR_ELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv>
  3ae617:	e9 74 2f ce ff                                  	jmp    91590 <pthread_join@plt>
  3ae61c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3ae620:	41 53                                           	push   %r11
  3ae622:	4c 8b 1d ff 03 ff ff                            	mov    -0xfc01(%rip),%r11        # 39ea28 <free@GLIBC_2.2.5>
  3ae629:	41 0f 18 93 63 11 00 00                         	prefetcht1 0x1163(%r11)
  3ae631:	4c 8b 1d 78 0c ff ff                            	mov    -0xf388(%rip),%r11        # 39f2b0 <poll@GLIBC_2.2.5>
  3ae638:	41 0f 18 93 90 5e 00 00                         	prefetcht1 0x5e90(%r11)
  3ae640:	4c 8b 1d e1 13 ff ff                            	mov    -0xec1f(%rip),%r11        # 39fa28 <pthread_create@GLIBC_2.34>
  3ae647:	41 0f 18 93 80 0a 00 00                         	prefetcht1 0xa80(%r11)
  3ae64f:	41 5b                                           	pop    %r11
  3ae651:	e9 fa 3d ce ff                                  	jmp    92450 <pthread_create@plt>
