
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_native_it0/317486ab030170061457bacd8d793ef2a68b3da84a619f34430ec865864426e5/UserReviewService:     file format elf64-x86-64


Disassembly of section .text.prefetch_calls:

00000000001d7340 <.text.prefetch_calls>:
  1d7340:	0f 18 3d 99 19 e9 ff                            	prefetchit0 -0x16e667(%rip)        # 68ce0 <_ZNK13media_service13TextMapReader10ForeachKeyESt8functionIFN11opentracing2v28expectedIvSt10error_codeEENS3_11string_viewES7_EE>
  1d7347:	0f 18 3d b2 cc e8 ff                            	prefetchit0 -0x17334e(%rip)        # 64000 <_ZNSt17_Function_handlerIFN11opentracing2v28expectedIvSt10error_codeEENS1_11string_viewES5_EZNK13jaegertracing11propagation10PropagatorIRKNS1_13TextMapReaderERKNS1_13TextMapWriterEE7extractESC_EUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESO_E_E9_M_invokeERKSt9_Any_dataOS5_SU_>
  1d734e:	0f 18 3d ac 19 e9 ff                            	prefetchit0 -0x16e654(%rip)        # 68d01 <_ZNK13media_service13TextMapReader10ForeachKeyESt8functionIFN11opentracing2v28expectedIvSt10error_codeEENS3_11string_viewES7_EE+0x21>
  1d7355:	0f 18 3d 34 c2 e8 ff                            	prefetchit0 -0x173dcc(%rip)        # 63590 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_>
  1d735c:	0f 18 3d dd 19 e9 ff                            	prefetchit0 -0x16e623(%rip)        # 68d40 <_ZNK13media_service13TextMapReader10ForeachKeyESt8functionIFN11opentracing2v28expectedIvSt10error_codeEENS3_11string_viewES7_EE+0x60>
  1d7363:	41 53                                           	push   %r11
  1d7365:	4c 8b 1d 9c de ff ff                            	mov    -0x2164(%rip),%r11        # 1d5208 <_ZN11opentracing2v26Tracer6GlobalEv@Base>
  1d736c:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7374:	4c 8b 1d 45 e2 ff ff                            	mov    -0x1dbb(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d737b:	41 0f 18 93 b0 65 fe ff                         	prefetcht1 -0x19a50(%r11)
  1d7383:	41 0f 18 93 60 69 00 00                         	prefetcht1 0x6960(%r11)
  1d738b:	41 5b                                           	pop    %r11
  1d738d:	e9 7e 60 e5 ff                                  	jmp    2d410 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  1d7392:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d739c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d73a0:	0f 18 3d d9 83 e7 ff                            	prefetchit0 -0x187c27(%rip)        # 4f780 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  1d73a7:	41 53                                           	push   %r11
  1d73a9:	4c 8b 1d 60 dd ff ff                            	mov    -0x22a0(%rip),%r11        # 1d5110 <_Znwm@GLIBCXX_3.4>
  1d73b0:	41 0f 18 93 b0 06 00 00                         	prefetcht1 0x6b0(%r11)
  1d73b8:	41 0f 18 93 d2 06 00 00                         	prefetcht1 0x6d2(%r11)
  1d73c0:	4c 8b 1d f9 e1 ff ff                            	mov    -0x1e07(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d73c7:	41 0f 18 93 10 5d fe ff                         	prefetcht1 -0x1a2f0(%r11)
  1d73cf:	41 0f 18 93 c0 31 00 00                         	prefetcht1 0x31c0(%r11)
  1d73d7:	41 5b                                           	pop    %r11
  1d73d9:	e9 32 60 e5 ff                                  	jmp    2d410 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  1d73de:	66 90                                           	xchg   %ax,%ax
  1d73e0:	41 53                                           	push   %r11
  1d73e2:	4c 8b 1d d7 e1 ff ff                            	mov    -0x1e29(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d73e9:	41 0f 18 93 50 79 00 00                         	prefetcht1 0x7950(%r11)
  1d73f1:	4c 8b 1d 28 e5 ff ff                            	mov    -0x1ad8(%rip),%r11        # 1d5920 <_ZNSt7__cxx1119basic_ostringstreamIcSt11char_traitsIcESaIcEEC1Ev@GLIBCXX_3.4.26>
  1d73f8:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7400:	41 0f 18 93 34 00 00 00                         	prefetcht1 0x34(%r11)
  1d7408:	41 5b                                           	pop    %r11
  1d740a:	e9 01 60 e5 ff                                  	jmp    2d410 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  1d740f:	90                                              	nop
  1d7410:	41 53                                           	push   %r11
  1d7412:	4c 8b 1d 87 e2 ff ff                            	mov    -0x1d79(%rip),%r11        # 1d56a0 <mongoc_client_get_collection@Base>
  1d7419:	41 0f 18 93 30 73 ff ff                         	prefetcht1 -0x8cd0(%r11)
  1d7421:	41 5b                                           	pop    %r11
  1d7423:	e9 f8 67 e5 ff                                  	jmp    2dc20 <mongoc_client_pool_pop@plt>
  1d7428:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d7430:	41 53                                           	push   %r11
  1d7432:	4c 8b 1d d7 dd ff ff                            	mov    -0x2229(%rip),%r11        # 1d5210 <pthread_once@GLIBC_2.34>
  1d7439:	41 0f 18 93 83 c5 00 00                         	prefetcht1 0xc583(%r11)
  1d7441:	4c 8b 1d a8 de ff ff                            	mov    -0x2158(%rip),%r11        # 1d52f0 <bson_destroy@Base>
  1d7448:	41 0f 18 93 00 d7 00 00                         	prefetcht1 0xd700(%r11)
  1d7450:	41 5b                                           	pop    %r11
  1d7452:	e9 e9 68 e5 ff                                  	jmp    2dd40 <mongoc_client_get_collection@plt>
  1d7457:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  1d7460:	41 53                                           	push   %r11
  1d7462:	4c 8b 1d a7 e0 ff ff                            	mov    -0x1f59(%rip),%r11        # 1d5510 <mongoc_collection_find_with_opts@Base>
  1d7469:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7471:	41 5b                                           	pop    %r11
  1d7473:	e9 a8 65 e5 ff                                  	jmp    2da20 <mongoc_collection_find_with_opts@plt>
  1d7478:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d7480:	0f 18 3d 09 6d e5 ff                            	prefetchit0 -0x1a92f7(%rip)        # 2e190 <bcon_new@plt>
  1d7487:	41 53                                           	push   %r11
  1d7489:	4c 8b 1d 38 e4 ff ff                            	mov    -0x1bc8(%rip),%r11        # 1d58c8 <bcon_new@Base>
  1d7490:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7498:	41 5b                                           	pop    %r11
  1d749a:	e9 f1 5b e5 ff                                  	jmp    2d090 <bson_bcon_magic@plt>
  1d749f:	90                                              	nop
  1d74a0:	41 53                                           	push   %r11
  1d74a2:	4c 8b 1d 1f e4 ff ff                            	mov    -0x1be1(%rip),%r11        # 1d58c8 <bcon_new@Base>
  1d74a9:	41 0f 18 93 b0 fe ff ff                         	prefetcht1 -0x150(%r11)
  1d74b1:	41 0f 18 93 13 00 00 00                         	prefetcht1 0x13(%r11)
  1d74b9:	41 5b                                           	pop    %r11
  1d74bb:	e9 d0 6c e5 ff                                  	jmp    2e190 <bcon_new@plt>
  1d74c0:	0f 18 3d b9 82 e7 ff                            	prefetchit0 -0x187d47(%rip)        # 4f780 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  1d74c7:	e9 44 5f e5 ff                                  	jmp    2d410 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  1d74cc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d74d0:	0f 18 3d 89 22 e9 ff                            	prefetchit0 -0x16dd77(%rip)        # 69760 <_ZNK11opentracing2v213SpanReference5ApplyERNS0_16StartSpanOptionsE>
  1d74d7:	41 53                                           	push   %r11
  1d74d9:	4c 8b 1d 30 dc ff ff                            	mov    -0x23d0(%rip),%r11        # 1d5110 <_Znwm@GLIBCXX_3.4>
  1d74e0:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d74e8:	41 0f 18 93 b0 06 00 00                         	prefetcht1 0x6b0(%r11)
  1d74f0:	41 0f 18 93 d2 06 00 00                         	prefetcht1 0x6d2(%r11)
  1d74f8:	4c 8b 1d c1 e0 ff ff                            	mov    -0x1f3f(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d74ff:	41 0f 18 93 40 1f 00 00                         	prefetcht1 0x1f40(%r11)
  1d7507:	41 0f 18 93 c0 31 00 00                         	prefetcht1 0x31c0(%r11)
  1d750f:	41 5b                                           	pop    %r11
  1d7511:	e9 6a 82 e7 ff                                  	jmp    4f780 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  1d7516:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7520:	41 53                                           	push   %r11
  1d7522:	4c 8b 1d 97 e0 ff ff                            	mov    -0x1f69(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d7529:	41 0f 18 93 41 ad ff ff                         	prefetcht1 -0x52bf(%r11)
  1d7531:	41 5b                                           	pop    %r11
  1d7533:	e9 f8 6c e5 ff                                  	jmp    2e230 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
  1d7538:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d7540:	0f 18 3d 99 60 e5 ff                            	prefetchit0 -0x1a9f67(%rip)        # 2d5e0 <bson_destroy@plt>
  1d7547:	e9 14 24 e9 ff                                  	jmp    69960 <_ZNSt6vectorIN11opentracing2v29LogRecordESaIS2_EED2Ev>
  1d754c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7550:	41 53                                           	push   %r11
  1d7552:	4c 8b 1d 67 e0 ff ff                            	mov    -0x1f99(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d7559:	41 0f 18 93 30 f5 ff ff                         	prefetcht1 -0xad0(%r11)
  1d7561:	41 0f 18 93 41 f5 ff ff                         	prefetcht1 -0xabf(%r11)
  1d7569:	41 5b                                           	pop    %r11
  1d756b:	e9 70 60 e5 ff                                  	jmp    2d5e0 <bson_destroy@plt>
  1d7570:	41 53                                           	push   %r11
  1d7572:	4c 8b 1d ff da ff ff                            	mov    -0x2501(%rip),%r11        # 1d5078 <mongoc_cursor_destroy@Base>
  1d7579:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7581:	4c 8b 1d 98 e0 ff ff                            	mov    -0x1f68(%rip),%r11        # 1d5620 <mongoc_cursor_next@Base>
  1d7588:	41 0f 18 93 00 2e 00 00                         	prefetcht1 0x2e00(%r11)
  1d7590:	41 0f 18 93 10 2e 00 00                         	prefetcht1 0x2e10(%r11)
  1d7598:	41 5b                                           	pop    %r11
  1d759a:	e9 41 60 e5 ff                                  	jmp    2d5e0 <bson_destroy@plt>
  1d759f:	90                                              	nop
  1d75a0:	0f 18 3d 7f 8b e7 ff                            	prefetchit0 -0x187481(%rip)        # 50126 <_ZN13media_service10ClientPoolINS_11RedisClientEE3PopEv+0x706>
  1d75a7:	0f 18 3d d2 d2 f6 ff                            	prefetchit0 -0x92d2e(%rip)        # 144880 <_ZNK9cpp_redis7network16redis_connection12is_connectedEv>
  1d75ae:	0f 18 3d bb db e6 ff                            	prefetchit0 -0x192445(%rip)        # 45170 <_ZN13media_service11RedisClient7ConnectEv>
  1d75b5:	0f 18 3d c4 61 f1 ff                            	prefetchit0 -0xe9e3c(%rip)        # ed780 <_ZNK9cpp_redis6client12is_connectedEv>
  1d75bc:	0f 18 3d fd 56 f7 ff                            	prefetchit0 -0x8a903(%rip)        # 14ccc0 <_ZNK7tacopie10tcp_client12is_connectedEv>
  1d75c3:	0f 18 3d 36 5e e5 ff                            	prefetchit0 -0x1aa1ca(%rip)        # 2d400 <pthread_mutex_lock@plt>
  1d75ca:	0f 18 3d 3f ef f6 ff                            	prefetchit0 -0x910c1(%rip)        # 146510 <_ZNK9cpp_redis7network10tcp_client12is_connectedEv>
  1d75d1:	0f 18 3d 4f 8f e7 ff                            	prefetchit0 -0x1870b1(%rip)        # 50527 <_ZN13media_service10ClientPoolINS_11RedisClientEE3PopEv+0xb07>
  1d75d8:	e9 43 84 e7 ff                                  	jmp    4fa20 <_ZN13media_service10ClientPoolINS_11RedisClientEE3PopEv>
  1d75dd:	0f 1f 00                                        	nopl   (%rax)
  1d75e0:	0f 18 3d 79 21 e9 ff                            	prefetchit0 -0x16de87(%rip)        # 69760 <_ZNK11opentracing2v213SpanReference5ApplyERNS0_16StartSpanOptionsE>
  1d75e7:	0f 18 3d 92 81 e7 ff                            	prefetchit0 -0x187e6e(%rip)        # 4f780 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  1d75ee:	e9 1d 5e e5 ff                                  	jmp    2d410 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  1d75f3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d75fd:	0f 1f 00                                        	nopl   (%rax)
  1d7600:	41 53                                           	push   %r11
  1d7602:	4c 8b 1d 07 db ff ff                            	mov    -0x24f9(%rip),%r11        # 1d5110 <_Znwm@GLIBCXX_3.4>
  1d7609:	41 0f 18 93 b0 06 00 00                         	prefetcht1 0x6b0(%r11)
  1d7611:	41 0f 18 93 d2 06 00 00                         	prefetcht1 0x6d2(%r11)
  1d7619:	4c 8b 1d a0 df ff ff                            	mov    -0x2060(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d7620:	41 0f 18 93 c5 1f 00 00                         	prefetcht1 0x1fc5(%r11)
  1d7628:	41 0f 18 93 c0 31 00 00                         	prefetcht1 0x31c0(%r11)
  1d7630:	41 5b                                           	pop    %r11
  1d7632:	e9 49 81 e7 ff                                  	jmp    4f780 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  1d7637:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  1d7640:	0f 18 3d 99 a2 f4 ff                            	prefetchit0 -0xb5d67(%rip)        # 1218e0 <_ZN9cpp_redis6client5zcardERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  1d7647:	0f 18 3d b2 a2 f4 ff                            	prefetchit0 -0xb5d4e(%rip)        # 121900 <_ZN9cpp_redis6client5zcardERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE+0x20>
  1d764e:	0f 18 3d 1b 9a f0 ff                            	prefetchit0 -0xf65e5(%rip)        # e1070 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.constprop.0>
  1d7655:	41 53                                           	push   %r11
  1d7657:	4c 8b 1d 62 de ff ff                            	mov    -0x219e(%rip),%r11        # 1d54c0 <_ZdlPv@GLIBCXX_3.4>
  1d765e:	41 0f 18 93 d0 3a ff ff                         	prefetcht1 -0xc530(%r11)
  1d7666:	4c 8b 1d c3 de ff ff                            	mov    -0x213d(%rip),%r11        # 1d5530 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructEmc@GLIBCXX_3.4.21>
  1d766d:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7675:	41 0f 18 93 14 00 00 00                         	prefetcht1 0x14(%r11)
  1d767d:	4c 8b 1d ac df ff ff                            	mov    -0x2054(%rip),%r11        # 1d5630 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@GLIBCXX_3.4.21>
  1d7684:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d768c:	41 5b                                           	pop    %r11
  1d768e:	e9 cd 63 e5 ff                                  	jmp    2da60 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructEmc@plt>
  1d7693:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d769d:	0f 1f 00                                        	nopl   (%rax)
  1d76a0:	0f 18 3d 79 65 f1 ff                            	prefetchit0 -0xe9a87(%rip)        # edc20 <_ZNK9cpp_redis6client15is_reconnectingEv>
  1d76a7:	e9 d4 5a e5 ff                                  	jmp    2d180 <_ZdlPvm@plt>
  1d76ac:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d76b0:	0f 18 3d 79 fd f5 ff                            	prefetchit0 -0xa0287(%rip)        # 137430 <_ZN9cpp_redis6client10try_commitEv>
  1d76b7:	0f 18 3d c4 f2 f6 ff                            	prefetchit0 -0x90d3c(%rip)        # 146982 <_ZN9cpp_redis7network10tcp_client11async_writeERNS0_16tcp_client_iface13write_requestE+0x12>
  1d76be:	0f 18 3d ab f2 f6 ff                            	prefetchit0 -0x90d55(%rip)        # 146970 <_ZN9cpp_redis7network10tcp_client11async_writeERNS0_16tcp_client_iface13write_requestE>
  1d76c5:	0f 18 3d 76 fd f5 ff                            	prefetchit0 -0xa028a(%rip)        # 137442 <_ZN9cpp_redis6client10try_commitEv+0x12>
  1d76cc:	e9 bf fd f5 ff                                  	jmp    137490 <_ZN9cpp_redis6client11sync_commitEv>
  1d76d1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d76db:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1d76e0:	0f 18 3d e9 29 e9 ff                            	prefetchit0 -0x16d617(%rip)        # 6a0d0 <_ZN9cpp_redis5replyC2ERKS0_>
  1d76e7:	0f 18 3d 94 2f f6 ff                            	prefetchit0 -0x9d06c(%rip)        # 13a682 <_ZNSt13__future_base7_ResultIN9cpp_redis5replyEE10_M_destroyEv+0x12>
  1d76ee:	0f 18 3d 3b 7e e9 ff                            	prefetchit0 -0x1681c5(%rip)        # 6f530 <_ZNSt13__future_base13_State_baseV217_M_complete_asyncEv>
  1d76f5:	0f 18 3d 94 27 e9 ff                            	prefetchit0 -0x16d86c(%rip)        # 69e90 <_ZNSt20__uninitialized_copyILb0EE13__uninit_copyIN9__gnu_cxx17__normal_iteratorIPKN9cpp_redis5replyESt6vectorIS5_SaIS5_EEEEPS5_EET0_T_SE_SD_>
  1d76fc:	0f 18 3d 6d 2f f6 ff                            	prefetchit0 -0x9d093(%rip)        # 13a670 <_ZNSt13__future_base7_ResultIN9cpp_redis5replyEE10_M_destroyEv>
  1d7703:	0f 18 3d 76 23 f6 ff                            	prefetchit0 -0x9dc8a(%rip)        # 139a80 <_ZNSt23_Sp_counted_ptr_inplaceINSt13__future_base13_State_baseV2ESaIS1_ELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv+0x30>
  1d770a:	e9 c1 70 e9 ff                                  	jmp    6e7d0 <_ZNKSt14__basic_futureIN9cpp_redis5replyEE13_M_get_resultEv>
  1d770f:	90                                              	nop
  1d7710:	0f 18 3d 39 db e6 ff                            	prefetchit0 -0x1924c7(%rip)        # 45250 <_ZN13media_service11RedisClient9KeepAliveEv>
  1d7717:	0f 18 3d ea ee e6 ff                            	prefetchit0 -0x191116(%rip)        # 46608 <_ZN13media_service17UserReviewHandler16UploadUserReviewEllllRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES7_St4lessIS7_ESaISt4pairIKS7_S7_EEE+0x1378>
  1d771e:	0f 18 3d 4b 49 f6 ff                            	prefetchit0 -0x9b6b5(%rip)        # 13c070 <_ZNK9cpp_redis5reply2okEv>
  1d7725:	0f 18 3d 84 90 e7 ff                            	prefetchit0 -0x186f7c(%rip)        # 507b0 <_ZN13media_service10ClientPoolINS_11RedisClientEE4PushEPS1_>
  1d772c:	e9 6f 72 e9 ff                                  	jmp    6e9a0 <_ZNSt20__uninitialized_copyILb0EE13__uninit_copyIPKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEPS7_EET0_T_SC_SB_>
  1d7731:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d773b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1d7740:	0f 18 3d c9 93 e7 ff                            	prefetchit0 -0x186c37(%rip)        # 50b10 <_ZNSt6vectorIN9cpp_redis5replyESaIS1_EED2Ev>
  1d7747:	41 53                                           	push   %r11
  1d7749:	4c 8b 1d 70 de ff ff                            	mov    -0x2190(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d7750:	41 0f 18 93 30 f5 ff ff                         	prefetcht1 -0xad0(%r11)
  1d7758:	41 5b                                           	pop    %r11
  1d775a:	e9 21 5a e5 ff                                  	jmp    2d180 <_ZdlPvm@plt>
  1d775f:	90                                              	nop
  1d7760:	41 53                                           	push   %r11
  1d7762:	4c 8b 1d d7 de ff ff                            	mov    -0x2129(%rip),%r11        # 1d5640 <mongoc_collection_find_and_modify@Base>
  1d7769:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7771:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
  1d7779:	41 5b                                           	pop    %r11
  1d777b:	e9 00 5a e5 ff                                  	jmp    2d180 <_ZdlPvm@plt>
  1d7780:	41 53                                           	push   %r11
  1d7782:	4c 8b 1d 37 de ff ff                            	mov    -0x21c9(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d7789:	41 0f 18 93 80 1c 00 00                         	prefetcht1 0x1c80(%r11)
  1d7791:	41 5b                                           	pop    %r11
  1d7793:	e9 98 8c e8 ff                                  	jmp    60430 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  1d7798:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d77a0:	41 53                                           	push   %r11
  1d77a2:	4c 8b 1d 67 de ff ff                            	mov    -0x2199(%rip),%r11        # 1d5610 <mongoc_client_pool_pop@Base>
  1d77a9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d77b1:	41 5b                                           	pop    %r11
  1d77b3:	e9 78 6b e5 ff                                  	jmp    2e330 <_ZNSt6localeD1Ev@plt>
  1d77b8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d77c0:	0f 18 3d 09 60 e5 ff                            	prefetchit0 -0x1a9ff7(%rip)        # 2d7d0 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode@plt>
  1d77c7:	41 53                                           	push   %r11
  1d77c9:	4c 8b 1d 18 dc ff ff                            	mov    -0x23e8(%rip),%r11        # 1d53e8 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode@GLIBCXX_3.4.21>
  1d77d0:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d77d8:	41 0f 18 93 11 00 00 00                         	prefetcht1 0x11(%r11)
  1d77e0:	41 5b                                           	pop    %r11
  1d77e2:	e9 79 64 e5 ff                                  	jmp    2dc60 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@plt>
  1d77e7:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  1d77f0:	0f 18 3d f9 c3 e8 ff                            	prefetchit0 -0x173c07(%rip)        # 63bf0 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE11decodeValueERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  1d77f7:	e9 34 59 e5 ff                                  	jmp    2d130 <memcpy@plt>
  1d77fc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7800:	0f 18 3d 69 c4 e8 ff                            	prefetchit0 -0x173b97(%rip)        # 63c70 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE12normalizeKeyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  1d7807:	0f 18 3d 72 c4 e8 ff                            	prefetchit0 -0x173b8e(%rip)        # 63c80 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE12normalizeKeyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE+0x10>
  1d780e:	e9 9d c8 e8 ff                                  	jmp    640b0 <_ZSt13__invoke_implIN11opentracing2v28expectedIvSt10error_codeEERZNK13jaegertracing11propagation10PropagatorIRKNS1_13TextMapReaderERKNS1_13TextMapWriterEE7extractESA_EUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESM_E_JNS1_11string_viewESP_EET_St14__invoke_otherOT0_DpOT1_>
  1d7813:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d781d:	0f 1f 00                                        	nopl   (%rax)
  1d7820:	0f 18 3d 69 dd e8 ff                            	prefetchit0 -0x172297(%rip)        # 65590 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_>
  1d7827:	e9 54 59 e5 ff                                  	jmp    2d180 <_ZdlPvm@plt>
  1d782c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7830:	0f 18 3d 19 69 e5 ff                            	prefetchit0 -0x1a96e7(%rip)        # 2e150 <_ZSt18_Rb_tree_incrementPKSt18_Rb_tree_node_base@plt>
  1d7837:	41 53                                           	push   %r11
  1d7839:	4c 8b 1d 68 e0 ff ff                            	mov    -0x1f98(%rip),%r11        # 1d58a8 <_ZSt18_Rb_tree_incrementPKSt18_Rb_tree_node_base@GLIBCXX_3.4>
  1d7840:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7848:	41 5b                                           	pop    %r11
  1d784a:	e9 31 59 e5 ff                                  	jmp    2d180 <_ZdlPvm@plt>
  1d784f:	90                                              	nop
  1d7850:	41 53                                           	push   %r11
  1d7852:	4c 8b 1d 67 dd ff ff                            	mov    -0x2299(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d7859:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7861:	41 0f 18 93 88 00 00 00                         	prefetcht1 0x88(%r11)
  1d7869:	4c 8b 1d 10 e1 ff ff                            	mov    -0x1ef0(%rip),%r11        # 1d5980 <_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l@GLIBCXX_3.4.9>
  1d7870:	41 0f 18 93 b0 3e fe ff                         	prefetcht1 -0x1c150(%r11)
  1d7878:	41 0f 18 93 40 46 fe ff                         	prefetcht1 -0x1b9c0(%r11)
  1d7880:	41 0f 18 93 70 46 fe ff                         	prefetcht1 -0x1b990(%r11)
  1d7888:	41 5b                                           	pop    %r11
  1d788a:	e9 f1 62 e5 ff                                  	jmp    2db80 <_ZN13jaegertracing11SpanContext10fromStreamERSi@plt>
  1d788f:	90                                              	nop
  1d7890:	0f 18 3d 69 d2 e8 ff                            	prefetchit0 -0x172d97(%rip)        # 64b00 <_ZN13jaegertracingeqERKNS_11SpanContextES2_>
  1d7897:	0f 18 3d 92 8b e8 ff                            	prefetchit0 -0x17746e(%rip)        # 60430 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  1d789e:	0f 18 3d 9e 8b e8 ff                            	prefetchit0 -0x177462(%rip)        # 60443 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev+0x13>
  1d78a5:	e9 86 d7 e8 ff                                  	jmp    65030 <_ZN13jaegertracing11SpanContext4swapERS0_>
  1d78aa:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1d78b0:	0f 18 3d 79 6a e5 ff                            	prefetchit0 -0x1a9587(%rip)        # 2e330 <_ZNSt6localeD1Ev@plt>
  1d78b7:	41 53                                           	push   %r11
  1d78b9:	4c 8b 1d 00 dc ff ff                            	mov    -0x2400(%rip),%r11        # 1d54c0 <_ZdlPv@GLIBCXX_3.4>
  1d78c0:	41 0f 18 93 a0 37 ff ff                         	prefetcht1 -0xc860(%r11)
  1d78c8:	4c 8b 1d a9 dd ff ff                            	mov    -0x2257(%rip),%r11        # 1d5678 <_ZNSt8ios_baseD2Ev@GLIBCXX_3.4>
  1d78cf:	41 0f 18 93 61 ff ff ff                         	prefetcht1 -0x9f(%r11)
  1d78d7:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d78df:	41 5b                                           	pop    %r11
  1d78e1:	e9 4a 8b e8 ff                                  	jmp    60430 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  1d78e6:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d78f0:	41 53                                           	push   %r11
  1d78f2:	4c 8b 1d 57 db ff ff                            	mov    -0x24a9(%rip),%r11        # 1d5450 <_ZNSo9_M_insertImEERSoT_@GLIBCXX_3.4.9>
  1d78f9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7901:	4c 8b 1d 78 e0 ff ff                            	mov    -0x1f88(%rip),%r11        # 1d5980 <_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l@GLIBCXX_3.4.9>
  1d7908:	41 0f 18 93 70 e8 fe ff                         	prefetcht1 -0x11790(%r11)
  1d7910:	41 0f 18 93 20 26 ff ff                         	prefetcht1 -0xd9e0(%r11)
  1d7918:	41 0f 18 93 31 26 ff ff                         	prefetcht1 -0xd9cf(%r11)
  1d7920:	41 0f 18 93 10 29 ff ff                         	prefetcht1 -0xd6f0(%r11)
  1d7928:	41 0f 18 93 a0 f5 ff ff                         	prefetcht1 -0xa60(%r11)
  1d7930:	41 0f 18 93 b0 f5 ff ff                         	prefetcht1 -0xa50(%r11)
  1d7938:	41 5b                                           	pop    %r11
  1d793a:	e9 41 df e8 ff                                  	jmp    65880 <_ZNK13jaegertracing7TraceID5printISoEEvRT_>
  1d793f:	90                                              	nop
  1d7940:	0f 18 3d 19 6b e5 ff                            	prefetchit0 -0x1a94e7(%rip)        # 2e460 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_@plt>
  1d7947:	41 53                                           	push   %r11
  1d7949:	4c 8b 1d e0 e0 ff ff                            	mov    -0x1f20(%rip),%r11        # 1d5a30 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_@GLIBCXX_3.4>
  1d7950:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7958:	41 0f 18 93 a8 02 00 00                         	prefetcht1 0x2a8(%r11)
  1d7960:	41 5b                                           	pop    %r11
  1d7962:	e9 a9 1c e9 ff                                  	jmp    69610 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE24_M_get_insert_unique_posERS7_>
  1d7967:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  1d7970:	41 53                                           	push   %r11
  1d7972:	4c 8b 1d 47 dc ff ff                            	mov    -0x23b9(%rip),%r11        # 1d55c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1d7979:	41 0f 18 93 10 5d fe ff                         	prefetcht1 -0x1a2f0(%r11)
  1d7981:	41 0f 18 93 60 1d 00 00                         	prefetcht1 0x1d60(%r11)
  1d7989:	41 0f 18 93 90 31 00 00                         	prefetcht1 0x3190(%r11)
  1d7991:	41 5b                                           	pop    %r11
  1d7993:	e9 88 58 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7998:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d79a0:	0f 18 3d 62 f2 ea ff                            	prefetchit0 -0x150d9e(%rip)        # 86c09 <_ZN13media_service26UserReviewServiceProcessor24process_UploadUserReviewEiPN6apache6thrift8protocol9TProtocolES5_Pv+0x2a9>
  1d79a7:	0f 18 3d 97 ee ea ff                            	prefetchit0 -0x151169(%rip)        # 86845 <_ZN13media_service26UserReviewServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x515>
  1d79ae:	0f 18 3d a2 1f eb ff                            	prefetchit0 -0x14e05e(%rip)        # 89957 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x77>
  1d79b5:	0f 18 3d ba ea ea ff                            	prefetchit0 -0x151546(%rip)        # 86476 <_ZN13media_service26UserReviewServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x146>
  1d79bc:	e9 bf 57 e5 ff                                  	jmp    2d180 <_ZdlPvm@plt>
  1d79c1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d79cb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1d79d0:	0f 18 3d 56 e6 e6 ff                            	prefetchit0 -0x1919aa(%rip)        # 4602d <_ZN13media_service17UserReviewHandler16UploadUserReviewEllllRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES7_St4lessIS7_ESaISt4pairIKS7_S7_EEE+0xd9d>
  1d79d7:	0f 18 3d f2 1d f6 ff                            	prefetchit0 -0x9e20e(%rip)        # 1397d0 <_ZNSt23_Sp_counted_ptr_inplaceINSt13__future_base13_State_baseV2ESaIS1_ELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv>
  1d79de:	e9 ad 24 e9 ff                                  	jmp    69e90 <_ZNSt20__uninitialized_copyILb0EE13__uninit_copyIN9__gnu_cxx17__normal_iteratorIPKN9cpp_redis5replyESt6vectorIS5_SaIS5_EEEEPS5_EET0_T_SE_SD_>
  1d79e3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d79ed:	0f 1f 00                                        	nopl   (%rax)
  1d79f0:	0f 18 3d 39 a3 e9 ff                            	prefetchit0 -0x165cc7(%rip)        # 71d30 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE12readI64_virtERl>
  1d79f7:	e9 94 5e e5 ff                                  	jmp    2d890 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@plt>
  1d79fc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7a00:	0f 18 3d 89 5e e5 ff                            	prefetchit0 -0x1aa177(%rip)        # 2d890 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@plt>
  1d7a07:	e9 44 aa e9 ff                                  	jmp    72450 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE14readStringBodyINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEEjRT_i>
  1d7a0c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7a10:	0f 18 3d 09 27 eb ff                            	prefetchit0 -0x14d8f7(%rip)        # 8a120 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE22_M_emplace_hint_uniqueIJRKSt21piecewise_construct_tSt5tupleIJRS7_EESJ_IJEEEEESt17_Rb_tree_iteratorIS8_ESt23_Rb_tree_const_iteratorIS8_EDpOT_>
  1d7a17:	e9 74 5e e5 ff                                  	jmp    2d890 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@plt>
  1d7a1c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7a20:	0f 18 3d 09 19 e9 ff                            	prefetchit0 -0x16e6f7(%rip)        # 69330 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_>
  1d7a27:	e9 f4 26 eb ff                                  	jmp    8a120 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE22_M_emplace_hint_uniqueIJRKSt21piecewise_construct_tSt5tupleIJRS7_EESJ_IJEEEEESt17_Rb_tree_iteratorIS8_ESt23_Rb_tree_const_iteratorIS8_EDpOT_>
  1d7a2c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7a30:	0f 18 3d f9 9e e9 ff                            	prefetchit0 -0x166107(%rip)        # 71930 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE20readStructBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  1d7a37:	0f 18 3d 62 b4 ea ff                            	prefetchit0 -0x154b9e(%rip)        # 82ea0 <_ZN13media_service39UserReviewService_UploadUserReview_args4readEPN6apache6thrift8protocol9TProtocolE>
  1d7a3e:	0f 18 3d 1b ef ea ff                            	prefetchit0 -0x1510e5(%rip)        # 86960 <_ZN13media_service26UserReviewServiceProcessor24process_UploadUserReviewEiPN6apache6thrift8protocol9TProtocolES5_Pv>
  1d7a45:	0f 18 3d f5 9e e9 ff                            	prefetchit0 -0x16610b(%rip)        # 71941 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE20readStructBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE+0x11>
  1d7a4c:	e9 8f 6a e5 ff                                  	jmp    2e4e0 <memcmp@plt>
  1d7a51:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7a5b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1d7a60:	0f 18 3d 39 9a e9 ff                            	prefetchit0 -0x1665c7(%rip)        # 714a0 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE22writeMessageBegin_virtERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  1d7a67:	0f 18 3d 12 a5 e9 ff                            	prefetchit0 -0x165aee(%rip)        # 71f80 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE17writeMessageBeginERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  1d7a6e:	e9 ed 61 e5 ff                                  	jmp    2dc60 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@plt>
  1d7a73:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7a7d:	0f 1f 00                                        	nopl   (%rax)
  1d7a80:	41 53                                           	push   %r11
  1d7a82:	4c 8b 1d f7 d5 ff ff                            	mov    -0x2a09(%rip),%r11        # 1d5080 <_ZNSt9exceptionD2Ev@GLIBCXX_3.4>
  1d7a89:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7a91:	41 5b                                           	pop    %r11
  1d7a93:	e9 28 04 ec ff                                  	jmp    97ec0 <_ZN13media_service16ServiceExceptionD1Ev>
  1d7a98:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d7aa0:	0f 18 3d 69 9e e9 ff                            	prefetchit0 -0x166197(%rip)        # 71910 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE21readMessageBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERNS1_12TMessageTypeERi>
  1d7aa7:	0f 18 3d 32 1e eb ff                            	prefetchit0 -0x14e1ce(%rip)        # 898e0 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv>
  1d7aae:	e9 cd 56 e5 ff                                  	jmp    2d180 <_ZdlPvm@plt>
  1d7ab3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7abd:	0f 1f 00                                        	nopl   (%rax)
  1d7ac0:	0f 18 3d b9 1b f6 ff                            	prefetchit0 -0x9e447(%rip)        # 139680 <_ZZNSt9once_flag18_Prepare_executionC4IZSt9call_onceIMNSt13__future_base13_State_baseV2EFvPSt8functionIFSt10unique_ptrINS3_12_Result_baseENS7_8_DeleterEEvEEPbEJPS4_SC_SD_EEvRS_OT_DpOT0_EUlvE_EERSI_ENUlvE_4_FUNEv>
  1d7ac7:	0f 18 3d 92 7d e9 ff                            	prefetchit0 -0x16826e(%rip)        # 6f860 <_ZNSt13__future_base13_State_baseV29_M_do_setEPSt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEPb>
  1d7ace:	41 53                                           	push   %r11
  1d7ad0:	4c 8b 1d e9 d9 ff ff                            	mov    -0x2617(%rip),%r11        # 1d54c0 <_ZdlPv@GLIBCXX_3.4>
  1d7ad7:	41 0f 18 93 10 34 ff ff                         	prefetcht1 -0xcbf0(%r11)
  1d7adf:	41 5b                                           	pop    %r11
  1d7ae1:	e9 3a 59 e5 ff                                  	jmp    2d420 <pthread_once@plt>
  1d7ae6:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7af0:	0f 18 3d 0d 47 f1 ff                            	prefetchit0 -0xeb8f3(%rip)        # ec204 <_ZNSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS5_EEC2ESt16initializer_listIS5_ERKS6_.constprop.3+0x84>
  1d7af7:	e9 34 56 e5 ff                                  	jmp    2d130 <memcpy@plt>
  1d7afc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7b00:	0f 18 3d 89 f9 f5 ff                            	prefetchit0 -0xa0677(%rip)        # 137490 <_ZN9cpp_redis6client11sync_commitEv>
  1d7b07:	e9 74 5e e5 ff                                  	jmp    2d980 <_ZdlPv@plt>
  1d7b0c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7b10:	0f 18 3d 09 d6 f6 ff                            	prefetchit0 -0x929f7(%rip)        # 145120 <_ZN9cpp_redis7network16redis_connection4sendERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS8_EE>
  1d7b17:	0f 18 3d a8 68 f1 ff                            	prefetchit0 -0xe9758(%rip)        # ee3c6 <_ZN9cpp_redis6client16unprotected_sendERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS7_EERKSt8functionIFvRNS_5replyEEE+0x26>
  1d7b1e:	0f 18 3d 4b 6c f1 ff                            	prefetchit0 -0xe93b5(%rip)        # ee770 <_ZN9cpp_redis6client4sendERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS7_EERKSt8functionIFvRNS_5replyEEE>
  1d7b25:	0f 18 3d 1a d6 f6 ff                            	prefetchit0 -0x929e6(%rip)        # 145146 <_ZN9cpp_redis7network16redis_connection4sendERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS8_EE+0x26>
  1d7b2c:	e9 ff 55 e5 ff                                  	jmp    2d130 <memcpy@plt>
  1d7b31:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7b3b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1d7b40:	0f 18 3d 59 68 f1 ff                            	prefetchit0 -0xe97a7(%rip)        # ee3a0 <_ZN9cpp_redis6client16unprotected_sendERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS7_EERKSt8functionIFvRNS_5replyEEE>
  1d7b47:	0f 18 3d c1 d4 f6 ff                            	prefetchit0 -0x92b3f(%rip)        # 14500f <_ZN9cpp_redis7network16redis_connection13build_commandERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS8_EE+0x77f>
  1d7b4e:	e9 dd 55 e5 ff                                  	jmp    2d130 <memcpy@plt>
  1d7b53:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7b5d:	0f 1f 00                                        	nopl   (%rax)
  1d7b60:	0f 18 3d db 55 f1 ff                            	prefetchit0 -0xeaa25(%rip)        # ed142 <_ZN9cpp_redis6client26connection_receive_handlerERNS_7network16redis_connectionERNS_5replyE+0x72>
  1d7b67:	e9 94 58 e5 ff                                  	jmp    2d400 <pthread_mutex_lock@plt>
  1d7b6c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7b70:	0f 18 3d 69 87 f0 ff                            	prefetchit0 -0xf7897(%rip)        # e02e0 <_ZNSt17_Function_handlerIFvRN9cpp_redis5replyEEZNS0_6client8exec_cmdERKSt8functionIFRS4_RKS5_IS3_EEEEUlS2_E_E9_M_invokeERKSt9_Any_dataS2_>
  1d7b77:	0f 18 3d c2 87 f0 ff                            	prefetchit0 -0xf783e(%rip)        # e0340 <_ZNSt17_Function_handlerIFvRN9cpp_redis5replyEEZNS0_6client8exec_cmdERKSt8functionIFRS4_RKS5_IS3_EEEEUlS2_E_E9_M_invokeERKSt9_Any_dataS2_+0x60>
  1d7b7e:	e9 fd 5d e5 ff                                  	jmp    2d980 <_ZdlPv@plt>
  1d7b83:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7b8d:	0f 1f 00                                        	nopl   (%rax)
  1d7b90:	41 53                                           	push   %r11
  1d7b92:	4c 8b 1d df da ff ff                            	mov    -0x2521(%rip),%r11        # 1d5678 <_ZNSt8ios_baseD2Ev@GLIBCXX_3.4>
  1d7b99:	41 0f 18 93 70 03 00 00                         	prefetcht1 0x370(%r11)
  1d7ba1:	41 5b                                           	pop    %r11
  1d7ba3:	e9 d8 5d e5 ff                                  	jmp    2d980 <_ZdlPv@plt>
  1d7ba8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d7bb0:	0f 18 3d 79 2b f6 ff                            	prefetchit0 -0x9d487(%rip)        # 13a730 <_ZNSt23_Sp_counted_ptr_inplaceISt7promiseIN9cpp_redis5replyEESaIS3_ELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv>
  1d7bb7:	0f 18 3d c8 2b f6 ff                            	prefetchit0 -0x9d438(%rip)        # 13a786 <_ZNSt23_Sp_counted_ptr_inplaceISt7promiseIN9cpp_redis5replyEESaIS3_ELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv+0x56>
  1d7bbe:	0f 18 3d ab 2d f6 ff                            	prefetchit0 -0x9d255(%rip)        # 13a970 <_ZNSt23_Sp_counted_ptr_inplaceISt7promiseIN9cpp_redis5replyEESaIS3_ELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv+0x240>
  1d7bc5:	0f 18 3d b9 2d f6 ff                            	prefetchit0 -0x9d247(%rip)        # 13a985 <_ZNSt23_Sp_counted_ptr_inplaceISt7promiseIN9cpp_redis5replyEESaIS3_ELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv+0x255>
  1d7bcc:	0f 18 3d 6e 2b f6 ff                            	prefetchit0 -0x9d492(%rip)        # 13a741 <_ZNSt23_Sp_counted_ptr_inplaceISt7promiseIN9cpp_redis5replyEESaIS3_ELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv+0x11>
  1d7bd3:	41 53                                           	push   %r11
  1d7bd5:	4c 8b 1d 24 d6 ff ff                            	mov    -0x29dc(%rip),%r11        # 1d5200 <pthread_mutex_lock@GLIBC_2.2.5>
  1d7bdc:	41 0f 18 93 00 af ff ff                         	prefetcht1 -0x5100(%r11)
  1d7be4:	41 0f 18 93 12 af ff ff                         	prefetcht1 -0x50ee(%r11)
  1d7bec:	4c 8b 1d cd d8 ff ff                            	mov    -0x2733(%rip),%r11        # 1d54c0 <_ZdlPv@GLIBCXX_3.4>
  1d7bf3:	41 0f 18 93 70 53 ff ff                         	prefetcht1 -0xac90(%r11)
  1d7bfb:	41 5b                                           	pop    %r11
  1d7bfd:	e9 fe 57 e5 ff                                  	jmp    2d400 <pthread_mutex_lock@plt>
  1d7c02:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7c0c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7c10:	0f 18 3d 81 d3 f6 ff                            	prefetchit0 -0x92c7f(%rip)        # 144f98 <_ZN9cpp_redis7network16redis_connection13build_commandERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS8_EE+0x708>
  1d7c17:	41 53                                           	push   %r11
  1d7c19:	4c 8b 1d 98 da ff ff                            	mov    -0x2568(%rip),%r11        # 1d56b8 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm@GLIBCXX_3.4.21>
  1d7c20:	41 0f 18 93 22 00 00 00                         	prefetcht1 0x22(%r11)
  1d7c28:	41 5b                                           	pop    %r11
  1d7c2a:	e9 f1 d4 f6 ff                                  	jmp    145120 <_ZN9cpp_redis7network16redis_connection4sendERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS8_EE>
  1d7c2f:	90                                              	nop
  1d7c30:	0f 18 3d 49 45 f1 ff                            	prefetchit0 -0xebab7(%rip)        # ec180 <_ZNSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS5_EEC2ESt16initializer_listIS5_ERKS6_.constprop.3>
  1d7c37:	e9 34 94 f0 ff                                  	jmp    e1070 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.constprop.0>
  1d7c3c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7c40:	0f 18 3d 39 6a e5 ff                            	prefetchit0 -0x1a95c7(%rip)        # 2e680 <_ZNSt13__future_base12_Result_baseC2Ev@plt>
  1d7c47:	41 53                                           	push   %r11
  1d7c49:	4c 8b 1d f0 de ff ff                            	mov    -0x2110(%rip),%r11        # 1d5b40 <_ZNSt13__future_base12_Result_baseC2Ev@GLIBCXX_3.4.15>
  1d7c50:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7c58:	41 5b                                           	pop    %r11
  1d7c5a:	e9 c1 55 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7c5f:	90                                              	nop
  1d7c60:	0f 18 3d 89 a3 f2 ff                            	prefetchit0 -0xd5c77(%rip)        # 101ff0 <_ZN9cpp_redis6client5zcardERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKSt8functionIFvRNS_5replyEEE>
  1d7c67:	0f 18 3d c2 a4 f2 ff                            	prefetchit0 -0xd5b3e(%rip)        # 102130 <_ZNSt17_Function_handlerIFRN9cpp_redis6clientERKSt8functionIFvRNS0_5replyEEEEZNS1_5zcardERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEUlS9_E_E9_M_invokeERKSt9_Any_dataS9_>
  1d7c6e:	0f 18 3d 8d a3 f2 ff                            	prefetchit0 -0xd5c73(%rip)        # 102002 <_ZN9cpp_redis6client5zcardERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKSt8functionIFvRNS_5replyEEE+0x12>
  1d7c75:	0f 18 3d c5 a3 f2 ff                            	prefetchit0 -0xd5c3b(%rip)        # 102041 <_ZN9cpp_redis6client5zcardERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKSt8functionIFvRNS_5replyEEE+0x51>
  1d7c7c:	e9 9f 55 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7c81:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7c8b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1d7c90:	0f 18 3d 89 77 f3 ff                            	prefetchit0 -0xc8877(%rip)        # 10f420 <_ZN9cpp_redis6client8exec_cmdERKSt8functionIFRS0_RKS1_IFvRNS_5replyEEEEE>
  1d7c97:	0f 18 3d a8 77 f3 ff                            	prefetchit0 -0xc8858(%rip)        # 10f446 <_ZN9cpp_redis6client8exec_cmdERKSt8functionIFRS0_RKS1_IFvRNS_5replyEEEEE+0x26>
  1d7c9e:	e9 7d 55 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7ca3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7cad:	0f 1f 00                                        	nopl   (%rax)
  1d7cb0:	0f 18 3d 19 c4 f0 ff                            	prefetchit0 -0xf3be7(%rip)        # e40d0 <_ZNSt17_Function_handlerIFRN9cpp_redis6clientERKSt8functionIFvRNS0_5replyEEEEZNS1_5zcardERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEUlS9_E_E10_M_managerERSt9_Any_dataRKSL_St18_Manager_operation>
  1d7cb7:	e9 14 2f f6 ff                                  	jmp    13abd0 <_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv>
  1d7cbc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7cc0:	0f 18 3d 19 64 f7 ff                            	prefetchit0 -0x89be7(%rip)        # 14e0e0 <_ZN7tacopie10tcp_client11async_writeERKNS0_13write_requestE>
  1d7cc7:	e9 14 d5 f6 ff                                  	jmp    1451e0 <_ZN9cpp_redis7network16redis_connection6commitEv>
  1d7ccc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7cd0:	41 53                                           	push   %r11
  1d7cd2:	4c 8b 1d 27 d5 ff ff                            	mov    -0x2ad9(%rip),%r11        # 1d5200 <pthread_mutex_lock@GLIBC_2.2.5>
  1d7cd9:	41 0f 18 93 40 91 ff ff                         	prefetcht1 -0x6ec0(%r11)
  1d7ce1:	41 0f 18 93 50 91 ff ff                         	prefetcht1 -0x6eb0(%r11)
  1d7ce9:	41 0f 18 93 40 b9 ff ff                         	prefetcht1 -0x46c0(%r11)
  1d7cf1:	41 0f 18 93 e0 ba ff ff                         	prefetcht1 -0x4520(%r11)
  1d7cf9:	4c 8b 1d c0 d7 ff ff                            	mov    -0x2840(%rip),%r11        # 1d54c0 <_ZdlPv@GLIBCXX_3.4>
  1d7d00:	41 0f 18 93 60 47 ff ff                         	prefetcht1 -0xb8a0(%r11)
  1d7d08:	41 5b                                           	pop    %r11
  1d7d0a:	e9 f1 56 e5 ff                                  	jmp    2d400 <pthread_mutex_lock@plt>
  1d7d0f:	90                                              	nop
  1d7d10:	0f 18 3d b9 6a e9 ff                            	prefetchit0 -0x169547(%rip)        # 6e7d0 <_ZNKSt14__basic_futureIN9cpp_redis5replyEE13_M_get_resultEv>
  1d7d17:	0f 18 3d 0b e1 e6 ff                            	prefetchit0 -0x191ef5(%rip)        # 45e29 <_ZN13media_service17UserReviewHandler16UploadUserReviewEllllRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES7_St4lessIS7_ESaISt4pairIKS7_S7_EEE+0xb99>
  1d7d1e:	e9 6d 56 e5 ff                                  	jmp    2d390 <pthread_mutex_unlock@plt>
  1d7d23:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7d2d:	0f 1f 00                                        	nopl   (%rax)
  1d7d30:	0f 18 3d 49 05 f5 ff                            	prefetchit0 -0xafab7(%rip)        # 128280 <_ZNSt17_Function_handlerIFvRN9cpp_redis5replyEEZNS0_6client8exec_cmdERKSt8functionIFRS4_RKS5_IS3_EEEEUlS2_E_E10_M_managerERSt9_Any_dataRKSG_St18_Manager_operation>
  1d7d37:	e9 f4 53 e5 ff                                  	jmp    2d130 <memcpy@plt>
  1d7d3c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7d40:	0f 18 3d 89 ef f6 ff                            	prefetchit0 -0x91077(%rip)        # 146cd0 <_ZNK9cpp_redis8builders13reply_builder15reply_availableEv>
  1d7d47:	e9 24 93 f0 ff                                  	jmp    e1070 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.constprop.0>
  1d7d4c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7d50:	0f 18 3d b3 d1 f6 ff                            	prefetchit0 -0x92e4d(%rip)        # 144f0a <_ZN9cpp_redis7network16redis_connection13build_commandERKSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS8_EE+0x67a>
  1d7d57:	e9 34 5b e5 ff                                  	jmp    2d890 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@plt>
  1d7d5c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7d60:	41 53                                           	push   %r11
  1d7d62:	4c 8b 1d 57 d7 ff ff                            	mov    -0x28a9(%rip),%r11        # 1d54c0 <_ZdlPv@GLIBCXX_3.4>
  1d7d69:	41 0f 18 93 c0 53 ff ff                         	prefetcht1 -0xac40(%r11)
  1d7d71:	41 5b                                           	pop    %r11
  1d7d73:	e9 f8 5f e5 ff                                  	jmp    2dd70 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_appendEPKcm@plt>
  1d7d78:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d7d80:	0f 18 3d b9 22 f6 ff                            	prefetchit0 -0x9dd47(%rip)        # 13a040 <_ZNSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS5_EEC1ERKS7_+0x30>
  1d7d87:	0f 18 3d 82 22 f6 ff                            	prefetchit0 -0x9dd7e(%rip)        # 13a010 <_ZNSt6vectorINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESaIS5_EEC1ERKS7_>
  1d7d8e:	e9 ed 5b e5 ff                                  	jmp    2d980 <_ZdlPv@plt>
  1d7d93:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7d9d:	0f 1f 00                                        	nopl   (%rax)
  1d7da0:	0f 18 3d 69 06 f7 ff                            	prefetchit0 -0x8f997(%rip)        # 148410 <_ZN9cpp_redis8builders14create_builderEc>
  1d7da7:	0f 18 3d 12 16 f7 ff                            	prefetchit0 -0x8e9ee(%rip)        # 1493c0 <_ZN9cpp_redis8builders15integer_builderC1Ev>
  1d7dae:	0f 18 3d 8b 06 f7 ff                            	prefetchit0 -0x8f975(%rip)        # 148440 <_ZN9cpp_redis8builders14create_builderEc+0x30>
  1d7db5:	0f 18 3d d4 41 f6 ff                            	prefetchit0 -0x9be2c(%rip)        # 13bf90 <_ZN9cpp_redis5replyC1Ev>
  1d7dbc:	0f 18 3d ad 63 e5 ff                            	prefetchit0 -0x1a9c53(%rip)        # 2e170 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE8_M_eraseEmm@plt>
  1d7dc3:	0f 18 3d 26 fe f6 ff                            	prefetchit0 -0x901da(%rip)        # 147bf0 <_ZN9cpp_redis8builders13reply_builder11build_replyEv>
  1d7dca:	41 53                                           	push   %r11
  1d7dcc:	4c 8b 1d e5 da ff ff                            	mov    -0x251b(%rip),%r11        # 1d58b8 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE8_M_eraseEmm@GLIBCXX_3.4.21>
  1d7dd3:	41 0f 18 93 13 00 00 00                         	prefetcht1 0x13(%r11)
  1d7ddb:	41 5b                                           	pop    %r11
  1d7ddd:	e9 8e 01 f7 ff                                  	jmp    147f70 <_ZN9cpp_redis8builders13reply_builderlsERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  1d7de2:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7dec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7df0:	0f 18 3d ff e0 f6 ff                            	prefetchit0 -0x91f01(%rip)        # 145ef6 <_ZN9cpp_redis7network16redis_connection26tcp_client_receive_handlerERKNS0_16tcp_client_iface11read_resultE+0x5b6>
  1d7df7:	0f 18 3d f2 18 f6 ff                            	prefetchit0 -0x9e70e(%rip)        # 1396f0 <_ZNSt17_Function_handlerIFvRN9cpp_redis7network16redis_connectionERNS0_5replyEESt5_BindIFMNS0_6clientEFvS3_S5_EPS8_St12_PlaceholderILi1EESC_ILi2EEEEE9_M_invokeERKSt9_Any_dataS3_S5_>
  1d7dfe:	0f 18 3d fd 18 f6 ff                            	prefetchit0 -0x9e703(%rip)        # 139702 <_ZNSt17_Function_handlerIFvRN9cpp_redis7network16redis_connectionERNS0_5replyEESt5_BindIFMNS0_6clientEFvS3_S5_EPS8_St12_PlaceholderILi1EESC_ILi2EEEEE9_M_invokeERKSt9_Any_dataS3_S5_+0x12>
  1d7e05:	0f 18 3d 77 dd f6 ff                            	prefetchit0 -0x92289(%rip)        # 145b83 <_ZN9cpp_redis7network16redis_connection26tcp_client_receive_handlerERKNS0_16tcp_client_iface11read_resultE+0x243>
  1d7e0c:	e9 bf ee f6 ff                                  	jmp    146cd0 <_ZNK9cpp_redis8builders13reply_builder15reply_availableEv>
  1d7e11:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7e1b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1d7e20:	0f 18 3d a9 52 f1 ff                            	prefetchit0 -0xead57(%rip)        # ed0d0 <_ZN9cpp_redis6client26connection_receive_handlerERNS_7network16redis_connectionERNS_5replyE>
  1d7e27:	e9 04 ef f6 ff                                  	jmp    146d30 <_ZNK9cpp_redis8builders13reply_builder9get_frontEv>
  1d7e2c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7e30:	0f 18 3d 09 78 f7 ff                            	prefetchit0 -0x887f7(%rip)        # 14f640 <_ZN7tacopie10tcp_socket4sendERKSt6vectorIcSaIcEEm>
  1d7e37:	0f 18 3d b2 77 f7 ff                            	prefetchit0 -0x8884e(%rip)        # 14f5f0 <_ZN7tacopie10tcp_socket17check_or_set_typeENS0_4typeE>
  1d7e3e:	e9 dd 53 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7e43:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7e4d:	0f 1f 00                                        	nopl   (%rax)
  1d7e50:	0f 18 3d 49 7d f7 ff                            	prefetchit0 -0x882b7(%rip)        # 14fba0 <_ZNK7tacopie10tcp_socket6get_fdEv>
  1d7e57:	e9 24 5b e5 ff                                  	jmp    2d980 <_ZdlPv@plt>
  1d7e5c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7e60:	0f 18 3d 89 77 f7 ff                            	prefetchit0 -0x88877(%rip)        # 14f5f0 <_ZN7tacopie10tcp_socket17check_or_set_typeENS0_4typeE>
  1d7e67:	e9 b4 53 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7e6c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7e70:	0f 18 3d 89 3d f7 ff                            	prefetchit0 -0x8c277(%rip)        # 14bc00 <_ZN7tacopie10io_service15set_wr_callbackERKNS_10tcp_socketERKSt8functionIFviEE>
  1d7e77:	e9 64 62 f7 ff                                  	jmp    14e0e0 <_ZN7tacopie10tcp_client11async_writeERKNS0_13write_requestE>
  1d7e7c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7e80:	0f 18 3d 19 14 f7 ff                            	prefetchit0 -0x8ebe7(%rip)        # 1492a0 <_ZN9cpp_redis8builders15integer_builderlsERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  1d7e87:	41 53                                           	push   %r11
  1d7e89:	4c 8b 1d 30 d4 ff ff                            	mov    -0x2bd0(%rip),%r11        # 1d52c0 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4findEPKcmm@GLIBCXX_3.4.21>
  1d7e90:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d7e98:	41 0f 18 93 25 00 00 00                         	prefetcht1 0x25(%r11)
  1d7ea0:	4c 8b 1d c9 db ff ff                            	mov    -0x2437(%rip),%r11        # 1d5a70 <memcmp@GLIBC_2.2.5>
  1d7ea7:	41 0f 18 93 00 fd ff ff                         	prefetcht1 -0x300(%r11)
  1d7eaf:	41 5b                                           	pop    %r11
  1d7eb1:	e9 5a 05 f7 ff                                  	jmp    148410 <_ZN9cpp_redis8builders14create_builderEc>
  1d7eb6:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7ec0:	41 53                                           	push   %r11
  1d7ec2:	4c 8b 1d f7 d5 ff ff                            	mov    -0x2a09(%rip),%r11        # 1d54c0 <_ZdlPv@GLIBCXX_3.4>
  1d7ec9:	41 0f 18 93 f0 48 ff ff                         	prefetcht1 -0xb710(%r11)
  1d7ed1:	41 5b                                           	pop    %r11
  1d7ed3:	e9 48 53 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7ed8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d7ee0:	0f 18 3d 19 3d f6 ff                            	prefetchit0 -0x9c2e7(%rip)        # 13bc00 <_ZN9cpp_redis5replyC1ERKS0_+0x3c0>
  1d7ee7:	0f 18 3d 82 91 f0 ff                            	prefetchit0 -0xf6e7e(%rip)        # e1070 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.constprop.0>
  1d7eee:	e9 2d 41 f6 ff                                  	jmp    13c020 <_ZN9cpp_redis5reply3setEl>
  1d7ef3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d7efd:	0f 1f 00                                        	nopl   (%rax)
  1d7f00:	0f 18 3d bd 5e f7 ff                            	prefetchit0 -0x8a143(%rip)        # 14ddc4 <_ZN7tacopie10tcp_client17on_read_availableEi+0x34>
  1d7f07:	0f 18 3d b2 33 f7 ff                            	prefetchit0 -0x8cc4e(%rip)        # 14b2c0 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_rd_eventERKiRNS2_14tracked_socketEEUlvE_E9_M_invokeERKSt9_Any_data>
  1d7f0e:	0f 18 3d ac 47 f7 ff                            	prefetchit0 -0x8b854(%rip)        # 14c6c1 <_ZN7tacopie10tcp_client12process_readERNS0_11read_resultE+0x21>
  1d7f15:	0f 18 3d 74 5e f7 ff                            	prefetchit0 -0x8a18c(%rip)        # 14dd90 <_ZN7tacopie10tcp_client17on_read_availableEi>
  1d7f1c:	0f 18 3d 7d 47 f7 ff                            	prefetchit0 -0x8b883(%rip)        # 14c6a0 <_ZN7tacopie10tcp_client12process_readERNS0_11read_resultE>
  1d7f23:	0f 18 3d f6 63 f7 ff                            	prefetchit0 -0x89c0a(%rip)        # 14e320 <_ZNSt17_Function_handlerIFviESt5_BindIFMN7tacopie10tcp_clientEFviEPS3_St12_PlaceholderILi1EEEEE9_M_invokeERKSt9_Any_dataOi>
  1d7f2a:	e9 f1 52 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7f2f:	90                                              	nop
  1d7f30:	0f 18 3d cb 34 f7 ff                            	prefetchit0 -0x8cb35(%rip)        # 14b402 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_wr_eventERKiRNS2_14tracked_socketEEUlvE_E9_M_invokeERKSt9_Any_data+0x22>
  1d7f37:	0f 18 3d a2 34 f7 ff                            	prefetchit0 -0x8cb5e(%rip)        # 14b3e0 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_wr_eventERKiRNS2_14tracked_socketEEUlvE_E9_M_invokeERKSt9_Any_data>
  1d7f3e:	0f 18 3d 3b 5f f7 ff                            	prefetchit0 -0x8a0c5(%rip)        # 14de80 <_ZN7tacopie10tcp_client18on_write_availableEi>
  1d7f45:	0f 18 3d f5 49 f7 ff                            	prefetchit0 -0x8b60b(%rip)        # 14c941 <_ZN7tacopie10tcp_client13process_writeERNS0_12write_resultE+0x11>
  1d7f4c:	0f 18 3d dd 49 f7 ff                            	prefetchit0 -0x8b623(%rip)        # 14c930 <_ZN7tacopie10tcp_client13process_writeERNS0_12write_resultE>
  1d7f53:	e9 c8 52 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7f58:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d7f60:	0f 18 3d 49 8a f7 ff                            	prefetchit0 -0x875b7(%rip)        # 1509b0 <_ZN7tacopie5utils11thread_poollsERKSt8functionIFvvEE>
  1d7f67:	e9 b4 52 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7f6c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7f70:	0f 18 3d 59 26 f7 ff                            	prefetchit0 -0x8d9a7(%rip)        # 14a5d0 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_wr_eventERKiRNS2_14tracked_socketEEUlvE_E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation>
  1d7f77:	0f 18 3d 62 89 f7 ff                            	prefetchit0 -0x8769e(%rip)        # 1508e0 <_ZN7tacopie5utils11thread_pool8add_taskERKSt8functionIFvvEE>
  1d7f7e:	0f 18 3d 7e 89 f7 ff                            	prefetchit0 -0x87682(%rip)        # 150903 <_ZN7tacopie5utils11thread_pool8add_taskERKSt8functionIFvvEE+0x23>
  1d7f85:	e9 96 52 e5 ff                                  	jmp    2d220 <_Znwm@plt>
  1d7f8a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1d7f90:	0f 18 3d 59 29 f7 ff                            	prefetchit0 -0x8d6a7(%rip)        # 14a8f0 <_ZN7tacopie10io_service16process_rd_eventERKiRNS0_14tracked_socketE>
  1d7f97:	0f 18 3d 63 29 f7 ff                            	prefetchit0 -0x8d69d(%rip)        # 14a901 <_ZN7tacopie10io_service16process_rd_eventERKiRNS0_14tracked_socketE+0x11>
  1d7f9e:	0f 18 3d 9f 29 f7 ff                            	prefetchit0 -0x8d661(%rip)        # 14a944 <_ZN7tacopie10io_service16process_rd_eventERKiRNS0_14tracked_socketE+0x54>
  1d7fa5:	0f 18 3d 44 36 f7 ff                            	prefetchit0 -0x8c9bc(%rip)        # 14b5f0 <_ZN7tacopie10io_service18init_poll_fds_infoEv>
  1d7fac:	0f 18 3d dd 63 f7 ff                            	prefetchit0 -0x89c23(%rip)        # 14e390 <_ZNSt17_Function_handlerIFviESt5_BindIFMN7tacopie10tcp_clientEFviEPS3_St12_PlaceholderILi1EEEEE10_M_managerERSt9_Any_dataRKSC_St18_Manager_operation>
  1d7fb3:	e9 68 59 e5 ff                                  	jmp    2d920 <__fdelt_chk@plt>
  1d7fb8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d7fc0:	0f 18 3d 7c 2b f7 ff                            	prefetchit0 -0x8d484(%rip)        # 14ab43 <_ZN7tacopie10io_service16process_wr_eventERKiRNS0_14tracked_socketE+0x53>
  1d7fc7:	0f 18 3d 22 2b f7 ff                            	prefetchit0 -0x8d4de(%rip)        # 14aaf0 <_ZN7tacopie10io_service16process_wr_eventERKiRNS0_14tracked_socketE>
  1d7fce:	0f 18 3d 2c 2b f7 ff                            	prefetchit0 -0x8d4d4(%rip)        # 14ab01 <_ZN7tacopie10io_service16process_wr_eventERKiRNS0_14tracked_socketE+0x11>
  1d7fd5:	e9 46 59 e5 ff                                  	jmp    2d920 <__fdelt_chk@plt>
  1d7fda:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1d7fe0:	0f 18 3d 09 2b f7 ff                            	prefetchit0 -0x8d4f7(%rip)        # 14aaf0 <_ZN7tacopie10io_service16process_wr_eventERKiRNS0_14tracked_socketE>
  1d7fe7:	e9 34 59 e5 ff                                  	jmp    2d920 <__fdelt_chk@plt>
  1d7fec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d7ff0:	41 53                                           	push   %r11
  1d7ff2:	4c 8b 1d 97 d0 ff ff                            	mov    -0x2f69(%rip),%r11        # 1d5090 <select@GLIBC_2.2.5>
  1d7ff9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d8001:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
  1d8009:	41 5b                                           	pop    %r11
  1d800b:	e9 10 59 e5 ff                                  	jmp    2d920 <__fdelt_chk@plt>
  1d8010:	41 53                                           	push   %r11
  1d8012:	4c 8b 1d 77 d0 ff ff                            	mov    -0x2f89(%rip),%r11        # 1d5090 <select@GLIBC_2.2.5>
  1d8019:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d8021:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
  1d8029:	41 5b                                           	pop    %r11
  1d802b:	e9 60 53 e5 ff                                  	jmp    2d390 <pthread_mutex_unlock@plt>
  1d8030:	0f 18 3d 19 8f f7 ff                            	prefetchit0 -0x870e7(%rip)        # 150f50 <_ZNK7tacopie9self_pipe11get_read_fdEv>
  1d8037:	0f 18 3d c2 53 e5 ff                            	prefetchit0 -0x1aac3e(%rip)        # 2d400 <pthread_mutex_lock@plt>
  1d803e:	0f 18 3d db 58 e5 ff                            	prefetchit0 -0x1aa725(%rip)        # 2d920 <__fdelt_chk@plt>
  1d8045:	0f 18 3d 3c 31 f7 ff                            	prefetchit0 -0x8cec4(%rip)        # 14b188 <_ZN7tacopie10io_service14process_eventsEv+0xf8>
  1d804c:	0f 18 3d dd 31 f7 ff                            	prefetchit0 -0x8ce23(%rip)        # 14b230 <_ZN7tacopie10io_service14process_eventsEv+0x1a0>
  1d8053:	41 53                                           	push   %r11
  1d8055:	4c 8b 1d 34 d4 ff ff                            	mov    -0x2bcc(%rip),%r11        # 1d5490 <__fdelt_chk@GLIBC_2.15>
  1d805c:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d8064:	4c 8b 1d 85 d6 ff ff                            	mov    -0x297b(%rip),%r11        # 1d56f0 <read@GLIBC_2.2.5>
  1d806b:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d8073:	41 5b                                           	pop    %r11
  1d8075:	e9 16 30 f7 ff                                  	jmp    14b090 <_ZN7tacopie10io_service14process_eventsEv>
  1d807a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1d8080:	0f 18 3d 3b 44 f7 ff                            	prefetchit0 -0x8bbc5(%rip)        # 14c4c2 <_ZNSt8__detail9_Map_baseIiSt4pairIKiN7tacopie10io_service14tracked_socketEESaIS6_ENS_10_Select1stESt8equal_toIiESt4hashIiENS_18_Mod_range_hashingENS_20_Default_ranged_hashENS_20_Prime_rehash_policyENS_17_Hashtable_traitsILb0ELb0ELb1EEELb1EEixEOi+0x52>
  1d8087:	e9 74 53 e5 ff                                  	jmp    2d400 <pthread_mutex_lock@plt>
  1d808c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d8090:	0f 18 3d d9 43 f7 ff                            	prefetchit0 -0x8bc27(%rip)        # 14c470 <_ZNSt8__detail9_Map_baseIiSt4pairIKiN7tacopie10io_service14tracked_socketEESaIS6_ENS_10_Select1stESt8equal_toIiESt4hashIiENS_18_Mod_range_hashingENS_20_Default_ranged_hashENS_20_Prime_rehash_policyENS_17_Hashtable_traitsILb0ELb0ELb1EEELb1EEixEOi>
  1d8097:	0f 18 3d 02 7b f7 ff                            	prefetchit0 -0x884fe(%rip)        # 14fba0 <_ZNK7tacopie10tcp_socket6get_fdEv>
  1d809e:	0f 18 3d db 43 f7 ff                            	prefetchit0 -0x8bc25(%rip)        # 14c480 <_ZNSt8__detail9_Map_baseIiSt4pairIKiN7tacopie10io_service14tracked_socketEESaIS6_ENS_10_Select1stESt8equal_toIiESt4hashIiENS_18_Mod_range_hashingENS_20_Default_ranged_hashENS_20_Prime_rehash_policyENS_17_Hashtable_traitsILb0ELb0ELb1EEELb1EEixEOi+0x10>
  1d80a5:	0f 18 3d c4 8e f7 ff                            	prefetchit0 -0x8713c(%rip)        # 150f70 <_ZN7tacopie9self_pipe6notifyEv>
  1d80ac:	0f 18 3d 65 3c f7 ff                            	prefetchit0 -0x8c39b(%rip)        # 14bd18 <_ZN7tacopie10io_service15set_wr_callbackERKNS_10tcp_socketERKSt8functionIFviEE+0x118>
  1d80b3:	0f 18 3d c9 8e f7 ff                            	prefetchit0 -0x87137(%rip)        # 150f83 <_ZN7tacopie9self_pipe6notifyEv+0x13>
  1d80ba:	41 53                                           	push   %r11
  1d80bc:	4c 8b 1d 15 d9 ff ff                            	mov    -0x26eb(%rip),%r11        # 1d59d8 <write@GLIBC_2.2.5>
  1d80c3:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1d80cb:	41 5b                                           	pop    %r11
  1d80cd:	e9 2e 53 e5 ff                                  	jmp    2d400 <pthread_mutex_lock@plt>
  1d80d2:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1d80dc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d80e0:	0f 18 3d 99 e3 f6 ff                            	prefetchit0 -0x91c67(%rip)        # 146480 <_ZNSt17_Function_handlerIFvRN7tacopie10tcp_client12write_resultEEZN9cpp_redis7network10tcp_client11async_writeERNS6_16tcp_client_iface13write_requestEEUlS3_E_E9_M_invokeERKSt9_Any_dataS3_>
  1d80e7:	e9 84 8e f7 ff                                  	jmp    150f70 <_ZN7tacopie9self_pipe6notifyEv>
  1d80ec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d80f0:	0f 18 3d 49 d8 f6 ff                            	prefetchit0 -0x927b7(%rip)        # 145940 <_ZN9cpp_redis7network16redis_connection26tcp_client_receive_handlerERKNS0_16tcp_client_iface11read_resultE>
  1d80f7:	0f 18 3d 72 fe f6 ff                            	prefetchit0 -0x9018e(%rip)        # 147f70 <_ZN9cpp_redis8builders13reply_builderlsERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  1d80fe:	0f 18 3d 2b de f6 ff                            	prefetchit0 -0x921d5(%rip)        # 145f30 <_ZN9cpp_redis7network16redis_connection26tcp_client_receive_handlerERKNS0_16tcp_client_iface11read_resultE+0x5f0>
  1d8105:	0f 18 3d 35 de f6 ff                            	prefetchit0 -0x921cb(%rip)        # 145f41 <_ZN9cpp_redis7network16redis_connection26tcp_client_receive_handlerERKNS0_16tcp_client_iface11read_resultE+0x601>
  1d810c:	0f 18 3d fd e0 f6 ff                            	prefetchit0 -0x91f03(%rip)        # 146210 <_ZNSt17_Function_handlerIFvRN9cpp_redis7network16tcp_client_iface11read_resultEESt5_BindIFMNS1_16redis_connectionEFvRKS3_EPS7_St12_PlaceholderILi1EEEEE9_M_invokeERKSt9_Any_dataS4_>
  1d8113:	e9 78 52 e5 ff                                  	jmp    2d390 <pthread_mutex_unlock@plt>
  1d8118:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1d8120:	0f 18 3d 99 e4 f6 ff                            	prefetchit0 -0x91b67(%rip)        # 1465c0 <_ZNSt17_Function_handlerIFvRN7tacopie10tcp_client12write_resultEEZN9cpp_redis7network10tcp_client11async_writeERNS6_16tcp_client_iface13write_requestEEUlS3_E_E10_M_managerERSt9_Any_dataRKSD_St18_Manager_operation>
  1d8127:	e9 d4 52 e5 ff                                  	jmp    2d400 <pthread_mutex_lock@plt>
  1d812c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d8130:	0f 18 3d 99 e1 f6 ff                            	prefetchit0 -0x91e67(%rip)        # 1462d0 <_ZNSt17_Function_handlerIFvRN9cpp_redis7network16tcp_client_iface11read_resultEESt5_BindIFMNS1_16redis_connectionEFvRKS3_EPS7_St12_PlaceholderILi1EEEEE10_M_managerERSt9_Any_dataRKSI_St18_Manager_operation>
  1d8137:	0f 18 3d e2 7a f7 ff                            	prefetchit0 -0x8851e(%rip)        # 14fc20 <_ZN7tacopie10tcp_socket4recvEm>
  1d813e:	0f 18 3d 5b e5 f6 ff                            	prefetchit0 -0x91aa5(%rip)        # 1466a0 <_ZNSt17_Function_handlerIFvRN7tacopie10tcp_client11read_resultEEZN9cpp_redis7network10tcp_client10async_readERNS6_16tcp_client_iface12read_requestEEUlS3_E_E10_M_managerERSt9_Any_dataRKSD_St18_Manager_operation>
  1d8145:	e9 56 45 f7 ff                                  	jmp    14c6a0 <_ZN7tacopie10tcp_client12process_readERNS0_11read_resultE>
  1d814a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1d8150:	0f 18 3d 69 6e f7 ff                            	prefetchit0 -0x89197(%rip)        # 14efc0 <_ZNSt5dequeIN7tacopie10tcp_client13write_requestESaIS2_EE16_M_push_back_auxIJRKS2_EEEvDpOT_+0x40>
  1d8157:	e9 24 58 e5 ff                                  	jmp    2d980 <_ZdlPv@plt>
  1d815c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d8160:	0f 18 3d f9 60 e5 ff                            	prefetchit0 -0x1a9f07(%rip)        # 2e260 <recv@plt>
  1d8167:	e9 54 53 e5 ff                                  	jmp    2d4c0 <memset@plt>
  1d816c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1d8170:	0f 18 3d 69 23 f7 ff                            	prefetchit0 -0x8dc97(%rip)        # 14a4e0 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_rd_eventERKiRNS2_14tracked_socketEEUlvE_E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation>
  1d8177:	0f 18 3d 12 62 f7 ff                            	prefetchit0 -0x89dee(%rip)        # 14e390 <_ZNSt17_Function_handlerIFviESt5_BindIFMN7tacopie10tcp_clientEFviEPS3_St12_PlaceholderILi1EEEEE10_M_managerERSt9_Any_dataRKSC_St18_Manager_operation>
  1d817e:	0f 18 3d 4b 24 f7 ff                            	prefetchit0 -0x8dbb5(%rip)        # 14a5d0 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_wr_eventERKiRNS2_14tracked_socketEEUlvE_E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation>
  1d8185:	e9 46 81 f7 ff                                  	jmp    1502d0 <_ZNK7tacopie5utils11thread_pool11should_stopEv>
  1d818a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1d8190:	41 53                                           	push   %r11
  1d8192:	4c 8b 1d 2f d0 ff ff                            	mov    -0x2fd1(%rip),%r11        # 1d51c8 <pthread_mutex_unlock@GLIBC_2.2.5>
  1d8199:	41 0f 18 93 e0 fe ff ff                         	prefetcht1 -0x120(%r11)
  1d81a1:	4c 8b 1d 18 d3 ff ff                            	mov    -0x2ce8(%rip),%r11        # 1d54c0 <_ZdlPv@GLIBCXX_3.4>
  1d81a8:	41 0f 18 93 60 47 ff ff                         	prefetcht1 -0xb8a0(%r11)
  1d81b0:	41 5b                                           	pop    %r11
  1d81b2:	e9 a9 59 e5 ff                                  	jmp    2db60 <_ZNSt18condition_variable4waitERSt11unique_lockISt5mutexE@plt>
  1d81b7:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  1d81c0:	0f 18 3d 19 23 f7 ff                            	prefetchit0 -0x8dce7(%rip)        # 14a4e0 <_ZNSt17_Function_handlerIFvvEZN7tacopie10io_service16process_rd_eventERKiRNS2_14tracked_socketEEUlvE_E10_M_managerERSt9_Any_dataRKS9_St18_Manager_operation>
  1d81c7:	e9 14 87 f7 ff                                  	jmp    1508e0 <_ZN7tacopie5utils11thread_pool8add_taskERKSt8functionIFvvEE>
