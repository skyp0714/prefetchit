
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_native_it0/74758375d70ece71e60caec108eeeae79d9abef7dce5ef79835d4c0c4edfca8e/libthrift.so.0.12.0:     file format elf64-x86-64


Disassembly of section .text.prefetch_calls:

00000000000c22c0 <.text.prefetch_calls>:
   c22c0:	0f 18 3d b9 00 fa ff                            	prefetchit0 -0x5ff47(%rip)        # 62380 <_ZNSt15_Sp_counted_ptrIPN6apache6thrift9transport13TMemoryBufferELN9__gnu_cxx12_Lock_policyE2EE10_M_destroyEv>
   c22c7:	e9 d4 67 f8 ff                                  	jmp    48aa0 <free@plt>
   c22cc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   c22d0:	0f 18 3d 49 6d f8 ff                            	prefetchit0 -0x792b7(%rip)        # 49020 <poll@plt>
   c22d7:	0f 18 3d 22 57 f8 ff                            	prefetchit0 -0x7a8de(%rip)        # 47a00 <recv@plt>
   c22de:	0f 18 3d cf 69 fb ff                            	prefetchit0 -0x49631(%rip)        # 78cb4 <_ZN6apache6thrift9transport7TSocket4readEPhj+0x144>
   c22e5:	e9 76 52 f8 ff                                  	jmp    47560 <__errno_location@plt>
   c22ea:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   c22f0:	0f 18 3d 09 60 f8 ff                            	prefetchit0 -0x79ff7(%rip)        # 48300 <memcpy@plt>
   c22f7:	0f 18 3d 02 e2 fb ff                            	prefetchit0 -0x41dfe(%rip)        # 80500 <_ZN6apache6thrift9transport16TFramedTransport8readSlowEPhj+0x40>
   c22fe:	e9 1d 6d f8 ff                                  	jmp    49020 <poll@plt>
   c2303:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   c230d:	0f 1f 00                                        	nopl   (%rax)
   c2310:	0f 18 3d ae 6c fb ff                            	prefetchit0 -0x49352(%rip)        # 78fc5 <_ZN6apache6thrift9transport7TSocket4readEPhj+0x455>
   c2317:	0f 18 3d 82 86 fb ff                            	prefetchit0 -0x4797e(%rip)        # 7a9a0 <_ZN6apache6thrift9transport17TVirtualTransportINS1_7TSocketENS1_18TTransportDefaultsEE12readAll_virtEPhj>
   c231e:	0f 18 3d 4b 85 fb ff                            	prefetchit0 -0x47ab5(%rip)        # 7a870 <_ZN6apache6thrift9transport7readAllINS1_7TSocketEEEjRT_Phj>
   c2325:	0f 18 3d 44 68 fb ff                            	prefetchit0 -0x497bc(%rip)        # 78b70 <_ZN6apache6thrift9transport7TSocket4readEPhj>
   c232c:	0f 18 3d 54 85 fb ff                            	prefetchit0 -0x47aac(%rip)        # 7a887 <_ZN6apache6thrift9transport7readAllINS1_7TSocketEEEjRT_Phj+0x17>
   c2333:	0f 18 3d b7 e1 fb ff                            	prefetchit0 -0x41e49(%rip)        # 804f1 <_ZN6apache6thrift9transport16TFramedTransport8readSlowEPhj+0x31>
   c233a:	0f 18 3d 44 68 fb ff                            	prefetchit0 -0x497bc(%rip)        # 78b85 <_ZN6apache6thrift9transport7TSocket4readEPhj+0x15>
   c2341:	0f 18 3d 23 e6 fb ff                            	prefetchit0 -0x419dd(%rip)        # 8096b <_ZN6apache6thrift9transport16TFramedTransport9readFrameEv+0x4b>
   c2348:	e9 b3 56 f8 ff                                  	jmp    47a00 <recv@plt>
   c234d:	0f 1f 00                                        	nopl   (%rax)
   c2350:	0f 18 3d 69 12 fb ff                            	prefetchit0 -0x4ed97(%rip)        # 735c0 <_ZN6apache6thrift9transport10TTransport5flushEv>
   c2357:	0f 18 3d e2 54 f8 ff                            	prefetchit0 -0x7ab1e(%rip)        # 47840 <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj@plt>
   c235e:	0f 18 3d 5b f5 fb ff                            	prefetchit0 -0x40aa5(%rip)        # 818c0 <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj>
   c2365:	0f 18 3d a4 f6 fb ff                            	prefetchit0 -0x4095c(%rip)        # 81a10 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE12readAll_virtEPhj>
   c236c:	e9 af 59 f8 ff                                  	jmp    47d20 <send@plt>
   c2371:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   c237b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
   c2380:	0f 18 3d 7a ec fb ff                            	prefetchit0 -0x41386(%rip)        # 81001 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE11borrow_virtEPhPj+0x11>
   c2387:	0f 18 3d 32 f3 fb ff                            	prefetchit0 -0x40cce(%rip)        # 816c0 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE12consume_virtEj>
   c238e:	0f 18 3d 80 f5 fb ff                            	prefetchit0 -0x40a80(%rip)        # 81915 <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj+0x55>
   c2395:	0f 18 3d ac f5 fb ff                            	prefetchit0 -0x40a54(%rip)        # 81948 <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj+0x88>
   c239c:	0f 18 3d 4d ec fb ff                            	prefetchit0 -0x413b3(%rip)        # 80ff0 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE11borrow_virtEPhPj>
   c23a3:	0f 18 3d 56 f3 fb ff                            	prefetchit0 -0x40caa(%rip)        # 81700 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE12consume_virtEj+0x40>
   c23aa:	41 53                                           	push   %r11
   c23ac:	4c 8b 1d 05 e5 ff ff                            	mov    -0x1afb(%rip),%r11        # c08b8 <_ZdlPv@GLIBCXX_3.4>
   c23b3:	41 0f 18 93 a0 04 0a 00                         	prefetcht1 0xa04a0(%r11)
   c23bb:	41 0f 18 93 40 06 0a 00                         	prefetcht1 0xa0640(%r11)
   c23c3:	41 5b                                           	pop    %r11
   c23c5:	e9 36 5f f8 ff                                  	jmp    48300 <memcpy@plt>
   c23ca:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   c23d0:	0f 18 3d 19 6e fb ff                            	prefetchit0 -0x491e7(%rip)        # 791f0 <_ZN6apache6thrift9transport7TSocket13write_partialEPKhj>
   c23d7:	0f 18 3d a2 e0 fb ff                            	prefetchit0 -0x41f5e(%rip)        # 80480 <_ZN6apache6thrift9transport16TFramedTransport8writeEndEv>
   c23de:	0f 18 3d 5b 4d fb ff                            	prefetchit0 -0x4b2a5(%rip)        # 77140 <_ZN6apache6thrift9transport7TSocket5writeEPKhj>
   c23e5:	0f 18 3d 94 4d fb ff                            	prefetchit0 -0x4b26c(%rip)        # 77180 <_ZN6apache6thrift9transport7TSocket5writeEPKhj+0x40>
   c23ec:	0f 18 3d 5d 84 fb ff                            	prefetchit0 -0x47ba3(%rip)        # 7a850 <_ZN6apache6thrift9transport17TVirtualTransportINS1_7TSocketENS1_18TTransportDefaultsEE10write_virtEPKhj>
   c23f3:	0f 18 3d 26 59 f8 ff                            	prefetchit0 -0x7a6da(%rip)        # 47d20 <send@plt>
   c23fa:	0f 18 3d 01 6e fb ff                            	prefetchit0 -0x491ff(%rip)        # 79202 <_ZN6apache6thrift9transport7TSocket13write_partialEPKhj+0x12>
   c2401:	e9 fa 5e f8 ff                                  	jmp    48300 <memcpy@plt>
   c2406:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   c2410:	41 53                                           	push   %r11
   c2412:	4c 8b 1d 9f e4 ff ff                            	mov    -0x1b61(%rip),%r11        # c08b8 <_ZdlPv@GLIBCXX_3.4>
   c2419:	41 0f 18 93 c0 53 ff ff                         	prefetcht1 -0xac40(%r11)
   c2421:	41 0f 18 93 71 1d 00 00                         	prefetcht1 0x1d71(%r11)
   c2429:	41 5b                                           	pop    %r11
   c242b:	e9 d0 5e f8 ff                                  	jmp    48300 <memcpy@plt>
