
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_native_it0/ea804b0c846d1d50c1abb962468a454dc68d1949a3a907de3e77fd4090cd8089/libjaegertracing.so.0.4.2:     file format elf64-x86-64


Disassembly of section .text.prefetch_calls:

00000000001a92c0 <.text.prefetch_calls>:
  1a92c0:	0f 18 3d d3 e1 ed ff                            	prefetchit0 -0x121e2d(%rip)        # 8749a <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE+0x74a>
  1a92c7:	0f 18 3d 33 db ed ff                            	prefetchit0 -0x1224cd(%rip)        # 86e01 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE+0xb1>
  1a92ce:	0f 18 3d 2c dd ed ff                            	prefetchit0 -0x1222d4(%rip)        # 87001 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE+0x2b1>
  1a92d5:	e9 86 9c ec ff                                  	jmp    72f60 <pthread_mutex_lock@plt>
  1a92da:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1a92e0:	0f 18 3d 09 9b f3 ff                            	prefetchit0 -0xc64f7(%rip)        # e2df0 <_ZN13jaegertracing9reporters14RemoteReporter6reportERKNS_4SpanE>
  1a92e7:	0f 18 3d 13 dd ed ff                            	prefetchit0 -0x1222ed(%rip)        # 87001 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE+0x2b1>
  1a92ee:	0f 18 3d 0c 9b f3 ff                            	prefetchit0 -0xc64f4(%rip)        # e2e01 <_ZN13jaegertracing9reporters14RemoteReporter6reportERKNS_4SpanE+0x11>
  1a92f5:	e9 56 85 ec ff                                  	jmp    71850 <pthread_mutex_unlock@plt>
  1a92fa:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1a9300:	0f 18 3d 99 8c ec ff                            	prefetchit0 -0x137367(%rip)        # 71fa0 <_Znwm@plt>
  1a9307:	41 53                                           	push   %r11
  1a9309:	4c 8b 1d f8 bb ff ff                            	mov    -0x4408(%rip),%r11        # 1a4f08 <_ZdlPv@GLIBCXX_3.4>
  1a9310:	41 0f 18 93 c0 24 ff ff                         	prefetcht1 -0xdb40(%r11)
  1a9318:	4c 8b 1d 71 bc ff ff                            	mov    -0x438f(%rip),%r11        # 1a4f90 <_Znwm@GLIBCXX_3.4>
  1a931f:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1a9327:	41 5b                                           	pop    %r11
  1a9329:	e9 32 9c ec ff                                  	jmp    72f60 <pthread_mutex_lock@plt>
  1a932e:	66 90                                           	xchg   %ax,%ax
  1a9330:	0f 18 3d 49 4c ee ff                            	prefetchit0 -0x11b3b7(%rip)        # 8df80 <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE>
  1a9337:	e9 14 85 ec ff                                  	jmp    71850 <pthread_mutex_unlock@plt>
  1a933c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a9340:	0f 18 3d 79 2a ee ff                            	prefetchit0 -0x11d587(%rip)        # 8bdc0 <_ZN13jaegertracing4SpanD0Ev+0x850>
  1a9347:	0f 18 3d e2 e0 ed ff                            	prefetchit0 -0x121f1e(%rip)        # 87430 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE+0x6e0>
  1a934e:	0f 18 3d ec e0 ed ff                            	prefetchit0 -0x121f14(%rip)        # 87441 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE+0x6f1>
  1a9355:	41 53                                           	push   %r11
  1a9357:	4c 8b 1d aa bb ff ff                            	mov    -0x4456(%rip),%r11        # 1a4f08 <_ZdlPv@GLIBCXX_3.4>
  1a935e:	41 0f 18 93 20 2f ff ff                         	prefetcht1 -0xd0e0(%r11)
  1a9366:	41 5b                                           	pop    %r11
  1a9368:	e9 93 81 ec ff                                  	jmp    71500 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE@plt>
  1a936d:	0f 1f 00                                        	nopl   (%rax)
  1a9370:	0f 18 3d 99 94 ec ff                            	prefetchit0 -0x136b67(%rip)        # 72810 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED1Ev@plt>
  1a9377:	0f 18 3d 82 ea ed ff                            	prefetchit0 -0x12157e(%rip)        # 87e00 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EED1Ev>
  1a937e:	0f 18 3d a0 ec ed ff                            	prefetchit0 -0x121360(%rip)        # 88025 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED1Ev+0x65>
  1a9385:	0f 18 3d cc ea ed ff                            	prefetchit0 -0x121534(%rip)        # 87e58 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EED1Ev+0x58>
  1a938c:	0f 18 3d 9d 6d ec ff                            	prefetchit0 -0x139263(%rip)        # 70130 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EED1Ev@plt>
  1a9393:	e9 f8 8a ec ff                                  	jmp    71e90 <_ZdlPv@plt>
  1a9398:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1a93a0:	0f 18 3d 59 43 ee ff                            	prefetchit0 -0x11bca7(%rip)        # 8d700 <_ZN13jaegertracing7TraceID10fromStreamERSi>
  1a93a7:	0f 18 3d 92 43 ee ff                            	prefetchit0 -0x11bc6e(%rip)        # 8d740 <_ZN13jaegertracing7TraceID10fromStreamERSi+0x40>
  1a93ae:	0f 18 3d 2b 98 ec ff                            	prefetchit0 -0x1367d5(%rip)        # 72be0 <_ZNSi3getERc@plt>
  1a93b5:	41 53                                           	push   %r11
  1a93b7:	4c 8b 1d 4a bb ff ff                            	mov    -0x44b6(%rip),%r11        # 1a4f08 <_ZdlPv@GLIBCXX_3.4>
  1a93be:	41 0f 18 93 80 4d ff ff                         	prefetcht1 -0xb280(%r11)
  1a93c6:	4c 8b 1d e3 c1 ff ff                            	mov    -0x3e1d(%rip),%r11        # 1a55b0 <_ZNSi3getERc@GLIBCXX_3.4>
  1a93cd:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1a93d5:	41 0f 18 93 80 00 00 00                         	prefetcht1 0x80(%r11)
  1a93dd:	41 5b                                           	pop    %r11
  1a93df:	e9 8c 82 ec ff                                  	jmp    71670 <_ZN13jaegertracing7TraceID10fromStreamERSi@plt>
  1a93e4:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1a93ee:	66 90                                           	xchg   %ax,%ax
  1a93f0:	41 53                                           	push   %r11
  1a93f2:	4c 8b 1d 4f b7 ff ff                            	mov    -0x48b1(%rip),%r11        # 1a4b48 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_@GLIBCXX_3.4.21>
  1a93f9:	41 0f 18 93 63 02 00 00                         	prefetcht1 0x263(%r11)
  1a9401:	41 5b                                           	pop    %r11
  1a9403:	e9 c8 7c ec ff                                  	jmp    710d0 <memset@plt>
  1a9408:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1a9410:	0f 18 3d ab 35 ee ff                            	prefetchit0 -0x11ca55(%rip)        # 8c9c2 <_ZN13jaegertracing11SpanContext10fromStreamERSi+0x982>
  1a9417:	0f 18 3d 7c 35 ee ff                            	prefetchit0 -0x11ca84(%rip)        # 8c99a <_ZN13jaegertracing11SpanContext10fromStreamERSi+0x95a>
  1a941e:	e9 bd 97 ec ff                                  	jmp    72be0 <_ZNSi3getERc@plt>
  1a9423:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1a942d:	0f 1f 00                                        	nopl   (%rax)
  1a9430:	0f 18 3d b9 40 ee ff                            	prefetchit0 -0x11bf47(%rip)        # 8d4f0 <_ZN13jaegertracing5utils10HexParsing11readSegmentB5cxx11ERSimc>
  1a9437:	0f 18 3d c2 40 ee ff                            	prefetchit0 -0x11bf3e(%rip)        # 8d500 <_ZN13jaegertracing5utils10HexParsing11readSegmentB5cxx11ERSimc+0x10>
  1a943e:	0f 18 3d 7b 7a ec ff                            	prefetchit0 -0x138585(%rip)        # 70ec0 <_ZN13jaegertracing5utils10HexParsing11readSegmentB5cxx11ERSimc@plt>
  1a9445:	0f 18 3d f9 40 ee ff                            	prefetchit0 -0x11bf07(%rip)        # 8d545 <_ZN13jaegertracing5utils10HexParsing11readSegmentB5cxx11ERSimc+0x55>
  1a944c:	0f 18 3d 2e 41 ee ff                            	prefetchit0 -0x11bed2(%rip)        # 8d581 <_ZN13jaegertracing5utils10HexParsing11readSegmentB5cxx11ERSimc+0x91>
  1a9453:	e9 88 97 ec ff                                  	jmp    72be0 <_ZNSi3getERc@plt>
  1a9458:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1a9460:	41 53                                           	push   %r11
  1a9462:	4c 8b 1d 5f c8 ff ff                            	mov    -0x37a1(%rip),%r11        # 1a5cc8 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@GLIBCXX_3.4.21>
  1a9469:	41 0f 18 93 40 52 ff ff                         	prefetcht1 -0xadc0(%r11)
  1a9471:	41 0f 18 93 b0 ec ff ff                         	prefetcht1 -0x1350(%r11)
  1a9479:	41 5b                                           	pop    %r11
  1a947b:	e9 40 7a ec ff                                  	jmp    70ec0 <_ZN13jaegertracing5utils10HexParsing11readSegmentB5cxx11ERSimc@plt>
  1a9480:	0f 18 3d 19 a6 ec ff                            	prefetchit0 -0x1359e7(%rip)        # 73aa0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm@plt>
  1a9487:	0f 18 3d 92 a8 ec ff                            	prefetchit0 -0x13576e(%rip)        # 73d20 <_ZNSi7putbackEc@plt>
  1a948e:	e9 4d 97 ec ff                                  	jmp    72be0 <_ZNSi3getERc@plt>
  1a9493:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1a949d:	0f 1f 00                                        	nopl   (%rax)
  1a94a0:	0f 18 3d 69 a5 ec ff                            	prefetchit0 -0x135a97(%rip)        # 73a10 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@plt>
  1a94a7:	0f 18 3d 56 45 ee ff                            	prefetchit0 -0x11baaa(%rip)        # 8da04 <_ZN13jaegertracing7TraceID10fromStreamERSi+0x304>
  1a94ae:	0f 18 3d 66 46 ee ff                            	prefetchit0 -0x11b99a(%rip)        # 8db1b <_ZN13jaegertracing7TraceID10fromStreamERSi+0x41b>
  1a94b5:	0f 18 3d 34 86 ec ff                            	prefetchit0 -0x1379cc(%rip)        # 71af0 <memcpy@plt>
  1a94bc:	0f 18 3d 1d 46 ee ff                            	prefetchit0 -0x11b9e3(%rip)        # 8dae0 <_ZN13jaegertracing7TraceID10fromStreamERSi+0x3e0>
  1a94c3:	41 53                                           	push   %r11
  1a94c5:	4c 8b 1d ac c6 ff ff                            	mov    -0x3954(%rip),%r11        # 1a5b78 <_ZNSt9basic_iosIcSt11char_traitsIcEE5clearESt12_Ios_Iostate@GLIBCXX_3.4>
  1a94cc:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1a94d4:	4c 8b 1d 75 c9 ff ff                            	mov    -0x368b(%rip),%r11        # 1a5e50 <_ZNSi7putbackEc@GLIBCXX_3.4>
  1a94db:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1a94e3:	41 0f 18 93 22 00 00 00                         	prefetcht1 0x22(%r11)
  1a94eb:	41 5b                                           	pop    %r11
  1a94ed:	e9 2e a8 ec ff                                  	jmp    73d20 <_ZNSi7putbackEc@plt>
  1a94f2:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1a94fc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a9500:	41 53                                           	push   %r11
  1a9502:	4c 8b 1d 87 b6 ff ff                            	mov    -0x4979(%rip),%r11        # 1a4b90 <isupper@GLIBC_2.2.5>
  1a9509:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1a9511:	41 5b                                           	pop    %r11
  1a9513:	e9 f8 a4 ec ff                                  	jmp    73a10 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@plt>
  1a9518:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1a9520:	0f 18 3d ef ab ee ff                            	prefetchit0 -0x115411(%rip)        # 94116 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_+0x3e6>
  1a9527:	0f 18 3d c6 ab ee ff                            	prefetchit0 -0x11543a(%rip)        # 940f4 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_+0x3c4>
  1a952e:	0f 18 3d fb a7 ee ff                            	prefetchit0 -0x115805(%rip)        # 93d30 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_>
  1a9535:	0f 18 3d 45 a8 ee ff                            	prefetchit0 -0x1157bb(%rip)        # 93d81 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_+0x51>
  1a953c:	0f 18 3d 06 a8 ee ff                            	prefetchit0 -0x1157fa(%rip)        # 93d49 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_+0x19>
  1a9543:	0f 18 3d 26 4e ee ff                            	prefetchit0 -0x11b1da(%rip)        # 8e370 <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE+0x3f0>
  1a954a:	0f 18 3d 2f a2 ec ff                            	prefetchit0 -0x135dd1(%rip)        # 73780 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_@plt>
  1a9551:	0f 18 3d a8 46 ee ff                            	prefetchit0 -0x11b958(%rip)        # 8dc00 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.constprop.0>
  1a9558:	e9 03 8f ec ff                                  	jmp    72460 <__dynamic_cast@plt>
  1a955d:	0f 1f 00                                        	nopl   (%rax)
  1a9560:	0f 18 3d 81 4e ee ff                            	prefetchit0 -0x11b17f(%rip)        # 8e3e8 <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE+0x468>
  1a9567:	0f 18 3d 96 4e ee ff                            	prefetchit0 -0x11b16a(%rip)        # 8e404 <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE+0x484>
  1a956e:	0f 18 3d ce 46 ee ff                            	prefetchit0 -0x11b932(%rip)        # 8dc43 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.constprop.0+0x43>
  1a9575:	e9 26 48 ee ff                                  	jmp    8dda0 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_.isra.0>
  1a957a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1a9580:	0f 18 3d 3a aa ee ff                            	prefetchit0 -0x1155c6(%rip)        # 93fc1 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_+0x291>
  1a9587:	0f 18 3d 76 38 ee ff                            	prefetchit0 -0x11c78a(%rip)        # 8ce04 <_ZN13jaegertracing11SpanContextC1ERKS0_+0x34>
  1a958e:	e9 6d 46 ee ff                                  	jmp    8dc00 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPcEEvT_S7_St20forward_iterator_tag.constprop.0>
  1a9593:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1a959d:	0f 1f 00                                        	nopl   (%rax)
  1a95a0:	0f 18 3d a9 a5 ee ff                            	prefetchit0 -0x115a57(%rip)        # 93b50 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPKcEEvT_S8_St20forward_iterator_tag>
  1a95a7:	0f 18 3d 0b 6e ee ff                            	prefetchit0 -0x1191f5(%rip)        # 903b9 <_ZNK13jaegertracing6Tracer20StartSpanWithOptionsEN11opentracing2v211string_viewERKNS2_16StartSpanOptionsE+0x11e9>
  1a95ae:	0f 18 3d 92 6a ee ff                            	prefetchit0 -0x11956e(%rip)        # 90047 <_ZNK13jaegertracing6Tracer20StartSpanWithOptionsEN11opentracing2v211string_viewERKNS2_16StartSpanOptionsE+0xe77>
  1a95b5:	0f 18 3d a4 75 ec ff                            	prefetchit0 -0x138a5c(%rip)        # 70b60 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPKcEEvT_S8_St20forward_iterator_tag@plt>
  1a95bc:	0f 18 3d 01 6e ee ff                            	prefetchit0 -0x1191ff(%rip)        # 903c4 <_ZNK13jaegertracing6Tracer20StartSpanWithOptionsEN11opentracing2v211string_viewERKNS2_16StartSpanOptionsE+0x11f4>
  1a95c3:	0f 18 3d b9 a5 ee ff                            	prefetchit0 -0x115a47(%rip)        # 93b83 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPKcEEvT_S8_St20forward_iterator_tag+0x33>
  1a95ca:	0f 18 3d af 6a ee ff                            	prefetchit0 -0x119551(%rip)        # 90080 <_ZNK13jaegertracing6Tracer20StartSpanWithOptionsEN11opentracing2v211string_viewERKNS2_16StartSpanOptionsE+0xeb0>
  1a95d1:	e9 fa 7a ec ff                                  	jmp    710d0 <memset@plt>
  1a95d6:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1a95e0:	0f 18 3d 49 57 ee ff                            	prefetchit0 -0x11a8b7(%rip)        # 8ed30 <_ZNK13jaegertracing6Tracer17startSpanInternalERKNS_11SpanContextERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKNSt6chrono10time_pointINSC_3_V212system_clockENSC_8durationIlSt5ratioILl1ELl1000000000EEEEEERKNSD_INSE_12steady_clockESJ_EERKSt6vectorINS_3TagESaISS_EERKSR_ISt4pairIS9_N11opentracing2v25ValueEESaIS11_EEbRKSR_INS_9ReferenceESaIS16_EE+0x830>
  1a95e7:	e9 c4 7b ec ff                                  	jmp    711b0 <_ZN13jaegertracing11SpanContextC1ERKS0_@plt>
  1a95ec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a95f0:	41 53                                           	push   %r11
  1a95f2:	4c 8b 1d 3f b8 ff ff                            	mov    -0x47c1(%rip),%r11        # 1a4e38 <_ZN6apache6thrift8protocol9TProtocolD2Ev@Base>
  1a95f9:	41 0f 18 93 60 44 fe ff                         	prefetcht1 -0x1bba0(%r11)
  1a9601:	41 0f 18 93 74 44 fe ff                         	prefetcht1 -0x1bb8c(%r11)
  1a9609:	41 5b                                           	pop    %r11
  1a960b:	e9 90 89 ec ff                                  	jmp    71fa0 <_Znwm@plt>
  1a9610:	41 53                                           	push   %r11
  1a9612:	4c 8b 1d 1f b8 ff ff                            	mov    -0x47e1(%rip),%r11        # 1a4e38 <_ZN6apache6thrift8protocol9TProtocolD2Ev@Base>
  1a9619:	41 0f 18 93 74 44 fe ff                         	prefetcht1 -0x1bb8c(%r11)
  1a9621:	41 5b                                           	pop    %r11
  1a9623:	e9 78 47 ee ff                                  	jmp    8dda0 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_.isra.0>
  1a9628:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1a9630:	0f 18 3d 29 8e ec ff                            	prefetchit0 -0x1371d7(%rip)        # 72460 <__dynamic_cast@plt>
  1a9637:	0f 18 3d c7 49 ee ff                            	prefetchit0 -0x11b639(%rip)        # 8e005 <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE+0x85>
  1a963e:	0f 18 3d 7d 49 ee ff                            	prefetchit0 -0x11b683(%rip)        # 8dfc2 <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE+0x42>
  1a9645:	0f 18 3d 9c 48 ee ff                            	prefetchit0 -0x11b764(%rip)        # 8dee8 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_.isra.0+0x148>
  1a964c:	e9 ff 86 ec ff                                  	jmp    71d50 <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE@plt>
  1a9651:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1a965b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1a9660:	0f 18 3d c1 57 ee ff                            	prefetchit0 -0x11a83f(%rip)        # 8ee28 <_ZNK13jaegertracing6Tracer17startSpanInternalERKNS_11SpanContextERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKNSt6chrono10time_pointINSC_3_V212system_clockENSC_8durationIlSt5ratioILl1ELl1000000000EEEEEERKNSD_INSE_12steady_clockESJ_EERKSt6vectorINS_3TagESaISS_EERKSR_ISt4pairIS9_N11opentracing2v25ValueEESaIS11_EEbRKSR_INS_9ReferenceESaIS16_EE+0x928>
  1a9667:	e9 f4 a5 ec ff                                  	jmp    73c60 <_ZNK13jaegertracing6Tracer17startSpanInternalERKNS_11SpanContextERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKNSt6chrono10time_pointINSC_3_V212system_clockENSC_8durationIlSt5ratioILl1ELl1000000000EEEEEERKNSD_INSE_12steady_clockESJ_EERKSt6vectorINS_3TagESaISS_EERKSR_ISt4pairIS9_N11opentracing2v25ValueEESaIS11_EEbRKSR_INS_9ReferenceESaIS16_EE@plt>
  1a966c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a9670:	0f 18 3d 59 df ed ff                            	prefetchit0 -0x1220a7(%rip)        # 875d0 <_ZNK13jaegertracing4Span7contextEv>
  1a9677:	e9 14 88 ec ff                                  	jmp    71e90 <_ZdlPv@plt>
  1a967c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a9680:	0f 18 3d 39 82 ee ff                            	prefetchit0 -0x117dc7(%rip)        # 918c0 <_ZN13jaegertracing11SpanContextC1ERKNS_7TraceIDEmmhRKSt13unordered_mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESA_St4hashISA_ESt8equal_toISA_ESaISt4pairIKSA_SA_EEERSG_>
  1a9687:	0f 18 3d 72 82 ee ff                            	prefetchit0 -0x117d8e(%rip)        # 91900 <_ZN13jaegertracing11SpanContextC1ERKNS_7TraceIDEmmhRKSt13unordered_mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESA_St4hashISA_ESt8equal_toISA_ESaISt4pairIKSA_SA_EEERSG_+0x40>
  1a968e:	0f 18 3d ac 82 ee ff                            	prefetchit0 -0x117d54(%rip)        # 91941 <_ZN13jaegertracing11SpanContextC1ERKNS_7TraceIDEmmhRKSt13unordered_mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESA_St4hashISA_ESt8equal_toISA_ESaISt4pairIKSA_SA_EEERSG_+0x81>
  1a9695:	0f 18 3d 04 a5 ec ff                            	prefetchit0 -0x135afc(%rip)        # 73ba0 <_ZN13jaegertracing11SpanContextC1ERKNS_7TraceIDEmmhRKSt13unordered_mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESA_St4hashISA_ESt8equal_toISA_ESaISt4pairIKSA_SA_EEERSG_@plt>
  1a969c:	e9 af 81 ec ff                                  	jmp    71850 <pthread_mutex_unlock@plt>
  1a96a1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1a96ab:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1a96b0:	0f 18 3d a9 7b ec ff                            	prefetchit0 -0x138457(%rip)        # 71260 <_ZN13jaegertracing11SpanContextD1Ev@plt>
  1a96b7:	e9 a4 74 ec ff                                  	jmp    70b60 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructIPKcEEvT_S8_St20forward_iterator_tag@plt>
  1a96bc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a96c0:	0f 18 3d 09 e4 ed ff                            	prefetchit0 -0x121bf7(%rip)        # 87ad0 <_ZN13jaegertracing11SpanContextD1Ev>
  1a96c7:	0f 18 3d 33 e4 ed ff                            	prefetchit0 -0x121bcd(%rip)        # 87b01 <_ZN13jaegertracing11SpanContextD1Ev+0x31>
  1a96ce:	e9 cd a4 ec ff                                  	jmp    73ba0 <_ZN13jaegertracing11SpanContextC1ERKNS_7TraceIDEmmhRKSt13unordered_mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESA_St4hashISA_ESt8equal_toISA_ESaISt4pairIKSA_SA_EEERSG_@plt>
  1a96d3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1a96dd:	0f 1f 00                                        	nopl   (%rax)
  1a96e0:	0f 18 3d 5e 63 ee ff                            	prefetchit0 -0x119ca2(%rip)        # 8fa45 <_ZNK13jaegertracing6Tracer20StartSpanWithOptionsEN11opentracing2v211string_viewERKNS2_16StartSpanOptionsE+0x875>
  1a96e7:	0f 18 3d e2 e3 ed ff                            	prefetchit0 -0x121c1e(%rip)        # 87ad0 <_ZN13jaegertracing11SpanContextD1Ev>
  1a96ee:	0f 18 3d 0c 63 ee ff                            	prefetchit0 -0x119cf4(%rip)        # 8fa01 <_ZNK13jaegertracing6Tracer20StartSpanWithOptionsEN11opentracing2v211string_viewERKNS2_16StartSpanOptionsE+0x831>
  1a96f5:	0f 18 3d 14 91 ec ff                            	prefetchit0 -0x136eec(%rip)        # 72810 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED1Ev@plt>
  1a96fc:	0f 18 3d 22 e9 ed ff                            	prefetchit0 -0x1216de(%rip)        # 88025 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED1Ev+0x65>
  1a9703:	e9 08 80 ec ff                                  	jmp    71710 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_@plt>
  1a9708:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1a9710:	41 53                                           	push   %r11
  1a9712:	4c 8b 1d 77 a9 ff ff                            	mov    -0x5689(%rip),%r11        # 1a4090 <_ZNSt6chrono3_V212system_clock3nowEv@GLIBCXX_3.4.19>
  1a9719:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1a9721:	41 0f 18 93 13 00 00 00                         	prefetcht1 0x13(%r11)
  1a9729:	41 5b                                           	pop    %r11
  1a972b:	e9 d0 92 ec ff                                  	jmp    72a00 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
  1a9730:	0f 18 3d 04 59 ee ff                            	prefetchit0 -0x11a6fc(%rip)        # 8f03b <_ZNK13jaegertracing6Tracer17startSpanInternalERKNS_11SpanContextERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKNSt6chrono10time_pointINSC_3_V212system_clockENSC_8durationIlSt5ratioILl1ELl1000000000EEEEEERKNSD_INSE_12steady_clockESJ_EERKSt6vectorINS_3TagESaISS_EERKSR_ISt4pairIS9_N11opentracing2v25ValueEESaIS11_EEbRKSR_INS_9ReferenceESaIS16_EE+0xb3b>
  1a9737:	0f 18 3d 02 59 ee ff                            	prefetchit0 -0x11a6fe(%rip)        # 8f040 <_ZNK13jaegertracing6Tracer17startSpanInternalERKNS_11SpanContextERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKNSt6chrono10time_pointINSC_3_V212system_clockENSC_8durationIlSt5ratioILl1ELl1000000000EEEEEERKNSD_INSE_12steady_clockESJ_EERKSt6vectorINS_3TagESaISS_EERKSR_ISt4pairIS9_N11opentracing2v25ValueEESaIS11_EEbRKSR_INS_9ReferenceESaIS16_EE+0xb40>
  1a973e:	0f 18 3d ab 83 ec ff                            	prefetchit0 -0x137c55(%rip)        # 71af0 <memcpy@plt>
  1a9745:	e9 56 6a ec ff                                  	jmp    701a0 <_ZNSt6chrono3_V212system_clock3nowEv@plt>
  1a974a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1a9750:	0f 18 3d 50 0a f4 ff                            	prefetchit0 -0xbf5b0(%rip)        # ea1a7 <_ZN13jaegertracing4SpanC1ERKS0_+0x1e97>
  1a9757:	0f 18 3d 62 39 ee ff                            	prefetchit0 -0x11c69e(%rip)        # 8d0c0 <_ZN13jaegertracing11SpanContextC1ERKS0_+0x2f0>
  1a975e:	0f 18 3d dd 36 ee ff                            	prefetchit0 -0x11c923(%rip)        # 8ce42 <_ZN13jaegertracing11SpanContextC1ERKS0_+0x72>
  1a9765:	0f 18 3d 1a ef f3 ff                            	prefetchit0 -0xc10e6(%rip)        # e8686 <_ZN13jaegertracing4SpanC1ERKS0_+0x376>
  1a976c:	41 53                                           	push   %r11
  1a976e:	4c 8b 1d d3 b3 ff ff                            	mov    -0x4c2d(%rip),%r11        # 1a4b48 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_@GLIBCXX_3.4.21>
  1a9775:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1a977d:	41 0f 18 93 63 02 00 00                         	prefetcht1 0x263(%r11)
  1a9785:	41 5b                                           	pop    %r11
  1a9787:	e9 d4 97 ec ff                                  	jmp    72f60 <pthread_mutex_lock@plt>
  1a978c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a9790:	0f 18 3d 79 90 ec ff                            	prefetchit0 -0x136f87(%rip)        # 72810 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED1Ev@plt>
  1a9797:	0f 18 3d 22 8d ee ff                            	prefetchit0 -0x1172de(%rip)        # 924c0 <_ZSt4lockISt5mutexS0_JEEvRT_RT0_DpRT1_>
  1a979e:	0f 18 3d 1b e8 ed ff                            	prefetchit0 -0x1217e5(%rip)        # 87fc0 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED1Ev>
  1a97a5:	0f 18 3d 79 e8 ed ff                            	prefetchit0 -0x121787(%rip)        # 88025 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED1Ev+0x65>
  1a97ac:	0f 18 3d ad 97 ec ff                            	prefetchit0 -0x136853(%rip)        # 72f60 <pthread_mutex_lock@plt>
  1a97b3:	0f 18 3d c6 6b ec ff                            	prefetchit0 -0x13943a(%rip)        # 70380 <pthread_mutex_trylock@plt>
  1a97ba:	e9 e1 8a ec ff                                  	jmp    722a0 <_ZSt4lockISt5mutexS0_JEEvRT_RT0_DpRT1_@plt>
  1a97bf:	90                                              	nop
  1a97c0:	41 53                                           	push   %r11
  1a97c2:	4c 8b 1d ff c4 ff ff                            	mov    -0x3b01(%rip),%r11        # 1a5cc8 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@GLIBCXX_3.4.21>
  1a97c9:	41 0f 18 93 40 8d ff ff                         	prefetcht1 -0x72c0(%r11)
  1a97d1:	41 5b                                           	pop    %r11
  1a97d3:	e9 88 8c ec ff                                  	jmp    72460 <__dynamic_cast@plt>
  1a97d8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1a97e0:	0f 18 3d 54 58 ee ff                            	prefetchit0 -0x11a7ac(%rip)        # 8f03b <_ZNK13jaegertracing6Tracer17startSpanInternalERKNS_11SpanContextERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKNSt6chrono10time_pointINSC_3_V212system_clockENSC_8durationIlSt5ratioILl1ELl1000000000EEEEEERKNSD_INSE_12steady_clockESJ_EERKSt6vectorINS_3TagESaISS_EERKSR_ISt4pairIS9_N11opentracing2v25ValueEESaIS11_EEbRKSR_INS_9ReferenceESaIS16_EE+0xb3b>
  1a97e7:	e9 24 a2 ec ff                                  	jmp    73a10 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@plt>
  1a97ec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a97f0:	0f 18 3d c1 0d f0 ff                            	prefetchit0 -0xff23f(%rip)        # aa5b8 <_ZN6apache6thrift8protocol24TCompactProtocolFactoryTINS0_9transport10TTransportEE11getProtocolESt10shared_ptrIS4_E+0x4f8>
  1a97f7:	0f 18 3d c2 08 f0 ff                            	prefetchit0 -0xff73e(%rip)        # aa0c0 <_ZN6apache6thrift8protocol24TCompactProtocolFactoryTINS0_9transport10TTransportEE11getProtocolESt10shared_ptrIS4_E>
  1a97fe:	0f 18 3d 3b 0d f0 ff                            	prefetchit0 -0xff2c5(%rip)        # aa540 <_ZN6apache6thrift8protocol24TCompactProtocolFactoryTINS0_9transport10TTransportEE11getProtocolESt10shared_ptrIS4_E+0x480>
  1a9805:	0f 18 3d 24 0d f0 ff                            	prefetchit0 -0xff2dc(%rip)        # aa530 <_ZN6apache6thrift8protocol24TCompactProtocolFactoryTINS0_9transport10TTransportEE11getProtocolESt10shared_ptrIS4_E+0x470>
  1a980c:	0f 18 3d f0 08 f0 ff                            	prefetchit0 -0xff710(%rip)        # aa103 <_ZN6apache6thrift8protocol24TCompactProtocolFactoryTINS0_9transport10TTransportEE11getProtocolESt10shared_ptrIS4_E+0x43>
  1a9813:	0f 18 3d 2b 09 f0 ff                            	prefetchit0 -0xff6d5(%rip)        # aa145 <_ZN6apache6thrift8protocol24TCompactProtocolFactoryTINS0_9transport10TTransportEE11getProtocolESt10shared_ptrIS4_E+0x85>
  1a981a:	0f 18 3d a3 0d f0 ff                            	prefetchit0 -0xff25d(%rip)        # aa5c4 <_ZN6apache6thrift8protocol24TCompactProtocolFactoryTINS0_9transport10TTransportEE11getProtocolESt10shared_ptrIS4_E+0x504>
  1a9821:	41 53                                           	push   %r11
  1a9823:	4c 8b 1d 0e b6 ff ff                            	mov    -0x49f2(%rip),%r11        # 1a4e38 <_ZN6apache6thrift8protocol9TProtocolD2Ev@Base>
  1a982a:	41 0f 18 93 74 44 fe ff                         	prefetcht1 -0x1bb8c(%r11)
  1a9832:	41 5b                                           	pop    %r11
  1a9834:	e9 67 87 ec ff                                  	jmp    71fa0 <_Znwm@plt>
  1a9839:	0f 1f 80 00 00 00 00                            	nopl   0x0(%rax)
  1a9840:	0f 18 3d 3c f2 ef ff                            	prefetchit0 -0x100dc4(%rip)        # a8a83 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE13writeI64_virtEl+0x13>
  1a9847:	0f 18 3d 22 f2 ef ff                            	prefetchit0 -0x100dde(%rip)        # a8a70 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE13writeI64_virtEl>
  1a984e:	0f 18 3d 6f f2 ef ff                            	prefetchit0 -0x100d91(%rip)        # a8ac4 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE13writeI64_virtEl+0x54>
  1a9855:	0f 18 3d e5 f2 ef ff                            	prefetchit0 -0x100d1b(%rip)        # a8b41 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE13writeI64_virtEl+0xd1>
  1a985c:	0f 18 3d 45 30 f0 ff                            	prefetchit0 -0xfcfbb(%rip)        # ac8a8 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE20writeFieldBegin_virtEPKcNS1_5TTypeEs+0x58>
  1a9863:	0f 18 3d b0 f3 ef ff                            	prefetchit0 -0x100c50(%rip)        # a8c1a <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE13writeI64_virtEl+0x1aa>
  1a986a:	e9 d1 99 ec ff                                  	jmp    73240 <_ZNK13jaegertracing6thrift4Span5writeEPN6apache6thrift8protocol9TProtocolE@plt>
  1a986f:	90                                              	nop
  1a9870:	0f 18 3d b9 f7 ef ff                            	prefetchit0 -0x100847(%rip)        # a9030 <_ZN6apache6thrift8protocol17TCompactProtocolTINS0_9transport10TTransportEED0Ev>
  1a9877:	0f 18 3d c3 f7 ef ff                            	prefetchit0 -0x10083d(%rip)        # a9041 <_ZN6apache6thrift8protocol17TCompactProtocolTINS0_9transport10TTransportEED0Ev+0x11>
  1a987e:	e9 cd 81 ec ff                                  	jmp    71a50 <_ZNSt16_Sp_counted_baseILN9__gnu_cxx12_Lock_policyE2EE10_M_releaseEv@plt>
  1a9883:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1a988d:	0f 1f 00                                        	nopl   (%rax)
  1a9890:	41 53                                           	push   %r11
  1a9892:	4c 8b 1d 9f b5 ff ff                            	mov    -0x4a61(%rip),%r11        # 1a4e38 <_ZN6apache6thrift8protocol9TProtocolD2Ev@Base>
  1a9899:	41 0f 18 93 90 5d fd ff                         	prefetcht1 -0x2a270(%r11)
  1a98a1:	41 0f 18 93 c0 f6 fe ff                         	prefetcht1 -0x10940(%r11)
  1a98a9:	4c 8b 1d 20 bc ff ff                            	mov    -0x43e0(%rip),%r11        # 1a54d0 <malloc@GLIBC_2.2.5>
  1a98b0:	41 0f 18 93 2e de ff ff                         	prefetcht1 -0x21d2(%r11)
  1a98b8:	41 5b                                           	pop    %r11
  1a98ba:	e9 51 8b ec ff                                  	jmp    72410 <_ZN6apache6thrift8protocol16TProtocolFactoryD2Ev@plt>
  1a98bf:	90                                              	nop
  1a98c0:	0f 18 3d 3c 0a f8 ff                            	prefetchit0 -0x7f5c4(%rip)        # 12a303 <_ZN13jaegertracing6thrift4SpanD1Ev+0x23>
  1a98c7:	0f 18 3d 75 97 f3 ff                            	prefetchit0 -0xc688b(%rip)        # e3043 <_ZN13jaegertracing9reporters14RemoteReporter10sweepQueueEv+0x153>
  1a98ce:	e9 4d 97 ec ff                                  	jmp    73020 <_ZN13jaegertracing6thrift4SpanD1Ev@plt>
  1a98d3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1a98dd:	0f 1f 00                                        	nopl   (%rax)
  1a98e0:	0f 18 3d 5b 2e f8 ff                            	prefetchit0 -0x7d1a5(%rip)        # 12c742 <_ZN13jaegertracing6thrift4SpanC1ERKS1_+0x42>
  1a98e7:	e9 a4 7f ec ff                                  	jmp    71890 <_ZN13jaegertracing6thrift4SpanC1ERKS1_@plt>
  1a98ec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a98f0:	0f 18 3d c1 0c f0 ff                            	prefetchit0 -0xff33f(%rip)        # aa5b8 <_ZN6apache6thrift8protocol24TCompactProtocolFactoryTINS0_9transport10TTransportEE11getProtocolESt10shared_ptrIS4_E+0x4f8>
  1a98f7:	0f 18 3d c2 07 f0 ff                            	prefetchit0 -0xff83e(%rip)        # aa0c0 <_ZN6apache6thrift8protocol24TCompactProtocolFactoryTINS0_9transport10TTransportEE11getProtocolESt10shared_ptrIS4_E>
  1a98fe:	e9 1d 91 ec ff                                  	jmp    72a20 <malloc@plt>
  1a9903:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1a990d:	0f 1f 00                                        	nopl   (%rax)
  1a9910:	0f 18 3d d9 83 ec ff                            	prefetchit0 -0x137c27(%rip)        # 71cf0 <_ZN6apache6thrift8protocol9TProtocolD2Ev@plt>
  1a9917:	41 53                                           	push   %r11
  1a9919:	4c 8b 1d 18 b5 ff ff                            	mov    -0x4ae8(%rip),%r11        # 1a4e38 <_ZN6apache6thrift8protocol9TProtocolD2Ev@Base>
  1a9920:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1a9928:	4c 8b 1d 99 b8 ff ff                            	mov    -0x4767(%rip),%r11        # 1a51c8 <_ZN6apache6thrift8protocol16TProtocolFactoryD2Ev@Base>
  1a992f:	41 0f 18 93 a0 ff ff ff                         	prefetcht1 -0x60(%r11)
  1a9937:	41 5b                                           	pop    %r11
  1a9939:	e9 d2 8c ec ff                                  	jmp    72610 <free@plt>
  1a993e:	66 90                                           	xchg   %ax,%ax
  1a9940:	41 53                                           	push   %r11
  1a9942:	4c 8b 1d ef b4 ff ff                            	mov    -0x4b11(%rip),%r11        # 1a4e38 <_ZN6apache6thrift8protocol9TProtocolD2Ev@Base>
  1a9949:	41 0f 18 93 60 44 fe ff                         	prefetcht1 -0x1bba0(%r11)
  1a9951:	41 5b                                           	pop    %r11
  1a9953:	e9 48 86 ec ff                                  	jmp    71fa0 <_Znwm@plt>
  1a9958:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1a9960:	0f 18 3d d9 fd f7 ff                            	prefetchit0 -0x80227(%rip)        # 129740 <_ZNK13jaegertracing6thrift4Span5writeEPN6apache6thrift8protocol9TProtocolE+0x30>
  1a9967:	0f 18 3d d5 44 f0 ff                            	prefetchit0 -0xfbb2b(%rip)        # ade43 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE21writeStructBegin_virtEPKc+0x23>
  1a996e:	0f 18 3d db 2e f0 ff                            	prefetchit0 -0xfd125(%rip)        # ac850 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE20writeFieldBegin_virtEPKcNS1_5TTypeEs>
  1a9975:	0f 18 3d 94 fd f7 ff                            	prefetchit0 -0x8026c(%rip)        # 129710 <_ZNK13jaegertracing6thrift4Span5writeEPN6apache6thrift8protocol9TProtocolE>
  1a997c:	0f 18 3d 9d 44 f0 ff                            	prefetchit0 -0xfbb63(%rip)        # ade20 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE21writeStructBegin_virtEPKc>
  1a9983:	0f 18 3d 37 2f f0 ff                            	prefetchit0 -0xfd0c9(%rip)        # ac8c1 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE20writeFieldBegin_virtEPKcNS1_5TTypeEs+0x71>
  1a998a:	41 53                                           	push   %r11
  1a998c:	4c 8b 1d a5 b4 ff ff                            	mov    -0x4b5b(%rip),%r11        # 1a4e38 <_ZN6apache6thrift8protocol9TProtocolD2Ev@Base>
  1a9993:	41 0f 18 93 f0 55 fd ff                         	prefetcht1 -0x2aa10(%r11)
  1a999b:	4c 8b 1d 26 b8 ff ff                            	mov    -0x47da(%rip),%r11        # 1a51c8 <_ZN6apache6thrift8protocol16TProtocolFactoryD2Ev@Base>
  1a99a2:	41 0f 18 93 10 e1 00 00                         	prefetcht1 0xe110(%r11)
  1a99aa:	41 5b                                           	pop    %r11
  1a99ac:	e9 ef 85 ec ff                                  	jmp    71fa0 <_Znwm@plt>
  1a99b1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1a99bb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1a99c0:	0f 18 3d 19 95 ec ff                            	prefetchit0 -0x136ae7(%rip)        # 72ee0 <_ZN13jaegertracing6thrift4Span16__set_traceIdLowEl@plt>
  1a99c7:	e9 84 75 ec ff                                  	jmp    70f50 <_ZN13jaegertracing6thrift4Span17__set_traceIdHighEl@plt>
  1a99cc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a99d0:	0f 18 3d 99 97 ec ff                            	prefetchit0 -0x136867(%rip)        # 73170 <_ZN13jaegertracing6thrift4Span18__set_parentSpanIdEl@plt>
  1a99d7:	e9 04 95 ec ff                                  	jmp    72ee0 <_ZN13jaegertracing6thrift4Span16__set_traceIdLowEl@plt>
  1a99dc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a99e0:	0f 18 3d 11 23 f0 ff                            	prefetchit0 -0xfdcef(%rip)        # abcf8 <_ZNK13jaegertracing4Span6thriftEv+0xa08>
  1a99e7:	0f 18 3d d2 8a ec ff                            	prefetchit0 -0x13752e(%rip)        # 724c0 <_ZN13jaegertracing6thrift4Span19__set_operationNameERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE@plt>
  1a99ee:	0f 18 3d 0b 23 f0 ff                            	prefetchit0 -0xfdcf5(%rip)        # abd00 <_ZNK13jaegertracing4Span6thriftEv+0xa10>
  1a99f5:	e9 46 77 ec ff                                  	jmp    71140 <_ZN13jaegertracing6thrift4Span12__set_spanIdEl@plt>
  1a99fa:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1a9a00:	0f 18 3d f1 22 f0 ff                            	prefetchit0 -0xfdd0f(%rip)        # abcf8 <_ZNK13jaegertracing4Span6thriftEv+0xa08>
  1a9a07:	e9 64 97 ec ff                                  	jmp    73170 <_ZN13jaegertracing6thrift4Span18__set_parentSpanIdEl@plt>
  1a9a0c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a9a10:	0f 18 3d 99 f0 f7 ff                            	prefetchit0 -0x80f67(%rip)        # 128ab0 <_ZN13jaegertracing6thrift7SpanRefD1Ev>
  1a9a17:	0f 18 3d 02 a5 ec ff                            	prefetchit0 -0x135afe(%rip)        # 73f20 <_ZN13jaegertracing6thrift4Span16__set_referencesERKSt6vectorINS0_7SpanRefESaIS3_EE@plt>
  1a9a1e:	0f 18 3d 2b 8a ec ff                            	prefetchit0 -0x1375d5(%rip)        # 72450 <_ZN13jaegertracing6thrift7SpanRefC1ERKS1_@plt>
  1a9a25:	0f 18 3d ac 19 f8 ff                            	prefetchit0 -0x7e654(%rip)        # 12b3d8 <_ZNSt6vectorIN13jaegertracing6thrift7SpanRefESaIS2_EEaSERKS4_.isra.0+0xf8>
  1a9a2c:	e9 1f 9e ec ff                                  	jmp    73850 <_ZN13jaegertracing6thrift7SpanRef17__set_traceIdHighEl@plt>
  1a9a31:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1a9a3b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1a9a40:	0f 18 3d 29 7f ec ff                            	prefetchit0 -0x1380d7(%rip)        # 71970 <_ZN13jaegertracing6thrift4Span15__set_startTimeEl@plt>
  1a9a47:	e9 d4 a4 ec ff                                  	jmp    73f20 <_ZN13jaegertracing6thrift4Span16__set_referencesERKSt6vectorINS0_7SpanRefESaIS3_EE@plt>
  1a9a4c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a9a50:	0f 18 3d 2b 04 f0 ff                            	prefetchit0 -0xffbd5(%rip)        # a9e82 <_ZNSt6vectorIN13jaegertracing6thrift3TagESaIS2_EE7reserveEm+0x32>
  1a9a57:	e9 14 a3 ec ff                                  	jmp    73d70 <_ZN13jaegertracing6thrift4Span11__set_flagsEi@plt>
  1a9a5c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a9a60:	0f 18 3d c9 25 f8 ff                            	prefetchit0 -0x7da37(%rip)        # 12c030 <_ZNSt6vectorIN13jaegertracing6thrift3LogESaIS2_EEaSERKS4_.isra.0>
  1a9a67:	0f 18 3d 94 11 f8 ff                            	prefetchit0 -0x7ee6c(%rip)        # 12ac02 <_ZNSt6vectorIN13jaegertracing6thrift3TagESaIS2_EEaSERKS4_.isra.0+0x42>
  1a9a6e:	0f 18 3d db 03 f0 ff                            	prefetchit0 -0xffc25(%rip)        # a9e50 <_ZNSt6vectorIN13jaegertracing6thrift3TagESaIS2_EE7reserveEm>
  1a9a75:	0f 18 3d 17 28 f8 ff                            	prefetchit0 -0x7d7e9(%rip)        # 12c293 <_ZNSt6vectorIN13jaegertracing6thrift3LogESaIS2_EEaSERKS4_.isra.0+0x263>
  1a9a7c:	0f 18 3d 3d 2a f8 ff                            	prefetchit0 -0x7d5c3(%rip)        # 12c4c0 <_ZN13jaegertracing6thrift4Span10__set_logsERKSt6vectorINS0_3LogESaIS3_EE>
  1a9a83:	0f 18 3d fb 25 f8 ff                            	prefetchit0 -0x7da05(%rip)        # 12c085 <_ZNSt6vectorIN13jaegertracing6thrift3LogESaIS2_EEaSERKS4_.isra.0+0x55>
  1a9a8a:	0f 18 3d 2f 11 f8 ff                            	prefetchit0 -0x7eed1(%rip)        # 12abc0 <_ZNSt6vectorIN13jaegertracing6thrift3TagESaIS2_EEaSERKS4_.isra.0>
  1a9a91:	0f 18 3d c8 99 ec ff                            	prefetchit0 -0x136638(%rip)        # 73460 <_ZN13jaegertracing6thrift4Span14__set_durationEl@plt>
  1a9a98:	e9 d3 7e ec ff                                  	jmp    71970 <_ZN13jaegertracing6thrift4Span15__set_startTimeEl@plt>
  1a9a9d:	0f 1f 00                                        	nopl   (%rax)
  1a9aa0:	0f 18 3d da e9 ef ff                            	prefetchit0 -0x101626(%rip)        # a8481 <_ZN13jaegertracing12UDPTransport6appendERKNS_4SpanE+0x311>
  1a9aa7:	e9 e4 83 ec ff                                  	jmp    71e90 <_ZdlPv@plt>
  1a9aac:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a9ab0:	0f 18 3d f1 eb ef ff                            	prefetchit0 -0x10140f(%rip)        # a86a8 <_ZN13jaegertracing12UDPTransport6appendERKNS_4SpanE+0x538>
  1a9ab7:	e9 94 7d ec ff                                  	jmp    71850 <pthread_mutex_unlock@plt>
  1a9abc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a9ac0:	0f 18 3d e9 16 f8 ff                            	prefetchit0 -0x7e917(%rip)        # 12b1b0 <_ZN13jaegertracing6thrift7SpanRef13__set_refTypeENS0_11SpanRefType4typeE>
  1a9ac7:	0f 18 3d 92 87 ec ff                            	prefetchit0 -0x13786e(%rip)        # 72260 <_ZN13jaegertracing6thrift7SpanRef16__set_traceIdLowEl@plt>
  1a9ace:	0f 18 3d 7b 9d ec ff                            	prefetchit0 -0x136285(%rip)        # 73850 <_ZN13jaegertracing6thrift7SpanRef17__set_traceIdHighEl@plt>
  1a9ad5:	e9 c6 84 ec ff                                  	jmp    71fa0 <_Znwm@plt>
  1a9ada:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1a9ae0:	0f 18 3d d1 89 f3 ff                            	prefetchit0 -0xc762f(%rip)        # e24b8 <_ZN13jaegertracing4SpanD2Ev.constprop.0+0x908>
  1a9ae7:	0f 18 3d d4 89 f3 ff                            	prefetchit0 -0xc762c(%rip)        # e24c2 <_ZN13jaegertracing4SpanD2Ev.constprop.0+0x912>
  1a9aee:	0f 18 3d 3b d9 ed ff                            	prefetchit0 -0x1226c5(%rip)        # 87430 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE+0x6e0>
  1a9af5:	0f 18 3d 54 d2 ed ff                            	prefetchit0 -0x122dac(%rip)        # 86d50 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE>
  1a9afc:	0f 18 3d 3e d9 ed ff                            	prefetchit0 -0x1226c2(%rip)        # 87441 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE+0x6f1>
  1a9b03:	0f 18 3d f6 79 ec ff                            	prefetchit0 -0x13860a(%rip)        # 71500 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE@plt>
  1a9b0a:	0f 18 3d 70 d2 ed ff                            	prefetchit0 -0x122d90(%rip)        # 86d81 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE+0x31>
  1a9b11:	0f 18 3d 71 82 f3 ff                            	prefetchit0 -0xc7d8f(%rip)        # e1d89 <_ZN13jaegertracing4SpanD2Ev.constprop.0+0x1d9>
  1a9b18:	e9 e3 8e ec ff                                  	jmp    72a00 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
  1a9b1d:	0f 1f 00                                        	nopl   (%rax)
  1a9b20:	0f 18 3d de 8d f3 ff                            	prefetchit0 -0xc7222(%rip)        # e2905 <_ZN13jaegertracing4SpanD2Ev.constprop.0+0xd55>
  1a9b27:	41 53                                           	push   %r11
  1a9b29:	4c 8b 1d d8 b3 ff ff                            	mov    -0x4c28(%rip),%r11        # 1a4f08 <_ZdlPv@GLIBCXX_3.4>
  1a9b30:	41 0f 18 93 20 2f ff ff                         	prefetcht1 -0xd0e0(%r11)
  1a9b38:	41 5b                                           	pop    %r11
  1a9b3a:	e9 91 75 ec ff                                  	jmp    710d0 <memset@plt>
  1a9b3f:	90                                              	nop
  1a9b40:	0f 18 3d be 8d f3 ff                            	prefetchit0 -0xc7242(%rip)        # e2905 <_ZN13jaegertracing4SpanD2Ev.constprop.0+0xd55>
  1a9b47:	e9 44 83 ec ff                                  	jmp    71e90 <_ZdlPv@plt>
  1a9b4c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a9b50:	0f 18 3d 2b e6 ef ff                            	prefetchit0 -0x1019d5(%rip)        # a8182 <_ZN13jaegertracing12UDPTransport6appendERKNS_4SpanE+0x12>
  1a9b57:	0f 18 3d 12 e6 ef ff                            	prefetchit0 -0x1019ee(%rip)        # a8170 <_ZN13jaegertracing12UDPTransport6appendERKNS_4SpanE>
  1a9b5e:	0f 18 3d db 7f f3 ff                            	prefetchit0 -0xc8025(%rip)        # e1b40 <_ZN13jaegertracing9reporters14RemoteReporter8sendSpanERKNS_4SpanE+0x30>
  1a9b65:	0f 18 3d a4 7f f3 ff                            	prefetchit0 -0xc805c(%rip)        # e1b10 <_ZN13jaegertracing9reporters14RemoteReporter8sendSpanERKNS_4SpanE>
  1a9b6c:	0f 18 3d 3d 6f ec ff                            	prefetchit0 -0x1390c3(%rip)        # 70ab0 <_ZN13jaegertracing9reporters14RemoteReporter8sendSpanERKNS_4SpanE@plt>
  1a9b73:	e9 58 75 ec ff                                  	jmp    710d0 <memset@plt>
  1a9b78:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1a9b80:	0f 18 3d 79 0b f4 ff                            	prefetchit0 -0xbf487(%rip)        # ea700 <_ZNSt5dequeIN13jaegertracing4SpanESaIS1_EE16_M_push_back_auxIJRKS1_EEEvDpOT_+0x40>
  1a9b87:	0f 18 3d 32 0b f4 ff                            	prefetchit0 -0xbf4ce(%rip)        # ea6c0 <_ZNSt5dequeIN13jaegertracing4SpanESaIS1_EE16_M_push_back_auxIJRKS1_EEEvDpOT_>
  1a9b8e:	0f 18 3d ad 0b f4 ff                            	prefetchit0 -0xbf453(%rip)        # ea742 <_ZNSt5dequeIN13jaegertracing4SpanESaIS1_EE16_M_push_back_auxIJRKS1_EEEvDpOT_+0x82>
  1a9b95:	0f 18 3d 64 e8 f3 ff                            	prefetchit0 -0xc179c(%rip)        # e8400 <_ZN13jaegertracing4SpanC1ERKS0_+0xf0>
  1a9b9c:	0f 18 3d e2 e8 f3 ff                            	prefetchit0 -0xc171e(%rip)        # e8485 <_ZN13jaegertracing4SpanC1ERKS0_+0x175>
  1a9ba3:	0f 18 3d f6 98 ec ff                            	prefetchit0 -0x13670a(%rip)        # 734a0 <memmove@plt>
  1a9baa:	0f 18 3d 7f 8e ec ff                            	prefetchit0 -0x137181(%rip)        # 72a30 <_ZNSt5dequeIN13jaegertracing4SpanESaIS1_EE16_M_push_back_auxIJRKS1_EEEvDpOT_@plt>
  1a9bb1:	0f 18 3d 8b e7 f3 ff                            	prefetchit0 -0xc1875(%rip)        # e8343 <_ZN13jaegertracing4SpanC1ERKS0_+0x33>
  1a9bb8:	e9 a3 93 ec ff                                  	jmp    72f60 <pthread_mutex_lock@plt>
  1a9bbd:	0f 1f 00                                        	nopl   (%rax)
  1a9bc0:	41 53                                           	push   %r11
  1a9bc2:	4c 8b 1d 4f ab ff ff                            	mov    -0x54b1(%rip),%r11        # 1a4718 <_ZNSt18condition_variable10notify_oneEv@GLIBCXX_3.4.11>
  1a9bc9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1a9bd1:	41 5b                                           	pop    %r11
  1a9bd3:	e9 78 7c ec ff                                  	jmp    71850 <pthread_mutex_unlock@plt>
  1a9bd8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1a9be0:	0f 18 3d 9a 19 ee ff                            	prefetchit0 -0x11e666(%rip)        # 8b581 <_ZN13jaegertracing4SpanD0Ev+0x11>
  1a9be7:	0f 18 3d 82 19 ee ff                            	prefetchit0 -0x11e67e(%rip)        # 8b570 <_ZN13jaegertracing4SpanD0Ev>
  1a9bee:	0f 18 3d cc 19 ee ff                            	prefetchit0 -0x11e634(%rip)        # 8b5c1 <_ZN13jaegertracing4SpanD0Ev+0x51>
  1a9bf5:	41 53                                           	push   %r11
  1a9bf7:	4c 8b 1d d2 aa ff ff                            	mov    -0x552e(%rip),%r11        # 1a46d0 <pthread_cond_clockwait@GLIBC_2.34>
  1a9bfe:	41 0f 18 93 40 f1 ff ff                         	prefetcht1 -0xec0(%r11)
  1a9c06:	41 0f 18 93 61 f1 ff ff                         	prefetcht1 -0xe9f(%r11)
  1a9c0e:	4c 8b 1d 23 b2 ff ff                            	mov    -0x4ddd(%rip),%r11        # 1a4e38 <_ZN6apache6thrift8protocol9TProtocolD2Ev@Base>
  1a9c15:	41 0f 18 93 60 44 fe ff                         	prefetcht1 -0x1bba0(%r11)
  1a9c1d:	41 0f 18 93 74 44 fe ff                         	prefetcht1 -0x1bb8c(%r11)
  1a9c25:	4c 8b 1d dc b2 ff ff                            	mov    -0x4d24(%rip),%r11        # 1a4f08 <_ZdlPv@GLIBCXX_3.4>
  1a9c2c:	41 0f 18 93 a0 20 ff ff                         	prefetcht1 -0xdf60(%r11)
  1a9c34:	41 5b                                           	pop    %r11
  1a9c36:	e9 75 72 ec ff                                  	jmp    70eb0 <_ZNSt18condition_variable10notify_oneEv@plt>
  1a9c3b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1a9c40:	0f 18 3d 59 86 ec ff                            	prefetchit0 -0x1379a7(%rip)        # 722a0 <_ZSt4lockISt5mutexS0_JEEvRT_RT0_DpRT1_@plt>
  1a9c47:	0f 18 3d 12 93 ec ff                            	prefetchit0 -0x136cee(%rip)        # 72f60 <pthread_mutex_lock@plt>
  1a9c4e:	0f 18 3d 1d 02 f4 ff                            	prefetchit0 -0xbfde3(%rip)        # e9e72 <_ZN13jaegertracing4SpanC1ERKS0_+0x1b62>
  1a9c55:	e9 26 9f ec ff                                  	jmp    73b80 <_ZN13jaegertracing4SpanC1ERKS0_@plt>
  1a9c5a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1a9c60:	0f 18 3d 89 16 f0 ff                            	prefetchit0 -0xfe977(%rip)        # ab2f0 <_ZNK13jaegertracing4Span6thriftEv>
  1a9c67:	0f 18 3d 92 16 f0 ff                            	prefetchit0 -0xfe96e(%rip)        # ab300 <_ZNK13jaegertracing4Span6thriftEv+0x10>
  1a9c6e:	0f 18 3d 5b 1b f8 ff                            	prefetchit0 -0x7e4a5(%rip)        # 12b7d0 <_ZN13jaegertracing6thrift4Span17__set_traceIdHighEl>
  1a9c75:	0f 18 3d b3 e7 ef ff                            	prefetchit0 -0x10184d(%rip)        # a842f <_ZN13jaegertracing12UDPTransport6appendERKNS_4SpanE+0x2bf>
  1a9c7c:	0f 18 3d bf e7 ef ff                            	prefetchit0 -0x101841(%rip)        # a8442 <_ZN13jaegertracing12UDPTransport6appendERKNS_4SpanE+0x2d2>
  1a9c83:	0f 18 3d 96 74 ec ff                            	prefetchit0 -0x138b6a(%rip)        # 71120 <_ZNK13jaegertracing4Span6thriftEv@plt>
  1a9c8a:	e9 21 6e ec ff                                  	jmp    70ab0 <_ZN13jaegertracing9reporters14RemoteReporter8sendSpanERKNS_4SpanE@plt>
  1a9c8f:	90                                              	nop
  1a9c90:	0f 18 3d a9 9f f3 ff                            	prefetchit0 -0xc6057(%rip)        # e3c40 <_ZN13jaegertracing9reporters14RemoteReporter10sweepQueueEv+0xd50>
  1a9c97:	e9 64 8d ec ff                                  	jmp    72a00 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
  1a9c9c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a9ca0:	0f 18 3d 50 a3 f3 ff                            	prefetchit0 -0xc5cb0(%rip)        # e3ff7 <_ZN13jaegertracing9reporters14RemoteReporter10sweepQueueEv+0x1107>
  1a9ca7:	e9 24 74 ec ff                                  	jmp    710d0 <memset@plt>
  1a9cac:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a9cb0:	41 53                                           	push   %r11
  1a9cb2:	4c 8b 1d 17 aa ff ff                            	mov    -0x55e9(%rip),%r11        # 1a46d0 <pthread_cond_clockwait@GLIBC_2.34>
  1a9cb9:	41 0f 18 93 63 00 00 00                         	prefetcht1 0x63(%r11)
  1a9cc1:	41 5b                                           	pop    %r11
  1a9cc3:	e9 88 7b ec ff                                  	jmp    71850 <pthread_mutex_unlock@plt>
  1a9cc8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1a9cd0:	41 53                                           	push   %r11
  1a9cd2:	4c 8b 1d f7 a9 ff ff                            	mov    -0x5609(%rip),%r11        # 1a46d0 <pthread_cond_clockwait@GLIBC_2.34>
  1a9cd9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1a9ce1:	41 0f 18 93 63 00 00 00                         	prefetcht1 0x63(%r11)
  1a9ce9:	41 5b                                           	pop    %r11
  1a9ceb:	e9 30 71 ec ff                                  	jmp    70e20 <pthread_cond_clockwait@plt>
  1a9cf0:	0f 18 3d 6e f0 f3 ff                            	prefetchit0 -0xc0f92(%rip)        # e8d65 <_ZN13jaegertracing4SpanC1ERKS0_+0xa55>
  1a9cf7:	0f 18 3d 45 e6 f3 ff                            	prefetchit0 -0xc19bb(%rip)        # e8343 <_ZN13jaegertracing4SpanC1ERKS0_+0x33>
  1a9cfe:	0f 18 3d bb 87 ee ff                            	prefetchit0 -0x117845(%rip)        # 924c0 <_ZSt4lockISt5mutexS0_JEEvRT_RT0_DpRT1_>
  1a9d05:	0f 18 3d 74 9e ec ff                            	prefetchit0 -0x13618c(%rip)        # 73b80 <_ZN13jaegertracing4SpanC1ERKS0_@plt>
  1a9d0c:	0f 18 3d 70 e6 f3 ff                            	prefetchit0 -0xc1990(%rip)        # e8383 <_ZN13jaegertracing4SpanC1ERKS0_+0x73>
  1a9d13:	0f 18 3d 9c 92 f3 ff                            	prefetchit0 -0xc6d64(%rip)        # e2fb6 <_ZN13jaegertracing9reporters14RemoteReporter10sweepQueueEv+0xc6>
  1a9d1a:	0f 18 3d a0 e6 f3 ff                            	prefetchit0 -0xc1960(%rip)        # e83c1 <_ZN13jaegertracing4SpanC1ERKS0_+0xb1>
  1a9d21:	0f 18 3d e8 e5 f3 ff                            	prefetchit0 -0xc1a18(%rip)        # e8310 <_ZN13jaegertracing4SpanC1ERKS0_>
  1a9d28:	e9 d3 8c ec ff                                  	jmp    72a00 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
  1a9d2d:	0f 1f 00                                        	nopl   (%rax)
  1a9d30:	0f 18 3d 99 73 ec ff                            	prefetchit0 -0x138c67(%rip)        # 710d0 <memset@plt>
  1a9d37:	e9 74 74 ec ff                                  	jmp    711b0 <_ZN13jaegertracing11SpanContextC1ERKS0_@plt>
  1a9d3c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a9d40:	0f 18 3d 09 73 ec ff                            	prefetchit0 -0x138cf7(%rip)        # 71050 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_assignERKS4_@plt>
  1a9d47:	41 53                                           	push   %r11
  1a9d49:	4c 8b 1d b8 b1 ff ff                            	mov    -0x4e48(%rip),%r11        # 1a4f08 <_ZdlPv@GLIBCXX_3.4>
  1a9d50:	41 0f 18 93 e0 54 ff ff                         	prefetcht1 -0xab20(%r11)
  1a9d58:	4c 8b 1d 31 b2 ff ff                            	mov    -0x4dcf(%rip),%r11        # 1a4f90 <_Znwm@GLIBCXX_3.4>
  1a9d5f:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1a9d67:	4c 8b 1d a2 bf ff ff                            	mov    -0x405e(%rip),%r11        # 1a5d10 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm@GLIBCXX_3.4.21>
  1a9d6e:	41 0f 18 93 d8 ff ff ff                         	prefetcht1 -0x28(%r11)
  1a9d76:	41 5b                                           	pop    %r11
  1a9d78:	e9 53 73 ec ff                                  	jmp    710d0 <memset@plt>
  1a9d7d:	0f 1f 00                                        	nopl   (%rax)
  1a9d80:	0f 18 3d 13 da f3 ff                            	prefetchit0 -0xc25ed(%rip)        # e779a <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EEaSERKS3_.isra.0+0x52a>
  1a9d87:	0f 18 3d e2 d4 f3 ff                            	prefetchit0 -0xc2b1e(%rip)        # e7270 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EEaSERKS3_.isra.0>
  1a9d8e:	0f 18 3d ed d4 f3 ff                            	prefetchit0 -0xc2b13(%rip)        # e7282 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EEaSERKS3_.isra.0+0x12>
  1a9d95:	0f 18 3d d4 f7 f3 ff                            	prefetchit0 -0xc082c(%rip)        # e9570 <_ZN13jaegertracing4SpanC1ERKS0_+0x1260>
  1a9d9c:	0f 18 3d 1f d5 f3 ff                            	prefetchit0 -0xc2ae1(%rip)        # e72c2 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EEaSERKS3_.isra.0+0x52>
  1a9da3:	0f 18 3d d9 e9 f3 ff                            	prefetchit0 -0xc1627(%rip)        # e8783 <_ZN13jaegertracing4SpanC1ERKS0_+0x473>
  1a9daa:	41 53                                           	push   %r11
  1a9dac:	4c 8b 1d 35 aa ff ff                            	mov    -0x55cb(%rip),%r11        # 1a47e8 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_assignERKS4_@GLIBCXX_3.4.21>
  1a9db3:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1a9dbb:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
  1a9dc3:	41 5b                                           	pop    %r11
  1a9dc5:	e9 86 72 ec ff                                  	jmp    71050 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_assignERKS4_@plt>
  1a9dca:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1a9dd0:	0f 18 3d ac f7 f3 ff                            	prefetchit0 -0xc0854(%rip)        # e9583 <_ZN13jaegertracing4SpanC1ERKS0_+0x1273>
  1a9dd7:	0f 18 3d bd ed f3 ff                            	prefetchit0 -0xc1243(%rip)        # e8b9b <_ZN13jaegertracing4SpanC1ERKS0_+0x88b>
  1a9dde:	0f 18 3d 8b f7 f3 ff                            	prefetchit0 -0xc0875(%rip)        # e9570 <_ZN13jaegertracing4SpanC1ERKS0_+0x1260>
  1a9de5:	e9 86 d4 f3 ff                                  	jmp    e7270 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EEaSERKS3_.isra.0>
  1a9dea:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1a9df0:	0f 18 3d b9 70 ec ff                            	prefetchit0 -0x138f47(%rip)        # 70eb0 <_ZNSt18condition_variable10notify_oneEv@plt>
  1a9df7:	41 53                                           	push   %r11
  1a9df9:	4c 8b 1d 18 a9 ff ff                            	mov    -0x56e8(%rip),%r11        # 1a4718 <_ZNSt18condition_variable10notify_oneEv@GLIBCXX_3.4.11>
  1a9e00:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1a9e08:	41 5b                                           	pop    %r11
  1a9e0a:	e9 41 7a ec ff                                  	jmp    71850 <pthread_mutex_unlock@plt>
  1a9e0f:	90                                              	nop
  1a9e10:	0f 18 3d 99 7d f3 ff                            	prefetchit0 -0xc8267(%rip)        # e1bb0 <_ZN13jaegertracing4SpanD2Ev.constprop.0>
  1a9e17:	0f 18 3d fe a4 f3 ff                            	prefetchit0 -0xc5b02(%rip)        # e431c <_ZN13jaegertracing9reporters14RemoteReporter10sweepQueueEv+0x142c>
  1a9e1e:	0f 18 3d 9b 7d f3 ff                            	prefetchit0 -0xc8265(%rip)        # e1bc0 <_ZN13jaegertracing4SpanD2Ev.constprop.0+0x10>
  1a9e25:	e9 76 81 ec ff                                  	jmp    71fa0 <_Znwm@plt>
  1a9e2a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1a9e30:	0f 18 3d 4c e5 f3 ff                            	prefetchit0 -0xc1ab4(%rip)        # e8383 <_ZN13jaegertracing4SpanC1ERKS0_+0x73>
  1a9e37:	0f 18 3d d2 e4 f3 ff                            	prefetchit0 -0xc1b2e(%rip)        # e8310 <_ZN13jaegertracing4SpanC1ERKS0_>
  1a9e3e:	0f 18 3d fb e5 f3 ff                            	prefetchit0 -0xc1a05(%rip)        # e8440 <_ZN13jaegertracing4SpanC1ERKS0_+0x130>
  1a9e45:	0f 18 3d 39 e6 f3 ff                            	prefetchit0 -0xc19c7(%rip)        # e8485 <_ZN13jaegertracing4SpanC1ERKS0_+0x175>
  1a9e4c:	0f 18 3d f0 e4 f3 ff                            	prefetchit0 -0xc1b10(%rip)        # e8343 <_ZN13jaegertracing4SpanC1ERKS0_+0x33>
  1a9e53:	0f 18 3d 67 e5 f3 ff                            	prefetchit0 -0xc1a99(%rip)        # e83c1 <_ZN13jaegertracing4SpanC1ERKS0_+0xb1>
  1a9e5a:	e9 41 81 ec ff                                  	jmp    71fa0 <_Znwm@plt>
  1a9e5f:	90                                              	nop
  1a9e60:	0f 18 3d fe ee f3 ff                            	prefetchit0 -0xc1102(%rip)        # e8d65 <_ZN13jaegertracing4SpanC1ERKS0_+0xa55>
  1a9e67:	0f 18 3d 32 84 ec ff                            	prefetchit0 -0x137bce(%rip)        # 722a0 <_ZSt4lockISt5mutexS0_JEEvRT_RT0_DpRT1_@plt>
  1a9e6e:	0f 18 3d fd ff f3 ff                            	prefetchit0 -0xc0003(%rip)        # e9e72 <_ZN13jaegertracing4SpanC1ERKS0_+0x1b62>
  1a9e75:	0f 18 3d 44 86 ee ff                            	prefetchit0 -0x1179bc(%rip)        # 924c0 <_ZSt4lockISt5mutexS0_JEEvRT_RT0_DpRT1_>
  1a9e7c:	0f 18 3d 81 2f ee ff                            	prefetchit0 -0x11d07f(%rip)        # 8ce04 <_ZN13jaegertracing11SpanContextC1ERKS0_+0x34>
  1a9e83:	0f 18 3d f6 64 ec ff                            	prefetchit0 -0x139b0a(%rip)        # 70380 <pthread_mutex_trylock@plt>
  1a9e8a:	41 53                                           	push   %r11
  1a9e8c:	4c 8b 1d ed a2 ff ff                            	mov    -0x5d13(%rip),%r11        # 1a4180 <pthread_mutex_trylock@GLIBC_2.34>
  1a9e93:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1a9e9b:	41 0f 18 93 33 00 00 00                         	prefetcht1 0x33(%r11)
  1a9ea3:	41 5b                                           	pop    %r11
  1a9ea5:	e9 d6 9c ec ff                                  	jmp    73b80 <_ZN13jaegertracing4SpanC1ERKS0_@plt>
  1a9eaa:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  1a9eb0:	0f 18 3d 29 04 f8 ff                            	prefetchit0 -0x7fbd7(%rip)        # 12a2e0 <_ZN13jaegertracing6thrift4SpanD1Ev>
  1a9eb7:	0f 18 3d 45 04 f8 ff                            	prefetchit0 -0x7fbbb(%rip)        # 12a303 <_ZN13jaegertracing6thrift4SpanD1Ev+0x23>
  1a9ebe:	e9 dd 80 ec ff                                  	jmp    71fa0 <_Znwm@plt>
  1a9ec3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1a9ecd:	0f 1f 00                                        	nopl   (%rax)
  1a9ed0:	0f 18 3d 89 7f ec ff                            	prefetchit0 -0x138077(%rip)        # 71e60 <_ZN13jaegertracing6thrift4Span10__set_logsERKSt6vectorINS0_3LogESaIS3_EE@plt>
  1a9ed7:	0f 18 3d ed 0e f8 ff                            	prefetchit0 -0x7f113(%rip)        # 12adcb <_ZNSt6vectorIN13jaegertracing6thrift3TagESaIS2_EEaSERKS4_.isra.0+0x20b>
  1a9ede:	0f 18 3d a2 1b f0 ff                            	prefetchit0 -0xfe45e(%rip)        # aba87 <_ZNK13jaegertracing4Span6thriftEv+0x797>
  1a9ee5:	0f 18 3d 54 21 f8 ff                            	prefetchit0 -0x7deac(%rip)        # 12c040 <_ZNSt6vectorIN13jaegertracing6thrift3LogESaIS2_EEaSERKS4_.isra.0+0x10>
  1a9eec:	e9 cf 0c f8 ff                                  	jmp    12abc0 <_ZNSt6vectorIN13jaegertracing6thrift3TagESaIS2_EEaSERKS4_.isra.0>
  1a9ef1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1a9efb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1a9f00:	0f 18 3d 19 91 ec ff                            	prefetchit0 -0x136ee7(%rip)        # 73020 <_ZN13jaegertracing6thrift4SpanD1Ev@plt>
  1a9f07:	e9 d4 13 f8 ff                                  	jmp    12b2e0 <_ZNSt6vectorIN13jaegertracing6thrift7SpanRefESaIS2_EEaSERKS4_.isra.0>
  1a9f0c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a9f10:	0f 18 3d ec 03 f8 ff                            	prefetchit0 -0x7fc14(%rip)        # 12a303 <_ZN13jaegertracing6thrift4SpanD1Ev+0x23>
  1a9f17:	e9 a4 0c f8 ff                                  	jmp    12abc0 <_ZNSt6vectorIN13jaegertracing6thrift3TagESaIS2_EEaSERKS4_.isra.0>
  1a9f1c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1a9f20:	0f 18 3d b9 03 f8 ff                            	prefetchit0 -0x7fc47(%rip)        # 12a2e0 <_ZN13jaegertracing6thrift4SpanD1Ev>
  1a9f27:	0f 18 3d c6 04 f8 ff                            	prefetchit0 -0x7fb3a(%rip)        # 12a3f4 <_ZN13jaegertracing6thrift4SpanD1Ev+0x114>
  1a9f2e:	e9 fd 20 f8 ff                                  	jmp    12c030 <_ZNSt6vectorIN13jaegertracing6thrift3LogESaIS2_EEaSERKS4_.isra.0>
