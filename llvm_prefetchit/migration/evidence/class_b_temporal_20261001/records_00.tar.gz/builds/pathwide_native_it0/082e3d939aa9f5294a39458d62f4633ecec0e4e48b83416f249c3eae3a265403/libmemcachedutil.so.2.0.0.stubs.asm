
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_native_it0/082e3d939aa9f5294a39458d62f4633ecec0e4e48b83416f249c3eae3a265403/libmemcachedutil.so.2.0.0:     file format elf64-x86-64


Disassembly of section .text.prefetch_calls:

00000000000072c0 <.text.prefetch_calls>:
    72c0:	0f 18 3d d9 b0 ff ff                            	prefetchit0 -0x4f27(%rip)        # 23a0 <pthread_mutex_lock@plt>
    72c7:	0f 18 3d f2 af ff ff                            	prefetchit0 -0x500e(%rip)        # 22c0 <pthread_mutex_unlock@plt>
    72ce:	e9 6d b2 ff ff                                  	jmp    2540 <_ZnwmRKSt9nothrow_t@plt+0xd0>
