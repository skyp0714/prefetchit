
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_native_it0/ff0825e113603c3866680d5d52216bc6d8eedf3a59f52a0aef67ff01994db128/libstdc++.so.6.0.30:     file format elf64-x86-64


Disassembly of section .text.prefetch_calls:

000000000022c300 <.text.prefetch_calls>:
  22c300:	0f 18 3d d9 e3 ea ff                            	prefetchit0 -0x151c27(%rip)        # da6e0 <_ZNSt8ios_baseC1Ev@@GLIBCXX_3.4>
  22c307:	0f 18 3d 9a a6 e9 ff                            	prefetchit0 -0x165966(%rip)        # c69a8 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_@@GLIBCXX_3.4+0x2a8>
  22c30e:	0f 18 3d 2d 58 ef ff                            	prefetchit0 -0x10a7d3(%rip)        # 121b42 <_ZNSi7putbackEc@@GLIBCXX_3.4+0x22>
  22c315:	e9 b6 2d e7 ff                                  	jmp    9f0d0 <malloc@plt>
  22c31a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  22c320:	0f 18 3d d9 54 e7 ff                            	prefetchit0 -0x18ab27(%rip)        # a1800 <_ZNSt9basic_iosIcSt11char_traitsIcEE15_M_cache_localeERKSt6locale@plt>
  22c327:	e9 54 34 e7 ff                                  	jmp    9f780 <_ZNSt6localeC1Ev@plt>
  22c32c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  22c330:	0f 18 3d f9 e5 ea ff                            	prefetchit0 -0x151a07(%rip)        # da930 <_ZNSt8ios_base17_M_call_callbacksENS_5eventE@@GLIBCXX_3.4.6>
  22c337:	0f 18 3d 32 24 e7 ff                            	prefetchit0 -0x18dbce(%rip)        # 9e770 <_ZNSt8ios_base20_M_dispose_callbacksEv@plt>
  22c33e:	e9 6d 40 e7 ff                                  	jmp    a03b0 <_ZNSt8ios_base17_M_call_callbacksENS_5eventE@plt>
  22c343:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  22c34d:	0f 1f 00                                        	nopl   (%rax)
  22c350:	0f 18 3d ac 86 f1 ff                            	prefetchit0 -0xe7954(%rip)        # 144a03 <_ZNSt7__cxx1119basic_ostringstreamIcSt11char_traitsIcESaIcEEC1Ev@@GLIBCXX_3.4.26+0xb3>
  22c357:	e9 b4 5e e7 ff                                  	jmp    a2210 <_ZSt9has_facetISt5ctypeIcEEbRKSt6locale@plt>
  22c35c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  22c360:	0f 18 3d 29 0d f1 ff                            	prefetchit0 -0xef2d7(%rip)        # 13d090 <_ZNSo9_M_insertIlEERSoT_@@GLIBCXX_3.4.9>
  22c367:	e9 e4 21 e7 ff                                  	jmp    9e550 <_ZSt9use_facetISt5ctypeIcEERKT_RKSt6locale@plt>
  22c36c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  22c370:	0f 18 3d 89 1c ef ff                            	prefetchit0 -0x10e377(%rip)        # 11e000 <_ZNSt9basic_iosIcSt11char_traitsIcEE4initEPSt15basic_streambufIcS1_E@@GLIBCXX_3.4+0x40>
  22c377:	e9 14 35 e7 ff                                  	jmp    9f890 <_ZSt9use_facetISt7num_getIcSt19istreambuf_iteratorIcSt11char_traitsIcEEEERKT_RKSt6locale@plt>
  22c37c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  22c380:	0f 18 3d fc 37 e9 ff                            	prefetchit0 -0x16c804(%rip)        # bfb83 <_ZNSt8ios_base7_M_initEv@@GLIBCXX_3.4+0x23>
  22c387:	e9 b4 52 e7 ff                                  	jmp    a1640 <_ZNSt8ios_base7_M_initEv@plt>
  22c38c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  22c390:	0f 18 3d 49 bf ef ff                            	prefetchit0 -0x1040b7(%rip)        # 1282e0 <_ZSt9use_facetISt7num_getIcSt19istreambuf_iteratorIcSt11char_traitsIcEEEERKT_RKSt6locale@@GLIBCXX_3.4>
  22c397:	0f 18 3d 12 26 e7 ff                            	prefetchit0 -0x18d9ee(%rip)        # 9e9b0 <_ZSt9use_facetISt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEEERKT_RKSt6locale@plt>
  22c39e:	0f 18 3d 6b bf ef ff                            	prefetchit0 -0x104095(%rip)        # 128310 <_ZSt9use_facetISt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEEERKT_RKSt6locale@@GLIBCXX_3.4>
  22c3a5:	0f 18 3d a4 bf ef ff                            	prefetchit0 -0x10405c(%rip)        # 128350 <_ZSt9has_facetISt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEEEbRKSt6locale@@GLIBCXX_3.4>
  22c3ac:	0f 18 3d ad 20 e7 ff                            	prefetchit0 -0x18df53(%rip)        # 9e460 <_ZSt9has_facetISt7num_getIcSt19istreambuf_iteratorIcSt11char_traitsIcEEEEbRKSt6locale@plt>
  22c3b3:	0f 18 3d f6 4d e7 ff                            	prefetchit0 -0x18b20a(%rip)        # a11b0 <_ZSt9has_facetISt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEEEbRKSt6locale@plt>
  22c3ba:	e9 41 54 e7 ff                                  	jmp    a1800 <_ZNSt9basic_iosIcSt11char_traitsIcEE15_M_cache_localeERKSt6locale@plt>
  22c3bf:	90                                              	nop
  22c3c0:	0f 18 3d fa 0c f1 ff                            	prefetchit0 -0xef306(%rip)        # 13d0c1 <_ZNSo9_M_insertIlEERSoT_@@GLIBCXX_3.4.9+0x31>
  22c3c7:	e9 e4 32 e7 ff                                  	jmp    9f6b0 <_ZNKSt6locale2id5_M_idEv@plt>
  22c3cc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  22c3d0:	0f 18 3d 99 66 f1 ff                            	prefetchit0 -0xe9967(%rip)        # 142a70 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8overflowEi@@GLIBCXX_3.4.21+0x1f0>
  22c3d7:	0f 18 3d a4 66 f1 ff                            	prefetchit0 -0xe995c(%rip)        # 142a82 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8overflowEi@@GLIBCXX_3.4.21+0x202>
  22c3de:	e9 cd 32 e7 ff                                  	jmp    9f6b0 <_ZNKSt6locale2id5_M_idEv@plt>
  22c3e3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  22c3ed:	0f 1f 00                                        	nopl   (%rax)
  22c3f0:	0f 18 3d 0b e4 f1 ff                            	prefetchit0 -0xe1bf5(%rip)        # 14a802 <_ZNSt15basic_streambufIcSt11char_traitsIcEE6xsputnEPKcl@@GLIBCXX_3.4+0x12>
  22c3f7:	0f 18 3d f2 e3 f1 ff                            	prefetchit0 -0xe1c0e(%rip)        # 14a7f0 <_ZNSt15basic_streambufIcSt11char_traitsIcEE6xsputnEPKcl@@GLIBCXX_3.4>
  22c3fe:	0f 18 3d d3 66 f1 ff                            	prefetchit0 -0xe992d(%rip)        # 142ad8 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8overflowEi@@GLIBCXX_3.4.21+0x258>
  22c405:	0f 18 3d 74 64 f1 ff                            	prefetchit0 -0xe9b8c(%rip)        # 142880 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8overflowEi@@GLIBCXX_3.4.21>
  22c40c:	0f 18 3d af 64 f1 ff                            	prefetchit0 -0xe9b51(%rip)        # 1428c2 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8overflowEi@@GLIBCXX_3.4.21+0x42>
  22c413:	0f 18 3d d6 24 f0 ff                            	prefetchit0 -0xfdb2a(%rip)        # 12e8f0 <_ZNKSt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEE6do_putES3_RSt8ios_basece@@GLIBCXX_3.4+0x20>
  22c41a:	e9 21 ee ef ff                                  	jmp    12b240 <_ZNSt16__numpunct_cacheIcE8_M_cacheERKSt6locale@@GLIBCXX_3.4+0x4f0>
  22c41f:	90                                              	nop
  22c420:	0f 18 3d 69 3a e7 ff                            	prefetchit0 -0x18c597(%rip)        # 9fe90 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8_M_pbumpEPcS5_l@plt>
  22c427:	e9 c4 24 f0 ff                                  	jmp    12e8f0 <_ZNKSt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEE6do_putES3_RSt8ios_basece@@GLIBCXX_3.4+0x20>
  22c42c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  22c430:	0f 18 3d c9 05 f1 ff                            	prefetchit0 -0xefa37(%rip)        # 13ca00 <_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l@@GLIBCXX_3.4.9+0x30>
  22c437:	0f 18 3d 92 05 f1 ff                            	prefetchit0 -0xefa6e(%rip)        # 13c9d0 <_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l@@GLIBCXX_3.4.9>
  22c43e:	e9 4d 3a e7 ff                                  	jmp    9fe90 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8_M_pbumpEPcS5_l@plt>
  22c443:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  22c44d:	0f 1f 00                                        	nopl   (%rax)
  22c450:	0f 18 3d 29 5e f1 ff                            	prefetchit0 -0xea1d7(%rip)        # 142280 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8_M_pbumpEPcS5_l@@GLIBCXX_3.4.21>
  22c457:	0f 18 3d 82 02 f2 ff                            	prefetchit0 -0xdfd7e(%rip)        # 14c6e0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7reserveEm@@GLIBCXX_3.4.21>
  22c45e:	0f 18 3d ab 56 e7 ff                            	prefetchit0 -0x18a955(%rip)        # a1b10 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7reserveEm@plt>
  22c465:	0f 18 3d 94 05 f1 ff                            	prefetchit0 -0xefa6c(%rip)        # 13ca00 <_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l@@GLIBCXX_3.4.9+0x30>
  22c46c:	e9 1f 3a e7 ff                                  	jmp    9fe90 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8_M_pbumpEPcS5_l@plt>
  22c471:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  22c47b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  22c480:	0f 18 3d 39 1b ef ff                            	prefetchit0 -0x10e4c7(%rip)        # 11dfc0 <_ZNSt9basic_iosIcSt11char_traitsIcEE4initEPSt15basic_streambufIcS1_E@@GLIBCXX_3.4>
  22c487:	0f 18 3d 12 51 e7 ff                            	prefetchit0 -0x18aeee(%rip)        # a15a0 <_ZNSt9basic_iosIcSt11char_traitsIcEE4initEPSt15basic_streambufIcS1_E@plt>
  22c48e:	0f 18 3d 8b 5e e9 ff                            	prefetchit0 -0x16a175(%rip)        # c2320 <_ZNSt6locale5_ImplC1Em@@GLIBCXX_3.4+0xe90>
  22c495:	0f 18 3d f4 5e e9 ff                            	prefetchit0 -0x16a10c(%rip)        # c2390 <_ZNSt6localeC1Ev@@GLIBCXX_3.4>
  22c49c:	0f 18 3d 5f e2 ea ff                            	prefetchit0 -0x151da1(%rip)        # da702 <_ZNSt8ios_baseC1Ev@@GLIBCXX_3.4+0x22>
  22c4a3:	0f 18 3d 36 e2 ea ff                            	prefetchit0 -0x151dca(%rip)        # da6e0 <_ZNSt8ios_baseC1Ev@@GLIBCXX_3.4>
  22c4aa:	0f 18 3d 7f 31 e7 ff                            	prefetchit0 -0x18ce81(%rip)        # 9f630 <pthread_once@plt>
  22c4b1:	0f 18 3d a8 36 e9 ff                            	prefetchit0 -0x16c958(%rip)        # bfb60 <_ZNSt8ios_base7_M_initEv@@GLIBCXX_3.4>
  22c4b8:	e9 f3 2c e7 ff                                  	jmp    9f1b0 <_ZNSt8ios_baseC2Ev@plt>
  22c4bd:	0f 1f 00                                        	nopl   (%rax)
  22c4c0:	0f 18 3d 19 45 e9 ff                            	prefetchit0 -0x16bae7(%rip)        # c09e0 <_ZNSt6localeaSERKS_@@GLIBCXX_3.4>
  22c4c7:	0f 18 3d 82 20 e7 ff                            	prefetchit0 -0x18df7e(%rip)        # 9e550 <_ZSt9use_facetISt5ctypeIcEERKT_RKSt6locale@plt>
  22c4ce:	0f 18 3d 2b 45 e9 ff                            	prefetchit0 -0x16bad5(%rip)        # c0a00 <_ZNSt6localeaSERKS_@@GLIBCXX_3.4+0x20>
  22c4d5:	0f 18 3d a4 43 e7 ff                            	prefetchit0 -0x18bc5c(%rip)        # a0880 <_ZNSt6localeaSERKS_@plt>
  22c4dc:	0f 18 3d 3d e1 ef ff                            	prefetchit0 -0x101ec3(%rip)        # 12a620 <_ZSt9use_facetISt5ctypeIcEERKT_RKSt6locale@@GLIBCXX_3.4>
  22c4e3:	0f 18 3d 66 48 e7 ff                            	prefetchit0 -0x18b79a(%rip)        # a0d50 <_ZNSt6localeD1Ev@plt>
  22c4ea:	0f 18 3d 4f 19 ef ff                            	prefetchit0 -0x10e6b1(%rip)        # 11de40 <_ZNSt9basic_iosIcSt11char_traitsIcEE15_M_cache_localeERKSt6locale@@GLIBCXX_3.4>
  22c4f1:	0f 18 3d c8 fd ef ff                            	prefetchit0 -0x100238(%rip)        # 12c2c0 <_ZSt9has_facetISt5ctypeIcEEbRKSt6locale@@GLIBCXX_3.4>
  22c4f8:	e9 a3 50 e7 ff                                  	jmp    a15a0 <_ZNSt9basic_iosIcSt11char_traitsIcEE4initEPSt15basic_streambufIcS1_E@plt>
  22c4fd:	0f 1f 00                                        	nopl   (%rax)
  22c500:	0f 18 3d 89 60 f1 ff                            	prefetchit0 -0xe9f77(%rip)        # 142590 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE7_M_syncEPcmm@@GLIBCXX_3.4.21>
  22c507:	0f 18 3d b4 60 f1 ff                            	prefetchit0 -0xe9f4c(%rip)        # 1425c2 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE7_M_syncEPcmm@@GLIBCXX_3.4.21+0x32>
  22c50e:	e9 cd 41 e7 ff                                  	jmp    a06e0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@plt>
  22c513:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  22c51d:	0f 1f 00                                        	nopl   (%rax)
  22c520:	0f 18 3d e9 f6 f1 ff                            	prefetchit0 -0xe0917(%rip)        # 14bc10 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@@GLIBCXX_3.4.21>
  22c527:	e9 b4 41 e7 ff                                  	jmp    a06e0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@plt>
  22c52c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  22c530:	0f 18 3d e9 55 ef ff                            	prefetchit0 -0x10aa17(%rip)        # 121b20 <_ZNSi7putbackEc@@GLIBCXX_3.4>
  22c537:	e9 b4 5b e7 ff                                  	jmp    a20f0 <memcpy@plt>
  22c53c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  22c540:	41 53                                           	push   %r11
  22c542:	4c 8b 1d d7 b3 ff ff                            	mov    -0x4c29(%rip),%r11        # 227920 <memcmp@GLIBC_2.2.5>
  22c549:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  22c551:	41 5b                                           	pop    %r11
  22c553:	e9 78 45 e7 ff                                  	jmp    a0ad0 <memmove@plt>
  22c558:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  22c560:	0f 18 3d 79 41 e7 ff                            	prefetchit0 -0x18be87(%rip)        # a06e0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@plt>
  22c567:	0f 18 3d e2 fa f1 ff                            	prefetchit0 -0xe051e(%rip)        # 14c050 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm@@GLIBCXX_3.4.21>
  22c56e:	0f 18 3d 0f fb f1 ff                            	prefetchit0 -0xe04f1(%rip)        # 14c084 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm@@GLIBCXX_3.4.21+0x34>
  22c575:	0f 18 3d f4 23 e8 ff                            	prefetchit0 -0x17dc0c(%rip)        # ae970 <_Znwm@@GLIBCXX_3.4>
  22c57c:	0f 18 3d 8d f6 f1 ff                            	prefetchit0 -0xe0973(%rip)        # 14bc10 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@@GLIBCXX_3.4.21>
  22c583:	0f 18 3d 16 26 e7 ff                            	prefetchit0 -0x18d9ea(%rip)        # 9eba0 <_Znwm@plt>
  22c58a:	e9 41 5a e7 ff                                  	jmp    a1fd0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm@plt>
  22c58f:	90                                              	nop
  22c590:	41 53                                           	push   %r11
  22c592:	4c 8b 1d df a6 ff ff                            	mov    -0x5921(%rip),%r11        # 226c78 <strlen@GLIBC_2.2.5>
  22c599:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  22c5a1:	41 5b                                           	pop    %r11
  22c5a3:	e9 08 36 e7 ff                                  	jmp    9fbb0 <strlen@plt>
