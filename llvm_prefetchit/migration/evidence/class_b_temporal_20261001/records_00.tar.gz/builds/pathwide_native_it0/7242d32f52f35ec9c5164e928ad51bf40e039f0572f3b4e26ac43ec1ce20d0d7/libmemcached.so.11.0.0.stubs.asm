
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_native_it0/7242d32f52f35ec9c5164e928ad51bf40e039f0572f3b4e26ac43ec1ce20d0d7/libmemcached.so.11.0.0:     file format elf64-x86-64


Disassembly of section .text.prefetch_calls:

00000000000312c0 <.text.prefetch_calls>:
   312c0:	0f 18 3d a9 5c fd ff                            	prefetchit0 -0x2a357(%rip)        # 6f70 <close@plt+0x16e0>
   312c7:	0f 18 3d e2 44 fe ff                            	prefetchit0 -0x1bb1e(%rip)        # 157b0 <memcached_server_response_count@@Base+0x440>
   312ce:	0f 18 3d db e8 fd ff                            	prefetchit0 -0x21725(%rip)        # fbb0 <memcached_fetch@@Base>
   312d5:	0f 18 3d 25 e9 fd ff                            	prefetchit0 -0x216db(%rip)        # fc01 <memcached_fetch@@Base+0x51>
   312dc:	0f 18 3d dd e8 fd ff                            	prefetchit0 -0x21723(%rip)        # fbc0 <memcached_fetch@@Base+0x10>
   312e3:	0f 18 3d dc 44 fe ff                            	prefetchit0 -0x1bb24(%rip)        # 157c6 <memcached_server_response_count@@Base+0x456>
   312ea:	e9 81 41 fd ff                                  	jmp    5470 <__errno_location@plt>
   312ef:	90                                              	nop
   312f0:	0f 18 3d e9 a9 fd ff                            	prefetchit0 -0x25617(%rip)        # bce0 <memcached_callback_set@@Base+0x980>
   312f7:	0f 18 3d 32 a4 fd ff                            	prefetchit0 -0x25bce(%rip)        # b730 <memcached_callback_set@@Base+0x3d0>
   312fe:	0f 18 3d 6b 41 fd ff                            	prefetchit0 -0x2be95(%rip)        # 5470 <__errno_location@plt>
   31305:	0f 18 3d 64 40 fe ff                            	prefetchit0 -0x1bf9c(%rip)        # 15370 <memcached_server_response_count@@Base>
   3130c:	e9 ff 42 fd ff                                  	jmp    5610 <memcpy@plt>
   31311:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   3131b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
   31320:	0f 18 3d 9e a6 fd ff                            	prefetchit0 -0x25962(%rip)        # b9c5 <memcached_callback_set@@Base+0x665>
   31327:	0f 18 3d e2 42 fd ff                            	prefetchit0 -0x2bd1e(%rip)        # 5610 <memcpy@plt>
   3132e:	0f 18 3d 2b a6 fd ff                            	prefetchit0 -0x259d5(%rip)        # b960 <memcached_callback_set@@Base+0x600>
   31335:	e9 26 d5 fe ff                                  	jmp    1e860 <memcached_verbosity@@Base+0x920>
   3133a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   31340:	0f 18 3d 29 41 fd ff                            	prefetchit0 -0x2bed7(%rip)        # 5470 <__errno_location@plt>
   31347:	e9 14 a6 fd ff                                  	jmp    b960 <memcached_callback_set@@Base+0x600>
   3134c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   31350:	0f 18 3d 19 f6 fd ff                            	prefetchit0 -0x209e7(%rip)        # 10970 <memcached_increment@@Base>
   31357:	0f 18 3d 5a 2d fe ff                            	prefetchit0 -0x1d2a6(%rip)        # 140b8 <memcached_result_length@@Base+0x248>
   3135e:	0f 18 3d fb 7b fe ff                            	prefetchit0 -0x18405(%rip)        # 18f60 <memcached_stat_execute@@Base+0x560>
   31365:	0f 18 3d 10 7a fe ff                            	prefetchit0 -0x185f0(%rip)        # 18d7c <memcached_stat_execute@@Base+0x37c>
   3136c:	0f 18 3d 05 b4 fd ff                            	prefetchit0 -0x24bfb(%rip)        # c778 <memcached_flush_buffers@@Base+0x288>
   31373:	0f 18 3d 06 f6 fd ff                            	prefetchit0 -0x209fa(%rip)        # 10980 <memcached_increment@@Base+0x10>
   3137a:	0f 18 3d 56 2b fe ff                            	prefetchit0 -0x1d4aa(%rip)        # 13ed7 <memcached_result_length@@Base+0x67>
   31381:	0f 18 3d ff 79 fe ff                            	prefetchit0 -0x18601(%rip)        # 18d87 <memcached_stat_execute@@Base+0x387>
   31388:	e9 83 42 fd ff                                  	jmp    5610 <memcpy@plt>
   3138d:	0f 1f 00                                        	nopl   (%rax)
   31390:	0f 18 3d ea 26 fe ff                            	prefetchit0 -0x1d916(%rip)        # 13a81 <memcached_result_reset@@Base+0x801>
   31397:	0f 18 3d 6a b2 fd ff                            	prefetchit0 -0x24d96(%rip)        # c608 <memcached_flush_buffers@@Base+0x118>
   3139e:	0f 18 3d 5d 1f fe ff                            	prefetchit0 -0x1e0a3(%rip)        # 13302 <memcached_result_reset@@Base+0x82>
   313a5:	0f 18 3d d4 1f fe ff                            	prefetchit0 -0x1e02c(%rip)        # 13380 <memcached_result_reset@@Base+0x100>
   313ac:	e9 2f 41 fd ff                                  	jmp    54e0 <recv@plt>
   313b1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   313bb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
   313c0:	0f 18 3d cf 5b fd ff                            	prefetchit0 -0x2a431(%rip)        # 6f96 <close@plt+0x1706>
   313c7:	0f 18 3d f3 5b fd ff                            	prefetchit0 -0x2a40d(%rip)        # 6fc1 <close@plt+0x1731>
   313ce:	0f 18 3d 36 f5 fd ff                            	prefetchit0 -0x20aca(%rip)        # 1090b <memcached_reset@@Base+0x30b>
   313d5:	e9 e6 b1 fd ff                                  	jmp    c5c0 <memcached_flush_buffers@@Base+0xd0>
   313da:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   313e0:	0f 18 3d 1d a6 fd ff                            	prefetchit0 -0x259e3(%rip)        # ba04 <memcached_callback_set@@Base+0x6a4>
   313e7:	e9 04 3e fe ff                                  	jmp    151f0 <memcached_server_count@@Base>
   313ec:	0f 1f 40 00                                     	nopl   0x0(%rax)
   313f0:	0f 18 3d b5 d7 fd ff                            	prefetchit0 -0x2284b(%rip)        # ebac <memcached_server_by_key@@Base+0x5ac>
   313f7:	0f 18 3d 21 e1 fd ff                            	prefetchit0 -0x21edf(%rip)        # f51f <memcached_server_by_key@@Base+0xf1f>
   313fe:	e9 4d d0 fd ff                                  	jmp    e450 <memcached_server_add@@Base+0x10>
   31403:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   3140d:	0f 1f 00                                        	nopl   (%rax)
   31410:	0f 18 3d 08 e1 fd ff                            	prefetchit0 -0x21ef8(%rip)        # f51f <memcached_server_by_key@@Base+0xf1f>
   31417:	0f 18 3d 32 ca fd ff                            	prefetchit0 -0x235ce(%rip)        # de50 <memcached_bucket_set@@Base+0x120>
   3141e:	0f 18 3d 5c d4 fe ff                            	prefetchit0 -0x12ba4(%rip)        # 1e881 <memcached_verbosity@@Base+0x941>
   31425:	0f 18 3d 34 d4 fe ff                            	prefetchit0 -0x12bcc(%rip)        # 1e860 <memcached_verbosity@@Base+0x920>
   3142c:	0f 18 3d 50 83 fd ff                            	prefetchit0 -0x27cb0(%rip)        # 9783 <memcached_analyze@@Base+0x203>
   31433:	e9 18 d0 fd ff                                  	jmp    e450 <memcached_server_add@@Base+0x10>
   31438:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   31440:	0f 18 3d 29 e0 fd ff                            	prefetchit0 -0x21fd7(%rip)        # f470 <memcached_server_by_key@@Base+0xe70>
   31447:	0f 18 3d c2 41 fd ff                            	prefetchit0 -0x2be3e(%rip)        # 5610 <memcpy@plt>
   3144e:	0f 18 3d 82 e0 fd ff                            	prefetchit0 -0x21f7e(%rip)        # f4d7 <memcached_server_by_key@@Base+0xed7>
   31455:	e9 06 d4 fe ff                                  	jmp    1e860 <memcached_verbosity@@Base+0x920>
   3145a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   31460:	0f 18 3d d0 de fd ff                            	prefetchit0 -0x22130(%rip)        # f337 <memcached_server_by_key@@Base+0xd37>
   31467:	0f 18 3d fa de fd ff                            	prefetchit0 -0x22106(%rip)        # f368 <memcached_server_by_key@@Base+0xd68>
   3146e:	e9 ed a4 fd ff                                  	jmp    b960 <memcached_callback_set@@Base+0x600>
   31473:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   3147d:	0f 1f 00                                        	nopl   (%rax)
   31480:	0f 18 3d f9 e4 fd ff                            	prefetchit0 -0x21b07(%rip)        # f980 <memcached_fetch_result@@Base>
   31487:	0f 18 3d 32 e5 fd ff                            	prefetchit0 -0x21ace(%rip)        # f9c0 <memcached_fetch_result@@Base+0x40>
   3148e:	0f 18 3d 1b e7 fd ff                            	prefetchit0 -0x218e5(%rip)        # fbb0 <memcached_fetch@@Base>
   31495:	0f 18 3d 65 e7 fd ff                            	prefetchit0 -0x2189b(%rip)        # fc01 <memcached_fetch@@Base+0x51>
   3149c:	e9 4f 3d fe ff                                  	jmp    151f0 <memcached_server_count@@Base>
   314a1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   314ab:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
   314b0:	0f 18 3d 20 e0 fd ff                            	prefetchit0 -0x21fe0(%rip)        # f4d7 <memcached_server_by_key@@Base+0xed7>
   314b7:	e9 94 c9 fd ff                                  	jmp    de50 <memcached_bucket_set@@Base+0x120>
   314bc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   314c0:	0f 18 3d 49 3b fe ff                            	prefetchit0 -0x1c4b7(%rip)        # 15010 <memcached_result_take_value@@Base+0x80>
   314c7:	0f 18 3d 7a 1b fe ff                            	prefetchit0 -0x1e486(%rip)        # 13048 <memcached_set_encoding_key@@Base+0x628>
   314ce:	0f 18 3d 5b 1b fe ff                            	prefetchit0 -0x1e4a5(%rip)        # 13030 <memcached_set_encoding_key@@Base+0x610>
   314d5:	41 53                                           	push   %r11
   314d7:	4c 8b 1d 9a eb ff ff                            	mov    -0x1466(%rip),%r11        # 30078 <strncpy@GLIBC_2.2.5>
   314de:	41 0f 18 93 1a 03 00 00                         	prefetcht1 0x31a(%r11)
   314e6:	41 0f 18 93 ed 04 00 00                         	prefetcht1 0x4ed(%r11)
   314ee:	41 0f 18 93 23 05 00 00                         	prefetcht1 0x523(%r11)
   314f6:	41 0f 18 93 00 07 00 00                         	prefetcht1 0x700(%r11)
   314fe:	41 5b                                           	pop    %r11
   31500:	e9 2b 40 fd ff                                  	jmp    5530 <strncpy@plt>
   31505:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   3150f:	90                                              	nop
   31510:	0f 18 3d 39 cf fd ff                            	prefetchit0 -0x230c7(%rip)        # e450 <memcached_server_add@@Base+0x10>
   31517:	0f 18 3d b0 76 fe ff                            	prefetchit0 -0x18950(%rip)        # 18bce <memcached_stat_execute@@Base+0x1ce>
   3151e:	0f 18 3d 5e cf fd ff                            	prefetchit0 -0x230a2(%rip)        # e483 <memcached_server_add@@Base+0x43>
   31525:	0f 18 3d 3e 77 fe ff                            	prefetchit0 -0x188c2(%rip)        # 18c6a <memcached_stat_execute@@Base+0x26a>
   3152c:	0f 18 3d 2a d0 fd ff                            	prefetchit0 -0x22fd6(%rip)        # e55d <memcached_server_add@@Base+0x11d>
   31533:	e9 48 1d fe ff                                  	jmp    13280 <memcached_result_reset@@Base>
   31538:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   31540:	0f 18 3d 3a aa fd ff                            	prefetchit0 -0x255c6(%rip)        # bf81 <memcached_callback_set@@Base+0xc21>
   31547:	0f 18 3d e2 a9 fd ff                            	prefetchit0 -0x2561e(%rip)        # bf30 <memcached_callback_set@@Base+0xbd0>
   3154e:	0f 18 3d 70 f3 fd ff                            	prefetchit0 -0x20c90(%rip)        # 108c5 <memcached_reset@@Base+0x2c5>
   31555:	0f 18 3d e5 a9 fd ff                            	prefetchit0 -0x2561b(%rip)        # bf41 <memcached_callback_set@@Base+0xbe1>
   3155c:	e9 ef ce fd ff                                  	jmp    e450 <memcached_server_add@@Base+0x10>
   31561:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   3156b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
   31570:	0f 18 3d d9 52 fe ff                            	prefetchit0 -0x1ad27(%rip)        # 16850 <memcached_server_response_count@@Base+0x14e0>
   31577:	0f 18 3d 04 53 fe ff                            	prefetchit0 -0x1acfc(%rip)        # 16882 <memcached_server_response_count@@Base+0x1512>
   3157e:	e9 ed 59 fd ff                                  	jmp    6f70 <close@plt+0x16e0>
   31583:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   3158d:	0f 1f 00                                        	nopl   (%rax)
   31590:	0f 18 3d f9 f0 fd ff                            	prefetchit0 -0x20f07(%rip)        # 10690 <memcached_reset@@Base+0x90>
   31597:	e9 d4 f1 fd ff                                  	jmp    10770 <memcached_reset@@Base+0x170>
   3159c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   315a0:	0f 18 3d 9b d1 fd ff                            	prefetchit0 -0x22e65(%rip)        # e742 <memcached_server_by_key@@Base+0x142>
   315a7:	0f 18 3d 42 d1 fd ff                            	prefetchit0 -0x22ebe(%rip)        # e6f0 <memcached_server_by_key@@Base+0xf0>
   315ae:	0f 18 3d cb 1c fe ff                            	prefetchit0 -0x1e335(%rip)        # 13280 <memcached_result_reset@@Base>
   315b5:	0f 18 3d 48 d1 fd ff                            	prefetchit0 -0x22eb8(%rip)        # e704 <memcached_server_by_key@@Base+0x104>
   315bc:	0f 18 3d c0 ce fd ff                            	prefetchit0 -0x23140(%rip)        # e483 <memcached_server_add@@Base+0x43>
   315c3:	e9 c8 f0 fd ff                                  	jmp    10690 <memcached_reset@@Base+0x90>
   315c8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   315d0:	0f 18 3d a9 6c fe ff                            	prefetchit0 -0x19357(%rip)        # 18280 <memcached_lib_version@@Base+0x10>
   315d7:	0f 18 3d a2 e3 fd ff                            	prefetchit0 -0x21c5e(%rip)        # f980 <memcached_fetch_result@@Base>
   315de:	0f 18 3d db e3 fd ff                            	prefetchit0 -0x21c25(%rip)        # f9c0 <memcached_fetch_result@@Base+0x40>
   315e5:	e9 c6 e5 fd ff                                  	jmp    fbb0 <memcached_fetch@@Base>
   315ea:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   315f0:	0f 18 3d 99 f0 fd ff                            	prefetchit0 -0x20f67(%rip)        # 10690 <memcached_reset@@Base+0x90>
   315f7:	e9 34 04 fe ff                                  	jmp    11a30 <memcached_get_by_key@@Base>
   315fc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   31600:	41 53                                           	push   %r11
   31602:	4c 8b 1d 1f ec ff ff                            	mov    -0x13e1(%rip),%r11        # 30228 <close@GLIBC_2.2.5>
   31609:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   31611:	41 5b                                           	pop    %r11
   31613:	e9 38 41 fd ff                                  	jmp    5750 <shutdown@plt>
   31618:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   31620:	0f 18 3d d9 94 fd ff                            	prefetchit0 -0x26b27(%rip)        # ab00 <memcached_behavior_set_distribution_hash@@Base+0x750>
   31627:	0f 18 3d 16 95 fd ff                            	prefetchit0 -0x26aea(%rip)        # ab44 <memcached_behavior_set_distribution_hash@@Base+0x794>
   3162e:	0f 18 3d 97 b1 fd ff                            	prefetchit0 -0x24e69(%rip)        # c7cc <memcached_flush_buffers@@Base+0x2dc>
   31635:	e9 46 b2 fd ff                                  	jmp    c880 <memcached_flush_buffers@@Base+0x390>
   3163a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   31640:	0f 18 3d 90 28 fe ff                            	prefetchit0 -0x1d770(%rip)        # 13ed7 <memcached_result_length@@Base+0x67>
   31647:	0f 18 3d 74 23 fe ff                            	prefetchit0 -0x1dc8c(%rip)        # 139c2 <memcached_result_reset@@Base+0x742>
   3164e:	0f 18 3d 27 77 fe ff                            	prefetchit0 -0x188d9(%rip)        # 18d7c <memcached_stat_execute@@Base+0x37c>
   31655:	0f 18 3d 2b 77 fe ff                            	prefetchit0 -0x188d5(%rip)        # 18d87 <memcached_stat_execute@@Base+0x387>
   3165c:	0f 18 3d fd 78 fe ff                            	prefetchit0 -0x18703(%rip)        # 18f60 <memcached_stat_execute@@Base+0x560>
   31663:	0f 18 3d 18 7c fe ff                            	prefetchit0 -0x183e8(%rip)        # 19282 <memcached_stat_execute@@Base+0x882>
   3166a:	e9 11 b2 fd ff                                  	jmp    c880 <memcached_flush_buffers@@Base+0x390>
   3166f:	90                                              	nop
   31670:	0f 18 3d 49 af fd ff                            	prefetchit0 -0x250b7(%rip)        # c5c0 <memcached_flush_buffers@@Base+0xd0>
   31677:	e9 04 1c fe ff                                  	jmp    13280 <memcached_result_reset@@Base>
   3167c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   31680:	0f 18 3d 49 54 fd ff                            	prefetchit0 -0x2abb7(%rip)        # 6ad0 <close@plt+0x1240>
   31687:	0f 18 3d 93 24 fe ff                            	prefetchit0 -0x1db6d(%rip)        # 13b21 <memcached_result_reset@@Base+0x8a1>
   3168e:	41 53                                           	push   %r11
   31690:	4c 8b 1d 49 eb ff ff                            	mov    -0x14b7(%rip),%r11        # 301e0 <realloc@GLIBC_2.2.5>
   31697:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   3169f:	41 5b                                           	pop    %r11
   316a1:	e9 da b1 fd ff                                  	jmp    c880 <memcached_flush_buffers@@Base+0x390>
   316a6:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   316b0:	0f 18 3d 79 19 fe ff                            	prefetchit0 -0x1e687(%rip)        # 13030 <memcached_set_encoding_key@@Base+0x610>
   316b7:	0f 18 3d 52 39 fe ff                            	prefetchit0 -0x1c6ae(%rip)        # 15010 <memcached_result_take_value@@Base+0x80>
   316be:	0f 18 3d bf 19 fe ff                            	prefetchit0 -0x1e641(%rip)        # 13084 <memcached_set_encoding_key@@Base+0x664>
   316c5:	0f 18 3d 7c 19 fe ff                            	prefetchit0 -0x1e684(%rip)        # 13048 <memcached_set_encoding_key@@Base+0x628>
   316cc:	0f 18 3d e5 29 fe ff                            	prefetchit0 -0x1d61b(%rip)        # 140b8 <memcached_result_length@@Base+0x248>
   316d3:	0f 18 3d 3d e3 fd ff                            	prefetchit0 -0x21cc3(%rip)        # fa17 <memcached_fetch_result@@Base+0x97>
   316da:	41 53                                           	push   %r11
   316dc:	4c 8b 1d 95 e9 ff ff                            	mov    -0x166b(%rip),%r11        # 30078 <strncpy@GLIBC_2.2.5>
   316e3:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   316eb:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
   316f3:	41 5b                                           	pop    %r11
   316f5:	e9 86 b1 fd ff                                  	jmp    c880 <memcached_flush_buffers@@Base+0x390>
   316fa:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   31700:	0f 18 3d 51 59 fd ff                            	prefetchit0 -0x2a6af(%rip)        # 7058 <close@plt+0x17c8>
   31707:	0f 18 3d 88 51 fe ff                            	prefetchit0 -0x1ae78(%rip)        # 16896 <memcached_server_response_count@@Base+0x1526>
   3170e:	e9 6d b1 fd ff                                  	jmp    c880 <memcached_flush_buffers@@Base+0x390>
   31713:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   3171d:	0f 1f 00                                        	nopl   (%rax)
   31720:	0f 18 3d 5e 04 fe ff                            	prefetchit0 -0x1fba2(%rip)        # 11b85 <memcached_get_by_key@@Base+0x155>
   31727:	e9 04 19 fe ff                                  	jmp    13030 <memcached_set_encoding_key@@Base+0x610>
   3172c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   31730:	0f 18 3d 4e 3f fe ff                            	prefetchit0 -0x1c0b2(%rip)        # 15685 <memcached_server_response_count@@Base+0x315>
   31737:	0f 18 3d 84 27 fe ff                            	prefetchit0 -0x1d87c(%rip)        # 13ec2 <memcached_result_length@@Base+0x52>
   3173e:	e9 1d a2 fd ff                                  	jmp    b960 <memcached_callback_set@@Base+0x600>
   31743:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   3174d:	0f 1f 00                                        	nopl   (%rax)
   31750:	0f 18 3d 29 b1 fd ff                            	prefetchit0 -0x24ed7(%rip)        # c880 <memcached_flush_buffers@@Base+0x390>
   31757:	0f 18 3d 62 b1 fd ff                            	prefetchit0 -0x24e9e(%rip)        # c8c0 <memcached_flush_buffers@@Base+0x3d0>
   3175e:	0f 18 3d 1b 27 fe ff                            	prefetchit0 -0x1d8e5(%rip)        # 13e80 <memcached_result_length@@Base+0x10>
   31765:	0f 18 3d 54 ae fd ff                            	prefetchit0 -0x251ac(%rip)        # c5c0 <memcached_flush_buffers@@Base+0xd0>
   3176c:	e9 7f 3a fe ff                                  	jmp    151f0 <memcached_server_count@@Base>
   31771:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   3177b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
   31780:	0f 18 3d 39 ae fd ff                            	prefetchit0 -0x251c7(%rip)        # c5c0 <memcached_flush_buffers@@Base+0xd0>
   31787:	0f 18 3d f2 b0 fd ff                            	prefetchit0 -0x24f0e(%rip)        # c880 <memcached_flush_buffers@@Base+0x390>
   3178e:	0f 18 3d eb 26 fe ff                            	prefetchit0 -0x1d915(%rip)        # 13e80 <memcached_result_length@@Base+0x10>
   31795:	0f 18 3d 24 b1 fd ff                            	prefetchit0 -0x24edc(%rip)        # c8c0 <memcached_flush_buffers@@Base+0x3d0>
   3179c:	e9 0f 40 fe ff                                  	jmp    157b0 <memcached_server_response_count@@Base+0x440>
   317a1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   317ab:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
   317b0:	0f 18 3d 99 c6 fd ff                            	prefetchit0 -0x23967(%rip)        # de50 <memcached_bucket_set@@Base+0x120>
   317b7:	0f 18 3d c2 1a fe ff                            	prefetchit0 -0x1e53e(%rip)        # 13280 <memcached_result_reset@@Base>
   317be:	0f 18 3d a3 c7 fd ff                            	prefetchit0 -0x2385d(%rip)        # df68 <memcached_bucket_set@@Base+0x238>
   317c5:	0f 18 3d b7 7f fd ff                            	prefetchit0 -0x28049(%rip)        # 9783 <memcached_analyze@@Base+0x203>
   317cc:	0f 18 3d 9d 7f fd ff                            	prefetchit0 -0x28063(%rip)        # 9770 <memcached_analyze@@Base+0x1f0>
   317d3:	0f 18 3d 16 3a fe ff                            	prefetchit0 -0x1c5ea(%rip)        # 151f0 <memcached_server_count@@Base>
   317da:	0f 18 3d 1f 78 fe ff                            	prefetchit0 -0x187e1(%rip)        # 19000 <memcached_stat_execute@@Base+0x600>
   317e1:	e9 aa ee fd ff                                  	jmp    10690 <memcached_reset@@Base+0x90>
   317e6:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   317f0:	0f 18 3d c9 d0 fe ff                            	prefetchit0 -0x12f37(%rip)        # 1e8c0 <memcached_verbosity@@Base+0x980>
   317f7:	e9 54 cc fd ff                                  	jmp    e450 <memcached_server_add@@Base+0x10>
   317fc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   31800:	0f 18 3d 29 73 fe ff                            	prefetchit0 -0x18cd7(%rip)        # 18b30 <memcached_stat_execute@@Base+0x130>
   31807:	0f 18 3d 74 73 fe ff                            	prefetchit0 -0x18c8c(%rip)        # 18b82 <memcached_stat_execute@@Base+0x182>
   3180e:	0f 18 3d ab a2 fd ff                            	prefetchit0 -0x25d55(%rip)        # bac0 <memcached_callback_set@@Base+0x760>
   31815:	0f 18 3d 04 75 fe ff                            	prefetchit0 -0x18afc(%rip)        # 18d20 <memcached_stat_execute@@Base+0x320>
   3181c:	0f 18 3d 3d d0 fe ff                            	prefetchit0 -0x12fc3(%rip)        # 1e860 <memcached_verbosity@@Base+0x920>
   31823:	0f 18 3d 57 d0 fe ff                            	prefetchit0 -0x12fa9(%rip)        # 1e881 <memcached_verbosity@@Base+0x941>
   3182a:	0f 18 3d 11 73 fe ff                            	prefetchit0 -0x18cef(%rip)        # 18b42 <memcached_stat_execute@@Base+0x142>
   31831:	0f 18 3d 0a 75 fe ff                            	prefetchit0 -0x18af6(%rip)        # 18d42 <memcached_stat_execute@@Base+0x342>
   31838:	e9 13 c6 fd ff                                  	jmp    de50 <memcached_bucket_set@@Base+0x120>
   3183d:	0f 1f 00                                        	nopl   (%rax)
   31840:	0f 18 3d 49 ee fd ff                            	prefetchit0 -0x211b7(%rip)        # 10690 <memcached_reset@@Base+0x90>
   31847:	e9 a4 76 fe ff                                  	jmp    18ef0 <memcached_stat_execute@@Base+0x4f0>
   3184c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   31850:	0f 18 3d 51 d7 fe ff                            	prefetchit0 -0x128af(%rip)        # 1efa8 <memcached_verbosity@@Base+0x1068>
   31857:	0f 18 3d 12 d7 fe ff                            	prefetchit0 -0x128ee(%rip)        # 1ef70 <memcached_verbosity@@Base+0x1030>
   3185e:	0f 18 3d 61 d7 fe ff                            	prefetchit0 -0x1289f(%rip)        # 1efc6 <memcached_verbosity@@Base+0x1086>
   31865:	e9 76 3f fd ff                                  	jmp    57e0 <gettimeofday@plt>
   3186a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   31870:	0f 18 3d 0a d8 fe ff                            	prefetchit0 -0x127f6(%rip)        # 1f081 <memcached_verbosity@@Base+0x1141>
   31877:	0f 18 3d 92 e1 fe ff                            	prefetchit0 -0x11e6e(%rip)        # 1fa10 <memcached_verbosity@@Base+0x1ad0>
   3187e:	0f 18 3d d1 d7 fe ff                            	prefetchit0 -0x1282f(%rip)        # 1f056 <memcached_verbosity@@Base+0x1116>
   31885:	e9 e6 3b fd ff                                  	jmp    5470 <__errno_location@plt>
   3188a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   31890:	0f 18 3d ea a1 fd ff                            	prefetchit0 -0x25e16(%rip)        # ba81 <memcached_callback_set@@Base+0x721>
   31897:	e9 14 3f fd ff                                  	jmp    57b0 <poll@plt>
   3189c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   318a0:	41 53                                           	push   %r11
   318a2:	4c 8b 1d 47 e8 ff ff                            	mov    -0x17b9(%rip),%r11        # 300f0 <connect@GLIBC_2.2.5>
   318a9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   318b1:	41 5b                                           	pop    %r11
   318b3:	e9 88 3f fd ff                                  	jmp    5840 <setsockopt@plt>
