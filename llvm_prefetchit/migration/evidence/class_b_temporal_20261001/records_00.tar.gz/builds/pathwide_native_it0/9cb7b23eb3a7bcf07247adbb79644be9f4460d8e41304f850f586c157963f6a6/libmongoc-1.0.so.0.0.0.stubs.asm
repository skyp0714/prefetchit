
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_native_it0/9cb7b23eb3a7bcf07247adbb79644be9f4460d8e41304f850f586c157963f6a6/libmongoc-1.0.so.0.0.0:     file format elf64-x86-64


Disassembly of section .text.prefetch_calls:

00000000000a12c0 <.text.prefetch_calls>:
   a12c0:	0f 18 3d 3c 26 f9 ff                            	prefetchit0 -0x6d9c4(%rip)        # 33903 <_mongoc_collection_write_command_execute_idl+0x23>
   a12c7:	0f 18 3d a2 1d f9 ff                            	prefetchit0 -0x6e25e(%rip)        # 33070 <mongoc_cluster_stream_for_writes>
   a12ce:	0f 18 3d 0b 26 f9 ff                            	prefetchit0 -0x6d9f5(%rip)        # 338e0 <_mongoc_collection_write_command_execute_idl>
   a12d5:	0f 18 3d a4 1d f9 ff                            	prefetchit0 -0x6e25c(%rip)        # 33080 <mongoc_cluster_stream_for_writes+0x10>
   a12dc:	0f 18 3d 8d dd f8 ff                            	prefetchit0 -0x72273(%rip)        # 2f070 <_in_sharded_txn>
   a12e3:	0f 18 3d 5b 26 f9 ff                            	prefetchit0 -0x6d9a5(%rip)        # 33945 <_mongoc_collection_write_command_execute_idl+0x65>
   a12ea:	e9 e1 05 f8 ff                                  	jmp    218d0 <memcpy@plt>
   a12ef:	90                                              	nop
   a12f0:	0f 18 3d 19 d1 fb ff                            	prefetchit0 -0x42ee7(%rip)        # 5e410 <mongoc_stream_buffered_readv>
   a12f7:	0f 18 3d 12 55 fb ff                            	prefetchit0 -0x4aaee(%rip)        # 56810 <_mongoc_rpc_scatter>
   a12fe:	0f 18 3d 3c d1 fb ff                            	prefetchit0 -0x42ec4(%rip)        # 5e441 <mongoc_stream_buffered_readv+0x31>
   a1305:	0f 18 3d 36 55 fb ff                            	prefetchit0 -0x4aaca(%rip)        # 56842 <_mongoc_rpc_scatter+0x32>
   a130c:	0f 18 3d 6f 55 fb ff                            	prefetchit0 -0x4aa91(%rip)        # 56882 <_mongoc_rpc_scatter+0x72>
   a1313:	0f 18 3d e6 db fb ff                            	prefetchit0 -0x4241a(%rip)        # 5ef00 <mongoc_stream_readv>
   a131a:	0f 18 3d df 00 f8 ff                            	prefetchit0 -0x7ff21(%rip)        # 21400 <mongoc_stream_readv@plt>
   a1321:	0f 18 3d da 56 f8 ff                            	prefetchit0 -0x7a926(%rip)        # 26a02 <_mongoc_buffer_fill+0x12>
   a1328:	e9 93 ec f7 ff                                  	jmp    1ffc0 <mongoc_stream_read@plt>
   a132d:	0f 1f 00                                        	nopl   (%rax)
   a1330:	0f 18 3d f9 b0 fb ff                            	prefetchit0 -0x44f07(%rip)        # 5c430 <mongoc_set_add>
   a1337:	e9 14 24 f8 ff                                  	jmp    23750 <mongoc_set_add@plt>
   a133c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a1340:	0f 18 3d 69 24 fb ff                            	prefetchit0 -0x4db97(%rip)        # 537b0 <_mongoc_queue_pop_head>
   a1347:	0f 18 3d 72 24 fb ff                            	prefetchit0 -0x4db8e(%rip)        # 537c0 <_mongoc_queue_pop_head+0x10>
   a134e:	0f 18 3d 5b 1e f8 ff                            	prefetchit0 -0x7e1a5(%rip)        # 231b0 <_mongoc_topology_start_background_scanner@plt>
   a1355:	0f 18 3d 84 09 f8 ff                            	prefetchit0 -0x7f67c(%rip)        # 21ce0 <bson_free@plt>
   a135c:	0f 18 3d 8d 07 f8 ff                            	prefetchit0 -0x7f873(%rip)        # 21af0 <_mongoc_queue_pop_head@plt>
   a1363:	0f 18 3d 76 13 fc ff                            	prefetchit0 -0x3ec8a(%rip)        # 626e0 <_mongoc_topology_start_background_scanner>
   a136a:	41 53                                           	push   %r11
   a136c:	4c 8b 1d 85 db ff ff                            	mov    -0x247b(%rip),%r11        # 9eef8 <bson_free@Base>
   a1373:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a137b:	41 5b                                           	pop    %r11
   a137d:	e9 8e 19 f8 ff                                  	jmp    22d10 <pthread_mutex_lock@plt>
   a1382:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a138c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a1390:	0f 18 3d 49 a6 f8 ff                            	prefetchit0 -0x759b7(%rip)        # 2b9e0 <mongoc_client_get_collection>
   a1397:	0f 18 3d e2 24 f8 ff                            	prefetchit0 -0x7db1e(%rip)        # 23880 <bson_malloc0@plt>
   a139e:	0f 18 3d bb 2e f9 ff                            	prefetchit0 -0x6d145(%rip)        # 34260 <_mongoc_collection_new>
   a13a5:	41 53                                           	push   %r11
   a13a7:	4c 8b 1d f2 d7 ff ff                            	mov    -0x280e(%rip),%r11        # 9eba0 <pthread_mutex_unlock@GLIBC_2.2.5>
   a13ae:	41 0f 18 93 b0 ca 00 00                         	prefetcht1 0xcab0(%r11)
   a13b6:	41 0f 18 93 15 cb 00 00                         	prefetcht1 0xcb15(%r11)
   a13be:	41 0f 18 93 54 cb 00 00                         	prefetcht1 0xcb54(%r11)
   a13c6:	41 5b                                           	pop    %r11
   a13c8:	e9 e3 1d f8 ff                                  	jmp    231b0 <_mongoc_topology_start_background_scanner@plt>
   a13cd:	0f 1f 00                                        	nopl   (%rax)
   a13d0:	0f 18 3d 99 eb f7 ff                            	prefetchit0 -0x81467(%rip)        # 1ff70 <pthread_cond_signal@plt>
   a13d7:	0f 18 3d 32 22 fb ff                            	prefetchit0 -0x4ddce(%rip)        # 53610 <_mongoc_queue_push_head>
   a13de:	0f 18 3d eb f6 f7 ff                            	prefetchit0 -0x80915(%rip)        # 20ad0 <_mongoc_queue_push_head@plt>
   a13e5:	e9 26 19 f8 ff                                  	jmp    22d10 <pthread_mutex_lock@plt>
   a13ea:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a13f0:	0f 18 3d e3 87 f9 ff                            	prefetchit0 -0x6781d(%rip)        # 39bda <mongoc_collection_find_and_modify_with_opts+0x39a>
   a13f7:	0f 18 3d 22 12 fc ff                            	prefetchit0 -0x3edde(%rip)        # 62620 <_mongoc_topology_update_last_used>
   a13fe:	0f 18 3d 6b ec fc ff                            	prefetchit0 -0x31395(%rip)        # 70070 <_mongoc_write_error_get_type>
   a1405:	0f 18 3d 5e b0 f9 ff                            	prefetchit0 -0x64fa2(%rip)        # 3c46a <_mongoc_cursor_run_command+0x2ea>
   a140c:	0f 18 3d 4d b2 f9 ff                            	prefetchit0 -0x64db3(%rip)        # 3c660 <_mongoc_cursor_run_command+0x4e0>
   a1413:	0f 18 3d 3c f2 fc ff                            	prefetchit0 -0x30dc4(%rip)        # 70656 <_mongoc_write_opmsg+0x306>
   a141a:	0f 18 3d 26 f0 f8 ff                            	prefetchit0 -0x70fda(%rip)        # 30447 <mongoc_cluster_run_command_monitored+0x2c7>
   a1421:	0f 18 3d d8 fb f7 ff                            	prefetchit0 -0x80428(%rip)        # 21000 <_mongoc_topology_update_last_used@plt>
   a1428:	e9 f3 ff f7 ff                                  	jmp    21420 <_mongoc_client_session_in_txn_or_ending@plt>
   a142d:	0f 1f 00                                        	nopl   (%rax)
   a1430:	0f 18 3d 89 37 fb ff                            	prefetchit0 -0x4c877(%rip)        # 54bc0 <_mongoc_rpc_gather>
   a1437:	0f 18 3d c4 41 fb ff                            	prefetchit0 -0x4be3c(%rip)        # 55602 <_mongoc_rpc_gather+0xa42>
   a143e:	0f 18 3d 3c 3d f8 ff                            	prefetchit0 -0x7c2c4(%rip)        # 25181 <_mongoc_array_append_vals+0x31>
   a1445:	0f 18 3d 04 3d f8 ff                            	prefetchit0 -0x7c2fc(%rip)        # 25150 <_mongoc_array_append_vals>
   a144c:	0f 18 3d 9d 41 fb ff                            	prefetchit0 -0x4be63(%rip)        # 555f0 <_mongoc_rpc_gather+0xa30>
   a1453:	e9 78 f3 f7 ff                                  	jmp    207d0 <_mongoc_buffer_init@plt>
   a1458:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a1460:	0f 18 3d e9 e6 fa ff                            	prefetchit0 -0x51917(%rip)        # 4fb50 <mongoc_cmd_is_compressible>
   a1467:	0f 18 3d 15 e7 fa ff                            	prefetchit0 -0x518eb(%rip)        # 4fb83 <mongoc_cmd_is_compressible+0x33>
   a146e:	41 53                                           	push   %r11
   a1470:	4c 8b 1d 11 dc ff ff                            	mov    -0x23ef(%rip),%r11        # 9f088 <strcasecmp@GLIBC_2.2.5>
   a1477:	41 0f 18 93 00 0a 00 00                         	prefetcht1 0xa00(%r11)
   a147f:	41 0f 18 93 40 0f 00 00                         	prefetcht1 0xf40(%r11)
   a1487:	41 0f 18 93 51 0f 00 00                         	prefetcht1 0xf51(%r11)
   a148f:	41 0f 18 93 12 12 00 00                         	prefetcht1 0x1212(%r11)
   a1497:	41 0f 18 93 80 14 00 00                         	prefetcht1 0x1480(%r11)
   a149f:	41 0f 18 93 91 14 00 00                         	prefetcht1 0x1491(%r11)
   a14a7:	41 5b                                           	pop    %r11
   a14a9:	e9 42 02 f8 ff                                  	jmp    216f0 <_mongoc_rpc_swab_to_le@plt>
   a14ae:	66 90                                           	xchg   %ax,%ax
   a14b0:	41 53                                           	push   %r11
   a14b2:	4c 8b 1d cf db ff ff                            	mov    -0x2431(%rip),%r11        # 9f088 <strcasecmp@GLIBC_2.2.5>
   a14b9:	41 0f 18 93 d0 00 00 00                         	prefetcht1 0xd0(%r11)
   a14c1:	41 0f 18 93 11 0a 00 00                         	prefetcht1 0xa11(%r11)
   a14c9:	41 0f 18 93 e0 11 00 00                         	prefetcht1 0x11e0(%r11)
   a14d1:	41 5b                                           	pop    %r11
   a14d3:	e9 78 10 f8 ff                                  	jmp    22550 <mongoc_cmd_is_compressible@plt>
   a14d8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a14e0:	0f 18 3d 59 f5 fb ff                            	prefetchit0 -0x40aa7(%rip)        # 60a40 <_mongoc_stream_socket_readv>
   a14e7:	0f 18 3d 72 c4 fb ff                            	prefetchit0 -0x43b8e(%rip)        # 5d960 <mongoc_socket_recv>
   a14ee:	0f 18 3d 8c c4 fb ff                            	prefetchit0 -0x43b74(%rip)        # 5d981 <mongoc_socket_recv+0x21>
   a14f5:	0f 18 3d 04 db fb ff                            	prefetchit0 -0x424fc(%rip)        # 5f000 <mongoc_stream_read+0x20>
   a14fc:	0f 18 3d 67 f6 fb ff                            	prefetchit0 -0x40999(%rip)        # 60b6a <_mongoc_stream_socket_readv+0x12a>
   a1503:	0f 18 3d 11 d1 fb ff                            	prefetchit0 -0x42eef(%rip)        # 5e61b <mongoc_stream_buffered_readv+0x20b>
   a150a:	e9 41 fc f7 ff                                  	jmp    21150 <_mongoc_buffer_append_from_stream@plt>
   a150f:	90                                              	nop
   a1510:	0f 18 3d d9 54 f8 ff                            	prefetchit0 -0x7ab27(%rip)        # 269f0 <_mongoc_buffer_fill>
   a1517:	41 53                                           	push   %r11
   a1519:	4c 8b 1d 80 d6 ff ff                            	mov    -0x2980(%rip),%r11        # 9eba0 <pthread_mutex_unlock@GLIBC_2.2.5>
   a1520:	41 0f 18 93 92 b0 00 00                         	prefetcht1 0xb092(%r11)
   a1528:	41 0f 18 93 d0 bc 00 00                         	prefetcht1 0xbcd0(%r11)
   a1530:	41 0f 18 93 20 bd 00 00                         	prefetcht1 0xbd20(%r11)
   a1538:	4c 8b 1d a9 e5 ff ff                            	mov    -0x1a57(%rip),%r11        # 9fae8 <bson_append_bool@Base>
   a153f:	41 0f 18 93 40 a8 ff ff                         	prefetcht1 -0x57c0(%r11)
   a1547:	4c 8b 1d 7a e7 ff ff                            	mov    -0x1886(%rip),%r11        # 9fcc8 <bson_malloc0@Base>
   a154e:	41 0f 18 93 60 00 00 00                         	prefetcht1 0x60(%r11)
   a1556:	41 5b                                           	pop    %r11
   a1558:	e9 f3 fb f7 ff                                  	jmp    21150 <_mongoc_buffer_append_from_stream@plt>
   a155d:	0f 1f 00                                        	nopl   (%rax)
   a1560:	0f 18 3d ca 59 fb ff                            	prefetchit0 -0x4a636(%rip)        # 56f31 <_mongoc_rpc_scatter+0x721>
   a1567:	0f 18 3d b2 1e f8 ff                            	prefetchit0 -0x7e14e(%rip)        # 23420 <bson_init_static@plt>
   a156e:	0f 18 3d 1b 47 fb ff                            	prefetchit0 -0x4b8e5(%rip)        # 55c90 <_mongoc_rpc_swab_from_le>
   a1575:	e9 56 15 f8 ff                                  	jmp    22ad0 <_mongoc_rpc_scatter@plt>
   a157a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a1580:	41 53                                           	push   %r11
   a1582:	4c 8b 1d 0f e5 ff ff                            	mov    -0x1af1(%rip),%r11        # 9fa98 <bson_init_static@Base>
   a1589:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a1591:	41 0f 18 93 11 00 00 00                         	prefetcht1 0x11(%r11)
   a1599:	41 5b                                           	pop    %r11
   a159b:	e9 c0 03 f8 ff                                  	jmp    21960 <_mongoc_rpc_swab_from_le@plt>
   a15a0:	0f 18 3d d9 33 fc ff                            	prefetchit0 -0x3cc27(%rip)        # 64980 <mongoc_topology_description_update_cluster_time>
   a15a7:	0f 18 3d 92 08 f8 ff                            	prefetchit0 -0x7f76e(%rip)        # 21e40 <_mongoc_topology_update_cluster_time@plt>
   a15ae:	0f 18 3d 1b 14 fc ff                            	prefetchit0 -0x3ebe5(%rip)        # 629d0 <_mongoc_topology_update_cluster_time>
   a15b5:	0f 18 3d f4 f4 f7 ff                            	prefetchit0 -0x80b0c(%rip)        # 20ab0 <bson_iter_init_find@plt>
   a15bc:	0f 18 3d cd 09 f8 ff                            	prefetchit0 -0x7f633(%rip)        # 21f90 <mongoc_topology_description_update_cluster_time@plt>
   a15c3:	41 53                                           	push   %r11
   a15c5:	4c 8b 1d 14 d0 ff ff                            	mov    -0x2fec(%rip),%r11        # 9e5e0 <bson_iter_init_find@Base>
   a15cc:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a15d4:	4c 8b 1d 95 e4 ff ff                            	mov    -0x1b6b(%rip),%r11        # 9fa70 <bson_iter_init@Base>
   a15db:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a15e3:	41 0f 18 93 22 00 00 00                         	prefetcht1 0x22(%r11)
   a15eb:	41 5b                                           	pop    %r11
   a15ed:	e9 2e 1e f8 ff                                  	jmp    23420 <bson_init_static@plt>
   a15f2:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a15fc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a1600:	0f 18 3d f9 4e f8 ff                            	prefetchit0 -0x7b107(%rip)        # 26500 <_mongoc_buffer_destroy>
   a1607:	e9 d4 03 f8 ff                                  	jmp    219e0 <bson_copy_to@plt>
   a160c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a1610:	0f 18 3d b9 de fb ff                            	prefetchit0 -0x42147(%rip)        # 5f4d0 <_mongoc_stream_writev_full>
   a1617:	0f 18 3d 02 d7 fb ff                            	prefetchit0 -0x428fe(%rip)        # 5ed20 <mongoc_stream_writev>
   a161e:	0f 18 3d 1d df fb ff                            	prefetchit0 -0x420e3(%rip)        # 5f542 <_mongoc_stream_writev_full+0x72>
   a1625:	0f 18 3d 54 d1 fb ff                            	prefetchit0 -0x42eac(%rip)        # 5e780 <mongoc_stream_buffered_writev>
   a162c:	0f 18 3d ed f6 fb ff                            	prefetchit0 -0x40913(%rip)        # 60d20 <_mongoc_stream_socket_writev>
   a1633:	0f 18 3d 08 d7 fb ff                            	prefetchit0 -0x428f8(%rip)        # 5ed42 <mongoc_stream_writev+0x22>
   a163a:	0f 18 3d ff f6 fb ff                            	prefetchit0 -0x40901(%rip)        # 60d40 <_mongoc_stream_socket_writev+0x20>
   a1641:	0f 18 3d b8 de fb ff                            	prefetchit0 -0x42148(%rip)        # 5f500 <_mongoc_stream_writev_full+0x30>
   a1648:	e9 93 10 f8 ff                                  	jmp    226e0 <mongoc_server_description_compressor_id@plt>
   a164d:	0f 1f 00                                        	nopl   (%rax)
   a1650:	0f 18 3d 59 e9 f8 ff                            	prefetchit0 -0x716a7(%rip)        # 2ffb0 <handle_not_master_error>
   a1657:	0f 18 3d 3b ec f8 ff                            	prefetchit0 -0x713c5(%rip)        # 30299 <mongoc_cluster_run_command_monitored+0x119>
   a165e:	0f 18 3d c9 de f8 ff                            	prefetchit0 -0x72137(%rip)        # 2f52e <mongoc_cluster_run_opmsg+0x35e>
   a1665:	0f 18 3d 55 ec f8 ff                            	prefetchit0 -0x713ab(%rip)        # 302c1 <mongoc_cluster_run_command_monitored+0x141>
   a166c:	0f 18 3d 82 ed f8 ff                            	prefetchit0 -0x7127e(%rip)        # 303f5 <mongoc_cluster_run_command_monitored+0x275>
   a1673:	e9 58 05 f8 ff                                  	jmp    21bd0 <_mongoc_buffer_destroy@plt>
   a1678:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a1680:	0f 18 3d 79 4d f8 ff                            	prefetchit0 -0x7b287(%rip)        # 26400 <_mongoc_buffer_init>
   a1687:	0f 18 3d 52 7c fb ff                            	prefetchit0 -0x483ae(%rip)        # 592e0 <mongoc_server_description_compressor_id>
   a168e:	e9 0d f3 f7 ff                                  	jmp    209a0 <bson_get_monotonic_time@plt>
   a1693:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a169d:	0f 1f 00                                        	nopl   (%rax)
   a16a0:	0f 18 3d 5a 35 fb ff                            	prefetchit0 -0x4caa6(%rip)        # 54c01 <_mongoc_rpc_gather+0x41>
   a16a7:	e9 24 db f8 ff                                  	jmp    2f1d0 <mongoc_cluster_run_opmsg>
   a16ac:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a16b0:	0f 18 3d 89 5d fb ff                            	prefetchit0 -0x4a277(%rip)        # 57440 <_mongoc_cmd_check_ok_no_wce>
   a16b7:	0f 18 3d c2 5d fb ff                            	prefetchit0 -0x4a23e(%rip)        # 57480 <_mongoc_cmd_check_ok_no_wce+0x40>
   a16be:	e9 ed e8 f8 ff                                  	jmp    2ffb0 <handle_not_master_error>
   a16c3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a16cd:	0f 1f 00                                        	nopl   (%rax)
   a16d0:	0f 18 3d 99 d9 f8 ff                            	prefetchit0 -0x72667(%rip)        # 2f070 <_in_sharded_txn>
   a16d7:	0f 18 3d a4 d9 f8 ff                            	prefetchit0 -0x7265c(%rip)        # 2f082 <_in_sharded_txn+0x12>
   a16de:	e9 fd ed f7 ff                                  	jmp    204e0 <_in_sharded_txn@plt>
   a16e3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a16ed:	0f 1f 00                                        	nopl   (%rax)
   a16f0:	0f 18 3d 8b af f9 ff                            	prefetchit0 -0x65075(%rip)        # 3c682 <_mongoc_cursor_run_command+0x502>
   a16f7:	0f 18 3d 84 e9 fc ff                            	prefetchit0 -0x3167c(%rip)        # 70082 <_mongoc_write_error_get_type+0x12>
   a16fe:	e9 fd f8 f7 ff                                  	jmp    21000 <_mongoc_topology_update_last_used@plt>
   a1703:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a170d:	0f 1f 00                                        	nopl   (%rax)
   a1710:	0f 18 3d 99 75 fb ff                            	prefetchit0 -0x48a67(%rip)        # 58cb0 <mongoc_server_description_new_copy>
   a1717:	0f 18 3d a3 75 fb ff                            	prefetchit0 -0x48a5d(%rip)        # 58cc1 <mongoc_server_description_new_copy+0x11>
   a171e:	e9 bd 18 f8 ff                                  	jmp    22fe0 <mongoc_server_description_new_copy@plt>
   a1723:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a172d:	0f 1f 00                                        	nopl   (%rax)
   a1730:	0f 18 3d 39 f2 f7 ff                            	prefetchit0 -0x80dc7(%rip)        # 20970 <mongoc_topology_scanner_valid@plt>
   a1737:	0f 18 3d 32 d9 f8 ff                            	prefetchit0 -0x726ce(%rip)        # 2f070 <_in_sharded_txn>
   a173e:	0f 18 3d bb 4b fc ff                            	prefetchit0 -0x3b445(%rip)        # 66300 <mongoc_topology_scanner_valid>
   a1745:	0f 18 3d f4 07 fc ff                            	prefetchit0 -0x3f80c(%rip)        # 61f40 <mongoc_topology_select_server_id+0x10>
   a174c:	0f 18 3d dd 07 fc ff                            	prefetchit0 -0x3f823(%rip)        # 61f30 <mongoc_topology_select_server_id>
   a1753:	e9 08 f4 f7 ff                                  	jmp    20b60 <_mongoc_client_session_in_txn@plt>
   a1758:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a1760:	0f 18 3d f9 29 fb ff                            	prefetchit0 -0x4d607(%rip)        # 54160 <mongoc_read_prefs_get_max_staleness_seconds>
   a1767:	e9 84 13 f8 ff                                  	jmp    22af0 <mongoc_topology_select_server_id@plt>
   a176c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a1770:	0f 18 3d 89 4b fc ff                            	prefetchit0 -0x3b477(%rip)        # 66300 <mongoc_topology_scanner_valid>
   a1777:	0f 18 3d b2 07 fc ff                            	prefetchit0 -0x3f84e(%rip)        # 61f30 <mongoc_topology_select_server_id>
   a177e:	0f 18 3d bb 07 fc ff                            	prefetchit0 -0x3f845(%rip)        # 61f40 <mongoc_topology_select_server_id+0x10>
   a1785:	e9 56 ed f7 ff                                  	jmp    204e0 <_in_sharded_txn@plt>
   a178a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a1790:	0f 18 3d 6d 04 f9 ff                            	prefetchit0 -0x6fb93(%rip)        # 31c04 <_mongoc_cluster_stream_for_server+0x44>
   a1797:	0f 18 3d a2 05 f9 ff                            	prefetchit0 -0x6fa5e(%rip)        # 31d40 <_mongoc_cluster_stream_for_server+0x180>
   a179e:	e9 fd 1c f8 ff                                  	jmp    234a0 <mongoc_cluster_check_interval@plt>
   a17a3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a17ad:	0f 1f 00                                        	nopl   (%rax)
   a17b0:	0f 18 3d b9 cd fc ff                            	prefetchit0 -0x33247(%rip)        # 6e570 <_mongoc_write_command_init>
   a17b7:	0f 18 3d 83 f2 fc ff                            	prefetchit0 -0x30d7d(%rip)        # 70a41 <_mongoc_write_command_execute_idl+0x21>
   a17be:	0f 18 3d 8b eb fc ff                            	prefetchit0 -0x31475(%rip)        # 70350 <_mongoc_write_opmsg>
   a17c5:	0f 18 3d 54 f2 fc ff                            	prefetchit0 -0x30dac(%rip)        # 70a20 <_mongoc_write_command_execute_idl>
   a17cc:	0f 18 3d ad f2 fc ff                            	prefetchit0 -0x30d53(%rip)        # 70a80 <_mongoc_write_command_execute_idl+0x60>
   a17d3:	0f 18 3d a7 eb fc ff                            	prefetchit0 -0x31459(%rip)        # 70381 <_mongoc_write_opmsg+0x31>
   a17da:	0f 18 3d e2 eb fc ff                            	prefetchit0 -0x3141e(%rip)        # 703c3 <_mongoc_write_opmsg+0x73>
   a17e1:	e9 7a f3 f7 ff                                  	jmp    20b60 <_mongoc_client_session_in_txn@plt>
   a17e6:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a17f0:	0f 18 3d f9 f6 f7 ff                            	prefetchit0 -0x80907(%rip)        # 20ef0 <mongoc_write_concern_copy@plt>
   a17f7:	e9 84 20 f8 ff                                  	jmp    23880 <bson_malloc0@plt>
   a17fc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a1800:	0f 18 3d a9 0c fd ff                            	prefetchit0 -0x2f357(%rip)        # 724b0 <mongoc_write_concern_copy>
   a1807:	0f 18 3d 62 0c fd ff                            	prefetchit0 -0x2f39e(%rip)        # 72470 <mongoc_write_concern_new>
   a180e:	0f 18 3d ac 0c fd ff                            	prefetchit0 -0x2f354(%rip)        # 724c1 <mongoc_write_concern_copy+0x11>
   a1815:	0f 18 3d 84 fd f7 ff                            	prefetchit0 -0x8027c(%rip)        # 215a0 <mongoc_write_concern_new@plt>
   a181c:	0f 18 3d 4d ec f7 ff                            	prefetchit0 -0x813b3(%rip)        # 20470 <bson_init@plt>
   a1823:	41 53                                           	push   %r11
   a1825:	4c 8b 1d 94 ca ff ff                            	mov    -0x356c(%rip),%r11        # 9e2c0 <bson_init@Base>
   a182c:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a1834:	4c 8b 1d 6d d0 ff ff                            	mov    -0x2f93(%rip),%r11        # 9e8a8 <bson_strdup@Base>
   a183b:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a1843:	41 5b                                           	pop    %r11
   a1845:	e9 a6 f6 f7 ff                                  	jmp    20ef0 <mongoc_write_concern_copy@plt>
   a184a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a1850:	0f 18 3d f9 0f f8 ff                            	prefetchit0 -0x7f007(%rip)        # 22850 <mongoc_read_concern_new@plt>
   a1857:	e9 14 19 f8 ff                                  	jmp    23170 <mongoc_read_concern_copy@plt>
   a185c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a1860:	0f 18 3d 9b 25 fb ff                            	prefetchit0 -0x4da65(%rip)        # 53e02 <mongoc_read_prefs_new+0x12>
   a1867:	0f 18 3d f2 f9 f7 ff                            	prefetchit0 -0x8060e(%rip)        # 21260 <mongoc_read_prefs_new@plt>
   a186e:	0f 18 3d 7b 25 fb ff                            	prefetchit0 -0x4da85(%rip)        # 53df0 <mongoc_read_prefs_new>
   a1875:	0f 18 3d 84 2a fb ff                            	prefetchit0 -0x4d57c(%rip)        # 54300 <mongoc_read_prefs_copy>
   a187c:	41 53                                           	push   %r11
   a187e:	4c 8b 1d 13 d7 ff ff                            	mov    -0x28ed(%rip),%r11        # 9ef98 <bson_destroy@Base>
   a1885:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a188d:	41 5b                                           	pop    %r11
   a188f:	e9 8c 06 f8 ff                                  	jmp    21f20 <mongoc_read_prefs_copy@plt>
   a1894:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a189e:	66 90                                           	xchg   %ax,%ax
   a18a0:	41 53                                           	push   %r11
   a18a2:	4c 8b 1d 97 c7 ff ff                            	mov    -0x3869(%rip),%r11        # 9e040 <pthread_cond_signal@GLIBC_2.3.2>
   a18a9:	41 0f 18 93 e3 22 fe ff                         	prefetcht1 -0x1dd1d(%r11)
   a18b1:	41 0f 18 93 d0 51 ff ff                         	prefetcht1 -0xae30(%r11)
   a18b9:	41 0f 18 93 e0 51 ff ff                         	prefetcht1 -0xae20(%r11)
   a18c1:	41 0f 18 93 a0 ab ff ff                         	prefetcht1 -0x5460(%r11)
   a18c9:	41 0f 18 93 30 b4 ff ff                         	prefetcht1 -0x4bd0(%r11)
   a18d1:	4c 8b 1d 08 c9 ff ff                            	mov    -0x36f8(%rip),%r11        # 9e1e0 <bson_snprintf@Base>
   a18d8:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a18e0:	4c 8b 1d b9 d3 ff ff                            	mov    -0x2c47(%rip),%r11        # 9eca0 <sendmsg@GLIBC_2.2.5>
   a18e7:	41 0f 18 93 10 d2 00 00                         	prefetcht1 0xd210(%r11)
   a18ef:	41 0f 18 93 21 d2 00 00                         	prefetcht1 0xd221(%r11)
   a18f7:	41 5b                                           	pop    %r11
   a18f9:	e9 b2 e9 f7 ff                                  	jmp    202b0 <bson_snprintf@plt>
   a18fe:	66 90                                           	xchg   %ax,%ax
   a1900:	41 53                                           	push   %r11
   a1902:	4c 8b 1d 8f e1 ff ff                            	mov    -0x1e71(%rip),%r11        # 9fa98 <bson_init_static@Base>
   a1909:	41 0f 18 93 10 01 00 00                         	prefetcht1 0x110(%r11)
   a1911:	41 5b                                           	pop    %r11
   a1913:	e9 c8 f2 f7 ff                                  	jmp    20be0 <strlen@plt>
   a1918:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a1920:	0f 18 3d f9 dd f9 ff                            	prefetchit0 -0x62207(%rip)        # 3f720 <_mongoc_cursor_find_new>
   a1927:	0f 18 3d 13 de f9 ff                            	prefetchit0 -0x621ed(%rip)        # 3f741 <_mongoc_cursor_find_new+0x21>
   a192e:	0f 18 3d 8e bc f9 ff                            	prefetchit0 -0x64372(%rip)        # 3d5c3 <_mongoc_cursor_new_with_opts+0x63>
   a1935:	0f 18 3d 44 bc f9 ff                            	prefetchit0 -0x643bc(%rip)        # 3d580 <_mongoc_cursor_new_with_opts+0x20>
   a193c:	0f 18 3d 1d bc f9 ff                            	prefetchit0 -0x643e3(%rip)        # 3d560 <_mongoc_cursor_new_with_opts>
   a1943:	e9 08 18 f8 ff                                  	jmp    23150 <_mongoc_cursor_find_new@plt>
   a1948:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a1950:	41 53                                           	push   %r11
   a1952:	4c 8b 1d 4f df ff ff                            	mov    -0x20b1(%rip),%r11        # 9f8a8 <bson_validate_with_error@Base>
   a1959:	41 0f 18 93 40 00 00 00                         	prefetcht1 0x40(%r11)
   a1961:	41 5b                                           	pop    %r11
   a1963:	e9 e8 06 f8 ff                                  	jmp    22050 <_mongoc_bson_init_if_set@plt>
   a1968:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a1970:	0f 18 3d 19 c7 fc ff                            	prefetchit0 -0x338e7(%rip)        # 6e090 <_mongoc_write_command_init_insert_idl>
   a1977:	0f 18 3d 82 4a f8 ff                            	prefetchit0 -0x7b57e(%rip)        # 26400 <_mongoc_buffer_init>
   a197e:	0f 18 3d 3b c5 fc ff                            	prefetchit0 -0x33ac5(%rip)        # 6dec0 <_mongoc_write_command_init_bulk>
   a1985:	0f 18 3d 35 c7 fc ff                            	prefetchit0 -0x338cb(%rip)        # 6e0c1 <_mongoc_write_command_init_insert_idl+0x31>
   a198c:	0f 18 3d cd ce fc ff                            	prefetchit0 -0x33133(%rip)        # 6e860 <_mongoc_write_result_init>
   a1993:	0f 18 3d 16 1c f8 ff                            	prefetchit0 -0x7e3ea(%rip)        # 235b0 <_mongoc_write_command_init_insert_idl@plt>
   a199a:	0f 18 3d 2f ee f7 ff                            	prefetchit0 -0x811d1(%rip)        # 207d0 <_mongoc_buffer_init@plt>
   a19a1:	0f 18 3d dd ce fc ff                            	prefetchit0 -0x33123(%rip)        # 6e885 <_mongoc_write_result_init+0x25>
   a19a8:	e9 c3 f7 f7 ff                                  	jmp    21170 <_mongoc_write_result_init@plt>
   a19ad:	0f 1f 00                                        	nopl   (%rax)
   a19b0:	0f 18 3d b9 bf fc ff                            	prefetchit0 -0x34047(%rip)        # 6d970 <_mongoc_write_command_insert_append>
   a19b7:	0f 18 3d 03 c0 fc ff                            	prefetchit0 -0x33ffd(%rip)        # 6d9c1 <_mongoc_write_command_insert_append+0x51>
   a19be:	0f 18 3d bc bf fc ff                            	prefetchit0 -0x34044(%rip)        # 6d981 <_mongoc_write_command_insert_append+0x11>
   a19c5:	41 53                                           	push   %r11
   a19c7:	4c 8b 1d 12 cc ff ff                            	mov    -0x33ee(%rip),%r11        # 9e5e0 <bson_iter_init_find@Base>
   a19ce:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a19d6:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
   a19de:	41 5b                                           	pop    %r11
   a19e0:	e9 cb 1b f8 ff                                  	jmp    235b0 <_mongoc_write_command_init_insert_idl@plt>
   a19e5:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a19ef:	90                                              	nop
   a19f0:	0f 18 3d 0c bc fc ff                            	prefetchit0 -0x343f4(%rip)        # 6d603 <_set_error_from_response+0x23>
   a19f7:	0f 18 3d e2 bb fc ff                            	prefetchit0 -0x3441e(%rip)        # 6d5e0 <_set_error_from_response>
   a19fe:	0f 18 3d db 22 f8 ff                            	prefetchit0 -0x7dd25(%rip)        # 23ce0 <bson_string_new@plt>
   a1a05:	41 53                                           	push   %r11
   a1a07:	4c 8b 1d da e0 ff ff                            	mov    -0x1f26(%rip),%r11        # 9fae8 <bson_append_bool@Base>
   a1a0e:	41 0f 18 93 d0 ab ff ff                         	prefetcht1 -0x5430(%r11)
   a1a16:	4c 8b 1d db e4 ff ff                            	mov    -0x1b25(%rip),%r11        # 9fef8 <bson_string_new@Base>
   a1a1d:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a1a25:	41 5b                                           	pop    %r11
   a1a27:	e9 84 02 f8 ff                                  	jmp    21cb0 <_mongoc_write_result_complete@plt>
   a1a2c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a1a30:	0f 18 3d f9 cd fc ff                            	prefetchit0 -0x33207(%rip)        # 6e830 <_mongoc_write_command_destroy>
   a1a37:	0f 18 3d e2 ce fc ff                            	prefetchit0 -0x3311e(%rip)        # 6e920 <_mongoc_write_result_destroy>
   a1a3e:	e9 9d 0d f8 ff                                  	jmp    227e0 <_mongoc_write_result_destroy@plt>
   a1a43:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a1a4d:	0f 1f 00                                        	nopl   (%rax)
   a1a50:	0f 18 3d fb 58 f9 ff                            	prefetchit0 -0x6a705(%rip)        # 37352 <mongoc_collection_insert_one+0x82>
   a1a57:	0f 18 3d 72 e4 fa ff                            	prefetchit0 -0x51b8e(%rip)        # 4fed0 <_mongoc_insert_one_opts_cleanup>
   a1a5e:	e9 4d fb f7 ff                                  	jmp    215b0 <_mongoc_write_command_destroy@plt>
   a1a63:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a1a6d:	0f 1f 00                                        	nopl   (%rax)
   a1a70:	0f 18 3d 09 16 f9 ff                            	prefetchit0 -0x6e9f7(%rip)        # 33080 <mongoc_cluster_stream_for_writes+0x10>
   a1a77:	0f 18 3d f2 15 f9 ff                            	prefetchit0 -0x6ea0e(%rip)        # 33070 <mongoc_cluster_stream_for_writes>
   a1a7e:	0f 18 3d cb 16 f9 ff                            	prefetchit0 -0x6e935(%rip)        # 33150 <mongoc_cluster_stream_for_writes+0xe0>
   a1a85:	e9 26 f0 f7 ff                                  	jmp    20ab0 <bson_iter_init_find@plt>
   a1a8a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a1a90:	41 53                                           	push   %r11
   a1a92:	4c 8b 1d b7 d0 ff ff                            	mov    -0x2f49(%rip),%r11        # 9eb50 <bson_append_utf8@Base>
   a1a99:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a1aa1:	4c 8b 1d 40 e0 ff ff                            	mov    -0x1fc0(%rip),%r11        # 9fae8 <bson_append_bool@Base>
   a1aa8:	41 0f 18 93 60 f1 ff ff                         	prefetcht1 -0xea0(%r11)
   a1ab0:	41 0f 18 93 bc f1 ff ff                         	prefetcht1 -0xe44(%r11)
   a1ab8:	41 5b                                           	pop    %r11
   a1aba:	e9 b1 e9 f7 ff                                  	jmp    20470 <bson_init@plt>
   a1abf:	90                                              	nop
   a1ac0:	41 53                                           	push   %r11
   a1ac2:	4c 8b 1d d7 cb ff ff                            	mov    -0x3429(%rip),%r11        # 9e6a0 <bson_strdup_printf@Base>
   a1ac9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a1ad1:	41 0f 18 93 24 00 00 00                         	prefetcht1 0x24(%r11)
   a1ad9:	4c 8b 1d e0 d5 ff ff                            	mov    -0x2a20(%rip),%r11        # 9f0c0 <bson_strncpy@Base>
   a1ae0:	41 0f 18 93 83 01 00 00                         	prefetcht1 0x183(%r11)
   a1ae8:	41 5b                                           	pop    %r11
   a1aea:	e9 01 1f f8 ff                                  	jmp    239f0 <_mongoc_document_is_pipeline@plt>
   a1aef:	90                                              	nop
   a1af0:	0f 18 3d 91 cc fa ff                            	prefetchit0 -0x5336f(%rip)        # 4e788 <mongoc_cmd_parts_append_opts+0x218>
   a1af7:	41 53                                           	push   %r11
   a1af9:	4c 8b 1d d0 cf ff ff                            	mov    -0x3030(%rip),%r11        # 9ead0 <bson_has_field@Base>
   a1b00:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a1b08:	41 0f 18 93 11 00 00 00                         	prefetcht1 0x11(%r11)
   a1b10:	41 0f 18 93 50 00 00 00                         	prefetcht1 0x50(%r11)
   a1b18:	41 5b                                           	pop    %r11
   a1b1a:	e9 b1 18 f8 ff                                  	jmp    233d0 <bson_iter_init@plt>
   a1b1f:	90                                              	nop
   a1b20:	0f 18 3d 29 1c fa ff                            	prefetchit0 -0x5e3d7(%rip)        # 43750 <mongoc_find_and_modify_opts_destroy>
   a1b27:	0f 18 3d f5 86 f9 ff                            	prefetchit0 -0x6790b(%rip)        # 3a223 <mongoc_collection_find_and_modify+0xb3>
   a1b2e:	0f 18 3d db ec f7 ff                            	prefetchit0 -0x81325(%rip)        # 20810 <mongoc_find_and_modify_opts_destroy@plt>
   a1b35:	e9 e6 02 f8 ff                                  	jmp    21e20 <bson_destroy@plt>
   a1b3a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a1b40:	0f 18 3d d9 ff f7 ff                            	prefetchit0 -0x80027(%rip)        # 21b20 <mongoc_write_concern_get_journal@plt>
   a1b47:	0f 18 3d c2 11 fd ff                            	prefetchit0 -0x2ee3e(%rip)        # 72d10 <mongoc_write_concern_is_valid>
   a1b4e:	0f 18 3d db 0a fd ff                            	prefetchit0 -0x2f525(%rip)        # 72630 <mongoc_write_concern_get_journal>
   a1b55:	e9 56 0a f8 ff                                  	jmp    225b0 <mongoc_write_concern_is_valid@plt>
   a1b5a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a1b60:	0f 18 3d 19 1d f8 ff                            	prefetchit0 -0x7e2e7(%rip)        # 23880 <bson_malloc0@plt>
   a1b67:	41 53                                           	push   %r11
   a1b69:	4c 8b 1d 30 d0 ff ff                            	mov    -0x2fd0(%rip),%r11        # 9eba0 <pthread_mutex_unlock@GLIBC_2.2.5>
   a1b70:	41 0f 18 93 b0 ca 00 00                         	prefetcht1 0xcab0(%r11)
   a1b78:	41 0f 18 93 54 cb 00 00                         	prefetcht1 0xcb54(%r11)
   a1b80:	41 5b                                           	pop    %r11
   a1b82:	e9 e9 f1 f7 ff                                  	jmp    20d70 <mongoc_find_and_modify_opts_new@plt>
   a1b87:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
   a1b90:	41 53                                           	push   %r11
   a1b92:	4c 8b 1d d7 dd ff ff                            	mov    -0x2229(%rip),%r11        # 9f970 <bson_copy@Base>
   a1b99:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a1ba1:	41 5b                                           	pop    %r11
   a1ba3:	e9 48 f1 f7 ff                                  	jmp    20cf0 <mongoc_find_and_modify_opts_set_sort@plt>
   a1ba8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a1bb0:	0f 18 3d 4b 7d f9 ff                            	prefetchit0 -0x682b5(%rip)        # 39902 <mongoc_collection_find_and_modify_with_opts+0xc2>
   a1bb7:	0f 18 3d 72 c6 fa ff                            	prefetchit0 -0x5398e(%rip)        # 4e230 <mongoc_cmd_parts_init>
   a1bbe:	0f 18 3d 7f 7d f9 ff                            	prefetchit0 -0x68281(%rip)        # 39944 <mongoc_collection_find_and_modify_with_opts+0x104>
   a1bc5:	0f 18 3d b5 7c f9 ff                            	prefetchit0 -0x6834b(%rip)        # 39881 <mongoc_collection_find_and_modify_with_opts+0x41>
   a1bcc:	0f 18 3d 6d 7c f9 ff                            	prefetchit0 -0x68393(%rip)        # 39840 <mongoc_collection_find_and_modify_with_opts>
   a1bd3:	0f 18 3d e8 7c f9 ff                            	prefetchit0 -0x68318(%rip)        # 398c2 <mongoc_collection_find_and_modify_with_opts+0x82>
   a1bda:	0f 18 3d 5f c6 fa ff                            	prefetchit0 -0x539a1(%rip)        # 4e240 <mongoc_cmd_parts_init+0x10>
   a1be1:	0f 18 3d 9b c6 fa ff                            	prefetchit0 -0x53965(%rip)        # 4e283 <mongoc_cmd_parts_init+0x53>
   a1be8:	e9 f3 1d f8 ff                                  	jmp    239e0 <mongoc_find_and_modify_opts_set_fields@plt>
   a1bed:	0f 1f 00                                        	nopl   (%rax)
   a1bf0:	0f 18 3d 39 ec f7 ff                            	prefetchit0 -0x813c7(%rip)        # 20830 <mongoc_cmd_parts_init@plt>
   a1bf7:	e9 54 18 f8 ff                                  	jmp    23450 <mongoc_find_and_modify_opts_set_flags@plt>
   a1bfc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a1c00:	0f 18 3d a9 5d fb ff                            	prefetchit0 -0x4a257(%rip)        # 579b0 <mongoc_server_description_cleanup>
   a1c07:	e9 a4 ee f7 ff                                  	jmp    20ab0 <bson_iter_init_find@plt>
   a1c0c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a1c10:	41 53                                           	push   %r11
   a1c12:	4c 8b 1d 87 c9 ff ff                            	mov    -0x3679(%rip),%r11        # 9e5a0 <strchr@GLIBC_2.2.5>
   a1c19:	41 0f 18 93 17 00 00 00                         	prefetcht1 0x17(%r11)
   a1c21:	41 0f 18 93 22 00 00 00                         	prefetcht1 0x22(%r11)
   a1c29:	4c 8b 1d 48 ca ff ff                            	mov    -0x35b8(%rip),%r11        # 9e678 <strlen@GLIBC_2.2.5>
   a1c30:	41 0f 18 93 10 12 00 00                         	prefetcht1 0x1210(%r11)
   a1c38:	41 0f 18 93 81 15 00 00                         	prefetcht1 0x1581(%r11)
   a1c40:	41 0f 18 93 e0 15 00 00                         	prefetcht1 0x15e0(%r11)
   a1c48:	41 0f 18 93 20 18 00 00                         	prefetcht1 0x1820(%r11)
   a1c50:	41 0f 18 93 10 1a 00 00                         	prefetcht1 0x1a10(%r11)
   a1c58:	41 0f 18 93 22 1a 00 00                         	prefetcht1 0x1a22(%r11)
   a1c60:	41 5b                                           	pop    %r11
   a1c62:	e9 09 04 f8 ff                                  	jmp    22070 <bson_strncpy@plt>
   a1c67:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
   a1c70:	0f 18 3d 0b 95 f9 ff                            	prefetchit0 -0x66af5(%rip)        # 3b182 <_mongoc_cursor_get_opt_bool+0x32>
   a1c77:	0f 18 3d c2 a5 fb ff                            	prefetchit0 -0x45a3e(%rip)        # 5c240 <mongoc_client_session_destroy>
   a1c7e:	0f 18 3d 5b f0 f7 ff                            	prefetchit0 -0x80fa5(%rip)        # 20ce0 <mongoc_client_session_in_transaction@plt>
   a1c85:	41 53                                           	push   %r11
   a1c87:	4c 8b 1d e2 dd ff ff                            	mov    -0x221e(%rip),%r11        # 9fa70 <bson_iter_init@Base>
   a1c8e:	41 0f 18 93 10 fc ff ff                         	prefetcht1 -0x3f0(%r11)
   a1c96:	41 0f 18 93 22 fc ff ff                         	prefetcht1 -0x3de(%r11)
   a1c9e:	41 0f 18 93 62 fc ff ff                         	prefetcht1 -0x39e(%r11)
   a1ca6:	4c 8b 1d 3b de ff ff                            	mov    -0x21c5(%rip),%r11        # 9fae8 <bson_append_bool@Base>
   a1cad:	41 0f 18 93 60 a1 ff ff                         	prefetcht1 -0x5ea0(%r11)
   a1cb5:	41 5b                                           	pop    %r11
   a1cb7:	e9 74 ed f7 ff                                  	jmp    20a30 <strchr@plt>
   a1cbc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a1cc0:	41 53                                           	push   %r11
   a1cc2:	4c 8b 1d d7 c3 ff ff                            	mov    -0x3c29(%rip),%r11        # 9e0a0 <bson_iter_recurse@Base>
   a1cc9:	41 0f 18 93 30 03 00 00                         	prefetcht1 0x330(%r11)
   a1cd1:	41 0f 18 93 76 03 00 00                         	prefetcht1 0x376(%r11)
   a1cd9:	41 5b                                           	pop    %r11
   a1cdb:	e9 60 13 f8 ff                                  	jmp    23040 <bson_validate_with_error@plt>
   a1ce0:	0f 18 3d 49 ad f9 ff                            	prefetchit0 -0x652b7(%rip)        # 3ca30 <mongoc_cursor_next>
   a1ce7:	0f 18 3d 53 ad f9 ff                            	prefetchit0 -0x652ad(%rip)        # 3ca41 <mongoc_cursor_next+0x11>
   a1cee:	0f 18 3d 8b 9e f9 ff                            	prefetchit0 -0x66175(%rip)        # 3bb80 <_mongoc_cursor_fetch_stream>
   a1cf5:	0f 18 3d 84 11 f9 ff                            	prefetchit0 -0x6ee7c(%rip)        # 32e80 <mongoc_cluster_stream_for_reads>
   a1cfc:	0f 18 3d be 9e f9 ff                            	prefetchit0 -0x66142(%rip)        # 3bbc1 <_mongoc_cursor_fetch_stream+0x41>
   a1d03:	0f 18 3d 76 d9 f9 ff                            	prefetchit0 -0x6268a(%rip)        # 3f680 <_prime>
   a1d0a:	0f 18 3d 74 ad f9 ff                            	prefetchit0 -0x6528c(%rip)        # 3ca85 <mongoc_cursor_next+0x55>
   a1d11:	0f 18 3d 38 ae f9 ff                            	prefetchit0 -0x651c8(%rip)        # 3cb50 <mongoc_cursor_next+0x120>
   a1d18:	e9 03 01 f8 ff                                  	jmp    21e20 <bson_destroy@plt>
   a1d1d:	0f 1f 00                                        	nopl   (%rax)
   a1d20:	0f 18 3d 49 27 f9 ff                            	prefetchit0 -0x6d8b7(%rip)        # 34470 <mongoc_collection_destroy>
   a1d27:	0f 18 3d 53 27 f9 ff                            	prefetchit0 -0x6d8ad(%rip)        # 34481 <mongoc_collection_destroy+0x11>
   a1d2e:	e9 5d e2 f7 ff                                  	jmp    1ff90 <mongoc_write_concern_destroy@plt>
   a1d33:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a1d3d:	0f 1f 00                                        	nopl   (%rax)
   a1d40:	0f 18 3d 69 0a f9 ff                            	prefetchit0 -0x6f597(%rip)        # 327b0 <mongoc_cluster_stream_for_server>
   a1d47:	0f 18 3d 73 0a f9 ff                            	prefetchit0 -0x6f58d(%rip)        # 327c1 <mongoc_cluster_stream_for_server+0x11>
   a1d4e:	0f 18 3d ad 0a f9 ff                            	prefetchit0 -0x6f553(%rip)        # 32802 <mongoc_cluster_stream_for_server+0x52>
   a1d55:	e9 d6 ea f7 ff                                  	jmp    20830 <mongoc_cmd_parts_init@plt>
   a1d5a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a1d60:	0f 18 3d e9 7c fb ff                            	prefetchit0 -0x48317(%rip)        # 59a50 <mongoc_session_opts_new>
   a1d67:	0f 18 3d 52 a8 f9 ff                            	prefetchit0 -0x657ae(%rip)        # 3c5c0 <_mongoc_cursor_run_command+0x440>
   a1d6e:	0f 18 3d 96 a7 f9 ff                            	prefetchit0 -0x6586a(%rip)        # 3c50b <_mongoc_cursor_run_command+0x38b>
   a1d75:	e9 56 16 f8 ff                                  	jmp    233d0 <bson_iter_init@plt>
   a1d7a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a1d80:	0f 18 3d 7d 5d fc ff                            	prefetchit0 -0x3a283(%rip)        # 67b04 <mongoc_uri_canonicalize_option+0x14>
   a1d87:	0f 18 3d f2 88 fc ff                            	prefetchit0 -0x3770e(%rip)        # 6a680 <mongoc_uri_get_option_as_bool>
   a1d8e:	0f 18 3d b0 cd fa ff                            	prefetchit0 -0x53250(%rip)        # 4eb45 <_is_retryable_read+0x15>
   a1d95:	0f 18 3d 94 cd fa ff                            	prefetchit0 -0x5326c(%rip)        # 4eb30 <_is_retryable_read>
   a1d9c:	0f 18 3d 4d 5d fc ff                            	prefetchit0 -0x3a2b3(%rip)        # 67af0 <mongoc_uri_canonicalize_option>
   a1da3:	41 53                                           	push   %r11
   a1da5:	4c 8b 1d dc d2 ff ff                            	mov    -0x2d24(%rip),%r11        # 9f088 <strcasecmp@GLIBC_2.2.5>
   a1dac:	41 0f 18 93 b0 08 00 00                         	prefetcht1 0x8b0(%r11)
   a1db4:	41 0f 18 93 40 16 00 00                         	prefetcht1 0x1640(%r11)
   a1dbc:	41 0f 18 93 53 16 00 00                         	prefetcht1 0x1653(%r11)
   a1dc4:	41 5b                                           	pop    %r11
   a1dc6:	e9 45 0d f8 ff                                  	jmp    22b10 <strcmp@plt>
   a1dcb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
   a1dd0:	41 53                                           	push   %r11
   a1dd2:	4c 8b 1d af d2 ff ff                            	mov    -0x2d51(%rip),%r11        # 9f088 <strcasecmp@GLIBC_2.2.5>
   a1dd9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a1de1:	41 0f 18 93 10 06 00 00                         	prefetcht1 0x610(%r11)
   a1de9:	41 0f 18 93 d2 08 00 00                         	prefetcht1 0x8d2(%r11)
   a1df1:	41 5b                                           	pop    %r11
   a1df3:	e9 d8 1a f8 ff                                  	jmp    238d0 <_is_retryable_read@plt>
   a1df8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a1e00:	0f 18 3d b9 1a f8 ff                            	prefetchit0 -0x7e547(%rip)        # 238c0 <mongoc_server_description_destroy@plt>
   a1e07:	e9 d4 14 f8 ff                                  	jmp    232e0 <mongoc_server_stream_cleanup@plt>
   a1e0c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a1e10:	0f 18 3d b9 24 fb ff                            	prefetchit0 -0x4db47(%rip)        # 542d0 <mongoc_read_prefs_destroy>
   a1e17:	e9 74 eb f7 ff                                  	jmp    20990 <mongoc_cmd_parts_cleanup@plt>
   a1e1c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a1e20:	0f 18 3d 91 c7 f9 ff                            	prefetchit0 -0x6386f(%rip)        # 3e5b8 <_mongoc_cursor_response_refresh+0x38>
   a1e27:	0f 18 3d 94 c4 f9 ff                            	prefetchit0 -0x63b6c(%rip)        # 3e2c2 <_mongoc_cursor_start_reading_response+0x32>
   a1e2e:	0f 18 3d 5b c4 f9 ff                            	prefetchit0 -0x63ba5(%rip)        # 3e290 <_mongoc_cursor_start_reading_response>
   a1e35:	e9 36 fb f7 ff                                  	jmp    21970 <mongoc_read_prefs_destroy@plt>
   a1e3a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a1e40:	0f 18 3d a9 81 fb ff                            	prefetchit0 -0x47e57(%rip)        # 59ff0 <_mongoc_server_session_timed_out>
   a1e47:	0f 18 3d f3 0b fc ff                            	prefetchit0 -0x3f40d(%rip)        # 62a41 <_mongoc_topology_pop_server_session+0x21>
   a1e4e:	e9 ed 12 f8 ff                                  	jmp    23140 <mongoc_session_opts_set_causal_consistency@plt>
   a1e53:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a1e5d:	0f 1f 00                                        	nopl   (%rax)
   a1e60:	0f 18 3d f9 e0 f7 ff                            	prefetchit0 -0x81f07(%rip)        # 1ff60 <mongoc_session_opts_destroy@plt>
   a1e67:	0f 18 3d c2 7e fb ff                            	prefetchit0 -0x4813e(%rip)        # 59d30 <mongoc_session_opts_destroy>
   a1e6e:	e9 8d fe f7 ff                                  	jmp    21d00 <mongoc_cmd_parts_set_session@plt>
   a1e73:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a1e7d:	0f 1f 00                                        	nopl   (%rax)
   a1e80:	41 53                                           	push   %r11
   a1e82:	4c 8b 1d c7 cc ff ff                            	mov    -0x3339(%rip),%r11        # 9eb50 <bson_append_utf8@Base>
   a1e89:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a1e91:	4c 8b 1d 50 dc ff ff                            	mov    -0x23b0(%rip),%r11        # 9fae8 <bson_append_bool@Base>
   a1e98:	41 0f 18 93 60 f1 ff ff                         	prefetcht1 -0xea0(%r11)
   a1ea0:	41 0f 18 93 bc f1 ff ff                         	prefetcht1 -0xe44(%r11)
   a1ea8:	41 5b                                           	pop    %r11
   a1eaa:	e9 b1 f4 f7 ff                                  	jmp    21360 <_mongoc_cursor_collection@plt>
   a1eaf:	90                                              	nop
   a1eb0:	0f 18 3d 19 8a fb ff                            	prefetchit0 -0x475e7(%rip)        # 5a8d0 <_mongoc_client_session_in_txn>
   a1eb7:	e9 b4 e5 f7 ff                                  	jmp    20470 <bson_init@plt>
   a1ebc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a1ec0:	0f 18 3d 09 19 f8 ff                            	prefetchit0 -0x7e6f7(%rip)        # 237d0 <_mongoc_cursor_check_and_copy_to@plt>
   a1ec7:	41 53                                           	push   %r11
   a1ec9:	4c 8b 1d d8 d9 ff ff                            	mov    -0x2628(%rip),%r11        # 9f8a8 <bson_validate_with_error@Base>
   a1ed0:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a1ed8:	41 0f 18 93 40 00 00 00                         	prefetcht1 0x40(%r11)
   a1ee0:	41 5b                                           	pop    %r11
   a1ee2:	e9 e9 0c f8 ff                                  	jmp    22bd0 <mongoc_read_concern_destroy@plt>
   a1ee7:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
   a1ef0:	0f 18 3d 59 92 f9 ff                            	prefetchit0 -0x66da7(%rip)        # 3b150 <_mongoc_cursor_get_opt_bool>
   a1ef7:	0f 18 3d c2 92 f9 ff                            	prefetchit0 -0x66d3e(%rip)        # 3b1c0 <_mongoc_set_cursor_ns>
   a1efe:	41 53                                           	push   %r11
   a1f00:	4c 8b 1d 71 c7 ff ff                            	mov    -0x388f(%rip),%r11        # 9e678 <strlen@GLIBC_2.2.5>
   a1f07:	41 0f 18 93 20 12 00 00                         	prefetcht1 0x1220(%r11)
   a1f0f:	41 0f 18 93 b0 19 00 00                         	prefetcht1 0x19b0(%r11)
   a1f17:	41 5b                                           	pop    %r11
   a1f19:	e9 c2 ec f7 ff                                  	jmp    20be0 <strlen@plt>
   a1f1e:	66 90                                           	xchg   %ax,%ax
   a1f20:	0f 18 3d f9 22 fb ff                            	prefetchit0 -0x4dd07(%rip)        # 54220 <mongoc_read_prefs_is_valid>
   a1f27:	0f 18 3d 12 0b f8 ff                            	prefetchit0 -0x7f4ee(%rip)        # 22a40 <_mongoc_read_prefs_validate@plt>
   a1f2e:	0f 18 3d cb 1d f8 ff                            	prefetchit0 -0x7e235(%rip)        # 23d00 <mongoc_read_prefs_is_valid@plt>
   a1f35:	0f 18 3d 24 28 fb ff                            	prefetchit0 -0x4d7dc(%rip)        # 54760 <_mongoc_read_prefs_validate>
   a1f3c:	e9 ef 11 f8 ff                                  	jmp    23130 <_mongoc_cursor_get_opt_bool@plt>
   a1f41:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a1f4b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
   a1f50:	41 53                                           	push   %r11
   a1f52:	4c 8b 1d 47 c1 ff ff                            	mov    -0x3eb9(%rip),%r11        # 9e0a0 <bson_iter_recurse@Base>
   a1f59:	41 0f 18 93 2a 00 00 00                         	prefetcht1 0x2a(%r11)
   a1f61:	4c 8b 1d e8 c3 ff ff                            	mov    -0x3c18(%rip),%r11        # 9e350 <bson_iter_document@Base>
   a1f68:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a1f70:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
   a1f78:	4c 8b 1d 69 db ff ff                            	mov    -0x2497(%rip),%r11        # 9fae8 <bson_append_bool@Base>
   a1f7f:	41 0f 18 93 20 a7 ff ff                         	prefetcht1 -0x58e0(%r11)
   a1f87:	41 5b                                           	pop    %r11
   a1f89:	e9 62 f4 f7 ff                                  	jmp    213f0 <bson_iter_type@plt>
   a1f8e:	66 90                                           	xchg   %ax,%ax
   a1f90:	0f 18 3d 29 92 f9 ff                            	prefetchit0 -0x66dd7(%rip)        # 3b1c0 <_mongoc_set_cursor_ns>
   a1f97:	41 53                                           	push   %r11
   a1f99:	4c 8b 1d 28 d0 ff ff                            	mov    -0x2fd8(%rip),%r11        # 9efc8 <bson_iter_utf8@Base>
   a1fa0:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a1fa8:	4c 8b 1d 11 d1 ff ff                            	mov    -0x2eef(%rip),%r11        # 9f0c0 <bson_strncpy@Base>
   a1faf:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a1fb7:	41 5b                                           	pop    %r11
   a1fb9:	e9 32 13 f8 ff                                  	jmp    232f0 <bson_iter_as_int64@plt>
   a1fbe:	66 90                                           	xchg   %ax,%ax
   a1fc0:	41 53                                           	push   %r11
   a1fc2:	4c 8b 1d af c6 ff ff                            	mov    -0x3951(%rip),%r11        # 9e678 <strlen@GLIBC_2.2.5>
   a1fc9:	41 0f 18 93 b0 19 00 00                         	prefetcht1 0x19b0(%r11)
   a1fd1:	41 5b                                           	pop    %r11
   a1fd3:	e9 e8 0c f8 ff                                  	jmp    22cc0 <bson_iter_key@plt>
   a1fd8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a1fe0:	0f 18 3d 9c c2 fa ff                            	prefetchit0 -0x53d64(%rip)        # 4e283 <mongoc_cmd_parts_init+0x53>
   a1fe7:	0f 18 3d 52 c2 fa ff                            	prefetchit0 -0x53dae(%rip)        # 4e240 <mongoc_cmd_parts_init+0x10>
   a1fee:	0f 18 3d 3b c2 fa ff                            	prefetchit0 -0x53dc5(%rip)        # 4e230 <mongoc_cmd_parts_init>
   a1ff5:	e9 26 fe f7 ff                                  	jmp    21e20 <bson_destroy@plt>
   a1ffa:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a2000:	0f 18 3d 49 a8 f9 ff                            	prefetchit0 -0x657b7(%rip)        # 3c850 <_mongoc_cursor_collection>
   a2007:	0f 18 3d c2 a8 f9 ff                            	prefetchit0 -0x6573e(%rip)        # 3c8d0 <_mongoc_cursor_prepare_find_command>
   a200e:	41 53                                           	push   %r11
   a2010:	4c 8b 1d 39 cb ff ff                            	mov    -0x34c7(%rip),%r11        # 9eb50 <bson_append_utf8@Base>
   a2017:	41 0f 18 93 80 00 00 00                         	prefetcht1 0x80(%r11)
   a201f:	41 5b                                           	pop    %r11
   a2021:	e9 ba fc f7 ff                                  	jmp    21ce0 <bson_free@plt>
   a2026:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a2030:	0f 18 3d 49 a1 f9 ff                            	prefetchit0 -0x65eb7(%rip)        # 3c180 <_mongoc_cursor_run_command>
   a2037:	0f 18 3d 84 a1 f9 ff                            	prefetchit0 -0x65e7c(%rip)        # 3c1c2 <_mongoc_cursor_run_command+0x42>
   a203e:	0f 18 3d 3b c5 f9 ff                            	prefetchit0 -0x63ac5(%rip)        # 3e580 <_mongoc_cursor_response_refresh>
   a2045:	e9 26 e6 f7 ff                                  	jmp    20670 <_mongoc_cursor_response_refresh@plt>
   a204a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a2050:	0f 18 3d a9 d8 f9 ff                            	prefetchit0 -0x62757(%rip)        # 3f900 <_pop_from_batch>
   a2057:	0f 18 3d a3 aa f9 ff                            	prefetchit0 -0x6555d(%rip)        # 3cb01 <mongoc_cursor_next+0xd1>
   a205e:	0f 18 3d 78 aa f9 ff                            	prefetchit0 -0x65588(%rip)        # 3cadd <mongoc_cursor_next+0xad>
   a2065:	0f 18 3d 47 aa f9 ff                            	prefetchit0 -0x655b9(%rip)        # 3cab3 <mongoc_cursor_next+0x83>
   a206c:	0f 18 3d 2d ab f9 ff                            	prefetchit0 -0x654d3(%rip)        # 3cba0 <mongoc_cursor_next+0x170>
   a2073:	e9 a8 fd f7 ff                                  	jmp    21e20 <bson_destroy@plt>
   a2078:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a2080:	0f 18 3d 49 f1 f7 ff                            	prefetchit0 -0x80eb7(%rip)        # 211d0 <mongoc_read_concern_is_default@plt>
   a2087:	e9 e4 07 f8 ff                                  	jmp    22870 <_mongoc_get_command_name@plt>
   a208c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2090:	41 53                                           	push   %r11
   a2092:	4c 8b 1d df c5 ff ff                            	mov    -0x3a21(%rip),%r11        # 9e678 <strlen@GLIBC_2.2.5>
   a2099:	41 0f 18 93 2a 15 00 00                         	prefetcht1 0x152a(%r11)
   a20a1:	41 0f 18 93 5c 17 00 00                         	prefetcht1 0x175c(%r11)
   a20a9:	41 0f 18 93 61 17 00 00                         	prefetcht1 0x1761(%r11)
   a20b1:	41 5b                                           	pop    %r11
   a20b3:	e9 18 f1 f7 ff                                  	jmp    211d0 <mongoc_read_concern_is_default@plt>
   a20b8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a20c0:	0f 18 3d 79 0a fd ff                            	prefetchit0 -0x2f587(%rip)        # 72b40 <_mongoc_write_concern_get_bson>
   a20c7:	0f 18 3d 12 0c fd ff                            	prefetchit0 -0x2f3ee(%rip)        # 72ce0 <mongoc_write_concern_is_acknowledged>
   a20ce:	41 53                                           	push   %r11
   a20d0:	4c 8b 1d b1 cf ff ff                            	mov    -0x304f(%rip),%r11        # 9f088 <strcasecmp@GLIBC_2.2.5>
   a20d7:	41 0f 18 93 e0 11 00 00                         	prefetcht1 0x11e0(%r11)
   a20df:	41 0f 18 93 12 12 00 00                         	prefetcht1 0x1212(%r11)
   a20e7:	41 0f 18 93 40 16 00 00                         	prefetcht1 0x1640(%r11)
   a20ef:	41 0f 18 93 53 16 00 00                         	prefetcht1 0x1653(%r11)
   a20f7:	41 5b                                           	pop    %r11
   a20f9:	e9 02 ff f7 ff                                  	jmp    22000 <strcasecmp@plt>
   a20fe:	66 90                                           	xchg   %ax,%ax
   a2100:	0f 18 3d 69 e7 fc ff                            	prefetchit0 -0x31897(%rip)        # 70870 <_mongoc_write_opmsg+0x520>
   a2107:	41 53                                           	push   %r11
   a2109:	4c 8b 1d 78 ce ff ff                            	mov    -0x3188(%rip),%r11        # 9ef88 <bson_reinit@Base>
   a2110:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
   a2118:	41 5b                                           	pop    %r11
   a211a:	e9 91 e5 f7 ff                                  	jmp    206b0 <mongoc_write_concern_is_acknowledged@plt>
   a211f:	90                                              	nop
   a2120:	0f 18 3d 79 ca fa ff                            	prefetchit0 -0x53587(%rip)        # 4eba0 <mongoc_cmd_parts_assemble>
   a2127:	0f 18 3d 92 ca fa ff                            	prefetchit0 -0x5356e(%rip)        # 4ebc0 <mongoc_cmd_parts_assemble+0x20>
   a212e:	0f 18 3d 13 cc fa ff                            	prefetchit0 -0x533ed(%rip)        # 4ed48 <mongoc_cmd_parts_assemble+0x1a8>
   a2135:	0f 18 3d c4 ca fa ff                            	prefetchit0 -0x5353c(%rip)        # 4ec00 <mongoc_cmd_parts_assemble+0x60>
   a213c:	e9 9f f8 f7 ff                                  	jmp    219e0 <bson_copy_to@plt>
   a2141:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a214b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
   a2150:	0f 18 3d 29 cc fa ff                            	prefetchit0 -0x533d7(%rip)        # 4ed80 <mongoc_cmd_parts_assemble+0x1e0>
   a2157:	41 53                                           	push   %r11
   a2159:	4c 8b 1d 70 c9 ff ff                            	mov    -0x3690(%rip),%r11        # 9ead0 <bson_has_field@Base>
   a2160:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2168:	41 0f 18 93 50 00 00 00                         	prefetcht1 0x50(%r11)
   a2170:	41 5b                                           	pop    %r11
   a2172:	e9 99 09 f8 ff                                  	jmp    22b10 <strcmp@plt>
   a2177:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
   a2180:	41 53                                           	push   %r11
   a2182:	4c 8b 1d 47 c9 ff ff                            	mov    -0x36b9(%rip),%r11        # 9ead0 <bson_has_field@Base>
   a2189:	41 0f 18 93 11 00 00 00                         	prefetcht1 0x11(%r11)
   a2191:	41 5b                                           	pop    %r11
   a2193:	e9 f8 f2 f7 ff                                  	jmp    21490 <bson_has_field@plt>
   a2198:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a21a0:	0f 18 3d 69 d6 fa ff                            	prefetchit0 -0x52997(%rip)        # 4f810 <mongoc_cmd_parts_assemble+0xc70>
   a21a7:	41 53                                           	push   %r11
   a21a9:	4c 8b 1d 38 d9 ff ff                            	mov    -0x26c8(%rip),%r11        # 9fae8 <bson_append_bool@Base>
   a21b0:	41 0f 18 93 00 e9 ff ff                         	prefetcht1 -0x1700(%r11)
   a21b8:	41 0f 18 93 42 e9 ff ff                         	prefetcht1 -0x16be(%r11)
   a21c0:	41 0f 18 93 83 e9 ff ff                         	prefetcht1 -0x167d(%r11)
   a21c8:	4c 8b 1d e1 d9 ff ff                            	mov    -0x261f(%rip),%r11        # 9fbb0 <bson_concat@Base>
   a21cf:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a21d7:	41 0f 18 93 12 00 00 00                         	prefetcht1 0x12(%r11)
   a21df:	41 5b                                           	pop    %r11
   a21e1:	e9 7a e9 f7 ff                                  	jmp    20b60 <_mongoc_client_session_in_txn@plt>
   a21e6:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a21f0:	41 53                                           	push   %r11
   a21f2:	4c 8b 1d 17 db ff ff                            	mov    -0x24e9(%rip),%r11        # 9fd10 <bson_append_document@Base>
   a21f9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2201:	41 5b                                           	pop    %r11
   a2203:	e9 28 04 f8 ff                                  	jmp    22630 <mongoc_client_session_get_lsid@plt>
   a2208:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a2210:	0f 18 3d 19 c9 fa ff                            	prefetchit0 -0x536e7(%rip)        # 4eb30 <_is_retryable_read>
   a2217:	0f 18 3d 22 d7 fa ff                            	prefetchit0 -0x528de(%rip)        # 4f940 <mongoc_cmd_parts_assemble+0xda0>
   a221e:	0f 18 3d 13 d7 fa ff                            	prefetchit0 -0x528ed(%rip)        # 4f938 <mongoc_cmd_parts_assemble+0xd98>
   a2225:	0f 18 3d 04 1b f8 ff                            	prefetchit0 -0x7e4fc(%rip)        # 23d30 <_mongoc_client_session_txn_in_progress@plt>
   a222c:	0f 18 3d 12 c9 fa ff                            	prefetchit0 -0x536ee(%rip)        # 4eb45 <_is_retryable_read+0x15>
   a2233:	0f 18 3d f2 d1 fa ff                            	prefetchit0 -0x52e0e(%rip)        # 4f42c <mongoc_cmd_parts_assemble+0x88c>
   a223a:	e9 61 e7 f7 ff                                  	jmp    209a0 <bson_get_monotonic_time@plt>
   a223f:	90                                              	nop
   a2240:	0f 18 3d 7a 89 fb ff                            	prefetchit0 -0x47686(%rip)        # 5abc1 <_mongoc_client_session_append_read_concern+0x61>
   a2247:	e9 f4 02 f8 ff                                  	jmp    22540 <mongoc_client_session_get_cluster_time@plt>
   a224c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2250:	0f 18 3d 29 89 fb ff                            	prefetchit0 -0x476d7(%rip)        # 5ab80 <_mongoc_client_session_append_read_concern+0x20>
   a2257:	0f 18 3d 63 89 fb ff                            	prefetchit0 -0x4769d(%rip)        # 5abc1 <_mongoc_client_session_append_read_concern+0x61>
   a225e:	0f 18 3d fb 88 fb ff                            	prefetchit0 -0x47705(%rip)        # 5ab60 <_mongoc_client_session_append_read_concern>
   a2265:	e9 56 0c f8 ff                                  	jmp    22ec0 <_mongoc_client_session_append_read_concern@plt>
   a226a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a2270:	0f 18 3d 09 df f8 ff                            	prefetchit0 -0x720f7(%rip)        # 30180 <mongoc_cluster_run_command_monitored>
   a2277:	0f 18 3d 42 df f8 ff                            	prefetchit0 -0x720be(%rip)        # 301c0 <mongoc_cluster_run_command_monitored+0x40>
   a227e:	e9 dd e8 f7 ff                                  	jmp    20b60 <_mongoc_client_session_in_txn@plt>
   a2283:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a228d:	0f 1f 00                                        	nopl   (%rax)
   a2290:	0f 18 3d 89 bb f8 ff                            	prefetchit0 -0x74477(%rip)        # 2de20 <mongoc_client_start_session>
   a2297:	e9 b4 13 f8 ff                                  	jmp    23650 <bson_concat@plt>
   a229c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a22a0:	0f 18 3d 99 9f fb ff                            	prefetchit0 -0x46067(%rip)        # 5c240 <mongoc_client_session_destroy>
   a22a7:	0f 18 3d 32 ea f7 ff                            	prefetchit0 -0x815ce(%rip)        # 20ce0 <mongoc_client_session_in_transaction@plt>
   a22ae:	e9 6d fb f7 ff                                  	jmp    21e20 <bson_destroy@plt>
   a22b3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a22bd:	0f 1f 00                                        	nopl   (%rax)
   a22c0:	0f 18 3d e9 d1 f8 ff                            	prefetchit0 -0x72e17(%rip)        # 2f4b0 <mongoc_cluster_run_opmsg+0x2e0>
   a22c7:	41 53                                           	push   %r11
   a22c9:	4c 8b 1d b8 cd ff ff                            	mov    -0x3248(%rip),%r11        # 9f088 <strcasecmp@GLIBC_2.2.5>
   a22d0:	41 0f 18 93 f0 0d 00 00                         	prefetcht1 0xdf0(%r11)
   a22d8:	41 0f 18 93 90 10 00 00                         	prefetcht1 0x1090(%r11)
   a22e0:	41 5b                                           	pop    %r11
   a22e2:	e9 19 fd f7 ff                                  	jmp    22000 <strcasecmp@plt>
   a22e7:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
   a22f0:	0f 18 3d 09 20 fb ff                            	prefetchit0 -0x4dff7(%rip)        # 54300 <mongoc_read_prefs_copy>
   a22f7:	41 53                                           	push   %r11
   a22f9:	4c 8b 1d a8 c5 ff ff                            	mov    -0x3a58(%rip),%r11        # 9e8a8 <bson_strdup@Base>
   a2300:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2308:	41 5b                                           	pop    %r11
   a230a:	e9 61 e1 f7 ff                                  	jmp    20470 <bson_init@plt>
   a230f:	90                                              	nop
   a2310:	0f 18 3d 39 14 f8 ff                            	prefetchit0 -0x7ebc7(%rip)        # 23750 <mongoc_set_add@plt>
   a2317:	41 53                                           	push   %r11
   a2319:	4c 8b 1d b0 c7 ff ff                            	mov    -0x3850(%rip),%r11        # 9ead0 <bson_has_field@Base>
   a2320:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2328:	41 0f 18 93 11 00 00 00                         	prefetcht1 0x11(%r11)
   a2330:	41 0f 18 93 50 00 00 00                         	prefetcht1 0x50(%r11)
   a2338:	41 5b                                           	pop    %r11
   a233a:	e9 31 e1 f7 ff                                  	jmp    20470 <bson_init@plt>
   a233f:	90                                              	nop
   a2340:	0f 18 3d 99 f6 f7 ff                            	prefetchit0 -0x80967(%rip)        # 219e0 <bson_copy_to@plt>
   a2347:	e9 14 ef f7 ff                                  	jmp    21260 <mongoc_read_prefs_new@plt>
   a234c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2350:	0f 18 3d 89 f6 f7 ff                            	prefetchit0 -0x80977(%rip)        # 219e0 <bson_copy_to@plt>
   a2357:	e9 c4 fa f7 ff                                  	jmp    21e20 <bson_destroy@plt>
   a235c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2360:	0f 18 3d 49 df f7 ff                            	prefetchit0 -0x820b7(%rip)        # 202b0 <bson_snprintf@plt>
   a2367:	0f 18 3d d3 a0 fb ff                            	prefetchit0 -0x45f2d(%rip)        # 5c441 <mongoc_set_add+0x11>
   a236e:	0f 18 3d bb a0 fb ff                            	prefetchit0 -0x45f45(%rip)        # 5c430 <mongoc_set_add>
   a2375:	41 53                                           	push   %r11
   a2377:	4c 8b 1d 62 be ff ff                            	mov    -0x419e(%rip),%r11        # 9e1e0 <bson_snprintf@Base>
   a237e:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2386:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
   a238e:	4c 8b 1d e3 c9 ff ff                            	mov    -0x361d(%rip),%r11        # 9ed78 <bson_copy_to@Base>
   a2395:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a239d:	4c 8b 1d 44 d7 ff ff                            	mov    -0x28bc(%rip),%r11        # 9fae8 <bson_append_bool@Base>
   a23a4:	41 0f 18 93 20 a9 ff ff                         	prefetcht1 -0x56e0(%r11)
   a23ac:	41 5b                                           	pop    %r11
   a23ae:	e9 2d f6 f7 ff                                  	jmp    219e0 <bson_copy_to@plt>
   a23b3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a23bd:	0f 1f 00                                        	nopl   (%rax)
   a23c0:	0f 18 3d b9 38 fb ff                            	prefetchit0 -0x4c747(%rip)        # 55c80 <_mongoc_rpc_swab_to_le>
   a23c7:	0f 18 3d ca 29 fb ff                            	prefetchit0 -0x4d636(%rip)        # 54d98 <_mongoc_rpc_gather+0x1d8>
   a23ce:	e9 fd df f7 ff                                  	jmp    203d0 <_mongoc_array_append_vals@plt>
   a23d3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a23dd:	0f 1f 00                                        	nopl   (%rax)
   a23e0:	0f 18 3d 69 d7 fa ff                            	prefetchit0 -0x52897(%rip)        # 4fb50 <mongoc_cmd_is_compressible>
   a23e7:	0f 18 3d 95 d7 fa ff                            	prefetchit0 -0x5286b(%rip)        # 4fb83 <mongoc_cmd_is_compressible+0x33>
   a23ee:	e9 dd df f7 ff                                  	jmp    203d0 <_mongoc_array_append_vals@plt>
   a23f3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a23fd:	0f 1f 00                                        	nopl   (%rax)
   a2400:	0f 18 3d 79 38 fb ff                            	prefetchit0 -0x4c787(%rip)        # 55c80 <_mongoc_rpc_swab_to_le>
   a2407:	e9 d4 e7 f7 ff                                  	jmp    20be0 <strlen@plt>
   a240c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2410:	0f 18 3d d9 81 fb ff                            	prefetchit0 -0x47e27(%rip)        # 5a5f0 <_mongoc_client_session_handle_reply>
   a2417:	0f 18 3d e3 81 fb ff                            	prefetchit0 -0x47e1d(%rip)        # 5a601 <_mongoc_client_session_handle_reply+0x11>
   a241e:	0f 18 3d f1 4e fb ff                            	prefetchit0 -0x4b10f(%rip)        # 57316 <_mongoc_cmd_check_ok+0xe6>
   a2425:	0f 18 3d 15 82 fb ff                            	prefetchit0 -0x47deb(%rip)        # 5a641 <_mongoc_client_session_handle_reply+0x51>
   a242c:	0f 18 3d 4d 15 f8 ff                            	prefetchit0 -0x7eab3(%rip)        # 23980 <mongoc_error_has_label@plt>
   a2433:	41 53                                           	push   %r11
   a2435:	4c 8b 1d 0c bc ff ff                            	mov    -0x43f4(%rip),%r11        # 9e048 <bson_iter_as_bool@Base>
   a243c:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2444:	4c 8b 1d 65 d8 ff ff                            	mov    -0x279b(%rip),%r11        # 9fcb0 <bson_iter_bool@Base>
   a244b:	41 0f 18 93 80 00 00 00                         	prefetcht1 0x80(%r11)
   a2453:	41 5b                                           	pop    %r11
   a2455:	e9 26 db f7 ff                                  	jmp    1ff80 <bson_iter_as_bool@plt>
   a245a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a2460:	41 53                                           	push   %r11
   a2462:	4c 8b 1d 0f c9 ff ff                            	mov    -0x36f1(%rip),%r11        # 9ed78 <bson_copy_to@Base>
   a2469:	41 0f 18 93 b2 00 00 00                         	prefetcht1 0xb2(%r11)
   a2471:	41 5b                                           	pop    %r11
   a2473:	e9 a8 f9 f7 ff                                  	jmp    21e20 <bson_destroy@plt>
   a2478:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a2480:	0f 18 3d fe 55 fb ff                            	prefetchit0 -0x4aa02(%rip)        # 57a85 <mongoc_server_description_reset+0x25>
   a2487:	e9 d4 ef f7 ff                                  	jmp    21460 <mongoc_server_description_reset@plt>
   a248c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2490:	41 53                                           	push   %r11
   a2492:	4c 8b 1d d7 d5 ff ff                            	mov    -0x2a29(%rip),%r11        # 9fa70 <bson_iter_init@Base>
   a2499:	41 0f 18 93 00 ff ff ff                         	prefetcht1 -0x100(%r11)
   a24a1:	41 5b                                           	pop    %r11
   a24a3:	e9 28 0f f8 ff                                  	jmp    233d0 <bson_iter_init@plt>
   a24a8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a24b0:	0f 18 3d 99 13 f8 ff                            	prefetchit0 -0x7ec67(%rip)        # 23850 <bson_iter_bool@plt>
   a24b7:	41 53                                           	push   %r11
   a24b9:	4c 8b 1d 50 d1 ff ff                            	mov    -0x2eb0(%rip),%r11        # 9f610 <strcmp@GLIBC_2.2.5>
   a24c0:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a24c8:	41 5b                                           	pop    %r11
   a24ca:	e9 51 05 f8 ff                                  	jmp    22a20 <bson_iter_next@plt>
   a24cf:	90                                              	nop
   a24d0:	0f 18 3d e9 5b fb ff                            	prefetchit0 -0x4a417(%rip)        # 580c0 <mongoc_server_description_update_rtt>
   a24d7:	0f 18 3d e2 6e fb ff                            	prefetchit0 -0x4911e(%rip)        # 593c0 <mongoc_server_stream_new>
   a24de:	0f 18 3d 5d 61 fb ff                            	prefetchit0 -0x49ea3(%rip)        # 58642 <mongoc_server_description_handle_ismaster+0x532>
   a24e5:	e9 96 da f7 ff                                  	jmp    1ff80 <bson_iter_as_bool@plt>
   a24ea:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a24f0:	41 53                                           	push   %r11
   a24f2:	4c 8b 1d 17 d1 ff ff                            	mov    -0x2ee9(%rip),%r11        # 9f610 <strcmp@GLIBC_2.2.5>
   a24f9:	41 0f 18 93 42 03 00 00                         	prefetcht1 0x342(%r11)
   a2501:	4c 8b 1d a8 d7 ff ff                            	mov    -0x2858(%rip),%r11        # 9fcb0 <bson_iter_bool@Base>
   a2508:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2510:	41 5b                                           	pop    %r11
   a2512:	e9 a9 07 f8 ff                                  	jmp    22cc0 <bson_iter_key@plt>
   a2517:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
   a2520:	41 53                                           	push   %r11
   a2522:	4c 8b 1d 87 d7 ff ff                            	mov    -0x2879(%rip),%r11        # 9fcb0 <bson_iter_bool@Base>
   a2529:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2531:	41 5b                                           	pop    %r11
   a2533:	e9 b8 ee f7 ff                                  	jmp    213f0 <bson_iter_type@plt>
   a2538:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a2540:	41 53                                           	push   %r11
   a2542:	4c 8b 1d 67 d7 ff ff                            	mov    -0x2899(%rip),%r11        # 9fcb0 <bson_iter_bool@Base>
   a2549:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2551:	41 5b                                           	pop    %r11
   a2553:	e9 f8 12 f8 ff                                  	jmp    23850 <bson_iter_bool@plt>
   a2558:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a2560:	0f 18 3d dc 5e fb ff                            	prefetchit0 -0x4a124(%rip)        # 58443 <mongoc_server_description_handle_ismaster+0x333>
   a2567:	e9 a4 05 f8 ff                                  	jmp    22b10 <strcmp@plt>
   a256c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2570:	0f 18 3d 66 60 fb ff                            	prefetchit0 -0x49f9a(%rip)        # 585dd <mongoc_server_description_handle_ismaster+0x4cd>
   a2577:	e9 94 05 f8 ff                                  	jmp    22b10 <strcmp@plt>
   a257c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2580:	0f 18 3d 0f 61 fb ff                            	prefetchit0 -0x49ef1(%rip)        # 58696 <mongoc_server_description_handle_ismaster+0x586>
   a2587:	e9 84 05 f8 ff                                  	jmp    22b10 <strcmp@plt>
   a258c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2590:	41 53                                           	push   %r11
   a2592:	4c 8b 1d 67 d4 ff ff                            	mov    -0x2b99(%rip),%r11        # 9fa00 <bson_iter_as_int64@Base>
   a2599:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a25a1:	4c 8b 1d 40 d5 ff ff                            	mov    -0x2ac0(%rip),%r11        # 9fae8 <bson_append_bool@Base>
   a25a8:	41 0f 18 93 50 a7 ff ff                         	prefetcht1 -0x58b0(%r11)
   a25b0:	41 5b                                           	pop    %r11
   a25b2:	e9 39 ee f7 ff                                  	jmp    213f0 <bson_iter_type@plt>
   a25b7:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
   a25c0:	0f 18 3d 87 61 fb ff                            	prefetchit0 -0x49e79(%rip)        # 5874e <mongoc_server_description_handle_ismaster+0x63e>
   a25c7:	e9 f4 06 f8 ff                                  	jmp    22cc0 <bson_iter_key@plt>
   a25cc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a25d0:	0f 18 3d 6a 64 fb ff                            	prefetchit0 -0x49b96(%rip)        # 58a41 <mongoc_server_description_handle_ismaster+0x931>
   a25d7:	e9 34 05 f8 ff                                  	jmp    22b10 <strcmp@plt>
   a25dc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a25e0:	0f 18 3d 06 66 fb ff                            	prefetchit0 -0x499fa(%rip)        # 58bed <mongoc_server_description_handle_ismaster+0xadd>
   a25e7:	e9 24 05 f8 ff                                  	jmp    22b10 <strcmp@plt>
   a25ec:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a25f0:	0f 18 3d 89 d9 f7 ff                            	prefetchit0 -0x82677(%rip)        # 1ff80 <bson_iter_as_bool@plt>
   a25f7:	41 53                                           	push   %r11
   a25f9:	4c 8b 1d 70 d4 ff ff                            	mov    -0x2b90(%rip),%r11        # 9fa70 <bson_iter_init@Base>
   a2600:	41 0f 18 93 71 ff ff ff                         	prefetcht1 -0x8f(%r11)
   a2608:	41 5b                                           	pop    %r11
   a260a:	e9 b1 06 f8 ff                                  	jmp    22cc0 <bson_iter_key@plt>
   a260f:	90                                              	nop
   a2610:	0f 18 3d 49 54 fb ff                            	prefetchit0 -0x4abb7(%rip)        # 57a60 <mongoc_server_description_reset>
   a2617:	0f 18 3d a5 54 fb ff                            	prefetchit0 -0x4ab5b(%rip)        # 57ac3 <mongoc_server_description_reset+0x63>
   a261e:	0f 18 3d 20 5b fb ff                            	prefetchit0 -0x4a4e0(%rip)        # 58145 <mongoc_server_description_handle_ismaster+0x35>
   a2625:	e9 46 de f7 ff                                  	jmp    20470 <bson_init@plt>
   a262a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a2630:	0f 18 3d 19 66 f9 ff                            	prefetchit0 -0x699e7(%rip)        # 38c50 <mongoc_collection_get_name>
   a2637:	0f 18 3d 8b bf fa ff                            	prefetchit0 -0x54075(%rip)        # 4e5c9 <mongoc_cmd_parts_append_opts+0x59>
   a263e:	0f 18 3d c0 f6 f8 ff                            	prefetchit0 -0x70940(%rip)        # 31d05 <_mongoc_cluster_stream_for_server+0x145>
   a2645:	e9 a6 02 f8 ff                                  	jmp    228f0 <bson_malloc@plt>
   a264a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a2650:	0f 18 3d 59 53 fb ff                            	prefetchit0 -0x4aca7(%rip)        # 579b0 <mongoc_server_description_cleanup>
   a2657:	0f 18 3d 66 53 fb ff                            	prefetchit0 -0x4ac9a(%rip)        # 579c4 <mongoc_server_description_cleanup+0x14>
   a265e:	0f 18 3d 0b 57 fb ff                            	prefetchit0 -0x4a8f5(%rip)        # 57d70 <mongoc_server_description_destroy>
   a2665:	0f 18 3d 16 57 fb ff                            	prefetchit0 -0x4a8ea(%rip)        # 57d82 <mongoc_server_description_destroy+0x12>
   a266c:	41 53                                           	push   %r11
   a266e:	4c 8b 1d 23 c9 ff ff                            	mov    -0x36dd(%rip),%r11        # 9ef98 <bson_destroy@Base>
   a2675:	41 0f 18 93 20 00 00 00                         	prefetcht1 0x20(%r11)
   a267d:	4c 8b 1d 64 d4 ff ff                            	mov    -0x2b9c(%rip),%r11        # 9fae8 <bson_append_bool@Base>
   a2684:	41 0f 18 93 20 a1 ff ff                         	prefetcht1 -0x5ee0(%r11)
   a268c:	41 5b                                           	pop    %r11
   a268e:	e9 2d 12 f8 ff                                  	jmp    238c0 <mongoc_server_description_destroy@plt>
   a2693:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a269d:	0f 1f 00                                        	nopl   (%rax)
   a26a0:	0f 18 3d 59 d4 fa ff                            	prefetchit0 -0x52ba7(%rip)        # 4fb00 <mongoc_cmd_parts_cleanup>
   a26a7:	0f 18 3d e2 d2 fc ff                            	prefetchit0 -0x32d1e(%rip)        # 6f990 <_mongoc_write_result_complete>
   a26ae:	0f 18 3d 4b 4d f9 ff                            	prefetchit0 -0x6b2b5(%rip)        # 37400 <mongoc_collection_insert_one+0x130>
   a26b5:	0f 18 3d 08 d3 fc ff                            	prefetchit0 -0x32cf8(%rip)        # 6f9c4 <_mongoc_write_result_complete+0x34>
   a26bc:	e9 5f f7 f7 ff                                  	jmp    21e20 <bson_destroy@plt>
   a26c1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a26cb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
   a26d0:	0f 18 3d ea fd fc ff                            	prefetchit0 -0x30216(%rip)        # 724c1 <mongoc_write_concern_copy+0x11>
   a26d7:	0f 18 3d 92 fd fc ff                            	prefetchit0 -0x3026e(%rip)        # 72470 <mongoc_write_concern_new>
   a26de:	e9 ad d8 f7 ff                                  	jmp    1ff90 <mongoc_write_concern_destroy@plt>
   a26e3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a26ed:	0f 1f 00                                        	nopl   (%rax)
   a26f0:	0f 18 3d 0b 17 fb ff                            	prefetchit0 -0x4e8f5(%rip)        # 53e02 <mongoc_read_prefs_new+0x12>
   a26f7:	e9 24 f8 f7 ff                                  	jmp    21f20 <mongoc_read_prefs_copy@plt>
   a26fc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2700:	0f 18 3d d9 72 fb ff                            	prefetchit0 -0x48d27(%rip)        # 599e0 <mongoc_session_opts_set_causal_consistency>
   a2707:	e9 74 11 f8 ff                                  	jmp    23880 <bson_malloc0@plt>
   a270c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2710:	0f 18 3d 09 b7 f8 ff                            	prefetchit0 -0x748f7(%rip)        # 2de20 <mongoc_client_start_session>
   a2717:	e9 24 0a f8 ff                                  	jmp    23140 <mongoc_session_opts_set_causal_consistency@plt>
   a271c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2720:	0f 18 3d 79 12 fb ff                            	prefetchit0 -0x4ed87(%rip)        # 539a0 <mongoc_read_concern_new>
   a2727:	0f 18 3d a2 12 fb ff                            	prefetchit0 -0x4ed5e(%rip)        # 539d0 <mongoc_read_concern_copy>
   a272e:	e9 3d dd f7 ff                                  	jmp    20470 <bson_init@plt>
   a2733:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a273d:	0f 1f 00                                        	nopl   (%rax)
   a2740:	0f 18 3d 39 06 fa ff                            	prefetchit0 -0x5f9c7(%rip)        # 42d80 <mongoc_error_has_label>
   a2747:	0f 18 3d 73 06 fa ff                            	prefetchit0 -0x5f98d(%rip)        # 42dc1 <mongoc_error_has_label+0x41>
   a274e:	0f 18 3d 2b 12 f8 ff                            	prefetchit0 -0x7edd5(%rip)        # 23980 <mongoc_error_has_label@plt>
   a2755:	e9 76 0c f8 ff                                  	jmp    233d0 <bson_iter_init@plt>
   a275a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a2760:	0f 18 3d a9 03 f8 ff                            	prefetchit0 -0x7fc57(%rip)        # 22b10 <strcmp@plt>
   a2767:	41 53                                           	push   %r11
   a2769:	4c 8b 1d a0 ce ff ff                            	mov    -0x3160(%rip),%r11        # 9f610 <strcmp@GLIBC_2.2.5>
   a2770:	41 0f 18 93 95 03 00 00                         	prefetcht1 0x395(%r11)
   a2778:	41 5b                                           	pop    %r11
   a277a:	e9 a1 02 f8 ff                                  	jmp    22a20 <bson_iter_next@plt>
   a277f:	90                                              	nop
   a2780:	41 53                                           	push   %r11
   a2782:	4c 8b 1d ef be ff ff                            	mov    -0x4111(%rip),%r11        # 9e678 <strlen@GLIBC_2.2.5>
   a2789:	41 0f 18 93 a1 fb ff ff                         	prefetcht1 -0x45f(%r11)
   a2791:	4c 8b 1d 78 ce ff ff                            	mov    -0x3188(%rip),%r11        # 9f610 <strcmp@GLIBC_2.2.5>
   a2798:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a27a0:	41 0f 18 93 42 03 00 00                         	prefetcht1 0x342(%r11)
   a27a8:	41 0f 18 93 95 03 00 00                         	prefetcht1 0x395(%r11)
   a27b0:	41 0f 18 93 c6 03 00 00                         	prefetcht1 0x3c6(%r11)
   a27b8:	41 5b                                           	pop    %r11
   a27ba:	e9 51 03 f8 ff                                  	jmp    22b10 <strcmp@plt>
   a27bf:	90                                              	nop
   a27c0:	41 53                                           	push   %r11
   a27c2:	4c 8b 1d 37 cd ff ff                            	mov    -0x32c9(%rip),%r11        # 9f500 <bson_malloc@Base>
   a27c9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a27d1:	41 5b                                           	pop    %r11
   a27d3:	e9 38 03 f8 ff                                  	jmp    22b10 <strcmp@plt>
   a27d8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a27e0:	0f 18 3d 39 fd fc ff                            	prefetchit0 -0x302c7(%rip)        # 72520 <mongoc_write_concern_destroy>
   a27e7:	e9 e4 03 f8 ff                                  	jmp    22bd0 <mongoc_read_concern_destroy@plt>
   a27ec:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a27f0:	0f 18 3d d9 1a fb ff                            	prefetchit0 -0x4e527(%rip)        # 542d0 <mongoc_read_prefs_destroy>
   a27f7:	e9 94 d7 f7 ff                                  	jmp    1ff90 <mongoc_write_concern_destroy@plt>
   a27fc:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2800:	0f 18 3d ca d1 f9 ff                            	prefetchit0 -0x62e36(%rip)        # 3f9d1 <_prime+0x81>
   a2807:	0f 18 3d 92 6c fb ff                            	prefetchit0 -0x4936e(%rip)        # 594a0 <mongoc_server_stream_cleanup>
   a280e:	0f 18 3d 88 11 f9 ff                            	prefetchit0 -0x6ee78(%rip)        # 3399d <_mongoc_collection_write_command_execute_idl+0xbd>
   a2815:	e9 06 f6 f7 ff                                  	jmp    21e20 <bson_destroy@plt>
   a281a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a2820:	0f 18 3d d9 b6 f8 ff                            	prefetchit0 -0x74927(%rip)        # 2df00 <_mongoc_client_unregister_session>
   a2827:	e9 b4 e4 f7 ff                                  	jmp    20ce0 <mongoc_client_session_in_transaction@plt>
   a282c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2830:	0f 18 3d b9 77 fb ff                            	prefetchit0 -0x48847(%rip)        # 59ff0 <_mongoc_server_session_timed_out>
   a2837:	0f 18 3d 22 f0 f7 ff                            	prefetchit0 -0x80fde(%rip)        # 21860 <mongoc_set_rm@plt>
   a283e:	0f 18 3d db 9c fb ff                            	prefetchit0 -0x46325(%rip)        # 5c520 <mongoc_set_rm+0x60>
   a2845:	41 53                                           	push   %r11
   a2847:	4c 8b 1d 0a bd ff ff                            	mov    -0x42f6(%rip),%r11        # 9e558 <bson_get_monotonic_time@Base>
   a284e:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2856:	41 5b                                           	pop    %r11
   a2858:	e9 03 ee f7 ff                                  	jmp    21660 <_mongoc_client_unregister_session@plt>
   a285d:	0f 1f 00                                        	nopl   (%rax)
   a2860:	0f 18 3d 67 42 f8 ff                            	prefetchit0 -0x7bd99(%rip)        # 26ace <_mongoc_buffer_fill+0xde>
   a2867:	0f 18 3d 80 bc fb ff                            	prefetchit0 -0x44380(%rip)        # 5e4ee <mongoc_stream_buffered_readv+0xde>
   a286e:	0f 18 3d 6b 09 f8 ff                            	prefetchit0 -0x7f695(%rip)        # 231e0 <memmove@plt>
   a2875:	0f 18 3d 84 bc fb ff                            	prefetchit0 -0x4437c(%rip)        # 5e500 <mongoc_stream_buffered_readv+0xf0>
   a287c:	0f 18 3d 4d f0 f7 ff                            	prefetchit0 -0x80fb3(%rip)        # 218d0 <memcpy@plt>
   a2883:	0f 18 3d 9d c7 fb ff                            	prefetchit0 -0x43863(%rip)        # 5f027 <mongoc_stream_read+0x47>
   a288a:	0f 18 3d 1c e2 fb ff                            	prefetchit0 -0x41de4(%rip)        # 60aad <_mongoc_stream_socket_readv+0x6d>
   a2891:	0f 18 3d fd ca f8 ff                            	prefetchit0 -0x73503(%rip)        # 2f395 <mongoc_cluster_run_opmsg+0x1c5>
   a2898:	e9 13 e0 f7 ff                                  	jmp    208b0 <recv@plt>
   a289d:	0f 1f 00                                        	nopl   (%rax)
   a28a0:	0f 18 3d 1d b5 fb ff                            	prefetchit0 -0x44ae3(%rip)        # 5ddc4 <mongoc_socket_sendv+0x294>
   a28a7:	e9 24 f0 f7 ff                                  	jmp    218d0 <memcpy@plt>
   a28ac:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a28b0:	0f 18 3d 19 a8 fb ff                            	prefetchit0 -0x457e7(%rip)        # 5d0d0 <mongoc_socket_errno>
   a28b7:	0f 18 3d 43 3f f8 ff                            	prefetchit0 -0x7c0bd(%rip)        # 26801 <_mongoc_buffer_append_from_stream+0x31>
   a28be:	0f 18 3d 0b 3f f8 ff                            	prefetchit0 -0x7c0f5(%rip)        # 267d0 <_mongoc_buffer_append_from_stream>
   a28c5:	0f 18 3d 14 c7 fb ff                            	prefetchit0 -0x438ec(%rip)        # 5efe0 <mongoc_stream_read>
   a28cc:	41 53                                           	push   %r11
   a28ce:	4c 8b 1d b3 b7 ff ff                            	mov    -0x484d(%rip),%r11        # 9e088 <__errno_location@GLIBC_2.2.5>
   a28d5:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a28dd:	41 5b                                           	pop    %r11
   a28df:	e9 fc f3 f7 ff                                  	jmp    21ce0 <bson_free@plt>
   a28e4:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a28ee:	66 90                                           	xchg   %ax,%ax
   a28f0:	0f 18 3d 19 bb fb ff                            	prefetchit0 -0x444e7(%rip)        # 5e410 <mongoc_stream_buffered_readv>
   a28f7:	0f 18 3d c2 d6 f7 ff                            	prefetchit0 -0x8293e(%rip)        # 1ffc0 <mongoc_stream_read@plt>
   a28fe:	0f 18 3d fb ea f7 ff                            	prefetchit0 -0x81505(%rip)        # 21400 <mongoc_stream_readv@plt>
   a2905:	0f 18 3d d4 c6 fb ff                            	prefetchit0 -0x4392c(%rip)        # 5efe0 <mongoc_stream_read>
   a290c:	41 53                                           	push   %r11
   a290e:	4c 8b 1d db c3 ff ff                            	mov    -0x3c25(%rip),%r11        # 9ecf0 <memcpy@GLIBC_2.14>
   a2915:	41 0f 18 93 50 03 00 00                         	prefetcht1 0x350(%r11)
   a291d:	41 5b                                           	pop    %r11
   a291f:	e9 ac ef f7 ff                                  	jmp    218d0 <memcpy@plt>
   a2924:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a292e:	66 90                                           	xchg   %ax,%ax
   a2930:	0f 18 3d 1f 3f f8 ff                            	prefetchit0 -0x7c0e1(%rip)        # 26856 <_mongoc_buffer_append_from_stream+0x86>
   a2937:	e9 a4 08 f8 ff                                  	jmp    231e0 <memmove@plt>
   a293c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2940:	0f 18 3d fe b1 fb ff                            	prefetchit0 -0x44e02(%rip)        # 5db45 <mongoc_socket_sendv+0x15>
   a2947:	0f 18 3d e2 b1 fb ff                            	prefetchit0 -0x44e1e(%rip)        # 5db30 <mongoc_socket_sendv>
   a294e:	0f 18 3d 2c b2 fb ff                            	prefetchit0 -0x44dd4(%rip)        # 5db81 <mongoc_socket_sendv+0x51>
   a2955:	e9 26 db f7 ff                                  	jmp    20480 <mongoc_stream_writev@plt>
   a295a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a2960:	0f 18 3d 59 a0 fb ff                            	prefetchit0 -0x45fa7(%rip)        # 5c9c0 <_mongoc_socket_wait.constprop.0>
   a2967:	0f 18 3d 92 a0 fb ff                            	prefetchit0 -0x45f6e(%rip)        # 5ca00 <_mongoc_socket_wait.constprop.0+0x40>
   a296e:	e9 2d e0 f7 ff                                  	jmp    209a0 <bson_get_monotonic_time@plt>
   a2973:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a297d:	0f 1f 00                                        	nopl   (%rax)
   a2980:	0f 18 3d fc 17 fc ff                            	prefetchit0 -0x3e804(%rip)        # 64183 <mongoc_topology_description_select+0x13>
   a2987:	0f 18 3d e2 17 fc ff                            	prefetchit0 -0x3e81e(%rip)        # 64170 <mongoc_topology_description_select>
   a298e:	0f 18 3d 5b f3 fb ff                            	prefetchit0 -0x40ca5(%rip)        # 61cf0 <mongoc_topology_compatible>
   a2995:	0f 18 3d 65 f3 fb ff                            	prefetchit0 -0x40c9b(%rip)        # 61d01 <mongoc_topology_compatible+0x11>
   a299c:	0f 18 3d cd dd f7 ff                            	prefetchit0 -0x82233(%rip)        # 20770 <mongoc_topology_description_select@plt>
   a29a3:	0f 18 3d a6 eb f7 ff                            	prefetchit0 -0x8145a(%rip)        # 21550 <mongoc_topology_compatible@plt>
   a29aa:	e9 c1 df f7 ff                                  	jmp    20970 <mongoc_topology_scanner_valid@plt>
   a29af:	90                                              	nop
   a29b0:	0f 18 3d 49 02 f9 ff                            	prefetchit0 -0x6fdb7(%rip)        # 32c00 <mongoc_cluster_check_interval>
   a29b7:	0f 18 3d 88 02 f9 ff                            	prefetchit0 -0x6fd78(%rip)        # 32c46 <mongoc_cluster_check_interval+0x46>
   a29be:	0f 18 3d fb f1 f8 ff                            	prefetchit0 -0x70e05(%rip)        # 31bc0 <_mongoc_cluster_stream_for_server>
   a29c5:	0f 18 3d d4 d6 f7 ff                            	prefetchit0 -0x8292c(%rip)        # 200a0 <_mongoc_cluster_stream_for_server@plt>
   a29cc:	0f 18 3d 2d 9c fb ff                            	prefetchit0 -0x463d3(%rip)        # 5c600 <mongoc_set_get_item>
   a29d3:	0f 18 3d c6 9b fb ff                            	prefetchit0 -0x4643a(%rip)        # 5c5a0 <mongoc_set_get>
   a29da:	0f 18 3d bf 0a f8 ff                            	prefetchit0 -0x7f541(%rip)        # 234a0 <mongoc_cluster_check_interval@plt>
   a29e1:	0f 18 3d db 9b fb ff                            	prefetchit0 -0x46425(%rip)        # 5c5c3 <mongoc_set_get+0x23>
   a29e8:	e9 83 dd f7 ff                                  	jmp    20770 <mongoc_topology_description_select@plt>
   a29ed:	0f 1f 00                                        	nopl   (%rax)
   a29f0:	0f 18 3d 69 3c fc ff                            	prefetchit0 -0x3c397(%rip)        # 66660 <mongoc_topology_scanner_get_node>
   a29f7:	0f 18 3d 52 fc fb ff                            	prefetchit0 -0x403ae(%rip)        # 62650 <mongoc_topology_server_timestamp>
   a29fe:	e9 2d ec f7 ff                                  	jmp    21630 <pthread_mutex_unlock@plt>
   a2a03:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a2a0d:	0f 1f 00                                        	nopl   (%rax)
   a2a10:	0f 18 3d 79 f8 f8 ff                            	prefetchit0 -0x70787(%rip)        # 32290 <_mongoc_cluster_stream_for_server+0x6d0>
   a2a17:	0f 18 3d f2 dd f8 ff                            	prefetchit0 -0x7220e(%rip)        # 30810 <_mongoc_cluster_create_server_stream>
   a2a1e:	0f 18 3d fb de f7 ff                            	prefetchit0 -0x82105(%rip)        # 20920 <mongoc_topology_description_server_by_id@plt>
   a2a25:	0f 18 3d b4 05 f8 ff                            	prefetchit0 -0x7fa4c(%rip)        # 22fe0 <mongoc_server_description_new_copy@plt>
   a2a2c:	0f 18 3d 8e 62 fb ff                            	prefetchit0 -0x49d72(%rip)        # 58cc1 <mongoc_server_description_new_copy+0x11>
   a2a33:	0f 18 3d f6 09 f8 ff                            	prefetchit0 -0x7f60a(%rip)        # 23430 <_mongoc_cluster_create_server_stream@plt>
   a2a3a:	0f 18 3d 6f 62 fb ff                            	prefetchit0 -0x49d91(%rip)        # 58cb0 <mongoc_server_description_new_copy>
   a2a41:	e9 ca 02 f8 ff                                  	jmp    22d10 <pthread_mutex_lock@plt>
   a2a46:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a2a50:	0f 18 3d 2a 18 f9 ff                            	prefetchit0 -0x6e7d6(%rip)        # 34281 <_mongoc_collection_new+0x21>
   a2a57:	e9 b4 02 f8 ff                                  	jmp    22d10 <pthread_mutex_lock@plt>
   a2a5c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2a60:	0f 18 3d 5a 1f fc ff                            	prefetchit0 -0x3e0a6(%rip)        # 649c1 <mongoc_topology_description_update_cluster_time+0x41>
   a2a67:	41 53                                           	push   %r11
   a2a69:	4c 8b 1d 70 bb ff ff                            	mov    -0x4490(%rip),%r11        # 9e5e0 <bson_iter_init_find@Base>
   a2a70:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
   a2a78:	41 0f 18 93 52 00 00 00                         	prefetcht1 0x52(%r11)
   a2a80:	4c 8b 1d f1 bb ff ff                            	mov    -0x440f(%rip),%r11        # 9e678 <strlen@GLIBC_2.2.5>
   a2a87:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2a8f:	4c 8b 1d 02 cb ff ff                            	mov    -0x34fe(%rip),%r11        # 9f598 <bson_iter_next@Base>
   a2a96:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2a9e:	4c 8b 1d cb cf ff ff                            	mov    -0x3035(%rip),%r11        # 9fa70 <bson_iter_init@Base>
   a2aa5:	41 0f 18 93 22 fc ff ff                         	prefetcht1 -0x3de(%r11)
   a2aad:	4c 8b 1d 34 d0 ff ff                            	mov    -0x2fcc(%rip),%r11        # 9fae8 <bson_append_bool@Base>
   a2ab4:	41 0f 18 93 b0 a5 ff ff                         	prefetcht1 -0x5a50(%r11)
   a2abc:	41 0f 18 93 a0 a8 ff ff                         	prefetcht1 -0x5760(%r11)
   a2ac4:	41 5b                                           	pop    %r11
   a2ac6:	e9 45 02 f8 ff                                  	jmp    22d10 <pthread_mutex_lock@plt>
   a2acb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
   a2ad0:	41 53                                           	push   %r11
   a2ad2:	4c 8b 1d bf ca ff ff                            	mov    -0x3541(%rip),%r11        # 9f598 <bson_iter_next@Base>
   a2ad9:	41 0f 18 93 50 00 00 00                         	prefetcht1 0x50(%r11)
   a2ae1:	4c 8b 1d 88 cf ff ff                            	mov    -0x3078(%rip),%r11        # 9fa70 <bson_iter_init@Base>
   a2ae8:	41 0f 18 93 f0 fd ff ff                         	prefetcht1 -0x210(%r11)
   a2af0:	41 5b                                           	pop    %r11
   a2af2:	e9 99 f4 f7 ff                                  	jmp    21f90 <mongoc_topology_description_update_cluster_time@plt>
   a2af7:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
   a2b00:	0f 18 3d 19 f3 f7 ff                            	prefetchit0 -0x80ce7(%rip)        # 21e20 <bson_destroy@plt>
   a2b07:	0f 18 3d d2 48 fc ff                            	prefetchit0 -0x3b72e(%rip)        # 673e0 <_mongoc_topology_scanner_set_cluster_time>
   a2b0e:	41 53                                           	push   %r11
   a2b10:	4c 8b 1d 81 c4 ff ff                            	mov    -0x3b7f(%rip),%r11        # 9ef98 <bson_destroy@Base>
   a2b17:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2b1f:	41 5b                                           	pop    %r11
   a2b21:	e9 6a 07 f8 ff                                  	jmp    23290 <_mongoc_topology_scanner_set_cluster_time@plt>
   a2b26:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a2b30:	0f 18 3d 99 9a fc ff                            	prefetchit0 -0x36567(%rip)        # 6c5d0 <_mongoc_rand_simple>
   a2b37:	41 53                                           	push   %r11
   a2b39:	4c 8b 1d 08 c4 ff ff                            	mov    -0x3bf8(%rip),%r11        # 9ef48 <rand_r@GLIBC_2.2.5>
   a2b40:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2b48:	41 0f 18 93 41 00 00 00                         	prefetcht1 0x41(%r11)
   a2b50:	41 5b                                           	pop    %r11
   a2b52:	e9 79 f1 f7 ff                                  	jmp    21cd0 <_mongoc_server_session_timed_out@plt>
   a2b57:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
   a2b60:	0f 18 3d a9 0e fb ff                            	prefetchit0 -0x4f157(%rip)        # 53a10 <mongoc_read_concern_destroy>
   a2b67:	e9 64 f1 f7 ff                                  	jmp    21cd0 <_mongoc_server_session_timed_out@plt>
   a2b6c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2b70:	41 53                                           	push   %r11
   a2b72:	4c 8b 1d 67 ba ff ff                            	mov    -0x4599(%rip),%r11        # 9e5e0 <bson_iter_init_find@Base>
   a2b79:	41 0f 18 93 70 ff ff ff                         	prefetcht1 -0x90(%r11)
   a2b81:	4c 8b 1d c0 bd ff ff                            	mov    -0x4240(%rip),%r11        # 9e948 <bson_get_data@Base>
   a2b88:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2b90:	4c 8b 1d d9 ce ff ff                            	mov    -0x3127(%rip),%r11        # 9fa70 <bson_iter_init@Base>
   a2b97:	41 0f 18 93 10 fc ff ff                         	prefetcht1 -0x3f0(%r11)
   a2b9f:	41 0f 18 93 62 fc ff ff                         	prefetcht1 -0x39e(%r11)
   a2ba7:	4c 8b 1d 3a cf ff ff                            	mov    -0x30c6(%rip),%r11        # 9fae8 <bson_append_bool@Base>
   a2bae:	41 0f 18 93 60 a1 ff ff                         	prefetcht1 -0x5ea0(%r11)
   a2bb6:	41 0f 18 93 40 a4 ff ff                         	prefetcht1 -0x5bc0(%r11)
   a2bbe:	41 0f 18 93 b0 a4 ff ff                         	prefetcht1 -0x5b50(%r11)
   a2bc6:	41 0f 18 93 90 a7 ff ff                         	prefetcht1 -0x5870(%r11)
   a2bce:	41 5b                                           	pop    %r11
   a2bd0:	e9 db de f7 ff                                  	jmp    20ab0 <bson_iter_init_find@plt>
   a2bd5:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a2bdf:	90                                              	nop
   a2be0:	0f 18 3d 49 46 fb ff                            	prefetchit0 -0x4b9b7(%rip)        # 57230 <_mongoc_cmd_check_ok>
   a2be7:	0f 18 3d 53 46 fb ff                            	prefetchit0 -0x4b9ad(%rip)        # 57241 <_mongoc_cmd_check_ok+0x11>
   a2bee:	0f 18 3d 8d 46 fb ff                            	prefetchit0 -0x4b973(%rip)        # 57282 <_mongoc_cmd_check_ok+0x52>
   a2bf5:	41 53                                           	push   %r11
   a2bf7:	4c 8b 1d a2 bf ff ff                            	mov    -0x405e(%rip),%r11        # 9eba0 <pthread_mutex_unlock@GLIBC_2.2.5>
   a2bfe:	41 0f 18 93 12 00 00 00                         	prefetcht1 0x12(%r11)
   a2c06:	4c 8b 1d 6b c1 ff ff                            	mov    -0x3e95(%rip),%r11        # 9ed78 <bson_copy_to@Base>
   a2c0d:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2c15:	41 5b                                           	pop    %r11
   a2c17:	e9 04 f2 f7 ff                                  	jmp    21e20 <bson_destroy@plt>
   a2c1c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2c20:	0f 18 3d e9 64 fc ff                            	prefetchit0 -0x39b17(%rip)        # 69110 <mongoc_uri_get_options>
   a2c27:	41 53                                           	push   %r11
   a2c29:	4c 8b 1d 58 c4 ff ff                            	mov    -0x3ba8(%rip),%r11        # 9f088 <strcasecmp@GLIBC_2.2.5>
   a2c30:	41 0f 18 93 52 06 00 00                         	prefetcht1 0x652(%r11)
   a2c38:	41 5b                                           	pop    %r11
   a2c3a:	e9 c1 f3 f7 ff                                  	jmp    22000 <strcasecmp@plt>
   a2c3f:	90                                              	nop
   a2c40:	0f 18 3d e9 be fa ff                            	prefetchit0 -0x54117(%rip)        # 4eb30 <_is_retryable_read>
   a2c47:	0f 18 3d f7 be fa ff                            	prefetchit0 -0x54109(%rip)        # 4eb45 <_is_retryable_read+0x15>
   a2c4e:	41 53                                           	push   %r11
   a2c50:	4c 8b 1d 31 c4 ff ff                            	mov    -0x3bcf(%rip),%r11        # 9f088 <strcasecmp@GLIBC_2.2.5>
   a2c57:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2c5f:	41 5b                                           	pop    %r11
   a2c61:	e9 ba fd f7 ff                                  	jmp    22a20 <bson_iter_next@plt>
   a2c66:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a2c70:	41 53                                           	push   %r11
   a2c72:	4c 8b 1d 0f c4 ff ff                            	mov    -0x3bf1(%rip),%r11        # 9f088 <strcasecmp@GLIBC_2.2.5>
   a2c79:	41 0f 18 93 14 00 00 00                         	prefetcht1 0x14(%r11)
   a2c81:	41 5b                                           	pop    %r11
   a2c83:	e9 88 fe f7 ff                                  	jmp    22b10 <strcmp@plt>
   a2c88:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a2c90:	0f 18 3d 09 71 f9 ff                            	prefetchit0 -0x68ef7(%rip)        # 39da0 <mongoc_collection_find_and_modify_with_opts+0x560>
   a2c97:	e9 74 fe f7 ff                                  	jmp    22b10 <strcmp@plt>
   a2c9c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2ca0:	41 53                                           	push   %r11
   a2ca2:	4c 8b 1d 37 b9 ff ff                            	mov    -0x46c9(%rip),%r11        # 9e5e0 <bson_iter_init_find@Base>
   a2ca9:	41 0f 18 93 70 ff ff ff                         	prefetcht1 -0x90(%r11)
   a2cb1:	4c 8b 1d e0 c8 ff ff                            	mov    -0x3720(%rip),%r11        # 9f598 <bson_iter_next@Base>
   a2cb8:	41 0f 18 93 50 00 00 00                         	prefetcht1 0x50(%r11)
   a2cc0:	4c 8b 1d 21 ce ff ff                            	mov    -0x31df(%rip),%r11        # 9fae8 <bson_append_bool@Base>
   a2cc7:	41 0f 18 93 60 a1 ff ff                         	prefetcht1 -0x5ea0(%r11)
   a2ccf:	41 5b                                           	pop    %r11
   a2cd1:	e9 da dd f7 ff                                  	jmp    20ab0 <bson_iter_init_find@plt>
   a2cd6:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a2ce0:	41 53                                           	push   %r11
   a2ce2:	4c 8b 1d a7 c7 ff ff                            	mov    -0x3859(%rip),%r11        # 9f490 <bson_oid_init@Base>
   a2ce9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2cf1:	41 5b                                           	pop    %r11
   a2cf3:	e9 78 d7 f7 ff                                  	jmp    20470 <bson_init@plt>
   a2cf8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a2d00:	41 53                                           	push   %r11
   a2d02:	4c 8b 1d df cd ff ff                            	mov    -0x3221(%rip),%r11        # 9fae8 <bson_append_bool@Base>
   a2d09:	41 0f 18 93 42 e9 ff ff                         	prefetcht1 -0x16be(%r11)
   a2d11:	41 5b                                           	pop    %r11
   a2d13:	e9 38 09 f8 ff                                  	jmp    23650 <bson_concat@plt>
   a2d18:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
   a2d20:	0f 18 3d e9 99 fc ff                            	prefetchit0 -0x36617(%rip)        # 6c710 <_mongoc_get_command_name>
   a2d27:	0f 18 3d 14 9a fc ff                            	prefetchit0 -0x365ec(%rip)        # 6c742 <_mongoc_get_command_name+0x32>
   a2d2e:	0f 18 3d fb b4 fa ff                            	prefetchit0 -0x54b05(%rip)        # 4e230 <mongoc_cmd_parts_init>
   a2d35:	e9 f6 da f7 ff                                  	jmp    20830 <mongoc_cmd_parts_init@plt>
   a2d3a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
   a2d40:	0f 18 3d b9 cd fa ff                            	prefetchit0 -0x53247(%rip)        # 4fb00 <mongoc_cmd_parts_cleanup>
   a2d47:	e9 d4 f0 f7 ff                                  	jmp    21e20 <bson_destroy@plt>
   a2d4c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2d50:	0f 18 3d a9 7b fb ff                            	prefetchit0 -0x48457(%rip)        # 5a900 <mongoc_client_session_in_transaction>
   a2d57:	e9 c4 f0 f7 ff                                  	jmp    21e20 <bson_destroy@plt>
   a2d5c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2d60:	0f 18 3d 09 04 f8 ff                            	prefetchit0 -0x7fbf7(%rip)        # 23170 <mongoc_read_concern_copy@plt>
   a2d67:	e9 14 0b f8 ff                                  	jmp    23880 <bson_malloc0@plt>
   a2d6c:	0f 1f 40 00                                     	nopl   0x0(%rax)
   a2d70:	0f 18 3d 59 15 fb ff                            	prefetchit0 -0x4eaa7(%rip)        # 542d0 <mongoc_read_prefs_destroy>
   a2d77:	41 53                                           	push   %r11
   a2d79:	4c 8b 1d 28 bb ff ff                            	mov    -0x44d8(%rip),%r11        # 9e8a8 <bson_strdup@Base>
   a2d80:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
   a2d88:	41 5b                                           	pop    %r11
   a2d8a:	e9 e1 d6 f7 ff                                  	jmp    20470 <bson_init@plt>
   a2d8f:	90                                              	nop
   a2d90:	0f 18 3d a9 e2 f7 ff                            	prefetchit0 -0x81d57(%rip)        # 21040 <bson_strdup@plt>
   a2d97:	41 53                                           	push   %r11
   a2d99:	4c 8b 1d 08 bb ff ff                            	mov    -0x44f8(%rip),%r11        # 9e8a8 <bson_strdup@Base>
   a2da0:	41 0f 18 93 50 00 00 00                         	prefetcht1 0x50(%r11)
   a2da8:	41 5b                                           	pop    %r11
   a2daa:	e9 f1 e7 f7 ff                                  	jmp    215a0 <mongoc_write_concern_new@plt>
   a2daf:	90                                              	nop
   a2db0:	0f 18 3d 99 fa f7 ff                            	prefetchit0 -0x80567(%rip)        # 22850 <mongoc_read_concern_new@plt>
   a2db7:	0f 18 3d b2 03 f8 ff                            	prefetchit0 -0x7fc4e(%rip)        # 23170 <mongoc_read_concern_copy@plt>
   a2dbe:	e9 7d e2 f7 ff                                  	jmp    21040 <bson_strdup@plt>
   a2dc3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a2dcd:	0f 1f 00                                        	nopl   (%rax)
   a2dd0:	0f 18 3d 99 b8 f8 ff                            	prefetchit0 -0x74767(%rip)        # 2e670 <mongoc_client_pool_push>
   a2dd7:	0f 18 3d a4 b8 f8 ff                            	prefetchit0 -0x7475c(%rip)        # 2e682 <mongoc_client_pool_push+0x12>
   a2dde:	e9 3d f0 f7 ff                                  	jmp    21e20 <bson_destroy@plt>
   a2de3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
   a2ded:	0f 1f 00                                        	nopl   (%rax)
   a2df0:	0f 18 3d 4b 99 fc ff                            	prefetchit0 -0x366b5(%rip)        # 6c742 <_mongoc_get_command_name+0x32>
   a2df7:	0f 18 3d 12 99 fc ff                            	prefetchit0 -0x366ee(%rip)        # 6c710 <_mongoc_get_command_name>
   a2dfe:	0f 18 3d 8b b6 fa ff                            	prefetchit0 -0x54975(%rip)        # 4e490 <mongoc_cmd_parts_set_write_concern>
   a2e05:	0f 18 3d d4 fe fc ff                            	prefetchit0 -0x3012c(%rip)        # 72ce0 <mongoc_write_concern_is_acknowledged>
   a2e0c:	e9 0f ed f7 ff                                  	jmp    21b20 <mongoc_write_concern_get_journal@plt>
