
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_native_it0/beee2b363cdd95391e3db419aeccb36e2dd16c7f8b7f4c3f560bd878fc4c6e7b/TextService:     file format elf64-x86-64


Disassembly of section .text.prefetch_calls:

0000000000110340 <.text.prefetch_calls>:
  110340:	0f 18 3d e9 88 f3 ff                            	prefetchit0 -0xc7717(%rip)        # 48c30 <_ZNK13media_service13TextMapReader10ForeachKeyESt8functionIFN11opentracing2v28expectedIvSt10error_codeEENS3_11string_viewES7_EE>
  110347:	0f 18 3d 62 31 f3 ff                            	prefetchit0 -0xcce9e(%rip)        # 434b0 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_>
  11034e:	0f 18 3d af 31 f3 ff                            	prefetchit0 -0xcce51(%rip)        # 43504 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0x54>
  110355:	0f 18 3d c4 3b f3 ff                            	prefetchit0 -0xcc43c(%rip)        # 43f20 <_ZNSt17_Function_handlerIFN11opentracing2v28expectedIvSt10error_codeEENS1_11string_viewES5_EZNK13jaegertracing11propagation10PropagatorIRKNS1_13TextMapReaderERKNS1_13TextMapWriterEE7extractESC_EUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESO_E_E9_M_invokeERKSt9_Any_dataOS5_SU_>
  11035c:	0f 18 3d a1 3c f3 ff                            	prefetchit0 -0xcc35f(%rip)        # 44004 <_ZSt13__invoke_implIN11opentracing2v28expectedIvSt10error_codeEERZNK13jaegertracing11propagation10PropagatorIRKNS1_13TextMapReaderERKNS1_13TextMapWriterEE7extractESA_EUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESM_E_JNS1_11string_viewESP_EET_St14__invoke_otherOT0_DpOT1_+0x34>
  110363:	0f 18 3d d8 88 f3 ff                            	prefetchit0 -0xc7728(%rip)        # 48c42 <_ZNK13media_service13TextMapReader10ForeachKeyESt8functionIFN11opentracing2v28expectedIvSt10error_codeEENS3_11string_viewES7_EE+0x12>
  11036a:	0f 18 3d 11 89 f3 ff                            	prefetchit0 -0xc76ef(%rip)        # 48c82 <_ZNK13media_service13TextMapReader10ForeachKeyESt8functionIFN11opentracing2v28expectedIvSt10error_codeEENS3_11string_viewES7_EE+0x52>
  110371:	0f 18 3d 4a 32 f3 ff                            	prefetchit0 -0xccdb6(%rip)        # 435c2 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0x112>
  110378:	e9 a3 5f f1 ff                                  	jmp    26320 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  11037d:	0f 1f 00                                        	nopl   (%rax)
  110380:	0f 18 3d 19 06 f2 ff                            	prefetchit0 -0xdf9e7(%rip)        # 309a0 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  110387:	41 53                                           	push   %r11
  110389:	4c 8b 1d 50 dd ff ff                            	mov    -0x22b0(%rip),%r11        # 10e0e0 <_Znwm@GLIBCXX_3.4>
  110390:	41 0f 18 93 b0 06 00 00                         	prefetcht1 0x6b0(%r11)
  110398:	41 0f 18 93 d2 06 00 00                         	prefetcht1 0x6d2(%r11)
  1103a0:	4c 8b 1d f1 e0 ff ff                            	mov    -0x1f0f(%rip),%r11        # 10e498 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1103a7:	41 0f 18 93 10 5d fe ff                         	prefetcht1 -0x1a2f0(%r11)
  1103af:	41 5b                                           	pop    %r11
  1103b1:	e9 6a 5f f1 ff                                  	jmp    26320 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  1103b6:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1103c0:	41 53                                           	push   %r11
  1103c2:	4c 8b 1d cf e0 ff ff                            	mov    -0x1f31(%rip),%r11        # 10e498 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1103c9:	41 0f 18 93 50 79 00 00                         	prefetcht1 0x7950(%r11)
  1103d1:	4c 8b 1d 70 e3 ff ff                            	mov    -0x1c90(%rip),%r11        # 10e748 <_ZNSt7__cxx1119basic_ostringstreamIcSt11char_traitsIcESaIcEEC1Ev@GLIBCXX_3.4.26>
  1103d8:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1103e0:	41 0f 18 93 34 00 00 00                         	prefetcht1 0x34(%r11)
  1103e8:	41 5b                                           	pop    %r11
  1103ea:	e9 31 5f f1 ff                                  	jmp    26320 <_ZN11opentracing2v26Tracer6GlobalEv@plt>
  1103ef:	90                                              	nop
  1103f0:	0f 18 3d 09 8c f5 ff                            	prefetchit0 -0xa73f7(%rip)        # 69000 <_ZN13media_service26ComposeReviewServiceClient10UploadTextElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKSt3mapIS6_S6_St4lessIS6_ESaISt4pairIS7_S6_EEE>
  1103f7:	0f 18 3d d2 bd f4 ff                            	prefetchit0 -0xb422e(%rip)        # 5c1d0 <_ZN13media_service12ThriftClientINS_26ComposeReviewServiceClientEE7ConnectEv>
  1103fe:	e9 cd 06 f2 ff                                  	jmp    30ad0 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_26ComposeReviewServiceClientEEEE3PopEv>
  110403:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  11040d:	0f 1f 00                                        	nopl   (%rax)
  110410:	41 53                                           	push   %r11
  110412:	4c 8b 1d 7f e0 ff ff                            	mov    -0x1f81(%rip),%r11        # 10e498 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  110419:	41 0f 18 93 c1 af ff ff                         	prefetcht1 -0x503f(%r11)
  110421:	41 5b                                           	pop    %r11
  110423:	e9 58 6a f1 ff                                  	jmp    26e80 <_ZNSt6chrono3_V212steady_clock3nowEv@plt>
  110428:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  110430:	0f 18 3d 2f 95 f3 ff                            	prefetchit0 -0xc6ad1(%rip)        # 49966 <_ZNSt6vectorIN11opentracing2v29LogRecordESaIS2_EED2Ev+0xb6>
  110437:	41 53                                           	push   %r11
  110439:	4c 8b 1d 58 e0 ff ff                            	mov    -0x1fa8(%rip),%r11        # 10e498 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  110440:	41 0f 18 93 30 f5 ff ff                         	prefetcht1 -0xad0(%r11)
  110448:	41 0f 18 93 41 f5 ff ff                         	prefetcht1 -0xabf(%r11)
  110450:	41 5b                                           	pop    %r11
  110452:	e9 59 94 f3 ff                                  	jmp    498b0 <_ZNSt6vectorIN11opentracing2v29LogRecordESaIS2_EED2Ev>
  110457:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  110460:	0f 18 3d f9 bd f4 ff                            	prefetchit0 -0xb4207(%rip)        # 5c260 <_ZN13media_service12ThriftClientINS_26ComposeReviewServiceClientEE9KeepAliveEv>
  110467:	41 53                                           	push   %r11
  110469:	4c 8b 1d b8 df ff ff                            	mov    -0x2048(%rip),%r11        # 10e428 <_ZNSt18condition_variable10notify_oneEv@GLIBCXX_3.4.11>
  110470:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  110478:	41 5b                                           	pop    %r11
  11047a:	e9 91 5e f1 ff                                  	jmp    26310 <pthread_mutex_lock@plt>
  11047f:	90                                              	nop
  110480:	0f 18 3d 79 31 f3 ff                            	prefetchit0 -0xcce87(%rip)        # 43600 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0x150>
  110487:	e9 34 5d f1 ff                                  	jmp    261c0 <_Znwm@plt>
  11048c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  110490:	41 53                                           	push   %r11
  110492:	4c 8b 1d ff df ff ff                            	mov    -0x2001(%rip),%r11        # 10e498 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  110499:	41 0f 18 93 20 6f fe ff                         	prefetcht1 -0x190e0(%r11)
  1104a1:	41 5b                                           	pop    %r11
  1104a3:	e9 a8 37 f3 ff                                  	jmp    43c50 <_ZN13jaegertracing11SpanContextC2ERKNS_7TraceIDEmmhRKSt13unordered_mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESA_St4hashISA_ESt8equal_toISA_ESaISt4pairIKSA_SA_EEERSG_>
  1104a8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  1104b0:	41 53                                           	push   %r11
  1104b2:	4c 8b 1d bf de ff ff                            	mov    -0x2141(%rip),%r11        # 10e378 <_ZNSo9_M_insertImEERSoT_@GLIBCXX_3.4.9>
  1104b9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1104c1:	4c 8b 1d c8 e2 ff ff                            	mov    -0x1d38(%rip),%r11        # 10e790 <_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l@GLIBCXX_3.4.9>
  1104c8:	41 0f 18 93 70 e8 fe ff                         	prefetcht1 -0x11790(%r11)
  1104d0:	41 0f 18 93 20 26 ff ff                         	prefetcht1 -0xd9e0(%r11)
  1104d8:	41 0f 18 93 31 26 ff ff                         	prefetcht1 -0xd9cf(%r11)
  1104e0:	41 0f 18 93 10 29 ff ff                         	prefetcht1 -0xd6f0(%r11)
  1104e8:	41 0f 18 93 a0 f5 ff ff                         	prefetcht1 -0xa60(%r11)
  1104f0:	41 0f 18 93 b0 f5 ff ff                         	prefetcht1 -0xa50(%r11)
  1104f8:	41 5b                                           	pop    %r11
  1104fa:	e9 d1 51 f3 ff                                  	jmp    456d0 <_ZNK13jaegertracing11SpanContext5printISoEEvRT_>
  1104ff:	90                                              	nop
  110500:	0f 18 3d 29 61 f1 ff                            	prefetchit0 -0xe9ed7(%rip)        # 26630 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode@plt>
  110507:	41 53                                           	push   %r11
  110509:	4c 8b 1d 08 de ff ff                            	mov    -0x21f8(%rip),%r11        # 10e318 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode@GLIBCXX_3.4.21>
  110510:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  110518:	41 0f 18 93 11 00 00 00                         	prefetcht1 0x11(%r11)
  110520:	41 5b                                           	pop    %r11
  110522:	e9 b9 64 f1 ff                                  	jmp    269e0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@plt>
  110527:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  110530:	41 53                                           	push   %r11
  110532:	4c 8b 1d 67 db ff ff                            	mov    -0x2499(%rip),%r11        # 10e0a0 <_ZdlPvm@CXXABI_1.3.9>
  110539:	41 0f 18 93 20 4a ff ff                         	prefetcht1 -0xb5e0(%r11)
  110541:	41 5b                                           	pop    %r11
  110543:	e9 a8 5b f1 ff                                  	jmp    260f0 <memcpy@plt>
  110548:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  110550:	0f 18 3d b9 35 f3 ff                            	prefetchit0 -0xcca47(%rip)        # 43b10 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE11decodeValueERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  110557:	e9 94 5b f1 ff                                  	jmp    260f0 <memcpy@plt>
  11055c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  110560:	0f 18 3d 19 94 f3 ff                            	prefetchit0 -0xc6be7(%rip)        # 49980 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  110567:	e9 e4 fd f2 ff                                  	jmp    40350 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  11056c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  110570:	0f 18 3d 19 36 f3 ff                            	prefetchit0 -0xcc9e7(%rip)        # 43b90 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE12normalizeKeyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  110577:	e9 54 3a f3 ff                                  	jmp    43fd0 <_ZSt13__invoke_implIN11opentracing2v28expectedIvSt10error_codeEERZNK13jaegertracing11propagation10PropagatorIRKNS1_13TextMapReaderERKNS1_13TextMapWriterEE7extractESA_EUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESM_E_JNS1_11string_viewESP_EET_St14__invoke_otherOT0_DpOT1_>
  11057c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  110580:	0f 18 3d 29 4f f3 ff                            	prefetchit0 -0xcb0d7(%rip)        # 454b0 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_>
  110587:	e9 b4 5b f1 ff                                  	jmp    26140 <_ZdlPvm@plt>
  11058c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  110590:	0f 18 3d 59 68 f1 ff                            	prefetchit0 -0xe97a7(%rip)        # 26df0 <_ZSt18_Rb_tree_incrementPKSt18_Rb_tree_node_base@plt>
  110597:	41 53                                           	push   %r11
  110599:	4c 8b 1d 58 e1 ff ff                            	mov    -0x1ea8(%rip),%r11        # 10e6f8 <_ZSt18_Rb_tree_incrementPKSt18_Rb_tree_node_base@GLIBCXX_3.4>
  1105a0:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1105a8:	41 5b                                           	pop    %r11
  1105aa:	e9 91 5b f1 ff                                  	jmp    26140 <_ZdlPvm@plt>
  1105af:	90                                              	nop
  1105b0:	41 53                                           	push   %r11
  1105b2:	4c 8b 1d df de ff ff                            	mov    -0x2121(%rip),%r11        # 10e498 <_ZN13jaegertracing11SpanContext10fromStreamERSi@Base>
  1105b9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1105c1:	41 0f 18 93 44 00 00 00                         	prefetcht1 0x44(%r11)
  1105c9:	41 0f 18 93 88 00 00 00                         	prefetcht1 0x88(%r11)
  1105d1:	4c 8b 1d b8 e1 ff ff                            	mov    -0x1e48(%rip),%r11        # 10e790 <_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l@GLIBCXX_3.4.9>
  1105d8:	41 0f 18 93 b0 3e fe ff                         	prefetcht1 -0x1c150(%r11)
  1105e0:	41 0f 18 93 40 46 fe ff                         	prefetcht1 -0x1b9c0(%r11)
  1105e8:	41 0f 18 93 70 46 fe ff                         	prefetcht1 -0x1b990(%r11)
  1105f0:	41 5b                                           	pop    %r11
  1105f2:	e9 39 63 f1 ff                                  	jmp    26930 <_ZN13jaegertracing11SpanContext10fromStreamERSi@plt>
  1105f7:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  110600:	0f 18 3d 49 fd f2 ff                            	prefetchit0 -0xd02b7(%rip)        # 40350 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  110607:	e9 44 49 f3 ff                                  	jmp    44f50 <_ZN13jaegertracing11SpanContext4swapERS0_>
  11060c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  110610:	0f 18 3d 09 44 f3 ff                            	prefetchit0 -0xcbbf7(%rip)        # 44a20 <_ZN13jaegertracingeqERKNS_11SpanContextES2_>
  110617:	e9 34 fd f2 ff                                  	jmp    40350 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  11061c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  110620:	0f 18 3d 29 69 f1 ff                            	prefetchit0 -0xe96d7(%rip)        # 26f50 <_ZNSt6localeD1Ev@plt>
  110627:	41 53                                           	push   %r11
  110629:	4c 8b 1d 00 df ff ff                            	mov    -0x2100(%rip),%r11        # 10e530 <_ZNSt8ios_baseD2Ev@GLIBCXX_3.4>
  110630:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  110638:	41 5b                                           	pop    %r11
  11063a:	e9 11 fd f2 ff                                  	jmp    40350 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  11063f:	90                                              	nop
  110640:	0f 18 3d d9 69 f1 ff                            	prefetchit0 -0xe9627(%rip)        # 27020 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_@plt>
  110647:	41 53                                           	push   %r11
  110649:	4c 8b 1d c0 e1 ff ff                            	mov    -0x1e40(%rip),%r11        # 10e810 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_@GLIBCXX_3.4>
  110650:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  110658:	41 5b                                           	pop    %r11
  11065a:	e9 01 8f f3 ff                                  	jmp    49560 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE24_M_get_insert_unique_posERS7_>
  11065f:	90                                              	nop
  110660:	0f 18 3d 2e 16 f5 ff                            	prefetchit0 -0xae9d2(%rip)        # 61c95 <_ZN13media_service20TextServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x515>
  110667:	0f 18 3d 89 33 f5 ff                            	prefetchit0 -0xacc77(%rip)        # 639f7 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x77>
  11066e:	0f 18 3d 4b c9 f4 ff                            	prefetchit0 -0xb36b5(%rip)        # 5cfc0 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE17writeMessageBeginERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  110675:	0f 18 3d 64 be f4 ff                            	prefetchit0 -0xb419c(%rip)        # 5c4e0 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE22writeMessageBegin_virtERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  11067c:	0f 18 3d 43 12 f5 ff                            	prefetchit0 -0xaedbd(%rip)        # 618c6 <_ZN13media_service20TextServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x146>
  110683:	e9 b8 5a f1 ff                                  	jmp    26140 <_ZdlPvm@plt>
  110688:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  110690:	0f 18 3d c6 19 f5 ff                            	prefetchit0 -0xae63a(%rip)        # 6205d <_ZN13media_service20TextServiceProcessor18process_UploadTextEiPN6apache6thrift8protocol9TProtocolES5_Pv+0x2ad>
  110697:	e9 e4 92 f3 ff                                  	jmp    49980 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  11069c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1106a0:	0f 18 3d c9 c6 f4 ff                            	prefetchit0 -0xb3937(%rip)        # 5cd70 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE12readI64_virtERl>
  1106a7:	e9 34 60 f1 ff                                  	jmp    266e0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@plt>
  1106ac:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1106b0:	0f 18 3d 09 3b f5 ff                            	prefetchit0 -0xac4f7(%rip)        # 641c0 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE22_M_emplace_hint_uniqueIJRKSt21piecewise_construct_tSt5tupleIJRS7_EESJ_IJEEEEESt17_Rb_tree_iteratorIS8_ESt23_Rb_tree_const_iteratorIS8_EDpOT_>
  1106b7:	41 53                                           	push   %r11
  1106b9:	4c 8b 1d e0 d9 ff ff                            	mov    -0x2620(%rip),%r11        # 10e0a0 <_ZdlPvm@CXXABI_1.3.9>
  1106c0:	41 0f 18 93 b0 53 ff ff                         	prefetcht1 -0xac50(%r11)
  1106c8:	4c 8b 1d 11 da ff ff                            	mov    -0x25ef(%rip),%r11        # 10e0e0 <_Znwm@GLIBCXX_3.4>
  1106cf:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1106d7:	4c 8b 1d 12 de ff ff                            	mov    -0x21ee(%rip),%r11        # 10e4f0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm@GLIBCXX_3.4.21>
  1106de:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1106e6:	41 5b                                           	pop    %r11
  1106e8:	e9 a3 cd f4 ff                                  	jmp    5d490 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE14readStringBodyINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEEjRT_i>
  1106ed:	0f 1f 00                                        	nopl   (%rax)
  1106f0:	0f 18 3d e9 5f f1 ff                            	prefetchit0 -0xea017(%rip)        # 266e0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@plt>
  1106f7:	0f 18 3d 92 69 f1 ff                            	prefetchit0 -0xe966e(%rip)        # 27090 <memcmp@plt>
  1106fe:	0f 18 3d 7b 10 f5 ff                            	prefetchit0 -0xaef85(%rip)        # 61780 <_ZN13media_service20TextServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv>
  110705:	0f 18 3d c0 32 f5 ff                            	prefetchit0 -0xacd40(%rip)        # 639cc <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x4c>
  11070c:	0f 18 3d bd 66 f1 ff                            	prefetchit0 -0xe9943(%rip)        # 26dd0 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc@plt>
  110713:	0f 18 3d b5 8b f5 ff                            	prefetchit0 -0xa744b(%rip)        # 692cf <_ZN13media_service26ComposeReviewServiceClient15recv_UploadTextEv+0x4f>
  11071a:	41 53                                           	push   %r11
  11071c:	4c 8b 1d 4d dc ff ff                            	mov    -0x23b3(%rip),%r11        # 10e370 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@GLIBCXX_3.4.21>
  110723:	41 0f 18 93 10 00 00 00                         	prefetcht1 0x10(%r11)
  11072b:	41 0f 18 93 d8 01 00 00                         	prefetcht1 0x1d8(%r11)
  110733:	41 5b                                           	pop    %r11
  110735:	e9 56 cd f4 ff                                  	jmp    5d490 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE14readStringBodyINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEEjRT_i>
  11073a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  110740:	41 53                                           	push   %r11
  110742:	4c 8b 1d 9f df ff ff                            	mov    -0x2061(%rip),%r11        # 10e6e8 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc@GLIBCXX_3.4.21>
  110749:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  110751:	41 5b                                           	pop    %r11
  110753:	e9 88 5f f1 ff                                  	jmp    266e0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm@plt>
  110758:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  110760:	0f 18 3d 19 8b f3 ff                            	prefetchit0 -0xc74e7(%rip)        # 49280 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_>
  110767:	0f 18 3d 0b 8f f3 ff                            	prefetchit0 -0xc70f5(%rip)        # 49679 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE24_M_get_insert_unique_posERS7_+0x119>
  11076e:	0f 18 3d 0c 8f f3 ff                            	prefetchit0 -0xc70f4(%rip)        # 49681 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE24_M_get_insert_unique_posERS7_+0x121>
  110775:	e9 46 3a f5 ff                                  	jmp    641c0 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE22_M_emplace_hint_uniqueIJRKSt21piecewise_construct_tSt5tupleIJRS7_EESJ_IJEEEEESt17_Rb_tree_iteratorIS8_ESt23_Rb_tree_const_iteratorIS8_EDpOT_>
  11077a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  110780:	0f 18 3d 29 16 f5 ff                            	prefetchit0 -0xae9d7(%rip)        # 61db0 <_ZN13media_service20TextServiceProcessor18process_UploadTextEiPN6apache6thrift8protocol9TProtocolES5_Pv>
  110787:	0f 18 3d 02 fa f4 ff                            	prefetchit0 -0xb05fe(%rip)        # 60190 <_ZN13media_service27TextService_UploadText_args4readEPN6apache6thrift8protocol9TProtocolE>
  11078e:	0f 18 3d db c1 f4 ff                            	prefetchit0 -0xb3e25(%rip)        # 5c970 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE20readStructBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  110795:	0f 18 3d 25 16 f5 ff                            	prefetchit0 -0xae9db(%rip)        # 61dc1 <_ZN13media_service20TextServiceProcessor18process_UploadTextEiPN6apache6thrift8protocol9TProtocolES5_Pv+0x11>
  11079c:	e9 ef 68 f1 ff                                  	jmp    27090 <memcmp@plt>
  1107a1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  1107ab:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  1107b0:	0f 18 3d c9 31 f5 ff                            	prefetchit0 -0xace37(%rip)        # 63980 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv>
  1107b7:	e9 84 59 f1 ff                                  	jmp    26140 <_ZdlPvm@plt>
  1107bc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  1107c0:	0f 18 3d 29 4c f5 ff                            	prefetchit0 -0xab3d7(%rip)        # 653f0 <_ZN13media_service39ComposeReviewService_UploadText_presult4readEPN6apache6thrift8protocol9TProtocolE>
  1107c7:	41 53                                           	push   %r11
  1107c9:	4c 8b 1d d0 d8 ff ff                            	mov    -0x2730(%rip),%r11        # 10e0a0 <_ZdlPvm@CXXABI_1.3.9>
  1107d0:	41 0f 18 93 e0 48 ff ff                         	prefetcht1 -0xb720(%r11)
  1107d8:	4c 8b 1d 09 df ff ff                            	mov    -0x20f7(%rip),%r11        # 10e6e8 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc@GLIBCXX_3.4.21>
  1107df:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  1107e7:	41 5b                                           	pop    %r11
  1107e9:	e9 e2 65 f1 ff                                  	jmp    26dd0 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc@plt>
  1107ee:	66 90                                           	xchg   %ax,%ax
  1107f0:	0f 18 3d ea da f1 ff                            	prefetchit0 -0xe2516(%rip)        # 2e2e1 <_ZN13media_service11TextHandler10UploadTextElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKSt3mapIS6_S6_St4lessIS6_ESaISt4pairIS7_S6_EEE+0x2b1>
  1107f7:	0f 18 3d 46 0e f2 ff                            	prefetchit0 -0xdf1ba(%rip)        # 31644 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_26ComposeReviewServiceClientEEEE4PushEPS3_+0x14>
  1107fe:	41 53                                           	push   %r11
  110800:	4c 8b 1d 61 d8 ff ff                            	mov    -0x279f(%rip),%r11        # 10e068 <_ZNSt9exceptionD2Ev@GLIBCXX_3.4>
  110807:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  11080f:	41 5b                                           	pop    %r11
  110811:	e9 ea 83 f6 ff                                  	jmp    78c00 <_ZN13media_service16ServiceExceptionD1Ev>
