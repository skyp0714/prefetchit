
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_native_it0/b2cf6c33b74d2f22543b7a469a75b538911e690f769d0b238843a49465b83793/libc.so.6:     file format elf64-x86-64


Disassembly of section .text.prefetch_calls:

0000000000229380 <.text.prefetch_calls>:
  229380:	0f 18 3d fc d1 e4 ff                            	prefetchit0 -0x1b2e04(%rip)        # 76583 <psiginfo@@GLIBC_2.10+0x14143>
  229387:	0f 18 3d 73 e1 e4 ff                            	prefetchit0 -0x1b1e8d(%rip)        # 77501 <psiginfo@@GLIBC_2.10+0x150c1>
  22938e:	0f 18 3d 6d dc e4 ff                            	prefetchit0 -0x1b2393(%rip)        # 77002 <psiginfo@@GLIBC_2.10+0x14bc2>
  229395:	0f 18 3d c1 d1 e4 ff                            	prefetchit0 -0x1b2e3f(%rip)        # 7655d <psiginfo@@GLIBC_2.10+0x1411d>
  22939c:	0f 18 3d dd 4b e6 ff                            	prefetchit0 -0x19b423(%rip)        # 8df80 <_IO_default_xsputn@@GLIBC_2.2.5+0x200>
  2293a3:	e9 88 0e e3 ff                                  	jmp    5a230 <cuserid@@GLIBC_2.2.5+0xb0>
  2293a8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  2293b0:	0f 18 3d 89 82 f8 ff                            	prefetchit0 -0x77d77(%rip)        # 1b1640 <__nss_database_lookup@GLIBC_2.2.5+0x393a0>
  2293b7:	0f 18 3d 22 48 e6 ff                            	prefetchit0 -0x19b7de(%rip)        # 8dbe0 <_IO_setb@@GLIBC_2.2.5>
  2293be:	0f 18 3d 3b bc e4 ff                            	prefetchit0 -0x1b43c5(%rip)        # 75000 <psiginfo@@GLIBC_2.10+0x12bc0>
  2293c5:	0f 18 3d d4 51 e6 ff                            	prefetchit0 -0x19ae2c(%rip)        # 8e5a0 <_IO_enable_locks@@GLIBC_PRIVATE+0x40>
  2293cc:	0f 18 3d 1d bc e4 ff                            	prefetchit0 -0x1b43e3(%rip)        # 74ff0 <psiginfo@@GLIBC_2.10+0x12bb0>
  2293d3:	0f 18 3d 96 65 e6 ff                            	prefetchit0 -0x199a6a(%rip)        # 8f970 <_IO_str_pbackfail@@GLIBC_2.2.5+0x60>
  2293da:	0f 18 3d 9f 65 e6 ff                            	prefetchit0 -0x199a61(%rip)        # 8f980 <_IO_str_pbackfail@@GLIBC_2.2.5+0x70>
  2293e1:	0f 18 3d 99 82 f8 ff                            	prefetchit0 -0x77d67(%rip)        # 1b1681 <__nss_database_lookup@GLIBC_2.2.5+0x393e1>
  2293e8:	e9 23 52 e6 ff                                  	jmp    8e610 <_IO_enable_locks@@GLIBC_PRIVATE+0xb0>
  2293ed:	0f 1f 00                                        	nopl   (%rax)
  2293f0:	0f 18 3d f2 d8 e4 ff                            	prefetchit0 -0x1b270e(%rip)        # 76ce9 <psiginfo@@GLIBC_2.10+0x148a9>
  2293f7:	0f 18 3d a2 db e4 ff                            	prefetchit0 -0x1b245e(%rip)        # 76fa0 <psiginfo@@GLIBC_2.10+0x14b60>
  2293fe:	0f 18 3d 4b cc e4 ff                            	prefetchit0 -0x1b33b5(%rip)        # 76050 <psiginfo@@GLIBC_2.10+0x13c10>
  229405:	0f 18 3d c4 c2 e4 ff                            	prefetchit0 -0x1b3d3c(%rip)        # 756d0 <psiginfo@@GLIBC_2.10+0x13290>
  22940c:	0f 18 3d e5 db e4 ff                            	prefetchit0 -0x1b241b(%rip)        # 76ff8 <psiginfo@@GLIBC_2.10+0x14bb8>
  229413:	0f 18 3d 16 0e e3 ff                            	prefetchit0 -0x1cf1ea(%rip)        # 5a230 <cuserid@@GLIBC_2.2.5+0xb0>
  22941a:	0f 18 3d 1f 0e e3 ff                            	prefetchit0 -0x1cf1e1(%rip)        # 5a240 <cuserid@@GLIBC_2.2.5+0xc0>
  229421:	0f 18 3d 38 4b e6 ff                            	prefetchit0 -0x19b4c8(%rip)        # 8df60 <_IO_default_xsputn@@GLIBC_2.2.5+0x1e0>
  229428:	e9 c3 bb e4 ff                                  	jmp    74ff0 <psiginfo@@GLIBC_2.10+0x12bb0>
  22942d:	0f 1f 00                                        	nopl   (%rax)
  229430:	0f 18 3d 09 bc e4 ff                            	prefetchit0 -0x1b43f7(%rip)        # 75040 <psiginfo@@GLIBC_2.10+0x12c00>
  229437:	0f 18 3d c3 47 e6 ff                            	prefetchit0 -0x19b83d(%rip)        # 8dc01 <_IO_setb@@GLIBC_2.2.5+0x21>
  22943e:	0f 18 3d e5 c5 e4 ff                            	prefetchit0 -0x1b3a1b(%rip)        # 75a2a <psiginfo@@GLIBC_2.10+0x135ea>
  229445:	0f 18 3d 77 c0 e4 ff                            	prefetchit0 -0x1b3f89(%rip)        # 754c3 <psiginfo@@GLIBC_2.10+0x13083>
  22944c:	e9 4f 51 e6 ff                                  	jmp    8e5a0 <_IO_enable_locks@@GLIBC_PRIVATE+0x40>
  229451:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  22945b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  229460:	0f 18 3d 36 ae e6 ff                            	prefetchit0 -0x1951ca(%rip)        # 9429d <pthread_cond_clockwait@GLIBC_2.30+0x1fd>
  229467:	0f 18 3d c9 d0 e6 ff                            	prefetchit0 -0x192f37(%rip)        # 96537 <pthread_join@@GLIBC_2.34+0xc7>
  22946e:	0f 18 3d 6f d1 e6 ff                            	prefetchit0 -0x192e91(%rip)        # 965e4 <pthread_join@@GLIBC_2.34+0x174>
  229475:	0f 18 3d 84 d1 e6 ff                            	prefetchit0 -0x192e7c(%rip)        # 96600 <pthread_join@@GLIBC_2.34+0x190>
  22947c:	0f 18 3d 7e a5 e6 ff                            	prefetchit0 -0x195a82(%rip)        # 93a01 <pthread_cond_wait@@GLIBC_2.3.2+0x211>
  229483:	0f 18 3d f1 ac e6 ff                            	prefetchit0 -0x19530f(%rip)        # 9417b <pthread_cond_clockwait@GLIBC_2.30+0xdb>
  22948a:	0f 18 3d b7 d0 e6 ff                            	prefetchit0 -0x192f49(%rip)        # 96548 <pthread_join@@GLIBC_2.34+0xd8>
  229491:	e9 8a 75 e6 ff                                  	jmp    90a20 <__libc_alloca_cutoff@@GLIBC_PRIVATE+0xc0>
  229496:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  2294a0:	0f 18 3d 59 7b e6 ff                            	prefetchit0 -0x1984a7(%rip)        # 91000 <__nptl_death_event@@GLIBC_PRIVATE+0xb0>
  2294a7:	e9 64 04 e7 ff                                  	jmp    99910 <__pthread_mutex_trylock@GLIBC_2.2.5+0xb00>
  2294ac:	0f 1f 40 00                                     	nopl   0x0(%rax)
  2294b0:	0f 18 3d 09 a4 e6 ff                            	prefetchit0 -0x195bf7(%rip)        # 938c0 <pthread_cond_wait@@GLIBC_2.3.2+0xd0>
  2294b7:	0f 18 3d ec a3 e6 ff                            	prefetchit0 -0x195c14(%rip)        # 938aa <pthread_cond_wait@@GLIBC_2.3.2+0xba>
  2294be:	e9 fd 75 e6 ff                                  	jmp    90ac0 <_pthread_cleanup_pop@GLIBC_2.2.5>
  2294c3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  2294cd:	0f 1f 00                                        	nopl   (%rax)
  2294d0:	0f 18 3d 19 7b e6 ff                            	prefetchit0 -0x1984e7(%rip)        # 90ff0 <__nptl_death_event@@GLIBC_PRIVATE+0xa0>
  2294d7:	0f 18 3d 25 7b e6 ff                            	prefetchit0 -0x1984db(%rip)        # 91003 <__nptl_death_event@@GLIBC_PRIVATE+0xb3>
  2294de:	e9 2d 04 e7 ff                                  	jmp    99910 <__pthread_mutex_trylock@GLIBC_2.2.5+0xb00>
  2294e3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  2294ed:	0f 1f 00                                        	nopl   (%rax)
  2294f0:	0f 18 3d 84 ac e6 ff                            	prefetchit0 -0x19537c(%rip)        # 9417b <pthread_cond_clockwait@GLIBC_2.30+0xdb>
  2294f7:	0f 18 3d 85 ac e6 ff                            	prefetchit0 -0x19537b(%rip)        # 94183 <pthread_cond_clockwait@GLIBC_2.30+0xe3>
  2294fe:	0f 18 3d 5b dc e6 ff                            	prefetchit0 -0x1923a5(%rip)        # 97160 <pthread_kill_other_threads_np@GLIBC_2.2.5+0x760>
  229505:	e9 b6 75 e6 ff                                  	jmp    90ac0 <_pthread_cleanup_pop@GLIBC_2.2.5>
  22950a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  229510:	0f 18 3d 39 c5 ef ff                            	prefetchit0 -0x103ac7(%rip)        # 125a50 <__clone@@GLIBC_2.2.5>
  229517:	0f 18 3d 92 d3 ef ff                            	prefetchit0 -0x102c6e(%rip)        # 1268b0 <__xmknodat@@GLIBC_2.4+0x200>
  22951e:	0f 18 3d 9c d3 ef ff                            	prefetchit0 -0x102c64(%rip)        # 1268c1 <__xmknodat@@GLIBC_2.4+0x211>
  229525:	0f 18 3d 58 c5 ef ff                            	prefetchit0 -0x103aa8(%rip)        # 125a84 <__clone@@GLIBC_2.2.5+0x34>
  22952c:	e9 cf d3 ef ff                                  	jmp    126900 <__xmknodat@@GLIBC_2.4+0x250>
  229531:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  22953b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  229540:	0f 18 3d fa b4 e6 ff                            	prefetchit0 -0x194b06(%rip)        # 94a41 <pthread_condattr_setpshared@@GLIBC_2.34+0x4d1>
  229547:	e9 74 0e e1 ff                                  	jmp    3a3c0 <__ctype_init@@GLIBC_PRIVATE>
  22954c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  229550:	0f 18 3d 89 73 e6 ff                            	prefetchit0 -0x198c77(%rip)        # 908e0 <dlvsym@GLIBC_2.2.5+0xe0>
  229557:	0f 18 3d 72 88 f2 ff                            	prefetchit0 -0xd778e(%rip)        # 151dd0 <__resolv_context_put@@GLIBC_PRIVATE+0xb0>
  22955e:	0f 18 3d 5c f3 f3 ff                            	prefetchit0 -0xc0ca4(%rip)        # 1688c1 <pmap_getport@GLIBC_2.2.5+0x271>
  229565:	0f 18 3d 44 f3 f3 ff                            	prefetchit0 -0xc0cbc(%rip)        # 1688b0 <pmap_getport@GLIBC_2.2.5+0x260>
  22956c:	0f 18 3d cd eb e7 ff                            	prefetchit0 -0x181433(%rip)        # a8140 <__libc_alloc_buffer_create_failure@@GLIBC_PRIVATE+0x50>
  229573:	0f 18 3d 06 06 f2 ff                            	prefetchit0 -0xdf9fa(%rip)        # 149b80 <inet_nsap_ntoa@@GLIBC_2.2.5+0x1c0>
  22957a:	0f 18 3d ef ed df ff                            	prefetchit0 -0x201211(%rip)        # 28370 <free@plt>
  229581:	0f 18 3d 38 80 e6 ff                            	prefetchit0 -0x197fc8(%rip)        # 915c0 <__pthread_get_minstack@@GLIBC_PRIVATE+0x50>
  229588:	e9 d3 c7 e1 ff                                  	jmp    45d60 <__call_tls_dtors@@GLIBC_PRIVATE>
  22958d:	0f 1f 00                                        	nopl   (%rax)
  229590:	0f 18 3d 98 88 f2 ff                            	prefetchit0 -0xd7768(%rip)        # 151e2f <__resolv_context_put@@GLIBC_PRIVATE+0x10f>
  229597:	e9 14 80 e6 ff                                  	jmp    915b0 <__pthread_get_minstack@@GLIBC_PRIVATE+0x40>
  22959c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  2295a0:	0f 18 3d e6 b5 e6 ff                            	prefetchit0 -0x194a1a(%rip)        # 94b8d <pthread_condattr_setpshared@@GLIBC_2.34+0x61d>
  2295a7:	e9 64 1d ef ff                                  	jmp    11b310 <__getpagesize@@GLIBC_2.2.5>
  2295ac:	0f 1f 40 00                                     	nopl   0x0(%rax)
  2295b0:	0f 18 3d 09 8a e6 ff                            	prefetchit0 -0x1975f7(%rip)        # 91fc0 <pthread_cond_wait@GLIBC_2.2.5+0x80>
  2295b7:	0f 18 3d 04 c1 e6 ff                            	prefetchit0 -0x193efc(%rip)        # 956c2 <pthread_create@GLIBC_2.2.5+0xac2>
  2295be:	0f 18 3d bb c0 e6 ff                            	prefetchit0 -0x193f45(%rip)        # 95680 <pthread_create@GLIBC_2.2.5+0xa80>
  2295c5:	e9 66 c7 e6 ff                                  	jmp    95d30 <pthread_getattr_default_np@@GLIBC_2.34>
  2295ca:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  2295d0:	0f 18 3d 29 d3 ef ff                            	prefetchit0 -0x102cd7(%rip)        # 126900 <__xmknodat@@GLIBC_2.4+0x250>
  2295d7:	e9 54 7d e6 ff                                  	jmp    91330 <__lll_lock_wake_private@@GLIBC_PRIVATE+0x70>
  2295dc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  2295e0:	0f 18 3d 29 03 e7 ff                            	prefetchit0 -0x18fcd7(%rip)        # 99910 <__pthread_mutex_trylock@GLIBC_2.2.5+0xb00>
  2295e7:	0f 18 3d d5 aa e6 ff                            	prefetchit0 -0x19552b(%rip)        # 940c3 <pthread_cond_clockwait@GLIBC_2.30+0x23>
  2295ee:	e9 ed 7c e6 ff                                  	jmp    912e0 <__lll_lock_wake_private@@GLIBC_PRIVATE+0x20>
  2295f3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  2295fd:	0f 1f 00                                        	nopl   (%rax)
  229600:	0f 18 3d 69 ce e6 ff                            	prefetchit0 -0x193197(%rip)        # 96470 <pthread_join@@GLIBC_2.34>
  229607:	0f 18 3d 75 ce e6 ff                            	prefetchit0 -0x19318b(%rip)        # 96483 <pthread_join@@GLIBC_2.34+0x13>
  22960e:	e9 7d 74 e6 ff                                  	jmp    90a90 <_pthread_cleanup_push@@GLIBC_2.34>
  229613:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  22961d:	0f 1f 00                                        	nopl   (%rax)
  229620:	0f 18 3d d0 b2 e6 ff                            	prefetchit0 -0x194d30(%rip)        # 948f7 <pthread_condattr_setpshared@@GLIBC_2.34+0x387>
  229627:	0f 18 3d d3 97 e6 ff                            	prefetchit0 -0x19682d(%rip)        # 92e01 <pthread_cond_broadcast@@GLIBC_2.3.2+0x51>
  22962e:	0f 18 3d 7b 7f e6 ff                            	prefetchit0 -0x198085(%rip)        # 915b0 <__pthread_get_minstack@@GLIBC_PRIVATE+0x40>
  229635:	e9 86 74 e6 ff                                  	jmp    90ac0 <_pthread_cleanup_pop@GLIBC_2.2.5>
  22963a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  229640:	0f 18 3d ba b5 f0 ff                            	prefetchit0 -0xf4a46(%rip)        # 134c01 <__vsnprintf_chk@@GLIBC_2.3.4+0x11>
  229647:	0f 18 3d 12 c7 e1 ff                            	prefetchit0 -0x1e38ee(%rip)        # 45d60 <__call_tls_dtors@@GLIBC_PRIVATE>
  22964e:	e9 7d 80 e7 ff                                  	jmp    a16d0 <timer_settime@GLIBC_2.2.5+0xce0>
  229653:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  22965d:	0f 1f 00                                        	nopl   (%rax)
  229660:	0f 18 3d f9 c6 e1 ff                            	prefetchit0 -0x1e3907(%rip)        # 45d60 <__call_tls_dtors@@GLIBC_PRIVATE>
  229667:	0f 18 3d 15 b4 e6 ff                            	prefetchit0 -0x194beb(%rip)        # 94a83 <pthread_condattr_setpshared@@GLIBC_2.34+0x513>
  22966e:	e9 fd a2 e7 ff                                  	jmp    a3970 <__default_morecore@GLIBC_2.2.5+0x1400>
  229673:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  22967d:	0f 1f 00                                        	nopl   (%rax)
  229680:	0f 18 3d 51 7a e7 ff                            	prefetchit0 -0x1885af(%rip)        # a10d8 <timer_settime@GLIBC_2.2.5+0x6e8>
  229687:	e9 c4 79 e7 ff                                  	jmp    a1050 <timer_settime@GLIBC_2.2.5+0x660>
  22968c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  229690:	0f 18 3d 89 ef df ff                            	prefetchit0 -0x201077(%rip)        # 28620 <*ABS*+0xa9bd0@plt>
  229697:	e9 d4 a2 e7 ff                                  	jmp    a3970 <__default_morecore@GLIBC_2.2.5+0x1400>
  22969c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  2296a0:	0f 18 3d 5c 80 e7 ff                            	prefetchit0 -0x187fa4(%rip)        # a1703 <timer_settime@GLIBC_2.2.5+0xd13>
  2296a7:	e9 c4 a2 e7 ff                                  	jmp    a3970 <__default_morecore@GLIBC_2.2.5+0x1400>
  2296ac:	0f 1f 40 00                                     	nopl   0x0(%rax)
  2296b0:	0f 18 3d 8b a1 e6 ff                            	prefetchit0 -0x195e75(%rip)        # 93842 <pthread_cond_wait@@GLIBC_2.3.2+0x52>
  2296b7:	0f 18 3d 02 55 ef ff                            	prefetchit0 -0x10aafe(%rip)        # 11ebc0 <__munmap@@GLIBC_PRIVATE>
  2296be:	0f 18 3d bb 08 e7 ff                            	prefetchit0 -0x18f745(%rip)        # 99f80 <__pthread_once@GLIBC_2.2.5>
  2296c5:	0f 18 3d 34 a1 e6 ff                            	prefetchit0 -0x195ecc(%rip)        # 93800 <pthread_cond_wait@@GLIBC_2.3.2+0x10>
  2296cc:	0f 18 3d 2f 96 e7 ff                            	prefetchit0 -0x1869d1(%rip)        # a2d02 <__default_morecore@GLIBC_2.2.5+0x792>
  2296d3:	0f 18 3d 06 ce e7 ff                            	prefetchit0 -0x1831fa(%rip)        # a64e0 <__libc_calloc@@GLIBC_2.2.5>
  2296da:	0f 18 3d 0f 79 e6 ff                            	prefetchit0 -0x1986f1(%rip)        # 90ff0 <__nptl_death_event@@GLIBC_PRIVATE+0xa0>
  2296e1:	0f 18 3d d9 a2 e6 ff                            	prefetchit0 -0x195d27(%rip)        # 939c1 <pthread_cond_wait@@GLIBC_2.3.2+0x1d1>
  2296e8:	e9 73 8f e7 ff                                  	jmp    a2660 <__default_morecore@GLIBC_2.2.5+0xf0>
  2296ed:	0f 1f 00                                        	nopl   (%rax)
  2296f0:	0f 18 3d 59 79 e7 ff                            	prefetchit0 -0x1886a7(%rip)        # a1050 <timer_settime@GLIBC_2.2.5+0x660>
  2296f7:	e9 54 b2 e7 ff                                  	jmp    a4950 <__default_morecore@GLIBC_2.2.5+0x23e0>
  2296fc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  229700:	0f 18 3d b9 55 ef ff                            	prefetchit0 -0x10aa47(%rip)        # 11ecc0 <__madvise@@GLIBC_PRIVATE>
  229707:	e9 94 bc e7 ff                                  	jmp    a53a0 <__libc_free@@GLIBC_2.2.5>
  22970c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  229710:	0f 18 3d 01 d0 e7 ff                            	prefetchit0 -0x182fff(%rip)        # a6718 <__libc_calloc@@GLIBC_2.2.5+0x238>
  229717:	e9 54 a2 e7 ff                                  	jmp    a3970 <__default_morecore@GLIBC_2.2.5+0x1400>
  22971c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  229720:	0f 18 3d b9 df ef ff                            	prefetchit0 -0x102047(%rip)        # 1276e0 <__recv@@GLIBC_PRIVATE>
  229727:	0f 18 3d 52 d1 f7 ff                            	prefetchit0 -0x82eae(%rip)        # 1a6880 <__nss_database_lookup@GLIBC_2.2.5+0x2e5e0>
  22972e:	e9 ed 72 e6 ff                                  	jmp    90a20 <__libc_alloca_cutoff@@GLIBC_PRIVATE+0xc0>
  229733:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  22973d:	0f 1f 00                                        	nopl   (%rax)
  229740:	0f 18 3d ba 1f ef ff                            	prefetchit0 -0x10e046(%rip)        # 11b701 <__select@@GLIBC_2.2.5+0xd1>
  229747:	0f 18 3d ae 1f ef ff                            	prefetchit0 -0x10e052(%rip)        # 11b6fc <__select@@GLIBC_2.2.5+0xcc>
  22974e:	e9 cd 72 e6 ff                                  	jmp    90a20 <__libc_alloca_cutoff@@GLIBC_PRIVATE+0xc0>
