
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_native_it0/fb16c1d304d6c0b56c24c422f5dfa7dde6ab3c368cec6a4fd9bcc0602a66c917/ComposeReviewService:     file format elf64-x86-64


Disassembly of section .text.prefetch_calls:

0000000000342380 <.text.prefetch_calls>:
  342380:	0f 18 3d c9 e9 f1 ff                            	prefetchit0 -0xe1637(%rip)        # 260d50 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm>
  342387:	e9 f4 e5 f1 ff                                  	jmp    260980 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructEmc>
  34238c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342390:	41 53                                           	push   %r11
  342392:	4c 8b 1d 6f 8e ff ff                            	mov    -0x7191(%rip),%r11        # 33b208 <memcached_mget@Base>
  342399:	41 0f 18 93 80 ff ff ff                         	prefetcht1 -0x80(%r11)
  3423a1:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3423a9:	41 5b                                           	pop    %r11
  3423ab:	e9 60 d9 d4 ff                                  	jmp    8fd10 <memcached_pool_pop@plt>
  3423b0:	41 53                                           	push   %r11
  3423b2:	4c 8b 1d 87 8d ff ff                            	mov    -0x7279(%rip),%r11        # 33b140 <strtoul@GLIBC_2.2.5>
  3423b9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3423c1:	41 0f 18 93 50 05 00 00                         	prefetcht1 0x550(%r11)
  3423c9:	41 0f 18 93 60 05 00 00                         	prefetcht1 0x560(%r11)
  3423d1:	41 0f 18 93 a4 05 00 00                         	prefetcht1 0x5a4(%r11)
  3423d9:	41 5b                                           	pop    %r11
  3423db:	e9 00 e5 f1 ff                                  	jmp    2608e0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm>
  3423e0:	41 53                                           	push   %r11
  3423e2:	4c 8b 1d 37 91 ff ff                            	mov    -0x6ec9(%rip),%r11        # 33b520 <strtol@GLIBC_2.2.5>
  3423e9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3423f1:	41 5b                                           	pop    %r11
  3423f3:	e9 c8 d3 d4 ff                                  	jmp    8f7c0 <bcmp@plt>
  3423f8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  342400:	0f 18 3d a9 b6 d5 ff                            	prefetchit0 -0x2a4957(%rip)        # 9dab0 <_ZN13media_service20ComposeReviewHandler17_ComposeAndUploadElRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES7_St4lessIS7_ESaISt4pairIKS7_S7_EEE+0xb00>
  342407:	41 53                                           	push   %r11
  342409:	4c 8b 1d 90 8d ff ff                            	mov    -0x7270(%rip),%r11        # 33b1a0 <memcached_fetch@Base>
  342410:	41 0f 18 93 d0 fd ff ff                         	prefetcht1 -0x230(%r11)
  342418:	4c 8b 1d e9 8f ff ff                            	mov    -0x7017(%rip),%r11        # 33b408 <memcached_add@Base>
  34241f:	41 0f 18 93 90 ee ff ff                         	prefetcht1 -0x1170(%r11)
  342427:	41 5b                                           	pop    %r11
  342429:	e9 a2 d4 d4 ff                                  	jmp    8f8d0 <free@plt>
  34242e:	66 90                                           	xchg   %ax,%ax
  342430:	41 53                                           	push   %r11
  342432:	4c 8b 1d cf 8d ff ff                            	mov    -0x7231(%rip),%r11        # 33b208 <memcached_mget@Base>
  342439:	41 0f 18 93 25 0f 00 00                         	prefetcht1 0xf25(%r11)
  342441:	41 5b                                           	pop    %r11
  342443:	e9 b8 d0 d4 ff                                  	jmp    8f500 <memcached_quit@plt>
  342448:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  342450:	0f 18 3d 09 e6 ee ff                            	prefetchit0 -0x1119f7(%rip)        # 230a60 <_ZNSt13__future_base12_Result_baseC1Ev>
  342457:	e9 34 a9 ea ff                                  	jmp    1ecd90 <_ZNSt6chrono3_V212system_clock3nowEv>
  34245c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342460:	0f 18 3d c9 1a f2 ff                            	prefetchit0 -0xde537(%rip)        # 263f30 <_ZNSt6thread15_M_start_threadESt10unique_ptrINS_6_StateESt14default_deleteIS1_EEPFvvE>
  342467:	0f 18 3d d4 1a f2 ff                            	prefetchit0 -0xde52c(%rip)        # 263f42 <_ZNSt6thread15_M_start_threadESt10unique_ptrINS_6_StateESt14default_deleteIS1_EEPFvvE+0x12>
  34246e:	41 53                                           	push   %r11
  342470:	4c 8b 1d a9 8b ff ff                            	mov    -0x7457(%rip),%r11        # 33b020 <pthread_cond_signal@GLIBC_2.3.2>
  342477:	41 0f 18 93 d0 ed ff ff                         	prefetcht1 -0x1230(%r11)
  34247f:	4c 8b 1d 22 91 ff ff                            	mov    -0x6ede(%rip),%r11        # 33b5a8 <pthread_getspecific@GLIBC_2.34>
  342486:	41 0f 18 93 a0 f4 ff ff                         	prefetcht1 -0xb60(%r11)
  34248e:	41 0f 18 93 50 f9 ff ff                         	prefetcht1 -0x6b0(%r11)
  342496:	41 0f 18 93 63 f9 ff ff                         	prefetcht1 -0x69d(%r11)
  34249e:	4c 8b 1d cb 91 ff ff                            	mov    -0x6e35(%rip),%r11        # 33b670 <pthread_create@GLIBC_2.34>
  3424a5:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3424ad:	41 0f 18 93 80 0a 00 00                         	prefetcht1 0xa80(%r11)
  3424b5:	41 5b                                           	pop    %r11
  3424b7:	e9 f4 fe e9 ff                                  	jmp    1e23b0 <_Znwm>
  3424bc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3424c0:	41 53                                           	push   %r11
  3424c2:	4c 8b 1d cf 90 ff ff                            	mov    -0x6f31(%rip),%r11        # 33b598 <poll@GLIBC_2.2.5>
  3424c9:	41 0f 18 93 90 5e 00 00                         	prefetcht1 0x5e90(%r11)
  3424d1:	41 5b                                           	pop    %r11
  3424d3:	e9 d8 fe e9 ff                                  	jmp    1e23b0 <_Znwm>
  3424d8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3424e0:	0f 18 3d 1a cd f0 ff                            	prefetchit0 -0xf32e6(%rip)        # 24f201 <__once_proxy+0x11>
  3424e7:	0f 18 3d e2 19 f2 ff                            	prefetchit0 -0xde61e(%rip)        # 263ed0 <_ZNSt6thread4joinEv>
  3424ee:	0f 18 3d 4b 77 d8 ff                            	prefetchit0 -0x2788b5(%rip)        # c9c40 <_ZNSt13__future_base21_Async_state_commonV217_M_complete_asyncEv>
  3424f5:	0f 18 3d 46 b7 d8 ff                            	prefetchit0 -0x2748ba(%rip)        # cdc42 <_ZZNSt9once_flag18_Prepare_executionC1IZSt9call_onceIMSt6threadFvvEJPS3_EEvRS_OT_DpOT0_EUlvE_EERS8_ENUlvE_8__invokeEv+0x12>
  3424fc:	0f 18 3d 7e 77 d8 ff                            	prefetchit0 -0x278882(%rip)        # c9c81 <_ZNSt13__future_base21_Async_state_commonV217_M_complete_asyncEv+0x41>
  342503:	41 53                                           	push   %r11
  342505:	4c 8b 1d 64 8e ff ff                            	mov    -0x719c(%rip),%r11        # 33b370 <pthread_join@GLIBC_2.34>
  34250c:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  342514:	41 5b                                           	pop    %r11
  342516:	e9 25 25 d8 ff                                  	jmp    c4a40 <_ZNKSt14__basic_futureIvE13_M_get_resultEv>
  34251b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  342520:	0f 18 3d da cc f0 ff                            	prefetchit0 -0xf3326(%rip)        # 24f201 <__once_proxy+0x11>
  342527:	e9 14 25 d8 ff                                  	jmp    c4a40 <_ZNKSt14__basic_futureIvE13_M_get_resultEv>
  34252c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342530:	0f 18 3d 0b b7 d8 ff                            	prefetchit0 -0x2748f5(%rip)        # cdc42 <_ZZNSt9once_flag18_Prepare_executionC1IZSt9call_onceIMSt6threadFvvEJPS3_EEvRS_OT_DpOT0_EUlvE_EERS8_ENUlvE_8__invokeEv+0x12>
  342537:	0f 18 3d c3 cc f0 ff                            	prefetchit0 -0xf333d(%rip)        # 24f201 <__once_proxy+0x11>
  34253e:	41 53                                           	push   %r11
  342540:	4c 8b 1d 29 8e ff ff                            	mov    -0x71d7(%rip),%r11        # 33b370 <pthread_join@GLIBC_2.34>
  342547:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  34254f:	41 5b                                           	pop    %r11
  342551:	e9 ea 24 d8 ff                                  	jmp    c4a40 <_ZNKSt14__basic_futureIvE13_M_get_resultEv>
  342556:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  342560:	0f 18 3d fe 49 d6 ff                            	prefetchit0 -0x29b602(%rip)        # a6f65 <_ZN13media_service20ComposeReviewHandler12UploadRatingEliRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES7_St4lessIS7_ESaISt4pairIKS7_S7_EEE+0xd65>
  342567:	0f 18 3d 72 a8 ea ff                            	prefetchit0 -0x15578e(%rip)        # 1ecde0 <_ZNSt6chrono3_V212steady_clock3nowEv>
  34256e:	e9 ad e2 e9 ff                                  	jmp    1e0820 <_ZdlPvm>
  342573:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  34257d:	0f 1f 00                                        	nopl   (%rax)
  342580:	0f 18 3d d9 39 e6 ff                            	prefetchit0 -0x19c627(%rip)        # 1a5f60 <_ZNSt11__copy_moveILb0ELb0ESt26random_access_iterator_tagE8__copy_mIPKN11opentracing2v29LogRecordESt20back_insert_iteratorISt6vectorIN13jaegertracing9LogRecordESaISB_EEEEET0_T_SG_SF_>
  342587:	e9 94 e2 e9 ff                                  	jmp    1e0820 <_ZdlPvm>
  34258c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342590:	0f 18 3d 6c ce d7 ff                            	prefetchit0 -0x283194(%rip)        # bf403 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0x103>
  342597:	0f 18 3d 25 ce d7 ff                            	prefetchit0 -0x2831db(%rip)        # bf3c3 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0xc3>
  34259e:	0f 18 3d 5b cd d7 ff                            	prefetchit0 -0x2832a5(%rip)        # bf300 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_>
  3425a5:	0f 18 3d 98 cd d7 ff                            	prefetchit0 -0x283268(%rip)        # bf344 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0x44>
  3425ac:	e9 cf 1c e7 ff                                  	jmp    1b4280 <_ZN11opentracing2v26Tracer6GlobalEv>
  3425b1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3425bb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3425c0:	0f 18 3d 79 6d f1 ff                            	prefetchit0 -0xe9287(%rip)        # 259340 <_ZNSt7__cxx1119basic_ostringstreamIcSt11char_traitsIcESaIcEEC1Ev>
  3425c7:	0f 18 3d d2 df e2 ff                            	prefetchit0 -0x1d202e(%rip)        # 1705a0 <_ZNK13jaegertracing6Tracer6InjectERKN11opentracing2v211SpanContextERKNS2_13TextMapWriterE>
  3425ce:	e9 ad 1c e7 ff                                  	jmp    1b4280 <_ZN11opentracing2v26Tracer6GlobalEv>
  3425d3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3425dd:	0f 1f 00                                        	nopl   (%rax)
  3425e0:	0f 18 3d 49 9c d6 ff                            	prefetchit0 -0x2963b7(%rip)        # ac230 <_ZN5boost3log12v2s_mt_posix7sources22basic_composite_loggerIcNS2_18severity_logger_mtINS1_7trivial14severity_levelEEENS2_18multi_thread_modelINS1_3aux14light_rw_mutexEEENS2_8featuresIJNS2_8severityIS6_EEEEEE11open_recordINS_9parameter3aux25tagged_argument_list_of_1INSJ_15tagged_argumentINS1_8keywords3tag8severityEKS6_EEEEEENS1_6recordERKT_>
  3425e7:	0f 18 3d 58 e1 df ff                            	prefetchit0 -0x201ea8(%rip)        # 140746 <_ZN5boost3log12v2s_mt_posix7sources3aux18get_severity_levelEv+0x16>
  3425ee:	0f 18 3d cb 30 df ff                            	prefetchit0 -0x20cf35(%rip)        # 1356c0 <_ZNK5boost3log12v2s_mt_posix4core19get_logging_enabledEv>
  3425f5:	41 53                                           	push   %r11
  3425f7:	4c 8b 1d 9a 8d ff ff                            	mov    -0x7266(%rip),%r11        # 33b398 <pthread_rwlock_rdlock@GLIBC_2.34>
  3425fe:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  342606:	4c 8b 1d 9b 8f ff ff                            	mov    -0x7065(%rip),%r11        # 33b5a8 <pthread_getspecific@GLIBC_2.34>
  34260d:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  342615:	41 0f 18 93 20 00 00 00                         	prefetcht1 0x20(%r11)
  34261d:	41 5b                                           	pop    %r11
  34261f:	e9 4c 0c e1 ff                                  	jmp    153270 <_ZN5boost3log12v2s_mt_posix7trivial6logger3getEv>
  342624:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  34262e:	66 90                                           	xchg   %ax,%ax
  342630:	0f 18 3d 29 18 e6 ff                            	prefetchit0 -0x19e7d7(%rip)        # 1a3e60 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE>
  342637:	e9 a4 a7 ea ff                                  	jmp    1ecde0 <_ZNSt6chrono3_V212steady_clock3nowEv>
  34263c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342640:	0f 18 3d b9 26 e6 ff                            	prefetchit0 -0x19d947(%rip)        # 1a4d00 <_ZN13jaegertracing4SpanD0Ev>
  342647:	e9 14 32 d8 ff                                  	jmp    c5860 <_ZNSt6vectorIN11opentracing2v29LogRecordESaIS2_EED2Ev>
  34264c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342650:	0f 18 3d b6 77 da ff                            	prefetchit0 -0x25884a(%rip)        # e9e0d <_ZN13media_service29ComposeReviewServiceProcessor21process_UploadMovieIdEiPN6apache6thrift8protocol9TProtocolES5_Pv+0x2ad>
  342657:	0f 18 3d 92 74 dd ff                            	prefetchit0 -0x228b6e(%rip)        # 119af0 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE10write_virtEPKhj>
  34265e:	0f 18 3d 9c 74 dd ff                            	prefetchit0 -0x228b64(%rip)        # 119b01 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE10write_virtEPKhj+0x11>
  342665:	e9 c6 32 d8 ff                                  	jmp    c5930 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  34266a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  342670:	0f 18 3d 8c cd d7 ff                            	prefetchit0 -0x283274(%rip)        # bf403 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0x103>
  342677:	0f 18 3d c6 cc d7 ff                            	prefetchit0 -0x28333a(%rip)        # bf344 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0x44>
  34267e:	0f 18 3d cb e2 e2 ff                            	prefetchit0 -0x1d1d35(%rip)        # 170950 <_ZNK13jaegertracing6Tracer7ExtractERKN11opentracing2v213TextMapReaderE>
  342685:	0f 18 3d 74 cc d7 ff                            	prefetchit0 -0x28338c(%rip)        # bf300 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_>
  34268c:	e9 ef 1b e7 ff                                  	jmp    1b4280 <_ZN11opentracing2v26Tracer6GlobalEv>
  342691:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  34269b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3426a0:	41 53                                           	push   %r11
  3426a2:	4c 8b 1d 5f 8d ff ff                            	mov    -0x72a1(%rip),%r11        # 33b408 <memcached_add@Base>
  3426a9:	41 0f 18 93 00 fb ff ff                         	prefetcht1 -0x500(%r11)
  3426b1:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3426b9:	4c 8b 1d c8 8f ff ff                            	mov    -0x7038(%rip),%r11        # 33b688 <memcached_pool_pop@Base>
  3426c0:	41 0f 18 93 20 f3 ff ff                         	prefetcht1 -0xce0(%r11)
  3426c8:	41 5b                                           	pop    %r11
  3426ca:	e9 41 d6 d4 ff                                  	jmp    8fd10 <memcached_pool_pop@plt>
  3426cf:	90                                              	nop
  3426d0:	41 53                                           	push   %r11
  3426d2:	4c 8b 1d 2f 8d ff ff                            	mov    -0x72d1(%rip),%r11        # 33b408 <memcached_add@Base>
  3426d9:	41 0f 18 93 11 fb ff ff                         	prefetcht1 -0x4ef(%r11)
  3426e1:	41 5b                                           	pop    %r11
  3426e3:	e9 98 e2 f1 ff                                  	jmp    260980 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE12_M_constructEmc>
  3426e8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3426f0:	0f 18 3d 4a 9b d6 ff                            	prefetchit0 -0x2964b6(%rip)        # ac241 <_ZN5boost3log12v2s_mt_posix7sources22basic_composite_loggerIcNS2_18severity_logger_mtINS1_7trivial14severity_levelEEENS2_18multi_thread_modelINS1_3aux14light_rw_mutexEEENS2_8featuresIJNS2_8severityIS6_EEEEEE11open_recordINS_9parameter3aux25tagged_argument_list_of_1INSJ_15tagged_argumentINS1_8keywords3tag8severityEKS6_EEEEEENS1_6recordERKT_+0x11>
  3426f7:	0f 18 3d 32 9b d6 ff                            	prefetchit0 -0x2964ce(%rip)        # ac230 <_ZN5boost3log12v2s_mt_posix7sources22basic_composite_loggerIcNS2_18severity_logger_mtINS1_7trivial14severity_levelEEENS2_18multi_thread_modelINS1_3aux14light_rw_mutexEEENS2_8featuresIJNS2_8severityIS6_EEEEEE11open_recordINS_9parameter3aux25tagged_argument_list_of_1INSJ_15tagged_argumentINS1_8keywords3tag8severityEKS6_EEEEEENS1_6recordERKT_>
  3426fe:	0f 18 3d bb 2f df ff                            	prefetchit0 -0x20d045(%rip)        # 1356c0 <_ZNK5boost3log12v2s_mt_posix4core19get_logging_enabledEv>
  342705:	41 53                                           	push   %r11
  342707:	4c 8b 1d 8a 8c ff ff                            	mov    -0x7376(%rip),%r11        # 33b398 <pthread_rwlock_rdlock@GLIBC_2.34>
  34270e:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  342716:	4c 8b 1d 8b 8e ff ff                            	mov    -0x7175(%rip),%r11        # 33b5a8 <pthread_getspecific@GLIBC_2.34>
  34271d:	41 0f 18 93 20 00 00 00                         	prefetcht1 0x20(%r11)
  342725:	41 5b                                           	pop    %r11
  342727:	e9 44 0b e1 ff                                  	jmp    153270 <_ZN5boost3log12v2s_mt_posix7trivial6logger3getEv>
  34272c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342730:	0f 18 3d 29 17 e6 ff                            	prefetchit0 -0x19e8d7(%rip)        # 1a3e60 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE>
  342737:	e9 54 cc d4 ff                                  	jmp    8f390 <memcached_pool_push@plt>
  34273c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342740:	0f 18 3d aa 87 da ff                            	prefetchit0 -0x257856(%rip)        # eaef1 <_ZN13media_service29ComposeReviewServiceProcessor20process_UploadUserIdEiPN6apache6thrift8protocol9TProtocolES5_Pv+0x291>
  342747:	0f 18 3d a2 95 d8 ff                            	prefetchit0 -0x276a5e(%rip)        # cbcf0 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE22writeMessageBegin_virtERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  34274e:	0f 18 3d ab a0 d8 ff                            	prefetchit0 -0x275f55(%rip)        # cc800 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE17writeMessageBeginERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi+0x30>
  342755:	0f 18 3d a5 73 dd ff                            	prefetchit0 -0x228c5b(%rip)        # 119b01 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE10write_virtEPKhj+0x11>
  34275c:	0f 18 3d 8d 73 dd ff                            	prefetchit0 -0x228c73(%rip)        # 119af0 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE10write_virtEPKhj>
  342763:	e9 c8 31 d8 ff                                  	jmp    c5930 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  342768:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  342770:	0f 18 3d d9 e1 e2 ff                            	prefetchit0 -0x1d1e27(%rip)        # 170950 <_ZNK13jaegertracing6Tracer7ExtractERKN11opentracing2v213TextMapReaderE>
  342777:	0f 18 3d 85 cc d7 ff                            	prefetchit0 -0x28337b(%rip)        # bf403 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0x103>
  34277e:	0f 18 3d 3e cc d7 ff                            	prefetchit0 -0x2833c2(%rip)        # bf3c3 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0xc3>
  342785:	0f 18 3d 74 cb d7 ff                            	prefetchit0 -0x28348c(%rip)        # bf300 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_>
  34278c:	e9 ef 1a e7 ff                                  	jmp    1b4280 <_ZN11opentracing2v26Tracer6GlobalEv>
  342791:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  34279b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3427a0:	41 53                                           	push   %r11
  3427a2:	4c 8b 1d 5f 8c ff ff                            	mov    -0x73a1(%rip),%r11        # 33b408 <memcached_add@Base>
  3427a9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3427b1:	4c 8b 1d d0 8e ff ff                            	mov    -0x7130(%rip),%r11        # 33b688 <memcached_pool_pop@Base>
  3427b8:	41 0f 18 93 a0 f3 ff ff                         	prefetcht1 -0xc60(%r11)
  3427c0:	41 5b                                           	pop    %r11
  3427c2:	e9 49 d5 d4 ff                                  	jmp    8fd10 <memcached_pool_pop@plt>
  3427c7:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  3427d0:	0f 18 3d 6a 9a d6 ff                            	prefetchit0 -0x296596(%rip)        # ac241 <_ZN5boost3log12v2s_mt_posix7sources22basic_composite_loggerIcNS2_18severity_logger_mtINS1_7trivial14severity_levelEEENS2_18multi_thread_modelINS1_3aux14light_rw_mutexEEENS2_8featuresIJNS2_8severityIS6_EEEEEE11open_recordINS_9parameter3aux25tagged_argument_list_of_1INSJ_15tagged_argumentINS1_8keywords3tag8severityEKS6_EEEEEENS1_6recordERKT_+0x11>
  3427d7:	0f 18 3d 52 9a d6 ff                            	prefetchit0 -0x2965ae(%rip)        # ac230 <_ZN5boost3log12v2s_mt_posix7sources22basic_composite_loggerIcNS2_18severity_logger_mtINS1_7trivial14severity_levelEEENS2_18multi_thread_modelINS1_3aux14light_rw_mutexEEENS2_8featuresIJNS2_8severityIS6_EEEEEE11open_recordINS_9parameter3aux25tagged_argument_list_of_1INSJ_15tagged_argumentINS1_8keywords3tag8severityEKS6_EEEEEENS1_6recordERKT_>
  3427de:	0f 18 3d db 2e df ff                            	prefetchit0 -0x20d125(%rip)        # 1356c0 <_ZNK5boost3log12v2s_mt_posix4core19get_logging_enabledEv>
  3427e5:	0f 18 3d 5a df df ff                            	prefetchit0 -0x2020a6(%rip)        # 140746 <_ZN5boost3log12v2s_mt_posix7sources3aux18get_severity_levelEv+0x16>
  3427ec:	0f 18 3d 8e df df ff                            	prefetchit0 -0x202072(%rip)        # 140781 <_ZN5boost3log12v2s_mt_posix7sources3aux18get_severity_levelEv+0x51>
  3427f3:	0f 18 3d 87 38 df ff                            	prefetchit0 -0x20c779(%rip)        # 136081 <_ZN5boost3log12v2s_mt_posix4core11open_recordERKNS1_13attribute_setE+0x21>
  3427fa:	41 53                                           	push   %r11
  3427fc:	4c 8b 1d 95 8b ff ff                            	mov    -0x746b(%rip),%r11        # 33b398 <pthread_rwlock_rdlock@GLIBC_2.34>
  342803:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  34280b:	4c 8b 1d 96 8d ff ff                            	mov    -0x726a(%rip),%r11        # 33b5a8 <pthread_getspecific@GLIBC_2.34>
  342812:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  34281a:	41 5b                                           	pop    %r11
  34281c:	e9 4f 0a e1 ff                                  	jmp    153270 <_ZN5boost3log12v2s_mt_posix7trivial6logger3getEv>
  342821:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  34282b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  342830:	0f 18 3d 79 d1 d4 ff                            	prefetchit0 -0x2b2e87(%rip)        # 8f9b0 <malloc@plt>
  342837:	e9 f4 99 d6 ff                                  	jmp    ac230 <_ZN5boost3log12v2s_mt_posix7sources22basic_composite_loggerIcNS2_18severity_logger_mtINS1_7trivial14severity_levelEEENS2_18multi_thread_modelINS1_3aux14light_rw_mutexEEENS2_8featuresIJNS2_8severityIS6_EEEEEE11open_recordINS_9parameter3aux25tagged_argument_list_of_1INSJ_15tagged_argumentINS1_8keywords3tag8severityEKS6_EEEEEENS1_6recordERKT_>
  34283c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342840:	0f 18 3d 19 37 e6 ff                            	prefetchit0 -0x19c8e7(%rip)        # 1a5f60 <_ZNSt11__copy_moveILb0ELb0ESt26random_access_iterator_tagE8__copy_mIPKN11opentracing2v29LogRecordESt20back_insert_iteratorISt6vectorIN13jaegertracing9LogRecordESaISB_EEEEET0_T_SG_SF_>
  342847:	e9 44 cb d4 ff                                  	jmp    8f390 <memcached_pool_push@plt>
  34284c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342850:	0f 18 3d 3a 7e da ff                            	prefetchit0 -0x2581c6(%rip)        # ea691 <_ZN13media_service29ComposeReviewServiceProcessor22process_UploadUniqueIdEiPN6apache6thrift8protocol9TProtocolES5_Pv+0x291>
  342857:	0f 18 3d a3 72 dd ff                            	prefetchit0 -0x228d5d(%rip)        # 119b01 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE10write_virtEPKhj+0x11>
  34285e:	0f 18 3d 8b 72 dd ff                            	prefetchit0 -0x228d75(%rip)        # 119af0 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE10write_virtEPKhj>
  342865:	e9 c6 30 d8 ff                                  	jmp    c5930 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  34286a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  342870:	0f 18 3d 89 ca d7 ff                            	prefetchit0 -0x283577(%rip)        # bf300 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_>
  342877:	0f 18 3d 85 cb d7 ff                            	prefetchit0 -0x28347b(%rip)        # bf403 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0x103>
  34287e:	0f 18 3d cb e0 e2 ff                            	prefetchit0 -0x1d1f35(%rip)        # 170950 <_ZNK13jaegertracing6Tracer7ExtractERKN11opentracing2v213TextMapReaderE>
  342885:	0f 18 3d b8 ca d7 ff                            	prefetchit0 -0x283548(%rip)        # bf344 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0x44>
  34288c:	e9 ef 19 e7 ff                                  	jmp    1b4280 <_ZN11opentracing2v26Tracer6GlobalEv>
  342891:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  34289b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3428a0:	0f 18 3d f9 dc e2 ff                            	prefetchit0 -0x1d2307(%rip)        # 1705a0 <_ZNK13jaegertracing6Tracer6InjectERKN11opentracing2v211SpanContextERKNS2_13TextMapWriterE>
  3428a7:	0f 18 3d 92 6a f1 ff                            	prefetchit0 -0xe956e(%rip)        # 259340 <_ZNSt7__cxx1119basic_ostringstreamIcSt11char_traitsIcESaIcEEC1Ev>
  3428ae:	e9 cd 19 e7 ff                                  	jmp    1b4280 <_ZN11opentracing2v26Tracer6GlobalEv>
  3428b3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3428bd:	0f 1f 00                                        	nopl   (%rax)
  3428c0:	41 53                                           	push   %r11
  3428c2:	4c 8b 1d 3f 8b ff ff                            	mov    -0x74c1(%rip),%r11        # 33b408 <memcached_add@Base>
  3428c9:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3428d1:	4c 8b 1d b8 8d ff ff                            	mov    -0x7248(%rip),%r11        # 33b690 <memcached_increment@Base>
  3428d8:	41 0f 18 93 20 fd ff ff                         	prefetcht1 -0x2e0(%r11)
  3428e0:	41 5b                                           	pop    %r11
  3428e2:	e9 29 d4 d4 ff                                  	jmp    8fd10 <memcached_pool_pop@plt>
  3428e7:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  3428f0:	0f 18 3d 4a 99 d6 ff                            	prefetchit0 -0x2966b6(%rip)        # ac241 <_ZN5boost3log12v2s_mt_posix7sources22basic_composite_loggerIcNS2_18severity_logger_mtINS1_7trivial14severity_levelEEENS2_18multi_thread_modelINS1_3aux14light_rw_mutexEEENS2_8featuresIJNS2_8severityIS6_EEEEEE11open_recordINS_9parameter3aux25tagged_argument_list_of_1INSJ_15tagged_argumentINS1_8keywords3tag8severityEKS6_EEEEEENS1_6recordERKT_+0x11>
  3428f7:	0f 18 3d 83 de df ff                            	prefetchit0 -0x20217d(%rip)        # 140781 <_ZN5boost3log12v2s_mt_posix7sources3aux18get_severity_levelEv+0x51>
  3428fe:	0f 18 3d 2b 99 d6 ff                            	prefetchit0 -0x2966d5(%rip)        # ac230 <_ZN5boost3log12v2s_mt_posix7sources22basic_composite_loggerIcNS2_18severity_logger_mtINS1_7trivial14severity_levelEEENS2_18multi_thread_modelINS1_3aux14light_rw_mutexEEENS2_8featuresIJNS2_8severityIS6_EEEEEE11open_recordINS_9parameter3aux25tagged_argument_list_of_1INSJ_15tagged_argumentINS1_8keywords3tag8severityEKS6_EEEEEENS1_6recordERKT_>
  342905:	0f 18 3d b4 2d df ff                            	prefetchit0 -0x20d24c(%rip)        # 1356c0 <_ZNK5boost3log12v2s_mt_posix4core19get_logging_enabledEv>
  34290c:	0f 18 3d 6e 37 df ff                            	prefetchit0 -0x20c892(%rip)        # 136081 <_ZN5boost3log12v2s_mt_posix4core11open_recordERKNS1_13attribute_setE+0x21>
  342913:	0f 18 3d e6 6f df ff                            	prefetchit0 -0x20901a(%rip)        # 139900 <_ZN5boost3log12v2s_mt_posix4core14implementation15get_thread_dataEv+0x30>
  34291a:	0f 18 3d 25 de df ff                            	prefetchit0 -0x2021db(%rip)        # 140746 <_ZN5boost3log12v2s_mt_posix7sources3aux18get_severity_levelEv+0x16>
  342921:	41 53                                           	push   %r11
  342923:	4c 8b 1d 7e 8c ff ff                            	mov    -0x7382(%rip),%r11        # 33b5a8 <pthread_getspecific@GLIBC_2.34>
  34292a:	41 0f 18 93 20 00 00 00                         	prefetcht1 0x20(%r11)
  342932:	41 5b                                           	pop    %r11
  342934:	e9 37 09 e1 ff                                  	jmp    153270 <_ZN5boost3log12v2s_mt_posix7trivial6logger3getEv>
  342939:	0f 1f 80 00 00 00 00                            	nopl   0x0(%rax)
  342940:	41 53                                           	push   %r11
  342942:	4c 8b 1d 5f 8c ff ff                            	mov    -0x73a1(%rip),%r11        # 33b5a8 <pthread_getspecific@GLIBC_2.34>
  342949:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  342951:	41 5b                                           	pop    %r11
  342953:	e9 d8 98 d6 ff                                  	jmp    ac230 <_ZN5boost3log12v2s_mt_posix7sources22basic_composite_loggerIcNS2_18severity_logger_mtINS1_7trivial14severity_levelEEENS2_18multi_thread_modelINS1_3aux14light_rw_mutexEEENS2_8featuresIJNS2_8severityIS6_EEEEEE11open_recordINS_9parameter3aux25tagged_argument_list_of_1INSJ_15tagged_argumentINS1_8keywords3tag8severityEKS6_EEEEEENS1_6recordERKT_>
  342958:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  342960:	0f 18 3d f9 14 e6 ff                            	prefetchit0 -0x19eb07(%rip)        # 1a3e60 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE>
  342967:	0f 18 3d f2 35 e6 ff                            	prefetchit0 -0x19ca0e(%rip)        # 1a5f60 <_ZNSt11__copy_moveILb0ELb0ESt26random_access_iterator_tagE8__copy_mIPKN11opentracing2v29LogRecordESt20back_insert_iteratorISt6vectorIN13jaegertracing9LogRecordESaISB_EEEEET0_T_SG_SF_>
  34296e:	e9 1d ca d4 ff                                  	jmp    8f390 <memcached_pool_push@plt>
  342973:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  34297d:	0f 1f 00                                        	nopl   (%rax)
  342980:	0f 18 3d 7a 71 dd ff                            	prefetchit0 -0x228e86(%rip)        # 119b01 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE10write_virtEPKhj+0x11>
  342987:	0f 18 3d 7f 63 da ff                            	prefetchit0 -0x259c81(%rip)        # e8d0d <_ZN13media_service29ComposeReviewServiceProcessor18process_UploadTextEiPN6apache6thrift8protocol9TProtocolES5_Pv+0x2ad>
  34298e:	0f 18 3d 5b 93 d8 ff                            	prefetchit0 -0x276ca5(%rip)        # cbcf0 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE22writeMessageBegin_virtERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  342995:	0f 18 3d 54 71 dd ff                            	prefetchit0 -0x228eac(%rip)        # 119af0 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE10write_virtEPKhj>
  34299c:	e9 8f 2f d8 ff                                  	jmp    c5930 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  3429a1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3429ab:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3429b0:	0f 18 3d 49 c9 d7 ff                            	prefetchit0 -0x2836b7(%rip)        # bf300 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_>
  3429b7:	0f 18 3d 92 df e2 ff                            	prefetchit0 -0x1d206e(%rip)        # 170950 <_ZNK13jaegertracing6Tracer7ExtractERKN11opentracing2v213TextMapReaderE>
  3429be:	0f 18 3d 7f c9 d7 ff                            	prefetchit0 -0x283681(%rip)        # bf344 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0x44>
  3429c5:	0f 18 3d 37 ca d7 ff                            	prefetchit0 -0x2835c9(%rip)        # bf403 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_+0x103>
  3429cc:	e9 af 18 e7 ff                                  	jmp    1b4280 <_ZN11opentracing2v26Tracer6GlobalEv>
  3429d1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3429db:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  3429e0:	41 53                                           	push   %r11
  3429e2:	4c 8b 1d 1f 8a ff ff                            	mov    -0x75e1(%rip),%r11        # 33b408 <memcached_add@Base>
  3429e9:	41 0f 18 93 00 fb ff ff                         	prefetcht1 -0x500(%r11)
  3429f1:	41 5b                                           	pop    %r11
  3429f3:	e9 18 d3 d4 ff                                  	jmp    8fd10 <memcached_pool_pop@plt>
  3429f8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  342a00:	0f 18 3d 29 98 d6 ff                            	prefetchit0 -0x2967d7(%rip)        # ac230 <_ZN5boost3log12v2s_mt_posix7sources22basic_composite_loggerIcNS2_18severity_logger_mtINS1_7trivial14severity_levelEEENS2_18multi_thread_modelINS1_3aux14light_rw_mutexEEENS2_8featuresIJNS2_8severityIS6_EEEEEE11open_recordINS_9parameter3aux25tagged_argument_list_of_1INSJ_15tagged_argumentINS1_8keywords3tag8severityEKS6_EEEEEENS1_6recordERKT_>
  342a07:	e9 64 08 e1 ff                                  	jmp    153270 <_ZN5boost3log12v2s_mt_posix7trivial6logger3getEv>
  342a0c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342a10:	0f 18 3d 2f dd df ff                            	prefetchit0 -0x2022d1(%rip)        # 140746 <_ZN5boost3log12v2s_mt_posix7sources3aux18get_severity_levelEv+0x16>
  342a17:	0f 18 3d 63 dd df ff                            	prefetchit0 -0x20229d(%rip)        # 140781 <_ZN5boost3log12v2s_mt_posix7sources3aux18get_severity_levelEv+0x51>
  342a1e:	41 53                                           	push   %r11
  342a20:	4c 8b 1d 71 89 ff ff                            	mov    -0x768f(%rip),%r11        # 33b398 <pthread_rwlock_rdlock@GLIBC_2.34>
  342a27:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  342a2f:	4c 8b 1d 72 8b ff ff                            	mov    -0x748e(%rip),%r11        # 33b5a8 <pthread_getspecific@GLIBC_2.34>
  342a36:	41 0f 18 93 20 00 00 00                         	prefetcht1 0x20(%r11)
  342a3e:	41 5b                                           	pop    %r11
  342a40:	e9 eb 97 d6 ff                                  	jmp    ac230 <_ZN5boost3log12v2s_mt_posix7sources22basic_composite_loggerIcNS2_18severity_logger_mtINS1_7trivial14severity_levelEEENS2_18multi_thread_modelINS1_3aux14light_rw_mutexEEENS2_8featuresIJNS2_8severityIS6_EEEEEE11open_recordINS_9parameter3aux25tagged_argument_list_of_1INSJ_15tagged_argumentINS1_8keywords3tag8severityEKS6_EEEEEENS1_6recordERKT_>
  342a45:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  342a4f:	90                                              	nop
  342a50:	0f 18 3d 59 a5 d5 ff                            	prefetchit0 -0x2a5aa7(%rip)        # 9cfb0 <_ZN13media_service20ComposeReviewHandler17_ComposeAndUploadElRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES7_St4lessIS7_ESaISt4pairIKS7_S7_EEE>
  342a57:	e9 34 c9 d4 ff                                  	jmp    8f390 <memcached_pool_push@plt>
  342a5c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342a60:	0f 18 3d 25 6b da ff                            	prefetchit0 -0x2594db(%rip)        # e958c <_ZN13media_service29ComposeReviewServiceProcessor20process_UploadRatingEiPN6apache6thrift8protocol9TProtocolES5_Pv+0x29c>
  342a67:	0f 18 3d 82 92 d8 ff                            	prefetchit0 -0x276d7e(%rip)        # cbcf0 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE22writeMessageBegin_virtERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  342a6e:	e9 bd 2e d8 ff                                  	jmp    c5930 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  342a73:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  342a7d:	0f 1f 00                                        	nopl   (%rax)
  342a80:	0f 18 3d 59 8f d8 ff                            	prefetchit0 -0x2770a7(%rip)        # cb9e0 <_ZN13media_service12ThriftClientINS_26ReviewStorageServiceClientEE7ConnectEv>
  342a87:	0f 18 3d 32 0d dd ff                            	prefetchit0 -0x22f2ce(%rip)        # 1137c0 <_ZN6apache6thrift9transport7TSocket6isOpenEv>
  342a8e:	0f 18 3d 6b 6f dd ff                            	prefetchit0 -0x229095(%rip)        # 119a00 <_ZN6apache6thrift9transport16TFramedTransport6isOpenEv>
  342a95:	0f 18 3d 54 c7 f0 ff                            	prefetchit0 -0xf38ac(%rip)        # 24f1f0 <__once_proxy>
  342a9c:	0f 18 3d cd 75 d8 ff                            	prefetchit0 -0x278a33(%rip)        # ca070 <_ZNSt13__future_base13_State_baseV29_M_do_setEPSt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEPb>
  342aa3:	0f 18 3d 16 76 d8 ff                            	prefetchit0 -0x2789ea(%rip)        # ca0c0 <_ZZNSt9once_flag18_Prepare_executionC1IZSt9call_onceIMNSt13__future_base13_State_baseV2EFvPSt8functionIFSt10unique_ptrINS3_12_Result_baseENS7_8_DeleterEEvEEPbEJPS4_SC_SD_EEvRS_OT_DpOT0_EUlvE_EERSI_ENUlvE_8__invokeEv>
  342aaa:	0f 18 3d bf cc d4 ff                            	prefetchit0 -0x2b3341(%rip)        # 8f770 <pthread_once@plt>
  342ab1:	0f 18 3d 49 c7 f0 ff                            	prefetchit0 -0xf38b7(%rip)        # 24f201 <__once_proxy+0x11>
  342ab8:	e9 93 73 d8 ff                                  	jmp    c9e50 <_ZNSt13__future_base13_State_baseV213_M_set_resultESt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEb>
  342abd:	0f 1f 00                                        	nopl   (%rax)
  342ac0:	0f 18 3d 69 95 db ff                            	prefetchit0 -0x246a97(%rip)        # fc030 <_ZN13media_service26ReviewStorageServiceClient11StoreReviewElRKNS_6ReviewERKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESA_St4lessISA_ESaISt4pairIKSA_SA_EEE>
  342ac7:	0f 18 3d 38 7d d8 ff                            	prefetchit0 -0x2782c8(%rip)        # ca806 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_26ReviewStorageServiceClientEEEE3PopEv+0x706>
  342ace:	e9 2d 76 d8 ff                                  	jmp    ca100 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_26ReviewStorageServiceClientEEEE3PopEv>
  342ad3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  342add:	0f 1f 00                                        	nopl   (%rax)
  342ae0:	0f 18 3d 89 8f d8 ff                            	prefetchit0 -0x277077(%rip)        # cba70 <_ZN13media_service12ThriftClientINS_26ReviewStorageServiceClientEE9KeepAliveEv>
  342ae7:	0f 18 3d 82 d5 ea ff                            	prefetchit0 -0x152a7e(%rip)        # 1f0070 <_ZNSt18condition_variable10notify_oneEv>
  342aee:	0f 18 3d 0b 74 d8 ff                            	prefetchit0 -0x278bf5(%rip)        # c9f00 <_ZNSt13__future_base13_State_baseV213_M_set_resultESt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEb+0xb0>
  342af5:	0f 18 3d 68 72 d6 ff                            	prefetchit0 -0x298d98(%rip)        # a9d64 <_ZNSt13__future_base17_Async_state_implINSt6thread8_InvokerISt5tupleIJZN13media_service20ComposeReviewHandler17_ComposeAndUploadElRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESC_St4lessISC_ESaISt4pairIKSC_SC_EEEE3$_0EEEEvE6_M_runEv+0x44>
  342afc:	e9 5f 81 d8 ff                                  	jmp    cac60 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_26ReviewStorageServiceClientEEEE4PushEPS3_>
  342b01:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  342b0b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  342b10:	41 53                                           	push   %r11
  342b12:	4c 8b 1d bf 89 ff ff                            	mov    -0x7641(%rip),%r11        # 33b4d8 <malloc@GLIBC_2.2.5>
  342b19:	41 0f 18 93 22 c0 ff ff                         	prefetcht1 -0x3fde(%r11)
  342b21:	41 5b                                           	pop    %r11
  342b23:	e9 78 13 f2 ff                                  	jmp    263ea0 <_ZNSt6thread6_StateD1Ev>
  342b28:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  342b30:	0f 18 3d 89 75 d8 ff                            	prefetchit0 -0x278a77(%rip)        # ca0c0 <_ZZNSt9once_flag18_Prepare_executionC1IZSt9call_onceIMNSt13__future_base13_State_baseV2EFvPSt8functionIFSt10unique_ptrINS3_12_Result_baseENS7_8_DeleterEEvEEPbEJPS4_SC_SD_EEvRS_OT_DpOT0_EUlvE_EERSI_ENUlvE_8__invokeEv>
  342b37:	0f 18 3d 22 b1 d8 ff                            	prefetchit0 -0x274ede(%rip)        # cdc60 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_23UserReviewServiceClientEEEE3PopEv>
  342b3e:	0f 18 3d ff 79 d6 ff                            	prefetchit0 -0x298601(%rip)        # aa544 <_ZNSt17_Function_handlerIFSt10unique_ptrINSt13__future_base12_Result_baseENS2_8_DeleterEEvENS1_12_Task_setterIS0_INS1_7_ResultIvEES3_ENSt6thread8_InvokerISt5tupleIJZN13media_service20ComposeReviewHandler17_ComposeAndUploadElRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESL_St4lessISL_ESaISt4pairIKSL_SL_EEEE3$_1EEEEvEEE9_M_invokeERKSt9_Any_data+0x24>
  342b45:	0f 18 3d a4 c6 f0 ff                            	prefetchit0 -0xf395c(%rip)        # 24f1f0 <__once_proxy>
  342b4c:	0f 18 3d 1d cc d4 ff                            	prefetchit0 -0x2b33e3(%rip)        # 8f770 <pthread_once@plt>
  342b53:	0f 18 3d 16 75 d8 ff                            	prefetchit0 -0x278aea(%rip)        # ca070 <_ZNSt13__future_base13_State_baseV29_M_do_setEPSt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEPb>
  342b5a:	e9 f1 72 d8 ff                                  	jmp    c9e50 <_ZNSt13__future_base13_State_baseV213_M_set_resultESt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEb>
  342b5f:	90                                              	nop
  342b60:	0f 18 3d ff b7 d8 ff                            	prefetchit0 -0x274801(%rip)        # ce366 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_23UserReviewServiceClientEEEE3PopEv+0x706>
  342b67:	0f 18 3d f2 0d dc ff                            	prefetchit0 -0x23f20e(%rip)        # 103960 <_ZN13media_service23UserReviewServiceClient16UploadUserReviewEllllRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES7_St4lessIS7_ESaISt4pairIKS7_S7_EEE>
  342b6e:	0f 18 3d 4b 0c dd ff                            	prefetchit0 -0x22f3b5(%rip)        # 1137c0 <_ZN6apache6thrift9transport7TSocket6isOpenEv>
  342b75:	0f 18 3d 84 6e dd ff                            	prefetchit0 -0x22917c(%rip)        # 119a00 <_ZN6apache6thrift9transport16TFramedTransport6isOpenEv>
  342b7c:	0f 18 3d bd c7 d8 ff                            	prefetchit0 -0x273843(%rip)        # cf340 <_ZN13media_service12ThriftClientINS_23UserReviewServiceClientEE7ConnectEv>
  342b83:	0f 18 3d 56 dd f1 ff                            	prefetchit0 -0xe22aa(%rip)        # 2608e0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm>
  342b8a:	e9 d1 b0 d8 ff                                  	jmp    cdc60 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_23UserReviewServiceClientEEEE3PopEv>
  342b8f:	90                                              	nop
  342b90:	0f 18 3d f9 7c d6 ff                            	prefetchit0 -0x298307(%rip)        # aa890 <_ZNSt17_Function_handlerIFSt10unique_ptrINSt13__future_base12_Result_baseENS2_8_DeleterEEvENS1_12_Task_setterIS0_INS1_7_ResultIvEES3_ENSt6thread8_InvokerISt5tupleIJZN13media_service20ComposeReviewHandler17_ComposeAndUploadElRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESL_St4lessISL_ESaISt4pairIKSL_SL_EEEE3$_1EEEEvEEE10_M_managerERSt9_Any_dataRKS10_St18_Manager_operation>
  342b97:	0f 18 3d 32 c8 d8 ff                            	prefetchit0 -0x2737ce(%rip)        # cf3d0 <_ZN13media_service12ThriftClientINS_23UserReviewServiceClientEE9KeepAliveEv>
  342b9e:	0f 18 3d ef 77 d6 ff                            	prefetchit0 -0x298811(%rip)        # aa394 <_ZNSt13__future_base17_Async_state_implINSt6thread8_InvokerISt5tupleIJZN13media_service20ComposeReviewHandler17_ComposeAndUploadElRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESC_St4lessISC_ESaISt4pairIKSC_SC_EEEE3$_1EEEEvE6_M_runEv+0x44>
  342ba5:	0f 18 3d db 74 d8 ff                            	prefetchit0 -0x278b25(%rip)        # ca087 <_ZNSt13__future_base13_State_baseV29_M_do_setEPSt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEPb+0x17>
  342bac:	0f 18 3d 4d 73 d8 ff                            	prefetchit0 -0x278cb3(%rip)        # c9f00 <_ZNSt13__future_base13_State_baseV213_M_set_resultESt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEb+0xb0>
  342bb3:	0f 18 3d b6 d4 ea ff                            	prefetchit0 -0x152b4a(%rip)        # 1f0070 <_ZNSt18condition_variable10notify_oneEv>
  342bba:	e9 01 bc d8 ff                                  	jmp    ce7c0 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_23UserReviewServiceClientEEEE4PushEPS3_>
  342bbf:	90                                              	nop
  342bc0:	41 53                                           	push   %r11
  342bc2:	4c 8b 1d 57 84 ff ff                            	mov    -0x7ba9(%rip),%r11        # 33b020 <pthread_cond_signal@GLIBC_2.3.2>
  342bc9:	41 0f 18 93 d0 e3 ff ff                         	prefetcht1 -0x1c30(%r11)
  342bd1:	4c 8b 1d 48 89 ff ff                            	mov    -0x76b8(%rip),%r11        # 33b520 <strtol@GLIBC_2.2.5>
  342bd8:	41 0f 18 93 80 e8 ff ff                         	prefetcht1 -0x1780(%r11)
  342be0:	41 5b                                           	pop    %r11
  342be2:	e9 b9 12 f2 ff                                  	jmp    263ea0 <_ZNSt6thread6_StateD1Ev>
  342be7:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  342bf0:	0f 18 3d e9 cd d8 ff                            	prefetchit0 -0x273217(%rip)        # cf9e0 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_24MovieReviewServiceClientEEEE3PopEv>
  342bf7:	0f 18 3d e8 d4 d8 ff                            	prefetchit0 -0x272b18(%rip)        # d00e6 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_24MovieReviewServiceClientEEEE3PopEv+0x706>
  342bfe:	0f 18 3d fc cd d8 ff                            	prefetchit0 -0x273204(%rip)        # cfa01 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_24MovieReviewServiceClientEEEE3PopEv+0x21>
  342c05:	0f 18 3d b4 0b dd ff                            	prefetchit0 -0x22f44c(%rip)        # 1137c0 <_ZN6apache6thrift9transport7TSocket6isOpenEv>
  342c0c:	0f 18 3d ed 6d dd ff                            	prefetchit0 -0x229213(%rip)        # 119a00 <_ZN6apache6thrift9transport16TFramedTransport6isOpenEv>
  342c13:	0f 18 3d a6 74 d8 ff                            	prefetchit0 -0x278b5a(%rip)        # ca0c0 <_ZZNSt9once_flag18_Prepare_executionC1IZSt9call_onceIMNSt13__future_base13_State_baseV2EFvPSt8functionIFSt10unique_ptrINS3_12_Result_baseENS7_8_DeleterEEvEEPbEJPS4_SC_SD_EEvRS_OT_DpOT0_EUlvE_EERSI_ENUlvE_8__invokeEv>
  342c1a:	0f 18 3d 9f e4 d8 ff                            	prefetchit0 -0x271b61(%rip)        # d10c0 <_ZN13media_service12ThriftClientINS_24MovieReviewServiceClientEE7ConnectEv>
  342c21:	0f 18 3d d9 c5 f0 ff                            	prefetchit0 -0xf3a27(%rip)        # 24f201 <__once_proxy+0x11>
  342c28:	e9 23 72 d8 ff                                  	jmp    c9e50 <_ZNSt13__future_base13_State_baseV213_M_set_resultESt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEb>
  342c2d:	0f 1f 00                                        	nopl   (%rax)
  342c30:	0f 18 3d 99 82 d6 ff                            	prefetchit0 -0x297d67(%rip)        # aaed0 <_ZNSt17_Function_handlerIFSt10unique_ptrINSt13__future_base12_Result_baseENS2_8_DeleterEEvENS1_12_Task_setterIS0_INS1_7_ResultIvEES3_ENSt6thread8_InvokerISt5tupleIJZN13media_service20ComposeReviewHandler17_ComposeAndUploadElRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESL_St4lessISL_ESaISt4pairIKSL_SL_EEEE3$_2EEEEvEEE10_M_managerERSt9_Any_dataRKS10_St18_Manager_operation>
  342c37:	0f 18 3d 12 e5 d8 ff                            	prefetchit0 -0x271aee(%rip)        # d1150 <_ZN13media_service12ThriftClientINS_24MovieReviewServiceClientEE9KeepAliveEv>
  342c3e:	0f 18 3d 8f 7d d6 ff                            	prefetchit0 -0x298271(%rip)        # aa9d4 <_ZNSt13__future_base17_Async_state_implINSt6thread8_InvokerISt5tupleIJZN13media_service20ComposeReviewHandler17_ComposeAndUploadElRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESC_St4lessISC_ESaISt4pairIKSC_SC_EEEE3$_2EEEEvE6_M_runEv+0x44>
  342c45:	0f 18 3d 3b 74 d8 ff                            	prefetchit0 -0x278bc5(%rip)        # ca087 <_ZNSt13__future_base13_State_baseV29_M_do_setEPSt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEPb+0x17>
  342c4c:	0f 18 3d ad 72 d8 ff                            	prefetchit0 -0x278d53(%rip)        # c9f00 <_ZNSt13__future_base13_State_baseV213_M_set_resultESt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEb+0xb0>
  342c53:	0f 18 3d 8d 72 d8 ff                            	prefetchit0 -0x278d73(%rip)        # c9ee7 <_ZNSt13__future_base13_State_baseV213_M_set_resultESt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEb+0x97>
  342c5a:	e9 e1 d8 d8 ff                                  	jmp    d0540 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_24MovieReviewServiceClientEEEE4PushEPS3_>
  342c5f:	90                                              	nop
  342c60:	41 53                                           	push   %r11
  342c62:	4c 8b 1d b7 88 ff ff                            	mov    -0x7749(%rip),%r11        # 33b520 <strtol@GLIBC_2.2.5>
  342c69:	41 0f 18 93 80 e8 ff ff                         	prefetcht1 -0x1780(%r11)
  342c71:	4c 8b 1d f8 89 ff ff                            	mov    -0x7608(%rip),%r11        # 33b670 <pthread_create@GLIBC_2.34>
  342c78:	41 0f 18 93 83 fe ff ff                         	prefetcht1 -0x17d(%r11)
  342c80:	41 5b                                           	pop    %r11
  342c82:	e9 19 12 f2 ff                                  	jmp    263ea0 <_ZNSt6thread6_StateD1Ev>
  342c87:	66 0f 1f 84 00 00 00 00 00                      	nopw   0x0(%rax,%rax,1)
  342c90:	0f 18 3d 39 6c df ff                            	prefetchit0 -0x2093c7(%rip)        # 1398d0 <_ZN5boost3log12v2s_mt_posix4core14implementation15get_thread_dataEv>
  342c97:	0f 18 3d 82 04 e1 ff                            	prefetchit0 -0x1efb7e(%rip)        # 153120 <_ZNK5boost3log12v2s_mt_posix3aux20thread_specific_base11get_contentEv>
  342c9e:	0f 18 3d 8b da df ff                            	prefetchit0 -0x202575(%rip)        # 140730 <_ZN5boost3log12v2s_mt_posix7sources3aux18get_severity_levelEv>
  342ca5:	0f 18 3d b4 33 df ff                            	prefetchit0 -0x20cc4c(%rip)        # 136060 <_ZN5boost3log12v2s_mt_posix4core11open_recordERKNS1_13attribute_setE>
  342cac:	0f 18 3d 0d 91 e8 ff                            	prefetchit0 -0x176ef3(%rip)        # 1cbdc0 <_ZN5boost6detail12get_tss_dataEPKv>
  342cb3:	0f 18 3d e6 8b e8 ff                            	prefetchit0 -0x17741a(%rip)        # 1cb8a0 <_ZN5boost6detail23get_current_thread_dataEv>
  342cba:	0f 18 3d bf 35 e9 ff                            	prefetchit0 -0x16ca41(%rip)        # 1d6280 <_ZN5boost13thread_detail17enter_once_regionERNS_9once_flagE>
  342cc1:	0f 18 3d a8 ca de ff                            	prefetchit0 -0x213558(%rip)        # 12f770 <_ZN5boost3log12v2s_mt_posix19attribute_value_setC1ERKNS1_13attribute_setES5_S5_m>
  342cc8:	e9 f3 29 df ff                                  	jmp    1356c0 <_ZNK5boost3log12v2s_mt_posix4core19get_logging_enabledEv>
  342ccd:	0f 1f 00                                        	nopl   (%rax)
  342cd0:	0f 18 3d 29 6c df ff                            	prefetchit0 -0x2093d7(%rip)        # 139900 <_ZN5boost3log12v2s_mt_posix4core14implementation15get_thread_dataEv+0x30>
  342cd7:	0f 18 3d a3 33 df ff                            	prefetchit0 -0x20cc5d(%rip)        # 136081 <_ZN5boost3log12v2s_mt_posix4core11open_recordERKNS1_13attribute_setE+0x21>
  342cde:	0f 18 3d 6b ce d4 ff                            	prefetchit0 -0x2b3195(%rip)        # 8fb50 <pthread_getspecific@plt>
  342ce5:	e9 46 ca d4 ff                                  	jmp    8f730 <pthread_rwlock_rdlock@plt>
  342cea:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  342cf0:	0f 18 3d e9 a0 ea ff                            	prefetchit0 -0x155f17(%rip)        # 1ecde0 <_ZNSt6chrono3_V212steady_clock3nowEv>
  342cf7:	e9 94 cc d4 ff                                  	jmp    8f990 <pthread_rwlock_unlock@plt>
  342cfc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342d00:	0f 18 3d bb dc e2 ff                            	prefetchit0 -0x1d2345(%rip)        # 1709c2 <_ZNK13jaegertracing6Tracer7ExtractERKN11opentracing2v213TextMapReaderE+0x72>
  342d07:	0f 18 3d 74 dc e2 ff                            	prefetchit0 -0x1d238c(%rip)        # 170982 <_ZNK13jaegertracing6Tracer7ExtractERKN11opentracing2v213TextMapReaderE+0x32>
  342d0e:	e9 8d cd d7 ff                                  	jmp    bfaa0 <_ZN13jaegertracing11SpanContextC2ERKNS_7TraceIDEmmhRKSt13unordered_mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESA_St4hashISA_ESt8equal_toISA_ESaISt4pairIKSA_SA_EEERSG_>
  342d13:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  342d1d:	0f 1f 00                                        	nopl   (%rax)
  342d20:	0f 18 3d 63 d0 f0 ff                            	prefetchit0 -0xf2f9d(%rip)        # 24fd8a <_ZNSo6sentryC1ERSo+0x5a>
  342d27:	0f 18 3d d8 e1 f0 ff                            	prefetchit0 -0xf1e28(%rip)        # 250f06 <_ZNSo9_M_insertImEERSoT_+0x136>
  342d2e:	0f 18 3d ab f5 ef ff                            	prefetchit0 -0x100a55(%rip)        # 2422e0 <_ZSt13__int_to_charIcmEiPT_T0_PKS0_St13_Ios_Fmtflagsb>
  342d35:	e9 e6 e7 d7 ff                                  	jmp    c1520 <_ZNK13jaegertracing11SpanContext5printISoEEvRT_>
  342d3a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  342d40:	0f 18 3d 99 46 ea ff                            	prefetchit0 -0x15b967(%rip)        # 1e73e0 <_ZNSt6locale13_S_initializeEv>
  342d47:	0f 18 3d d2 46 ea ff                            	prefetchit0 -0x15b92e(%rip)        # 1e7420 <_ZNSt6localeC1Ev>
  342d4e:	0f 18 3d f0 46 ea ff                            	prefetchit0 -0x15b910(%rip)        # 1e7445 <_ZNSt6localeC1Ev+0x25>
  342d55:	0f 18 3d 14 ca d4 ff                            	prefetchit0 -0x2b35ec(%rip)        # 8f770 <pthread_once@plt>
  342d5c:	e9 7f db f1 ff                                  	jmp    2608e0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm>
  342d61:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  342d6b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  342d70:	0f 18 3d 99 5c f1 ff                            	prefetchit0 -0xea367(%rip)        # 258a10 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode>
  342d77:	0f 18 3d 85 f9 ee ff                            	prefetchit0 -0x11067b(%rip)        # 232703 <_ZNSt8ios_baseC1Ev+0x13>
  342d7e:	0f 18 3d 6b f9 ee ff                            	prefetchit0 -0x110695(%rip)        # 2326f0 <_ZNSt8ios_baseC1Ev>
  342d85:	0f 18 3d d4 cb d7 ff                            	prefetchit0 -0x28342c(%rip)        # bf960 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE11decodeValueERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  342d8c:	0f 18 3d b1 5c f1 ff                            	prefetchit0 -0xea34f(%rip)        # 258a44 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode+0x34>
  342d93:	e9 c8 c8 d4 ff                                  	jmp    8f660 <memcpy@plt>
  342d98:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  342da0:	0f 18 3d 99 2b d8 ff                            	prefetchit0 -0x27d467(%rip)        # c5940 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E+0x10>
  342da7:	e9 f4 93 d7 ff                                  	jmp    bc1a0 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  342dac:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342db0:	0f 18 3d 4a d2 d7 ff                            	prefetchit0 -0x282db6(%rip)        # c0001 <_ZZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_ENKUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESI_E_clESI_SI_+0x11>
  342db7:	e9 24 db f1 ff                                  	jmp    2608e0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm>
  342dbc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342dc0:	0f 18 3d 19 cc d7 ff                            	prefetchit0 -0x2833e7(%rip)        # bf9e0 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE12normalizeKeyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  342dc7:	0f 18 3d 35 cc d7 ff                            	prefetchit0 -0x2833cb(%rip)        # bfa03 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE12normalizeKeyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE+0x23>
  342dce:	0f 18 3d 6e d2 d7 ff                            	prefetchit0 -0x282d92(%rip)        # c0043 <_ZZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_ENKUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESI_E_clESI_SI_+0x53>
  342dd5:	0f 18 3d 30 d3 d7 ff                            	prefetchit0 -0x282cd0(%rip)        # c010c <_ZZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_ENKUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESI_E_clESI_SI_+0x11c>
  342ddc:	0f 18 3d dd c9 d4 ff                            	prefetchit0 -0x2b3623(%rip)        # 8f7c0 <bcmp@plt>
  342de3:	e9 08 d2 d7 ff                                  	jmp    bfff0 <_ZZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_ENKUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESI_E_clESI_SI_>
  342de8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  342df0:	0f 18 3d 79 ac e2 ff                            	prefetchit0 -0x1d5387(%rip)        # 16da70 <_ZN13jaegertracing5utils10HexParsing11readSegmentB5cxx11ERSimc>
  342df7:	0f 18 3d e2 21 ef ff                            	prefetchit0 -0x10de1e(%rip)        # 234fe0 <_ZNSi3getERc>
  342dfe:	0f 18 3d bb b0 e2 ff                            	prefetchit0 -0x1d4f45(%rip)        # 16dec0 <_ZN13jaegertracing7TraceID10fromStreamERSi>
  342e05:	0f 18 3d f4 19 ef ff                            	prefetchit0 -0x10e60c(%rip)        # 234800 <_ZNSi6sentryC1ERSib>
  342e0c:	0f 18 3d ef 21 ef ff                            	prefetchit0 -0x10de11(%rip)        # 235002 <_ZNSi3getERc+0x22>
  342e13:	0f 18 3d e6 ac e2 ff                            	prefetchit0 -0x1d531a(%rip)        # 16db00 <_ZN13jaegertracing5utils10HexParsing11readSegmentB5cxx11ERSimc+0x90>
  342e1a:	0f 18 3d 61 ac e2 ff                            	prefetchit0 -0x1d539f(%rip)        # 16da82 <_ZN13jaegertracing5utils10HexParsing11readSegmentB5cxx11ERSimc+0x12>
  342e21:	e9 da a6 e2 ff                                  	jmp    16d500 <_ZN13jaegertracing11SpanContext10fromStreamERSi>
  342e26:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  342e30:	0f 18 3d 89 cc d4 ff                            	prefetchit0 -0x2b3377(%rip)        # 8fac0 <pthread_mutex_lock@plt>
  342e37:	e9 64 df d7 ff                                  	jmp    c0da0 <_ZN13jaegertracing11SpanContext4swapERS0_>
  342e3c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342e40:	0f 18 3d ba da d7 ff                            	prefetchit0 -0x282546(%rip)        # c0901 <_ZN13jaegertracingeqERKNS_11SpanContextES2_+0x91>
  342e47:	0f 18 3d e2 e0 d7 ff                            	prefetchit0 -0x281f1e(%rip)        # c0f30 <_ZNKSt8__detail9_EqualityINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS6_S6_ESaIS9_ENS_10_Select1stESt8equal_toIS6_ESt4hashIS6_ENS_18_Mod_range_hashingENS_20_Default_ranged_hashENS_20_Prime_rehash_policyENS_17_Hashtable_traitsILb1ELb0ELb1EEELb1EE8_M_equalERKSt10_HashtableIS6_S9_SA_SB_SD_SF_SG_SH_SI_SK_E>
  342e4e:	0f 18 3d 72 da d7 ff                            	prefetchit0 -0x28258e(%rip)        # c08c7 <_ZN13jaegertracingeqERKNS_11SpanContextES2_+0x57>
  342e55:	e9 46 93 d7 ff                                  	jmp    bc1a0 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  342e5a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  342e60:	0f 18 3d d9 d3 d7 ff                            	prefetchit0 -0x282c27(%rip)        # c0240 <_ZZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_ENKUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESI_E_clESI_SI_+0x250>
  342e67:	e9 04 da d7 ff                                  	jmp    c0870 <_ZN13jaegertracingeqERKNS_11SpanContextES2_>
  342e6c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342e70:	0f 18 3d 99 fb ee ff                            	prefetchit0 -0x110467(%rip)        # 232a10 <_ZNSt8ios_baseD1Ev>
  342e77:	e9 24 93 d7 ff                                  	jmp    bc1a0 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  342e7c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342e80:	0f 18 3d 89 fb ee ff                            	prefetchit0 -0x110477(%rip)        # 232a10 <_ZNSt8ios_baseD1Ev>
  342e87:	e9 94 d9 e9 ff                                  	jmp    1e0820 <_ZdlPvm>
  342e8c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342e90:	0f 18 3d c9 fa ee ff                            	prefetchit0 -0x110537(%rip)        # 232960 <_ZNSt8ios_base17_M_call_callbacksENS_5eventE>
  342e97:	0f 18 3d 24 fb ee ff                            	prefetchit0 -0x1104dc(%rip)        # 2329c2 <_ZNSt8ios_base20_M_dispose_callbacksEv+0x12>
  342e9e:	0f 18 3d ef fa ee ff                            	prefetchit0 -0x110511(%rip)        # 232994 <_ZNSt8ios_base17_M_call_callbacksENS_5eventE+0x34>
  342ea5:	0f 18 3d 97 fb ee ff                            	prefetchit0 -0x110469(%rip)        # 232a43 <_ZNSt8ios_baseD1Ev+0x33>
  342eac:	e9 2f 2a ea ff                                  	jmp    1e58e0 <_ZNSt6localeD1Ev>
  342eb1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  342ebb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  342ec0:	0f 18 3d b9 94 ea ff                            	prefetchit0 -0x156b47(%rip)        # 1ec380 <_ZSt18_Rb_tree_incrementPKSt18_Rb_tree_node_base>
  342ec7:	0f 18 3d f4 ce d7 ff                            	prefetchit0 -0x28310c(%rip)        # bfdc2 <_ZNSt17_Function_handlerIFN11opentracing2v28expectedIvSt10error_codeEENS1_11string_viewES5_EZNK13jaegertracing11propagation10PropagatorIRKNS1_13TextMapReaderERKNS1_13TextMapWriterEE7extractESC_EUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESO_E_E10_M_managerERSt9_Any_dataRKSR_St18_Manager_operation+0x12>
  342ece:	0f 18 3d ec 94 ea ff                            	prefetchit0 -0x156b14(%rip)        # 1ec3c1 <_ZSt18_Rb_tree_incrementPKSt18_Rb_tree_node_base+0x41>
  342ed5:	e9 46 d9 e9 ff                                  	jmp    1e0820 <_ZdlPvm>
  342eda:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  342ee0:	0f 18 3d 79 fa ee ff                            	prefetchit0 -0x110587(%rip)        # 232960 <_ZNSt8ios_base17_M_call_callbacksENS_5eventE>
  342ee7:	e9 94 c6 d4 ff                                  	jmp    8f580 <pthread_mutex_unlock@plt>
  342eec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  342ef0:	0f 18 3d 39 ce f0 ff                            	prefetchit0 -0xf31c7(%rip)        # 24fd30 <_ZNSo6sentryC1ERSo>
  342ef7:	0f 18 3d 03 fa ef ff                            	prefetchit0 -0x1005fd(%rip)        # 242901 <_ZNKSt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEE13_M_insert_intImEES3_S3_RSt8ios_basecT_+0x11>
  342efe:	0f 18 3d 5b f5 ef ff                            	prefetchit0 -0x100aa5(%rip)        # 242460 <_ZNKSt11__use_cacheISt16__numpunct_cacheIcEEclERKSt6locale>
  342f05:	0f 18 3d e4 f9 ef ff                            	prefetchit0 -0x10061c(%rip)        # 2428f0 <_ZNKSt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEE13_M_insert_intImEES3_S3_RSt8ios_basecT_>
  342f0c:	0f 18 3d cd fc ef ff                            	prefetchit0 -0x100333(%rip)        # 242be0 <_ZNKSt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEE6do_putES3_RSt8ios_basecm>
  342f13:	0f 18 3d b6 de f0 ff                            	prefetchit0 -0xf214a(%rip)        # 250dd0 <_ZNSo9_M_insertImEERSoT_>
  342f1a:	0f 18 3d e0 de f0 ff                            	prefetchit0 -0xf2120(%rip)        # 250e01 <_ZNSo9_M_insertImEERSoT_+0x31>
  342f21:	0f 18 3d 18 ce f0 ff                            	prefetchit0 -0xf31e8(%rip)        # 24fd40 <_ZNSo6sentryC1ERSo+0x10>
  342f28:	e9 c3 e6 d7 ff                                  	jmp    c15f0 <_ZNK13jaegertracing7TraceID5printISoEEvRT_>
  342f2d:	0f 1f 00                                        	nopl   (%rax)
  342f30:	0f 18 3d 79 20 d8 ff                            	prefetchit0 -0x27df87(%rip)        # c4fb0 <_ZNSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES5_St4lessIS5_ESaISt4pairIKS5_S5_EEEixEOS5_>
  342f37:	0f 18 3d 84 20 d8 ff                            	prefetchit0 -0x27df7c(%rip)        # c4fc2 <_ZNSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES5_St4lessIS5_ESaISt4pairIKS5_S5_EEEixEOS5_+0x12>
  342f3e:	e9 1d c7 d4 ff                                  	jmp    8f660 <memcpy@plt>
  342f43:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  342f4d:	0f 1f 00                                        	nopl   (%rax)
  342f50:	0f 18 3d f9 dd f1 ff                            	prefetchit0 -0xe2207(%rip)        # 260d50 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm>
  342f57:	0f 18 3d 25 de f1 ff                            	prefetchit0 -0xe21db(%rip)        # 260d83 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm+0x33>
  342f5e:	e9 0d 26 d8 ff                                  	jmp    c5570 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE24_M_get_insert_unique_posERS7_>
  342f63:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  342f6d:	0f 1f 00                                        	nopl   (%rax)
  342f70:	0f 18 3d 49 be e2 ff                            	prefetchit0 -0x1d41b7(%rip)        # 16edc0 <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE>
  342f77:	0f 18 3d 89 be e2 ff                            	prefetchit0 -0x1d4177(%rip)        # 16ee07 <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE+0x47>
  342f7e:	e9 9d 27 d8 ff                                  	jmp    c5720 <_ZNSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS2_11SpanContextEESaIS7_EE17_M_realloc_insertIJRKS3_RKS6_EEEvN9__gnu_cxx17__normal_iteratorIPS7_S9_EEDpOT_>
  342f83:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  342f8d:	0f 1f 00                                        	nopl   (%rax)
  342f90:	0f 18 3d b9 bb da ff                            	prefetchit0 -0x254447(%rip)        # eeb50 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv>
  342f97:	0f 18 3d 12 5a de ff                            	prefetchit0 -0x21a5ee(%rip)        # 1289b0 <_ZN6apache6thrift6server16TConnectedClient3runEv+0x180>
  342f9e:	0f 18 3d 3b 6e dd ff                            	prefetchit0 -0x2291c5(%rip)        # 119de0 <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj>
  342fa5:	0f 18 3d 14 5a de ff                            	prefetchit0 -0x21a5ec(%rip)        # 1289c0 <_ZN6apache6thrift6server16TConnectedClient3runEv+0x190>
  342fac:	0f 18 3d 4d 6e dd ff                            	prefetchit0 -0x2291b3(%rip)        # 119e00 <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj+0x20>
  342fb3:	0f 18 3d f6 6a dd ff                            	prefetchit0 -0x22950a(%rip)        # 119ab0 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE12readAll_virtEPhj>
  342fba:	0f 18 3d 9f 91 d8 ff                            	prefetchit0 -0x276e61(%rip)        # cc160 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE21readMessageBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERNS1_12TMessageTypeERi>
  342fc1:	0f 18 3d 78 6e dd ff                            	prefetchit0 -0x229188(%rip)        # 119e40 <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj+0x60>
  342fc8:	e9 53 d8 e9 ff                                  	jmp    1e0820 <_ZdlPvm>
  342fcd:	0f 1f 00                                        	nopl   (%rax)
  342fd0:	0f 18 3d fd 5a de ff                            	prefetchit0 -0x21a503(%rip)        # 128ad4 <_ZN6apache6thrift6server16TConnectedClient3runEv+0x2a4>
  342fd7:	0f 18 3d f2 97 d8 ff                            	prefetchit0 -0x27680e(%rip)        # cc7d0 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE17writeMessageBeginERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  342fde:	0f 18 3d 91 55 da ff                            	prefetchit0 -0x25aa6f(%rip)        # e8576 <_ZN13media_service29ComposeReviewServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x146>
  342fe5:	0f 18 3d 04 8d d8 ff                            	prefetchit0 -0x2772fc(%rip)        # cbcf0 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE22writeMessageBegin_virtERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi>
  342fec:	0f 18 3d 0d 98 d8 ff                            	prefetchit0 -0x2767f3(%rip)        # cc800 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE17writeMessageBeginERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEENS1_12TMessageTypeEi+0x30>
  342ff3:	e9 28 d8 e9 ff                                  	jmp    1e0820 <_ZdlPvm>
  342ff8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  343000:	0f 18 3d f9 2d d8 ff                            	prefetchit0 -0x27d207(%rip)        # c5e00 <_ZN5boost3log12v2s_mt_posix3aux27single_type_dispatcher_base12get_callbackEPNS1_15type_dispatcherENS_9typeindex14stl_type_indexE>
  343007:	0f 18 3d 82 08 e1 ff                            	prefetchit0 -0x1ef77e(%rip)        # 153890 <_ZN5boost3log12v2s_mt_posix7sources3aux14severity_levelINS1_7trivial14severity_levelEE4impl8dispatchERNS1_15type_dispatcherE>
  34300e:	0f 18 3d ec 68 d8 ff                            	prefetchit0 -0x279714(%rip)        # c9901 <_ZNK5boost3log12v2s_mt_posix15value_extractorINS1_7trivial14severity_levelENS1_16fallback_to_noneENS3_3tag8severityEEclERKNS1_14attribute_nameERKNS1_19attribute_value_setE+0x31>
  343015:	0f 18 3d e6 cd de ff                            	prefetchit0 -0x21321a(%rip)        # 12fe02 <_ZNK5boost3log12v2s_mt_posix19attribute_value_set4findENS1_14attribute_nameE+0x2f2>
  34301c:	0f 18 3d 9e 08 e1 ff                            	prefetchit0 -0x1ef762(%rip)        # 1538c1 <_ZN5boost3log12v2s_mt_posix7sources3aux14severity_levelINS1_7trivial14severity_levelEE4impl8dispatchERNS1_15type_dispatcherE+0x31>
  343023:	e9 a8 68 d8 ff                                  	jmp    c98d0 <_ZNK5boost3log12v2s_mt_posix15value_extractorINS1_7trivial14severity_levelENS1_16fallback_to_noneENS3_3tag8severityEEclERKNS1_14attribute_nameERKNS1_19attribute_value_setE>
  343028:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  343030:	0f 18 3d f9 ab d8 ff                            	prefetchit0 -0x275407(%rip)        # cdc30 <_ZZNSt9once_flag18_Prepare_executionC1IZSt9call_onceIMSt6threadFvvEJPS3_EEvRS_OT_DpOT0_EUlvE_EERS8_ENUlvE_8__invokeEv>
  343037:	0f 18 3d b2 c1 f0 ff                            	prefetchit0 -0xf3e4e(%rip)        # 24f1f0 <__once_proxy>
  34303e:	0f 18 3d 9b c6 d4 ff                            	prefetchit0 -0x2b3965(%rip)        # 8f6e0 <pthread_join@plt>
  343045:	e9 26 c7 d4 ff                                  	jmp    8f770 <pthread_once@plt>
  34304a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  343050:	0f 18 3d 1b bc d5 ff                            	prefetchit0 -0x2a43e5(%rip)        # 9ec72 <_ZN13media_service20ComposeReviewHandler17_ComposeAndUploadElRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES7_St4lessIS7_ESaISt4pairIKS7_S7_EEE+0x1cc2>
  343057:	0f 18 3d e2 6b d8 ff                            	prefetchit0 -0x27941e(%rip)        # c9c40 <_ZNSt13__future_base21_Async_state_commonV217_M_complete_asyncEv>
  34305e:	0f 18 3d 4b d8 da ff                            	prefetchit0 -0x2527b5(%rip)        # f08b0 <_ZN13media_service6ReviewD1Ev>
  343065:	0f 18 3d 04 c7 d4 ff                            	prefetchit0 -0x2b38fc(%rip)        # 8f770 <pthread_once@plt>
  34306c:	0f 18 3d 17 bc d5 ff                            	prefetchit0 -0x2a43e9(%rip)        # 9ec8a <_ZN13media_service20ComposeReviewHandler17_ComposeAndUploadElRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES7_St4lessIS7_ESaISt4pairIKS7_S7_EEE+0x1cda>
  343073:	e9 08 da ee ff                                  	jmp    230a80 <_ZNSt13__future_base12_Result_baseD1Ev>
  343078:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  343080:	0f 18 3d 69 c1 f0 ff                            	prefetchit0 -0xf3e97(%rip)        # 24f1f0 <__once_proxy>
  343087:	0f 18 3d f3 6f d8 ff                            	prefetchit0 -0x27900d(%rip)        # ca081 <_ZNSt13__future_base13_State_baseV29_M_do_setEPSt8functionIFSt10unique_ptrINS_12_Result_baseENS3_8_DeleterEEvEEPb+0x11>
  34308e:	e9 dd c6 d4 ff                                  	jmp    8f770 <pthread_once@plt>
  343093:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  34309d:	0f 1f 00                                        	nopl   (%rax)
  3430a0:	0f 18 3d cd 0d f2 ff                            	prefetchit0 -0xdf233(%rip)        # 263e74 <execute_native_thread_routine+0x14>
  3430a7:	e9 14 ca d4 ff                                  	jmp    8fac0 <pthread_mutex_lock@plt>
  3430ac:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3430b0:	0f 18 3d 99 71 d6 ff                            	prefetchit0 -0x298e67(%rip)        # aa250 <_ZNSt17_Function_handlerIFSt10unique_ptrINSt13__future_base12_Result_baseENS2_8_DeleterEEvENS1_12_Task_setterIS0_INS1_7_ResultIvEES3_ENSt6thread8_InvokerISt5tupleIJZN13media_service20ComposeReviewHandler17_ComposeAndUploadElRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESL_St4lessISL_ESaISt4pairIKSL_SL_EEEE3$_0EEEEvEEE10_M_managerERSt9_Any_dataRKS10_St18_Manager_operation>
  3430b7:	e9 c4 c4 d4 ff                                  	jmp    8f580 <pthread_mutex_unlock@plt>
  3430bc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3430c0:	0f 18 3d 3b 91 d8 ff                            	prefetchit0 -0x276ec5(%rip)        # cc202 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE19readFieldBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERNS1_5TTypeERs+0x52>
  3430c7:	0f 18 3d 78 21 da ff                            	prefetchit0 -0x25de88(%rip)        # e5246 <_ZN13media_service38ComposeReviewService_UploadUserId_args4readEPN6apache6thrift8protocol9TProtocolE+0x3b6>
  3430ce:	e9 9d eb f1 ff                                  	jmp    261c70 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm>
  3430d3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3430dd:	0f 1f 00                                        	nopl   (%rax)
  3430e0:	0f 18 3d 9f 53 da ff                            	prefetchit0 -0x25ac61(%rip)        # e8486 <_ZN13media_service29ComposeReviewServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x56>
  3430e7:	0f 18 3d ae ba da ff                            	prefetchit0 -0x254552(%rip)        # eeb9c <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x4c>
  3430ee:	0f 18 3d 3b 53 da ff                            	prefetchit0 -0x25acc5(%rip)        # e8430 <_ZN13media_service29ComposeReviewServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv>
  3430f5:	0f 18 3d 44 01 f2 ff                            	prefetchit0 -0xdfebc(%rip)        # 263240 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc+0x10>
  3430fc:	0f 18 3d 2d 01 f2 ff                            	prefetchit0 -0xdfed3(%rip)        # 263230 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc>
  343103:	0f 18 3d f9 91 db ff                            	prefetchit0 -0x246e07(%rip)        # fc303 <_ZN13media_service26ReviewStorageServiceClient16recv_StoreReviewEv+0x53>
  34310a:	0f 18 3d b1 eb f1 ff                            	prefetchit0 -0xe144f(%rip)        # 261cc2 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm+0x52>
  343111:	0f 18 3d 6c ec f1 ff                            	prefetchit0 -0xe1394(%rip)        # 261d84 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm+0x114>
  343118:	e9 83 9b d8 ff                                  	jmp    ccca0 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE14readStringBodyINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEEjRT_i>
  34311d:	0f 1f 00                                        	nopl   (%rax)
  343120:	0f 18 3d 69 c2 da ff                            	prefetchit0 -0x253d97(%rip)        # ef390 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE22_M_emplace_hint_uniqueIJRKSt21piecewise_construct_tSt5tupleIJRS7_EESJ_IJEEEEESt17_Rb_tree_iteratorIS8_ESt23_Rb_tree_const_iteratorIS8_EDpOT_>
  343127:	0f 18 3d 82 c8 d4 ff                            	prefetchit0 -0x2b377e(%rip)        # 8f9b0 <malloc@plt>
  34312e:	0f 18 3d 7b f2 e9 ff                            	prefetchit0 -0x160d85(%rip)        # 1e23b0 <_Znwm>
  343135:	0f 18 3d 47 dc f1 ff                            	prefetchit0 -0xe23b9(%rip)        # 260d83 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm+0x33>
  34313c:	0f 18 3d cd c1 d4 ff                            	prefetchit0 -0x2b3e33(%rip)        # 8f310 <strlen@plt>
  343143:	0f 18 3d f6 9b d8 ff                            	prefetchit0 -0x27640a(%rip)        # ccd40 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE14readStringBodyINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEEEjRT_i+0xa0>
  34314a:	0f 18 3d ff db f1 ff                            	prefetchit0 -0xe2401(%rip)        # 260d50 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm>
  343151:	0f 18 3d 69 99 d8 ff                            	prefetchit0 -0x276697(%rip)        # ccac1 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE16readMessageBeginERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERNS1_12TMessageTypeERi+0xd1>
  343158:	e9 13 eb f1 ff                                  	jmp    261c70 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm>
  34315d:	0f 1f 00                                        	nopl   (%rax)
  343160:	41 53                                           	push   %r11
  343162:	4c 8b 1d 6f 83 ff ff                            	mov    -0x7c91(%rip),%r11        # 33b4d8 <malloc@GLIBC_2.2.5>
  343169:	41 0f 18 93 f0 bf ff ff                         	prefetcht1 -0x4010(%r11)
  343171:	41 5b                                           	pop    %r11
  343173:	e9 48 c9 d4 ff                                  	jmp    8fac0 <pthread_mutex_lock@plt>
  343178:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  343180:	0f 18 3d 29 f2 e9 ff                            	prefetchit0 -0x160dd7(%rip)        # 1e23b0 <_Znwm>
  343187:	e9 04 c2 da ff                                  	jmp    ef390 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE22_M_emplace_hint_uniqueIJRKSt21piecewise_construct_tSt5tupleIJRS7_EESJ_IJEEEEESt17_Rb_tree_iteratorIS8_ESt23_Rb_tree_const_iteratorIS8_EDpOT_>
  34318c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343190:	0f 18 3d 39 9c d8 ff                            	prefetchit0 -0x2763c7(%rip)        # ccdd0 <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE12readMapBeginERNS1_5TTypeES8_Rj>
  343197:	e9 94 27 d8 ff                                  	jmp    c5930 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  34319c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3431a0:	0f 18 3d 59 72 da ff                            	prefetchit0 -0x258da7(%rip)        # ea400 <_ZN13media_service29ComposeReviewServiceProcessor22process_UploadUniqueIdEiPN6apache6thrift8protocol9TProtocolES5_Pv>
  3431a7:	0f 18 3d 16 1d da ff                            	prefetchit0 -0x25e2ea(%rip)        # e4ec4 <_ZN13media_service38ComposeReviewService_UploadUserId_args4readEPN6apache6thrift8protocol9TProtocolE+0x34>
  3431ae:	0f 18 3d ab 58 da ff                            	prefetchit0 -0x25a755(%rip)        # e8a60 <_ZN13media_service29ComposeReviewServiceProcessor18process_UploadTextEiPN6apache6thrift8protocol9TProtocolES5_Pv>
  3431b5:	0f 18 3d 34 61 da ff                            	prefetchit0 -0x259ecc(%rip)        # e92f0 <_ZN13media_service29ComposeReviewServiceProcessor20process_UploadRatingEiPN6apache6thrift8protocol9TProtocolES5_Pv>
  3431bc:	0f 18 3d 9d 7a da ff                            	prefetchit0 -0x258563(%rip)        # eac60 <_ZN13media_service29ComposeReviewServiceProcessor20process_UploadUserIdEiPN6apache6thrift8protocol9TProtocolES5_Pv>
  3431c3:	0f 18 3d bb 53 da ff                            	prefetchit0 -0x25ac45(%rip)        # e8585 <_ZN13media_service29ComposeReviewServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x155>
  3431ca:	0f 18 3d 8f 69 da ff                            	prefetchit0 -0x259671(%rip)        # e9b60 <_ZN13media_service29ComposeReviewServiceProcessor21process_UploadMovieIdEiPN6apache6thrift8protocol9TProtocolES5_Pv>
  3431d1:	0f 18 3d 29 61 da ff                            	prefetchit0 -0x259ed7(%rip)        # e9301 <_ZN13media_service29ComposeReviewServiceProcessor20process_UploadRatingEiPN6apache6thrift8protocol9TProtocolES5_Pv+0x11>
  3431d8:	e9 53 c1 d4 ff                                  	jmp    8f330 <memcmp@plt>
  3431dd:	0f 1f 00                                        	nopl   (%rax)
  3431e0:	0f 18 3d 99 8f d8 ff                            	prefetchit0 -0x277067(%rip)        # cc180 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE20readStructBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  3431e7:	0f 18 3d e2 f0 d9 ff                            	prefetchit0 -0x260f1e(%rip)        # e22d0 <_ZN13media_service38ComposeReviewService_UploadRating_args4readEPN6apache6thrift8protocol9TProtocolE>
  3431ee:	0f 18 3d 8b ff d9 ff                            	prefetchit0 -0x260075(%rip)        # e3180 <_ZN13media_service39ComposeReviewService_UploadMovieId_args4readEPN6apache6thrift8protocol9TProtocolE>
  3431f5:	0f 18 3d 04 0e da ff                            	prefetchit0 -0x25f1fc(%rip)        # e4000 <_ZN13media_service40ComposeReviewService_UploadUniqueId_args4readEPN6apache6thrift8protocol9TProtocolE>
  3431fc:	0f 18 3d 81 e2 d9 ff                            	prefetchit0 -0x261d7f(%rip)        # e1484 <_ZN13media_service36ComposeReviewService_UploadText_args4readEPN6apache6thrift8protocol9TProtocolE+0x34>
  343203:	0f 18 3d fa f0 d9 ff                            	prefetchit0 -0x260f06(%rip)        # e2304 <_ZN13media_service38ComposeReviewService_UploadRating_args4readEPN6apache6thrift8protocol9TProtocolE+0x34>
  34320a:	0f 18 3d 7f 1c da ff                            	prefetchit0 -0x25e381(%rip)        # e4e90 <_ZN13media_service38ComposeReviewService_UploadUserId_args4readEPN6apache6thrift8protocol9TProtocolE>
  343211:	0f 18 3d 38 e2 d9 ff                            	prefetchit0 -0x261dc8(%rip)        # e1450 <_ZN13media_service36ComposeReviewService_UploadText_args4readEPN6apache6thrift8protocol9TProtocolE>
  343218:	e9 13 c1 d4 ff                                  	jmp    8f330 <memcmp@plt>
  34321d:	0f 1f 00                                        	nopl   (%rax)
  343220:	0f 18 3d 59 93 d8 ff                            	prefetchit0 -0x276ca7(%rip)        # cc580 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE12readI64_virtERl>
  343227:	e9 24 e2 d9 ff                                  	jmp    e1450 <_ZN13media_service36ComposeReviewService_UploadText_args4readEPN6apache6thrift8protocol9TProtocolE>
  34322c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343230:	0f 18 3d b9 dc e9 ff                            	prefetchit0 -0x162347(%rip)        # 1e0ef0 <_ZNSt9exceptionD1Ev>
  343237:	e9 c4 24 db ff                                  	jmp    f5700 <_ZN13media_service16ServiceExceptionD1Ev>
  34323c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343240:	0f 18 3d 80 b9 da ff                            	prefetchit0 -0x254680(%rip)        # eebc7 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x77>
  343247:	0f 18 3d 02 b9 da ff                            	prefetchit0 -0x2546fe(%rip)        # eeb50 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv>
  34324e:	0f 18 3d 8b 6b dd ff                            	prefetchit0 -0x229475(%rip)        # 119de0 <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj>
  343255:	0f 18 3d 64 57 de ff                            	prefetchit0 -0x21a89c(%rip)        # 1289c0 <_ZN6apache6thrift6server16TConnectedClient3runEv+0x190>
  34325c:	0f 18 3d bd 59 dd ff                            	prefetchit0 -0x22a643(%rip)        # 118c20 <_ZN6apache6thrift9transport16TFramedTransport8readSlowEPhj>
  343263:	0f 18 3d 96 6b dd ff                            	prefetchit0 -0x22946a(%rip)        # 119e00 <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj+0x20>
  34326a:	0f 18 3d 63 58 de ff                            	prefetchit0 -0x21a79d(%rip)        # 128ad4 <_ZN6apache6thrift6server16TConnectedClient3runEv+0x2a4>
  343271:	e9 aa d5 e9 ff                                  	jmp    1e0820 <_ZdlPvm>
  343276:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  343280:	0f 18 3d f9 92 d8 ff                            	prefetchit0 -0x276d07(%rip)        # cc580 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE12readI64_virtERl>
  343287:	e9 44 f0 d9 ff                                  	jmp    e22d0 <_ZN13media_service38ComposeReviewService_UploadRating_args4readEPN6apache6thrift8protocol9TProtocolE>
  34328c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343290:	0f 18 3d ae 56 da ff                            	prefetchit0 -0x25a952(%rip)        # e8945 <_ZN13media_service29ComposeReviewServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x515>
  343297:	0f 18 3d d8 52 da ff                            	prefetchit0 -0x25ad28(%rip)        # e8576 <_ZN13media_service29ComposeReviewServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x146>
  34329e:	e9 8d 26 d8 ff                                  	jmp    c5930 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  3432a3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3432ad:	0f 1f 00                                        	nopl   (%rax)
  3432b0:	0f 18 3d c9 92 d8 ff                            	prefetchit0 -0x276d37(%rip)        # cc580 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE12readI64_virtERl>
  3432b7:	e9 c4 fe d9 ff                                  	jmp    e3180 <_ZN13media_service39ComposeReviewService_UploadMovieId_args4readEPN6apache6thrift8protocol9TProtocolE>
  3432bc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3432c0:	0f 18 3d 7e 56 da ff                            	prefetchit0 -0x25a982(%rip)        # e8945 <_ZN13media_service29ComposeReviewServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x515>
  3432c7:	0f 18 3d f9 b8 da ff                            	prefetchit0 -0x254707(%rip)        # eebc7 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x77>
  3432ce:	e9 5d 26 d8 ff                                  	jmp    c5930 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  3432d3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3432dd:	0f 1f 00                                        	nopl   (%rax)
  3432e0:	0f 18 3d 99 92 d8 ff                            	prefetchit0 -0x276d67(%rip)        # cc580 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE12readI64_virtERl>
  3432e7:	0f 18 3d d2 8e d8 ff                            	prefetchit0 -0x27712e(%rip)        # cc1c0 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE19readFieldBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERNS1_5TTypeERs+0x10>
  3432ee:	e9 0d 0d da ff                                  	jmp    e4000 <_ZN13media_service40ComposeReviewService_UploadUniqueId_args4readEPN6apache6thrift8protocol9TProtocolE>
  3432f3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3432fd:	0f 1f 00                                        	nopl   (%rax)
  343300:	0f 18 3d c0 b8 da ff                            	prefetchit0 -0x254740(%rip)        # eebc7 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x77>
  343307:	e9 24 26 d8 ff                                  	jmp    c5930 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  34330c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343310:	0f 18 3d 69 92 d8 ff                            	prefetchit0 -0x276d97(%rip)        # cc580 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE12readI64_virtERl>
  343317:	e9 74 1b da ff                                  	jmp    e4e90 <_ZN13media_service38ComposeReviewService_UploadUserId_args4readEPN6apache6thrift8protocol9TProtocolE>
  34331c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343320:	0f 18 3d 1e 56 da ff                            	prefetchit0 -0x25a9e2(%rip)        # e8945 <_ZN13media_service29ComposeReviewServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x515>
  343327:	0f 18 3d 99 b8 da ff                            	prefetchit0 -0x254767(%rip)        # eebc7 <_ZN6apache6thrift18TDispatchProcessor7processESt10shared_ptrINS0_8protocol9TProtocolEES5_Pv+0x77>
  34332e:	0f 18 3d 41 52 da ff                            	prefetchit0 -0x25adbf(%rip)        # e8576 <_ZN13media_service29ComposeReviewServiceProcessor12dispatchCallEPN6apache6thrift8protocol9TProtocolES5_RKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEiPv+0x146>
  343335:	e9 f6 25 d8 ff                                  	jmp    c5930 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E>
  34333a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  343340:	0f 18 3d 49 1f d8 ff                            	prefetchit0 -0x27e0b7(%rip)        # c5290 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_>
  343347:	0f 18 3d 73 c0 da ff                            	prefetchit0 -0x253f8d(%rip)        # ef3c1 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE22_M_emplace_hint_uniqueIJRKSt21piecewise_construct_tSt5tupleIJRS7_EESJ_IJEEEEESt17_Rb_tree_iteratorIS8_ESt23_Rb_tree_const_iteratorIS8_EDpOT_+0x31>
  34334e:	e9 5d f0 e9 ff                                  	jmp    1e23b0 <_Znwm>
  343353:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  34335d:	0f 1f 00                                        	nopl   (%rax)
  343360:	0f 18 3d e9 91 ea ff                            	prefetchit0 -0x156e17(%rip)        # 1ec550 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_>
  343367:	0f 18 3d 15 92 ea ff                            	prefetchit0 -0x156deb(%rip)        # 1ec583 <_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_+0x33>
  34336e:	0f 18 3d 1b 1f d8 ff                            	prefetchit0 -0x27e0e5(%rip)        # c5290 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_>
  343375:	0f 18 3d 76 21 d8 ff                            	prefetchit0 -0x27de8a(%rip)        # c54f2 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE29_M_get_insert_hint_unique_posESt23_Rb_tree_const_iteratorIS8_ERS7_+0x262>
  34337c:	0f 18 3d ed 21 d8 ff                            	prefetchit0 -0x27de13(%rip)        # c5570 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE24_M_get_insert_unique_posERS7_>
  343383:	0f 18 3d db c0 da ff                            	prefetchit0 -0x253f25(%rip)        # ef465 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE22_M_emplace_hint_uniqueIJRKSt21piecewise_construct_tSt5tupleIJRS7_EESJ_IJEEEEESt17_Rb_tree_iteratorIS8_ESt23_Rb_tree_const_iteratorIS8_EDpOT_+0xd5>
  34338a:	e9 71 c1 da ff                                  	jmp    ef500 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE17_M_construct_nodeIJRKSt21piecewise_construct_tSt5tupleIJRS7_EESJ_IJEEEEEvPSt13_Rb_tree_nodeIS8_EDpOT_>
  34338f:	90                                              	nop
  343390:	0f 18 3d 69 5c dd ff                            	prefetchit0 -0x22a397(%rip)        # 119000 <_ZN6apache6thrift9transport16TFramedTransport5flushEv+0x10>
  343397:	0f 18 3d 72 31 dd ff                            	prefetchit0 -0x22ce8e(%rip)        # 116510 <_ZN6apache6thrift9transport17TVirtualTransportINS1_7TSocketENS1_18TTransportDefaultsEE10write_virtEPKhj>
  34339e:	e9 dd 8f ea ff                                  	jmp    1ec380 <_ZSt18_Rb_tree_incrementPKSt18_Rb_tree_node_base>
  3433a3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3433ad:	0f 1f 00                                        	nopl   (%rax)
  3433b0:	0f 18 3d 09 8c d8 ff                            	prefetchit0 -0x2773f7(%rip)        # cbfc0 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE13writeI64_virtEl>
  3433b7:	e9 94 71 db ff                                  	jmp    fa550 <_ZNK13media_service38ReviewStorageService_StoreReview_pargs5writeEPN6apache6thrift8protocol9TProtocolE>
  3433bc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3433c0:	0f 18 3d fb 76 db ff                            	prefetchit0 -0x248905(%rip)        # faac2 <_ZN13media_service40ReviewStorageService_StoreReview_presult4readEPN6apache6thrift8protocol9TProtocolE+0x52>
  3433c7:	0f 18 3d a2 76 db ff                            	prefetchit0 -0x24895e(%rip)        # faa70 <_ZN13media_service40ReviewStorageService_StoreReview_presult4readEPN6apache6thrift8protocol9TProtocolE>
  3433ce:	0f 18 3d 2e 91 db ff                            	prefetchit0 -0x246ed2(%rip)        # fc503 <_ZN13media_service26ReviewStorageServiceClient16recv_StoreReviewEv+0x253>
  3433d5:	0f 18 3d d0 90 db ff                            	prefetchit0 -0x246f30(%rip)        # fc4ac <_ZN13media_service26ReviewStorageServiceClient16recv_StoreReviewEv+0x1fc>
  3433dc:	41 53                                           	push   %r11
  3433de:	4c 8b 1d b3 7d ff ff                            	mov    -0x824d(%rip),%r11        # 33b198 <memcmp@GLIBC_2.2.5>
  3433e5:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3433ed:	41 5b                                           	pop    %r11
  3433ef:	e9 3c fe f1 ff                                  	jmp    263230 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc>
  3433f4:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3433fe:	66 90                                           	xchg   %ax,%ax
  343400:	0f 18 3d 59 78 d8 ff                            	prefetchit0 -0x2787a7(%rip)        # cac60 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_26ReviewStorageServiceClientEEEE4PushEPS3_>
  343407:	0f 18 3d b2 c6 d4 ff                            	prefetchit0 -0x2b394e(%rip)        # 8fac0 <pthread_mutex_lock@plt>
  34340e:	0f 18 3d 25 6b d6 ff                            	prefetchit0 -0x2994db(%rip)        # a9f3a <_ZNSt17_Function_handlerIFSt10unique_ptrINSt13__future_base12_Result_baseENS2_8_DeleterEEvENS1_12_Task_setterIS0_INS1_7_ResultIvEES3_ENSt6thread8_InvokerISt5tupleIJZN13media_service20ComposeReviewHandler17_ComposeAndUploadElRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESL_St4lessISL_ESaISt4pairIKSL_SL_EEEE3$_0EEEEvEEE9_M_invokeERKSt9_Any_data+0x4a>
  343415:	e9 e6 22 db ff                                  	jmp    f5700 <_ZN13media_service16ServiceExceptionD1Ev>
  34341a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  343420:	0f 18 3d e9 30 dd ff                            	prefetchit0 -0x22cf17(%rip)        # 116510 <_ZN6apache6thrift9transport17TVirtualTransportINS1_7TSocketENS1_18TTransportDefaultsEE10write_virtEPKhj>
  343427:	0f 18 3d c2 5b dd ff                            	prefetchit0 -0x22a43e(%rip)        # 118ff0 <_ZN6apache6thrift9transport16TFramedTransport5flushEv>
  34342e:	e9 4d 8f ea ff                                  	jmp    1ec380 <_ZSt18_Rb_tree_incrementPKSt18_Rb_tree_node_base>
  343433:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  34343d:	0f 1f 00                                        	nopl   (%rax)
  343440:	0f 18 3d b9 e9 db ff                            	prefetchit0 -0x241647(%rip)        # 101e00 <_ZNK13media_service40UserReviewService_UploadUserReview_pargs5writeEPN6apache6thrift8protocol9TProtocolE>
  343447:	e9 d4 d3 e9 ff                                  	jmp    1e0820 <_ZdlPvm>
  34344c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343450:	0f 18 3d ac ef db ff                            	prefetchit0 -0x241054(%rip)        # 102403 <_ZN13media_service42UserReviewService_UploadUserReview_presult4readEPN6apache6thrift8protocol9TProtocolE+0x33>
  343457:	0f 18 3d 72 ef db ff                            	prefetchit0 -0x24108e(%rip)        # 1023d0 <_ZN13media_service42UserReviewService_UploadUserReview_presult4readEPN6apache6thrift8protocol9TProtocolE>
  34345e:	e9 cd fd f1 ff                                  	jmp    263230 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc>
  343463:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  34346d:	0f 1f 00                                        	nopl   (%rax)
  343470:	0f 18 3d 49 b3 d8 ff                            	prefetchit0 -0x274cb7(%rip)        # ce7c0 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_23UserReviewServiceClientEEEE4PushEPS3_>
  343477:	0f 18 3d f8 70 d6 ff                            	prefetchit0 -0x298f08(%rip)        # aa576 <_ZNSt17_Function_handlerIFSt10unique_ptrINSt13__future_base12_Result_baseENS2_8_DeleterEEvENS1_12_Task_setterIS0_INS1_7_ResultIvEES3_ENSt6thread8_InvokerISt5tupleIJZN13media_service20ComposeReviewHandler17_ComposeAndUploadElRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESL_St4lessISL_ESaISt4pairIKSL_SL_EEEE3$_1EEEEvEEE9_M_invokeERKSt9_Any_data+0x56>
  34347e:	0f 18 3d 6b da e9 ff                            	prefetchit0 -0x162595(%rip)        # 1e0ef0 <_ZNSt9exceptionD1Ev>
  343485:	e9 76 22 db ff                                  	jmp    f5700 <_ZN13media_service16ServiceExceptionD1Ev>
  34348a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  343490:	0f 18 3d 99 61 dc ff                            	prefetchit0 -0x239e67(%rip)        # 109630 <_ZNK13media_service42MovieReviewService_UploadMovieReview_pargs5writeEPN6apache6thrift8protocol9TProtocolE>
  343497:	0f 18 3d 22 8b d8 ff                            	prefetchit0 -0x2774de(%rip)        # cbfc0 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE13writeI64_virtEl>
  34349e:	e9 7d d3 e9 ff                                  	jmp    1e0820 <_ZdlPvm>
  3434a3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3434ad:	0f 1f 00                                        	nopl   (%rax)
  3434b0:	0f 18 3d 39 67 dc ff                            	prefetchit0 -0x2398c7(%rip)        # 109bf0 <_ZN13media_service44MovieReviewService_UploadMovieReview_presult4readEPN6apache6thrift8protocol9TProtocolE>
  3434b7:	e9 74 fd f1 ff                                  	jmp    263230 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc>
  3434bc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3434c0:	0f 18 3d 39 22 db ff                            	prefetchit0 -0x24ddc7(%rip)        # f5700 <_ZN13media_service16ServiceExceptionD1Ev>
  3434c7:	e9 24 67 dc ff                                  	jmp    109bf0 <_ZN13media_service44MovieReviewService_UploadMovieReview_presult4readEPN6apache6thrift8protocol9TProtocolE>
  3434cc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3434d0:	0f 18 3d df 76 d6 ff                            	prefetchit0 -0x298921(%rip)        # aabb6 <_ZNSt17_Function_handlerIFSt10unique_ptrINSt13__future_base12_Result_baseENS2_8_DeleterEEvENS1_12_Task_setterIS0_INS1_7_ResultIvEES3_ENSt6thread8_InvokerISt5tupleIJZN13media_service20ComposeReviewHandler17_ComposeAndUploadElRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESL_St4lessISL_ESaISt4pairIKSL_SL_EEEE3$_2EEEEvEEE9_M_invokeERKSt9_Any_data+0x56>
  3434d7:	0f 18 3d 62 d0 d8 ff                            	prefetchit0 -0x272f9e(%rip)        # d0540 <_ZN13media_service10ClientPoolINS_12ThriftClientINS_24MovieReviewServiceClientEEEE4PushEPS3_>
  3434de:	0f 18 3d db c5 d4 ff                            	prefetchit0 -0x2b3a25(%rip)        # 8fac0 <pthread_mutex_lock@plt>
  3434e5:	e9 16 22 db ff                                  	jmp    f5700 <_ZN13media_service16ServiceExceptionD1Ev>
  3434ea:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  3434f0:	0f 18 3d f9 2f dd ff                            	prefetchit0 -0x22d007(%rip)        # 1164f0 <_ZN6apache6thrift9transport17TVirtualTransportINS1_7TSocketENS1_18TTransportDefaultsEE12readAll_virtEPhj>
  3434f7:	0f 18 3d 82 57 dd ff                            	prefetchit0 -0x22a87e(%rip)        # 118c80 <_ZN6apache6thrift9transport16TFramedTransport8readSlowEPhj+0x60>
  3434fe:	0f 18 3d 62 57 dd ff                            	prefetchit0 -0x22a89e(%rip)        # 118c67 <_ZN6apache6thrift9transport16TFramedTransport8readSlowEPhj+0x47>
  343505:	0f 18 3d 54 c1 d4 ff                            	prefetchit0 -0x2b3eac(%rip)        # 8f660 <memcpy@plt>
  34350c:	0f 18 3d fd 19 dd ff                            	prefetchit0 -0x22e603(%rip)        # 114f10 <_ZN6apache6thrift9transport7TSocket4readEPhj>
  343513:	0f 18 3d c1 57 dd ff                            	prefetchit0 -0x22a83f(%rip)        # 118cdb <_ZN6apache6thrift9transport16TFramedTransport9readFrameEv+0x3b>
  34351a:	0f 18 3d e0 57 dd ff                            	prefetchit0 -0x22a820(%rip)        # 118d01 <_ZN6apache6thrift9transport16TFramedTransport9readFrameEv+0x61>
  343521:	0f 18 3d 18 1a dd ff                            	prefetchit0 -0x22e5e8(%rip)        # 114f40 <_ZN6apache6thrift9transport7TSocket4readEPhj+0x30>
  343528:	e9 63 bd d4 ff                                  	jmp    8f290 <recv@plt>
  34352d:	0f 1f 00                                        	nopl   (%rax)
  343530:	0f 18 3d a9 2f dd ff                            	prefetchit0 -0x22d057(%rip)        # 1164e0 <_ZN6apache6thrift9transport17TVirtualTransportINS1_7TSocketENS1_18TTransportDefaultsEE9read_virtEPhj>
  343537:	0f 18 3d e2 56 dd ff                            	prefetchit0 -0x22a91e(%rip)        # 118c20 <_ZN6apache6thrift9transport16TFramedTransport8readSlowEPhj>
  34353e:	0f 18 3d bb 21 db ff                            	prefetchit0 -0x24de45(%rip)        # f5700 <_ZN13media_service16ServiceExceptionD1Ev>
  343545:	0f 18 3d 94 68 dd ff                            	prefetchit0 -0x22976c(%rip)        # 119de0 <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj>
  34354c:	0f 18 3d ad 68 dd ff                            	prefetchit0 -0x229753(%rip)        # 119e00 <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj+0x20>
  343553:	0f 18 3d 96 d9 e9 ff                            	prefetchit0 -0x16266a(%rip)        # 1e0ef0 <_ZNSt9exceptionD1Ev>
  34355a:	0f 18 3d 4f 8d db ff                            	prefetchit0 -0x2472b1(%rip)        # fc2b0 <_ZN13media_service26ReviewStorageServiceClient16recv_StoreReviewEv>
  343561:	e9 3a be d4 ff                                  	jmp    8f3a0 <send@plt>
  343566:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  343570:	0f 18 3d f9 e6 f1 ff                            	prefetchit0 -0xe1907(%rip)        # 261c70 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm>
  343577:	0f 18 3d 32 65 dd ff                            	prefetchit0 -0x229ace(%rip)        # 119ab0 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE12readAll_virtEPhj>
  34357e:	0f 18 3d c1 68 dd ff                            	prefetchit0 -0x22973f(%rip)        # 119e46 <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj+0x66>
  343585:	0f 18 3d f4 e6 f1 ff                            	prefetchit0 -0xe190c(%rip)        # 261c80 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm+0x10>
  34358c:	0f 18 3d 97 68 dd ff                            	prefetchit0 -0x229769(%rip)        # 119e2a <_ZN6apache6thrift9transport7readAllINS1_11TBufferBaseEEEjRT_Phj+0x4a>
  343593:	0f 18 3d a6 65 dd ff                            	prefetchit0 -0x229a5a(%rip)        # 119b40 <_ZN6apache6thrift9transport17TVirtualTransportINS1_16TFramedTransportENS1_11TBufferBaseEE11borrow_virtEPhPj>
  34359a:	0f 18 3d 1f e8 f1 ff                            	prefetchit0 -0xe17e1(%rip)        # 261dc0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE10_M_replaceEmmPKcm+0x150>
  3435a1:	0f 18 3d 74 94 d8 ff                            	prefetchit0 -0x276b8c(%rip)        # cca1c <_ZN6apache6thrift8protocol16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEE16readMessageBeginERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERNS1_12TMessageTypeERi+0x2c>
  3435a8:	e9 b3 c0 d4 ff                                  	jmp    8f660 <memcpy@plt>
  3435ad:	0f 1f 00                                        	nopl   (%rax)
  3435b0:	0f 18 3d c9 0c e7 ff                            	prefetchit0 -0x18f337(%rip)        # 1b4280 <_ZN11opentracing2v26Tracer6GlobalEv>
  3435b7:	0f 18 3d 75 23 d8 ff                            	prefetchit0 -0x27dc8b(%rip)        # c5933 <_ZNSt8_Rb_treeINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESt10_Select1stIS8_ESt4lessIS5_ESaIS8_EE8_M_eraseEPSt13_Rb_tree_nodeIS8_E+0x3>
  3435be:	0f 18 3d 8b 8f d8 ff                            	prefetchit0 -0x277075(%rip)        # cc550 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE12readI32_virtERi>
  3435c5:	0f 18 3d b4 c8 d5 ff                            	prefetchit0 -0x2a374c(%rip)        # 9fe80 <_ZN13media_service20ComposeReviewHandler13UploadMovieIdElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKSt3mapIS6_S6_St4lessIS6_ESaISt4pairIS7_S6_EEE>
  3435cc:	0f 18 3d ad e0 d5 ff                            	prefetchit0 -0x2a1f53(%rip)        # a1680 <_ZN13media_service20ComposeReviewHandler12UploadUserIdEllRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES7_St4lessIS7_ESaISt4pairIKS7_S7_EEE>
  3435d3:	0f 18 3d 86 fa d5 ff                            	prefetchit0 -0x2a057a(%rip)        # a3060 <_ZN13media_service20ComposeReviewHandler14UploadUniqueIdEllRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES7_St4lessIS7_ESaISt4pairIKS7_S7_EEE>
  3435da:	0f 18 3d e0 0c e7 ff                            	prefetchit0 -0x18f320(%rip)        # 1b42c1 <_ZN11opentracing2v26Tracer6GlobalEv+0x41>
  3435e1:	0f 18 3d 18 14 d6 ff                            	prefetchit0 -0x29ebe8(%rip)        # a4a00 <_ZN13media_service20ComposeReviewHandler10UploadTextElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKSt3mapIS6_S6_St4lessIS6_ESaISt4pairIS7_S6_EEE>
  3435e8:	e9 73 c0 d4 ff                                  	jmp    8f660 <memcpy@plt>
  3435ed:	0f 1f 00                                        	nopl   (%rax)
  3435f0:	0f 18 3d 09 5a dd ff                            	prefetchit0 -0x22a5f7(%rip)        # 119000 <_ZN6apache6thrift9transport16TFramedTransport5flushEv+0x10>
  3435f7:	0f 18 3d 12 2f dd ff                            	prefetchit0 -0x22d0ee(%rip)        # 116510 <_ZN6apache6thrift9transport17TVirtualTransportINS1_7TSocketENS1_18TTransportDefaultsEE10write_virtEPKhj>
  3435fe:	0f 18 3d 5b 1f dd ff                            	prefetchit0 -0x22e0a5(%rip)        # 115560 <_ZN6apache6thrift9transport7TSocket5writeEPKhj>
  343605:	0f 18 3d e4 59 dd ff                            	prefetchit0 -0x22a61c(%rip)        # 118ff0 <_ZN6apache6thrift9transport16TFramedTransport5flushEv>
  34360c:	0f 18 3d fd 86 d8 ff                            	prefetchit0 -0x277903(%rip)        # cbd10 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE21writeStructBegin_virtEPKc>
  343613:	0f 18 3d 76 87 d8 ff                            	prefetchit0 -0x27788a(%rip)        # cbd90 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE19writeFieldStop_virtEv>
  34361a:	0f 18 3d 2f 6f db ff                            	prefetchit0 -0x2490d1(%rip)        # fa550 <_ZNK13media_service38ReviewStorageService_StoreReview_pargs5writeEPN6apache6thrift8protocol9TProtocolE>
  343621:	0f 18 3d 48 d7 da ff                            	prefetchit0 -0x2528b8(%rip)        # f0d70 <_ZNK13media_service6Review5writeEPN6apache6thrift8protocol9TProtocolE>
  343628:	e9 33 c0 d4 ff                                  	jmp    8f660 <memcpy@plt>
  34362d:	0f 1f 00                                        	nopl   (%rax)
  343630:	0f 18 3d 09 dd d9 ff                            	prefetchit0 -0x2622f7(%rip)        # e1340 <_ZNSt15_Sp_counted_ptrIPN6apache6thrift8protocol9TProtocolELN9__gnu_cxx12_Lock_policyE2EE10_M_disposeEv>
  343637:	0f 18 3d e2 47 e5 ff                            	prefetchit0 -0x1ab81e(%rip)        # 197e20 <_ZNK13jaegertracing6thrift7SpanRef5writeEPN6apache6thrift8protocol9TProtocolE>
  34363e:	0f 18 3d bc 59 e5 ff                            	prefetchit0 -0x1aa644(%rip)        # 199001 <_ZNK13jaegertracing6thrift4Span5writeEPN6apache6thrift8protocol9TProtocolE+0x1f1>
  343645:	0f 18 3d 77 25 e3 ff                            	prefetchit0 -0x1cda89(%rip)        # 175bc3 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE19writeListBegin_virtENS1_5TTypeEj+0x23>
  34364c:	e9 0f c0 d4 ff                                  	jmp    8f660 <memcpy@plt>
  343651:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  34365b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  343660:	0f 18 3d e9 61 d8 ff                            	prefetchit0 -0x279e17(%rip)        # c9850 <_ZN5boost3log12v2s_mt_posix3aux14light_functionIFbRKNS1_19attribute_value_setEEE4implINS_7phoenix5actorINS_5proto7exprns_10basic_exprINSC_6tagns_3tag13greater_equalENSC_7argsns_5list2INS1_11expressions15attribute_actorINS1_7trivial14severity_levelENS1_16fallback_to_noneENSM_3tag8severityESB_EENSB_INSE_INSG_8terminalENSI_4termISN_EELl0EEEEEEELl2EEEEEE11invoke_implEPvS6_>
  343667:	0f 18 3d a2 c4 de ff                            	prefetchit0 -0x213b5e(%rip)        # 12fb10 <_ZNK5boost3log12v2s_mt_posix19attribute_value_set4findENS1_14attribute_nameE>
  34366e:	0f 18 3d cd c4 de ff                            	prefetchit0 -0x213b33(%rip)        # 12fb42 <_ZNK5boost3log12v2s_mt_posix19attribute_value_set4findENS1_14attribute_nameE+0x32>
  343675:	e9 56 62 df ff                                  	jmp    1398d0 <_ZN5boost3log12v2s_mt_posix4core14implementation15get_thread_dataEv>
  34367a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  343680:	0f 18 3d 09 bd d4 ff                            	prefetchit0 -0x2b42f7(%rip)        # 8f390 <memcached_pool_push@plt>
  343687:	0f 18 3d 99 38 d6 ff                            	prefetchit0 -0x29c767(%rip)        # a6f27 <_ZN13media_service20ComposeReviewHandler12UploadRatingEliRKSt3mapINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES7_St4lessIS7_ESaISt4pairIKS7_S7_EEE+0xd27>
  34368e:	41 53                                           	push   %r11
  343690:	4c 8b 1d 31 7b ff ff                            	mov    -0x84cf(%rip),%r11        # 33b1c8 <memcached_pool_push@Base>
  343697:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  34369f:	4c 8b 1d 22 7e ff ff                            	mov    -0x81de(%rip),%r11        # 33b4c8 <pthread_rwlock_unlock@GLIBC_2.34>
  3436a6:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3436ae:	41 0f 18 93 31 00 00 00                         	prefetcht1 0x31(%r11)
  3436b6:	4c 8b 1d cb 7f ff ff                            	mov    -0x8035(%rip),%r11        # 33b688 <memcached_pool_pop@Base>
  3436bd:	41 0f 18 93 80 f1 ff ff                         	prefetcht1 -0xe80(%r11)
  3436c5:	41 0f 18 93 70 00 00 00                         	prefetcht1 0x70(%r11)
  3436cd:	41 5b                                           	pop    %r11
  3436cf:	e9 cc c1 de ff                                  	jmp    12f8a0 <_ZN5boost3log12v2s_mt_posix19attribute_value_setD1Ev>
  3436d4:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3436de:	66 90                                           	xchg   %ax,%ax
  3436e0:	0f 18 3d da a0 e2 ff                            	prefetchit0 -0x1d5f26(%rip)        # 16d7c1 <_ZN13jaegertracing11SpanContext10fromStreamERSi+0x2c1>
  3436e7:	e9 64 be d4 ff                                  	jmp    8f550 <isupper@plt>
  3436ec:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3436f0:	0f 18 3d 79 d1 d7 ff                            	prefetchit0 -0x282e87(%rip)        # c0870 <_ZN13jaegertracingeqERKNS_11SpanContextES2_>
  3436f7:	0f 18 3d a2 8a d7 ff                            	prefetchit0 -0x28755e(%rip)        # bc1a0 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  3436fe:	0f 18 3d 9b d6 d7 ff                            	prefetchit0 -0x282965(%rip)        # c0da0 <_ZN13jaegertracing11SpanContext4swapERS0_>
  343705:	0f 18 3d f6 d6 d7 ff                            	prefetchit0 -0x28290a(%rip)        # c0e02 <_ZN13jaegertracing11SpanContext4swapERS0_+0x62>
  34370c:	0f 18 3d 3d ba d4 ff                            	prefetchit0 -0x2b45c3(%rip)        # 8f150 <pthread_mutex_trylock@plt>
  343713:	0f 18 3d 26 f2 f1 ff                            	prefetchit0 -0xe0dda(%rip)        # 262940 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_>
  34371a:	0f 18 3d 92 f2 f1 ff                            	prefetchit0 -0xe0d6e(%rip)        # 2629b3 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_+0x73>
  343721:	0f 18 3d 22 8b d7 ff                            	prefetchit0 -0x2874de(%rip)        # bc24a <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev+0xaa>
  343728:	e9 03 bd d4 ff                                  	jmp    8f430 <memset@plt>
  34372d:	0f 1f 00                                        	nopl   (%rax)
  343730:	0f 18 3d 69 be f1 ff                            	prefetchit0 -0xe4197(%rip)        # 25f5a0 <_ZNSt15basic_streambufIcSt11char_traitsIcEE5uflowEv>
  343737:	e9 a4 18 ef ff                                  	jmp    234fe0 <_ZNSi3getERc>
  34373c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343740:	0f 18 3d 99 22 f1 ff                            	prefetchit0 -0xedd67(%rip)        # 2559e0 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE9underflowEv>
  343747:	e9 24 a3 e2 ff                                  	jmp    16da70 <_ZN13jaegertracing5utils10HexParsing11readSegmentB5cxx11ERSimc>
  34374c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343750:	0f 18 3d 7d 9f e2 ff                            	prefetchit0 -0x1d6083(%rip)        # 16d6d4 <_ZN13jaegertracing11SpanContext10fromStreamERSi+0x1d4>
  343757:	0f 18 3d 64 d6 d7 ff                            	prefetchit0 -0x28299c(%rip)        # c0dc2 <_ZN13jaegertracing11SpanContext4swapERS0_+0x22>
  34375e:	e9 bd db ee ff                                  	jmp    231320 <_ZNSt9basic_iosIcSt11char_traitsIcEE5clearESt12_Ios_Iostate>
  343763:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  34376d:	0f 1f 00                                        	nopl   (%rax)
  343770:	0f 18 3d b9 bc d4 ff                            	prefetchit0 -0x2b4347(%rip)        # 8f430 <memset@plt>
  343777:	e9 84 db d7 ff                                  	jmp    c1300 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_>
  34377c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343780:	41 53                                           	push   %r11
  343782:	4c 8b 1d 1f 7b ff ff                            	mov    -0x84e1(%rip),%r11        # 33b2a8 <isupper@GLIBC_2.2.5>
  343789:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  343791:	41 5b                                           	pop    %r11
  343793:	e9 48 d1 f1 ff                                  	jmp    2608e0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm>
  343798:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3437a0:	0f 18 3d 19 9e e2 ff                            	prefetchit0 -0x1d61e7(%rip)        # 16d5c0 <_ZN13jaegertracing11SpanContext10fromStreamERSi+0xc0>
  3437a7:	0f 18 3d 55 9e e2 ff                            	prefetchit0 -0x1d61ab(%rip)        # 16d603 <_ZN13jaegertracing11SpanContext10fromStreamERSi+0x103>
  3437ae:	0f 18 3d 4d a9 e2 ff                            	prefetchit0 -0x1d56b3(%rip)        # 16e102 <_ZN13jaegertracing7TraceID10fromStreamERSi+0x242>
  3437b5:	e9 56 d0 e9 ff                                  	jmp    1e0810 <_ZdlPv>
  3437ba:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  3437c0:	0f 18 3d 3c 9e e2 ff                            	prefetchit0 -0x1d61c4(%rip)        # 16d603 <_ZN13jaegertracing11SpanContext10fromStreamERSi+0x103>
  3437c7:	e9 44 d0 e9 ff                                  	jmp    1e0810 <_ZdlPv>
  3437cc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3437d0:	0f 18 3d 36 b2 e2 ff                            	prefetchit0 -0x1d4dca(%rip)        # 16ea0d <_ZNK13jaegertracing6Tracer20StartSpanWithOptionsEN11opentracing2v211string_viewERKNS2_16StartSpanOptionsE+0x8ad>
  3437d7:	0f 18 3d 26 b0 e2 ff                            	prefetchit0 -0x1d4fda(%rip)        # 16e804 <_ZNK13jaegertracing6Tracer20StartSpanWithOptionsEN11opentracing2v211string_viewERKNS2_16StartSpanOptionsE+0x6a4>
  3437de:	0f 18 3d 25 b1 e2 ff                            	prefetchit0 -0x1d4edb(%rip)        # 16e90a <_ZNK13jaegertracing6Tracer20StartSpanWithOptionsEN11opentracing2v211string_viewERKNS2_16StartSpanOptionsE+0x7aa>
  3437e5:	0f 18 3d a4 95 ea ff                            	prefetchit0 -0x156a5c(%rip)        # 1ecd90 <_ZNSt6chrono3_V212system_clock3nowEv>
  3437ec:	e9 af d5 d7 ff                                  	jmp    c0da0 <_ZN13jaegertracing11SpanContext4swapERS0_>
  3437f1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3437fb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  343800:	0f 18 3d 89 e8 e2 ff                            	prefetchit0 -0x1d1777(%rip)        # 172090 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EE15_M_range_insertIN9__gnu_cxx17__normal_iteratorIPKS1_S3_EEEEvNS6_IPS1_S3_EET_SC_St20forward_iterator_tag>
  343807:	0f 18 3d cc eb e2 ff                            	prefetchit0 -0x1d1434(%rip)        # 1723da <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EE15_M_range_insertIN9__gnu_cxx17__normal_iteratorIPKS1_S3_EEEEvNS6_IPS1_S3_EET_SC_St20forward_iterator_tag+0x34a>
  34380e:	0f 18 3d bb c4 e2 ff                            	prefetchit0 -0x1d3b45(%rip)        # 16fcd0 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EE7reserveEm>
  343815:	0f 18 3d cd c5 e2 ff                            	prefetchit0 -0x1d3a33(%rip)        # 16fde9 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EE7reserveEm+0x119>
  34381c:	e9 6f 95 ea ff                                  	jmp    1ecd90 <_ZNSt6chrono3_V212system_clock3nowEv>
  343821:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  34382b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  343830:	0f 18 3d ca 8c d6 ff                            	prefetchit0 -0x297336(%rip)        # ac501 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE+0x91>
  343837:	e9 d4 cf e9 ff                                  	jmp    1e0810 <_ZdlPv>
  34383c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343840:	0f 18 3d e9 ee e2 ff                            	prefetchit0 -0x1d1117(%rip)        # 172730 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_>
  343847:	0f 18 3d 73 ef e2 ff                            	prefetchit0 -0x1d108d(%rip)        # 1727c1 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_+0x91>
  34384e:	0f 18 3d ec ee e2 ff                            	prefetchit0 -0x1d1114(%rip)        # 172741 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_+0x11>
  343855:	0f 18 3d 5a b7 e2 ff                            	prefetchit0 -0x1d48a6(%rip)        # 16efb6 <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE+0x1f6>
  34385c:	e9 df cf e9 ff                                  	jmp    1e0840 <__dynamic_cast>
  343861:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  34386b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  343870:	0f 18 3d 8c d8 e2 ff                            	prefetchit0 -0x1d2774(%rip)        # 171103 <_ZNSt12_Destroy_auxILb0EE9__destroyIPN13jaegertracing9ReferenceEEEvT_S5_+0x3>
  343877:	e9 b4 ee e2 ff                                  	jmp    172730 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE17_M_realloc_insertIJS1_EEEvN9__gnu_cxx17__normal_iteratorIPS1_S3_EEDpOT_>
  34387c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343880:	0f 18 3d 99 d6 e2 ff                            	prefetchit0 -0x1d2967(%rip)        # 170f20 <_ZNSt23mersenne_twister_engineImLm64ELm312ELm156ELm31ELm13043109905998158313ELm29ELm6148914691236517205ELm17ELm8202884508482404352ELm37ELm18444473444759240704ELm43ELm6364136223846793005EEclEv>
  343887:	e9 a4 bb d4 ff                                  	jmp    8f430 <memset@plt>
  34388c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343890:	0f 18 3d 19 a1 d7 ff                            	prefetchit0 -0x285ee7(%rip)        # bd9b0 <_ZNSt20__uninitialized_copyILb0EE13__uninit_copyIN9__gnu_cxx17__normal_iteratorIPKN13jaegertracing3TagESt6vectorIS5_SaIS5_EEEEPS5_EET0_T_SE_SD_>
  343897:	0f 18 3d a3 c5 e2 ff                            	prefetchit0 -0x1d3a5d(%rip)        # 16fe41 <_ZN13jaegertracing4SpanC2ERKSt10shared_ptrIKNS_6TracerEERKNS_11SpanContextERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKNSt6chrono10time_pointINSI_3_V212system_clockENSI_8durationIlSt5ratioILl1ELl1000000000EEEEEERKNSJ_INSK_12steady_clockESP_EERKSt6vectorINS_3TagESaISY_EERKSX_INS_9ReferenceESaIS13_EE+0x31>
  34389e:	0f 18 3d 1c a1 d7 ff                            	prefetchit0 -0x285ee4(%rip)        # bd9c1 <_ZNSt20__uninitialized_copyILb0EE13__uninit_copyIN9__gnu_cxx17__normal_iteratorIPKN13jaegertracing3TagESt6vectorIS5_SaIS5_EEEEPS5_EET0_T_SE_SD_+0x11>
  3438a5:	0f 18 3d 64 c5 e2 ff                            	prefetchit0 -0x1d3a9c(%rip)        # 16fe10 <_ZN13jaegertracing4SpanC2ERKSt10shared_ptrIKNS_6TracerEERKNS_11SpanContextERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKNSt6chrono10time_pointINSI_3_V212system_clockENSI_8durationIlSt5ratioILl1ELl1000000000EEEEEERKNSJ_INSK_12steady_clockESP_EERKSt6vectorINS_3TagESaISY_EERKSX_INS_9ReferenceESaIS13_EE>
  3438ac:	0f 18 3d 8f ba e2 ff                            	prefetchit0 -0x1d4571(%rip)        # 16f342 <_ZNK13jaegertracing6Tracer17startSpanInternalERKNS_11SpanContextERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKNSt6chrono10time_pointINSC_3_V212system_clockENSC_8durationIlSt5ratioILl1ELl1000000000EEEEEERKNSD_INSE_12steady_clockESJ_EERKSt6vectorINS_3TagESaISS_EERKSR_ISt4pairIS9_N11opentracing2v25ValueEESaIS11_EEbRKSR_INS_9ReferenceESaIS16_EE+0x232>
  3438b3:	e9 d8 e7 e2 ff                                  	jmp    172090 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EE15_M_range_insertIN9__gnu_cxx17__normal_iteratorIPKS1_S3_EEEEvNS6_IPS1_S3_EET_SC_St20forward_iterator_tag>
  3438b8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  3438c0:	0f 18 3d b9 a1 d7 ff                            	prefetchit0 -0x285e47(%rip)        # bda80 <_ZNSt20__uninitialized_copyILb0EE13__uninit_copyIN9__gnu_cxx17__normal_iteratorIPKN13jaegertracing3TagESt6vectorIS5_SaIS5_EEEEPS5_EET0_T_SE_SD_+0xd0>
  3438c7:	e9 e4 ea e9 ff                                  	jmp    1e23b0 <_Znwm>
  3438cc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3438d0:	0f 18 3d 29 d9 e2 ff                            	prefetchit0 -0x1d26d7(%rip)        # 171200 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EEC2ERKS3_+0x20>
  3438d7:	0f 18 3d 91 a1 d7 ff                            	prefetchit0 -0x285e6f(%rip)        # bda6f <_ZNSt20__uninitialized_copyILb0EE13__uninit_copyIN9__gnu_cxx17__normal_iteratorIPKN13jaegertracing3TagESt6vectorIS5_SaIS5_EEEEPS5_EET0_T_SE_SD_+0xbf>
  3438de:	e9 7d bd d4 ff                                  	jmp    8f660 <memcpy@plt>
  3438e3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3438ed:	0f 1f 00                                        	nopl   (%rax)
  3438f0:	0f 18 3d 49 13 d8 ff                            	prefetchit0 -0x27ecb7(%rip)        # c4c40 <_ZNK13media_service13TextMapReader10ForeachKeyESt8functionIFN11opentracing2v28expectedIvSt10error_codeEENS3_11string_viewES7_EE>
  3438f7:	0f 18 3d 72 c4 d7 ff                            	prefetchit0 -0x283b8e(%rip)        # bfd70 <_ZNSt17_Function_handlerIFN11opentracing2v28expectedIvSt10error_codeEENS1_11string_viewES5_EZNK13jaegertracing11propagation10PropagatorIRKNS1_13TextMapReaderERKNS1_13TextMapWriterEE7extractESC_EUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESO_E_E9_M_invokeERKSt9_Any_dataOS5_SU_>
  3438fe:	0f 18 3d 7c 13 d8 ff                            	prefetchit0 -0x27ec84(%rip)        # c4c81 <_ZNK13media_service13TextMapReader10ForeachKeyESt8functionIFN11opentracing2v28expectedIvSt10error_codeEENS3_11string_viewES7_EE+0x41>
  343905:	0f 18 3d 14 c5 d7 ff                            	prefetchit0 -0x283aec(%rip)        # bfe20 <_ZSt13__invoke_implIN11opentracing2v28expectedIvSt10error_codeEERZNK13jaegertracing11propagation10PropagatorIRKNS1_13TextMapReaderERKNS1_13TextMapWriterEE7extractESA_EUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESM_E_JNS1_11string_viewESP_EET_St14__invoke_otherOT0_DpOT1_>
  34390c:	0f 18 3d 70 c4 d7 ff                            	prefetchit0 -0x283b90(%rip)        # bfd83 <_ZNSt17_Function_handlerIFN11opentracing2v28expectedIvSt10error_codeEENS1_11string_viewES5_EZNK13jaegertracing11propagation10PropagatorIRKNS1_13TextMapReaderERKNS1_13TextMapWriterEE7extractESC_EUlRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESO_E_E9_M_invokeERKSt9_Any_dataOS5_SU_+0x13>
  343913:	e9 e8 b9 d7 ff                                  	jmp    bf300 <_ZNK13jaegertracing11propagation10PropagatorIRKN11opentracing2v213TextMapReaderERKNS3_13TextMapWriterEE7extractES6_>
  343918:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  343920:	0f 18 3d 49 8b d6 ff                            	prefetchit0 -0x2974b7(%rip)        # ac470 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE>
  343927:	0f 18 3d 92 8b d6 ff                            	prefetchit0 -0x29746e(%rip)        # ac4c0 <_ZNK11opentracing2v26Tracer9StartSpanENS0_11string_viewESt16initializer_listINS0_14option_wrapperINS0_15StartSpanOptionEEEE+0x50>
  34392e:	0f 18 3d 90 c6 d5 ff                            	prefetchit0 -0x2a3970(%rip)        # 9ffc5 <_ZN13media_service20ComposeReviewHandler13UploadMovieIdElRKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEERKSt3mapIS6_S6_St4lessIS6_ESaISt4pairIS7_S6_EEE+0x145>
  343935:	e9 76 ea e9 ff                                  	jmp    1e23b0 <_Znwm>
  34393a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  343940:	0f 18 3d 3e b5 e2 ff                            	prefetchit0 -0x1d4ac2(%rip)        # 16ee85 <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE+0xc5>
  343947:	e9 e4 ba d4 ff                                  	jmp    8f430 <memset@plt>
  34394c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343950:	0f 18 3d 79 9f d7 ff                            	prefetchit0 -0x286087(%rip)        # bd8d0 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EED2Ev>
  343957:	0f 18 3d 92 1a e6 ff                            	prefetchit0 -0x19e56e(%rip)        # 1a53f0 <_ZNK13jaegertracing4Span7contextEv>
  34395e:	0f 18 3d 4b 38 d7 ff                            	prefetchit0 -0x28c7b5(%rip)        # b71b0 <_ZN13jaegertracing7metrics11NullCounter3incEl>
  343965:	e9 26 a3 e2 ff                                  	jmp    16dc90 <_ZN13jaegertracing11SpanContextC2ERKS0_>
  34396a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  343970:	0f 18 3d 8a b6 e2 ff                            	prefetchit0 -0x1d4976(%rip)        # 16f001 <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE+0x241>
  343977:	e9 14 a3 e2 ff                                  	jmp    16dc90 <_ZN13jaegertracing11SpanContextC2ERKS0_>
  34397c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343980:	0f 18 3d 09 8d d8 ff                            	prefetchit0 -0x2772f7(%rip)        # cc690 <_ZN6apache6thrift8protocol17TProtocolDefaultsC2ESt10shared_ptrINS0_9transport10TTransportEE>
  343987:	0f 18 3d c2 19 e3 ff                            	prefetchit0 -0x1ce63e(%rip)        # 175350 <_ZN6apache6thrift8protocol24TCompactProtocolFactoryTINS0_9transport10TTransportEE11getProtocolESt10shared_ptrIS4_E>
  34398e:	0f 18 3d 3b 1d e3 ff                            	prefetchit0 -0x1ce2c5(%rip)        # 1756d0 <_ZN6apache6thrift8protocol17TCompactProtocolTINS0_9transport10TTransportEEC2ESt10shared_ptrIS4_Eii>
  343995:	e9 16 ea e9 ff                                  	jmp    1e23b0 <_Znwm>
  34399a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  3439a0:	0f 18 3d f9 48 e5 ff                            	prefetchit0 -0x1ab707(%rip)        # 1982a0 <_ZN13jaegertracing6thrift4SpanD2Ev>
  3439a7:	0f 18 3d 13 49 e5 ff                            	prefetchit0 -0x1ab6ed(%rip)        # 1982c1 <_ZN13jaegertracing6thrift4SpanD2Ev+0x21>
  3439ae:	e9 dd 49 e5 ff                                  	jmp    198390 <_ZN13jaegertracing6thrift4SpanD1Ev>
  3439b3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3439bd:	0f 1f 00                                        	nopl   (%rax)
  3439c0:	0f 18 3d 59 4a e5 ff                            	prefetchit0 -0x1ab5a7(%rip)        # 198420 <_ZN13jaegertracing6thrift4Span17__set_traceIdHighEl>
  3439c7:	e9 f4 c0 d4 ff                                  	jmp    8fac0 <pthread_mutex_lock@plt>
  3439cc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3439d0:	0f 18 3d 19 41 e5 ff                            	prefetchit0 -0x1abee7(%rip)        # 197af0 <_ZN13jaegertracing6thrift7SpanRef13__set_refTypeENS0_11SpanRefType4typeE>
  3439d7:	0f 18 3d 32 08 e3 ff                            	prefetchit0 -0x1cf7ce(%rip)        # 174210 <_ZNSt6vectorIN13jaegertracing6thrift7SpanRefESaIS2_EE20_M_allocate_and_copyIPKS2_EEPS2_mT_S9_>
  3439de:	e9 5d 4a e5 ff                                  	jmp    198440 <_ZN13jaegertracing6thrift4Span18__set_parentSpanIdEl>
  3439e3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3439ed:	0f 1f 00                                        	nopl   (%rax)
  3439f0:	0f 18 3d c9 7c e5 ff                            	prefetchit0 -0x1a8337(%rip)        # 19b6c0 <_ZNSt6vectorIN13jaegertracing6thrift3TagESaIS2_EEaSERKS4_>
  3439f7:	0f 18 3d f5 03 e3 ff                            	prefetchit0 -0x1cfc0b(%rip)        # 173df3 <_ZNK13jaegertracing4Span6thriftEv+0x463>
  3439fe:	0f 18 3d 1a 86 e5 ff                            	prefetchit0 -0x1a79e6(%rip)        # 19c01f <_ZNSt6vectorIN13jaegertracing6thrift3LogESaIS2_EEaSERKS4_+0x12f>
  343a05:	e9 86 4a e5 ff                                  	jmp    198490 <_ZN13jaegertracing6thrift4Span15__set_startTimeEl>
  343a0a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  343a10:	0f 18 3d 99 40 e5 ff                            	prefetchit0 -0x1abf67(%rip)        # 197ab0 <_ZN13jaegertracing6thrift7SpanRefD1Ev>
  343a17:	0f 18 3d 72 46 e5 ff                            	prefetchit0 -0x1ab98e(%rip)        # 198090 <_ZN13jaegertracing6thrift7SpanRefC1ERKS1_>
  343a1e:	0f 18 3d 7b 82 e5 ff                            	prefetchit0 -0x1a7d85(%rip)        # 19bca0 <_ZNSt6vectorIN13jaegertracing6thrift7SpanRefESaIS2_EEaSERKS4_>
  343a25:	e9 86 e9 e9 ff                                  	jmp    1e23b0 <_Znwm>
  343a2a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  343a30:	0f 18 3d 79 40 e5 ff                            	prefetchit0 -0x1abf87(%rip)        # 197ab0 <_ZN13jaegertracing6thrift7SpanRefD1Ev>
  343a37:	0f 18 3d 62 82 e5 ff                            	prefetchit0 -0x1a7d9e(%rip)        # 19bca0 <_ZNSt6vectorIN13jaegertracing6thrift7SpanRefESaIS2_EEaSERKS4_>
  343a3e:	0f 18 3d 4b 46 e5 ff                            	prefetchit0 -0x1ab9b5(%rip)        # 198090 <_ZN13jaegertracing6thrift7SpanRefC1ERKS1_>
  343a45:	0f 18 3d 75 82 e5 ff                            	prefetchit0 -0x1a7d8b(%rip)        # 19bcc1 <_ZNSt6vectorIN13jaegertracing6thrift7SpanRefESaIS2_EEaSERKS4_+0x21>
  343a4c:	e9 9f 40 e5 ff                                  	jmp    197af0 <_ZN13jaegertracing6thrift7SpanRef13__set_refTypeENS0_11SpanRefType4typeE>
  343a51:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  343a5b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  343a60:	0f 18 3d d9 23 e3 ff                            	prefetchit0 -0x1cdc27(%rip)        # 175e40 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE13writeI64_virtEl>
  343a67:	0f 18 3d a2 62 dd ff                            	prefetchit0 -0x229d5e(%rip)        # 119d10 <_ZN6apache6thrift9transport17TVirtualTransportINS1_13TMemoryBufferENS1_11TBufferBaseEE10write_virtEPKhj>
  343a6e:	e9 3d e9 e9 ff                                  	jmp    1e23b0 <_Znwm>
  343a73:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  343a7d:	0f 1f 00                                        	nopl   (%rax)
  343a80:	0f 18 3d 29 2a e3 ff                            	prefetchit0 -0x1cd5d7(%rip)        # 1764b0 <_ZNSt11_Deque_baseIsSaIsEE17_M_initialize_mapEm>
  343a87:	0f 18 3d 74 1e e3 ff                            	prefetchit0 -0x1ce18c(%rip)        # 175902 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEEC2ESt10shared_ptrIS5_E+0xa2>
  343a8e:	e9 cd 1d e3 ff                                  	jmp    175860 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEEC2ESt10shared_ptrIS5_E>
  343a93:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  343a9d:	0f 1f 00                                        	nopl   (%rax)
  343aa0:	0f 18 3d f9 ed dc ff                            	prefetchit0 -0x231207(%rip)        # 1128a0 <_ZN6apache6thrift8protocol9TProtocolD1Ev>
  343aa7:	0f 18 3d 1d f8 e2 ff                            	prefetchit0 -0x1d07e3(%rip)        # 1732cb <_ZN13jaegertracing12UDPTransport6appendERKNS_4SpanE+0x7bb>
  343aae:	0f 18 3d 0d ee dc ff                            	prefetchit0 -0x2311f3(%rip)        # 1128c2 <_ZN6apache6thrift8protocol9TProtocolD1Ev+0x22>
  343ab5:	e9 56 cd e9 ff                                  	jmp    1e0810 <_ZdlPv>
  343aba:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  343ac0:	0f 18 3d f9 60 dd ff                            	prefetchit0 -0x229f07(%rip)        # 119bc0 <_ZN6apache6thrift9transport13TMemoryBufferD0Ev>
  343ac7:	e9 d4 ed dc ff                                  	jmp    1128a0 <_ZN6apache6thrift8protocol9TProtocolD1Ev>
  343acc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343ad0:	0f 18 3d 39 53 e5 ff                            	prefetchit0 -0x1aacc7(%rip)        # 198e10 <_ZNK13jaegertracing6thrift4Span5writeEPN6apache6thrift8protocol9TProtocolE>
  343ad7:	0f 18 3d 82 1f e3 ff                            	prefetchit0 -0x1ce07e(%rip)        # 175a60 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_17TCompactProtocolTINS0_9transport10TTransportEEENS1_17TProtocolDefaultsEE21writeStructBegin_virtEPKc>
  343ade:	e9 cd e8 e9 ff                                  	jmp    1e23b0 <_Znwm>
  343ae3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  343aed:	0f 1f 00                                        	nopl   (%rax)
  343af0:	0f 18 3d 89 b4 e4 ff                            	prefetchit0 -0x1b4b77(%rip)        # 18ef80 <_ZN13jaegertracing4SpanC2ERKS0_>
  343af7:	0f 18 3d 0a b5 e4 ff                            	prefetchit0 -0x1b4af6(%rip)        # 18f008 <_ZN13jaegertracing4SpanC2ERKS0_+0x88>
  343afe:	0f 18 3d 4b b6 d4 ff                            	prefetchit0 -0x2b49b5(%rip)        # 8f150 <pthread_mutex_trylock@plt>
  343b05:	0f 18 3d b4 b5 e4 ff                            	prefetchit0 -0x1b4a4c(%rip)        # 18f0c0 <_ZN13jaegertracing4SpanC2ERKS0_+0x140>
  343b0c:	0f 18 3d 2f c8 e4 ff                            	prefetchit0 -0x1b37d1(%rip)        # 190342 <_ZNSt5dequeIN13jaegertracing4SpanESaIS1_EE16_M_push_back_auxIJRKS1_EEEvDpOT_+0x12>
  343b13:	e9 a8 bf d4 ff                                  	jmp    8fac0 <pthread_mutex_lock@plt>
  343b18:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  343b20:	41 53                                           	push   %r11
  343b22:	4c 8b 1d f7 74 ff ff                            	mov    -0x8b09(%rip),%r11        # 33b020 <pthread_cond_signal@GLIBC_2.3.2>
  343b29:	41 0f 18 93 61 00 00 00                         	prefetcht1 0x61(%r11)
  343b31:	41 5b                                           	pop    %r11
  343b33:	e9 48 ba d4 ff                                  	jmp    8f580 <pthread_mutex_unlock@plt>
  343b38:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  343b40:	41 53                                           	push   %r11
  343b42:	4c 8b 1d d7 74 ff ff                            	mov    -0x8b29(%rip),%r11        # 33b020 <pthread_cond_signal@GLIBC_2.3.2>
  343b49:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  343b51:	41 0f 18 93 21 00 00 00                         	prefetcht1 0x21(%r11)
  343b59:	41 5b                                           	pop    %r11
  343b5b:	e9 10 c5 ea ff                                  	jmp    1f0070 <_ZNSt18condition_variable10notify_oneEv>
  343b60:	0f 18 3d 19 f4 e2 ff                            	prefetchit0 -0x1d0be7(%rip)        # 172f80 <_ZN13jaegertracing12UDPTransport6appendERKNS_4SpanE+0x470>
  343b67:	0f 18 3d 22 fe e2 ff                            	prefetchit0 -0x1d01de(%rip)        # 173990 <_ZNK13jaegertracing4Span6thriftEv>
  343b6e:	0f 18 3d 06 f4 e2 ff                            	prefetchit0 -0x1d0bfa(%rip)        # 172f7b <_ZN13jaegertracing12UDPTransport6appendERKNS_4SpanE+0x46b>
  343b75:	0f 18 3d 04 ff e2 ff                            	prefetchit0 -0x1d00fc(%rip)        # 173a80 <_ZNK13jaegertracing4Span6thriftEv+0xf0>
  343b7c:	e9 4f b1 e4 ff                                  	jmp    18ecd0 <_ZN13jaegertracing9reporters14RemoteReporter8sendSpanERKNS_4SpanE>
  343b81:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  343b8b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  343b90:	41 53                                           	push   %r11
  343b92:	4c 8b 1d 1f 76 ff ff                            	mov    -0x89e1(%rip),%r11        # 33b1b8 <pthread_cond_clockwait@GLIBC_2.34>
  343b99:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  343ba1:	41 5b                                           	pop    %r11
  343ba3:	e9 d8 b9 d4 ff                                  	jmp    8f580 <pthread_mutex_unlock@plt>
  343ba8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  343bb0:	41 53                                           	push   %r11
  343bb2:	4c 8b 1d 07 77 ff ff                            	mov    -0x88f9(%rip),%r11        # 33b2c0 <pthread_mutex_unlock@GLIBC_2.2.5>
  343bb9:	41 0f 18 93 e0 fe ff ff                         	prefetcht1 -0x120(%r11)
  343bc1:	41 5b                                           	pop    %r11
  343bc3:	e9 a8 b7 d4 ff                                  	jmp    8f370 <pthread_cond_clockwait@plt>
  343bc8:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  343bd0:	0f 18 3d 79 af e4 ff                            	prefetchit0 -0x1b5087(%rip)        # 18eb50 <_ZN13jaegertracing9reporters14RemoteReporter10sweepQueueEv+0xb0>
  343bd7:	0f 18 3d e2 be d4 ff                            	prefetchit0 -0x2b411e(%rip)        # 8fac0 <pthread_mutex_lock@plt>
  343bde:	0f 18 3d 23 b4 e4 ff                            	prefetchit0 -0x1b4bdd(%rip)        # 18f008 <_ZN13jaegertracing4SpanC2ERKS0_+0x88>
  343be5:	0f 18 3d d4 b4 e4 ff                            	prefetchit0 -0x1b4b2c(%rip)        # 18f0c0 <_ZN13jaegertracing4SpanC2ERKS0_+0x140>
  343bec:	e9 ef 91 ea ff                                  	jmp    1ecde0 <_ZNSt6chrono3_V212steady_clock3nowEv>
  343bf1:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  343bfb:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  343c00:	0f 18 3d 99 d1 d7 ff                            	prefetchit0 -0x282e67(%rip)        # c0da0 <_ZN13jaegertracing11SpanContext4swapERS0_>
  343c07:	0f 18 3d 82 a0 e2 ff                            	prefetchit0 -0x1d5f7e(%rip)        # 16dc90 <_ZN13jaegertracing11SpanContextC2ERKS0_>
  343c0e:	e9 6d b3 e4 ff                                  	jmp    18ef80 <_ZN13jaegertracing4SpanC2ERKS0_>
  343c13:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  343c1d:	0f 1f 00                                        	nopl   (%rax)
  343c20:	0f 18 3d 38 d7 d7 ff                            	prefetchit0 -0x2828c8(%rip)        # c135f <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_+0x5f>
  343c27:	0f 18 3d 1c a1 e2 ff                            	prefetchit0 -0x1d5ee4(%rip)        # 16dd4a <_ZN13jaegertracing11SpanContextC2ERKS0_+0xba>
  343c2e:	e9 8d be d4 ff                                  	jmp    8fac0 <pthread_mutex_lock@plt>
  343c33:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  343c3d:	0f 1f 00                                        	nopl   (%rax)
  343c40:	0f 18 3d 39 d0 f1 ff                            	prefetchit0 -0xe2fc7(%rip)        # 260c80 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_assignERKS4_+0x30>
  343c47:	0f 18 3d 02 d0 f1 ff                            	prefetchit0 -0xe2ffe(%rip)        # 260c50 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_assignERKS4_>
  343c4e:	0f 18 3d d3 d0 f1 ff                            	prefetchit0 -0xe2f2d(%rip)        # 260d28 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_assignERKS4_+0xd8>
  343c55:	e9 36 a0 e2 ff                                  	jmp    16dc90 <_ZN13jaegertracing11SpanContextC2ERKS0_>
  343c5a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  343c60:	0f 18 3d 49 bc e4 ff                            	prefetchit0 -0x1b43b7(%rip)        # 18f8b0 <_ZNSt6vectorIN13jaegertracing9LogRecordESaIS1_EEaSERKS3_>
  343c67:	0f 18 3d 12 b9 e2 ff                            	prefetchit0 -0x1d46ee(%rip)        # 16f580 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EEaSERKS3_>
  343c6e:	0f 18 3d 4c bc e4 ff                            	prefetchit0 -0x1b43b4(%rip)        # 18f8c1 <_ZNSt6vectorIN13jaegertracing9LogRecordESaIS1_EEaSERKS3_+0x11>
  343c75:	e9 d6 cf f1 ff                                  	jmp    260c50 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_assignERKS4_>
  343c7a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  343c80:	0f 18 3d 29 c3 e4 ff                            	prefetchit0 -0x1b3cd7(%rip)        # 18ffb0 <_ZNSt6vectorIN13jaegertracing9ReferenceESaIS1_EE20_M_allocate_and_copyIN9__gnu_cxx17__normal_iteratorIPKS1_S3_EEEEPS1_mT_SB_>
  343c87:	0f 18 3d 75 d4 e2 ff                            	prefetchit0 -0x1d2b8b(%rip)        # 171103 <_ZNSt12_Destroy_auxILb0EE9__destroyIPN13jaegertracing9ReferenceEEEvT_S5_+0x3>
  343c8e:	0f 18 3d 3d d5 e2 ff                            	prefetchit0 -0x1d2ac3(%rip)        # 1711d2 <_ZNSt12_Destroy_auxILb0EE9__destroyIPN13jaegertracing9ReferenceEEEvT_S5_+0xd2>
  343c95:	e9 16 bc e4 ff                                  	jmp    18f8b0 <_ZNSt6vectorIN13jaegertracing9LogRecordESaIS1_EEaSERKS3_>
  343c9a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  343ca0:	0f 18 3d c9 c3 ea ff                            	prefetchit0 -0x153c37(%rip)        # 1f0070 <_ZNSt18condition_variable10notify_oneEv>
  343ca7:	0f 18 3d b2 01 e6 ff                            	prefetchit0 -0x19fe4e(%rip)        # 1a3e60 <_ZN13jaegertracing4Span17FinishWithOptionsERKN11opentracing2v217FinishSpanOptionsE>
  343cae:	e9 cd b8 d4 ff                                  	jmp    8f580 <pthread_mutex_unlock@plt>
  343cb3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  343cbd:	0f 1f 00                                        	nopl   (%rax)
  343cc0:	0f 18 3d 09 9c d7 ff                            	prefetchit0 -0x2863f7(%rip)        # bd8d0 <_ZNSt6vectorIN13jaegertracing3TagESaIS1_EED2Ev>
  343cc7:	e9 34 d4 e2 ff                                  	jmp    171100 <_ZNSt12_Destroy_auxILb0EE9__destroyIPN13jaegertracing9ReferenceEEEvT_S5_>
  343ccc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343cd0:	0f 18 3d 39 bf d7 ff                            	prefetchit0 -0x2840c7(%rip)        # bfc10 <_ZN13jaegertracing11SpanContextD0Ev>
  343cd7:	0f 18 3d c2 84 d7 ff                            	prefetchit0 -0x287b3e(%rip)        # bc1a0 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEED2Ev>
  343cde:	0f 18 3d 2b ee e2 ff                            	prefetchit0 -0x1d11d5(%rip)        # 172b10 <_ZN13jaegertracing12UDPTransport6appendERKNS_4SpanE>
  343ce5:	e9 46 b7 d4 ff                                  	jmp    8f430 <memset@plt>
  343cea:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  343cf0:	0f 18 3d cc ae e4 ff                            	prefetchit0 -0x1b5134(%rip)        # 18ebc3 <_ZN13jaegertracing9reporters14RemoteReporter10sweepQueueEv+0x123>
  343cf7:	e9 94 9f e2 ff                                  	jmp    16dc90 <_ZN13jaegertracing11SpanContextC2ERKS0_>
  343cfc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343d00:	0f 18 3d 89 9f e2 ff                            	prefetchit0 -0x1d6077(%rip)        # 16dc90 <_ZN13jaegertracing11SpanContextC2ERKS0_>
  343d07:	0f 18 3d f5 9f e2 ff                            	prefetchit0 -0x1d600b(%rip)        # 16dd03 <_ZN13jaegertracing11SpanContextC2ERKS0_+0x73>
  343d0e:	0f 18 3d 8b d0 d7 ff                            	prefetchit0 -0x282f75(%rip)        # c0da0 <_ZN13jaegertracing11SpanContext4swapERS0_>
  343d15:	0f 18 3d a6 d0 d7 ff                            	prefetchit0 -0x282f5a(%rip)        # c0dc2 <_ZN13jaegertracing11SpanContext4swapERS0_+0x22>
  343d1c:	0f 18 3d dd d5 d7 ff                            	prefetchit0 -0x282a23(%rip)        # c1300 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_>
  343d23:	0f 18 3d d8 d0 d7 ff                            	prefetchit0 -0x282f28(%rip)        # c0e02 <_ZN13jaegertracing11SpanContext4swapERS0_+0x62>
  343d2a:	0f 18 3d 92 9f e2 ff                            	prefetchit0 -0x1d606e(%rip)        # 16dcc3 <_ZN13jaegertracing11SpanContextC2ERKS0_+0x33>
  343d31:	0f 18 3d 08 ec f1 ff                            	prefetchit0 -0xe13f8(%rip)        # 262940 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE4swapERS4_>
  343d38:	e9 43 b2 e4 ff                                  	jmp    18ef80 <_ZN13jaegertracing4SpanC2ERKS0_>
  343d3d:	0f 1f 00                                        	nopl   (%rax)
  343d40:	0f 18 3d 49 46 e5 ff                            	prefetchit0 -0x1ab9b7(%rip)        # 198390 <_ZN13jaegertracing6thrift4SpanD1Ev>
  343d47:	e9 54 7f e5 ff                                  	jmp    19bca0 <_ZNSt6vectorIN13jaegertracing6thrift7SpanRefESaIS2_EEaSERKS4_>
  343d4c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343d50:	0f 18 3d 09 22 e6 ff                            	prefetchit0 -0x19ddf7(%rip)        # 1a5f60 <_ZNSt11__copy_moveILb0ELb0ESt26random_access_iterator_tagE8__copy_mIPKN11opentracing2v29LogRecordESt20back_insert_iteratorISt6vectorIN13jaegertracing9LogRecordESaISB_EEEEET0_T_SG_SF_>
  343d57:	e9 64 bd d4 ff                                  	jmp    8fac0 <pthread_mutex_lock@plt>
  343d5c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343d60:	0f 18 3d 9a 16 e6 ff                            	prefetchit0 -0x19e966(%rip)        # 1a5401 <_ZNK13jaegertracing4Span7contextEv+0x11>
  343d67:	e9 f4 21 e6 ff                                  	jmp    1a5f60 <_ZNSt11__copy_moveILb0ELb0ESt26random_access_iterator_tagE8__copy_mIPKN11opentracing2v29LogRecordESt20back_insert_iteratorISt6vectorIN13jaegertracing9LogRecordESaISB_EEEEET0_T_SG_SF_>
  343d6c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343d70:	0f 18 3d a9 aa e4 ff                            	prefetchit0 -0x1b5557(%rip)        # 18e820 <_ZN13jaegertracing9reporters14RemoteReporter6reportERKNS_4SpanE>
  343d77:	0f 18 3d b2 c5 e4 ff                            	prefetchit0 -0x1b3a4e(%rip)        # 190330 <_ZNSt5dequeIN13jaegertracing4SpanESaIS1_EE16_M_push_back_auxIJRKS1_EEEvDpOT_>
  343d7e:	0f 18 3d 2b 34 d7 ff                            	prefetchit0 -0x28cbd5(%rip)        # b71b0 <_ZN13jaegertracing7metrics11NullCounter3incEl>
  343d85:	0f 18 3d 64 16 e6 ff                            	prefetchit0 -0x19e99c(%rip)        # 1a53f0 <_ZNK13jaegertracing4Span7contextEv>
  343d8c:	0f 18 3d ee aa e4 ff                            	prefetchit0 -0x1b5512(%rip)        # 18e881 <_ZN13jaegertracing9reporters14RemoteReporter6reportERKNS_4SpanE+0x61>
  343d93:	0f 18 3d e7 c5 e4 ff                            	prefetchit0 -0x1b3a19(%rip)        # 190381 <_ZNSt5dequeIN13jaegertracing4SpanESaIS1_EE16_M_push_back_auxIJRKS1_EEEvDpOT_+0x51>
  343d9a:	0f 18 3d a1 aa e4 ff                            	prefetchit0 -0x1b555f(%rip)        # 18e842 <_ZN13jaegertracing9reporters14RemoteReporter6reportERKNS_4SpanE+0x22>
  343da1:	0f 18 3d 08 e6 e9 ff                            	prefetchit0 -0x1619f8(%rip)        # 1e23b0 <_Znwm>
  343da8:	e9 d3 b7 d4 ff                                  	jmp    8f580 <pthread_mutex_unlock@plt>
  343dad:	0f 1f 00                                        	nopl   (%rax)
  343db0:	0f 18 3d c3 b2 e2 ff                            	prefetchit0 -0x1d4d3d(%rip)        # 16f07a <_ZNK13jaegertracing6Tracer17analyzeReferencesERKSt6vectorISt4pairIN11opentracing2v217SpanReferenceTypeEPKNS4_11SpanContextEESaIS9_EE+0x2ba>
  343db7:	e9 f4 bb d4 ff                                  	jmp    8f9b0 <malloc@plt>
  343dbc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343dc0:	0f 18 3d d9 83 ef ff                            	prefetchit0 -0x107c27(%rip)        # 23c1a0 <_ZSt9use_facetISt7num_getIcSt19istreambuf_iteratorIcSt11char_traitsIcEEEERKT_RKSt6locale>
  343dc7:	e9 24 84 ef ff                                  	jmp    23c1f0 <_ZSt9use_facetISt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEEERKT_RKSt6locale>
  343dcc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343dd0:	0f 18 3d 29 97 e2 ff                            	prefetchit0 -0x1d68d7(%rip)        # 16d500 <_ZN13jaegertracing11SpanContext10fromStreamERSi>
  343dd7:	0f 18 3d a5 97 e2 ff                            	prefetchit0 -0x1d685b(%rip)        # 16d583 <_ZN13jaegertracing11SpanContext10fromStreamERSi+0x83>
  343dde:	0f 18 3d 5f 97 e2 ff                            	prefetchit0 -0x1d68a1(%rip)        # 16d544 <_ZN13jaegertracing11SpanContext10fromStreamERSi+0x44>
  343de5:	0f 18 3d 34 d7 d7 ff                            	prefetchit0 -0x2828cc(%rip)        # c1520 <_ZNK13jaegertracing11SpanContext5printISoEEvRT_>
  343dec:	0f 18 3d fd d7 d7 ff                            	prefetchit0 -0x282803(%rip)        # c15f0 <_ZNK13jaegertracing7TraceID5printISoEEvRT_>
  343df3:	0f 18 3d 07 d0 f0 ff                            	prefetchit0 -0xf2ff9(%rip)        # 250e01 <_ZNSo9_M_insertImEERSoT_+0x31>
  343dfa:	0f 18 3d cf cf f0 ff                            	prefetchit0 -0xf3031(%rip)        # 250dd0 <_ZNSo9_M_insertImEERSoT_>
  343e01:	0f 18 3d 79 dd ee ff                            	prefetchit0 -0x112287(%rip)        # 231b81 <_ZNSt9basic_iosIcSt11char_traitsIcEE4initEPSt15basic_streambufIcS1_E+0x51>
  343e08:	e9 33 84 ef ff                                  	jmp    23c240 <_ZSt9has_facetISt7num_getIcSt19istreambuf_iteratorIcSt11char_traitsIcEEEEbRKSt6locale>
  343e0d:	0f 1f 00                                        	nopl   (%rax)
  343e10:	0f 18 3d c9 4d f1 ff                            	prefetchit0 -0xeb237(%rip)        # 258be0 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode+0x1d0>
  343e17:	0f 18 3d e3 d7 d7 ff                            	prefetchit0 -0x28281d(%rip)        # c1601 <_ZNK13jaegertracing7TraceID5printISoEEvRT_+0x11>
  343e1e:	e9 7d 83 ef ff                                  	jmp    23c1a0 <_ZSt9use_facetISt7num_getIcSt19istreambuf_iteratorIcSt11char_traitsIcEEEERKT_RKSt6locale>
  343e23:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  343e2d:	0f 1f 00                                        	nopl   (%rax)
  343e30:	0f 18 3d ca f0 e9 ff                            	prefetchit0 -0x160f36(%rip)        # 1e2f01 <_ZNK10__cxxabiv121__vmi_class_type_info12__do_dyncastElNS_17__class_type_info10__sub_kindEPKS1_PKvS4_S6_RNS1_16__dyncast_resultE+0x561>
  343e37:	41 53                                           	push   %r11
  343e39:	4c 8b 1d d8 76 ff ff                            	mov    -0x8928(%rip),%r11        # 33b518 <strcmp@GLIBC_2.2.5>
  343e40:	41 0f 18 93 20 00 00 00                         	prefetcht1 0x20(%r11)
  343e48:	41 5b                                           	pop    %r11
  343e4a:	e9 41 9b f3 ff                                  	jmp    27d990 <_ZNSt8ios_base7_M_initEv>
  343e4f:	90                                              	nop
  343e50:	0f 18 3d a9 d4 d7 ff                            	prefetchit0 -0x282b57(%rip)        # c1300 <_ZNSt10_HashtableINSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEESt4pairIKS5_S5_ESaIS8_ENSt8__detail10_Select1stESt8equal_toIS5_ESt4hashIS5_ENSA_18_Mod_range_hashingENSA_20_Default_ranged_hashENSA_20_Prime_rehash_policyENSA_17_Hashtable_traitsILb1ELb0ELb1EEEE9_M_assignIRKSL_NSA_10_AllocNodeISaINSA_10_Hash_nodeIS8_Lb1EEEEEEEEvOT_RKT0_>
  343e57:	0f 18 3d b1 9b e2 ff                            	prefetchit0 -0x1d644f(%rip)        # 16da0f <_ZN13jaegertracing11SpanContext10fromStreamERSi+0x50f>
  343e5e:	0f 18 3d 1b 9b e2 ff                            	prefetchit0 -0x1d64e5(%rip)        # 16d980 <_ZN13jaegertracing11SpanContext10fromStreamERSi+0x480>
  343e65:	e9 b6 d4 ee ff                                  	jmp    231320 <_ZNSt9basic_iosIcSt11char_traitsIcEE5clearESt12_Ios_Iostate>
  343e6a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  343e70:	0f 18 3d 9b a1 e2 ff                            	prefetchit0 -0x1d5e65(%rip)        # 16e012 <_ZN13jaegertracing7TraceID10fromStreamERSi+0x152>
  343e77:	0f 18 3d c6 a1 e2 ff                            	prefetchit0 -0x1d5e3a(%rip)        # 16e044 <_ZN13jaegertracing7TraceID10fromStreamERSi+0x184>
  343e7e:	e9 7d 09 ef ff                                  	jmp    234800 <_ZNSi6sentryC1ERSib>
  343e83:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  343e8d:	0f 1f 00                                        	nopl   (%rax)
  343e90:	0f 18 3d 49 d0 f0 ff                            	prefetchit0 -0xf2fb7(%rip)        # 250ee0 <_ZNSo9_M_insertImEERSoT_+0x110>
  343e97:	0f 18 3d a5 4c f1 ff                            	prefetchit0 -0xeb35b(%rip)        # 258b43 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode+0x133>
  343e9e:	0f 18 3d 9d 55 f1 ff                            	prefetchit0 -0xeaa63(%rip)        # 259442 <_ZNSt7__cxx1119basic_ostringstreamIcSt11char_traitsIcESaIcEEC1Ev+0x102>
  343ea5:	e9 96 c9 e9 ff                                  	jmp    1e0840 <__dynamic_cast>
  343eaa:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  343eb0:	0f 18 3d 4f d8 ee ff                            	prefetchit0 -0x1127b1(%rip)        # 231706 <_ZNSt9basic_iosIcSt11char_traitsIcEE15_M_cache_localeERKSt6locale+0x46>
  343eb7:	e9 44 1c ea ff                                  	jmp    1e5b00 <_ZNKSt6locale2id5_M_idEv>
  343ebc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343ec0:	0f 18 3d 79 83 ef ff                            	prefetchit0 -0x107c87(%rip)        # 23c240 <_ZSt9has_facetISt7num_getIcSt19istreambuf_iteratorIcSt11char_traitsIcEEEEbRKSt6locale>
  343ec7:	e9 74 c9 e9 ff                                  	jmp    1e0840 <__dynamic_cast>
  343ecc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343ed0:	0f 18 3d eb e6 e9 ff                            	prefetchit0 -0x161915(%rip)        # 1e25c2 <_ZNK10__cxxabiv120__si_class_type_info12__do_dyncastElNS_17__class_type_info10__sub_kindEPKS1_PKvS4_S6_RNS1_16__dyncast_resultE+0x22>
  343ed7:	0f 18 3d c2 e6 e9 ff                            	prefetchit0 -0x16193e(%rip)        # 1e25a0 <_ZNK10__cxxabiv120__si_class_type_info12__do_dyncastElNS_17__class_type_info10__sub_kindEPKS1_PKvS4_S6_RNS1_16__dyncast_resultE>
  343ede:	e9 1d 1c ea ff                                  	jmp    1e5b00 <_ZNKSt6locale2id5_M_idEv>
  343ee3:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  343eed:	0f 1f 00                                        	nopl   (%rax)
  343ef0:	0f 18 3d 99 83 ef ff                            	prefetchit0 -0x107c67(%rip)        # 23c290 <_ZSt9has_facetISt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEEEbRKSt6locale>
  343ef7:	0f 18 3d c2 a9 ef ff                            	prefetchit0 -0x10563e(%rip)        # 23e8c0 <_ZSt9use_facetISt5ctypeIcEERKT_RKSt6locale>
  343efe:	e9 fd 1b ea ff                                  	jmp    1e5b00 <_ZNKSt6locale2id5_M_idEv>
  343f03:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  343f0d:	0f 1f 00                                        	nopl   (%rax)
  343f10:	0f 18 3d 50 ec ef ff                            	prefetchit0 -0x1013b0(%rip)        # 242b67 <_ZNKSt7num_putIcSt19ostreambuf_iteratorIcSt11char_traitsIcEEE13_M_insert_intImEES3_S3_RSt8ios_basecT_+0x277>
  343f17:	e9 44 e5 ef ff                                  	jmp    242460 <_ZNKSt11__use_cacheISt16__numpunct_cacheIcEEclERKSt6locale>
  343f1c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343f20:	0f 18 3d d9 2e f1 ff                            	prefetchit0 -0xed127(%rip)        # 256e00 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8_M_pbumpEPcS5_l>
  343f27:	0f 18 3d d2 b5 f1 ff                            	prefetchit0 -0xe4a2e(%rip)        # 25f500 <_ZNSt15basic_streambufIcSt11char_traitsIcEE6xsputnEPKcl>
  343f2e:	0f 18 3d 8c 34 f1 ff                            	prefetchit0 -0xecb74(%rip)        # 2573c1 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8overflowEi+0x31>
  343f35:	0f 18 3d f4 35 f1 ff                            	prefetchit0 -0xeca0c(%rip)        # 257530 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8overflowEi+0x1a0>
  343f3c:	0f 18 3d 4d 34 f1 ff                            	prefetchit0 -0xecbb3(%rip)        # 257390 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8overflowEi>
  343f43:	0f 18 3d f8 35 f1 ff                            	prefetchit0 -0xeca08(%rip)        # 257542 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8overflowEi+0x1b2>
  343f4a:	e9 91 e3 ef ff                                  	jmp    2422e0 <_ZSt13__int_to_charIcmEiPT_T0_PKS0_St13_Ios_Fmtflagsb>
  343f4f:	90                                              	nop
  343f50:	0f 18 3d 79 c5 f0 ff                            	prefetchit0 -0xf3a87(%rip)        # 2504d0 <_ZSt16__ostream_insertIcSt11char_traitsIcEERSt13basic_ostreamIT_T0_ES6_PKS3_l>
  343f57:	0f 18 3d e4 d5 d7 ff                            	prefetchit0 -0x282a1c(%rip)        # c1542 <_ZNK13jaegertracing11SpanContext5printISoEEvRT_+0x22>
  343f5e:	e9 2d 31 f1 ff                                  	jmp    257090 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE7_M_syncEPcmm>
  343f63:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  343f6d:	0f 1f 00                                        	nopl   (%rax)
  343f70:	0f 18 3d cc 34 f1 ff                            	prefetchit0 -0xecb34(%rip)        # 257443 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8overflowEi+0xb3>
  343f77:	e9 84 2e f1 ff                                  	jmp    256e00 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE8_M_pbumpEPcS5_l>
  343f7c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  343f80:	0f 18 3d a9 18 ea ff                            	prefetchit0 -0x15e757(%rip)        # 1e5830 <_ZNSt6localeaSERKS_>
  343f87:	0f 18 3d a2 db ee ff                            	prefetchit0 -0x11245e(%rip)        # 231b30 <_ZNSt9basic_iosIcSt11char_traitsIcEE4initEPSt15basic_streambufIcS1_E>
  343f8e:	0f 18 3d fb 99 f3 ff                            	prefetchit0 -0xc6605(%rip)        # 27d990 <_ZNSt8ios_base7_M_initEv>
  343f95:	0f 18 3d a4 db ee ff                            	prefetchit0 -0x11245c(%rip)        # 231b40 <_ZNSt9basic_iosIcSt11char_traitsIcEE4initEPSt15basic_streambufIcS1_E+0x10>
  343f9c:	0f 18 3d 1d 9a f3 ff                            	prefetchit0 -0xc65e3(%rip)        # 27d9c0 <_ZNSt8ios_base7_M_initEv+0x30>
  343fa3:	0f 18 3d 96 18 ea ff                            	prefetchit0 -0x15e76a(%rip)        # 1e5840 <_ZNSt6localeaSERKS_+0x10>
  343faa:	e9 41 e7 ee ff                                  	jmp    2326f0 <_ZNSt8ios_baseC1Ev>
  343faf:	90                                              	nop
  343fb0:	0f 18 3d 0d ca ef ff                            	prefetchit0 -0x1035f3(%rip)        # 2409c4 <_ZSt9has_facetISt5ctypeIcEEbRKSt6locale+0x14>
  343fb7:	0f 18 3d f2 c9 ef ff                            	prefetchit0 -0x10360e(%rip)        # 2409b0 <_ZSt9has_facetISt5ctypeIcEEbRKSt6locale>
  343fbe:	0f 18 3d 3c ea e9 ff                            	prefetchit0 -0x1615c4(%rip)        # 1e2a01 <_ZNK10__cxxabiv121__vmi_class_type_info12__do_dyncastElNS_17__class_type_info10__sub_kindEPKS1_PKvS4_S6_RNS1_16__dyncast_resultE+0x61>
  343fc5:	0f 18 3d f7 e9 e9 ff                            	prefetchit0 -0x161609(%rip)        # 1e29c3 <_ZNK10__cxxabiv121__vmi_class_type_info12__do_dyncastElNS_17__class_type_info10__sub_kindEPKS1_PKvS4_S6_RNS1_16__dyncast_resultE+0x23>
  343fcc:	0f 18 3d 1d ef e9 ff                            	prefetchit0 -0x1610e3(%rip)        # 1e2ef0 <_ZNK10__cxxabiv121__vmi_class_type_info12__do_dyncastElNS_17__class_type_info10__sub_kindEPKS1_PKvS4_S6_RNS1_16__dyncast_resultE+0x550>
  343fd3:	0f 18 3d e6 d6 ee ff                            	prefetchit0 -0x11291a(%rip)        # 2316c0 <_ZNSt9basic_iosIcSt11char_traitsIcEE15_M_cache_localeERKSt6locale>
  343fda:	0f 18 3d bf e9 e9 ff                            	prefetchit0 -0x161641(%rip)        # 1e29a0 <_ZNK10__cxxabiv121__vmi_class_type_info12__do_dyncastElNS_17__class_type_info10__sub_kindEPKS1_PKvS4_S6_RNS1_16__dyncast_resultE>
  343fe1:	0f 18 3d d8 c8 e9 ff                            	prefetchit0 -0x163728(%rip)        # 1e08c0 <__dynamic_cast+0x80>
  343fe8:	e9 43 db ee ff                                  	jmp    231b30 <_ZNSt9basic_iosIcSt11char_traitsIcEE4initEPSt15basic_streambufIcS1_E>
  343fed:	0f 1f 00                                        	nopl   (%rax)
  343ff0:	0f 18 3d 09 4c f1 ff                            	prefetchit0 -0xeb3f7(%rip)        # 258c00 <_ZNSt7__cxx1119basic_istringstreamIcSt11char_traitsIcESaIcEEC1ERKNS_12basic_stringIcS2_S3_EESt13_Ios_Openmode+0x1f0>
  343ff7:	e9 24 34 ea ff                                  	jmp    1e7420 <_ZNSt6localeC1Ev>
  343ffc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  344000:	0f 18 3d bb 30 f1 ff                            	prefetchit0 -0xecf45(%rip)        # 2570c2 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE7_M_syncEPcmm+0x32>
  344007:	0f 18 3d 82 30 f1 ff                            	prefetchit0 -0xecf7e(%rip)        # 257090 <_ZNSt7__cxx1115basic_stringbufIcSt11char_traitsIcESaIcEE7_M_syncEPcmm>
  34400e:	e9 cd c8 f1 ff                                  	jmp    2608e0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm>
  344013:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  34401d:	0f 1f 00                                        	nopl   (%rax)
  344020:	0f 18 3d 89 b9 d4 ff                            	prefetchit0 -0x2b4677(%rip)        # 8f9b0 <malloc@plt>
  344027:	0f 18 3d 02 b4 d4 ff                            	prefetchit0 -0x2b4bfe(%rip)        # 8f430 <memset@plt>
  34402e:	0f 18 3d 7b e3 e9 ff                            	prefetchit0 -0x161c85(%rip)        # 1e23b0 <_Znwm>
  344035:	0f 18 3d 47 cd f1 ff                            	prefetchit0 -0xe32b9(%rip)        # 260d83 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm+0x33>
  34403c:	e9 9f c8 f1 ff                                  	jmp    2608e0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm>
  344041:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  34404b:	0f 1f 44 00 00                                  	nopl   0x0(%rax,%rax,1)
  344050:	0f 18 3d 6b 1c ef ff                            	prefetchit0 -0x10e395(%rip)        # 235cc2 <_ZNSi7putbackEc+0x32>
  344057:	e9 84 c8 f1 ff                                  	jmp    2608e0 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_createERmm>
  34405c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  344060:	0f 18 3d 29 1c ef ff                            	prefetchit0 -0x10e3d7(%rip)        # 235c90 <_ZNSi7putbackEc>
  344067:	0f 18 3d b2 d2 ee ff                            	prefetchit0 -0x112d4e(%rip)        # 231320 <_ZNSt9basic_iosIcSt11char_traitsIcEE5clearESt12_Ios_Iostate>
  34406e:	e9 ed b5 d4 ff                                  	jmp    8f660 <memcpy@plt>
  344073:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  34407d:	0f 1f 00                                        	nopl   (%rax)
  344080:	0f 18 3d 48 74 dc ff                            	prefetchit0 -0x238bb8(%rip)        # 10b4cf <_ZN13media_service24MovieReviewServiceClient22recv_UploadMovieReviewEv+0x4f>
  344087:	0f 18 3d a2 f1 f1 ff                            	prefetchit0 -0xe0e5e(%rip)        # 263230 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc>
  34408e:	0f 18 3d ab f1 f1 ff                            	prefetchit0 -0xe0e55(%rip)        # 263240 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc+0x10>
  344095:	0f 18 3d a4 81 d8 ff                            	prefetchit0 -0x277e5c(%rip)        # cc240 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE15readMapEnd_virtEv>
  34409c:	0f 18 3d 6d bc d4 ff                            	prefetchit0 -0x2b4393(%rip)        # 8fd10 <memcached_pool_pop@plt>
  3440a3:	0f 18 3d d9 fb db ff                            	prefetchit0 -0x240427(%rip)        # 103c83 <_ZN13media_service23UserReviewServiceClient21recv_UploadUserReviewEv+0x53>
  3440aa:	41 53                                           	push   %r11
  3440ac:	4c 8b 1d d5 70 ff ff                            	mov    -0x8f2b(%rip),%r11        # 33b188 <strlen@GLIBC_2.2.5>
  3440b3:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  3440bb:	41 5b                                           	pop    %r11
  3440bd:	e9 9e b5 d4 ff                                  	jmp    8f660 <memcpy@plt>
  3440c2:	66 2e 0f 1f 84 00 00 00 00 00                   	cs nopw 0x0(%rax,%rax,1)
  3440cc:	0f 1f 40 00                                     	nopl   0x0(%rax)
  3440d0:	41 53                                           	push   %r11
  3440d2:	4c 8b 1d 2f 73 ff ff                            	mov    -0x8cd1(%rip),%r11        # 33b408 <memcached_add@Base>
  3440d9:	41 0f 18 93 00 fb ff ff                         	prefetcht1 -0x500(%r11)
  3440e1:	41 0f 18 93 11 fb ff ff                         	prefetcht1 -0x4ef(%r11)
  3440e9:	4c 8b 1d 98 75 ff ff                            	mov    -0x8a68(%rip),%r11        # 33b688 <memcached_pool_pop@Base>
  3440f0:	41 0f 18 93 20 f3 ff ff                         	prefetcht1 -0xce0(%r11)
  3440f8:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  344100:	41 0f 18 93 22 00 00 00                         	prefetcht1 0x22(%r11)
  344108:	41 5b                                           	pop    %r11
  34410a:	e9 01 c7 e9 ff                                  	jmp    1e0810 <_ZdlPv>
  34410f:	90                                              	nop
  344110:	41 53                                           	push   %r11
  344112:	4c 8b 1d 7f 70 ff ff                            	mov    -0x8f81(%rip),%r11        # 33b198 <memcmp@GLIBC_2.2.5>
  344119:	41 0f 18 93 00 00 00 00                         	prefetcht1 0x0(%r11)
  344121:	41 5b                                           	pop    %r11
  344123:	e9 38 b5 d4 ff                                  	jmp    8f660 <memcpy@plt>
  344128:	0f 1f 84 00 00 00 00 00                         	nopl   0x0(%rax,%rax,1)
  344130:	0f 18 3d d9 c6 e9 ff                            	prefetchit0 -0x163927(%rip)        # 1e0810 <_ZdlPv>
  344137:	e9 14 cc f1 ff                                  	jmp    260d50 <_ZNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE9_M_mutateEmmPKcm>
  34413c:	0f 1f 40 00                                     	nopl   0x0(%rax)
  344140:	0f 18 3d 39 80 d8 ff                            	prefetchit0 -0x277fc7(%rip)        # cc180 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE20readStructBegin_virtERNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEE>
  344147:	0f 18 3d 22 80 d8 ff                            	prefetchit0 -0x277fde(%rip)        # cc170 <_ZN6apache6thrift8protocol16TVirtualProtocolINS1_16TBinaryProtocolTINS0_9transport10TTransportENS1_17TNetworkBigEndianEEENS1_17TProtocolDefaultsEE19readMessageEnd_virtEv>
  34414e:	0f 18 3d 2c f1 f1 ff                            	prefetchit0 -0xe0ed4(%rip)        # 263281 <_ZNKSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEE7compareEPKc+0x51>
  344155:	e9 b6 b1 d4 ff                                  	jmp    8f310 <strlen@plt>
  34415a:	66 0f 1f 44 00 00                               	nopw   0x0(%rax,%rax,1)
  344160:	41 53                                           	push   %r11
  344162:	4c 8b 1d 07 72 ff ff                            	mov    -0x8df9(%rip),%r11        # 33b370 <pthread_join@GLIBC_2.34>
  344169:	41 0f 18 93 13 00 00 00                         	prefetcht1 0x13(%r11)
  344171:	41 5b                                           	pop    %r11
  344173:	e9 68 b5 d4 ff                                  	jmp    8f6e0 <pthread_join@plt>
