
/storage/prefetchit/class_b_temporal_20261001/builds/path512/7277229c6489da6761bfa3456517c6cf25e006a732d2a0dab69141658d47f872/call-stub-f2586x95/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000422c0 <pf_call_0>:
   422c0:	0f 18 15 7a 10 fd ff 	prefetcht1 -0x2ef86(%rip)        # 13341 <pf_target_0_0>
   422c7:	0f 18 15 42 10 fd ff 	prefetcht1 -0x2efbe(%rip)        # 13310 <pf_target_0_1>

00000000000422ce <pf_jump_0>:
   422ce:	e9 5d b4 fc ff       	jmp    d730 <pf_callee_0>
   422d3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   422da:	00 00 00 
   422dd:	0f 1f 00             	nopl   (%rax)

00000000000422e0 <pf_call_1>:
   422e0:	0f 18 15 39 01 fd ff 	prefetcht1 -0x2fec7(%rip)        # 12420 <pf_target_1_0>
   422e7:	0f 18 15 52 01 fd ff 	prefetcht1 -0x2feae(%rip)        # 12440 <pf_target_1_1>

00000000000422ee <pf_jump_1>:
   422ee:	e9 7d ac fc ff       	jmp    cf70 <pf_callee_1>
   422f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   422fa:	00 00 00 
   422fd:	0f 1f 00             	nopl   (%rax)

0000000000042300 <pf_call_2>:
   42300:	0f 18 15 e9 dc fc ff 	prefetcht1 -0x32317(%rip)        # fff0 <pf_target_2_0>
   42307:	0f 18 15 f7 dc fc ff 	prefetcht1 -0x32309(%rip)        # 10005 <pf_target_2_1>
   4230e:	0f 18 15 03 fd fc ff 	prefetcht1 -0x302fd(%rip)        # 12018 <pf_target_2_2>
   42315:	0f 18 15 a4 fa fc ff 	prefetcht1 -0x3055c(%rip)        # 11dc0 <pf_target_2_3>

000000000004231c <pf_jump_2>:
   4231c:	e9 af a8 fc ff       	jmp    cbd0 <pf_callee_2>
   42321:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   42328:	00 00 00 
   4232b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000042330 <pf_call_3>:
   42330:	0f 18 15 79 78 fd ff 	prefetcht1 -0x28787(%rip)        # 19bb0 <pf_callee_5>

0000000000042337 <pf_jump_3>:
   42337:	e9 64 af fc ff       	jmp    d2a0 <pf_callee_3>
   4233c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042340 <pf_call_4>:
   42340:	0f 18 15 49 42 fe ff 	prefetcht1 -0x1bdb7(%rip)        # 26590 <pf_target_4_0>
   42347:	0f 18 15 a2 9f fd ff 	prefetcht1 -0x2605e(%rip)        # 1c2f0 <pf_target_4_1>
   4234e:	0f 18 15 6e 42 fe ff 	prefetcht1 -0x1bd92(%rip)        # 265c3 <pf_target_4_2>
   42355:	0f 18 15 e4 aa fc ff 	prefetcht1 -0x3551c(%rip)        # ce40 <pf_callee_6>

000000000004235c <pf_jump_4>:
   4235c:	e9 3f af fc ff       	jmp    d2a0 <pf_callee_3>
   42361:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   42368:	00 00 00 
   4236b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000042370 <pf_call_5>:
   42370:	41 53                	push   %r11
   42372:	4c 8b 1d 0f 8e ff ff 	mov    -0x71f1(%rip),%r11        # 3b188 <pf_got_5_0>

0000000000042379 <pf_got_hint_5_0>:
   42379:	41 0f 18 93 80 fa ff 	prefetcht1 -0x580(%r11)
   42380:	ff 
   42381:	41 5b                	pop    %r11

0000000000042383 <pf_jump_5>:
   42383:	e9 28 78 fd ff       	jmp    19bb0 <pf_callee_5>
   42388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   4238f:	00 

0000000000042390 <pf_call_6>:
   42390:	41 53                	push   %r11
   42392:	4c 8b 1d f7 8c ff ff 	mov    -0x7309(%rip),%r11        # 3b090 <pf_got_6_0>

0000000000042399 <pf_got_hint_6_0>:
   42399:	41 0f 18 93 f5 fe ff 	prefetcht1 -0x10b(%r11)
   423a0:	ff 
   423a1:	4c 8b 1d f0 8c ff ff 	mov    -0x7310(%rip),%r11        # 3b098 <pf_got_6_1>

00000000000423a8 <pf_got_hint_6_1>:
   423a8:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   423af:	00 
   423b0:	41 5b                	pop    %r11

00000000000423b2 <pf_jump_6>:
   423b2:	e9 89 aa fc ff       	jmp    ce40 <pf_callee_6>
   423b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   423be:	00 00 

00000000000423c0 <pf_call_7>:
   423c0:	41 53                	push   %r11
   423c2:	4c 8b 1d c7 8c ff ff 	mov    -0x7339(%rip),%r11        # 3b090 <pf_got_6_0>

00000000000423c9 <pf_got_hint_7_0>:
   423c9:	41 0f 18 93 12 ff ff 	prefetcht1 -0xee(%r11)
   423d0:	ff 
   423d1:	41 5b                	pop    %r11

00000000000423d3 <pf_jump_7>:
   423d3:	e9 88 a7 fc ff       	jmp    cb60 <pf_callee_7>
   423d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   423df:	00 

00000000000423e0 <pf_call_8>:
   423e0:	0f 18 15 59 85 fd ff 	prefetcht1 -0x27aa7(%rip)        # 1a940 <pf_target_8_0>
   423e7:	0f 18 15 62 26 fd ff 	prefetcht1 -0x2d99e(%rip)        # 14a50 <pf_target_8_1>

00000000000423ee <pf_jump_8>:
   423ee:	e9 6d a8 fc ff       	jmp    cc60 <pf_callee_8>
   423f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   423fa:	00 00 00 
   423fd:	0f 1f 00             	nopl   (%rax)

0000000000042400 <pf_call_9>:
   42400:	0f 18 15 b9 7e fd ff 	prefetcht1 -0x28147(%rip)        # 1a2c0 <pf_target_9_0>

0000000000042407 <pf_jump_9>:
   42407:	e9 94 ae fc ff       	jmp    d2a0 <pf_callee_3>
   4240c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042410 <pf_call_10>:
   42410:	0f 18 15 39 ee fc ff 	prefetcht1 -0x311c7(%rip)        # 11250 <pf_target_10_0>

0000000000042417 <pf_jump_10>:
   42417:	e9 c4 a8 fc ff       	jmp    cce0 <pf_callee_10>
   4241c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042420 <pf_call_11>:
   42420:	0f 18 15 d9 e9 fc ff 	prefetcht1 -0x31627(%rip)        # 10e00 <pf_target_11_0>

0000000000042427 <pf_jump_11>:
   42427:	e9 54 b0 fc ff       	jmp    d480 <pf_callee_11>
   4242c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042430 <pf_call_12>:
   42430:	0f 18 15 8b 55 fd ff 	prefetcht1 -0x2aa75(%rip)        # 179c2 <pf_target_12_0>
   42437:	0f 18 15 d2 13 fd ff 	prefetcht1 -0x2ec2e(%rip)        # 13810 <pf_target_12_1>
   4243e:	41 53                	push   %r11
   42440:	4c 8b 1d e9 8c ff ff 	mov    -0x7317(%rip),%r11        # 3b130 <pf_got_12_0>

0000000000042447 <pf_got_hint_12_0>:
   42447:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   4244e:	00 
   4244f:	41 5b                	pop    %r11

0000000000042451 <pf_jump_12>:
   42451:	e9 ba ad fc ff       	jmp    d210 <pf_callee_12>
   42456:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4245d:	00 00 00 

0000000000042460 <pf_call_13>:
   42460:	0f 18 15 b9 41 fd ff 	prefetcht1 -0x2be47(%rip)        # 16620 <pf_target_13_0>

0000000000042467 <pf_jump_13>:
   42467:	e9 64 b1 fc ff       	jmp    d5d0 <pf_callee_13>
   4246c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042470 <pf_call_14>:
   42470:	0f 18 15 89 80 fd ff 	prefetcht1 -0x27f77(%rip)        # 1a500 <pf_target_14_0>
   42477:	0f 18 15 92 7e fd ff 	prefetcht1 -0x2816e(%rip)        # 1a310 <pf_target_14_1>
   4247e:	0f 18 15 4b 2c fd ff 	prefetcht1 -0x2d3b5(%rip)        # 150d0 <pf_target_14_2>
   42485:	0f 18 15 d4 7f fd ff 	prefetcht1 -0x2802c(%rip)        # 1a460 <pf_target_14_3>

000000000004248c <pf_jump_14>:
   4248c:	e9 bf a7 fc ff       	jmp    cc50 <pf_callee_14>
   42491:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   42498:	00 00 00 
   4249b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000424a0 <pf_call_15>:
   424a0:	41 53                	push   %r11
   424a2:	4c 8b 1d 9f 90 ff ff 	mov    -0x6f61(%rip),%r11        # 3b548 <pf_got_15_0>

00000000000424a9 <pf_got_hint_15_0>:
   424a9:	41 0f 18 93 60 3c ff 	prefetcht1 -0xc3a0(%r11)
   424b0:	ff 

00000000000424b1 <pf_got_hint_15_1>:
   424b1:	41 0f 18 93 20 46 ff 	prefetcht1 -0xb9e0(%r11)
   424b8:	ff 

00000000000424b9 <pf_got_hint_15_2>:
   424b9:	41 0f 18 93 f0 59 ff 	prefetcht1 -0xa610(%r11)
   424c0:	ff 

00000000000424c1 <pf_got_hint_15_3>:
   424c1:	41 0f 18 93 00 5a ff 	prefetcht1 -0xa600(%r11)
   424c8:	ff 
   424c9:	41 5b                	pop    %r11

00000000000424cb <pf_jump_15>:
   424cb:	e9 b0 ae fc ff       	jmp    d380 <pf_callee_15>

00000000000424d0 <pf_call_16>:
   424d0:	41 53                	push   %r11
   424d2:	4c 8b 1d 6f 90 ff ff 	mov    -0x6f91(%rip),%r11        # 3b548 <pf_got_15_0>

00000000000424d9 <pf_got_hint_16_0>:
   424d9:	41 0f 18 93 c0 b0 fd 	prefetcht1 -0x24f40(%r11)
   424e0:	ff 

00000000000424e1 <pf_got_hint_16_1>:
   424e1:	41 0f 18 93 60 bf fd 	prefetcht1 -0x240a0(%r11)
   424e8:	ff 

00000000000424e9 <pf_got_hint_16_2>:
   424e9:	41 0f 18 93 e8 ca fd 	prefetcht1 -0x23518(%r11)
   424f0:	ff 

00000000000424f1 <pf_got_hint_16_3>:
   424f1:	41 0f 18 93 f7 cd fd 	prefetcht1 -0x23209(%r11)
   424f8:	ff 
   424f9:	41 5b                	pop    %r11

00000000000424fb <pf_jump_16>:
   424fb:	e9 20 ae fc ff       	jmp    d320 <pf_callee_16>

0000000000042500 <pf_call_17>:
   42500:	41 53                	push   %r11
   42502:	4c 8b 1d 3f 90 ff ff 	mov    -0x6fc1(%rip),%r11        # 3b548 <pf_got_15_0>

0000000000042509 <pf_got_hint_17_0>:
   42509:	41 0f 18 93 c0 b0 fd 	prefetcht1 -0x24f40(%r11)
   42510:	ff 

0000000000042511 <pf_got_hint_17_1>:
   42511:	41 0f 18 93 20 46 ff 	prefetcht1 -0xb9e0(%r11)
   42518:	ff 

0000000000042519 <pf_got_hint_17_2>:
   42519:	41 0f 18 93 42 46 ff 	prefetcht1 -0xb9be(%r11)
   42520:	ff 

0000000000042521 <pf_got_hint_17_3>:
   42521:	41 0f 18 93 00 5a ff 	prefetcht1 -0xa600(%r11)
   42528:	ff 
   42529:	41 5b                	pop    %r11

000000000004252b <pf_jump_17>:
   4252b:	e9 f0 ad fc ff       	jmp    d320 <pf_callee_16>
