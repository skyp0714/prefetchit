.text
.balign 16
.global pf_call_0
.type pf_call_0,@function
pf_call_0:
.cfi_startproc
prefetcht1 pf_target_0_0(%rip)
prefetcht1 pf_target_0_1(%rip)
.global pf_jump_0
pf_jump_0:
jmp pf_callee_0
.cfi_endproc
.size pf_call_0,.-pf_call_0
.balign 16
.global pf_call_1
.type pf_call_1,@function
pf_call_1:
.cfi_startproc
prefetcht1 pf_target_1_0(%rip)
prefetcht1 pf_target_1_1(%rip)
.global pf_jump_1
pf_jump_1:
jmp pf_callee_1
.cfi_endproc
.size pf_call_1,.-pf_call_1
.balign 16
.global pf_call_2
.type pf_call_2,@function
pf_call_2:
.cfi_startproc
prefetcht1 pf_target_2_0(%rip)
prefetcht1 pf_target_2_1(%rip)
prefetcht1 pf_target_2_2(%rip)
prefetcht1 pf_target_2_3(%rip)
.global pf_jump_2
pf_jump_2:
jmp pf_callee_2
.cfi_endproc
.size pf_call_2,.-pf_call_2
.balign 16
.global pf_call_3
.type pf_call_3,@function
pf_call_3:
.cfi_startproc
prefetcht1 pf_target_3_0(%rip)
.global pf_jump_3
pf_jump_3:
jmp pf_callee_3
.cfi_endproc
.size pf_call_3,.-pf_call_3
.balign 16
.global pf_call_4
.type pf_call_4,@function
pf_call_4:
.cfi_startproc
prefetcht1 pf_target_4_0(%rip)
prefetcht1 pf_target_4_1(%rip)
prefetcht1 pf_target_4_2(%rip)
prefetcht1 pf_target_4_3(%rip)
.global pf_jump_4
pf_jump_4:
jmp pf_callee_4
.cfi_endproc
.size pf_call_4,.-pf_call_4
.balign 16
.global pf_call_5
.type pf_call_5,@function
pf_call_5:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_5_0(%rip),%r11
.global pf_got_hint_5_0
pf_got_hint_5_0:
.byte 0x41,0x0f,0x18,0x93
.long -1408
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_5
pf_jump_5:
jmp pf_callee_5
.cfi_endproc
.size pf_call_5,.-pf_call_5
.balign 16
.global pf_call_6
.type pf_call_6,@function
pf_call_6:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_6_0(%rip),%r11
.global pf_got_hint_6_0
pf_got_hint_6_0:
.byte 0x41,0x0f,0x18,0x93
.long -267
mov pf_got_6_1(%rip),%r11
.global pf_got_hint_6_1
pf_got_hint_6_1:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_6
pf_jump_6:
jmp pf_callee_6
.cfi_endproc
.size pf_call_6,.-pf_call_6
.balign 16
.global pf_call_7
.type pf_call_7,@function
pf_call_7:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_7_0(%rip),%r11
.global pf_got_hint_7_0
pf_got_hint_7_0:
.byte 0x41,0x0f,0x18,0x93
.long -238
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_7
pf_jump_7:
jmp pf_callee_7
.cfi_endproc
.size pf_call_7,.-pf_call_7
.balign 16
.global pf_call_8
.type pf_call_8,@function
pf_call_8:
.cfi_startproc
prefetcht1 pf_target_8_0(%rip)
prefetcht1 pf_target_8_1(%rip)
.global pf_jump_8
pf_jump_8:
jmp pf_callee_8
.cfi_endproc
.size pf_call_8,.-pf_call_8
.balign 16
.global pf_call_9
.type pf_call_9,@function
pf_call_9:
.cfi_startproc
prefetcht1 pf_target_9_0(%rip)
.global pf_jump_9
pf_jump_9:
jmp pf_callee_9
.cfi_endproc
.size pf_call_9,.-pf_call_9
.balign 16
.global pf_call_10
.type pf_call_10,@function
pf_call_10:
.cfi_startproc
prefetcht1 pf_target_10_0(%rip)
.global pf_jump_10
pf_jump_10:
jmp pf_callee_10
.cfi_endproc
.size pf_call_10,.-pf_call_10
.balign 16
.global pf_call_11
.type pf_call_11,@function
pf_call_11:
.cfi_startproc
prefetcht1 pf_target_11_0(%rip)
.global pf_jump_11
pf_jump_11:
jmp pf_callee_11
.cfi_endproc
.size pf_call_11,.-pf_call_11
.balign 16
.global pf_call_12
.type pf_call_12,@function
pf_call_12:
.cfi_startproc
prefetcht1 pf_target_12_0(%rip)
prefetcht1 pf_target_12_1(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_12_0(%rip),%r11
.global pf_got_hint_12_0
pf_got_hint_12_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_12
pf_jump_12:
jmp pf_callee_12
.cfi_endproc
.size pf_call_12,.-pf_call_12
.balign 16
.global pf_call_13
.type pf_call_13,@function
pf_call_13:
.cfi_startproc
prefetcht1 pf_target_13_0(%rip)
.global pf_jump_13
pf_jump_13:
jmp pf_callee_13
.cfi_endproc
.size pf_call_13,.-pf_call_13
.balign 16
.global pf_call_14
.type pf_call_14,@function
pf_call_14:
.cfi_startproc
prefetcht1 pf_target_14_0(%rip)
prefetcht1 pf_target_14_1(%rip)
prefetcht1 pf_target_14_2(%rip)
prefetcht1 pf_target_14_3(%rip)
.global pf_jump_14
pf_jump_14:
jmp pf_callee_14
.cfi_endproc
.size pf_call_14,.-pf_call_14
.balign 16
.global pf_call_15
.type pf_call_15,@function
pf_call_15:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_15_0(%rip),%r11
.global pf_got_hint_15_0
pf_got_hint_15_0:
.byte 0x41,0x0f,0x18,0x93
.long -50080
.global pf_got_hint_15_1
pf_got_hint_15_1:
.byte 0x41,0x0f,0x18,0x93
.long -47584
.global pf_got_hint_15_2
pf_got_hint_15_2:
.byte 0x41,0x0f,0x18,0x93
.long -42512
.global pf_got_hint_15_3
pf_got_hint_15_3:
.byte 0x41,0x0f,0x18,0x93
.long -42496
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_15
pf_jump_15:
jmp pf_callee_15
.cfi_endproc
.size pf_call_15,.-pf_call_15
.balign 16
.global pf_call_16
.type pf_call_16,@function
pf_call_16:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_16_0(%rip),%r11
.global pf_got_hint_16_0
pf_got_hint_16_0:
.byte 0x41,0x0f,0x18,0x93
.long -151360
.global pf_got_hint_16_1
pf_got_hint_16_1:
.byte 0x41,0x0f,0x18,0x93
.long -147616
.global pf_got_hint_16_2
pf_got_hint_16_2:
.byte 0x41,0x0f,0x18,0x93
.long -144664
.global pf_got_hint_16_3
pf_got_hint_16_3:
.byte 0x41,0x0f,0x18,0x93
.long -143881
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_16
pf_jump_16:
jmp pf_callee_16
.cfi_endproc
.size pf_call_16,.-pf_call_16
.balign 16
.global pf_call_17
.type pf_call_17,@function
pf_call_17:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_17_0(%rip),%r11
.global pf_got_hint_17_0
pf_got_hint_17_0:
.byte 0x41,0x0f,0x18,0x93
.long -151360
.global pf_got_hint_17_1
pf_got_hint_17_1:
.byte 0x41,0x0f,0x18,0x93
.long -47584
.global pf_got_hint_17_2
pf_got_hint_17_2:
.byte 0x41,0x0f,0x18,0x93
.long -47550
.global pf_got_hint_17_3
pf_got_hint_17_3:
.byte 0x41,0x0f,0x18,0x93
.long -42496
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_17
pf_jump_17:
jmp pf_callee_17
.cfi_endproc
.size pf_call_17,.-pf_call_17
.section .note.GNU-stack,"",@progbits
