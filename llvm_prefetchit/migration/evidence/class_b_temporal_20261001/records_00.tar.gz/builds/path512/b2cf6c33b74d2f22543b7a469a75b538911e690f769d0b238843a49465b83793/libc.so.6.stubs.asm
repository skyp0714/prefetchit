
/storage/prefetchit/class_b_temporal_20261001/builds/path512/b2cf6c33b74d2f22543b7a469a75b538911e690f769d0b238843a49465b83793/call-stub-cq489pyo/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000229380 <pf_call_0>:
  229380:	0f 18 15 7a e1 e4 ff 	prefetcht1 -0x1b1e86(%rip)        # 77501 <pf_target_0_0>

0000000000229387 <pf_jump_0>:
  229387:	e9 a4 0e e3 ff       	jmp    5a230 <pf_callee_0>
  22938c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229390 <pf_call_1>:
  229390:	0f 18 15 a9 82 f8 ff 	prefetcht1 -0x77d57(%rip)        # 1b1640 <pf_target_1_0>
  229397:	0f 18 15 62 bc e4 ff 	prefetcht1 -0x1b439e(%rip)        # 75000 <pf_target_1_1>
  22939e:	0f 18 15 4b bc e4 ff 	prefetcht1 -0x1b43b5(%rip)        # 74ff0 <pf_callee_3>
  2293a5:	0f 18 15 34 48 e6 ff 	prefetcht1 -0x19b7cc(%rip)        # 8dbe0 <pf_callee_5>

00000000002293ac <pf_jump_1>:
  2293ac:	e9 5f 52 e6 ff       	jmp    8e610 <pf_callee_1>
  2293b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2293b8:	00 00 00 
  2293bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000002293c0 <pf_call_2>:
  2293c0:	0f 18 15 99 4b e6 ff 	prefetcht1 -0x19b467(%rip)        # 8df60 <pf_target_2_0>
  2293c7:	0f 18 15 b2 d9 e4 ff 	prefetcht1 -0x1b264e(%rip)        # 76d80 <pf_target_2_1>
  2293ce:	0f 18 15 55 c6 e4 ff 	prefetcht1 -0x1b39ab(%rip)        # 75a2a <pf_target_2_2>

00000000002293d5 <pf_jump_2>:
  2293d5:	e9 96 65 e6 ff       	jmp    8f970 <pf_callee_2>
  2293da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000002293e0 <pf_call_3>:
  2293e0:	0f 18 15 02 d9 e4 ff 	prefetcht1 -0x1b26fe(%rip)        # 76ce9 <pf_target_3_0>
  2293e7:	0f 18 15 95 d1 e4 ff 	prefetcht1 -0x1b2e6b(%rip)        # 76583 <pf_target_3_1>
  2293ee:	0f 18 15 8b 49 e6 ff 	prefetcht1 -0x19b675(%rip)        # 8dd80 <pf_target_3_2>
  2293f5:	0f 18 15 a4 db e4 ff 	prefetcht1 -0x1b245c(%rip)        # 76fa0 <pf_target_3_3>

00000000002293fc <pf_jump_3>:
  2293fc:	e9 ef bb e4 ff       	jmp    74ff0 <pf_callee_3>
  229401:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229408:	00 00 00 
  22940b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229410 <pf_call_4>:
  229410:	0f 18 15 6a 82 f8 ff 	prefetcht1 -0x77d96(%rip)        # 1b1681 <pf_target_4_0>
  229417:	0f 18 15 32 cc e4 ff 	prefetcht1 -0x1b33ce(%rip)        # 76050 <pf_target_4_1>
  22941e:	0f 18 15 ab c2 e4 ff 	prefetcht1 -0x1b3d55(%rip)        # 756d0 <pf_target_4_2>
  229425:	0f 18 15 04 0e e3 ff 	prefetcht1 -0x1cf1fc(%rip)        # 5a230 <pf_callee_0>

000000000022942c <pf_jump_4>:
  22942c:	e9 6f 51 e6 ff       	jmp    8e5a0 <pf_callee_4>
  229431:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229438:	00 00 00 
  22943b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229440 <pf_call_5>:
  229440:	0f 18 15 bb db e4 ff 	prefetcht1 -0x1b2445(%rip)        # 77002 <pf_target_5_0>
  229447:	0f 18 15 aa db e4 ff 	prefetcht1 -0x1b2456(%rip)        # 76ff8 <pf_target_5_1>
  22944e:	0f 18 15 eb 0d e3 ff 	prefetcht1 -0x1cf215(%rip)        # 5a240 <pf_target_5_2>
  229455:	0f 18 15 01 d1 e4 ff 	prefetcht1 -0x1b2eff(%rip)        # 7655d <pf_target_5_3>

000000000022945c <pf_jump_5>:
  22945c:	e9 7f 47 e6 ff       	jmp    8dbe0 <pf_callee_5>
  229461:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229468:	00 00 00 
  22946b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229470 <pf_call_6>:
  229470:	0f 18 15 04 ad e6 ff 	prefetcht1 -0x1952fc(%rip)        # 9417b <pf_target_6_0>
  229477:	0f 18 15 b9 d0 e6 ff 	prefetcht1 -0x192f47(%rip)        # 96537 <pf_target_6_1>

000000000022947e <pf_jump_6>:
  22947e:	e9 9d 75 e6 ff       	jmp    90a20 <pf_callee_17>
  229483:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22948a:	00 00 00 
  22948d:	0f 1f 00             	nopl   (%rax)

0000000000229490 <pf_call_7>:
  229490:	0f 18 15 49 74 e6 ff 	prefetcht1 -0x198bb7(%rip)        # 908e0 <pf_target_7_0>
  229497:	0f 18 15 32 89 f2 ff 	prefetcht1 -0xd76ce(%rip)        # 151dd0 <pf_target_7_1>
  22949e:	0f 18 15 db 06 f2 ff 	prefetcht1 -0xdf925(%rip)        # 149b80 <pf_target_7_2>
  2294a5:	0f 18 15 c4 ee df ff 	prefetcht1 -0x20113c(%rip)        # 28370 <pf_target_7_3>

00000000002294ac <pf_jump_7>:
  2294ac:	e9 af c8 e1 ff       	jmp    45d60 <pf_callee_7>
  2294b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2294b8:	00 00 00 
  2294bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000002294c0 <pf_call_8>:
  2294c0:	0f 18 15 b9 c1 e6 ff 	prefetcht1 -0x193e47(%rip)        # 95680 <pf_target_8_0>

00000000002294c7 <pf_jump_8>:
  2294c7:	e9 64 c8 e6 ff       	jmp    95d30 <pf_callee_8>
  2294cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002294d0 <pf_call_9>:
  2294d0:	0f 18 15 19 7b e6 ff 	prefetcht1 -0x1984e7(%rip)        # 90ff0 <pf_target_15_3>

00000000002294d7 <pf_jump_9>:
  2294d7:	e9 04 7e e6 ff       	jmp    912e0 <pf_callee_9>
  2294dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002294e0 <pf_call_10>:
  2294e0:	0f 18 15 9c cf e6 ff 	prefetcht1 -0x193064(%rip)        # 96483 <pf_target_10_0>

00000000002294e7 <pf_jump_10>:
  2294e7:	e9 a4 75 e6 ff       	jmp    90a90 <pf_callee_10>
  2294ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002294f0 <pf_call_11>:
  2294f0:	0f 18 15 69 c8 e1 ff 	prefetcht1 -0x1e3797(%rip)        # 45d60 <pf_callee_7>
  2294f7:	0f 18 15 84 7b e7 ff 	prefetcht1 -0x18847c(%rip)        # a1082 <pf_target_11_1>
  2294fe:	0f 18 15 bb 80 e6 ff 	prefetcht1 -0x197f45(%rip)        # 915c0 <pf_target_11_2>
  229505:	0f 18 15 a4 80 e6 ff 	prefetcht1 -0x197f5c(%rip)        # 915b0 <pf_target_11_3>

000000000022950c <pf_jump_11>:
  22950c:	e9 af 75 e6 ff       	jmp    90ac0 <pf_callee_11>
  229511:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229518:	00 00 00 
  22951b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229520 <pf_call_12>:
  229520:	0f 18 15 e9 50 e6 ff 	prefetcht1 -0x19af17(%rip)        # 8e610 <pf_callee_1>

0000000000229527 <pf_jump_12>:
  229527:	e9 a4 81 e7 ff       	jmp    a16d0 <pf_callee_12>
  22952c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229530 <pf_call_13>:
  229530:	0f 18 15 79 f3 f3 ff 	prefetcht1 -0xc0c87(%rip)        # 1688b0 <pf_target_13_0>
  229537:	0f 18 15 83 f3 f3 ff 	prefetcht1 -0xc0c7d(%rip)        # 1688c1 <pf_target_13_1>
  22953e:	0f 18 15 fb eb e7 ff 	prefetcht1 -0x181405(%rip)        # a8140 <pf_target_13_2>

0000000000229545 <pf_jump_13>:
  229545:	e9 26 a4 e7 ff       	jmp    a3970 <pf_callee_13>
  22954a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229550 <pf_call_14>:
  229550:	0f 18 15 09 c8 e1 ff 	prefetcht1 -0x1e37f7(%rip)        # 45d60 <pf_callee_7>
  229557:	0f 18 15 25 b5 e6 ff 	prefetcht1 -0x194adb(%rip)        # 94a83 <pf_target_14_1>

000000000022955e <pf_jump_14>:
  22955e:	e9 ed 7a e7 ff       	jmp    a1050 <pf_callee_14>
  229563:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22956a:	00 00 00 
  22956d:	0f 1f 00             	nopl   (%rax)

0000000000229570 <pf_call_15>:
  229570:	0f 18 15 99 03 e7 ff 	prefetcht1 -0x18fc67(%rip)        # 99910 <pf_target_15_0>
  229577:	0f 18 15 72 a2 e6 ff 	prefetcht1 -0x195d8e(%rip)        # 937f0 <pf_target_15_1>
  22957e:	0f 18 15 2b f3 f3 ff 	prefetcht1 -0xc0cd5(%rip)        # 1688b0 <pf_target_13_0>
  229585:	0f 18 15 64 7a e6 ff 	prefetcht1 -0x19859c(%rip)        # 90ff0 <pf_target_15_3>

000000000022958c <pf_jump_15>:
  22958c:	e9 cf 90 e7 ff       	jmp    a2660 <pf_callee_15>
  229591:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229598:	00 00 00 
  22959b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000002295a0 <pf_call_16>:
  2295a0:	0f 18 15 19 57 ef ff 	prefetcht1 -0x10a8e7(%rip)        # 11ecc0 <pf_target_16_0>

00000000002295a7 <pf_jump_16>:
  2295a7:	e9 f4 bd e7 ff       	jmp    a53a0 <pf_callee_16>
  2295ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002295b0 <pf_call_17>:
  2295b0:	0f 18 15 99 cf f0 ff 	prefetcht1 -0xf3067(%rip)        # 136550 <pf_target_17_0>
  2295b7:	0f 18 15 62 b3 ee ff 	prefetcht1 -0x114c9e(%rip)        # 114920 <pf_target_17_1>

00000000002295be <pf_jump_17>:
  2295be:	e9 5d 74 e6 ff       	jmp    90a20 <pf_callee_17>
  2295c3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2295ca:	00 00 00 
  2295cd:	0f 1f 00             	nopl   (%rax)

00000000002295d0 <pf_call_18>:
  2295d0:	0f 18 15 f9 d5 f7 ff 	prefetcht1 -0x82a07(%rip)        # 1a6bd0 <pf_target_18_0>

00000000002295d7 <pf_jump_18>:
  2295d7:	e9 d4 73 e6 ff       	jmp    909b0 <pf_callee_18>
