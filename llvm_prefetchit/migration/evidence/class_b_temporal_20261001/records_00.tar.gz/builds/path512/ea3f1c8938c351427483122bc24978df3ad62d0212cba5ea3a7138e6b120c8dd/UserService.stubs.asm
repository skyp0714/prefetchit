
/storage/prefetchit/class_b_temporal_20261001/builds/path512/ea3f1c8938c351427483122bc24978df3ad62d0212cba5ea3a7138e6b120c8dd/call-stub-4b7d6513/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000013f340 <pf_call_0>:
  13f340:	0f 18 15 bc 68 f1 ff 	prefetcht1 -0xe9744(%rip)        # 55c03 <pf_target_0_0>
  13f347:	0f 18 15 a2 72 f1 ff 	prefetcht1 -0xe8d5e(%rip)        # 565f0 <pf_target_0_1>
  13f34e:	0f 18 15 2b 68 f1 ff 	prefetcht1 -0xe97d5(%rip)        # 55b80 <pf_target_0_2>
  13f355:	0f 18 15 a6 bf f1 ff 	prefetcht1 -0xe405a(%rip)        # 5b302 <pf_target_0_3>

000000000013f35c <pf_jump_0>:
  13f35c:	e9 ef a0 ee ff       	jmp    29450 <pf_callee_0>
  13f361:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f368:	00 00 00 
  13f36b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000013f370 <pf_call_1>:
  13f370:	41 53                	push   %r11
  13f372:	4c 8b 1d bf dd ff ff 	mov    -0x2241(%rip),%r11        # 13d138 <pf_got_1_0>

000000000013f379 <pf_got_hint_1_0>:
  13f379:	41 0f 18 93 b0 06 00 	prefetcht1 0x6b0(%r11)
  13f380:	00 

000000000013f381 <pf_got_hint_1_1>:
  13f381:	41 0f 18 93 d2 06 00 	prefetcht1 0x6d2(%r11)
  13f388:	00 
  13f389:	41 5b                	pop    %r11

000000000013f38b <pf_jump_1>:
  13f38b:	e9 c0 a0 ee ff       	jmp    29450 <pf_callee_0>

000000000013f390 <pf_call_2>:
  13f390:	0f 18 15 99 3f f7 ff 	prefetcht1 -0x8c067(%rip)        # b3330 <pf_callee_25>
  13f397:	0f 18 15 f2 ad f7 ff 	prefetcht1 -0x8520e(%rip)        # ba190 <pf_callee_26>
  13f39e:	0f 18 15 1b 07 f7 ff 	prefetcht1 -0x8f8e5(%rip)        # afac0 <pf_target_2_2>
  13f3a5:	0f 18 15 44 b0 ee ff 	prefetcht1 -0x114fbc(%rip)        # 2a3f0 <pf_target_2_3>

000000000013f3ac <pf_jump_2>:
  13f3ac:	e9 5f cb f1 ff       	jmp    5bf10 <pf_callee_2>
  13f3b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f3b8:	00 00 00 
  13f3bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000013f3c0 <pf_call_3>:
  13f3c0:	0f 18 15 59 87 fa ff 	prefetcht1 -0x578a7(%rip)        # e7b20 <pf_target_3_0>
  13f3c7:	0f 18 15 32 31 fb ff 	prefetcht1 -0x4cece(%rip)        # f2500 <pf_target_3_1>
  13f3ce:	0f 18 15 6b 8c fa ff 	prefetcht1 -0x57395(%rip)        # e8040 <pf_target_3_2>
  13f3d5:	0f 18 15 e9 ad f7 ff 	prefetcht1 -0x85217(%rip)        # ba1c5 <pf_target_3_3>

000000000013f3dc <pf_jump_3>:
  13f3dc:	e9 8f 9c ee ff       	jmp    29070 <pf_callee_3>
  13f3e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f3e8:	00 00 00 
  13f3eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000013f3f0 <pf_call_4>:
  13f3f0:	0f 18 15 d9 9d f6 ff 	prefetcht1 -0x96227(%rip)        # a91d0 <pf_target_4_0>
  13f3f7:	0f 18 15 42 3f f7 ff 	prefetcht1 -0x8c0be(%rip)        # b3340 <pf_target_4_1>

000000000013f3fe <pf_jump_4>:
  13f3fe:	e9 cd d9 f8 ff       	jmp    ccdd0 <pf_callee_4>
  13f403:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f40a:	00 00 00 
  13f40d:	0f 1f 00             	nopl   (%rax)

000000000013f410 <pf_call_5>:
  13f410:	41 53                	push   %r11
  13f412:	4c 8b 1d 67 e3 ff ff 	mov    -0x1c99(%rip),%r11        # 13d780 <pf_got_5_0>

000000000013f419 <pf_got_hint_5_0>:
  13f419:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  13f420:	00 

000000000013f421 <pf_got_hint_5_1>:
  13f421:	41 0f 18 93 50 05 00 	prefetcht1 0x550(%r11)
  13f428:	00 
  13f429:	41 5b                	pop    %r11

000000000013f42b <pf_jump_5>:
  13f42b:	e9 60 a2 ee ff       	jmp    29690 <pf_callee_5>

000000000013f430 <pf_call_6>:
  13f430:	0f 18 15 16 61 f4 ff 	prefetcht1 -0xb9eea(%rip)        # 8554d <pf_target_6_0>

000000000013f437 <pf_jump_6>:
  13f437:	e9 a4 cb f1 ff       	jmp    5bfe0 <pf_callee_6>
  13f43c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f440 <pf_call_7>:
  13f440:	0f 18 15 09 74 f3 ff 	prefetcht1 -0xc8bf7(%rip)        # 76850 <pf_target_7_0>

000000000013f447 <pf_jump_7>:
  13f447:	e9 f4 9f ee ff       	jmp    29440 <pf_callee_7>
  13f44c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f450 <pf_call_8>:
  13f450:	41 53                	push   %r11
  13f452:	4c 8b 1d e7 e4 ff ff 	mov    -0x1b19(%rip),%r11        # 13d940 <pf_got_12_1>

000000000013f459 <pf_got_hint_8_0>:
  13f459:	41 0f 18 93 31 26 ff 	prefetcht1 -0xd9cf(%r11)
  13f460:	ff 

000000000013f461 <pf_got_hint_8_1>:
  13f461:	41 0f 18 93 10 29 ff 	prefetcht1 -0xd6f0(%r11)
  13f468:	ff 
  13f469:	41 5b                	pop    %r11

000000000013f46b <pf_jump_8>:
  13f46b:	e9 30 89 f1 ff       	jmp    57da0 <pf_callee_8>

000000000013f470 <pf_call_9>:
  13f470:	0f 18 15 49 a3 ee ff 	prefetcht1 -0x115cb7(%rip)        # 297c0 <pf_target_9_0>

000000000013f477 <pf_jump_9>:
  13f477:	e9 f4 9c ee ff       	jmp    29170 <pf_callee_11>
  13f47c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f480 <pf_call_10>:
  13f480:	0f 18 15 fc 6d f1 ff 	prefetcht1 -0xe9204(%rip)        # 56283 <pf_target_10_0>

000000000013f487 <pf_jump_10>:
  13f487:	e9 14 72 f1 ff       	jmp    566a0 <pf_callee_10>
  13f48c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f490 <pf_call_11>:
  13f490:	0f 18 15 49 6d f1 ff 	prefetcht1 -0xe92b7(%rip)        # 561e0 <pf_target_11_0>
  13f497:	0f 18 15 65 6d f1 ff 	prefetcht1 -0xe929b(%rip)        # 56203 <pf_target_11_1>

000000000013f49e <pf_jump_11>:
  13f49e:	e9 cd 9c ee ff       	jmp    29170 <pf_callee_11>
  13f4a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f4aa:	00 00 00 
  13f4ad:	0f 1f 00             	nopl   (%rax)

000000000013f4b0 <pf_call_12>:
  13f4b0:	41 53                	push   %r11
  13f4b2:	4c 8b 1d 0f e1 ff ff 	mov    -0x1ef1(%rip),%r11        # 13d5c8 <pf_got_12_0>

000000000013f4b9 <pf_got_hint_12_0>:
  13f4b9:	41 0f 18 93 c0 16 00 	prefetcht1 0x16c0(%r11)
  13f4c0:	00 
  13f4c1:	4c 8b 1d 78 e4 ff ff 	mov    -0x1b88(%rip),%r11        # 13d940 <pf_got_12_1>

000000000013f4c8 <pf_got_hint_12_1>:
  13f4c8:	41 0f 18 93 b0 3e fe 	prefetcht1 -0x1c150(%r11)
  13f4cf:	ff 
  13f4d0:	41 5b                	pop    %r11

000000000013f4d2 <pf_jump_12>:
  13f4d2:	e9 b9 a6 ee ff       	jmp    29b90 <pf_callee_12>
  13f4d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  13f4de:	00 00 

000000000013f4e0 <pf_call_13>:
  13f4e0:	0f 18 15 09 7c f1 ff 	prefetcht1 -0xe83f7(%rip)        # 570f0 <pf_target_13_0>
  13f4e7:	0f 18 15 a2 a2 ee ff 	prefetcht1 -0x115d5e(%rip)        # 29790 <pf_target_13_1>
  13f4ee:	0f 18 15 10 7c f1 ff 	prefetcht1 -0xe83f0(%rip)        # 57105 <pf_target_13_2>

000000000013f4f5 <pf_jump_13>:
  13f4f5:	e9 26 81 f1 ff       	jmp    57620 <pf_callee_13>
  13f4fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000013f500 <pf_call_14>:
  13f500:	0f 18 15 79 86 f1 ff 	prefetcht1 -0xe7987(%rip)        # 57b80 <pf_target_14_0>

000000000013f507 <pf_jump_14>:
  13f507:	e9 e4 ab ee ff       	jmp    2a0f0 <pf_callee_14>
  13f50c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f510 <pf_call_15>:
  13f510:	0f 18 15 50 a0 f4 ff 	prefetcht1 -0xb5fb0(%rip)        # 89567 <pf_target_15_0>

000000000013f517 <pf_jump_15>:
  13f517:	e9 c4 9c ee ff       	jmp    291e0 <pf_callee_15>
  13f51c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f520 <pf_call_16>:
  13f520:	0f 18 15 59 43 f2 ff 	prefetcht1 -0xdbca7(%rip)        # 63880 <pf_target_16_0>
  13f527:	0f 18 15 c2 de f8 ff 	prefetcht1 -0x7213e(%rip)        # cd3f0 <pf_target_16_1>
  13f52e:	0f 18 15 2b 43 f2 ff 	prefetcht1 -0xdbcd5(%rip)        # 63860 <pf_target_16_2>

000000000013f535 <pf_jump_16>:
  13f535:	e9 f6 7d f2 ff       	jmp    67330 <pf_callee_16>
  13f53a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000013f540 <pf_call_17>:
  13f540:	0f 18 15 89 ab ee ff 	prefetcht1 -0x115477(%rip)        # 2a0d0 <pf_callee_23>
  13f547:	41 53                	push   %r11
  13f549:	4c 8b 1d a0 db ff ff 	mov    -0x2460(%rip),%r11        # 13d0f0 <pf_got_17_0>

000000000013f550 <pf_got_hint_17_0>:
  13f550:	41 0f 18 93 b0 53 ff 	prefetcht1 -0xac50(%r11)
  13f557:	ff 
  13f558:	41 5b                	pop    %r11

000000000013f55a <pf_jump_17>:
  13f55a:	e9 21 a3 ee ff       	jmp    29880 <pf_callee_17>
  13f55f:	90                   	nop

000000000013f560 <pf_call_18>:
  13f560:	0f 18 15 79 ae ee ff 	prefetcht1 -0x115187(%rip)        # 2a3e0 <pf_target_18_0>
  13f567:	0f 18 15 72 c3 f1 ff 	prefetcht1 -0xe3c8e(%rip)        # 5b8e0 <pf_target_18_1>

000000000013f56e <pf_jump_18>:
  13f56e:	e9 bd a7 f4 ff       	jmp    89d30 <pf_callee_18>
  13f573:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f57a:	00 00 00 
  13f57d:	0f 1f 00             	nopl   (%rax)

000000000013f580 <pf_call_19>:
  13f580:	0f 18 15 39 fb f3 ff 	prefetcht1 -0xc04c7(%rip)        # 7f0c0 <pf_callee_21>
  13f587:	0f 18 15 12 5d f4 ff 	prefetcht1 -0xba2ee(%rip)        # 852a0 <pf_target_19_1>

000000000013f58e <pf_jump_19>:
  13f58e:	e9 bd ae ee ff       	jmp    2a450 <pf_callee_19>
  13f593:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f59a:	00 00 00 
  13f59d:	0f 1f 00             	nopl   (%rax)

000000000013f5a0 <pf_call_20>:
  13f5a0:	0f 18 15 49 7a f3 ff 	prefetcht1 -0xc85b7(%rip)        # 76ff0 <pf_target_20_0>
  13f5a7:	0f 18 15 53 7a f3 ff 	prefetcht1 -0xc85ad(%rip)        # 77001 <pf_target_20_1>

000000000013f5ae <pf_jump_20>:
  13f5ae:	e9 9d ae ee ff       	jmp    2a450 <pf_callee_19>
  13f5b3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f5ba:	00 00 00 
  13f5bd:	0f 1f 00             	nopl   (%rax)

000000000013f5c0 <pf_call_21>:
  13f5c0:	0f 18 15 29 7e f3 ff 	prefetcht1 -0xc81d7(%rip)        # 773f0 <pf_target_21_0>

000000000013f5c7 <pf_jump_21>:
  13f5c7:	e9 f4 fa f3 ff       	jmp    7f0c0 <pf_callee_21>
  13f5cc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f5d0 <pf_call_22>:
  13f5d0:	0f 18 15 19 9f f4 ff 	prefetcht1 -0xb60e7(%rip)        # 894f0 <pf_target_22_0>

000000000013f5d7 <pf_jump_22>:
  13f5d7:	e9 04 9c ee ff       	jmp    291e0 <pf_callee_15>
  13f5dc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f5e0 <pf_call_23>:
  13f5e0:	0f 18 15 1b f4 f4 ff 	prefetcht1 -0xb0be5(%rip)        # 8ea02 <pf_target_23_0>
  13f5e7:	0f 18 15 c2 f3 f4 ff 	prefetcht1 -0xb0c3e(%rip)        # 8e9b0 <pf_target_23_1>
  13f5ee:	0f 18 15 0c 7a f3 ff 	prefetcht1 -0xc85f4(%rip)        # 77001 <pf_target_20_1>
  13f5f5:	41 53                	push   %r11
  13f5f7:	4c 8b 1d f2 da ff ff 	mov    -0x250e(%rip),%r11        # 13d0f0 <pf_got_17_0>

000000000013f5fe <pf_got_hint_23_0>:
  13f5fe:	41 0f 18 93 e0 48 ff 	prefetcht1 -0xb720(%r11)
  13f605:	ff 
  13f606:	41 5b                	pop    %r11

000000000013f608 <pf_jump_23>:
  13f608:	e9 c3 aa ee ff       	jmp    2a0d0 <pf_callee_23>
  13f60d:	0f 1f 00             	nopl   (%rax)

000000000013f610 <pf_call_24>:
  13f610:	0f 18 15 c9 72 f3 ff 	prefetcht1 -0xc8d37(%rip)        # 768e0 <pf_target_24_0>
  13f617:	0f 18 15 22 9e ee ff 	prefetcht1 -0x1161de(%rip)        # 29440 <pf_callee_7>
  13f61e:	0f 18 15 0b 44 f0 ff 	prefetcht1 -0xfbbf5(%rip)        # 43a30 <pf_target_24_2>

000000000013f625 <pf_jump_24>:
  13f625:	e9 46 f1 f5 ff       	jmp    9e770 <pf_callee_24>
  13f62a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000013f630 <pf_call_25>:
  13f630:	0f 18 15 79 7c f2 ff 	prefetcht1 -0xd8387(%rip)        # 672b0 <pf_target_25_0>

000000000013f637 <pf_jump_25>:
  13f637:	e9 f4 3c f7 ff       	jmp    b3330 <pf_callee_25>
  13f63c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f640 <pf_call_26>:
  13f640:	41 53                	push   %r11
  13f642:	4c 8b 1d 9f e1 ff ff 	mov    -0x1e61(%rip),%r11        # 13d7e8 <pf_got_26_0>

000000000013f649 <pf_got_hint_26_0>:
  13f649:	41 0f 18 93 31 00 00 	prefetcht1 0x31(%r11)
  13f650:	00 
  13f651:	41 5b                	pop    %r11

000000000013f653 <pf_jump_26>:
  13f653:	e9 38 ab f7 ff       	jmp    ba190 <pf_callee_26>
