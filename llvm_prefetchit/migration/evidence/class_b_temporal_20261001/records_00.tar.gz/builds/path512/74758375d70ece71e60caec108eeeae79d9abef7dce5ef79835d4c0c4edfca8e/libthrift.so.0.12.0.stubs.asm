
/storage/prefetchit/class_b_temporal_20261001/builds/path512/74758375d70ece71e60caec108eeeae79d9abef7dce5ef79835d4c0c4edfca8e/call-stub-fxh0_qn2/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000c22c0 <pf_call_0>:
   c22c0:	0f 18 15 b9 00 fa ff 	prefetcht1 -0x5ff47(%rip)        # 62380 <pf_target_0_0>

00000000000c22c7 <pf_jump_0>:
   c22c7:	e9 d4 67 f8 ff       	jmp    48aa0 <pf_callee_0>
   c22cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000c22d0 <pf_call_1>:
   c22d0:	0f 18 15 1a e2 fb ff 	prefetcht1 -0x41de6(%rip)        # 804f1 <pf_target_1_0>
   c22d7:	0f 18 15 22 60 f8 ff 	prefetcht1 -0x79fde(%rip)        # 48300 <pf_callee_5>

00000000000c22de <pf_jump_1>:
   c22de:	e9 7d 52 f8 ff       	jmp    47560 <pf_callee_1>
   c22e3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c22ea:	00 00 00 
   c22ed:	0f 1f 00             	nopl   (%rax)

00000000000c22f0 <pf_call_2>:
   c22f0:	0f 18 15 51 f6 fb ff 	prefetcht1 -0x409af(%rip)        # 81948 <pf_target_2_0>

00000000000c22f7 <pf_jump_2>:
   c22f7:	e9 24 6d f8 ff       	jmp    49020 <pf_callee_2>
   c22fc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000c2300 <pf_call_3>:
   c2300:	0f 18 15 99 86 fb ff 	prefetcht1 -0x47967(%rip)        # 7a9a0 <pf_target_3_0>
   c2307:	0f 18 15 62 85 fb ff 	prefetcht1 -0x47a9e(%rip)        # 7a870 <pf_target_3_1>
   c230e:	0f 18 15 0b 6d f8 ff 	prefetcht1 -0x792f5(%rip)        # 49020 <pf_callee_2>
   c2315:	0f 18 15 54 68 fb ff 	prefetcht1 -0x497ac(%rip)        # 78b70 <pf_target_3_3>

00000000000c231c <pf_jump_3>:
   c231c:	e9 df 56 f8 ff       	jmp    47a00 <pf_callee_3>
   c2321:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c2328:	00 00 00 
   c232b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000c2330 <pf_call_4>:
   c2330:	0f 18 15 09 55 f8 ff 	prefetcht1 -0x7aaf7(%rip)        # 47840 <pf_target_4_0>
   c2337:	0f 18 15 82 f5 fb ff 	prefetcht1 -0x40a7e(%rip)        # 818c0 <pf_target_4_1>
   c233e:	0f 18 15 7b 12 fb ff 	prefetcht1 -0x4ed85(%rip)        # 735c0 <pf_target_4_2>
   c2345:	41 53                	push   %r11
   c2347:	4c 8b 1d 6a e5 ff ff 	mov    -0x1a96(%rip),%r11        # c08b8 <pf_got_4_0>

00000000000c234e <pf_got_hint_4_0>:
   c234e:	41 0f 18 93 40 07 00 	prefetcht1 0x740(%r11)
   c2355:	00 
   c2356:	41 5b                	pop    %r11

00000000000c2358 <pf_jump_4>:
   c2358:	e9 c3 59 f8 ff       	jmp    47d20 <pf_callee_4>
   c235d:	0f 1f 00             	nopl   (%rax)

00000000000c2360 <pf_call_5>:
   c2360:	0f 18 15 9a ec fb ff 	prefetcht1 -0x41366(%rip)        # 81001 <pf_target_5_0>
   c2367:	0f 18 15 52 f3 fb ff 	prefetcht1 -0x40cae(%rip)        # 816c0 <pf_target_5_1>
   c236e:	0f 18 15 a0 f5 fb ff 	prefetcht1 -0x40a60(%rip)        # 81915 <pf_target_5_2>
   c2375:	0f 18 15 74 ec fb ff 	prefetcht1 -0x4138c(%rip)        # 80ff0 <pf_target_5_3>

00000000000c237c <pf_jump_5>:
   c237c:	e9 7f 5f f8 ff       	jmp    48300 <pf_callee_5>
   c2381:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c2388:	00 00 00 
   c238b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000c2390 <pf_call_6>:
   c2390:	0f 18 15 59 6e fb ff 	prefetcht1 -0x491a7(%rip)        # 791f0 <pf_target_6_0>
   c2397:	0f 18 15 a2 4d fb ff 	prefetcht1 -0x4b25e(%rip)        # 77140 <pf_target_6_1>
   c239e:	0f 18 15 db 4d fb ff 	prefetcht1 -0x4b225(%rip)        # 77180 <pf_target_6_2>
   c23a5:	0f 18 15 a4 84 fb ff 	prefetcht1 -0x47b5c(%rip)        # 7a850 <pf_target_6_3>

00000000000c23ac <pf_jump_6>:
   c23ac:	e9 4f 5f f8 ff       	jmp    48300 <pf_callee_5>
   c23b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c23b8:	00 00 00 
   c23bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000c23c0 <pf_call_7>:
   c23c0:	41 53                	push   %r11
   c23c2:	4c 8b 1d ef e4 ff ff 	mov    -0x1b11(%rip),%r11        # c08b8 <pf_got_4_0>

00000000000c23c9 <pf_got_hint_7_0>:
   c23c9:	41 0f 18 93 c0 53 ff 	prefetcht1 -0xac40(%r11)
   c23d0:	ff 

00000000000c23d1 <pf_got_hint_7_1>:
   c23d1:	41 0f 18 93 40 07 00 	prefetcht1 0x740(%r11)
   c23d8:	00 

00000000000c23d9 <pf_got_hint_7_2>:
   c23d9:	41 0f 18 93 a0 04 0a 	prefetcht1 0xa04a0(%r11)
   c23e0:	00 

00000000000c23e1 <pf_got_hint_7_3>:
   c23e1:	41 0f 18 93 b0 04 0a 	prefetcht1 0xa04b0(%r11)
   c23e8:	00 
   c23e9:	41 5b                	pop    %r11

00000000000c23eb <pf_jump_7>:
   c23eb:	e9 10 5f f8 ff       	jmp    48300 <pf_callee_5>
