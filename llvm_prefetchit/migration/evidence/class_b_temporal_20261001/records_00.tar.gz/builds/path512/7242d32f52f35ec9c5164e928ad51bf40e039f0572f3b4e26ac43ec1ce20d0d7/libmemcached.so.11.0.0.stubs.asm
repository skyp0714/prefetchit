
/storage/prefetchit/class_b_temporal_20261001/builds/path512/7242d32f52f35ec9c5164e928ad51bf40e039f0572f3b4e26ac43ec1ce20d0d7/call-stub-3y5dogxf/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000312c0 <pf_call_0>:
   312c0:	0f 18 15 b9 e6 fd ff 	prefetcht1 -0x21947(%rip)        # f980 <pf_target_0_0>
   312c7:	0f 18 15 b2 6f fe ff 	prefetcht1 -0x1904e(%rip)        # 18280 <pf_target_0_1>
   312ce:	0f 18 15 db e8 fd ff 	prefetcht1 -0x21725(%rip)        # fbb0 <pf_target_0_2>
   312d5:	0f 18 15 25 e9 fd ff 	prefetcht1 -0x216db(%rip)        # fc01 <pf_target_0_3>

00000000000312dc <pf_jump_0>:
   312dc:	e9 8f 41 fd ff       	jmp    5470 <pf_callee_0>
   312e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   312e8:	00 00 00 
   312eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000312f0 <pf_call_1>:
   312f0:	0f 18 15 c9 e6 fd ff 	prefetcht1 -0x21937(%rip)        # f9c0 <pf_target_1_0>

00000000000312f7 <pf_jump_1>:
   312f7:	e9 14 42 fd ff       	jmp    5510 <pf_callee_1>
   312fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031300 <pf_call_2>:
   31300:	0f 18 15 49 55 fe ff 	prefetcht1 -0x1aab7(%rip)        # 16850 <pf_target_2_0>
   31307:	0f 18 15 b2 e8 fd ff 	prefetcht1 -0x2174e(%rip)        # fbc0 <pf_target_2_1>

000000000003130e <pf_jump_2>:
   3130e:	e9 7d 40 fe ff       	jmp    15390 <pf_callee_2>
   31313:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3131a:	00 00 00 
   3131d:	0f 1f 00             	nopl   (%rax)

0000000000031320 <pf_call_3>:
   31320:	0f 18 15 89 44 fe ff 	prefetcht1 -0x1bb77(%rip)        # 157b0 <pf_callee_20>

0000000000031327 <pf_jump_3>:
   31327:	e9 34 a6 fd ff       	jmp    b960 <pf_callee_10>
   3132c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031330 <pf_call_4>:
   31330:	0f 18 15 d9 3c fe ff 	prefetcht1 -0x1c327(%rip)        # 15010 <pf_target_4_0>
   31337:	0f 18 15 0a 1d fe ff 	prefetcht1 -0x1e2f6(%rip)        # 13048 <pf_target_4_1>
   3133e:	0f 18 15 1b 7c fe ff 	prefetcht1 -0x183e5(%rip)        # 18f60 <pf_target_4_2>
   31345:	0f 18 15 30 7a fe ff 	prefetcht1 -0x185d0(%rip)        # 18d7c <pf_target_4_3>

000000000003134c <pf_jump_4>:
   3134c:	e9 bf 42 fd ff       	jmp    5610 <pf_callee_4>
   31351:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31358:	00 00 00 
   3135b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031360 <pf_call_5>:
   31360:	0f 18 15 9b 1f fe ff 	prefetcht1 -0x1e065(%rip)        # 13302 <pf_target_5_0>

0000000000031367 <pf_jump_5>:
   31367:	e9 74 41 fd ff       	jmp    54e0 <pf_callee_5>
   3136c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031370 <pf_call_6>:
   31370:	0f 18 15 60 2b fe ff 	prefetcht1 -0x1d4a0(%rip)        # 13ed7 <pf_target_6_0>

0000000000031377 <pf_jump_6>:
   31377:	e9 44 b2 fd ff       	jmp    c5c0 <pf_callee_6>
   3137c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031380 <pf_call_7>:
   31380:	0f 18 15 89 42 fd ff 	prefetcht1 -0x2bd77(%rip)        # 5610 <pf_callee_4>

0000000000031387 <pf_jump_7>:
   31387:	e9 64 3e fe ff       	jmp    151f0 <pf_callee_7>
   3138c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031390 <pf_call_8>:
   31390:	0f 18 15 88 e1 fd ff 	prefetcht1 -0x21e78(%rip)        # f51f <pf_target_8_0>
   31397:	0f 18 15 b2 ca fd ff 	prefetcht1 -0x2354e(%rip)        # de50 <pf_callee_23>

000000000003139e <pf_jump_8>:
   3139e:	e9 ad d0 fd ff       	jmp    e450 <pf_callee_12>
   313a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   313aa:	00 00 00 
   313ad:	0f 1f 00             	nopl   (%rax)

00000000000313b0 <pf_call_9>:
   313b0:	0f 18 15 b9 e0 fd ff 	prefetcht1 -0x21f47(%rip)        # f470 <pf_target_9_0>

00000000000313b7 <pf_jump_9>:
   313b7:	e9 a4 d4 fe ff       	jmp    1e860 <pf_callee_9>
   313bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000313c0 <pf_call_10>:
   313c0:	0f 18 15 70 df fd ff 	prefetcht1 -0x22090(%rip)        # f337 <pf_target_10_0>

00000000000313c7 <pf_jump_10>:
   313c7:	e9 94 a5 fd ff       	jmp    b960 <pf_callee_10>
   313cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000313d0 <pf_call_11>:
   313d0:	0f 18 15 59 77 fe ff 	prefetcht1 -0x188a7(%rip)        # 18b30 <pf_target_11_0>
   313d7:	0f 18 15 a4 77 fe ff 	prefetcht1 -0x1885c(%rip)        # 18b82 <pf_target_11_1>
   313de:	0f 18 15 3b 79 fe ff 	prefetcht1 -0x186c5(%rip)        # 18d20 <pf_target_11_2>
   313e5:	0f 18 15 56 79 fe ff 	prefetcht1 -0x186aa(%rip)        # 18d42 <pf_target_11_3>

00000000000313ec <pf_jump_11>:
   313ec:	e9 8f 1e fe ff       	jmp    13280 <pf_callee_11>
   313f1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   313f8:	00 00 00 
   313fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031400 <pf_call_12>:
   31400:	0f 18 15 7a ab fd ff 	prefetcht1 -0x25486(%rip)        # bf81 <pf_target_12_0>

0000000000031407 <pf_jump_12>:
   31407:	e9 44 d0 fd ff       	jmp    e450 <pf_callee_12>
   3140c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031410 <pf_call_13>:
   31410:	0f 18 15 39 d0 fd ff 	prefetcht1 -0x22fc7(%rip)        # e450 <pf_callee_12>

0000000000031417 <pf_jump_13>:
   31417:	e9 54 f3 fd ff       	jmp    10770 <pf_callee_13>
   3141c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031420 <pf_call_14>:
   31420:	0f 18 15 29 d0 fd ff 	prefetcht1 -0x22fd7(%rip)        # e450 <pf_callee_12>
   31427:	0f 18 15 c2 d2 fd ff 	prefetcht1 -0x22d3e(%rip)        # e6f0 <pf_target_14_1>

000000000003142e <pf_jump_14>:
   3142e:	e9 5d f2 fd ff       	jmp    10690 <pf_callee_14>
   31433:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3143a:	00 00 00 
   3143d:	0f 1f 00             	nopl   (%rax)

0000000000031440 <pf_call_15>:
   31440:	0f 18 15 fb d2 fd ff 	prefetcht1 -0x22d05(%rip)        # e742 <pf_target_15_0>

0000000000031447 <pf_jump_15>:
   31447:	e9 e4 05 fe ff       	jmp    11a30 <pf_callee_15>
   3144c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031450 <pf_call_16>:
   31450:	0f 18 15 a9 96 fd ff 	prefetcht1 -0x26957(%rip)        # ab00 <pf_target_16_0>
   31457:	0f 18 15 e6 96 fd ff 	prefetcht1 -0x2691a(%rip)        # ab44 <pf_target_16_1>

000000000003145e <pf_jump_16>:
   3145e:	e9 1d b4 fd ff       	jmp    c880 <pf_callee_16>
   31463:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3146a:	00 00 00 
   3146d:	0f 1f 00             	nopl   (%rax)

0000000000031470 <pf_call_17>:
   31470:	41 53                	push   %r11
   31472:	4c 8b 1d 67 ed ff ff 	mov    -0x1299(%rip),%r11        # 301e0 <pf_got_17_0>

0000000000031479 <pf_got_hint_17_0>:
   31479:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   31480:	00 
   31481:	41 5b                	pop    %r11

0000000000031483 <pf_jump_17>:
   31483:	e9 f8 b3 fd ff       	jmp    c880 <pf_callee_16>
   31488:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   3148f:	00 

0000000000031490 <pf_call_18>:
   31490:	0f 18 15 99 1b fe ff 	prefetcht1 -0x1e467(%rip)        # 13030 <pf_target_18_0>
   31497:	0f 18 15 e6 1b fe ff 	prefetcht1 -0x1e41a(%rip)        # 13084 <pf_target_18_1>

000000000003149e <pf_jump_18>:
   3149e:	e9 dd b3 fd ff       	jmp    c880 <pf_callee_16>
   314a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   314aa:	00 00 00 
   314ad:	0f 1f 00             	nopl   (%rax)

00000000000314b0 <pf_call_19>:
   314b0:	0f 18 15 a1 5b fd ff 	prefetcht1 -0x2a45f(%rip)        # 7058 <pf_target_19_0>

00000000000314b7 <pf_jump_19>:
   314b7:	e9 c4 b3 fd ff       	jmp    c880 <pf_callee_16>
   314bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000314c0 <pf_call_20>:
   314c0:	0f 18 15 f9 b0 fd ff 	prefetcht1 -0x24f07(%rip)        # c5c0 <pf_callee_6>

00000000000314c7 <pf_jump_20>:
   314c7:	e9 e4 42 fe ff       	jmp    157b0 <pf_callee_20>
   314cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000314d0 <pf_call_21>:
   314d0:	0f 18 15 79 cf fd ff 	prefetcht1 -0x23087(%rip)        # e450 <pf_callee_12>
   314d7:	0f 18 15 72 c9 fd ff 	prefetcht1 -0x2368e(%rip)        # de50 <pf_callee_23>
   314de:	0f 18 15 9b 1d fe ff 	prefetcht1 -0x1e265(%rip)        # 13280 <pf_callee_11>
   314e5:	0f 18 15 7c ca fd ff 	prefetcht1 -0x23584(%rip)        # df68 <pf_target_21_3>

00000000000314ec <pf_jump_21>:
   314ec:	e9 9f f1 fd ff       	jmp    10690 <pf_callee_14>
   314f1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   314f8:	00 00 00 
   314fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031500 <pf_call_22>:
   31500:	0f 18 15 3b 76 fe ff 	prefetcht1 -0x189c5(%rip)        # 18b42 <pf_target_22_0>

0000000000031507 <pf_jump_22>:
   31507:	e9 44 cf fd ff       	jmp    e450 <pf_callee_12>
   3150c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031510 <pf_call_23>:
   31510:	0f 18 15 a9 a5 fd ff 	prefetcht1 -0x25a57(%rip)        # bac0 <pf_target_23_0>
   31517:	0f 18 15 42 d3 fe ff 	prefetcht1 -0x12cbe(%rip)        # 1e860 <pf_callee_9>
   3151e:	0f 18 15 5c d3 fe ff 	prefetcht1 -0x12ca4(%rip)        # 1e881 <pf_target_23_2>
   31525:	0f 18 15 99 a4 fd ff 	prefetcht1 -0x25b67(%rip)        # b9c5 <pf_target_23_3>

000000000003152c <pf_jump_23>:
   3152c:	e9 1f c9 fd ff       	jmp    de50 <pf_callee_23>
   31531:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31538:	00 00 00 
   3153b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031540 <pf_call_24>:
   31540:	0f 18 15 3c 82 fd ff 	prefetcht1 -0x27dc4(%rip)        # 9783 <pf_target_24_0>
   31547:	0f 18 15 22 82 fd ff 	prefetcht1 -0x27dde(%rip)        # 9770 <pf_target_24_1>

000000000003154e <pf_jump_24>:
   3154e:	e9 9d 79 fe ff       	jmp    18ef0 <pf_callee_24>
   31553:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3155a:	00 00 00 
   3155d:	0f 1f 00             	nopl   (%rax)

0000000000031560 <pf_call_25>:
   31560:	0f 18 15 41 da fe ff 	prefetcht1 -0x125bf(%rip)        # 1efa8 <pf_target_25_0>
   31567:	41 53                	push   %r11
   31569:	4c 8b 1d 80 eb ff ff 	mov    -0x1480(%rip),%r11        # 300f0 <pf_got_25_0>

0000000000031570 <pf_got_hint_25_0>:
   31570:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   31577:	00 
   31578:	41 5b                	pop    %r11

000000000003157a <pf_jump_25>:
   3157a:	e9 61 42 fd ff       	jmp    57e0 <pf_callee_25>
