
/storage/prefetchit/class_b_temporal_20261001/builds/path512/ff0825e113603c3866680d5d52216bc6d8eedf3a59f52a0aef67ff01994db128/call-stub-b3rzudgh/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000022c300 <pf_call_0>:
  22c300:	0f 18 15 89 60 e9 ff 	prefetcht1 -0x169f77(%rip)        # c2390 <pf_target_0_0>
  22c307:	0f 18 15 9a a6 e9 ff 	prefetcht1 -0x165966(%rip)        # c69a8 <pf_target_0_1>
  22c30e:	0f 18 15 ed e3 ea ff 	prefetcht1 -0x151c13(%rip)        # da702 <pf_target_0_2>
  22c315:	0f 18 15 c4 e3 ea ff 	prefetcht1 -0x151c3c(%rip)        # da6e0 <pf_target_0_3>

000000000022c31c <pf_jump_0>:
  22c31c:	e9 af 2d e7 ff       	jmp    9f0d0 <pf_callee_0>
  22c321:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c328:	00 00 00 
  22c32b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c330 <pf_call_1>:
  22c330:	0f 18 15 09 1b ef ff 	prefetcht1 -0x10e4f7(%rip)        # 11de40 <pf_target_1_0>
  22c337:	0f 18 15 82 ff ef ff 	prefetcht1 -0x10007e(%rip)        # 12c2c0 <pf_target_1_1>

000000000022c33e <pf_jump_1>:
  22c33e:	e9 3d 34 e7 ff       	jmp    9f780 <pf_callee_1>
  22c343:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c34a:	00 00 00 
  22c34d:	0f 1f 00             	nopl   (%rax)

000000000022c350 <pf_call_2>:
  22c350:	0f 18 15 29 45 e7 ff 	prefetcht1 -0x18bad7(%rip)        # a0880 <pf_target_2_0>
  22c357:	0f 18 15 25 38 e9 ff 	prefetcht1 -0x16c7db(%rip)        # bfb83 <pf_target_2_1>

000000000022c35e <pf_jump_2>:
  22c35e:	e9 bd 5f e9 ff       	jmp    c2320 <pf_callee_2>
  22c363:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c36a:	00 00 00 
  22c36d:	0f 1f 00             	nopl   (%rax)

000000000022c370 <pf_call_3>:
  22c370:	0f 18 15 b9 37 e7 ff 	prefetcht1 -0x18c847(%rip)        # 9fb30 <pf_target_3_0>

000000000022c377 <pf_jump_3>:
  22c377:	e9 94 27 e7 ff       	jmp    9eb10 <pf_callee_3>
  22c37c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c380 <pf_call_4>:
  22c380:	0f 18 15 d9 20 e7 ff 	prefetcht1 -0x18df27(%rip)        # 9e460 <pf_target_4_0>

000000000022c387 <pf_jump_4>:
  22c387:	e9 c4 21 e7 ff       	jmp    9e550 <pf_callee_4>
  22c38c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c390 <pf_call_5>:
  22c390:	0f 18 15 59 2c f0 ff 	prefetcht1 -0xfd3a7(%rip)        # 12eff0 <pf_target_5_0>
  22c397:	0f 18 15 42 2f f0 ff 	prefetcht1 -0xfd0be(%rip)        # 12f2e0 <pf_target_5_1>

000000000022c39e <pf_jump_5>:
  22c39e:	e9 ed 34 e7 ff       	jmp    9f890 <pf_callee_5>
  22c3a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c3aa:	00 00 00 
  22c3ad:	0f 1f 00             	nopl   (%rax)

000000000022c3b0 <pf_call_6>:
  22c3b0:	0f 18 15 99 49 e7 ff 	prefetcht1 -0x18b667(%rip)        # a0d50 <pf_target_6_0>

000000000022c3b7 <pf_jump_6>:
  22c3b7:	e9 84 52 e7 ff       	jmp    a1640 <pf_callee_6>
  22c3bc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c3c0 <pf_call_7>:
  22c3c0:	0f 18 15 19 bf ef ff 	prefetcht1 -0x1040e7(%rip)        # 1282e0 <pf_target_7_0>
  22c3c7:	0f 18 15 e2 25 e7 ff 	prefetcht1 -0x18da1e(%rip)        # 9e9b0 <pf_target_7_1>
  22c3ce:	0f 18 15 3b bf ef ff 	prefetcht1 -0x1040c5(%rip)        # 128310 <pf_target_7_2>
  22c3d5:	0f 18 15 74 bf ef ff 	prefetcht1 -0x10408c(%rip)        # 128350 <pf_target_7_3>

000000000022c3dc <pf_jump_7>:
  22c3dc:	e9 1f 54 e7 ff       	jmp    a1800 <pf_callee_7>
  22c3e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c3e8:	00 00 00 
  22c3eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c3f0 <pf_call_8>:
  22c3f0:	0f 18 15 49 ee ef ff 	prefetcht1 -0x1011b7(%rip)        # 12b240 <pf_callee_10>
  22c3f7:	0f 18 15 03 2c f0 ff 	prefetcht1 -0xfd3fd(%rip)        # 12f001 <pf_target_8_1>
  22c3fe:	0f 18 15 3b 4c ef ff 	prefetcht1 -0x10b3c5(%rip)        # 121040 <pf_target_8_2>
  22c405:	0f 18 15 04 4c ef ff 	prefetcht1 -0x10b3fc(%rip)        # 121010 <pf_target_8_3>

000000000022c40c <pf_jump_8>:
  22c40c:	e9 9f 32 e7 ff       	jmp    9f6b0 <pf_callee_8>
  22c411:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c418:	00 00 00 
  22c41b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c420 <pf_call_9>:
  22c420:	0f 18 15 49 66 f1 ff 	prefetcht1 -0xe99b7(%rip)        # 142a70 <pf_target_9_0>
  22c427:	0f 18 15 54 66 f1 ff 	prefetcht1 -0xe99ac(%rip)        # 142a82 <pf_target_9_1>

000000000022c42e <pf_jump_9>:
  22c42e:	e9 7d 32 e7 ff       	jmp    9f6b0 <pf_callee_8>
  22c433:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c43a:	00 00 00 
  22c43d:	0f 1f 00             	nopl   (%rax)

000000000022c440 <pf_call_10>:
  22c440:	0f 18 15 91 66 f1 ff 	prefetcht1 -0xe996f(%rip)        # 142ad8 <pf_target_10_0>
  22c447:	0f 18 15 32 64 f1 ff 	prefetcht1 -0xe9bce(%rip)        # 142880 <pf_target_10_1>
  22c44e:	0f 18 15 6d 64 f1 ff 	prefetcht1 -0xe9b93(%rip)        # 1428c2 <pf_target_10_2>

000000000022c455 <pf_jump_10>:
  22c455:	e9 e6 ed ef ff       	jmp    12b240 <pf_callee_10>
  22c45a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000022c460 <pf_call_11>:
  22c460:	0f 18 15 19 5e f1 ff 	prefetcht1 -0xea1e7(%rip)        # 142280 <pf_target_11_0>

000000000022c467 <pf_jump_11>:
  22c467:	e9 84 24 f0 ff       	jmp    12e8f0 <pf_callee_11>
  22c46c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c470 <pf_call_12>:
  22c470:	0f 18 15 69 02 f2 ff 	prefetcht1 -0xdfd97(%rip)        # 14c6e0 <pf_target_12_0>

000000000022c477 <pf_jump_12>:
  22c477:	e9 14 3a e7 ff       	jmp    9fe90 <pf_callee_12>
  22c47c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c480 <pf_call_13>:
  22c480:	0f 18 15 39 1b ef ff 	prefetcht1 -0x10e4c7(%rip)        # 11dfc0 <pf_target_13_0>
  22c487:	0f 18 15 12 51 e7 ff 	prefetcht1 -0x18aeee(%rip)        # a15a0 <pf_callee_14>
  22c48e:	0f 18 15 8b 5e e9 ff 	prefetcht1 -0x16a175(%rip)        # c2320 <pf_callee_2>
  22c495:	0f 18 15 94 31 e7 ff 	prefetcht1 -0x18ce6c(%rip)        # 9f630 <pf_target_13_3>

000000000022c49c <pf_jump_13>:
  22c49c:	e9 0f 2d e7 ff       	jmp    9f1b0 <pf_callee_13>
  22c4a1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c4a8:	00 00 00 
  22c4ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c4b0 <pf_call_14>:
  22c4b0:	0f 18 15 29 45 e9 ff 	prefetcht1 -0x16bad7(%rip)        # c09e0 <pf_target_14_0>
  22c4b7:	0f 18 15 92 20 e7 ff 	prefetcht1 -0x18df6e(%rip)        # 9e550 <pf_callee_4>
  22c4be:	0f 18 15 3b 45 e9 ff 	prefetcht1 -0x16bac5(%rip)        # c0a00 <pf_target_14_2>
  22c4c5:	0f 18 15 54 e1 ef ff 	prefetcht1 -0x101eac(%rip)        # 12a620 <pf_target_14_3>

000000000022c4cc <pf_jump_14>:
  22c4cc:	e9 cf 50 e7 ff       	jmp    a15a0 <pf_callee_14>
  22c4d1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c4d8:	00 00 00 
  22c4db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c4e0 <pf_call_15>:
  22c4e0:	0f 18 15 19 50 e7 ff 	prefetcht1 -0x18afe7(%rip)        # a1500 <pf_target_15_0>
  22c4e7:	0f 18 15 f2 1e f2 ff 	prefetcht1 -0xde10e(%rip)        # 14e3e0 <pf_target_15_1>
  22c4ee:	0f 18 15 10 1f f2 ff 	prefetcht1 -0xde0f0(%rip)        # 14e405 <pf_target_15_2>

000000000022c4f5 <pf_jump_15>:
  22c4f5:	e9 d6 45 e7 ff       	jmp    a0ad0 <pf_callee_15>
  22c4fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000022c500 <pf_call_16>:
  22c500:	0f 18 15 89 26 f2 ff 	prefetcht1 -0xdd977(%rip)        # 14eb90 <pf_target_16_0>
  22c507:	0f 18 15 f2 04 f1 ff 	prefetcht1 -0xefb0e(%rip)        # 13ca00 <pf_target_16_1>
  22c50e:	0f 18 15 eb 4f e7 ff 	prefetcht1 -0x18b015(%rip)        # a1500 <pf_target_15_0>

000000000022c515 <pf_jump_16>:
  22c515:	e9 d6 5b e7 ff       	jmp    a20f0 <pf_callee_16>
  22c51a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000022c520 <pf_call_17>:
  22c520:	0f 18 15 49 24 e8 ff 	prefetcht1 -0x17dbb7(%rip)        # ae970 <pf_target_17_0>

000000000022c527 <pf_jump_17>:
  22c527:	e9 a4 5a e7 ff       	jmp    a1fd0 <pf_callee_17>
  22c52c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c530 <pf_call_18>:
  22c530:	0f 18 15 99 45 e7 ff 	prefetcht1 -0x18ba67(%rip)        # a0ad0 <pf_callee_15>

000000000022c537 <pf_jump_18>:
  22c537:	e9 b4 5b e7 ff       	jmp    a20f0 <pf_callee_16>
