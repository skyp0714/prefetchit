
/storage/prefetchit/class_b_temporal_20261001/builds/path512/54771f7236ce5ab22b131b8381b31d23e0a8b2b45695d559a9c47f572e2c3859/call-stub-6yeuzbjq/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000113340 <pf_call_0>:
  113340:	0f 18 15 b9 2e f3 ff 	prefetcht1 -0xcd147(%rip)        # 46200 <pf_target_0_0>
  113347:	0f 18 15 d2 85 f3 ff 	prefetcht1 -0xc7a2e(%rip)        # 4b920 <pf_target_0_1>
  11334e:	0f 18 15 4b 2e f3 ff 	prefetcht1 -0xcd1b5(%rip)        # 461a0 <pf_target_0_2>
  113355:	0f 18 15 b4 38 f3 ff 	prefetcht1 -0xcc74c(%rip)        # 46c10 <pf_target_0_3>

000000000011335c <pf_jump_0>:
  11335c:	e9 ef 3f f1 ff       	jmp    27350 <pf_callee_0>
  113361:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  113368:	00 00 00 
  11336b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000113370 <pf_call_1>:
  113370:	0f 18 15 c9 cf f7 ff 	prefetcht1 -0x83037(%rip)        # 90340 <pf_target_1_0>
  113377:	0f 18 15 c2 8d f7 ff 	prefetcht1 -0x8723e(%rip)        # 8c140 <pf_target_1_1>
  11337e:	0f 18 15 4b 97 f7 ff 	prefetcht1 -0x868b5(%rip)        # 8cad0 <pf_target_1_2>
  113385:	0f 18 15 84 c1 fb ff 	prefetcht1 -0x43e7c(%rip)        # cf510 <pf_target_1_3>

000000000011338c <pf_jump_1>:
  11338c:	e9 4f 6a f9 ff       	jmp    a9de0 <pf_callee_1>
  113391:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  113398:	00 00 00 
  11339b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000001133a0 <pf_call_2>:
  1133a0:	0f 18 15 59 97 f7 ff 	prefetcht1 -0x868a7(%rip)        # 8cb00 <pf_target_2_0>
  1133a7:	0f 18 15 f2 3d f8 ff 	prefetcht1 -0x7c20e(%rip)        # 971a0 <pf_callee_5>
  1133ae:	0f 18 15 4b 3e f8 ff 	prefetcht1 -0x7c1b5(%rip)        # 97200 <pf_target_2_2>
  1133b5:	0f 18 15 24 2e f7 ff 	prefetcht1 -0x8d1dc(%rip)        # 861e0 <pf_target_2_3>

00000000001133bc <pf_jump_2>:
  1133bc:	e9 3f f5 f1 ff       	jmp    32900 <pf_callee_2>
  1133c1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1133c8:	00 00 00 
  1133cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000001133d0 <pf_call_3>:
  1133d0:	0f 18 15 59 9f f5 ff 	prefetcht1 -0xa60a7(%rip)        # 6d330 <pf_target_3_0>

00000000001133d7 <pf_jump_3>:
  1133d7:	e9 94 03 f2 ff       	jmp    33770 <pf_callee_3>
  1133dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001133e0 <pf_call_4>:
  1133e0:	0f 18 15 5d 17 fb ff 	prefetcht1 -0x4e8a3(%rip)        # c4b44 <pf_target_4_0>
  1133e7:	0f 18 15 62 1c fb ff 	prefetcht1 -0x4e39e(%rip)        # c5050 <pf_target_4_1>
  1133ee:	0f 18 15 3b 17 fb ff 	prefetcht1 -0x4e8c5(%rip)        # c4b30 <pf_target_4_2>
  1133f5:	0f 18 15 94 68 f9 ff 	prefetcht1 -0x6976c(%rip)        # a9c90 <pf_target_4_3>

00000000001133fc <pf_jump_4>:
  1133fc:	e9 2f 8d f7 ff       	jmp    8c130 <pf_callee_4>
  113401:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  113408:	00 00 00 
  11340b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000113410 <pf_call_5>:
  113410:	0f 18 15 e9 d4 f3 ff 	prefetcht1 -0xc2b17(%rip)        # 50900 <pf_target_5_0>

0000000000113417 <pf_jump_5>:
  113417:	e9 84 3d f8 ff       	jmp    971a0 <pf_callee_5>
  11341c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113420 <pf_call_6>:
  113420:	0f 18 15 99 ba f4 ff 	prefetcht1 -0xb4567(%rip)        # 5eec0 <pf_target_6_0>

0000000000113427 <pf_jump_6>:
  113427:	e9 64 49 f1 ff       	jmp    27d90 <pf_callee_19>
  11342c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113430 <pf_call_7>:
  113430:	41 53                	push   %r11
  113432:	4c 8b 1d 8f e3 ff ff 	mov    -0x1c71(%rip),%r11        # 1117c8 <pf_got_7_0>

0000000000113439 <pf_got_hint_7_0>:
  113439:	41 0f 18 93 10 29 ff 	prefetcht1 -0xd6f0(%r11)
  113440:	ff 
  113441:	41 5b                	pop    %r11

0000000000113443 <pf_jump_7>:
  113443:	e9 78 4f f3 ff       	jmp    483c0 <pf_callee_7>
  113448:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11344f:	00 

0000000000113450 <pf_call_8>:
  113450:	41 53                	push   %r11
  113452:	4c 8b 1d 6f e0 ff ff 	mov    -0x1f91(%rip),%r11        # 1114c8 <pf_got_8_0>

0000000000113459 <pf_got_hint_8_0>:
  113459:	41 0f 18 93 c0 16 00 	prefetcht1 0x16c0(%r11)
  113460:	00 
  113461:	4c 8b 1d 30 e4 ff ff 	mov    -0x1bd0(%rip),%r11        # 111898 <pf_got_8_1>

0000000000113468 <pf_got_hint_8_1>:
  113468:	41 0f 18 93 c0 2d 00 	prefetcht1 0x2dc0(%r11)
  11346f:	00 
  113470:	41 5b                	pop    %r11

0000000000113472 <pf_jump_8>:
  113472:	e9 19 45 f1 ff       	jmp    27990 <pf_callee_8>
  113477:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  11347e:	00 00 

0000000000113480 <pf_call_9>:
  113480:	0f 18 15 b9 fb f2 ff 	prefetcht1 -0xd0447(%rip)        # 43040 <pf_target_9_0>

0000000000113487 <pf_jump_9>:
  113487:	e9 b4 47 f3 ff       	jmp    47c40 <pf_callee_9>
  11348c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113490 <pf_call_10>:
  113490:	0f 18 15 09 4d f3 ff 	prefetcht1 -0xcb2f7(%rip)        # 481a0 <pf_target_10_0>

0000000000113497 <pf_jump_10>:
  113497:	e9 c4 49 f1 ff       	jmp    27e60 <pf_callee_10>
  11349c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001134a0 <pf_call_11>:
  1134a0:	0f 18 15 59 30 f5 ff 	prefetcht1 -0xacfa7(%rip)        # 66500 <pf_target_11_0>

00000000001134a7 <pf_jump_11>:
  1134a7:	e9 94 3c f1 ff       	jmp    27140 <pf_callee_11>
  1134ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001134b0 <pf_call_12>:
  1134b0:	0f 18 15 f9 99 f3 ff 	prefetcht1 -0xc6607(%rip)        # 4ceb0 <pf_target_12_0>

00000000001134b7 <pf_jump_12>:
  1134b7:	e9 c4 d4 f3 ff       	jmp    50980 <pf_callee_12>
  1134bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001134c0 <pf_call_13>:
  1134c0:	0f 18 15 b6 0e f5 ff 	prefetcht1 -0xaf14a(%rip)        # 6437d <pf_target_13_0>
  1134c7:	0f 18 15 32 4c f1 ff 	prefetcht1 -0xeb3ce(%rip)        # 28100 <pf_callee_14>
  1134ce:	0f 18 15 ab 0e f5 ff 	prefetcht1 -0xaf155(%rip)        # 64380 <pf_target_13_2>
  1134d5:	0f 18 15 70 30 f5 ff 	prefetcht1 -0xacf90(%rip)        # 6654c <pf_target_13_3>

00000000001134dc <pf_jump_13>:
  1134dc:	e9 9f cc f4 ff       	jmp    60180 <pf_callee_13>
  1134e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1134e8:	00 00 00 
  1134eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000001134f0 <pf_call_14>:
  1134f0:	0f 18 15 89 14 f5 ff 	prefetcht1 -0xaeb77(%rip)        # 64980 <pf_target_14_0>
  1134f7:	0f 18 15 62 c1 f4 ff 	prefetcht1 -0xb3e9e(%rip)        # 5f660 <pf_target_14_1>
  1134fe:	0f 18 15 6b f9 f4 ff 	prefetcht1 -0xb0695(%rip)        # 62e70 <pf_target_14_2>

0000000000113505 <pf_jump_14>:
  113505:	e9 f6 4b f1 ff       	jmp    28100 <pf_callee_14>
  11350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000113510 <pf_call_15>:
  113510:	0f 18 15 79 4b f1 ff 	prefetcht1 -0xeb487(%rip)        # 28090 <pf_target_15_0>
  113517:	0f 18 15 b4 8c f3 ff 	prefetcht1 -0xc734c(%rip)        # 4c1d2 <pf_target_15_1>
  11351e:	0f 18 15 4b 8a f3 ff 	prefetcht1 -0xc75b5(%rip)        # 4bf70 <pf_target_15_2>

0000000000113525 <pf_jump_15>:
  113525:	e9 a6 3c f1 ff       	jmp    271d0 <pf_callee_15>
  11352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000113530 <pf_call_16>:
  113530:	0f 18 15 4b 76 f5 ff 	prefetcht1 -0xa89b5(%rip)        # 6ab82 <pf_target_16_0>
  113537:	0f 18 15 f2 75 f5 ff 	prefetcht1 -0xa8a0e(%rip)        # 6ab30 <pf_target_16_1>

000000000011353e <pf_jump_16>:
  11353e:	e9 fd 48 f1 ff       	jmp    27e40 <pf_callee_16>
  113543:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11354a:	00 00 00 
  11354d:	0f 1f 00             	nopl   (%rax)

0000000000113550 <pf_call_17>:
  113550:	0f 18 15 f9 b9 f4 ff 	prefetcht1 -0xb4607(%rip)        # 5ef50 <pf_target_17_0>

0000000000113557 <pf_jump_17>:
  113557:	e9 24 82 f6 ff       	jmp    7b780 <pf_callee_17>
  11355c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113560 <pf_call_18>:
  113560:	0f 18 15 99 6e f9 ff 	prefetcht1 -0x69167(%rip)        # aa400 <pf_target_18_0>

0000000000113567 <pf_jump_18>:
  113567:	e9 c4 48 f1 ff       	jmp    27e30 <pf_callee_18>
  11356c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113570 <pf_call_19>:
  113570:	0f 18 15 ff 08 f2 ff 	prefetcht1 -0xdf701(%rip)        # 33e76 <pf_target_19_0>

0000000000113577 <pf_jump_19>:
  113577:	e9 14 48 f1 ff       	jmp    27d90 <pf_callee_19>
