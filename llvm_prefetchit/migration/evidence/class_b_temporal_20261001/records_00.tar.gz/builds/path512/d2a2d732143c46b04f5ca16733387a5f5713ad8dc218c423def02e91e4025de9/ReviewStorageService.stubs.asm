
/storage/prefetchit/class_b_temporal_20261001/builds/path512/d2a2d732143c46b04f5ca16733387a5f5713ad8dc218c423def02e91e4025de9/call-stub-tvy68tdr/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000010b340 <pf_call_0>:
  10b340:	0f 18 15 bc 06 f4 ff 	prefetcht1 -0xbf944(%rip)        # 4ba03 <pf_target_0_0>
  10b347:	0f 18 15 f5 06 f4 ff 	prefetcht1 -0xbf90b(%rip)        # 4ba43 <pf_target_0_1>
  10b34e:	0f 18 15 5b 10 f4 ff 	prefetcht1 -0xbefa5(%rip)        # 4c3b0 <pf_target_0_2>
  10b355:	0f 18 15 c4 5c f4 ff 	prefetcht1 -0xba33c(%rip)        # 51020 <pf_target_0_3>

000000000010b35c <pf_jump_0>:
  10b35c:	e9 df c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b361:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b368:	00 00 00 
  10b36b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000010b370 <pf_call_1>:
  10b370:	41 53                	push   %r11
  10b372:	4c 8b 1d b7 dd ff ff 	mov    -0x2249(%rip),%r11        # 109130 <pf_got_1_0>

000000000010b379 <pf_got_hint_1_0>:
  10b379:	41 0f 18 93 b0 06 00 	prefetcht1 0x6b0(%r11)
  10b380:	00 
  10b381:	4c 8b 1d 28 e2 ff ff 	mov    -0x1dd8(%rip),%r11        # 1095b0 <pf_got_1_1>

000000000010b388 <pf_got_hint_1_1>:
  10b388:	41 0f 18 93 c5 1f 00 	prefetcht1 0x1fc5(%r11)
  10b38f:	00 
  10b390:	41 5b                	pop    %r11

000000000010b392 <pf_jump_1>:
  10b392:	e9 79 e2 f2 ff       	jmp    39610 <pf_callee_1>
  10b397:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  10b39e:	00 00 

000000000010b3a0 <pf_call_2>:
  10b3a0:	41 53                	push   %r11
  10b3a2:	4c 8b 1d cf e2 ff ff 	mov    -0x1d31(%rip),%r11        # 109678 <pf_got_2_0>

000000000010b3a9 <pf_got_hint_2_0>:
  10b3a9:	41 0f 18 93 10 61 ff 	prefetcht1 -0x9ef0(%r11)
  10b3b0:	ff 
  10b3b1:	41 5b                	pop    %r11

000000000010b3b3 <pf_jump_2>:
  10b3b3:	e9 38 c8 f1 ff       	jmp    27bf0 <pf_callee_2>
  10b3b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b3bf:	00 

000000000010b3c0 <pf_call_3>:
  10b3c0:	41 53                	push   %r11
  10b3c2:	4c 8b 1d 2f df ff ff 	mov    -0x20d1(%rip),%r11        # 1092f8 <pf_got_3_0>

000000000010b3c9 <pf_got_hint_3_0>:
  10b3c9:	41 0f 18 93 b0 04 00 	prefetcht1 0x4b0(%r11)
  10b3d0:	00 

000000000010b3d1 <pf_got_hint_3_1>:
  10b3d1:	41 0f 18 93 80 53 00 	prefetcht1 0x5380(%r11)
  10b3d8:	00 
  10b3d9:	4c 8b 1d 68 e1 ff ff 	mov    -0x1e98(%rip),%r11        # 109548 <pf_got_3_2>

000000000010b3e0 <pf_got_hint_3_2>:
  10b3e0:	41 0f 18 93 30 5a 03 	prefetcht1 0x35a30(%r11)
  10b3e7:	00 
  10b3e8:	4c 8b 1d 89 e2 ff ff 	mov    -0x1d77(%rip),%r11        # 109678 <pf_got_2_0>

000000000010b3ef <pf_got_hint_3_3>:
  10b3ef:	41 0f 18 93 60 76 ff 	prefetcht1 -0x89a0(%r11)
  10b3f6:	ff 
  10b3f7:	41 5b                	pop    %r11

000000000010b3f9 <pf_jump_3>:
  10b3f9:	e9 92 c6 f1 ff       	jmp    27a90 <pf_callee_3>
  10b3fe:	66 90                	xchg   %ax,%ax

000000000010b400 <pf_call_4>:
  10b400:	41 53                	push   %r11
  10b402:	4c 8b 1d 3f e1 ff ff 	mov    -0x1ec1(%rip),%r11        # 109548 <pf_got_3_2>

000000000010b409 <pf_got_hint_4_0>:
  10b409:	41 0f 18 93 b0 89 01 	prefetcht1 0x189b0(%r11)
  10b410:	00 
  10b411:	4c 8b 1d 60 e2 ff ff 	mov    -0x1da0(%rip),%r11        # 109678 <pf_got_2_0>

000000000010b418 <pf_got_hint_4_1>:
  10b418:	41 0f 18 93 60 50 ff 	prefetcht1 -0xafa0(%r11)
  10b41f:	ff 
  10b420:	41 5b                	pop    %r11

000000000010b422 <pf_jump_4>:
  10b422:	e9 89 bd f1 ff       	jmp    271b0 <pf_callee_13>
  10b427:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  10b42e:	00 00 

000000000010b430 <pf_call_5>:
  10b430:	41 53                	push   %r11
  10b432:	4c 8b 1d c7 e4 ff ff 	mov    -0x1b39(%rip),%r11        # 109900 <pf_got_10_0>

000000000010b439 <pf_got_hint_5_0>:
  10b439:	41 0f 18 93 70 e8 fe 	prefetcht1 -0x11790(%r11)
  10b440:	ff 

000000000010b441 <pf_got_hint_5_1>:
  10b441:	41 0f 18 93 20 26 ff 	prefetcht1 -0xd9e0(%r11)
  10b448:	ff 

000000000010b449 <pf_got_hint_5_2>:
  10b449:	41 0f 18 93 10 29 ff 	prefetcht1 -0xd6f0(%r11)
  10b450:	ff 
  10b451:	41 5b                	pop    %r11

000000000010b453 <pf_jump_5>:
  10b453:	e9 d8 26 f4 ff       	jmp    4db30 <pf_callee_5>
  10b458:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b45f:	00 

000000000010b460 <pf_call_6>:
  10b460:	41 53                	push   %r11
  10b462:	4c 8b 1d af e4 ff ff 	mov    -0x1b51(%rip),%r11        # 109918 <pf_got_6_0>

000000000010b469 <pf_got_hint_6_0>:
  10b469:	41 0f 18 93 d0 f0 ff 	prefetcht1 -0xf30(%r11)
  10b470:	ff 
  10b471:	41 5b                	pop    %r11

000000000010b473 <pf_jump_6>:
  10b473:	e9 c8 bc f1 ff       	jmp    27140 <pf_callee_6>
  10b478:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b47f:	00 

000000000010b480 <pf_call_7>:
  10b480:	0f 18 15 59 c3 f1 ff 	prefetcht1 -0xe3ca7(%rip)        # 277e0 <pf_target_7_0>
  10b487:	41 53                	push   %r11
  10b489:	4c 8b 1d 60 df ff ff 	mov    -0x20a0(%rip),%r11        # 1093f0 <pf_got_7_0>

000000000010b490 <pf_got_hint_7_0>:
  10b490:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b497:	00 
  10b498:	41 5b                	pop    %r11

000000000010b49a <pf_jump_7>:
  10b49a:	e9 a1 bc f1 ff       	jmp    27140 <pf_callee_6>
  10b49f:	90                   	nop

000000000010b4a0 <pf_call_8>:
  10b4a0:	0f 18 15 79 0b f4 ff 	prefetcht1 -0xbf487(%rip)        # 4c020 <pf_target_8_0>
  10b4a7:	0f 18 15 95 0b f4 ff 	prefetcht1 -0xbf46b(%rip)        # 4c043 <pf_target_8_1>

000000000010b4ae <pf_jump_8>:
  10b4ae:	e9 ad 0f f4 ff       	jmp    4c460 <pf_callee_8>
  10b4b3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b4ba:	00 00 00 
  10b4bd:	0f 1f 00             	nopl   (%rax)

000000000010b4c0 <pf_call_9>:
  10b4c0:	41 53                	push   %r11
  10b4c2:	4c 8b 1d 8f e1 ff ff 	mov    -0x1e71(%rip),%r11        # 109658 <pf_got_9_0>

000000000010b4c9 <pf_got_hint_9_0>:
  10b4c9:	41 0f 18 93 00 fd ff 	prefetcht1 -0x300(%r11)
  10b4d0:	ff 
  10b4d1:	41 5b                	pop    %r11

000000000010b4d3 <pf_jump_9>:
  10b4d3:	e9 88 c7 f1 ff       	jmp    27c60 <pf_callee_9>
  10b4d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b4df:	00 

000000000010b4e0 <pf_call_10>:
  10b4e0:	41 53                	push   %r11
  10b4e2:	4c 8b 1d 17 e4 ff ff 	mov    -0x1be9(%rip),%r11        # 109900 <pf_got_10_0>

000000000010b4e9 <pf_got_hint_10_0>:
  10b4e9:	41 0f 18 93 b0 3e fe 	prefetcht1 -0x1c150(%r11)
  10b4f0:	ff 

000000000010b4f1 <pf_got_hint_10_1>:
  10b4f1:	41 0f 18 93 70 46 fe 	prefetcht1 -0x1b990(%r11)
  10b4f8:	ff 
  10b4f9:	41 5b                	pop    %r11

000000000010b4fb <pf_jump_10>:
  10b4fb:	e9 60 c6 f1 ff       	jmp    27b60 <pf_callee_10>

000000000010b500 <pf_call_11>:
  10b500:	0f 18 15 a9 19 f4 ff 	prefetcht1 -0xbe657(%rip)        # 4ceb0 <pf_target_11_0>
  10b507:	0f 18 15 d2 d2 f3 ff 	prefetcht1 -0xc2d2e(%rip)        # 487e0 <pf_target_11_1>

000000000010b50e <pf_jump_11>:
  10b50e:	e9 cd 1e f4 ff       	jmp    4d3e0 <pf_callee_11>
  10b513:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b51a:	00 00 00 
  10b51d:	0f 1f 00             	nopl   (%rax)

000000000010b520 <pf_call_12>:
  10b520:	0f 18 15 e9 23 f4 ff 	prefetcht1 -0xbdc17(%rip)        # 4d910 <pf_target_12_0>

000000000010b527 <pf_jump_12>:
  10b527:	e9 74 cb f1 ff       	jmp    280a0 <pf_callee_12>
  10b52c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b530 <pf_call_13>:
  10b530:	0f 18 15 09 c4 f5 ff 	prefetcht1 -0xa3bf7(%rip)        # 67940 <pf_target_13_0>
  10b537:	0f 18 15 e2 c3 f5 ff 	prefetcht1 -0xa3c1e(%rip)        # 67920 <pf_target_13_1>
  10b53e:	0f 18 15 fb b8 f5 ff 	prefetcht1 -0xa4705(%rip)        # 66e40 <pf_target_13_2>

000000000010b545 <pf_jump_13>:
  10b545:	e9 66 bc f1 ff       	jmp    271b0 <pf_callee_13>
  10b54a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000010b550 <pf_call_14>:
  10b550:	0f 18 15 55 3a f6 ff 	prefetcht1 -0x9c5ab(%rip)        # 6efac <pf_target_14_0>
  10b557:	0f 18 15 72 04 f6 ff 	prefetcht1 -0x9fb8e(%rip)        # 6b9d0 <pf_target_14_1>
  10b55e:	0f 18 15 5b ce f1 ff 	prefetcht1 -0xe31a5(%rip)        # 283c0 <pf_callee_16>

000000000010b565 <pf_jump_14>:
  10b565:	e9 86 c8 f5 ff       	jmp    67df0 <pf_callee_14>
  10b56a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000010b570 <pf_call_15>:
  10b570:	0f 18 15 d9 cd f1 ff 	prefetcht1 -0xe3227(%rip)        # 28350 <pf_target_15_0>
  10b577:	0f 18 15 f2 60 f4 ff 	prefetcht1 -0xb9f0e(%rip)        # 51670 <pf_target_15_1>
  10b57e:	41 53                	push   %r11
  10b580:	4c 8b 1d 21 e4 ff ff 	mov    -0x1bdf(%rip),%r11        # 1099a8 <pf_got_15_0>

000000000010b587 <pf_got_hint_15_0>:
  10b587:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b58e:	00 
  10b58f:	41 5b                	pop    %r11

000000000010b591 <pf_jump_15>:
  10b591:	e9 0a 42 f6 ff       	jmp    6f7a0 <pf_callee_15>
  10b596:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b59d:	00 00 00 

000000000010b5a0 <pf_call_16>:
  10b5a0:	0f 18 15 59 0a f6 ff 	prefetcht1 -0x9f5a7(%rip)        # 6c000 <pf_target_16_0>

000000000010b5a7 <pf_jump_16>:
  10b5a7:	e9 14 ce f1 ff       	jmp    283c0 <pf_callee_16>
  10b5ac:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b5b0 <pf_call_17>:
  10b5b0:	0f 18 15 19 bd f5 ff 	prefetcht1 -0xa42e7(%rip)        # 672d0 <pf_target_17_0>

000000000010b5b7 <pf_jump_17>:
  10b5b7:	e9 04 ce f1 ff       	jmp    283c0 <pf_callee_16>
  10b5bc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b5c0 <pf_call_18>:
  10b5c0:	0f 18 15 09 c1 f5 ff 	prefetcht1 -0xa3ef7(%rip)        # 676d0 <pf_target_18_0>

000000000010b5c7 <pf_jump_18>:
  10b5c7:	e9 24 d1 f5 ff       	jmp    686f0 <pf_callee_18>
  10b5cc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b5d0 <pf_call_19>:
  10b5d0:	0f 18 15 89 39 f6 ff 	prefetcht1 -0x9c677(%rip)        # 6ef60 <pf_target_19_0>

000000000010b5d7 <pf_jump_19>:
  10b5d7:	e9 e4 5a f6 ff       	jmp    710c0 <pf_callee_19>
