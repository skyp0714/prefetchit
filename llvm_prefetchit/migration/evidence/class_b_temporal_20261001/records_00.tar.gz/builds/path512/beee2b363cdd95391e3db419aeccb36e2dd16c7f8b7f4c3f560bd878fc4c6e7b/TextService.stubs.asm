
/storage/prefetchit/class_b_temporal_20261001/builds/path512/beee2b363cdd95391e3db419aeccb36e2dd16c7f8b7f4c3f560bd878fc4c6e7b/call-stub-3y48k37z/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000110340 <pf_call_0>:
  110340:	0f 18 15 e9 88 f3 ff 	prefetcht1 -0xc7717(%rip)        # 48c30 <pf_target_0_0>
  110347:	0f 18 15 62 31 f3 ff 	prefetcht1 -0xcce9e(%rip)        # 434b0 <pf_target_0_1>
  11034e:	0f 18 15 af 31 f3 ff 	prefetcht1 -0xcce51(%rip)        # 43504 <pf_target_0_2>
  110355:	0f 18 15 c4 3b f3 ff 	prefetcht1 -0xcc43c(%rip)        # 43f20 <pf_target_0_3>

000000000011035c <pf_jump_0>:
  11035c:	e9 bf 5f f1 ff       	jmp    26320 <pf_callee_0>
  110361:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  110368:	00 00 00 
  11036b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000110370 <pf_call_1>:
  110370:	0f 18 15 89 8c f5 ff 	prefetcht1 -0xa7377(%rip)        # 69000 <pf_target_1_0>
  110377:	0f 18 15 52 be f4 ff 	prefetcht1 -0xb41ae(%rip)        # 5c1d0 <pf_target_1_1>

000000000011037e <pf_jump_1>:
  11037e:	e9 4d 07 f2 ff       	jmp    30ad0 <pf_callee_1>
  110383:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11038a:	00 00 00 
  11038d:	0f 1f 00             	nopl   (%rax)

0000000000110390 <pf_call_2>:
  110390:	0f 18 15 c9 be f4 ff 	prefetcht1 -0xb4137(%rip)        # 5c260 <pf_target_2_0>

0000000000110397 <pf_jump_2>:
  110397:	e9 74 5f f1 ff       	jmp    26310 <pf_callee_2>
  11039c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001103a0 <pf_call_3>:
  1103a0:	0f 18 15 5d 3c f3 ff 	prefetcht1 -0xcc3a3(%rip)        # 44004 <pf_target_3_0>

00000000001103a7 <pf_jump_3>:
  1103a7:	e9 14 5e f1 ff       	jmp    261c0 <pf_callee_3>
  1103ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001103b0 <pf_call_4>:
  1103b0:	41 53                	push   %r11
  1103b2:	4c 8b 1d d7 e3 ff ff 	mov    -0x1c29(%rip),%r11        # 10e790 <pf_got_4_0>

00000000001103b9 <pf_got_hint_4_0>:
  1103b9:	41 0f 18 93 20 26 ff 	prefetcht1 -0xd9e0(%r11)
  1103c0:	ff 

00000000001103c1 <pf_got_hint_4_1>:
  1103c1:	41 0f 18 93 10 29 ff 	prefetcht1 -0xd6f0(%r11)
  1103c8:	ff 
  1103c9:	41 5b                	pop    %r11

00000000001103cb <pf_jump_4>:
  1103cb:	e9 00 53 f3 ff       	jmp    456d0 <pf_callee_4>

00000000001103d0 <pf_call_5>:
  1103d0:	41 53                	push   %r11
  1103d2:	4c 8b 1d 57 e1 ff ff 	mov    -0x1ea9(%rip),%r11        # 10e530 <pf_got_5_0>

00000000001103d9 <pf_got_hint_5_0>:
  1103d9:	41 0f 18 93 22 fd ff 	prefetcht1 -0x2de(%r11)
  1103e0:	ff 
  1103e1:	41 5b                	pop    %r11

00000000001103e3 <pf_jump_5>:
  1103e3:	e9 f8 65 f1 ff       	jmp    269e0 <pf_callee_5>
  1103e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1103ef:	00 

00000000001103f0 <pf_call_6>:
  1103f0:	0f 18 15 39 62 f1 ff 	prefetcht1 -0xe9dc7(%rip)        # 26630 <pf_target_6_0>
  1103f7:	41 53                	push   %r11
  1103f9:	4c 8b 1d 18 df ff ff 	mov    -0x20e8(%rip),%r11        # 10e318 <pf_got_6_0>

0000000000110400 <pf_got_hint_6_0>:
  110400:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110407:	00 

0000000000110408 <pf_got_hint_6_1>:
  110408:	41 0f 18 93 11 00 00 	prefetcht1 0x11(%r11)
  11040f:	00 
  110410:	41 5b                	pop    %r11

0000000000110412 <pf_jump_6>:
  110412:	e9 d9 5c f1 ff       	jmp    260f0 <pf_callee_6>
  110417:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  11041e:	00 00 

0000000000110420 <pf_call_7>:
  110420:	41 53                	push   %r11
  110422:	4c 8b 1d 67 e3 ff ff 	mov    -0x1c99(%rip),%r11        # 10e790 <pf_got_4_0>

0000000000110429 <pf_got_hint_7_0>:
  110429:	41 0f 18 93 70 46 fe 	prefetcht1 -0x1b990(%r11)
  110430:	ff 
  110431:	41 5b                	pop    %r11

0000000000110433 <pf_jump_7>:
  110433:	e9 f8 64 f1 ff       	jmp    26930 <pf_callee_7>
  110438:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11043f:	00 

0000000000110440 <pf_call_8>:
  110440:	0f 18 15 09 ff f2 ff 	prefetcht1 -0xd00f7(%rip)        # 40350 <pf_callee_9>

0000000000110447 <pf_jump_8>:
  110447:	e9 04 4b f3 ff       	jmp    44f50 <pf_callee_8>
  11044c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110450 <pf_call_9>:
  110450:	41 53                	push   %r11
  110452:	4c 8b 1d d7 e0 ff ff 	mov    -0x1f29(%rip),%r11        # 10e530 <pf_got_5_0>

0000000000110459 <pf_got_hint_9_0>:
  110459:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110460:	00 
  110461:	41 5b                	pop    %r11

0000000000110463 <pf_jump_9>:
  110463:	e9 e8 fe f2 ff       	jmp    40350 <pf_callee_9>
  110468:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11046f:	00 

0000000000110470 <pf_call_10>:
  110470:	0f 18 15 39 50 f3 ff 	prefetcht1 -0xcafc7(%rip)        # 454b0 <pf_target_10_0>

0000000000110477 <pf_jump_10>:
  110477:	e9 74 69 f1 ff       	jmp    26df0 <pf_callee_10>
  11047c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110480 <pf_call_11>:
  110480:	0f 18 15 70 35 f5 ff 	prefetcht1 -0xaca90(%rip)        # 639f7 <pf_target_11_0>
  110487:	0f 18 15 32 cb f4 ff 	prefetcht1 -0xb34ce(%rip)        # 5cfc0 <pf_target_11_1>

000000000011048e <pf_jump_11>:
  11048e:	e9 ad 5c f1 ff       	jmp    26140 <pf_callee_11>
  110493:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11049a:	00 00 00 
  11049d:	0f 1f 00             	nopl   (%rax)

00000000001104a0 <pf_call_12>:
  1104a0:	0f 18 15 e9 6b f1 ff 	prefetcht1 -0xe9417(%rip)        # 27090 <pf_callee_15>
  1104a7:	0f 18 15 d2 12 f5 ff 	prefetcht1 -0xaed2e(%rip)        # 61780 <pf_target_12_1>
  1104ae:	0f 18 15 17 35 f5 ff 	prefetcht1 -0xacae9(%rip)        # 639cc <pf_target_12_2>
  1104b5:	0f 18 15 14 69 f1 ff 	prefetcht1 -0xe96ec(%rip)        # 26dd0 <pf_callee_18>

00000000001104bc <pf_jump_12>:
  1104bc:	e9 cf cf f4 ff       	jmp    5d490 <pf_callee_12>
  1104c1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1104c8:	00 00 00 
  1104cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000001104d0 <pf_call_13>:
  1104d0:	41 53                	push   %r11
  1104d2:	4c 8b 1d 0f e2 ff ff 	mov    -0x1df1(%rip),%r11        # 10e6e8 <pf_got_13_0>

00000000001104d9 <pf_got_hint_13_0>:
  1104d9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1104e0:	00 
  1104e1:	41 5b                	pop    %r11

00000000001104e3 <pf_jump_13>:
  1104e3:	e9 f8 61 f1 ff       	jmp    266e0 <pf_callee_13>
  1104e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1104ef:	00 

00000000001104f0 <pf_call_14>:
  1104f0:	0f 18 15 29 6b f1 ff 	prefetcht1 -0xe94d7(%rip)        # 27020 <pf_target_14_0>
  1104f7:	0f 18 15 82 8d f3 ff 	prefetcht1 -0xc727e(%rip)        # 49280 <pf_target_14_1>

00000000001104fe <pf_jump_14>:
  1104fe:	e9 bd 3c f5 ff       	jmp    641c0 <pf_callee_14>
  110503:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11050a:	00 00 00 
  11050d:	0f 1f 00             	nopl   (%rax)

0000000000110510 <pf_call_15>:
  110510:	0f 18 15 79 fc f4 ff 	prefetcht1 -0xb0387(%rip)        # 60190 <pf_callee_16>
  110517:	0f 18 15 92 18 f5 ff 	prefetcht1 -0xae76e(%rip)        # 61db0 <pf_target_15_1>
  11051e:	0f 18 15 4b c4 f4 ff 	prefetcht1 -0xb3bb5(%rip)        # 5c970 <pf_target_15_2>

0000000000110525 <pf_jump_15>:
  110525:	e9 66 6b f1 ff       	jmp    27090 <pf_callee_15>
  11052a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000110530 <pf_call_16>:
  110530:	0f 18 15 39 c8 f4 ff 	prefetcht1 -0xb37c7(%rip)        # 5cd70 <pf_target_16_0>

0000000000110537 <pf_jump_16>:
  110537:	e9 54 fc f4 ff       	jmp    60190 <pf_callee_16>
  11053c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110540 <pf_call_17>:
  110540:	0f 18 15 39 34 f5 ff 	prefetcht1 -0xacbc7(%rip)        # 63980 <pf_target_17_0>

0000000000110547 <pf_jump_17>:
  110547:	e9 f4 5b f1 ff       	jmp    26140 <pf_callee_11>
  11054c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110550 <pf_call_18>:
  110550:	0f 18 15 99 4e f5 ff 	prefetcht1 -0xab167(%rip)        # 653f0 <pf_target_18_0>
  110557:	41 53                	push   %r11
  110559:	4c 8b 1d 40 db ff ff 	mov    -0x24c0(%rip),%r11        # 10e0a0 <pf_got_18_0>

0000000000110560 <pf_got_hint_18_0>:
  110560:	41 0f 18 93 e0 48 ff 	prefetcht1 -0xb720(%r11)
  110567:	ff 
  110568:	41 5b                	pop    %r11

000000000011056a <pf_jump_18>:
  11056a:	e9 61 68 f1 ff       	jmp    26dd0 <pf_callee_18>
