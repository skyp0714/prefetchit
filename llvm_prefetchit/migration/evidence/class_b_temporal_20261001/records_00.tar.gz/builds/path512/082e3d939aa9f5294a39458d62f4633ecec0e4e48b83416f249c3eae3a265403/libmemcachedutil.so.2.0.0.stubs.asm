
/storage/prefetchit/class_b_temporal_20261001/builds/path512/082e3d939aa9f5294a39458d62f4633ecec0e4e48b83416f249c3eae3a265403/call-stub-peuriukc/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000072c0 <pf_call_0>:
    72c0:	0f 18 15 f9 af ff ff 	prefetcht1 -0x5007(%rip)        # 22c0 <pf_target_0_0>

00000000000072c7 <pf_jump_0>:
    72c7:	e9 74 b2 ff ff       	jmp    2540 <pf_callee_0>
    72cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000072d0 <pf_call_1>:
    72d0:	41 53                	push   %r11
    72d2:	4c 8b 1d df ed ff ff 	mov    -0x1221(%rip),%r11        # 60b8 <pf_got_1_0>

00000000000072d9 <pf_got_hint_1_0>:
    72d9:	41 0f 18 93 30 e5 ff 	prefetcht1 -0x1ad0(%r11)
    72e0:	ff 
    72e1:	41 5b                	pop    %r11

00000000000072e3 <pf_jump_1>:
    72e3:	e9 b8 b0 ff ff       	jmp    23a0 <pf_callee_1>
