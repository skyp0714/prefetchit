.text
.balign 16
.global pf_call_0
.type pf_call_0,@function
pf_call_0:
.cfi_startproc
prefetcht1 pf_target_0_0(%rip)
.global pf_jump_0
pf_jump_0:
jmp pf_callee_0
.cfi_endproc
.size pf_call_0,.-pf_call_0
.balign 16
.global pf_call_1
.type pf_call_1,@function
pf_call_1:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_1_0(%rip),%r11
.global pf_got_hint_1_0
pf_got_hint_1_0:
.byte 0x41,0x0f,0x18,0x93
.long -6864
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_1
pf_jump_1:
jmp pf_callee_1
.cfi_endproc
.size pf_call_1,.-pf_call_1
.section .note.GNU-stack,"",@progbits
