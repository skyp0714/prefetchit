
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide/beee2b363cdd95391e3db419aeccb36e2dd16c7f8b7f4c3f560bd878fc4c6e7b/call-stub-x1sve4v7/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000110340 <pf_call_0>:
  110340:	0f 18 15 e9 88 f3 ff 	prefetcht1 -0xc7717(%rip)        # 48c30 <pf_target_0_0>
  110347:	0f 18 15 62 31 f3 ff 	prefetcht1 -0xcce9e(%rip)        # 434b0 <pf_target_0_1>
  11034e:	0f 18 15 af 31 f3 ff 	prefetcht1 -0xcce51(%rip)        # 43504 <pf_target_0_2>
  110355:	0f 18 15 c4 3b f3 ff 	prefetcht1 -0xcc43c(%rip)        # 43f20 <pf_target_0_3>
  11035c:	0f 18 15 a1 3c f3 ff 	prefetcht1 -0xcc35f(%rip)        # 44004 <pf_target_0_4>
  110363:	0f 18 15 d8 88 f3 ff 	prefetcht1 -0xc7728(%rip)        # 48c42 <pf_target_0_5>
  11036a:	0f 18 15 11 89 f3 ff 	prefetcht1 -0xc76ef(%rip)        # 48c82 <pf_target_0_6>
  110371:	0f 18 15 4a 32 f3 ff 	prefetcht1 -0xccdb6(%rip)        # 435c2 <pf_target_0_7>

0000000000110378 <pf_jump_0>:
  110378:	e9 a3 5f f1 ff       	jmp    26320 <pf_callee_0>
  11037d:	0f 1f 00             	nopl   (%rax)

0000000000110380 <pf_call_1>:
  110380:	0f 18 15 19 06 f2 ff 	prefetcht1 -0xdf9e7(%rip)        # 309a0 <pf_target_1_0>
  110387:	41 53                	push   %r11
  110389:	4c 8b 1d 50 dd ff ff 	mov    -0x22b0(%rip),%r11        # 10e0e0 <pf_got_1_0>

0000000000110390 <pf_got_hint_1_0>:
  110390:	41 0f 18 93 b0 06 00 	prefetcht1 0x6b0(%r11)
  110397:	00 

0000000000110398 <pf_got_hint_1_1>:
  110398:	41 0f 18 93 d2 06 00 	prefetcht1 0x6d2(%r11)
  11039f:	00 
  1103a0:	4c 8b 1d f1 e0 ff ff 	mov    -0x1f0f(%rip),%r11        # 10e498 <pf_got_17_0>

00000000001103a7 <pf_got_hint_1_2>:
  1103a7:	41 0f 18 93 10 5d fe 	prefetcht1 -0x1a2f0(%r11)
  1103ae:	ff 
  1103af:	41 5b                	pop    %r11

00000000001103b1 <pf_jump_1>:
  1103b1:	e9 6a 5f f1 ff       	jmp    26320 <pf_callee_0>
  1103b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1103bd:	00 00 00 

00000000001103c0 <pf_call_2>:
  1103c0:	41 53                	push   %r11
  1103c2:	4c 8b 1d cf e0 ff ff 	mov    -0x1f31(%rip),%r11        # 10e498 <pf_got_17_0>

00000000001103c9 <pf_got_hint_2_0>:
  1103c9:	41 0f 18 93 50 79 00 	prefetcht1 0x7950(%r11)
  1103d0:	00 
  1103d1:	4c 8b 1d 70 e3 ff ff 	mov    -0x1c90(%rip),%r11        # 10e748 <pf_got_2_1>

00000000001103d8 <pf_got_hint_2_1>:
  1103d8:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1103df:	00 

00000000001103e0 <pf_got_hint_2_2>:
  1103e0:	41 0f 18 93 34 00 00 	prefetcht1 0x34(%r11)
  1103e7:	00 
  1103e8:	41 5b                	pop    %r11

00000000001103ea <pf_jump_2>:
  1103ea:	e9 31 5f f1 ff       	jmp    26320 <pf_callee_0>
  1103ef:	90                   	nop

00000000001103f0 <pf_call_3>:
  1103f0:	0f 18 15 09 8c f5 ff 	prefetcht1 -0xa73f7(%rip)        # 69000 <pf_target_3_0>
  1103f7:	0f 18 15 d2 bd f4 ff 	prefetcht1 -0xb422e(%rip)        # 5c1d0 <pf_target_3_1>

00000000001103fe <pf_jump_3>:
  1103fe:	e9 cd 06 f2 ff       	jmp    30ad0 <pf_callee_3>
  110403:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11040a:	00 00 00 
  11040d:	0f 1f 00             	nopl   (%rax)

0000000000110410 <pf_call_4>:
  110410:	41 53                	push   %r11
  110412:	4c 8b 1d 7f e0 ff ff 	mov    -0x1f81(%rip),%r11        # 10e498 <pf_got_17_0>

0000000000110419 <pf_got_hint_4_0>:
  110419:	41 0f 18 93 c1 af ff 	prefetcht1 -0x503f(%r11)
  110420:	ff 
  110421:	41 5b                	pop    %r11

0000000000110423 <pf_jump_4>:
  110423:	e9 58 6a f1 ff       	jmp    26e80 <pf_callee_4>
  110428:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11042f:	00 

0000000000110430 <pf_call_5>:
  110430:	0f 18 15 2f 95 f3 ff 	prefetcht1 -0xc6ad1(%rip)        # 49966 <pf_target_5_0>
  110437:	41 53                	push   %r11
  110439:	4c 8b 1d 58 e0 ff ff 	mov    -0x1fa8(%rip),%r11        # 10e498 <pf_got_17_0>

0000000000110440 <pf_got_hint_5_0>:
  110440:	41 0f 18 93 30 f5 ff 	prefetcht1 -0xad0(%r11)
  110447:	ff 

0000000000110448 <pf_got_hint_5_1>:
  110448:	41 0f 18 93 41 f5 ff 	prefetcht1 -0xabf(%r11)
  11044f:	ff 
  110450:	41 5b                	pop    %r11

0000000000110452 <pf_jump_5>:
  110452:	e9 59 94 f3 ff       	jmp    498b0 <pf_callee_5>
  110457:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  11045e:	00 00 

0000000000110460 <pf_call_6>:
  110460:	0f 18 15 f9 bd f4 ff 	prefetcht1 -0xb4207(%rip)        # 5c260 <pf_target_6_0>
  110467:	41 53                	push   %r11
  110469:	4c 8b 1d b8 df ff ff 	mov    -0x2048(%rip),%r11        # 10e428 <pf_got_6_0>

0000000000110470 <pf_got_hint_6_0>:
  110470:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110477:	00 
  110478:	41 5b                	pop    %r11

000000000011047a <pf_jump_6>:
  11047a:	e9 91 5e f1 ff       	jmp    26310 <pf_callee_6>
  11047f:	90                   	nop

0000000000110480 <pf_call_7>:
  110480:	0f 18 15 79 31 f3 ff 	prefetcht1 -0xcce87(%rip)        # 43600 <pf_target_7_0>

0000000000110487 <pf_jump_7>:
  110487:	e9 34 5d f1 ff       	jmp    261c0 <pf_callee_7>
  11048c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110490 <pf_call_8>:
  110490:	41 53                	push   %r11
  110492:	4c 8b 1d ff df ff ff 	mov    -0x2001(%rip),%r11        # 10e498 <pf_got_17_0>

0000000000110499 <pf_got_hint_8_0>:
  110499:	41 0f 18 93 20 6f fe 	prefetcht1 -0x190e0(%r11)
  1104a0:	ff 
  1104a1:	41 5b                	pop    %r11

00000000001104a3 <pf_jump_8>:
  1104a3:	e9 a8 37 f3 ff       	jmp    43c50 <pf_callee_8>
  1104a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1104af:	00 

00000000001104b0 <pf_call_9>:
  1104b0:	41 53                	push   %r11
  1104b2:	4c 8b 1d bf de ff ff 	mov    -0x2141(%rip),%r11        # 10e378 <pf_got_9_0>

00000000001104b9 <pf_got_hint_9_0>:
  1104b9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1104c0:	00 
  1104c1:	4c 8b 1d c8 e2 ff ff 	mov    -0x1d38(%rip),%r11        # 10e790 <pf_got_17_3>

00000000001104c8 <pf_got_hint_9_1>:
  1104c8:	41 0f 18 93 70 e8 fe 	prefetcht1 -0x11790(%r11)
  1104cf:	ff 

00000000001104d0 <pf_got_hint_9_2>:
  1104d0:	41 0f 18 93 20 26 ff 	prefetcht1 -0xd9e0(%r11)
  1104d7:	ff 

00000000001104d8 <pf_got_hint_9_3>:
  1104d8:	41 0f 18 93 31 26 ff 	prefetcht1 -0xd9cf(%r11)
  1104df:	ff 

00000000001104e0 <pf_got_hint_9_4>:
  1104e0:	41 0f 18 93 10 29 ff 	prefetcht1 -0xd6f0(%r11)
  1104e7:	ff 

00000000001104e8 <pf_got_hint_9_5>:
  1104e8:	41 0f 18 93 a0 f5 ff 	prefetcht1 -0xa60(%r11)
  1104ef:	ff 

00000000001104f0 <pf_got_hint_9_6>:
  1104f0:	41 0f 18 93 b0 f5 ff 	prefetcht1 -0xa50(%r11)
  1104f7:	ff 
  1104f8:	41 5b                	pop    %r11

00000000001104fa <pf_jump_9>:
  1104fa:	e9 d1 51 f3 ff       	jmp    456d0 <pf_callee_9>
  1104ff:	90                   	nop

0000000000110500 <pf_call_10>:
  110500:	0f 18 15 29 61 f1 ff 	prefetcht1 -0xe9ed7(%rip)        # 26630 <pf_target_10_0>
  110507:	41 53                	push   %r11
  110509:	4c 8b 1d 08 de ff ff 	mov    -0x21f8(%rip),%r11        # 10e318 <pf_got_10_0>

0000000000110510 <pf_got_hint_10_0>:
  110510:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110517:	00 

0000000000110518 <pf_got_hint_10_1>:
  110518:	41 0f 18 93 11 00 00 	prefetcht1 0x11(%r11)
  11051f:	00 
  110520:	41 5b                	pop    %r11

0000000000110522 <pf_jump_10>:
  110522:	e9 b9 64 f1 ff       	jmp    269e0 <pf_callee_10>
  110527:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  11052e:	00 00 

0000000000110530 <pf_call_11>:
  110530:	41 53                	push   %r11
  110532:	4c 8b 1d 67 db ff ff 	mov    -0x2499(%rip),%r11        # 10e0a0 <pf_got_11_0>

0000000000110539 <pf_got_hint_11_0>:
  110539:	41 0f 18 93 20 4a ff 	prefetcht1 -0xb5e0(%r11)
  110540:	ff 
  110541:	41 5b                	pop    %r11

0000000000110543 <pf_jump_11>:
  110543:	e9 a8 5b f1 ff       	jmp    260f0 <pf_callee_11>
  110548:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11054f:	00 

0000000000110550 <pf_call_12>:
  110550:	0f 18 15 b9 35 f3 ff 	prefetcht1 -0xcca47(%rip)        # 43b10 <pf_target_12_0>

0000000000110557 <pf_jump_12>:
  110557:	e9 94 5b f1 ff       	jmp    260f0 <pf_callee_11>
  11055c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110560 <pf_call_13>:
  110560:	0f 18 15 19 94 f3 ff 	prefetcht1 -0xc6be7(%rip)        # 49980 <pf_callee_23>

0000000000110567 <pf_jump_13>:
  110567:	e9 e4 fd f2 ff       	jmp    40350 <pf_callee_13>
  11056c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110570 <pf_call_14>:
  110570:	0f 18 15 19 36 f3 ff 	prefetcht1 -0xcc9e7(%rip)        # 43b90 <pf_target_14_0>

0000000000110577 <pf_jump_14>:
  110577:	e9 54 3a f3 ff       	jmp    43fd0 <pf_callee_14>
  11057c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110580 <pf_call_15>:
  110580:	0f 18 15 29 4f f3 ff 	prefetcht1 -0xcb0d7(%rip)        # 454b0 <pf_target_15_0>

0000000000110587 <pf_jump_15>:
  110587:	e9 b4 5b f1 ff       	jmp    26140 <pf_callee_15>
  11058c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110590 <pf_call_16>:
  110590:	0f 18 15 59 68 f1 ff 	prefetcht1 -0xe97a7(%rip)        # 26df0 <pf_target_16_0>
  110597:	41 53                	push   %r11
  110599:	4c 8b 1d 58 e1 ff ff 	mov    -0x1ea8(%rip),%r11        # 10e6f8 <pf_got_16_0>

00000000001105a0 <pf_got_hint_16_0>:
  1105a0:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1105a7:	00 
  1105a8:	41 5b                	pop    %r11

00000000001105aa <pf_jump_16>:
  1105aa:	e9 91 5b f1 ff       	jmp    26140 <pf_callee_15>
  1105af:	90                   	nop

00000000001105b0 <pf_call_17>:
  1105b0:	41 53                	push   %r11
  1105b2:	4c 8b 1d df de ff ff 	mov    -0x2121(%rip),%r11        # 10e498 <pf_got_17_0>

00000000001105b9 <pf_got_hint_17_0>:
  1105b9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1105c0:	00 

00000000001105c1 <pf_got_hint_17_1>:
  1105c1:	41 0f 18 93 44 00 00 	prefetcht1 0x44(%r11)
  1105c8:	00 

00000000001105c9 <pf_got_hint_17_2>:
  1105c9:	41 0f 18 93 88 00 00 	prefetcht1 0x88(%r11)
  1105d0:	00 
  1105d1:	4c 8b 1d b8 e1 ff ff 	mov    -0x1e48(%rip),%r11        # 10e790 <pf_got_17_3>

00000000001105d8 <pf_got_hint_17_3>:
  1105d8:	41 0f 18 93 b0 3e fe 	prefetcht1 -0x1c150(%r11)
  1105df:	ff 

00000000001105e0 <pf_got_hint_17_4>:
  1105e0:	41 0f 18 93 40 46 fe 	prefetcht1 -0x1b9c0(%r11)
  1105e7:	ff 

00000000001105e8 <pf_got_hint_17_5>:
  1105e8:	41 0f 18 93 70 46 fe 	prefetcht1 -0x1b990(%r11)
  1105ef:	ff 
  1105f0:	41 5b                	pop    %r11

00000000001105f2 <pf_jump_17>:
  1105f2:	e9 39 63 f1 ff       	jmp    26930 <pf_callee_17>
  1105f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  1105fe:	00 00 

0000000000110600 <pf_call_18>:
  110600:	0f 18 15 49 fd f2 ff 	prefetcht1 -0xd02b7(%rip)        # 40350 <pf_callee_13>

0000000000110607 <pf_jump_18>:
  110607:	e9 44 49 f3 ff       	jmp    44f50 <pf_callee_18>
  11060c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110610 <pf_call_19>:
  110610:	0f 18 15 09 44 f3 ff 	prefetcht1 -0xcbbf7(%rip)        # 44a20 <pf_target_19_0>

0000000000110617 <pf_jump_19>:
  110617:	e9 34 fd f2 ff       	jmp    40350 <pf_callee_13>
  11061c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110620 <pf_call_20>:
  110620:	0f 18 15 29 69 f1 ff 	prefetcht1 -0xe96d7(%rip)        # 26f50 <pf_target_20_0>
  110627:	41 53                	push   %r11
  110629:	4c 8b 1d 00 df ff ff 	mov    -0x2100(%rip),%r11        # 10e530 <pf_got_20_0>

0000000000110630 <pf_got_hint_20_0>:
  110630:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110637:	00 
  110638:	41 5b                	pop    %r11

000000000011063a <pf_jump_20>:
  11063a:	e9 11 fd f2 ff       	jmp    40350 <pf_callee_13>
  11063f:	90                   	nop

0000000000110640 <pf_call_21>:
  110640:	0f 18 15 d9 69 f1 ff 	prefetcht1 -0xe9627(%rip)        # 27020 <pf_target_21_0>
  110647:	41 53                	push   %r11
  110649:	4c 8b 1d c0 e1 ff ff 	mov    -0x1e40(%rip),%r11        # 10e810 <pf_got_21_0>

0000000000110650 <pf_got_hint_21_0>:
  110650:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110657:	00 
  110658:	41 5b                	pop    %r11

000000000011065a <pf_jump_21>:
  11065a:	e9 01 8f f3 ff       	jmp    49560 <pf_callee_21>
  11065f:	90                   	nop

0000000000110660 <pf_call_22>:
  110660:	0f 18 15 2e 16 f5 ff 	prefetcht1 -0xae9d2(%rip)        # 61c95 <pf_target_22_0>
  110667:	0f 18 15 89 33 f5 ff 	prefetcht1 -0xacc77(%rip)        # 639f7 <pf_target_22_1>
  11066e:	0f 18 15 4b c9 f4 ff 	prefetcht1 -0xb36b5(%rip)        # 5cfc0 <pf_target_22_2>
  110675:	0f 18 15 64 be f4 ff 	prefetcht1 -0xb419c(%rip)        # 5c4e0 <pf_target_22_3>
  11067c:	0f 18 15 43 12 f5 ff 	prefetcht1 -0xaedbd(%rip)        # 618c6 <pf_target_22_4>

0000000000110683 <pf_jump_22>:
  110683:	e9 b8 5a f1 ff       	jmp    26140 <pf_callee_15>
  110688:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11068f:	00 

0000000000110690 <pf_call_23>:
  110690:	0f 18 15 c6 19 f5 ff 	prefetcht1 -0xae63a(%rip)        # 6205d <pf_target_23_0>

0000000000110697 <pf_jump_23>:
  110697:	e9 e4 92 f3 ff       	jmp    49980 <pf_callee_23>
  11069c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001106a0 <pf_call_24>:
  1106a0:	0f 18 15 c9 c6 f4 ff 	prefetcht1 -0xb3937(%rip)        # 5cd70 <pf_target_24_0>

00000000001106a7 <pf_jump_24>:
  1106a7:	e9 34 60 f1 ff       	jmp    266e0 <pf_callee_24>
  1106ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001106b0 <pf_call_25>:
  1106b0:	0f 18 15 09 3b f5 ff 	prefetcht1 -0xac4f7(%rip)        # 641c0 <pf_callee_28>
  1106b7:	41 53                	push   %r11
  1106b9:	4c 8b 1d e0 d9 ff ff 	mov    -0x2620(%rip),%r11        # 10e0a0 <pf_got_11_0>

00000000001106c0 <pf_got_hint_25_0>:
  1106c0:	41 0f 18 93 b0 53 ff 	prefetcht1 -0xac50(%r11)
  1106c7:	ff 
  1106c8:	4c 8b 1d 11 da ff ff 	mov    -0x25ef(%rip),%r11        # 10e0e0 <pf_got_1_0>

00000000001106cf <pf_got_hint_25_1>:
  1106cf:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1106d6:	00 
  1106d7:	4c 8b 1d 12 de ff ff 	mov    -0x21ee(%rip),%r11        # 10e4f0 <pf_got_25_2>

00000000001106de <pf_got_hint_25_2>:
  1106de:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1106e5:	00 
  1106e6:	41 5b                	pop    %r11

00000000001106e8 <pf_jump_25>:
  1106e8:	e9 a3 cd f4 ff       	jmp    5d490 <pf_callee_25>
  1106ed:	0f 1f 00             	nopl   (%rax)

00000000001106f0 <pf_call_26>:
  1106f0:	0f 18 15 e9 5f f1 ff 	prefetcht1 -0xea017(%rip)        # 266e0 <pf_callee_24>
  1106f7:	0f 18 15 92 69 f1 ff 	prefetcht1 -0xe966e(%rip)        # 27090 <pf_callee_29>
  1106fe:	0f 18 15 7b 10 f5 ff 	prefetcht1 -0xaef85(%rip)        # 61780 <pf_target_26_2>
  110705:	0f 18 15 c0 32 f5 ff 	prefetcht1 -0xacd40(%rip)        # 639cc <pf_target_26_3>
  11070c:	0f 18 15 bd 66 f1 ff 	prefetcht1 -0xe9943(%rip)        # 26dd0 <pf_callee_31>
  110713:	0f 18 15 b5 8b f5 ff 	prefetcht1 -0xa744b(%rip)        # 692cf <pf_target_26_5>
  11071a:	41 53                	push   %r11
  11071c:	4c 8b 1d 4d dc ff ff 	mov    -0x23b3(%rip),%r11        # 10e370 <pf_got_26_0>

0000000000110723 <pf_got_hint_26_0>:
  110723:	41 0f 18 93 10 00 00 	prefetcht1 0x10(%r11)
  11072a:	00 

000000000011072b <pf_got_hint_26_1>:
  11072b:	41 0f 18 93 d8 01 00 	prefetcht1 0x1d8(%r11)
  110732:	00 
  110733:	41 5b                	pop    %r11

0000000000110735 <pf_jump_26>:
  110735:	e9 56 cd f4 ff       	jmp    5d490 <pf_callee_25>
  11073a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000110740 <pf_call_27>:
  110740:	41 53                	push   %r11
  110742:	4c 8b 1d 9f df ff ff 	mov    -0x2061(%rip),%r11        # 10e6e8 <pf_got_27_0>

0000000000110749 <pf_got_hint_27_0>:
  110749:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110750:	00 
  110751:	41 5b                	pop    %r11

0000000000110753 <pf_jump_27>:
  110753:	e9 88 5f f1 ff       	jmp    266e0 <pf_callee_24>
  110758:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11075f:	00 

0000000000110760 <pf_call_28>:
  110760:	0f 18 15 19 8b f3 ff 	prefetcht1 -0xc74e7(%rip)        # 49280 <pf_target_28_0>
  110767:	0f 18 15 0b 8f f3 ff 	prefetcht1 -0xc70f5(%rip)        # 49679 <pf_target_28_1>
  11076e:	0f 18 15 0c 8f f3 ff 	prefetcht1 -0xc70f4(%rip)        # 49681 <pf_target_28_2>

0000000000110775 <pf_jump_28>:
  110775:	e9 46 3a f5 ff       	jmp    641c0 <pf_callee_28>
  11077a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000110780 <pf_call_29>:
  110780:	0f 18 15 29 16 f5 ff 	prefetcht1 -0xae9d7(%rip)        # 61db0 <pf_target_29_0>
  110787:	0f 18 15 02 fa f4 ff 	prefetcht1 -0xb05fe(%rip)        # 60190 <pf_target_29_1>
  11078e:	0f 18 15 db c1 f4 ff 	prefetcht1 -0xb3e25(%rip)        # 5c970 <pf_target_29_2>
  110795:	0f 18 15 25 16 f5 ff 	prefetcht1 -0xae9db(%rip)        # 61dc1 <pf_target_29_3>

000000000011079c <pf_jump_29>:
  11079c:	e9 ef 68 f1 ff       	jmp    27090 <pf_callee_29>
  1107a1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1107a8:	00 00 00 
  1107ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000001107b0 <pf_call_30>:
  1107b0:	0f 18 15 c9 31 f5 ff 	prefetcht1 -0xace37(%rip)        # 63980 <pf_target_30_0>

00000000001107b7 <pf_jump_30>:
  1107b7:	e9 84 59 f1 ff       	jmp    26140 <pf_callee_15>
  1107bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001107c0 <pf_call_31>:
  1107c0:	0f 18 15 29 4c f5 ff 	prefetcht1 -0xab3d7(%rip)        # 653f0 <pf_target_31_0>
  1107c7:	41 53                	push   %r11
  1107c9:	4c 8b 1d d0 d8 ff ff 	mov    -0x2730(%rip),%r11        # 10e0a0 <pf_got_11_0>

00000000001107d0 <pf_got_hint_31_0>:
  1107d0:	41 0f 18 93 e0 48 ff 	prefetcht1 -0xb720(%r11)
  1107d7:	ff 
  1107d8:	4c 8b 1d 09 df ff ff 	mov    -0x20f7(%rip),%r11        # 10e6e8 <pf_got_27_0>

00000000001107df <pf_got_hint_31_1>:
  1107df:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1107e6:	00 
  1107e7:	41 5b                	pop    %r11

00000000001107e9 <pf_jump_31>:
  1107e9:	e9 e2 65 f1 ff       	jmp    26dd0 <pf_callee_31>
  1107ee:	66 90                	xchg   %ax,%ax

00000000001107f0 <pf_call_32>:
  1107f0:	0f 18 15 ea da f1 ff 	prefetcht1 -0xe2516(%rip)        # 2e2e1 <pf_target_32_0>
  1107f7:	0f 18 15 46 0e f2 ff 	prefetcht1 -0xdf1ba(%rip)        # 31644 <pf_target_32_1>
  1107fe:	41 53                	push   %r11
  110800:	4c 8b 1d 61 d8 ff ff 	mov    -0x279f(%rip),%r11        # 10e068 <pf_got_32_0>

0000000000110807 <pf_got_hint_32_0>:
  110807:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  11080e:	00 
  11080f:	41 5b                	pop    %r11

0000000000110811 <pf_jump_32>:
  110811:	e9 ea 83 f6 ff       	jmp    78c00 <pf_callee_32>
