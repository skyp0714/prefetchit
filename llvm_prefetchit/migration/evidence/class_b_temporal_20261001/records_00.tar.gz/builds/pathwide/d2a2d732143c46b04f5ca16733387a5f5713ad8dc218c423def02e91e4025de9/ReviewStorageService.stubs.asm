
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide/d2a2d732143c46b04f5ca16733387a5f5713ad8dc218c423def02e91e4025de9/call-stub-xmkizw6s/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000010b340 <pf_call_0>:
  10b340:	0f 18 15 bc 06 f4 ff 	prefetcht1 -0xbf944(%rip)        # 4ba03 <pf_target_0_0>
  10b347:	0f 18 15 f5 06 f4 ff 	prefetcht1 -0xbf90b(%rip)        # 4ba43 <pf_target_0_1>
  10b34e:	0f 18 15 5b 10 f4 ff 	prefetcht1 -0xbefa5(%rip)        # 4c3b0 <pf_target_0_2>
  10b355:	0f 18 15 c4 5c f4 ff 	prefetcht1 -0xba33c(%rip)        # 51020 <pf_target_0_3>
  10b35c:	0f 18 15 dd 05 f4 ff 	prefetcht1 -0xbfa23(%rip)        # 4b940 <pf_target_0_4>
  10b363:	0f 18 15 16 5d f4 ff 	prefetcht1 -0xba2ea(%rip)        # 51080 <pf_target_0_5>
  10b36a:	41 53                	push   %r11
  10b36c:	4c 8b 1d ad de ff ff 	mov    -0x2153(%rip),%r11        # 109220 <pf_got_0_0>

000000000010b373 <pf_got_hint_0_0>:
  10b373:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b37a:	00 
  10b37b:	4c 8b 1d 2e e2 ff ff 	mov    -0x1dd2(%rip),%r11        # 1095b0 <pf_got_0_1>

000000000010b382 <pf_got_hint_0_1>:
  10b382:	41 0f 18 93 60 69 00 	prefetcht1 0x6960(%r11)
  10b389:	00 
  10b38a:	41 5b                	pop    %r11

000000000010b38c <pf_jump_0>:
  10b38c:	e9 af c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b391:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b398:	00 00 00 
  10b39b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000010b3a0 <pf_call_1>:
  10b3a0:	0f 18 15 69 e2 f2 ff 	prefetcht1 -0xd1d97(%rip)        # 39610 <pf_callee_2>

000000000010b3a7 <pf_jump_1>:
  10b3a7:	e9 94 c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b3ac:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b3b0 <pf_call_2>:
  10b3b0:	41 53                	push   %r11
  10b3b2:	4c 8b 1d 77 dd ff ff 	mov    -0x2289(%rip),%r11        # 109130 <pf_got_2_0>

000000000010b3b9 <pf_got_hint_2_0>:
  10b3b9:	41 0f 18 93 b0 06 00 	prefetcht1 0x6b0(%r11)
  10b3c0:	00 
  10b3c1:	4c 8b 1d e8 e1 ff ff 	mov    -0x1e18(%rip),%r11        # 1095b0 <pf_got_0_1>

000000000010b3c8 <pf_got_hint_2_1>:
  10b3c8:	41 0f 18 93 c5 1f 00 	prefetcht1 0x1fc5(%r11)
  10b3cf:	00 

000000000010b3d0 <pf_got_hint_2_2>:
  10b3d0:	41 0f 18 93 c0 31 00 	prefetcht1 0x31c0(%r11)
  10b3d7:	00 
  10b3d8:	41 5b                	pop    %r11

000000000010b3da <pf_jump_2>:
  10b3da:	e9 31 e2 f2 ff       	jmp    39610 <pf_callee_2>
  10b3df:	90                   	nop

000000000010b3e0 <pf_call_3>:
  10b3e0:	41 53                	push   %r11
  10b3e2:	4c 8b 1d c7 e1 ff ff 	mov    -0x1e39(%rip),%r11        # 1095b0 <pf_got_0_1>

000000000010b3e9 <pf_got_hint_3_0>:
  10b3e9:	41 0f 18 93 50 79 00 	prefetcht1 0x7950(%r11)
  10b3f0:	00 
  10b3f1:	4c 8b 1d b8 e4 ff ff 	mov    -0x1b48(%rip),%r11        # 1098b0 <pf_got_3_1>

000000000010b3f8 <pf_got_hint_3_1>:
  10b3f8:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b3ff:	00 

000000000010b400 <pf_got_hint_3_2>:
  10b400:	41 0f 18 93 34 00 00 	prefetcht1 0x34(%r11)
  10b407:	00 
  10b408:	41 5b                	pop    %r11

000000000010b40a <pf_jump_3>:
  10b40a:	e9 31 c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b40f:	90                   	nop

000000000010b410 <pf_call_4>:
  10b410:	41 53                	push   %r11
  10b412:	4c 8b 1d df de ff ff 	mov    -0x2121(%rip),%r11        # 1092f8 <pf_got_4_0>

000000000010b419 <pf_got_hint_4_0>:
  10b419:	41 0f 18 93 d0 d7 00 	prefetcht1 0xd7d0(%r11)
  10b420:	00 
  10b421:	41 5b                	pop    %r11

000000000010b423 <pf_jump_4>:
  10b423:	e9 c8 c7 f1 ff       	jmp    27bf0 <pf_callee_4>
  10b428:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b42f:	00 

000000000010b430 <pf_call_5>:
  10b430:	41 53                	push   %r11
  10b432:	4c 8b 1d 9f dd ff ff 	mov    -0x2261(%rip),%r11        # 1091d8 <pf_got_5_0>

000000000010b439 <pf_got_hint_5_0>:
  10b439:	41 0f 18 93 d3 ca 00 	prefetcht1 0xcad3(%r11)
  10b440:	00 
  10b441:	4c 8b 1d b0 de ff ff 	mov    -0x2150(%rip),%r11        # 1092f8 <pf_got_4_0>

000000000010b448 <pf_got_hint_5_1>:
  10b448:	41 0f 18 93 00 d7 00 	prefetcht1 0xd700(%r11)
  10b44f:	00 
  10b450:	41 5b                	pop    %r11

000000000010b452 <pf_jump_5>:
  10b452:	e9 99 c8 f1 ff       	jmp    27cf0 <pf_callee_5>
  10b457:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  10b45e:	00 00 

000000000010b460 <pf_call_6>:
  10b460:	41 53                	push   %r11
  10b462:	4c 8b 1d 7f e3 ff ff 	mov    -0x1c81(%rip),%r11        # 1097e8 <pf_got_6_0>

000000000010b469 <pf_got_hint_6_0>:
  10b469:	41 0f 18 93 e0 99 ff 	prefetcht1 -0x6620(%r11)
  10b470:	ff 
  10b471:	41 5b                	pop    %r11

000000000010b473 <pf_jump_6>:
  10b473:	e9 c8 cc f1 ff       	jmp    28140 <pf_callee_6>
  10b478:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b47f:	00 

000000000010b480 <pf_call_7>:
  10b480:	41 53                	push   %r11
  10b482:	4c 8b 1d 47 dd ff ff 	mov    -0x22b9(%rip),%r11        # 1091d0 <pf_got_7_0>

000000000010b489 <pf_got_hint_7_0>:
  10b489:	41 0f 18 93 3a 00 00 	prefetcht1 0x3a(%r11)
  10b490:	00 

000000000010b491 <pf_got_hint_7_1>:
  10b491:	41 0f 18 93 80 00 00 	prefetcht1 0x80(%r11)
  10b498:	00 
  10b499:	4c 8b 1d 48 e3 ff ff 	mov    -0x1cb8(%rip),%r11        # 1097e8 <pf_got_6_0>

000000000010b4a0 <pf_got_hint_7_2>:
  10b4a0:	41 0f 18 93 70 e9 ff 	prefetcht1 -0x1690(%r11)
  10b4a7:	ff 

000000000010b4a8 <pf_got_hint_7_3>:
  10b4a8:	41 0f 18 93 91 e9 ff 	prefetcht1 -0x166f(%r11)
  10b4af:	ff 
  10b4b0:	41 5b                	pop    %r11

000000000010b4b2 <pf_jump_7>:
  10b4b2:	e9 c9 c1 f1 ff       	jmp    27680 <pf_callee_7>
  10b4b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  10b4be:	00 00 

000000000010b4c0 <pf_call_8>:
  10b4c0:	41 53                	push   %r11
  10b4c2:	4c 8b 1d 1f e3 ff ff 	mov    -0x1ce1(%rip),%r11        # 1097e8 <pf_got_6_0>

000000000010b4c9 <pf_got_hint_8_0>:
  10b4c9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b4d0:	00 

000000000010b4d1 <pf_got_hint_8_1>:
  10b4d1:	41 0f 18 93 15 00 00 	prefetcht1 0x15(%r11)
  10b4d8:	00 

000000000010b4d9 <pf_got_hint_8_2>:
  10b4d9:	41 0f 18 93 53 00 00 	prefetcht1 0x53(%r11)
  10b4e0:	00 
  10b4e1:	41 5b                	pop    %r11

000000000010b4e3 <pf_jump_8>:
  10b4e3:	e9 e8 ca f1 ff       	jmp    27fd0 <pf_callee_8>
  10b4e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b4ef:	00 

000000000010b4f0 <pf_call_9>:
  10b4f0:	41 53                	push   %r11
  10b4f2:	4c 8b 1d ff dd ff ff 	mov    -0x2201(%rip),%r11        # 1092f8 <pf_got_4_0>

000000000010b4f9 <pf_got_hint_9_0>:
  10b4f9:	41 0f 18 93 b0 04 00 	prefetcht1 0x4b0(%r11)
  10b500:	00 

000000000010b501 <pf_got_hint_9_1>:
  10b501:	41 0f 18 93 e0 26 00 	prefetcht1 0x26e0(%r11)
  10b508:	00 

000000000010b509 <pf_got_hint_9_2>:
  10b509:	41 0f 18 93 80 53 00 	prefetcht1 0x5380(%r11)
  10b510:	00 
  10b511:	4c 8b 1d 30 e0 ff ff 	mov    -0x1fd0(%rip),%r11        # 109548 <pf_got_12_0>

000000000010b518 <pf_got_hint_9_3>:
  10b518:	41 0f 18 93 b0 89 01 	prefetcht1 0x189b0(%r11)
  10b51f:	00 

000000000010b520 <pf_got_hint_9_4>:
  10b520:	41 0f 18 93 b0 57 03 	prefetcht1 0x357b0(%r11)
  10b527:	00 

000000000010b528 <pf_got_hint_9_5>:
  10b528:	41 0f 18 93 30 5a 03 	prefetcht1 0x35a30(%r11)
  10b52f:	00 
  10b530:	4c 8b 1d 41 e1 ff ff 	mov    -0x1ebf(%rip),%r11        # 109678 <pf_got_9_6>

000000000010b537 <pf_got_hint_9_6>:
  10b537:	41 0f 18 93 60 50 ff 	prefetcht1 -0xafa0(%r11)
  10b53e:	ff 

000000000010b53f <pf_got_hint_9_7>:
  10b53f:	41 0f 18 93 60 76 ff 	prefetcht1 -0x89a0(%r11)
  10b546:	ff 
  10b547:	41 5b                	pop    %r11

000000000010b549 <pf_jump_9>:
  10b549:	e9 42 c5 f1 ff       	jmp    27a90 <pf_callee_9>
  10b54e:	66 90                	xchg   %ax,%ax

000000000010b550 <pf_call_10>:
  10b550:	41 53                	push   %r11
  10b552:	4c 8b 1d 57 e0 ff ff 	mov    -0x1fa9(%rip),%r11        # 1095b0 <pf_got_0_1>

000000000010b559 <pf_got_hint_10_0>:
  10b559:	41 0f 18 93 20 6f fe 	prefetcht1 -0x190e0(%r11)
  10b560:	ff 

000000000010b561 <pf_got_hint_10_1>:
  10b561:	41 0f 18 93 5a b4 ff 	prefetcht1 -0x4ba6(%r11)
  10b568:	ff 
  10b569:	41 5b                	pop    %r11

000000000010b56b <pf_jump_10>:
  10b56b:	e9 e0 cb f1 ff       	jmp    28150 <pf_callee_10>

000000000010b570 <pf_call_11>:
  10b570:	0f 18 15 79 c0 f1 ff 	prefetcht1 -0xe3f87(%rip)        # 275f0 <pf_target_11_0>

000000000010b577 <pf_jump_11>:
  10b577:	e9 24 67 f4 ff       	jmp    51ca0 <pf_callee_11>
  10b57c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b580 <pf_call_12>:
  10b580:	41 53                	push   %r11
  10b582:	4c 8b 1d bf df ff ff 	mov    -0x2041(%rip),%r11        # 109548 <pf_got_12_0>

000000000010b589 <pf_got_hint_12_0>:
  10b589:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b590:	00 

000000000010b591 <pf_got_hint_12_1>:
  10b591:	41 0f 18 93 f2 89 01 	prefetcht1 0x189f2(%r11)
  10b598:	00 
  10b599:	41 5b                	pop    %r11

000000000010b59b <pf_jump_12>:
  10b59b:	e9 10 bc f1 ff       	jmp    271b0 <pf_callee_12>

000000000010b5a0 <pf_call_13>:
  10b5a0:	41 53                	push   %r11
  10b5a2:	4c 8b 1d af de ff ff 	mov    -0x2151(%rip),%r11        # 109458 <pf_got_13_0>

000000000010b5a9 <pf_got_hint_13_0>:
  10b5a9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b5b0:	00 
  10b5b1:	4c 8b 1d 48 e3 ff ff 	mov    -0x1cb8(%rip),%r11        # 109900 <pf_got_13_1>

000000000010b5b8 <pf_got_hint_13_1>:
  10b5b8:	41 0f 18 93 70 e8 fe 	prefetcht1 -0x11790(%r11)
  10b5bf:	ff 

000000000010b5c0 <pf_got_hint_13_2>:
  10b5c0:	41 0f 18 93 20 26 ff 	prefetcht1 -0xd9e0(%r11)
  10b5c7:	ff 

000000000010b5c8 <pf_got_hint_13_3>:
  10b5c8:	41 0f 18 93 31 26 ff 	prefetcht1 -0xd9cf(%r11)
  10b5cf:	ff 

000000000010b5d0 <pf_got_hint_13_4>:
  10b5d0:	41 0f 18 93 10 29 ff 	prefetcht1 -0xd6f0(%r11)
  10b5d7:	ff 

000000000010b5d8 <pf_got_hint_13_5>:
  10b5d8:	41 0f 18 93 a0 f5 ff 	prefetcht1 -0xa60(%r11)
  10b5df:	ff 

000000000010b5e0 <pf_got_hint_13_6>:
  10b5e0:	41 0f 18 93 b0 f5 ff 	prefetcht1 -0xa50(%r11)
  10b5e7:	ff 
  10b5e8:	41 5b                	pop    %r11

000000000010b5ea <pf_jump_13>:
  10b5ea:	e9 41 25 f4 ff       	jmp    4db30 <pf_callee_13>
  10b5ef:	90                   	nop

000000000010b5f0 <pf_call_14>:
  10b5f0:	41 53                	push   %r11
  10b5f2:	4c 8b 1d ff df ff ff 	mov    -0x2001(%rip),%r11        # 1095f8 <pf_got_14_0>

000000000010b5f9 <pf_got_hint_14_0>:
  10b5f9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b600:	00 
  10b601:	41 5b                	pop    %r11

000000000010b603 <pf_jump_14>:
  10b603:	e9 28 cc f1 ff       	jmp    28230 <pf_callee_14>
  10b608:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b60f:	00 

000000000010b610 <pf_call_15>:
  10b610:	41 53                	push   %r11
  10b612:	4c 8b 1d d7 dd ff ff 	mov    -0x2229(%rip),%r11        # 1093f0 <pf_got_15_0>

000000000010b619 <pf_got_hint_15_0>:
  10b619:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b620:	00 
  10b621:	41 5b                	pop    %r11

000000000010b623 <pf_jump_15>:
  10b623:	e9 18 bb f1 ff       	jmp    27140 <pf_callee_15>
  10b628:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b62f:	00 

000000000010b630 <pf_call_16>:
  10b630:	0f 18 15 a9 c1 f1 ff 	prefetcht1 -0xe3e57(%rip)        # 277e0 <pf_target_16_0>
  10b637:	0f 18 15 85 09 f4 ff 	prefetcht1 -0xbf67b(%rip)        # 4bfc3 <pf_target_16_1>
  10b63e:	41 53                	push   %r11
  10b640:	4c 8b 1d a9 dd ff ff 	mov    -0x2257(%rip),%r11        # 1093f0 <pf_got_15_0>

000000000010b647 <pf_got_hint_16_0>:
  10b647:	41 0f 18 93 11 00 00 	prefetcht1 0x11(%r11)
  10b64e:	00 
  10b64f:	41 5b                	pop    %r11

000000000010b651 <pf_jump_16>:
  10b651:	e9 ea ba f1 ff       	jmp    27140 <pf_callee_15>
  10b656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b65d:	00 00 00 

000000000010b660 <pf_call_17>:
  10b660:	0f 18 15 89 be f1 ff 	prefetcht1 -0xe4177(%rip)        # 274f0 <pf_target_17_0>
  10b667:	0f 18 15 1c d2 f3 ff 	prefetcht1 -0xc2de4(%rip)        # 4888a <pf_target_17_1>

000000000010b66e <pf_jump_17>:
  10b66e:	e9 6d d1 f3 ff       	jmp    487e0 <pf_callee_17>
  10b673:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b67a:	00 00 00 
  10b67d:	0f 1f 00             	nopl   (%rax)

000000000010b680 <pf_call_18>:
  10b680:	0f 18 15 99 09 f4 ff 	prefetcht1 -0xbf667(%rip)        # 4c020 <pf_target_18_0>
  10b687:	0f 18 15 b5 09 f4 ff 	prefetcht1 -0xbf64b(%rip)        # 4c043 <pf_target_18_1>

000000000010b68e <pf_jump_18>:
  10b68e:	e9 cd 0d f4 ff       	jmp    4c460 <pf_callee_18>
  10b693:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b69a:	00 00 00 
  10b69d:	0f 1f 00             	nopl   (%rax)

000000000010b6a0 <pf_call_19>:
  10b6a0:	0f 18 15 69 22 f4 ff 	prefetcht1 -0xbdd97(%rip)        # 4d910 <pf_target_19_0>

000000000010b6a7 <pf_jump_19>:
  10b6a7:	e9 04 bb f1 ff       	jmp    271b0 <pf_callee_12>
  10b6ac:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b6b0 <pf_call_20>:
  10b6b0:	0f 18 15 e9 08 f4 ff 	prefetcht1 -0xbf717(%rip)        # 4bfa0 <pf_target_20_0>

000000000010b6b7 <pf_jump_20>:
  10b6b7:	e9 84 ba f1 ff       	jmp    27140 <pf_callee_15>
  10b6bc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b6c0 <pf_call_21>:
  10b6c0:	0f 18 15 d9 c9 f1 ff 	prefetcht1 -0xe3627(%rip)        # 280a0 <pf_target_21_0>

000000000010b6c7 <pf_jump_21>:
  10b6c7:	e9 e4 ba f1 ff       	jmp    271b0 <pf_callee_12>
  10b6cc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b6d0 <pf_call_22>:
  10b6d0:	41 53                	push   %r11
  10b6d2:	4c 8b 1d d7 de ff ff 	mov    -0x2129(%rip),%r11        # 1095b0 <pf_got_0_1>

000000000010b6d9 <pf_got_hint_22_0>:
  10b6d9:	41 0f 18 93 30 56 fe 	prefetcht1 -0x1a9d0(%r11)
  10b6e0:	ff 

000000000010b6e1 <pf_got_hint_22_1>:
  10b6e1:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b6e8:	00 

000000000010b6e9 <pf_got_hint_22_2>:
  10b6e9:	41 0f 18 93 44 00 00 	prefetcht1 0x44(%r11)
  10b6f0:	00 

000000000010b6f1 <pf_got_hint_22_3>:
  10b6f1:	41 0f 18 93 88 00 00 	prefetcht1 0x88(%r11)
  10b6f8:	00 
  10b6f9:	4c 8b 1d 00 e2 ff ff 	mov    -0x1e00(%rip),%r11        # 109900 <pf_got_13_1>

000000000010b700 <pf_got_hint_22_4>:
  10b700:	41 0f 18 93 b0 3e fe 	prefetcht1 -0x1c150(%r11)
  10b707:	ff 

000000000010b708 <pf_got_hint_22_5>:
  10b708:	41 0f 18 93 40 46 fe 	prefetcht1 -0x1b9c0(%r11)
  10b70f:	ff 

000000000010b710 <pf_got_hint_22_6>:
  10b710:	41 0f 18 93 70 46 fe 	prefetcht1 -0x1b990(%r11)
  10b717:	ff 
  10b718:	41 5b                	pop    %r11

000000000010b71a <pf_jump_22>:
  10b71a:	e9 41 c4 f1 ff       	jmp    27b60 <pf_callee_22>
  10b71f:	90                   	nop

000000000010b720 <pf_call_23>:
  10b720:	0f 18 15 89 17 f4 ff 	prefetcht1 -0xbe877(%rip)        # 4ceb0 <pf_target_23_0>
  10b727:	0f 18 15 b2 d0 f3 ff 	prefetcht1 -0xc2f4e(%rip)        # 487e0 <pf_callee_17>

000000000010b72e <pf_jump_23>:
  10b72e:	e9 ad 1c f4 ff       	jmp    4d3e0 <pf_callee_23>
  10b733:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b73a:	00 00 00 
  10b73d:	0f 1f 00             	nopl   (%rax)

000000000010b740 <pf_call_24>:
  10b740:	0f 18 15 e9 ca f1 ff 	prefetcht1 -0xe3517(%rip)        # 28230 <pf_callee_14>
  10b747:	41 53                	push   %r11
  10b749:	4c 8b 1d 88 d9 ff ff 	mov    -0x2678(%rip),%r11        # 1090d8 <pf_got_24_0>

000000000010b750 <pf_got_hint_24_0>:
  10b750:	41 0f 18 93 90 37 ff 	prefetcht1 -0xc870(%r11)
  10b757:	ff 
  10b758:	4c 8b 1d f9 de ff ff 	mov    -0x2107(%rip),%r11        # 109658 <pf_got_24_1>

000000000010b75f <pf_got_hint_24_1>:
  10b75f:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b766:	00 
  10b767:	41 5b                	pop    %r11

000000000010b769 <pf_jump_24>:
  10b769:	e9 72 d0 f3 ff       	jmp    487e0 <pf_callee_17>
  10b76e:	66 90                	xchg   %ax,%ax

000000000010b770 <pf_call_25>:
  10b770:	0f 18 15 19 5c f4 ff 	prefetcht1 -0xba3e7(%rip)        # 51390 <pf_target_25_0>

000000000010b777 <pf_jump_25>:
  10b777:	e9 b4 c4 f1 ff       	jmp    27c30 <pf_callee_25>
  10b77c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b780 <pf_call_26>:
  10b780:	0f 18 15 c9 cb f1 ff 	prefetcht1 -0xe3437(%rip)        # 28350 <pf_target_26_0>
  10b787:	41 53                	push   %r11
  10b789:	4c 8b 1d 18 e2 ff ff 	mov    -0x1de8(%rip),%r11        # 1099a8 <pf_got_26_0>

000000000010b790 <pf_got_hint_26_0>:
  10b790:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b797:	00 

000000000010b798 <pf_got_hint_26_1>:
  10b798:	41 0f 18 93 a8 02 00 	prefetcht1 0x2a8(%r11)
  10b79f:	00 
  10b7a0:	41 5b                	pop    %r11

000000000010b7a2 <pf_jump_26>:
  10b7a2:	e9 a9 61 f4 ff       	jmp    51950 <pf_callee_26>
  10b7a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  10b7ae:	00 00 

000000000010b7b0 <pf_call_27>:
  10b7b0:	0f 18 15 89 c1 f5 ff 	prefetcht1 -0xa3e77(%rip)        # 67940 <pf_target_27_0>
  10b7b7:	0f 18 15 62 c1 f5 ff 	prefetcht1 -0xa3e9e(%rip)        # 67920 <pf_target_27_1>
  10b7be:	0f 18 15 7b b6 f5 ff 	prefetcht1 -0xa4985(%rip)        # 66e40 <pf_target_27_2>
  10b7c5:	0f 18 15 64 0b f6 ff 	prefetcht1 -0x9f49c(%rip)        # 6c330 <pf_target_27_3>
  10b7cc:	0f 18 15 ed 58 f6 ff 	prefetcht1 -0x9a713(%rip)        # 710c0 <pf_callee_34>

000000000010b7d3 <pf_jump_27>:
  10b7d3:	e9 d8 b9 f1 ff       	jmp    271b0 <pf_callee_12>
  10b7d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b7df:	00 

000000000010b7e0 <pf_call_28>:
  10b7e0:	0f 18 15 e9 be f5 ff 	prefetcht1 -0xa4117(%rip)        # 676d0 <pf_target_28_0>

000000000010b7e7 <pf_jump_28>:
  10b7e7:	e9 b4 c0 f1 ff       	jmp    278a0 <pf_callee_28>
  10b7ec:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b7f0 <pf_call_29>:
  10b7f0:	0f 18 15 a9 c0 f1 ff 	prefetcht1 -0xe3f57(%rip)        # 278a0 <pf_callee_28>
  10b7f7:	0f 18 15 ae 37 f6 ff 	prefetcht1 -0x9c852(%rip)        # 6efac <pf_target_29_1>
  10b7fe:	0f 18 15 cb 01 f6 ff 	prefetcht1 -0x9fe35(%rip)        # 6b9d0 <pf_target_29_2>
  10b805:	0f 18 15 b4 cb f1 ff 	prefetcht1 -0xe344c(%rip)        # 283c0 <pf_callee_32>
  10b80c:	41 53                	push   %r11
  10b80e:	4c 8b 1d 3b dc ff ff 	mov    -0x23c5(%rip),%r11        # 109450 <pf_got_29_0>

000000000010b815 <pf_got_hint_29_0>:
  10b815:	41 0f 18 93 10 00 00 	prefetcht1 0x10(%r11)
  10b81c:	00 
  10b81d:	41 5b                	pop    %r11

000000000010b81f <pf_jump_29>:
  10b81f:	e9 cc c5 f5 ff       	jmp    67df0 <pf_callee_29>
  10b824:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b82b:	00 00 00 
  10b82e:	66 90                	xchg   %ax,%ax

000000000010b830 <pf_call_30>:
  10b830:	0f 18 15 69 3f f6 ff 	prefetcht1 -0x9c097(%rip)        # 6f7a0 <pf_callee_31>
  10b837:	41 53                	push   %r11
  10b839:	4c 8b 1d 98 d8 ff ff 	mov    -0x2768(%rip),%r11        # 1090d8 <pf_got_24_0>

000000000010b840 <pf_got_hint_30_0>:
  10b840:	41 0f 18 93 b0 53 ff 	prefetcht1 -0xac50(%r11)
  10b847:	ff 
  10b848:	41 5b                	pop    %r11

000000000010b84a <pf_jump_30>:
  10b84a:	e9 51 c0 f1 ff       	jmp    278a0 <pf_callee_28>
  10b84f:	90                   	nop

000000000010b850 <pf_call_31>:
  10b850:	0f 18 15 19 5e f4 ff 	prefetcht1 -0xba1e7(%rip)        # 51670 <pf_target_31_0>

000000000010b857 <pf_jump_31>:
  10b857:	e9 44 3f f6 ff       	jmp    6f7a0 <pf_callee_31>
  10b85c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b860 <pf_call_32>:
  10b860:	0f 18 15 69 ba f5 ff 	prefetcht1 -0xa4597(%rip)        # 672d0 <pf_target_32_0>
  10b867:	0f 18 15 92 07 f6 ff 	prefetcht1 -0x9f86e(%rip)        # 6c000 <pf_target_32_1>
  10b86e:	0f 18 15 7b ce f5 ff 	prefetcht1 -0xa3185(%rip)        # 686f0 <pf_target_32_2>

000000000010b875 <pf_jump_32>:
  10b875:	e9 46 cb f1 ff       	jmp    283c0 <pf_callee_32>
  10b87a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000010b880 <pf_call_33>:
  10b880:	41 53                	push   %r11
  10b882:	4c 8b 1d 07 d8 ff ff 	mov    -0x27f9(%rip),%r11        # 109090 <pf_got_33_0>

000000000010b889 <pf_got_hint_33_0>:
  10b889:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b890:	00 
  10b891:	41 5b                	pop    %r11

000000000010b893 <pf_jump_33>:
  10b893:	e9 78 a6 f6 ff       	jmp    75f10 <pf_callee_33>
  10b898:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b89f:	00 

000000000010b8a0 <pf_call_34>:
  10b8a0:	0f 18 15 30 37 f6 ff 	prefetcht1 -0x9c8d0(%rip)        # 6efd7 <pf_target_34_0>
  10b8a7:	0f 18 15 37 06 f6 ff 	prefetcht1 -0x9f9c9(%rip)        # 6bee5 <pf_target_34_1>
  10b8ae:	0f 18 15 ab 36 f6 ff 	prefetcht1 -0x9c955(%rip)        # 6ef60 <pf_target_34_2>
  10b8b5:	0f 18 15 5a 02 f6 ff 	prefetcht1 -0x9fda6(%rip)        # 6bb16 <pf_target_34_3>

000000000010b8bc <pf_jump_34>:
  10b8bc:	e9 ff 57 f6 ff       	jmp    710c0 <pf_callee_34>
