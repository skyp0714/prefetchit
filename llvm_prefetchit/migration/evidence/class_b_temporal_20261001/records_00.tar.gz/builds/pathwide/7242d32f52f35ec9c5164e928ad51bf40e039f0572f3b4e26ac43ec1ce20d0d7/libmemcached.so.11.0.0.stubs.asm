
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide/7242d32f52f35ec9c5164e928ad51bf40e039f0572f3b4e26ac43ec1ce20d0d7/call-stub-_efrw194/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000312c0 <pf_call_0>:
   312c0:	0f 18 15 a9 5c fd ff 	prefetcht1 -0x2a357(%rip)        # 6f70 <pf_callee_17>
   312c7:	0f 18 15 e2 44 fe ff 	prefetcht1 -0x1bb1e(%rip)        # 157b0 <pf_callee_32>
   312ce:	0f 18 15 db e8 fd ff 	prefetcht1 -0x21725(%rip)        # fbb0 <pf_callee_20>
   312d5:	0f 18 15 25 e9 fd ff 	prefetcht1 -0x216db(%rip)        # fc01 <pf_target_0_3>
   312dc:	0f 18 15 dd e8 fd ff 	prefetcht1 -0x21723(%rip)        # fbc0 <pf_target_0_4>
   312e3:	0f 18 15 dc 44 fe ff 	prefetcht1 -0x1bb24(%rip)        # 157c6 <pf_target_0_5>

00000000000312ea <pf_jump_0>:
   312ea:	e9 81 41 fd ff       	jmp    5470 <pf_callee_0>
   312ef:	90                   	nop

00000000000312f0 <pf_call_1>:
   312f0:	0f 18 15 e9 a9 fd ff 	prefetcht1 -0x25617(%rip)        # bce0 <pf_target_1_0>
   312f7:	0f 18 15 32 a4 fd ff 	prefetcht1 -0x25bce(%rip)        # b730 <pf_target_1_1>
   312fe:	0f 18 15 6b 41 fd ff 	prefetcht1 -0x2be95(%rip)        # 5470 <pf_callee_0>
   31305:	0f 18 15 64 40 fe ff 	prefetcht1 -0x1bf9c(%rip)        # 15370 <pf_target_1_3>

000000000003130c <pf_jump_1>:
   3130c:	e9 ff 42 fd ff       	jmp    5610 <pf_callee_1>
   31311:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31318:	00 00 00 
   3131b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031320 <pf_call_2>:
   31320:	0f 18 15 9e a6 fd ff 	prefetcht1 -0x25962(%rip)        # b9c5 <pf_target_2_0>
   31327:	0f 18 15 e2 42 fd ff 	prefetcht1 -0x2bd1e(%rip)        # 5610 <pf_callee_1>
   3132e:	0f 18 15 2b a6 fd ff 	prefetcht1 -0x259d5(%rip)        # b960 <pf_callee_11>

0000000000031335 <pf_jump_2>:
   31335:	e9 26 d5 fe ff       	jmp    1e860 <pf_callee_10>
   3133a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031340 <pf_call_3>:
   31340:	0f 18 15 29 41 fd ff 	prefetcht1 -0x2bed7(%rip)        # 5470 <pf_callee_0>

0000000000031347 <pf_jump_3>:
   31347:	e9 14 a6 fd ff       	jmp    b960 <pf_callee_11>
   3134c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031350 <pf_call_4>:
   31350:	0f 18 15 19 f6 fd ff 	prefetcht1 -0x209e7(%rip)        # 10970 <pf_target_4_0>
   31357:	0f 18 15 5a 2d fe ff 	prefetcht1 -0x1d2a6(%rip)        # 140b8 <pf_target_27_4>
   3135e:	0f 18 15 fb 7b fe ff 	prefetcht1 -0x18405(%rip)        # 18f60 <pf_target_24_4>
   31365:	0f 18 15 10 7a fe ff 	prefetcht1 -0x185f0(%rip)        # 18d7c <pf_target_24_2>
   3136c:	0f 18 15 05 b4 fd ff 	prefetcht1 -0x24bfb(%rip)        # c778 <pf_target_4_4>
   31373:	0f 18 15 06 f6 fd ff 	prefetcht1 -0x209fa(%rip)        # 10980 <pf_target_4_5>
   3137a:	0f 18 15 56 2b fe ff 	prefetcht1 -0x1d4aa(%rip)        # 13ed7 <pf_target_24_0>
   31381:	0f 18 15 ff 79 fe ff 	prefetcht1 -0x18601(%rip)        # 18d87 <pf_target_24_3>

0000000000031388 <pf_jump_4>:
   31388:	e9 83 42 fd ff       	jmp    5610 <pf_callee_1>
   3138d:	0f 1f 00             	nopl   (%rax)

0000000000031390 <pf_call_5>:
   31390:	0f 18 15 ea 26 fe ff 	prefetcht1 -0x1d916(%rip)        # 13a81 <pf_target_5_0>
   31397:	0f 18 15 6a b2 fd ff 	prefetcht1 -0x24d96(%rip)        # c608 <pf_target_5_1>
   3139e:	0f 18 15 5d 1f fe ff 	prefetcht1 -0x1e0a3(%rip)        # 13302 <pf_target_5_2>
   313a5:	0f 18 15 d4 1f fe ff 	prefetcht1 -0x1e02c(%rip)        # 13380 <pf_target_5_3>

00000000000313ac <pf_jump_5>:
   313ac:	e9 2f 41 fd ff       	jmp    54e0 <pf_callee_5>
   313b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   313b8:	00 00 00 
   313bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000313c0 <pf_call_6>:
   313c0:	0f 18 15 cf 5b fd ff 	prefetcht1 -0x2a431(%rip)        # 6f96 <pf_target_6_0>
   313c7:	0f 18 15 f3 5b fd ff 	prefetcht1 -0x2a40d(%rip)        # 6fc1 <pf_target_6_1>
   313ce:	0f 18 15 36 f5 fd ff 	prefetcht1 -0x20aca(%rip)        # 1090b <pf_target_6_2>

00000000000313d5 <pf_jump_6>:
   313d5:	e9 e6 b1 fd ff       	jmp    c5c0 <pf_callee_6>
   313da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000313e0 <pf_call_7>:
   313e0:	0f 18 15 1d a6 fd ff 	prefetcht1 -0x259e3(%rip)        # ba04 <pf_target_7_0>

00000000000313e7 <pf_jump_7>:
   313e7:	e9 04 3e fe ff       	jmp    151f0 <pf_callee_12>
   313ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000313f0 <pf_call_8>:
   313f0:	0f 18 15 b5 d7 fd ff 	prefetcht1 -0x2284b(%rip)        # ebac <pf_target_8_0>
   313f7:	0f 18 15 21 e1 fd ff 	prefetcht1 -0x21edf(%rip)        # f51f <pf_target_8_1>

00000000000313fe <pf_jump_8>:
   313fe:	e9 4d d0 fd ff       	jmp    e450 <pf_callee_16>
   31403:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3140a:	00 00 00 
   3140d:	0f 1f 00             	nopl   (%rax)

0000000000031410 <pf_call_9>:
   31410:	0f 18 15 08 e1 fd ff 	prefetcht1 -0x21ef8(%rip)        # f51f <pf_target_8_1>
   31417:	0f 18 15 32 ca fd ff 	prefetcht1 -0x235ce(%rip)        # de50 <pf_callee_13>
   3141e:	0f 18 15 5c d4 fe ff 	prefetcht1 -0x12ba4(%rip)        # 1e881 <pf_target_35_5>
   31425:	0f 18 15 34 d4 fe ff 	prefetcht1 -0x12bcc(%rip)        # 1e860 <pf_callee_10>
   3142c:	0f 18 15 50 83 fd ff 	prefetcht1 -0x27cb0(%rip)        # 9783 <pf_target_33_3>

0000000000031433 <pf_jump_9>:
   31433:	e9 18 d0 fd ff       	jmp    e450 <pf_callee_16>
   31438:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   3143f:	00 

0000000000031440 <pf_call_10>:
   31440:	0f 18 15 29 e0 fd ff 	prefetcht1 -0x21fd7(%rip)        # f470 <pf_target_10_0>
   31447:	0f 18 15 c2 41 fd ff 	prefetcht1 -0x2be3e(%rip)        # 5610 <pf_callee_1>
   3144e:	0f 18 15 82 e0 fd ff 	prefetcht1 -0x21f7e(%rip)        # f4d7 <pf_target_10_2>

0000000000031455 <pf_jump_10>:
   31455:	e9 06 d4 fe ff       	jmp    1e860 <pf_callee_10>
   3145a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031460 <pf_call_11>:
   31460:	0f 18 15 d0 de fd ff 	prefetcht1 -0x22130(%rip)        # f337 <pf_target_11_0>
   31467:	0f 18 15 fa de fd ff 	prefetcht1 -0x22106(%rip)        # f368 <pf_target_11_1>

000000000003146e <pf_jump_11>:
   3146e:	e9 ed a4 fd ff       	jmp    b960 <pf_callee_11>
   31473:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3147a:	00 00 00 
   3147d:	0f 1f 00             	nopl   (%rax)

0000000000031480 <pf_call_12>:
   31480:	0f 18 15 f9 e4 fd ff 	prefetcht1 -0x21b07(%rip)        # f980 <pf_target_12_0>
   31487:	0f 18 15 32 e5 fd ff 	prefetcht1 -0x21ace(%rip)        # f9c0 <pf_target_12_1>
   3148e:	0f 18 15 1b e7 fd ff 	prefetcht1 -0x218e5(%rip)        # fbb0 <pf_callee_20>
   31495:	0f 18 15 65 e7 fd ff 	prefetcht1 -0x2189b(%rip)        # fc01 <pf_target_0_3>

000000000003149c <pf_jump_12>:
   3149c:	e9 4f 3d fe ff       	jmp    151f0 <pf_callee_12>
   314a1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   314a8:	00 00 00 
   314ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000314b0 <pf_call_13>:
   314b0:	0f 18 15 20 e0 fd ff 	prefetcht1 -0x21fe0(%rip)        # f4d7 <pf_target_10_2>

00000000000314b7 <pf_jump_13>:
   314b7:	e9 94 c9 fd ff       	jmp    de50 <pf_callee_13>
   314bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000314c0 <pf_call_14>:
   314c0:	0f 18 15 49 3b fe ff 	prefetcht1 -0x1c4b7(%rip)        # 15010 <pf_target_14_0>
   314c7:	0f 18 15 7a 1b fe ff 	prefetcht1 -0x1e486(%rip)        # 13048 <pf_target_14_1>
   314ce:	0f 18 15 5b 1b fe ff 	prefetcht1 -0x1e4a5(%rip)        # 13030 <pf_callee_29>
   314d5:	41 53                	push   %r11
   314d7:	4c 8b 1d 9a eb ff ff 	mov    -0x1466(%rip),%r11        # 30078 <pf_got_14_0>

00000000000314de <pf_got_hint_14_0>:
   314de:	41 0f 18 93 1a 03 00 	prefetcht1 0x31a(%r11)
   314e5:	00 

00000000000314e6 <pf_got_hint_14_1>:
   314e6:	41 0f 18 93 ed 04 00 	prefetcht1 0x4ed(%r11)
   314ed:	00 

00000000000314ee <pf_got_hint_14_2>:
   314ee:	41 0f 18 93 23 05 00 	prefetcht1 0x523(%r11)
   314f5:	00 

00000000000314f6 <pf_got_hint_14_3>:
   314f6:	41 0f 18 93 00 07 00 	prefetcht1 0x700(%r11)
   314fd:	00 
   314fe:	41 5b                	pop    %r11

0000000000031500 <pf_jump_14>:
   31500:	e9 2b 40 fd ff       	jmp    5530 <pf_callee_14>
   31505:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3150c:	00 00 00 
   3150f:	90                   	nop

0000000000031510 <pf_call_15>:
   31510:	0f 18 15 39 cf fd ff 	prefetcht1 -0x230c7(%rip)        # e450 <pf_callee_16>
   31517:	0f 18 15 b0 76 fe ff 	prefetcht1 -0x18950(%rip)        # 18bce <pf_target_15_1>
   3151e:	0f 18 15 5e cf fd ff 	prefetcht1 -0x230a2(%rip)        # e483 <pf_target_15_2>
   31525:	0f 18 15 3e 77 fe ff 	prefetcht1 -0x188c2(%rip)        # 18c6a <pf_target_15_3>
   3152c:	0f 18 15 2a d0 fd ff 	prefetcht1 -0x22fd6(%rip)        # e55d <pf_target_15_4>

0000000000031533 <pf_jump_15>:
   31533:	e9 48 1d fe ff       	jmp    13280 <pf_callee_15>
   31538:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   3153f:	00 

0000000000031540 <pf_call_16>:
   31540:	0f 18 15 3a aa fd ff 	prefetcht1 -0x255c6(%rip)        # bf81 <pf_target_16_0>
   31547:	0f 18 15 e2 a9 fd ff 	prefetcht1 -0x2561e(%rip)        # bf30 <pf_target_16_1>
   3154e:	0f 18 15 70 f3 fd ff 	prefetcht1 -0x20c90(%rip)        # 108c5 <pf_target_16_2>
   31555:	0f 18 15 e5 a9 fd ff 	prefetcht1 -0x2561b(%rip)        # bf41 <pf_target_16_3>

000000000003155c <pf_jump_16>:
   3155c:	e9 ef ce fd ff       	jmp    e450 <pf_callee_16>
   31561:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31568:	00 00 00 
   3156b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031570 <pf_call_17>:
   31570:	0f 18 15 d9 52 fe ff 	prefetcht1 -0x1ad27(%rip)        # 16850 <pf_target_17_0>
   31577:	0f 18 15 04 53 fe ff 	prefetcht1 -0x1acfc(%rip)        # 16882 <pf_target_17_1>

000000000003157e <pf_jump_17>:
   3157e:	e9 ed 59 fd ff       	jmp    6f70 <pf_callee_17>
   31583:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3158a:	00 00 00 
   3158d:	0f 1f 00             	nopl   (%rax)

0000000000031590 <pf_call_18>:
   31590:	0f 18 15 f9 f0 fd ff 	prefetcht1 -0x20f07(%rip)        # 10690 <pf_callee_19>

0000000000031597 <pf_jump_18>:
   31597:	e9 d4 f1 fd ff       	jmp    10770 <pf_callee_18>
   3159c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000315a0 <pf_call_19>:
   315a0:	0f 18 15 9b d1 fd ff 	prefetcht1 -0x22e65(%rip)        # e742 <pf_target_19_0>
   315a7:	0f 18 15 42 d1 fd ff 	prefetcht1 -0x22ebe(%rip)        # e6f0 <pf_target_19_1>
   315ae:	0f 18 15 cb 1c fe ff 	prefetcht1 -0x1e335(%rip)        # 13280 <pf_callee_15>
   315b5:	0f 18 15 48 d1 fd ff 	prefetcht1 -0x22eb8(%rip)        # e704 <pf_target_19_3>
   315bc:	0f 18 15 c0 ce fd ff 	prefetcht1 -0x23140(%rip)        # e483 <pf_target_15_2>

00000000000315c3 <pf_jump_19>:
   315c3:	e9 c8 f0 fd ff       	jmp    10690 <pf_callee_19>
   315c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   315cf:	00 

00000000000315d0 <pf_call_20>:
   315d0:	0f 18 15 a9 6c fe ff 	prefetcht1 -0x19357(%rip)        # 18280 <pf_target_20_0>
   315d7:	0f 18 15 a2 e3 fd ff 	prefetcht1 -0x21c5e(%rip)        # f980 <pf_target_12_0>
   315de:	0f 18 15 db e3 fd ff 	prefetcht1 -0x21c25(%rip)        # f9c0 <pf_target_12_1>

00000000000315e5 <pf_jump_20>:
   315e5:	e9 c6 e5 fd ff       	jmp    fbb0 <pf_callee_20>
   315ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000315f0 <pf_call_21>:
   315f0:	0f 18 15 99 f0 fd ff 	prefetcht1 -0x20f67(%rip)        # 10690 <pf_callee_19>

00000000000315f7 <pf_jump_21>:
   315f7:	e9 34 04 fe ff       	jmp    11a30 <pf_callee_21>
   315fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031600 <pf_call_22>:
   31600:	41 53                	push   %r11
   31602:	4c 8b 1d 1f ec ff ff 	mov    -0x13e1(%rip),%r11        # 30228 <pf_got_22_0>

0000000000031609 <pf_got_hint_22_0>:
   31609:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   31610:	00 
   31611:	41 5b                	pop    %r11

0000000000031613 <pf_jump_22>:
   31613:	e9 38 41 fd ff       	jmp    5750 <pf_callee_22>
   31618:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   3161f:	00 

0000000000031620 <pf_call_23>:
   31620:	0f 18 15 d9 94 fd ff 	prefetcht1 -0x26b27(%rip)        # ab00 <pf_target_23_0>
   31627:	0f 18 15 16 95 fd ff 	prefetcht1 -0x26aea(%rip)        # ab44 <pf_target_23_1>
   3162e:	0f 18 15 97 b1 fd ff 	prefetcht1 -0x24e69(%rip)        # c7cc <pf_target_23_2>

0000000000031635 <pf_jump_23>:
   31635:	e9 46 b2 fd ff       	jmp    c880 <pf_callee_23>
   3163a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031640 <pf_call_24>:
   31640:	0f 18 15 90 28 fe ff 	prefetcht1 -0x1d770(%rip)        # 13ed7 <pf_target_24_0>
   31647:	0f 18 15 74 23 fe ff 	prefetcht1 -0x1dc8c(%rip)        # 139c2 <pf_target_24_1>
   3164e:	0f 18 15 27 77 fe ff 	prefetcht1 -0x188d9(%rip)        # 18d7c <pf_target_24_2>
   31655:	0f 18 15 2b 77 fe ff 	prefetcht1 -0x188d5(%rip)        # 18d87 <pf_target_24_3>
   3165c:	0f 18 15 fd 78 fe ff 	prefetcht1 -0x18703(%rip)        # 18f60 <pf_target_24_4>
   31663:	0f 18 15 18 7c fe ff 	prefetcht1 -0x183e8(%rip)        # 19282 <pf_target_24_5>

000000000003166a <pf_jump_24>:
   3166a:	e9 11 b2 fd ff       	jmp    c880 <pf_callee_23>
   3166f:	90                   	nop

0000000000031670 <pf_call_25>:
   31670:	0f 18 15 49 af fd ff 	prefetcht1 -0x250b7(%rip)        # c5c0 <pf_callee_6>

0000000000031677 <pf_jump_25>:
   31677:	e9 04 1c fe ff       	jmp    13280 <pf_callee_15>
   3167c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031680 <pf_call_26>:
   31680:	0f 18 15 49 54 fd ff 	prefetcht1 -0x2abb7(%rip)        # 6ad0 <pf_target_26_0>
   31687:	0f 18 15 93 24 fe ff 	prefetcht1 -0x1db6d(%rip)        # 13b21 <pf_target_26_1>
   3168e:	41 53                	push   %r11
   31690:	4c 8b 1d 49 eb ff ff 	mov    -0x14b7(%rip),%r11        # 301e0 <pf_got_26_0>

0000000000031697 <pf_got_hint_26_0>:
   31697:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   3169e:	00 
   3169f:	41 5b                	pop    %r11

00000000000316a1 <pf_jump_26>:
   316a1:	e9 da b1 fd ff       	jmp    c880 <pf_callee_23>
   316a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   316ad:	00 00 00 

00000000000316b0 <pf_call_27>:
   316b0:	0f 18 15 79 19 fe ff 	prefetcht1 -0x1e687(%rip)        # 13030 <pf_callee_29>
   316b7:	0f 18 15 52 39 fe ff 	prefetcht1 -0x1c6ae(%rip)        # 15010 <pf_target_14_0>
   316be:	0f 18 15 bf 19 fe ff 	prefetcht1 -0x1e641(%rip)        # 13084 <pf_target_27_2>
   316c5:	0f 18 15 7c 19 fe ff 	prefetcht1 -0x1e684(%rip)        # 13048 <pf_target_14_1>
   316cc:	0f 18 15 e5 29 fe ff 	prefetcht1 -0x1d61b(%rip)        # 140b8 <pf_target_27_4>
   316d3:	0f 18 15 3d e3 fd ff 	prefetcht1 -0x21cc3(%rip)        # fa17 <pf_target_27_5>
   316da:	41 53                	push   %r11
   316dc:	4c 8b 1d 95 e9 ff ff 	mov    -0x166b(%rip),%r11        # 30078 <pf_got_14_0>

00000000000316e3 <pf_got_hint_27_0>:
   316e3:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   316ea:	00 

00000000000316eb <pf_got_hint_27_1>:
   316eb:	41 0f 18 93 10 00 00 	prefetcht1 0x10(%r11)
   316f2:	00 
   316f3:	41 5b                	pop    %r11

00000000000316f5 <pf_jump_27>:
   316f5:	e9 86 b1 fd ff       	jmp    c880 <pf_callee_23>
   316fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031700 <pf_call_28>:
   31700:	0f 18 15 51 59 fd ff 	prefetcht1 -0x2a6af(%rip)        # 7058 <pf_target_28_0>
   31707:	0f 18 15 88 51 fe ff 	prefetcht1 -0x1ae78(%rip)        # 16896 <pf_target_28_1>

000000000003170e <pf_jump_28>:
   3170e:	e9 6d b1 fd ff       	jmp    c880 <pf_callee_23>
   31713:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3171a:	00 00 00 
   3171d:	0f 1f 00             	nopl   (%rax)

0000000000031720 <pf_call_29>:
   31720:	0f 18 15 5e 04 fe ff 	prefetcht1 -0x1fba2(%rip)        # 11b85 <pf_target_29_0>

0000000000031727 <pf_jump_29>:
   31727:	e9 04 19 fe ff       	jmp    13030 <pf_callee_29>
   3172c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031730 <pf_call_30>:
   31730:	0f 18 15 4e 3f fe ff 	prefetcht1 -0x1c0b2(%rip)        # 15685 <pf_target_30_0>
   31737:	0f 18 15 84 27 fe ff 	prefetcht1 -0x1d87c(%rip)        # 13ec2 <pf_target_30_1>

000000000003173e <pf_jump_30>:
   3173e:	e9 1d a2 fd ff       	jmp    b960 <pf_callee_11>
   31743:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3174a:	00 00 00 
   3174d:	0f 1f 00             	nopl   (%rax)

0000000000031750 <pf_call_31>:
   31750:	0f 18 15 29 b1 fd ff 	prefetcht1 -0x24ed7(%rip)        # c880 <pf_callee_23>
   31757:	0f 18 15 62 b1 fd ff 	prefetcht1 -0x24e9e(%rip)        # c8c0 <pf_target_31_1>
   3175e:	0f 18 15 1b 27 fe ff 	prefetcht1 -0x1d8e5(%rip)        # 13e80 <pf_target_31_2>
   31765:	0f 18 15 54 ae fd ff 	prefetcht1 -0x251ac(%rip)        # c5c0 <pf_callee_6>

000000000003176c <pf_jump_31>:
   3176c:	e9 7f 3a fe ff       	jmp    151f0 <pf_callee_12>
   31771:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31778:	00 00 00 
   3177b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031780 <pf_call_32>:
   31780:	0f 18 15 39 ae fd ff 	prefetcht1 -0x251c7(%rip)        # c5c0 <pf_callee_6>
   31787:	0f 18 15 f2 b0 fd ff 	prefetcht1 -0x24f0e(%rip)        # c880 <pf_callee_23>
   3178e:	0f 18 15 eb 26 fe ff 	prefetcht1 -0x1d915(%rip)        # 13e80 <pf_target_31_2>
   31795:	0f 18 15 24 b1 fd ff 	prefetcht1 -0x24edc(%rip)        # c8c0 <pf_target_31_1>

000000000003179c <pf_jump_32>:
   3179c:	e9 0f 40 fe ff       	jmp    157b0 <pf_callee_32>
   317a1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   317a8:	00 00 00 
   317ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000317b0 <pf_call_33>:
   317b0:	0f 18 15 99 c6 fd ff 	prefetcht1 -0x23967(%rip)        # de50 <pf_callee_13>
   317b7:	0f 18 15 c2 1a fe ff 	prefetcht1 -0x1e53e(%rip)        # 13280 <pf_callee_15>
   317be:	0f 18 15 a3 c7 fd ff 	prefetcht1 -0x2385d(%rip)        # df68 <pf_target_33_2>
   317c5:	0f 18 15 b7 7f fd ff 	prefetcht1 -0x28049(%rip)        # 9783 <pf_target_33_3>
   317cc:	0f 18 15 9d 7f fd ff 	prefetcht1 -0x28063(%rip)        # 9770 <pf_target_33_4>
   317d3:	0f 18 15 16 3a fe ff 	prefetcht1 -0x1c5ea(%rip)        # 151f0 <pf_callee_12>
   317da:	0f 18 15 1f 78 fe ff 	prefetcht1 -0x187e1(%rip)        # 19000 <pf_target_33_6>

00000000000317e1 <pf_jump_33>:
   317e1:	e9 aa ee fd ff       	jmp    10690 <pf_callee_19>
   317e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   317ed:	00 00 00 

00000000000317f0 <pf_call_34>:
   317f0:	0f 18 15 c9 d0 fe ff 	prefetcht1 -0x12f37(%rip)        # 1e8c0 <pf_target_34_0>

00000000000317f7 <pf_jump_34>:
   317f7:	e9 54 cc fd ff       	jmp    e450 <pf_callee_16>
   317fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031800 <pf_call_35>:
   31800:	0f 18 15 29 73 fe ff 	prefetcht1 -0x18cd7(%rip)        # 18b30 <pf_target_35_0>
   31807:	0f 18 15 74 73 fe ff 	prefetcht1 -0x18c8c(%rip)        # 18b82 <pf_target_35_1>
   3180e:	0f 18 15 ab a2 fd ff 	prefetcht1 -0x25d55(%rip)        # bac0 <pf_target_35_2>
   31815:	0f 18 15 04 75 fe ff 	prefetcht1 -0x18afc(%rip)        # 18d20 <pf_target_35_3>
   3181c:	0f 18 15 3d d0 fe ff 	prefetcht1 -0x12fc3(%rip)        # 1e860 <pf_callee_10>
   31823:	0f 18 15 57 d0 fe ff 	prefetcht1 -0x12fa9(%rip)        # 1e881 <pf_target_35_5>
   3182a:	0f 18 15 11 73 fe ff 	prefetcht1 -0x18cef(%rip)        # 18b42 <pf_target_35_6>
   31831:	0f 18 15 0a 75 fe ff 	prefetcht1 -0x18af6(%rip)        # 18d42 <pf_target_35_7>

0000000000031838 <pf_jump_35>:
   31838:	e9 13 c6 fd ff       	jmp    de50 <pf_callee_13>
   3183d:	0f 1f 00             	nopl   (%rax)

0000000000031840 <pf_call_36>:
   31840:	0f 18 15 49 ee fd ff 	prefetcht1 -0x211b7(%rip)        # 10690 <pf_callee_19>

0000000000031847 <pf_jump_36>:
   31847:	e9 a4 76 fe ff       	jmp    18ef0 <pf_callee_36>
   3184c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031850 <pf_call_37>:
   31850:	0f 18 15 51 d7 fe ff 	prefetcht1 -0x128af(%rip)        # 1efa8 <pf_target_37_0>
   31857:	0f 18 15 12 d7 fe ff 	prefetcht1 -0x128ee(%rip)        # 1ef70 <pf_target_37_1>
   3185e:	0f 18 15 61 d7 fe ff 	prefetcht1 -0x1289f(%rip)        # 1efc6 <pf_target_37_2>

0000000000031865 <pf_jump_37>:
   31865:	e9 76 3f fd ff       	jmp    57e0 <pf_callee_37>
   3186a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031870 <pf_call_38>:
   31870:	0f 18 15 0a d8 fe ff 	prefetcht1 -0x127f6(%rip)        # 1f081 <pf_target_38_0>
   31877:	0f 18 15 92 e1 fe ff 	prefetcht1 -0x11e6e(%rip)        # 1fa10 <pf_target_38_1>
   3187e:	0f 18 15 d1 d7 fe ff 	prefetcht1 -0x1282f(%rip)        # 1f056 <pf_target_38_2>

0000000000031885 <pf_jump_38>:
   31885:	e9 e6 3b fd ff       	jmp    5470 <pf_callee_0>
   3188a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031890 <pf_call_39>:
   31890:	0f 18 15 ea a1 fd ff 	prefetcht1 -0x25e16(%rip)        # ba81 <pf_target_39_0>

0000000000031897 <pf_jump_39>:
   31897:	e9 14 3f fd ff       	jmp    57b0 <pf_callee_39>
   3189c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000318a0 <pf_call_40>:
   318a0:	41 53                	push   %r11
   318a2:	4c 8b 1d 47 e8 ff ff 	mov    -0x17b9(%rip),%r11        # 300f0 <pf_got_40_0>

00000000000318a9 <pf_got_hint_40_0>:
   318a9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   318b0:	00 
   318b1:	41 5b                	pop    %r11

00000000000318b3 <pf_jump_40>:
   318b3:	e9 88 3f fd ff       	jmp    5840 <pf_callee_40>
