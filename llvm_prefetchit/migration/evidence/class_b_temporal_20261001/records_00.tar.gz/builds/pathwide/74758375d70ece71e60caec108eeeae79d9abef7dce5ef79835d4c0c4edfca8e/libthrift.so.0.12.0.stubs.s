.text
.balign 16
.global pf_call_0
.type pf_call_0,@function
pf_call_0:
.cfi_startproc
prefetcht1 pf_target_0_0(%rip)
.global pf_jump_0
pf_jump_0:
jmp pf_callee_0
.cfi_endproc
.size pf_call_0,.-pf_call_0
.balign 16
.global pf_call_1
.type pf_call_1,@function
pf_call_1:
.cfi_startproc
prefetcht1 pf_target_1_0(%rip)
prefetcht1 pf_target_1_1(%rip)
prefetcht1 pf_target_1_2(%rip)
.global pf_jump_1
pf_jump_1:
jmp pf_callee_1
.cfi_endproc
.size pf_call_1,.-pf_call_1
.balign 16
.global pf_call_2
.type pf_call_2,@function
pf_call_2:
.cfi_startproc
prefetcht1 pf_target_2_0(%rip)
prefetcht1 pf_target_2_1(%rip)
.global pf_jump_2
pf_jump_2:
jmp pf_callee_2
.cfi_endproc
.size pf_call_2,.-pf_call_2
.balign 16
.global pf_call_3
.type pf_call_3,@function
pf_call_3:
.cfi_startproc
prefetcht1 pf_target_3_0(%rip)
prefetcht1 pf_target_3_1(%rip)
prefetcht1 pf_target_3_2(%rip)
prefetcht1 pf_target_3_3(%rip)
prefetcht1 pf_target_3_4(%rip)
prefetcht1 pf_target_3_5(%rip)
prefetcht1 pf_target_3_6(%rip)
prefetcht1 pf_target_3_7(%rip)
.global pf_jump_3
pf_jump_3:
jmp pf_callee_3
.cfi_endproc
.size pf_call_3,.-pf_call_3
.balign 16
.global pf_call_4
.type pf_call_4,@function
pf_call_4:
.cfi_startproc
prefetcht1 pf_target_4_0(%rip)
prefetcht1 pf_target_4_1(%rip)
prefetcht1 pf_target_4_2(%rip)
prefetcht1 pf_target_4_3(%rip)
.global pf_jump_4
pf_jump_4:
jmp pf_callee_4
.cfi_endproc
.size pf_call_4,.-pf_call_4
.balign 16
.global pf_call_5
.type pf_call_5,@function
pf_call_5:
.cfi_startproc
prefetcht1 pf_target_5_0(%rip)
prefetcht1 pf_target_5_1(%rip)
prefetcht1 pf_target_5_2(%rip)
prefetcht1 pf_target_5_3(%rip)
prefetcht1 pf_target_5_4(%rip)
prefetcht1 pf_target_5_5(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_5_0(%rip),%r11
.global pf_got_hint_5_0
pf_got_hint_5_0:
.byte 0x41,0x0f,0x18,0x93
.long 656544
.global pf_got_hint_5_1
pf_got_hint_5_1:
.byte 0x41,0x0f,0x18,0x93
.long 656960
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_5
pf_jump_5:
jmp pf_callee_5
.cfi_endproc
.size pf_call_5,.-pf_call_5
.balign 16
.global pf_call_6
.type pf_call_6,@function
pf_call_6:
.cfi_startproc
prefetcht1 pf_target_6_0(%rip)
prefetcht1 pf_target_6_1(%rip)
prefetcht1 pf_target_6_2(%rip)
prefetcht1 pf_target_6_3(%rip)
prefetcht1 pf_target_6_4(%rip)
prefetcht1 pf_target_6_5(%rip)
prefetcht1 pf_target_6_6(%rip)
.global pf_jump_6
pf_jump_6:
jmp pf_callee_6
.cfi_endproc
.size pf_call_6,.-pf_call_6
.balign 16
.global pf_call_7
.type pf_call_7,@function
pf_call_7:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_7_0(%rip),%r11
.global pf_got_hint_7_0
pf_got_hint_7_0:
.byte 0x41,0x0f,0x18,0x93
.long -44096
.global pf_got_hint_7_1
pf_got_hint_7_1:
.byte 0x41,0x0f,0x18,0x93
.long 7537
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_7
pf_jump_7:
jmp pf_callee_7
.cfi_endproc
.size pf_call_7,.-pf_call_7
.section .note.GNU-stack,"",@progbits
