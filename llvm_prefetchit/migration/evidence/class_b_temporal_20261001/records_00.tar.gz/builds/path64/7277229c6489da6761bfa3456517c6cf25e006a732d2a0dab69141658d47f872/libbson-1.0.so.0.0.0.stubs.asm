
/storage/prefetchit/class_b_temporal_20261001/builds/path64/7277229c6489da6761bfa3456517c6cf25e006a732d2a0dab69141658d47f872/call-stub-i4qo8aia/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000422c0 <pf_call_0>:
   422c0:	0f 18 15 d9 b9 fc ff 	prefetcht1 -0x34627(%rip)        # dca0 <pf_target_0_0>
   422c7:	0f 18 15 73 10 fd ff 	prefetcht1 -0x2ef8d(%rip)        # 13341 <pf_target_0_1>
   422ce:	0f 18 15 3b 10 fd ff 	prefetcht1 -0x2efc5(%rip)        # 13310 <pf_target_0_2>
   422d5:	0f 18 15 14 0f fd ff 	prefetcht1 -0x2f0ec(%rip)        # 131f0 <pf_target_0_3>

00000000000422dc <pf_jump_0>:
   422dc:	e9 4f b4 fc ff       	jmp    d730 <pf_callee_0>
   422e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   422e8:	00 00 00 
   422eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000422f0 <pf_call_1>:
   422f0:	0f 18 15 49 cd fc ff 	prefetcht1 -0x332b7(%rip)        # f040 <pf_target_1_0>

00000000000422f7 <pf_jump_1>:
   422f7:	e9 b4 ad fc ff       	jmp    d0b0 <pf_callee_1>
   422fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042300 <pf_call_2>:
   42300:	0f 18 15 09 c2 fc ff 	prefetcht1 -0x33df7(%rip)        # e510 <pf_target_2_0>
   42307:	0f 18 15 34 c2 fc ff 	prefetcht1 -0x33dcc(%rip)        # e542 <pf_target_2_1>

000000000004230e <pf_jump_2>:
   4230e:	e9 cd b1 fc ff       	jmp    d4e0 <pf_callee_2>
   42313:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4231a:	00 00 00 
   4231d:	0f 1f 00             	nopl   (%rax)

0000000000042320 <pf_call_3>:
   42320:	0f 18 15 f9 00 fd ff 	prefetcht1 -0x2ff07(%rip)        # 12420 <pf_target_3_0>
   42327:	0f 18 15 12 01 fd ff 	prefetcht1 -0x2feee(%rip)        # 12440 <pf_target_3_1>

000000000004232e <pf_jump_3>:
   4232e:	e9 3d ac fc ff       	jmp    cf70 <pf_callee_3>
   42333:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4233a:	00 00 00 
   4233d:	0f 1f 00             	nopl   (%rax)

0000000000042340 <pf_call_4>:
   42340:	0f 18 15 b9 06 fd ff 	prefetcht1 -0x2f947(%rip)        # 12a00 <pf_target_4_0>

0000000000042347 <pf_jump_4>:
   42347:	e9 34 ae fc ff       	jmp    d180 <pf_callee_4>
   4234c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042350 <pf_call_5>:
   42350:	0f 18 15 d7 9e fd ff 	prefetcht1 -0x26129(%rip)        # 1c22e <pf_target_5_0>

0000000000042357 <pf_jump_5>:
   42357:	e9 64 ab fc ff       	jmp    cec0 <pf_callee_5>
   4235c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042360 <pf_call_6>:
   42360:	0f 18 15 59 0c fd ff 	prefetcht1 -0x2f3a7(%rip)        # 12fc0 <pf_target_6_0>

0000000000042367 <pf_jump_6>:
   42367:	e9 14 ae fc ff       	jmp    d180 <pf_callee_4>
   4236c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042370 <pf_call_7>:
   42370:	0f 18 15 a9 fe fd ff 	prefetcht1 -0x20157(%rip)        # 22220 <pf_target_7_0>
   42377:	0f 18 15 c2 fe fd ff 	prefetcht1 -0x2013e(%rip)        # 22240 <pf_target_7_1>

000000000004237e <pf_jump_7>:
   4237e:	e9 3d fa fc ff       	jmp    11dc0 <pf_callee_7>
   42383:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4238a:	00 00 00 
   4238d:	0f 1f 00             	nopl   (%rax)

0000000000042390 <pf_call_8>:
   42390:	0f 18 15 59 dc fc ff 	prefetcht1 -0x323a7(%rip)        # fff0 <pf_target_8_0>
   42397:	0f 18 15 67 dc fc ff 	prefetcht1 -0x32399(%rip)        # 10005 <pf_target_8_1>
   4239e:	0f 18 15 6b 0f fd ff 	prefetcht1 -0x2f095(%rip)        # 13310 <pf_target_0_2>
   423a5:	0f 18 15 14 fa fc ff 	prefetcht1 -0x305ec(%rip)        # 11dc0 <pf_callee_7>

00000000000423ac <pf_jump_8>:
   423ac:	e9 1f a8 fc ff       	jmp    cbd0 <pf_callee_8>
   423b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   423b8:	00 00 00 
   423bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000423c0 <pf_call_9>:
   423c0:	0f 18 15 f9 96 fd ff 	prefetcht1 -0x26907(%rip)        # 1bac0 <pf_target_9_0>
   423c7:	0f 18 15 e2 77 fd ff 	prefetcht1 -0x2881e(%rip)        # 19bb0 <pf_target_9_1>

00000000000423ce <pf_jump_9>:
   423ce:	e9 cd ae fc ff       	jmp    d2a0 <pf_callee_10>
   423d3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   423da:	00 00 00 
   423dd:	0f 1f 00             	nopl   (%rax)

00000000000423e0 <pf_call_10>:
   423e0:	0f 18 15 a9 41 fe ff 	prefetcht1 -0x1be57(%rip)        # 26590 <pf_target_10_0>
   423e7:	0f 18 15 02 9f fd ff 	prefetcht1 -0x260fe(%rip)        # 1c2f0 <pf_target_10_1>
   423ee:	0f 18 15 ce 41 fe ff 	prefetcht1 -0x1be32(%rip)        # 265c3 <pf_target_10_2>
   423f5:	0f 18 15 44 aa fc ff 	prefetcht1 -0x355bc(%rip)        # ce40 <pf_target_10_3>

00000000000423fc <pf_jump_10>:
   423fc:	e9 9f ae fc ff       	jmp    d2a0 <pf_callee_10>
   42401:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   42408:	00 00 00 
   4240b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000042410 <pf_call_11>:
   42410:	0f 18 15 f9 13 fd ff 	prefetcht1 -0x2ec07(%rip)        # 13810 <pf_target_11_0>

0000000000042417 <pf_jump_11>:
   42417:	e9 74 a9 fc ff       	jmp    cd90 <pf_callee_11>
   4241c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042420 <pf_call_12>:
   42420:	0f 18 15 9b 55 fd ff 	prefetcht1 -0x2aa65(%rip)        # 179c2 <pf_target_12_0>
   42427:	41 53                	push   %r11
   42429:	4c 8b 1d 00 8d ff ff 	mov    -0x7300(%rip),%r11        # 3b130 <pf_got_12_0>

0000000000042430 <pf_got_hint_12_0>:
   42430:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   42437:	00 
   42438:	41 5b                	pop    %r11

000000000004243a <pf_jump_12>:
   4243a:	e9 81 b1 fc ff       	jmp    d5c0 <pf_callee_12>
   4243f:	90                   	nop

0000000000042440 <pf_call_13>:
   42440:	0f 18 15 89 25 fe ff 	prefetcht1 -0x1da77(%rip)        # 249d0 <pf_target_13_0>

0000000000042447 <pf_jump_13>:
   42447:	e9 54 ae fc ff       	jmp    d2a0 <pf_callee_10>
   4244c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042450 <pf_call_14>:
   42450:	0f 18 15 e9 84 fd ff 	prefetcht1 -0x27b17(%rip)        # 1a940 <pf_target_14_0>

0000000000042457 <pf_jump_14>:
   42457:	e9 44 ac fc ff       	jmp    d0a0 <pf_callee_14>
   4245c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042460 <pf_call_15>:
   42460:	0f 18 15 49 91 fd ff 	prefetcht1 -0x26eb7(%rip)        # 1b5b0 <pf_target_15_0>

0000000000042467 <pf_jump_15>:
   42467:	e9 b4 ac fc ff       	jmp    d120 <pf_callee_15>
   4246c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042470 <pf_call_16>:
   42470:	0f 18 15 d9 ed fc ff 	prefetcht1 -0x31227(%rip)        # 11250 <pf_target_16_0>
   42477:	0f 18 15 62 8a fd ff 	prefetcht1 -0x2759e(%rip)        # 1aee0 <pf_target_16_1>

000000000004247e <pf_jump_16>:
   4247e:	e9 5d a8 fc ff       	jmp    cce0 <pf_callee_16>
   42483:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4248a:	00 00 00 
   4248d:	0f 1f 00             	nopl   (%rax)

0000000000042490 <pf_call_17>:
   42490:	0f 18 15 69 e9 fc ff 	prefetcht1 -0x31697(%rip)        # 10e00 <pf_target_17_0>

0000000000042497 <pf_jump_17>:
   42497:	e9 e4 af fc ff       	jmp    d480 <pf_callee_17>
   4249c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000424a0 <pf_call_18>:
   424a0:	0f 18 15 89 56 fd ff 	prefetcht1 -0x2a977(%rip)        # 17b30 <pf_target_18_0>

00000000000424a7 <pf_jump_18>:
   424a7:	e9 64 ad fc ff       	jmp    d210 <pf_callee_18>
   424ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000424b0 <pf_call_19>:
   424b0:	0f 18 15 69 41 fd ff 	prefetcht1 -0x2be97(%rip)        # 16620 <pf_target_19_0>

00000000000424b7 <pf_jump_19>:
   424b7:	e9 14 b1 fc ff       	jmp    d5d0 <pf_callee_19>
   424bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000424c0 <pf_call_20>:
   424c0:	0f 18 15 39 80 fd ff 	prefetcht1 -0x27fc7(%rip)        # 1a500 <pf_target_20_0>
   424c7:	0f 18 15 42 7e fd ff 	prefetcht1 -0x281be(%rip)        # 1a310 <pf_target_20_1>
   424ce:	0f 18 15 fb 2b fd ff 	prefetcht1 -0x2d405(%rip)        # 150d0 <pf_target_20_2>
   424d5:	0f 18 15 84 7f fd ff 	prefetcht1 -0x2807c(%rip)        # 1a460 <pf_target_20_3>

00000000000424dc <pf_jump_20>:
   424dc:	e9 6f a7 fc ff       	jmp    cc50 <pf_callee_20>
   424e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   424e8:	00 00 00 
   424eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000424f0 <pf_call_21>:
   424f0:	41 53                	push   %r11
   424f2:	4c 8b 1d 4f 90 ff ff 	mov    -0x6fb1(%rip),%r11        # 3b548 <pf_got_21_0>

00000000000424f9 <pf_got_hint_21_0>:
   424f9:	41 0f 18 93 60 bf fd 	prefetcht1 -0x240a0(%r11)
   42500:	ff 

0000000000042501 <pf_got_hint_21_1>:
   42501:	41 0f 18 93 e8 ca fd 	prefetcht1 -0x23518(%r11)
   42508:	ff 

0000000000042509 <pf_got_hint_21_2>:
   42509:	41 0f 18 93 f7 cd fd 	prefetcht1 -0x23209(%r11)
   42510:	ff 

0000000000042511 <pf_got_hint_21_3>:
   42511:	41 0f 18 93 90 46 ff 	prefetcht1 -0xb970(%r11)
   42518:	ff 
   42519:	41 5b                	pop    %r11

000000000004251b <pf_jump_21>:
   4251b:	e9 00 ae fc ff       	jmp    d320 <pf_callee_21>

0000000000042520 <pf_call_22>:
   42520:	41 53                	push   %r11
   42522:	4c 8b 1d ff 8e ff ff 	mov    -0x7101(%rip),%r11        # 3b428 <pf_got_22_0>

0000000000042529 <pf_got_hint_22_0>:
   42529:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   42530:	00 

0000000000042531 <pf_got_hint_22_1>:
   42531:	41 0f 18 93 11 00 00 	prefetcht1 0x11(%r11)
   42538:	00 
   42539:	4c 8b 1d 08 90 ff ff 	mov    -0x6ff8(%rip),%r11        # 3b548 <pf_got_21_0>

0000000000042540 <pf_got_hint_22_2>:
   42540:	41 0f 18 93 42 46 ff 	prefetcht1 -0xb9be(%r11)
   42547:	ff 
   42548:	41 5b                	pop    %r11

000000000004254a <pf_jump_22>:
   4254a:	e9 d1 ad fc ff       	jmp    d320 <pf_callee_21>
