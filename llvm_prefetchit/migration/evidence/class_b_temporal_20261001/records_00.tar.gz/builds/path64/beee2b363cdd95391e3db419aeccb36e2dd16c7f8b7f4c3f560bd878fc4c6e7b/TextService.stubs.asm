
/storage/prefetchit/class_b_temporal_20261001/builds/path64/beee2b363cdd95391e3db419aeccb36e2dd16c7f8b7f4c3f560bd878fc4c6e7b/call-stub-tahrlnje/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000110340 <pf_call_0>:
  110340:	0f 18 15 e9 88 f3 ff 	prefetcht1 -0xc7717(%rip)        # 48c30 <pf_target_0_0>
  110347:	0f 18 15 62 31 f3 ff 	prefetcht1 -0xcce9e(%rip)        # 434b0 <pf_target_0_1>
  11034e:	0f 18 15 af 31 f3 ff 	prefetcht1 -0xcce51(%rip)        # 43504 <pf_target_0_2>
  110355:	0f 18 15 c4 3b f3 ff 	prefetcht1 -0xcc43c(%rip)        # 43f20 <pf_target_0_3>

000000000011035c <pf_jump_0>:
  11035c:	e9 bf 5f f1 ff       	jmp    26320 <pf_callee_0>
  110361:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  110368:	00 00 00 
  11036b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000110370 <pf_call_1>:
  110370:	0f 18 15 29 06 f2 ff 	prefetcht1 -0xdf9d7(%rip)        # 309a0 <pf_target_1_0>

0000000000110377 <pf_jump_1>:
  110377:	e9 a4 5f f1 ff       	jmp    26320 <pf_callee_0>
  11037c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110380 <pf_call_2>:
  110380:	41 53                	push   %r11
  110382:	4c 8b 1d bf e3 ff ff 	mov    -0x1c41(%rip),%r11        # 10e748 <pf_got_2_0>

0000000000110389 <pf_got_hint_2_0>:
  110389:	41 0f 18 93 34 00 00 	prefetcht1 0x34(%r11)
  110390:	00 
  110391:	41 5b                	pop    %r11

0000000000110393 <pf_jump_2>:
  110393:	e9 88 5f f1 ff       	jmp    26320 <pf_callee_0>
  110398:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11039f:	00 

00000000001103a0 <pf_call_3>:
  1103a0:	0f 18 15 59 8c f5 ff 	prefetcht1 -0xa73a7(%rip)        # 69000 <pf_target_3_0>
  1103a7:	0f 18 15 22 be f4 ff 	prefetcht1 -0xb41de(%rip)        # 5c1d0 <pf_target_3_1>

00000000001103ae <pf_jump_3>:
  1103ae:	e9 1d 07 f2 ff       	jmp    30ad0 <pf_callee_3>
  1103b3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1103ba:	00 00 00 
  1103bd:	0f 1f 00             	nopl   (%rax)

00000000001103c0 <pf_call_4>:
  1103c0:	41 53                	push   %r11
  1103c2:	4c 8b 1d cf e0 ff ff 	mov    -0x1f31(%rip),%r11        # 10e498 <pf_got_4_0>

00000000001103c9 <pf_got_hint_4_0>:
  1103c9:	41 0f 18 93 30 f5 ff 	prefetcht1 -0xad0(%r11)
  1103d0:	ff 

00000000001103d1 <pf_got_hint_4_1>:
  1103d1:	41 0f 18 93 41 f5 ff 	prefetcht1 -0xabf(%r11)
  1103d8:	ff 
  1103d9:	41 5b                	pop    %r11

00000000001103db <pf_jump_4>:
  1103db:	e9 d0 94 f3 ff       	jmp    498b0 <pf_callee_4>

00000000001103e0 <pf_call_5>:
  1103e0:	0f 18 15 79 be f4 ff 	prefetcht1 -0xb4187(%rip)        # 5c260 <pf_target_5_0>

00000000001103e7 <pf_jump_5>:
  1103e7:	e9 24 5f f1 ff       	jmp    26310 <pf_callee_5>
  1103ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001103f0 <pf_call_6>:
  1103f0:	0f 18 15 0d 3c f3 ff 	prefetcht1 -0xcc3f3(%rip)        # 44004 <pf_target_6_0>
  1103f7:	0f 18 15 44 88 f3 ff 	prefetcht1 -0xc77bc(%rip)        # 48c42 <pf_target_6_1>

00000000001103fe <pf_jump_6>:
  1103fe:	e9 bd 5d f1 ff       	jmp    261c0 <pf_callee_6>
  110403:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11040a:	00 00 00 
  11040d:	0f 1f 00             	nopl   (%rax)

0000000000110410 <pf_call_7>:
  110410:	41 53                	push   %r11
  110412:	4c 8b 1d 5f df ff ff 	mov    -0x20a1(%rip),%r11        # 10e378 <pf_got_7_0>

0000000000110419 <pf_got_hint_7_0>:
  110419:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110420:	00 
  110421:	4c 8b 1d 68 e3 ff ff 	mov    -0x1c98(%rip),%r11        # 10e790 <pf_got_12_0>

0000000000110428 <pf_got_hint_7_1>:
  110428:	41 0f 18 93 20 26 ff 	prefetcht1 -0xd9e0(%r11)
  11042f:	ff 

0000000000110430 <pf_got_hint_7_2>:
  110430:	41 0f 18 93 a0 f5 ff 	prefetcht1 -0xa60(%r11)
  110437:	ff 

0000000000110438 <pf_got_hint_7_3>:
  110438:	41 0f 18 93 b0 f5 ff 	prefetcht1 -0xa50(%r11)
  11043f:	ff 
  110440:	41 5b                	pop    %r11

0000000000110442 <pf_jump_7>:
  110442:	e9 89 52 f3 ff       	jmp    456d0 <pf_callee_7>
  110447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  11044e:	00 00 

0000000000110450 <pf_call_8>:
  110450:	0f 18 15 d9 61 f1 ff 	prefetcht1 -0xe9e27(%rip)        # 26630 <pf_target_8_0>
  110457:	41 53                	push   %r11
  110459:	4c 8b 1d b8 de ff ff 	mov    -0x2148(%rip),%r11        # 10e318 <pf_got_8_0>

0000000000110460 <pf_got_hint_8_0>:
  110460:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110467:	00 

0000000000110468 <pf_got_hint_8_1>:
  110468:	41 0f 18 93 11 00 00 	prefetcht1 0x11(%r11)
  11046f:	00 
  110470:	4c 8b 1d b9 e0 ff ff 	mov    -0x1f47(%rip),%r11        # 10e530 <pf_got_14_0>

0000000000110477 <pf_got_hint_8_2>:
  110477:	41 0f 18 93 22 fd ff 	prefetcht1 -0x2de(%r11)
  11047e:	ff 
  11047f:	41 5b                	pop    %r11

0000000000110481 <pf_jump_8>:
  110481:	e9 5a 65 f1 ff       	jmp    269e0 <pf_callee_8>
  110486:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11048d:	00 00 00 

0000000000110490 <pf_call_9>:
  110490:	41 53                	push   %r11
  110492:	4c 8b 1d 07 dc ff ff 	mov    -0x23f9(%rip),%r11        # 10e0a0 <pf_got_20_0>

0000000000110499 <pf_got_hint_9_0>:
  110499:	41 0f 18 93 10 2a ff 	prefetcht1 -0xd5f0(%r11)
  1104a0:	ff 
  1104a1:	41 5b                	pop    %r11

00000000001104a3 <pf_jump_9>:
  1104a3:	e9 48 5c f1 ff       	jmp    260f0 <pf_callee_9>
  1104a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1104af:	00 

00000000001104b0 <pf_call_10>:
  1104b0:	0f 18 15 f9 4f f3 ff 	prefetcht1 -0xcb007(%rip)        # 454b0 <pf_target_10_0>

00000000001104b7 <pf_jump_10>:
  1104b7:	e9 84 5c f1 ff       	jmp    26140 <pf_callee_10>
  1104bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001104c0 <pf_call_11>:
  1104c0:	41 53                	push   %r11
  1104c2:	4c 8b 1d 2f e2 ff ff 	mov    -0x1dd1(%rip),%r11        # 10e6f8 <pf_got_11_0>

00000000001104c9 <pf_got_hint_11_0>:
  1104c9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1104d0:	00 
  1104d1:	41 5b                	pop    %r11

00000000001104d3 <pf_jump_11>:
  1104d3:	e9 68 5c f1 ff       	jmp    26140 <pf_callee_10>
  1104d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1104df:	00 

00000000001104e0 <pf_call_12>:
  1104e0:	41 53                	push   %r11
  1104e2:	4c 8b 1d a7 e2 ff ff 	mov    -0x1d59(%rip),%r11        # 10e790 <pf_got_12_0>

00000000001104e9 <pf_got_hint_12_0>:
  1104e9:	41 0f 18 93 70 46 fe 	prefetcht1 -0x1b990(%r11)
  1104f0:	ff 
  1104f1:	41 5b                	pop    %r11

00000000001104f3 <pf_jump_12>:
  1104f3:	e9 38 64 f1 ff       	jmp    26930 <pf_callee_12>
  1104f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1104ff:	00 

0000000000110500 <pf_call_13>:
  110500:	0f 18 15 49 fe f2 ff 	prefetcht1 -0xd01b7(%rip)        # 40350 <pf_callee_14>

0000000000110507 <pf_jump_13>:
  110507:	e9 44 4a f3 ff       	jmp    44f50 <pf_callee_13>
  11050c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110510 <pf_call_14>:
  110510:	0f 18 15 39 6a f1 ff 	prefetcht1 -0xe95c7(%rip)        # 26f50 <pf_target_14_0>
  110517:	41 53                	push   %r11
  110519:	4c 8b 1d 10 e0 ff ff 	mov    -0x1ff0(%rip),%r11        # 10e530 <pf_got_14_0>

0000000000110520 <pf_got_hint_14_0>:
  110520:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110527:	00 
  110528:	41 5b                	pop    %r11

000000000011052a <pf_jump_14>:
  11052a:	e9 21 fe f2 ff       	jmp    40350 <pf_callee_14>
  11052f:	90                   	nop

0000000000110530 <pf_call_15>:
  110530:	41 53                	push   %r11
  110532:	4c 8b 1d 57 e2 ff ff 	mov    -0x1da9(%rip),%r11        # 10e790 <pf_got_12_0>

0000000000110539 <pf_got_hint_15_0>:
  110539:	41 0f 18 93 10 29 ff 	prefetcht1 -0xd6f0(%r11)
  110540:	ff 
  110541:	41 5b                	pop    %r11

0000000000110543 <pf_jump_15>:
  110543:	e9 58 52 f3 ff       	jmp    457a0 <pf_callee_15>
  110548:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11054f:	00 

0000000000110550 <pf_call_16>:
  110550:	0f 18 15 c9 6a f1 ff 	prefetcht1 -0xe9537(%rip)        # 27020 <pf_target_16_0>

0000000000110557 <pf_jump_16>:
  110557:	e9 04 90 f3 ff       	jmp    49560 <pf_callee_16>
  11055c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110560 <pf_call_17>:
  110560:	0f 18 15 2e 17 f5 ff 	prefetcht1 -0xae8d2(%rip)        # 61c95 <pf_target_17_0>
  110567:	0f 18 15 89 34 f5 ff 	prefetcht1 -0xacb77(%rip)        # 639f7 <pf_target_17_1>
  11056e:	0f 18 15 4b ca f4 ff 	prefetcht1 -0xb35b5(%rip)        # 5cfc0 <pf_target_17_2>

0000000000110575 <pf_jump_17>:
  110575:	e9 c6 5b f1 ff       	jmp    26140 <pf_callee_10>
  11057a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000110580 <pf_call_18>:
  110580:	0f 18 15 d6 1a f5 ff 	prefetcht1 -0xae52a(%rip)        # 6205d <pf_target_18_0>

0000000000110587 <pf_jump_18>:
  110587:	e9 f4 93 f3 ff       	jmp    49980 <pf_callee_18>
  11058c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110590 <pf_call_19>:
  110590:	0f 18 15 d9 c7 f4 ff 	prefetcht1 -0xb3827(%rip)        # 5cd70 <pf_target_19_0>

0000000000110597 <pf_jump_19>:
  110597:	e9 44 61 f1 ff       	jmp    266e0 <pf_callee_19>
  11059c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001105a0 <pf_call_20>:
  1105a0:	0f 18 15 19 3c f5 ff 	prefetcht1 -0xac3e7(%rip)        # 641c0 <pf_callee_23>
  1105a7:	41 53                	push   %r11
  1105a9:	4c 8b 1d f0 da ff ff 	mov    -0x2510(%rip),%r11        # 10e0a0 <pf_got_20_0>

00000000001105b0 <pf_got_hint_20_0>:
  1105b0:	41 0f 18 93 b0 53 ff 	prefetcht1 -0xac50(%r11)
  1105b7:	ff 
  1105b8:	41 5b                	pop    %r11

00000000001105ba <pf_jump_20>:
  1105ba:	e9 d1 ce f4 ff       	jmp    5d490 <pf_callee_20>
  1105bf:	90                   	nop

00000000001105c0 <pf_call_21>:
  1105c0:	0f 18 15 19 61 f1 ff 	prefetcht1 -0xe9ee7(%rip)        # 266e0 <pf_callee_19>
  1105c7:	0f 18 15 c2 6a f1 ff 	prefetcht1 -0xe953e(%rip)        # 27090 <pf_callee_24>
  1105ce:	0f 18 15 ab 11 f5 ff 	prefetcht1 -0xaee55(%rip)        # 61780 <pf_target_21_2>
  1105d5:	0f 18 15 f0 33 f5 ff 	prefetcht1 -0xacc10(%rip)        # 639cc <pf_target_21_3>

00000000001105dc <pf_jump_21>:
  1105dc:	e9 af ce f4 ff       	jmp    5d490 <pf_callee_20>
  1105e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1105e8:	00 00 00 
  1105eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000001105f0 <pf_call_22>:
  1105f0:	0f 18 15 d9 67 f1 ff 	prefetcht1 -0xe9827(%rip)        # 26dd0 <pf_callee_26>

00000000001105f7 <pf_jump_22>:
  1105f7:	e9 e4 60 f1 ff       	jmp    266e0 <pf_callee_19>
  1105fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110600 <pf_call_23>:
  110600:	0f 18 15 79 8c f3 ff 	prefetcht1 -0xc7387(%rip)        # 49280 <pf_target_23_0>

0000000000110607 <pf_jump_23>:
  110607:	e9 b4 3b f5 ff       	jmp    641c0 <pf_callee_23>
  11060c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110610 <pf_call_24>:
  110610:	0f 18 15 99 17 f5 ff 	prefetcht1 -0xae867(%rip)        # 61db0 <pf_target_24_0>
  110617:	0f 18 15 72 fb f4 ff 	prefetcht1 -0xb048e(%rip)        # 60190 <pf_target_24_1>
  11061e:	0f 18 15 4b c3 f4 ff 	prefetcht1 -0xb3cb5(%rip)        # 5c970 <pf_target_24_2>

0000000000110625 <pf_jump_24>:
  110625:	e9 66 6a f1 ff       	jmp    27090 <pf_callee_24>
  11062a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000110630 <pf_call_25>:
  110630:	0f 18 15 49 33 f5 ff 	prefetcht1 -0xaccb7(%rip)        # 63980 <pf_target_25_0>

0000000000110637 <pf_jump_25>:
  110637:	e9 04 5b f1 ff       	jmp    26140 <pf_callee_10>
  11063c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110640 <pf_call_26>:
  110640:	0f 18 15 a9 4d f5 ff 	prefetcht1 -0xab257(%rip)        # 653f0 <pf_target_26_0>
  110647:	41 53                	push   %r11
  110649:	4c 8b 1d 50 da ff ff 	mov    -0x25b0(%rip),%r11        # 10e0a0 <pf_got_20_0>

0000000000110650 <pf_got_hint_26_0>:
  110650:	41 0f 18 93 e0 48 ff 	prefetcht1 -0xb720(%r11)
  110657:	ff 
  110658:	4c 8b 1d 89 e0 ff ff 	mov    -0x1f77(%rip),%r11        # 10e6e8 <pf_got_26_1>

000000000011065f <pf_got_hint_26_1>:
  11065f:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110666:	00 
  110667:	41 5b                	pop    %r11

0000000000110669 <pf_jump_26>:
  110669:	e9 62 67 f1 ff       	jmp    26dd0 <pf_callee_26>
  11066e:	66 90                	xchg   %ax,%ax

0000000000110670 <pf_call_27>:
  110670:	0f 18 15 6a dc f1 ff 	prefetcht1 -0xe2396(%rip)        # 2e2e1 <pf_target_27_0>
  110677:	41 53                	push   %r11
  110679:	4c 8b 1d e8 d9 ff ff 	mov    -0x2618(%rip),%r11        # 10e068 <pf_got_27_0>

0000000000110680 <pf_got_hint_27_0>:
  110680:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110687:	00 
  110688:	41 5b                	pop    %r11

000000000011068a <pf_jump_27>:
  11068a:	e9 71 85 f6 ff       	jmp    78c00 <pf_callee_27>
