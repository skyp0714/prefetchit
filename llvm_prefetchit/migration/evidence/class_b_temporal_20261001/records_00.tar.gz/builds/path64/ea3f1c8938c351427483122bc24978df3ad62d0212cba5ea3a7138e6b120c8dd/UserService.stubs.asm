
/storage/prefetchit/class_b_temporal_20261001/builds/path64/ea3f1c8938c351427483122bc24978df3ad62d0212cba5ea3a7138e6b120c8dd/call-stub-0fd9uwfp/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000013f340 <pf_call_0>:
  13f340:	0f 18 15 bc 68 f1 ff 	prefetcht1 -0xe9744(%rip)        # 55c03 <pf_target_0_0>
  13f347:	0f 18 15 a2 72 f1 ff 	prefetcht1 -0xe8d5e(%rip)        # 565f0 <pf_target_0_1>
  13f34e:	0f 18 15 2b 68 f1 ff 	prefetcht1 -0xe97d5(%rip)        # 55b80 <pf_target_0_2>
  13f355:	0f 18 15 a6 bf f1 ff 	prefetcht1 -0xe405a(%rip)        # 5b302 <pf_target_0_3>

000000000013f35c <pf_jump_0>:
  13f35c:	e9 ef a0 ee ff       	jmp    29450 <pf_callee_0>
  13f361:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f368:	00 00 00 
  13f36b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000013f370 <pf_call_1>:
  13f370:	41 53                	push   %r11
  13f372:	4c 8b 1d bf dd ff ff 	mov    -0x2241(%rip),%r11        # 13d138 <pf_got_1_0>

000000000013f379 <pf_got_hint_1_0>:
  13f379:	41 0f 18 93 b0 06 00 	prefetcht1 0x6b0(%r11)
  13f380:	00 

000000000013f381 <pf_got_hint_1_1>:
  13f381:	41 0f 18 93 d2 06 00 	prefetcht1 0x6d2(%r11)
  13f388:	00 
  13f389:	41 5b                	pop    %r11

000000000013f38b <pf_jump_1>:
  13f38b:	e9 c0 a0 ee ff       	jmp    29450 <pf_callee_0>

000000000013f390 <pf_call_2>:
  13f390:	41 53                	push   %r11
  13f392:	4c 8b 1d 57 e5 ff ff 	mov    -0x1aa9(%rip),%r11        # 13d8f0 <pf_got_2_0>

000000000013f399 <pf_got_hint_2_0>:
  13f399:	41 0f 18 93 34 00 00 	prefetcht1 0x34(%r11)
  13f3a0:	00 
  13f3a1:	41 5b                	pop    %r11

000000000013f3a3 <pf_jump_2>:
  13f3a3:	e9 a8 a0 ee ff       	jmp    29450 <pf_callee_0>
  13f3a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  13f3af:	00 

000000000013f3b0 <pf_call_3>:
  13f3b0:	41 53                	push   %r11
  13f3b2:	4c 8b 1d b7 e1 ff ff 	mov    -0x1e49(%rip),%r11        # 13d570 <pf_got_3_0>

000000000013f3b9 <pf_got_hint_3_0>:
  13f3b9:	41 0f 18 93 c0 fc ff 	prefetcht1 -0x340(%r11)
  13f3c0:	ff 

000000000013f3c1 <pf_got_hint_3_1>:
  13f3c1:	41 0f 18 93 d3 fc ff 	prefetcht1 -0x32d(%r11)
  13f3c8:	ff 

000000000013f3c9 <pf_got_hint_3_2>:
  13f3c9:	41 0f 18 93 10 00 00 	prefetcht1 0x10(%r11)
  13f3d0:	00 
  13f3d1:	41 5b                	pop    %r11

000000000013f3d3 <pf_jump_3>:
  13f3d3:	e9 08 a7 ee ff       	jmp    29ae0 <pf_callee_3>
  13f3d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  13f3df:	00 

000000000013f3e0 <pf_call_4>:
  13f3e0:	0f 18 15 49 3f f7 ff 	prefetcht1 -0x8c0b7(%rip)        # b3330 <pf_target_4_0>
  13f3e7:	0f 18 15 a2 ad f7 ff 	prefetcht1 -0x8525e(%rip)        # ba190 <pf_target_4_1>
  13f3ee:	0f 18 15 cb 06 f7 ff 	prefetcht1 -0x8f935(%rip)        # afac0 <pf_target_4_2>
  13f3f5:	0f 18 15 d4 d9 f8 ff 	prefetcht1 -0x7262c(%rip)        # ccdd0 <pf_callee_6>

000000000013f3fc <pf_jump_4>:
  13f3fc:	e9 0f cb f1 ff       	jmp    5bf10 <pf_callee_4>
  13f401:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f408:	00 00 00 
  13f40b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000013f410 <pf_call_5>:
  13f410:	0f 18 15 09 87 fa ff 	prefetcht1 -0x578f7(%rip)        # e7b20 <pf_target_5_0>
  13f417:	0f 18 15 e2 30 fb ff 	prefetcht1 -0x4cf1e(%rip)        # f2500 <pf_target_5_1>
  13f41e:	0f 18 15 cb af ee ff 	prefetcht1 -0x115035(%rip)        # 2a3f0 <pf_target_5_2>
  13f425:	0f 18 15 14 8c fa ff 	prefetcht1 -0x573ec(%rip)        # e8040 <pf_target_5_3>

000000000013f42c <pf_jump_5>:
  13f42c:	e9 3f 9c ee ff       	jmp    29070 <pf_callee_5>
  13f431:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f438:	00 00 00 
  13f43b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000013f440 <pf_call_6>:
  13f440:	0f 18 15 7e ad f7 ff 	prefetcht1 -0x85282(%rip)        # ba1c5 <pf_target_6_0>
  13f447:	0f 18 15 82 9d f6 ff 	prefetcht1 -0x9627e(%rip)        # a91d0 <pf_target_6_1>
  13f44e:	0f 18 15 eb 3e f7 ff 	prefetcht1 -0x8c115(%rip)        # b3340 <pf_target_6_2>

000000000013f455 <pf_jump_6>:
  13f455:	e9 76 d9 f8 ff       	jmp    ccdd0 <pf_callee_6>
  13f45a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000013f460 <pf_call_7>:
  13f460:	41 53                	push   %r11
  13f462:	4c 8b 1d 17 e3 ff ff 	mov    -0x1ce9(%rip),%r11        # 13d780 <pf_got_7_0>

000000000013f469 <pf_got_hint_7_0>:
  13f469:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  13f470:	00 

000000000013f471 <pf_got_hint_7_1>:
  13f471:	41 0f 18 93 50 05 00 	prefetcht1 0x550(%r11)
  13f478:	00 
  13f479:	41 5b                	pop    %r11

000000000013f47b <pf_jump_7>:
  13f47b:	e9 10 a2 ee ff       	jmp    29690 <pf_callee_7>

000000000013f480 <pf_call_8>:
  13f480:	0f 18 15 59 74 f3 ff 	prefetcht1 -0xc8ba7(%rip)        # 768e0 <pf_target_8_0>

000000000013f487 <pf_jump_8>:
  13f487:	e9 a4 45 f0 ff       	jmp    43a30 <pf_callee_8>
  13f48c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f490 <pf_call_9>:
  13f490:	0f 18 15 b6 60 f4 ff 	prefetcht1 -0xb9f4a(%rip)        # 8554d <pf_target_9_0>

000000000013f497 <pf_jump_9>:
  13f497:	e9 44 cb f1 ff       	jmp    5bfe0 <pf_callee_9>
  13f49c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f4a0 <pf_call_10>:
  13f4a0:	41 53                	push   %r11
  13f4a2:	4c 8b 1d 1f e1 ff ff 	mov    -0x1ee1(%rip),%r11        # 13d5c8 <pf_got_10_0>

000000000013f4a9 <pf_got_hint_10_0>:
  13f4a9:	41 0f 18 93 50 79 00 	prefetcht1 0x7950(%r11)
  13f4b0:	00 
  13f4b1:	4c 8b 1d f8 e1 ff ff 	mov    -0x1e08(%rip),%r11        # 13d6b0 <pf_got_10_1>

000000000013f4b8 <pf_got_hint_10_1>:
  13f4b8:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  13f4bf:	00 

000000000013f4c0 <pf_got_hint_10_2>:
  13f4c0:	41 0f 18 93 22 00 00 	prefetcht1 0x22(%r11)
  13f4c7:	00 
  13f4c8:	41 5b                	pop    %r11

000000000013f4ca <pf_jump_10>:
  13f4ca:	e9 11 9d ee ff       	jmp    291e0 <pf_callee_10>
  13f4cf:	90                   	nop

000000000013f4d0 <pf_call_11>:
  13f4d0:	0f 18 15 79 73 f3 ff 	prefetcht1 -0xc8c87(%rip)        # 76850 <pf_target_11_0>

000000000013f4d7 <pf_jump_11>:
  13f4d7:	e9 64 9f ee ff       	jmp    29440 <pf_callee_11>
  13f4dc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f4e0 <pf_call_12>:
  13f4e0:	0f 18 15 a9 bd f1 ff 	prefetcht1 -0xe4257(%rip)        # 5b290 <pf_target_12_0>

000000000013f4e7 <pf_jump_12>:
  13f4e7:	e9 84 9d ee ff       	jmp    29270 <pf_callee_12>
  13f4ec:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f4f0 <pf_call_13>:
  13f4f0:	41 53                	push   %r11
  13f4f2:	4c 8b 1d 4f df ff ff 	mov    -0x20b1(%rip),%r11        # 13d448 <pf_got_13_0>

000000000013f4f9 <pf_got_hint_13_0>:
  13f4f9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  13f500:	00 
  13f501:	4c 8b 1d 38 e4 ff ff 	mov    -0x1bc8(%rip),%r11        # 13d940 <pf_got_13_1>

000000000013f508 <pf_got_hint_13_1>:
  13f508:	41 0f 18 93 31 26 ff 	prefetcht1 -0xd9cf(%r11)
  13f50f:	ff 

000000000013f510 <pf_got_hint_13_2>:
  13f510:	41 0f 18 93 10 29 ff 	prefetcht1 -0xd6f0(%r11)
  13f517:	ff 

000000000013f518 <pf_got_hint_13_3>:
  13f518:	41 0f 18 93 b0 f5 ff 	prefetcht1 -0xa50(%r11)
  13f51f:	ff 
  13f520:	41 5b                	pop    %r11

000000000013f522 <pf_jump_13>:
  13f522:	e9 79 88 f1 ff       	jmp    57da0 <pf_callee_13>
  13f527:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  13f52e:	00 00 

000000000013f530 <pf_call_14>:
  13f530:	0f 18 15 89 a2 ee ff 	prefetcht1 -0x115d77(%rip)        # 297c0 <pf_target_14_0>

000000000013f537 <pf_jump_14>:
  13f537:	e9 34 a7 ee ff       	jmp    29c70 <pf_callee_14>
  13f53c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f540 <pf_call_15>:
  13f540:	0f 18 15 99 6c f1 ff 	prefetcht1 -0xe9367(%rip)        # 561e0 <pf_target_15_0>
  13f547:	0f 18 15 b5 6c f1 ff 	prefetcht1 -0xe934b(%rip)        # 56203 <pf_target_15_1>

000000000013f54e <pf_jump_15>:
  13f54e:	e9 1d 9c ee ff       	jmp    29170 <pf_callee_15>
  13f553:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f55a:	00 00 00 
  13f55d:	0f 1f 00             	nopl   (%rax)

000000000013f560 <pf_call_16>:
  13f560:	0f 18 15 1c 6d f1 ff 	prefetcht1 -0xe92e4(%rip)        # 56283 <pf_target_16_0>

000000000013f567 <pf_jump_16>:
  13f567:	e9 34 71 f1 ff       	jmp    566a0 <pf_callee_16>
  13f56c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f570 <pf_call_17>:
  13f570:	0f 18 15 09 86 f1 ff 	prefetcht1 -0xe79f7(%rip)        # 57b80 <pf_target_17_0>

000000000013f577 <pf_jump_17>:
  13f577:	e9 64 9c ee ff       	jmp    291e0 <pf_callee_10>
  13f57c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f580 <pf_call_18>:
  13f580:	0f 18 15 69 ab ee ff 	prefetcht1 -0x115497(%rip)        # 2a0f0 <pf_target_18_0>
  13f587:	41 53                	push   %r11
  13f589:	4c 8b 1d e8 e2 ff ff 	mov    -0x1d18(%rip),%r11        # 13d878 <pf_got_18_0>

000000000013f590 <pf_got_hint_18_0>:
  13f590:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  13f597:	00 
  13f598:	41 5b                	pop    %r11

000000000013f59a <pf_jump_18>:
  13f59a:	e9 41 9c ee ff       	jmp    291e0 <pf_callee_10>
  13f59f:	90                   	nop

000000000013f5a0 <pf_call_19>:
  13f5a0:	41 53                	push   %r11
  13f5a2:	4c 8b 1d 1f e0 ff ff 	mov    -0x1fe1(%rip),%r11        # 13d5c8 <pf_got_10_0>

000000000013f5a9 <pf_got_hint_19_0>:
  13f5a9:	41 0f 18 93 30 56 fe 	prefetcht1 -0x1a9d0(%r11)
  13f5b0:	ff 
  13f5b1:	4c 8b 1d 88 e3 ff ff 	mov    -0x1c78(%rip),%r11        # 13d940 <pf_got_13_1>

000000000013f5b8 <pf_got_hint_19_1>:
  13f5b8:	41 0f 18 93 b0 3e fe 	prefetcht1 -0x1c150(%r11)
  13f5bf:	ff 
  13f5c0:	41 5b                	pop    %r11

000000000013f5c2 <pf_jump_19>:
  13f5c2:	e9 c9 a5 ee ff       	jmp    29b90 <pf_callee_19>
  13f5c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  13f5ce:	00 00 

000000000013f5d0 <pf_call_20>:
  13f5d0:	0f 18 15 19 7b f1 ff 	prefetcht1 -0xe84e7(%rip)        # 570f0 <pf_target_20_0>
  13f5d7:	0f 18 15 b2 a1 ee ff 	prefetcht1 -0x115e4e(%rip)        # 29790 <pf_target_20_1>
  13f5de:	0f 18 15 20 7b f1 ff 	prefetcht1 -0xe84e0(%rip)        # 57105 <pf_target_20_2>

000000000013f5e5 <pf_jump_20>:
  13f5e5:	e9 36 80 f1 ff       	jmp    57620 <pf_callee_20>
  13f5ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000013f5f0 <pf_call_21>:
  13f5f0:	0f 18 15 70 9f f4 ff 	prefetcht1 -0xb6090(%rip)        # 89567 <pf_target_21_0>
  13f5f7:	0f 18 15 87 37 f4 ff 	prefetcht1 -0xbc879(%rip)        # 82d85 <pf_target_21_1>

000000000013f5fe <pf_jump_21>:
  13f5fe:	e9 dd 9b ee ff       	jmp    291e0 <pf_callee_10>
  13f603:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f60a:	00 00 00 
  13f60d:	0f 1f 00             	nopl   (%rax)

000000000013f610 <pf_call_22>:
  13f610:	0f 18 15 69 42 f2 ff 	prefetcht1 -0xdbd97(%rip)        # 63880 <pf_target_22_0>
  13f617:	0f 18 15 d2 dd f8 ff 	prefetcht1 -0x7222e(%rip)        # cd3f0 <pf_target_22_1>
  13f61e:	0f 18 15 3b 42 f2 ff 	prefetcht1 -0xdbdc5(%rip)        # 63860 <pf_target_22_2>

000000000013f625 <pf_jump_22>:
  13f625:	e9 06 7d f2 ff       	jmp    67330 <pf_callee_22>
  13f62a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000013f630 <pf_call_23>:
  13f630:	0f 18 15 49 a2 ee ff 	prefetcht1 -0x115db7(%rip)        # 29880 <pf_callee_24>

000000000013f637 <pf_jump_23>:
  13f637:	e9 d4 84 f3 ff       	jmp    77b10 <pf_callee_23>
  13f63c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f640 <pf_call_24>:
  13f640:	0f 18 15 89 aa ee ff 	prefetcht1 -0x115577(%rip)        # 2a0d0 <pf_callee_29>
  13f647:	0f 18 15 e2 a6 f4 ff 	prefetcht1 -0xb591e(%rip)        # 89d30 <pf_callee_25>
  13f64e:	41 53                	push   %r11
  13f650:	4c 8b 1d 99 da ff ff 	mov    -0x2567(%rip),%r11        # 13d0f0 <pf_got_24_0>

000000000013f657 <pf_got_hint_24_0>:
  13f657:	41 0f 18 93 b0 53 ff 	prefetcht1 -0xac50(%r11)
  13f65e:	ff 
  13f65f:	41 5b                	pop    %r11

000000000013f661 <pf_jump_24>:
  13f661:	e9 1a a2 ee ff       	jmp    29880 <pf_callee_24>
  13f666:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f66d:	00 00 00 

000000000013f670 <pf_call_25>:
  13f670:	0f 18 15 69 ad ee ff 	prefetcht1 -0x115297(%rip)        # 2a3e0 <pf_target_25_0>
  13f677:	0f 18 15 62 c2 f1 ff 	prefetcht1 -0xe3d9e(%rip)        # 5b8e0 <pf_target_25_1>

000000000013f67e <pf_jump_25>:
  13f67e:	e9 ad a6 f4 ff       	jmp    89d30 <pf_callee_25>
  13f683:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f68a:	00 00 00 
  13f68d:	0f 1f 00             	nopl   (%rax)

000000000013f690 <pf_call_26>:
  13f690:	0f 18 15 29 fa f3 ff 	prefetcht1 -0xc05d7(%rip)        # 7f0c0 <pf_callee_27>
  13f697:	0f 18 15 52 79 f3 ff 	prefetcht1 -0xc86ae(%rip)        # 76ff0 <pf_target_26_1>
  13f69e:	0f 18 15 fb 5b f4 ff 	prefetcht1 -0xba405(%rip)        # 852a0 <pf_target_26_2>
  13f6a5:	0f 18 15 55 79 f3 ff 	prefetcht1 -0xc86ab(%rip)        # 77001 <pf_target_26_3>

000000000013f6ac <pf_jump_26>:
  13f6ac:	e9 9f ad ee ff       	jmp    2a450 <pf_callee_26>
  13f6b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f6b8:	00 00 00 
  13f6bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000013f6c0 <pf_call_27>:
  13f6c0:	0f 18 15 29 7d f3 ff 	prefetcht1 -0xc82d7(%rip)        # 773f0 <pf_target_27_0>

000000000013f6c7 <pf_jump_27>:
  13f6c7:	e9 f4 f9 f3 ff       	jmp    7f0c0 <pf_callee_27>
  13f6cc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f6d0 <pf_call_28>:
  13f6d0:	0f 18 15 19 9e f4 ff 	prefetcht1 -0xb61e7(%rip)        # 894f0 <pf_target_28_0>

000000000013f6d7 <pf_jump_28>:
  13f6d7:	e9 04 9b ee ff       	jmp    291e0 <pf_callee_10>
  13f6dc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f6e0 <pf_call_29>:
  13f6e0:	0f 18 15 1b f3 f4 ff 	prefetcht1 -0xb0ce5(%rip)        # 8ea02 <pf_target_29_0>
  13f6e7:	0f 18 15 c2 f2 f4 ff 	prefetcht1 -0xb0d3e(%rip)        # 8e9b0 <pf_target_29_1>
  13f6ee:	0f 18 15 0c 79 f3 ff 	prefetcht1 -0xc86f4(%rip)        # 77001 <pf_target_26_3>
  13f6f5:	41 53                	push   %r11
  13f6f7:	4c 8b 1d f2 d9 ff ff 	mov    -0x260e(%rip),%r11        # 13d0f0 <pf_got_24_0>

000000000013f6fe <pf_got_hint_29_0>:
  13f6fe:	41 0f 18 93 e0 48 ff 	prefetcht1 -0xb720(%r11)
  13f705:	ff 
  13f706:	41 5b                	pop    %r11

000000000013f708 <pf_jump_29>:
  13f708:	e9 c3 a9 ee ff       	jmp    2a0d0 <pf_callee_29>
  13f70d:	0f 1f 00             	nopl   (%rax)

000000000013f710 <pf_call_30>:
  13f710:	0f 18 15 c8 81 ef ff 	prefetcht1 -0x107e38(%rip)        # 378df <pf_target_30_0>
  13f717:	0f 18 15 22 9d ee ff 	prefetcht1 -0x1162de(%rip)        # 29440 <pf_callee_11>
  13f71e:	0f 18 15 0b 43 f0 ff 	prefetcht1 -0xfbcf5(%rip)        # 43a30 <pf_callee_8>
  13f725:	41 53                	push   %r11
  13f727:	4c 8b 1d 7a d9 ff ff 	mov    -0x2686(%rip),%r11        # 13d0a8 <pf_got_30_0>

000000000013f72e <pf_got_hint_30_0>:
  13f72e:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  13f735:	00 
  13f736:	41 5b                	pop    %r11

000000000013f738 <pf_jump_30>:
  13f738:	e9 33 f0 f5 ff       	jmp    9e770 <pf_callee_30>
  13f73d:	0f 1f 00             	nopl   (%rax)

000000000013f740 <pf_call_31>:
  13f740:	0f 18 15 69 7b f2 ff 	prefetcht1 -0xd8497(%rip)        # 672b0 <pf_target_31_0>

000000000013f747 <pf_jump_31>:
  13f747:	e9 74 a9 ee ff       	jmp    2a0c0 <pf_callee_31>
  13f74c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f750 <pf_call_32>:
  13f750:	41 53                	push   %r11
  13f752:	4c 8b 1d 8f e0 ff ff 	mov    -0x1f71(%rip),%r11        # 13d7e8 <pf_got_32_0>

000000000013f759 <pf_got_hint_32_0>:
  13f759:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  13f760:	00 

000000000013f761 <pf_got_hint_32_1>:
  13f761:	41 0f 18 93 31 00 00 	prefetcht1 0x31(%r11)
  13f768:	00 
  13f769:	41 5b                	pop    %r11

000000000013f76b <pf_jump_32>:
  13f76b:	e9 90 9b f6 ff       	jmp    a9300 <pf_callee_32>
