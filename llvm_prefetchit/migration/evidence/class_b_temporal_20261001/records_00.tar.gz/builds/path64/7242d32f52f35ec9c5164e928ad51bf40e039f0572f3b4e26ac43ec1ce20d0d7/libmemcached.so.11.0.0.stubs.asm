
/storage/prefetchit/class_b_temporal_20261001/builds/path64/7242d32f52f35ec9c5164e928ad51bf40e039f0572f3b4e26ac43ec1ce20d0d7/call-stub-x7i77euk/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000312c0 <pf_call_0>:
   312c0:	0f 18 15 a9 5c fd ff 	prefetcht1 -0x2a357(%rip)        # 6f70 <pf_callee_12>
   312c7:	0f 18 15 e2 44 fe ff 	prefetcht1 -0x1bb1e(%rip)        # 157b0 <pf_callee_22>
   312ce:	0f 18 15 db e8 fd ff 	prefetcht1 -0x21725(%rip)        # fbb0 <pf_callee_14>
   312d5:	0f 18 15 25 e9 fd ff 	prefetcht1 -0x216db(%rip)        # fc01 <pf_target_0_3>

00000000000312dc <pf_jump_0>:
   312dc:	e9 8f 41 fd ff       	jmp    5470 <pf_callee_0>
   312e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   312e8:	00 00 00 
   312eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000312f0 <pf_call_1>:
   312f0:	0f 18 15 ce a6 fd ff 	prefetcht1 -0x25932(%rip)        # b9c5 <pf_target_1_0>
   312f7:	0f 18 15 12 43 fd ff 	prefetcht1 -0x2bcee(%rip)        # 5610 <pf_target_1_1>

00000000000312fe <pf_jump_1>:
   312fe:	e9 5d d5 fe ff       	jmp    1e860 <pf_callee_1>
   31303:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3130a:	00 00 00 
   3130d:	0f 1f 00             	nopl   (%rax)

0000000000031310 <pf_call_2>:
   31310:	0f 18 15 6a 27 fe ff 	prefetcht1 -0x1d896(%rip)        # 13a81 <pf_target_2_0>

0000000000031317 <pf_jump_2>:
   31317:	e9 c4 41 fd ff       	jmp    54e0 <pf_callee_2>
   3131c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031320 <pf_call_3>:
   31320:	0f 18 15 39 d5 fe ff 	prefetcht1 -0x12ac7(%rip)        # 1e860 <pf_callee_1>

0000000000031327 <pf_jump_3>:
   31327:	e9 c4 3e fe ff       	jmp    151f0 <pf_callee_21>
   3132c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031330 <pf_call_4>:
   31330:	0f 18 15 4a d5 fe ff 	prefetcht1 -0x12ab6(%rip)        # 1e881 <pf_target_4_0>

0000000000031337 <pf_jump_4>:
   31337:	e9 b4 3e fe ff       	jmp    151f0 <pf_callee_21>
   3133c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031340 <pf_call_5>:
   31340:	0f 18 15 d8 e1 fd ff 	prefetcht1 -0x21e28(%rip)        # f51f <pf_target_5_0>
   31347:	0f 18 15 02 cb fd ff 	prefetcht1 -0x234fe(%rip)        # de50 <pf_callee_24>

000000000003134e <pf_jump_5>:
   3134e:	e9 fd d0 fd ff       	jmp    e450 <pf_callee_11>
   31353:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3135a:	00 00 00 
   3135d:	0f 1f 00             	nopl   (%rax)

0000000000031360 <pf_call_6>:
   31360:	0f 18 15 09 e1 fd ff 	prefetcht1 -0x21ef7(%rip)        # f470 <pf_target_6_0>
   31367:	0f 18 15 a2 42 fd ff 	prefetcht1 -0x2bd5e(%rip)        # 5610 <pf_target_1_1>
   3136e:	0f 18 15 62 e1 fd ff 	prefetcht1 -0x21e9e(%rip)        # f4d7 <pf_target_6_2>

0000000000031375 <pf_jump_6>:
   31375:	e9 e6 d4 fe ff       	jmp    1e860 <pf_callee_1>
   3137a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031380 <pf_call_7>:
   31380:	0f 18 15 b0 df fd ff 	prefetcht1 -0x22050(%rip)        # f337 <pf_target_7_0>
   31387:	0f 18 15 da df fd ff 	prefetcht1 -0x22026(%rip)        # f368 <pf_target_7_1>

000000000003138e <pf_jump_7>:
   3138e:	e9 cd a5 fd ff       	jmp    b960 <pf_callee_7>
   31393:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3139a:	00 00 00 
   3139d:	0f 1f 00             	nopl   (%rax)

00000000000313a0 <pf_call_8>:
   313a0:	0f 18 15 d9 e5 fd ff 	prefetcht1 -0x21a27(%rip)        # f980 <pf_target_14_1>
   313a7:	0f 18 15 12 e6 fd ff 	prefetcht1 -0x219ee(%rip)        # f9c0 <pf_target_14_2>
   313ae:	0f 18 15 fb e7 fd ff 	prefetcht1 -0x21805(%rip)        # fbb0 <pf_callee_14>
   313b5:	0f 18 15 45 e8 fd ff 	prefetcht1 -0x217bb(%rip)        # fc01 <pf_target_0_3>

00000000000313bc <pf_jump_8>:
   313bc:	e9 2f 3e fe ff       	jmp    151f0 <pf_callee_21>
   313c1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   313c8:	00 00 00 
   313cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000313d0 <pf_call_9>:
   313d0:	0f 18 15 39 3c fe ff 	prefetcht1 -0x1c3c7(%rip)        # 15010 <pf_target_19_1>

00000000000313d7 <pf_jump_9>:
   313d7:	e9 54 41 fd ff       	jmp    5530 <pf_callee_9>
   313dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000313e0 <pf_call_10>:
   313e0:	0f 18 15 69 d0 fd ff 	prefetcht1 -0x22f97(%rip)        # e450 <pf_callee_11>
   313e7:	0f 18 15 54 77 fe ff 	prefetcht1 -0x188ac(%rip)        # 18b42 <pf_target_10_1>
   313ee:	0f 18 15 4d 79 fe ff 	prefetcht1 -0x186b3(%rip)        # 18d42 <pf_target_10_2>
   313f5:	0f 18 15 74 83 fd ff 	prefetcht1 -0x27c8c(%rip)        # 9770 <pf_target_10_3>

00000000000313fc <pf_jump_10>:
   313fc:	e9 7f 1e fe ff       	jmp    13280 <pf_callee_10>
   31401:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31408:	00 00 00 
   3140b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031410 <pf_call_11>:
   31410:	0f 18 15 6a ab fd ff 	prefetcht1 -0x25496(%rip)        # bf81 <pf_target_11_0>
   31417:	0f 18 15 12 ab fd ff 	prefetcht1 -0x254ee(%rip)        # bf30 <pf_target_11_1>

000000000003141e <pf_jump_11>:
   3141e:	e9 2d d0 fd ff       	jmp    e450 <pf_callee_11>
   31423:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3142a:	00 00 00 
   3142d:	0f 1f 00             	nopl   (%rax)

0000000000031430 <pf_call_12>:
   31430:	0f 18 15 19 54 fe ff 	prefetcht1 -0x1abe7(%rip)        # 16850 <pf_target_12_0>
   31437:	0f 18 15 44 54 fe ff 	prefetcht1 -0x1abbc(%rip)        # 16882 <pf_target_12_1>

000000000003143e <pf_jump_12>:
   3143e:	e9 2d 5b fd ff       	jmp    6f70 <pf_callee_12>
   31443:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3144a:	00 00 00 
   3144d:	0f 1f 00             	nopl   (%rax)

0000000000031450 <pf_call_13>:
   31450:	0f 18 15 eb d2 fd ff 	prefetcht1 -0x22d15(%rip)        # e742 <pf_target_13_0>
   31457:	0f 18 15 92 d2 fd ff 	prefetcht1 -0x22d6e(%rip)        # e6f0 <pf_target_13_1>

000000000003145e <pf_jump_13>:
   3145e:	e9 2d f2 fd ff       	jmp    10690 <pf_callee_13>
   31463:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3146a:	00 00 00 
   3146d:	0f 1f 00             	nopl   (%rax)

0000000000031470 <pf_call_14>:
   31470:	0f 18 15 09 6e fe ff 	prefetcht1 -0x191f7(%rip)        # 18280 <pf_target_14_0>
   31477:	0f 18 15 02 e5 fd ff 	prefetcht1 -0x21afe(%rip)        # f980 <pf_target_14_1>
   3147e:	0f 18 15 3b e5 fd ff 	prefetcht1 -0x21ac5(%rip)        # f9c0 <pf_target_14_2>

0000000000031485 <pf_jump_14>:
   31485:	e9 26 e7 fd ff       	jmp    fbb0 <pf_callee_14>
   3148a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031490 <pf_call_15>:
   31490:	0f 18 15 f9 f1 fd ff 	prefetcht1 -0x20e07(%rip)        # 10690 <pf_callee_13>

0000000000031497 <pf_jump_15>:
   31497:	e9 94 05 fe ff       	jmp    11a30 <pf_callee_15>
   3149c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000314a0 <pf_call_16>:
   314a0:	41 53                	push   %r11
   314a2:	4c 8b 1d 7f ed ff ff 	mov    -0x1281(%rip),%r11        # 30228 <pf_got_16_0>

00000000000314a9 <pf_got_hint_16_0>:
   314a9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   314b0:	00 
   314b1:	41 5b                	pop    %r11

00000000000314b3 <pf_jump_16>:
   314b3:	e9 98 42 fd ff       	jmp    5750 <pf_callee_16>
   314b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   314bf:	00 

00000000000314c0 <pf_call_17>:
   314c0:	0f 18 15 39 96 fd ff 	prefetcht1 -0x269c7(%rip)        # ab00 <pf_target_17_0>
   314c7:	0f 18 15 76 96 fd ff 	prefetcht1 -0x2698a(%rip)        # ab44 <pf_target_17_1>

00000000000314ce <pf_jump_17>:
   314ce:	e9 ad b3 fd ff       	jmp    c880 <pf_callee_17>
   314d3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   314da:	00 00 00 
   314dd:	0f 1f 00             	nopl   (%rax)

00000000000314e0 <pf_call_18>:
   314e0:	0f 18 15 e9 55 fd ff 	prefetcht1 -0x2aa17(%rip)        # 6ad0 <pf_target_18_0>

00000000000314e7 <pf_jump_18>:
   314e7:	e9 94 b3 fd ff       	jmp    c880 <pf_callee_17>
   314ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000314f0 <pf_call_19>:
   314f0:	0f 18 15 39 1b fe ff 	prefetcht1 -0x1e4c7(%rip)        # 13030 <pf_target_19_0>
   314f7:	0f 18 15 12 3b fe ff 	prefetcht1 -0x1c4ee(%rip)        # 15010 <pf_target_19_1>
   314fe:	0f 18 15 7f 1b fe ff 	prefetcht1 -0x1e481(%rip)        # 13084 <pf_target_19_2>
   31505:	0f 18 15 3c 1b fe ff 	prefetcht1 -0x1e4c4(%rip)        # 13048 <pf_target_19_3>

000000000003150c <pf_jump_19>:
   3150c:	e9 6f b3 fd ff       	jmp    c880 <pf_callee_17>
   31511:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31518:	00 00 00 
   3151b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031520 <pf_call_20>:
   31520:	0f 18 15 31 5b fd ff 	prefetcht1 -0x2a4cf(%rip)        # 7058 <pf_target_20_0>

0000000000031527 <pf_jump_20>:
   31527:	e9 54 b3 fd ff       	jmp    c880 <pf_callee_17>
   3152c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031530 <pf_call_21>:
   31530:	0f 18 15 49 b3 fd ff 	prefetcht1 -0x24cb7(%rip)        # c880 <pf_callee_17>

0000000000031537 <pf_jump_21>:
   31537:	e9 b4 3c fe ff       	jmp    151f0 <pf_callee_21>
   3153c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031540 <pf_call_22>:
   31540:	0f 18 15 79 b0 fd ff 	prefetcht1 -0x24f87(%rip)        # c5c0 <pf_target_22_0>
   31547:	0f 18 15 32 b3 fd ff 	prefetcht1 -0x24cce(%rip)        # c880 <pf_callee_17>
   3154e:	0f 18 15 2b 29 fe ff 	prefetcht1 -0x1d6d5(%rip)        # 13e80 <pf_target_22_2>
   31555:	0f 18 15 64 b3 fd ff 	prefetcht1 -0x24c9c(%rip)        # c8c0 <pf_target_22_3>

000000000003155c <pf_jump_22>:
   3155c:	e9 4f 42 fe ff       	jmp    157b0 <pf_callee_22>
   31561:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31568:	00 00 00 
   3156b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031570 <pf_call_23>:
   31570:	0f 18 15 d9 c8 fd ff 	prefetcht1 -0x23727(%rip)        # de50 <pf_callee_24>
   31577:	0f 18 15 02 1d fe ff 	prefetcht1 -0x1e2fe(%rip)        # 13280 <pf_callee_10>
   3157e:	0f 18 15 e3 c9 fd ff 	prefetcht1 -0x2361d(%rip)        # df68 <pf_target_23_2>
   31585:	0f 18 15 f7 81 fd ff 	prefetcht1 -0x27e09(%rip)        # 9783 <pf_target_23_3>

000000000003158c <pf_jump_23>:
   3158c:	e9 ff f0 fd ff       	jmp    10690 <pf_callee_13>
   31591:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31598:	00 00 00 
   3159b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000315a0 <pf_call_24>:
   315a0:	0f 18 15 89 75 fe ff 	prefetcht1 -0x18a77(%rip)        # 18b30 <pf_target_24_0>
   315a7:	0f 18 15 d4 75 fe ff 	prefetcht1 -0x18a2c(%rip)        # 18b82 <pf_target_24_1>
   315ae:	0f 18 15 0b a5 fd ff 	prefetcht1 -0x25af5(%rip)        # bac0 <pf_target_24_2>
   315b5:	0f 18 15 64 77 fe ff 	prefetcht1 -0x1889c(%rip)        # 18d20 <pf_target_24_3>

00000000000315bc <pf_jump_24>:
   315bc:	e9 8f c8 fd ff       	jmp    de50 <pf_callee_24>
   315c1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   315c8:	00 00 00 
   315cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000315d0 <pf_call_25>:
   315d0:	0f 18 15 b9 f0 fd ff 	prefetcht1 -0x20f47(%rip)        # 10690 <pf_callee_13>
   315d7:	0f 18 15 12 3c fe ff 	prefetcht1 -0x1c3ee(%rip)        # 151f0 <pf_callee_21>

00000000000315de <pf_jump_25>:
   315de:	e9 0d 79 fe ff       	jmp    18ef0 <pf_callee_25>
   315e3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   315ea:	00 00 00 
   315ed:	0f 1f 00             	nopl   (%rax)

00000000000315f0 <pf_call_26>:
   315f0:	0f 18 15 b1 d9 fe ff 	prefetcht1 -0x1264f(%rip)        # 1efa8 <pf_target_26_0>

00000000000315f7 <pf_jump_26>:
   315f7:	e9 e4 41 fd ff       	jmp    57e0 <pf_callee_26>
   315fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031600 <pf_call_27>:
   31600:	41 53                	push   %r11
   31602:	4c 8b 1d e7 ea ff ff 	mov    -0x1519(%rip),%r11        # 300f0 <pf_got_27_0>

0000000000031609 <pf_got_hint_27_0>:
   31609:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   31610:	00 
   31611:	41 5b                	pop    %r11

0000000000031613 <pf_jump_27>:
   31613:	e9 28 42 fd ff       	jmp    5840 <pf_callee_27>
