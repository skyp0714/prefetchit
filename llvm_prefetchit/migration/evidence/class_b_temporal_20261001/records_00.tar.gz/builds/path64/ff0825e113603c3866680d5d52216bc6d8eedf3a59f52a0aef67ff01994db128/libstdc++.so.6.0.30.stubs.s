.text
.balign 16
.global pf_call_0
.type pf_call_0,@function
pf_call_0:
.cfi_startproc
prefetcht1 pf_target_0_0(%rip)
prefetcht1 pf_target_0_1(%rip)
prefetcht1 pf_target_0_2(%rip)
prefetcht1 pf_target_0_3(%rip)
.global pf_jump_0
pf_jump_0:
jmp pf_callee_0
.cfi_endproc
.size pf_call_0,.-pf_call_0
.balign 16
.global pf_call_1
.type pf_call_1,@function
pf_call_1:
.cfi_startproc
prefetcht1 pf_target_1_0(%rip)
prefetcht1 pf_target_1_1(%rip)
prefetcht1 pf_target_1_2(%rip)
.global pf_jump_1
pf_jump_1:
jmp pf_callee_1
.cfi_endproc
.size pf_call_1,.-pf_call_1
.balign 16
.global pf_call_2
.type pf_call_2,@function
pf_call_2:
.cfi_startproc
prefetcht1 pf_target_2_0(%rip)
prefetcht1 pf_target_2_1(%rip)
prefetcht1 pf_target_2_2(%rip)
prefetcht1 pf_target_2_3(%rip)
.global pf_jump_2
pf_jump_2:
jmp pf_callee_2
.cfi_endproc
.size pf_call_2,.-pf_call_2
.balign 16
.global pf_call_3
.type pf_call_3,@function
pf_call_3:
.cfi_startproc
prefetcht1 pf_target_3_0(%rip)
prefetcht1 pf_target_3_1(%rip)
.global pf_jump_3
pf_jump_3:
jmp pf_callee_3
.cfi_endproc
.size pf_call_3,.-pf_call_3
.balign 16
.global pf_call_4
.type pf_call_4,@function
pf_call_4:
.cfi_startproc
prefetcht1 pf_target_4_0(%rip)
.global pf_jump_4
pf_jump_4:
jmp pf_callee_4
.cfi_endproc
.size pf_call_4,.-pf_call_4
.balign 16
.global pf_call_5
.type pf_call_5,@function
pf_call_5:
.cfi_startproc
prefetcht1 pf_target_5_0(%rip)
.global pf_jump_5
pf_jump_5:
jmp pf_callee_5
.cfi_endproc
.size pf_call_5,.-pf_call_5
.balign 16
.global pf_call_6
.type pf_call_6,@function
pf_call_6:
.cfi_startproc
prefetcht1 pf_target_6_0(%rip)
prefetcht1 pf_target_6_1(%rip)
prefetcht1 pf_target_6_2(%rip)
prefetcht1 pf_target_6_3(%rip)
.global pf_jump_6
pf_jump_6:
jmp pf_callee_6
.cfi_endproc
.size pf_call_6,.-pf_call_6
.balign 16
.global pf_call_7
.type pf_call_7,@function
pf_call_7:
.cfi_startproc
prefetcht1 pf_target_7_0(%rip)
prefetcht1 pf_target_7_1(%rip)
.global pf_jump_7
pf_jump_7:
jmp pf_callee_7
.cfi_endproc
.size pf_call_7,.-pf_call_7
.balign 16
.global pf_call_8
.type pf_call_8,@function
pf_call_8:
.cfi_startproc
prefetcht1 pf_target_8_0(%rip)
prefetcht1 pf_target_8_1(%rip)
prefetcht1 pf_target_8_2(%rip)
.global pf_jump_8
pf_jump_8:
jmp pf_callee_8
.cfi_endproc
.size pf_call_8,.-pf_call_8
.balign 16
.global pf_call_9
.type pf_call_9,@function
pf_call_9:
.cfi_startproc
prefetcht1 pf_target_9_0(%rip)
prefetcht1 pf_target_9_1(%rip)
prefetcht1 pf_target_9_2(%rip)
prefetcht1 pf_target_9_3(%rip)
.global pf_jump_9
pf_jump_9:
jmp pf_callee_9
.cfi_endproc
.size pf_call_9,.-pf_call_9
.balign 16
.global pf_call_10
.type pf_call_10,@function
pf_call_10:
.cfi_startproc
prefetcht1 pf_target_10_0(%rip)
prefetcht1 pf_target_10_1(%rip)
prefetcht1 pf_target_10_2(%rip)
prefetcht1 pf_target_10_3(%rip)
.global pf_jump_10
pf_jump_10:
jmp pf_callee_10
.cfi_endproc
.size pf_call_10,.-pf_call_10
.balign 16
.global pf_call_11
.type pf_call_11,@function
pf_call_11:
.cfi_startproc
prefetcht1 pf_target_11_0(%rip)
prefetcht1 pf_target_11_1(%rip)
.global pf_jump_11
pf_jump_11:
jmp pf_callee_11
.cfi_endproc
.size pf_call_11,.-pf_call_11
.balign 16
.global pf_call_12
.type pf_call_12,@function
pf_call_12:
.cfi_startproc
prefetcht1 pf_target_12_0(%rip)
prefetcht1 pf_target_12_1(%rip)
prefetcht1 pf_target_12_2(%rip)
.global pf_jump_12
pf_jump_12:
jmp pf_callee_12
.cfi_endproc
.size pf_call_12,.-pf_call_12
.section .note.GNU-stack,"",@progbits
