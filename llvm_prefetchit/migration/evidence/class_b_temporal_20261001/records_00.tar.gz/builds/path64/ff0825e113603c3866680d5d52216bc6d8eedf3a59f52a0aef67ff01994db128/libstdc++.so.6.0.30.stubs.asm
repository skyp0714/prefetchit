
/storage/prefetchit/class_b_temporal_20261001/builds/path64/ff0825e113603c3866680d5d52216bc6d8eedf3a59f52a0aef67ff01994db128/call-stub-mkfx05bk/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000022c300 <pf_call_0>:
  22c300:	0f 18 15 19 e3 ef ff 	prefetcht1 -0x101ce7(%rip)        # 12a620 <pf_target_0_0>
  22c307:	0f 18 15 42 4a e7 ff 	prefetcht1 -0x18b5be(%rip)        # a0d50 <pf_target_0_1>
  22c30e:	0f 18 15 2b 1b ef ff 	prefetcht1 -0x10e4d5(%rip)        # 11de40 <pf_target_0_2>
  22c315:	0f 18 15 a4 ff ef ff 	prefetcht1 -0x10005c(%rip)        # 12c2c0 <pf_target_0_3>

000000000022c31c <pf_jump_0>:
  22c31c:	e9 5f 34 e7 ff       	jmp    9f780 <pf_callee_0>
  22c321:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c328:	00 00 00 
  22c32b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c330 <pf_call_1>:
  22c330:	0f 18 15 f9 e5 ea ff 	prefetcht1 -0x151a07(%rip)        # da930 <pf_target_1_0>
  22c337:	0f 18 15 03 e6 ea ff 	prefetcht1 -0x1519fd(%rip)        # da941 <pf_target_1_1>
  22c33e:	0f 18 15 2b 24 e7 ff 	prefetcht1 -0x18dbd5(%rip)        # 9e770 <pf_target_1_2>

000000000022c345 <pf_jump_1>:
  22c345:	e9 66 40 e7 ff       	jmp    a03b0 <pf_callee_1>
  22c34a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000022c350 <pf_call_2>:
  22c350:	0f 18 15 89 bf ef ff 	prefetcht1 -0x104077(%rip)        # 1282e0 <pf_target_2_0>
  22c357:	0f 18 15 52 26 e7 ff 	prefetcht1 -0x18d9ae(%rip)        # 9e9b0 <pf_target_2_1>
  22c35e:	0f 18 15 ab bf ef ff 	prefetcht1 -0x104055(%rip)        # 128310 <pf_target_2_2>
  22c365:	0f 18 15 e4 bf ef ff 	prefetcht1 -0x10401c(%rip)        # 128350 <pf_target_2_3>

000000000022c36c <pf_jump_2>:
  22c36c:	e9 8f 54 e7 ff       	jmp    a1800 <pf_callee_2>
  22c371:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c378:	00 00 00 
  22c37b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c380 <pf_call_3>:
  22c380:	0f 18 15 b9 ee ef ff 	prefetcht1 -0x101147(%rip)        # 12b240 <pf_callee_6>
  22c387:	0f 18 15 73 2c f0 ff 	prefetcht1 -0xfd38d(%rip)        # 12f001 <pf_target_3_1>

000000000022c38e <pf_jump_3>:
  22c38e:	e9 1d 33 e7 ff       	jmp    9f6b0 <pf_callee_3>
  22c393:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c39a:	00 00 00 
  22c39d:	0f 1f 00             	nopl   (%rax)

000000000022c3a0 <pf_call_4>:
  22c3a0:	0f 18 15 b9 20 e7 ff 	prefetcht1 -0x18df47(%rip)        # 9e460 <pf_target_4_0>

000000000022c3a7 <pf_jump_4>:
  22c3a7:	e9 04 33 e7 ff       	jmp    9f6b0 <pf_callee_3>
  22c3ac:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c3b0 <pf_call_5>:
  22c3b0:	0f 18 15 b9 66 f1 ff 	prefetcht1 -0xe9947(%rip)        # 142a70 <pf_target_5_0>

000000000022c3b7 <pf_jump_5>:
  22c3b7:	e9 f4 32 e7 ff       	jmp    9f6b0 <pf_callee_3>
  22c3bc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c3c0 <pf_call_6>:
  22c3c0:	0f 18 15 3b e4 f1 ff 	prefetcht1 -0xe1bc5(%rip)        # 14a802 <pf_target_6_0>
  22c3c7:	0f 18 15 22 e4 f1 ff 	prefetcht1 -0xe1bde(%rip)        # 14a7f0 <pf_target_6_1>
  22c3ce:	0f 18 15 03 67 f1 ff 	prefetcht1 -0xe98fd(%rip)        # 142ad8 <pf_target_6_2>
  22c3d5:	0f 18 15 a4 64 f1 ff 	prefetcht1 -0xe9b5c(%rip)        # 142880 <pf_target_6_3>

000000000022c3dc <pf_jump_6>:
  22c3dc:	e9 5f ee ef ff       	jmp    12b240 <pf_callee_6>
  22c3e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c3e8:	00 00 00 
  22c3eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c3f0 <pf_call_7>:
  22c3f0:	0f 18 15 09 06 f1 ff 	prefetcht1 -0xef9f7(%rip)        # 13ca00 <pf_target_7_0>
  22c3f7:	0f 18 15 d2 05 f1 ff 	prefetcht1 -0xefa2e(%rip)        # 13c9d0 <pf_target_7_1>

000000000022c3fe <pf_jump_7>:
  22c3fe:	e9 8d 3a e7 ff       	jmp    9fe90 <pf_callee_7>
  22c403:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c40a:	00 00 00 
  22c40d:	0f 1f 00             	nopl   (%rax)

000000000022c410 <pf_call_8>:
  22c410:	0f 18 15 69 5e f1 ff 	prefetcht1 -0xea197(%rip)        # 142280 <pf_target_8_0>
  22c417:	0f 18 15 c2 02 f2 ff 	prefetcht1 -0xdfd3e(%rip)        # 14c6e0 <pf_target_8_1>
  22c41e:	0f 18 15 eb 56 e7 ff 	prefetcht1 -0x18a915(%rip)        # a1b10 <pf_target_8_2>

000000000022c425 <pf_jump_8>:
  22c425:	e9 66 3a e7 ff       	jmp    9fe90 <pf_callee_7>
  22c42a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000022c430 <pf_call_9>:
  22c430:	0f 18 15 89 1b ef ff 	prefetcht1 -0x10e477(%rip)        # 11dfc0 <pf_target_9_0>
  22c437:	0f 18 15 62 51 e7 ff 	prefetcht1 -0x18ae9e(%rip)        # a15a0 <pf_callee_10>
  22c43e:	0f 18 15 db 5e e9 ff 	prefetcht1 -0x16a125(%rip)        # c2320 <pf_target_9_2>
  22c445:	0f 18 15 44 5f e9 ff 	prefetcht1 -0x16a0bc(%rip)        # c2390 <pf_target_9_3>

000000000022c44c <pf_jump_9>:
  22c44c:	e9 5f 2d e7 ff       	jmp    9f1b0 <pf_callee_9>
  22c451:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c458:	00 00 00 
  22c45b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c460 <pf_call_10>:
  22c460:	0f 18 15 79 45 e9 ff 	prefetcht1 -0x16ba87(%rip)        # c09e0 <pf_target_10_0>
  22c467:	0f 18 15 e2 20 e7 ff 	prefetcht1 -0x18df1e(%rip)        # 9e550 <pf_target_10_1>
  22c46e:	0f 18 15 8b 45 e9 ff 	prefetcht1 -0x16ba75(%rip)        # c0a00 <pf_target_10_2>
  22c475:	0f 18 15 04 44 e7 ff 	prefetcht1 -0x18bbfc(%rip)        # a0880 <pf_target_10_3>

000000000022c47c <pf_jump_10>:
  22c47c:	e9 1f 51 e7 ff       	jmp    a15a0 <pf_callee_10>
  22c481:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c488:	00 00 00 
  22c48b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c490 <pf_call_11>:
  22c490:	0f 18 15 f9 60 f1 ff 	prefetcht1 -0xe9f07(%rip)        # 142590 <pf_target_11_0>
  22c497:	0f 18 15 24 61 f1 ff 	prefetcht1 -0xe9edc(%rip)        # 1425c2 <pf_target_11_1>

000000000022c49e <pf_jump_11>:
  22c49e:	e9 3d 42 e7 ff       	jmp    a06e0 <pf_callee_11>
  22c4a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c4aa:	00 00 00 
  22c4ad:	0f 1f 00             	nopl   (%rax)

000000000022c4b0 <pf_call_12>:
  22c4b0:	0f 18 15 49 50 e7 ff 	prefetcht1 -0x18afb7(%rip)        # a1500 <pf_target_12_0>
  22c4b7:	0f 18 15 22 1f f2 ff 	prefetcht1 -0xde0de(%rip)        # 14e3e0 <pf_target_12_1>
  22c4be:	0f 18 15 40 1f f2 ff 	prefetcht1 -0xde0c0(%rip)        # 14e405 <pf_target_12_2>

000000000022c4c5 <pf_jump_12>:
  22c4c5:	e9 06 46 e7 ff       	jmp    a0ad0 <pf_callee_12>
