
/storage/prefetchit/class_b_temporal_20261001/builds/path64/74758375d70ece71e60caec108eeeae79d9abef7dce5ef79835d4c0c4edfca8e/call-stub-i1mz4yta/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000c22c0 <pf_call_0>:
   c22c0:	0f 18 15 b9 00 fa ff 	prefetcht1 -0x5ff47(%rip)        # 62380 <pf_target_0_0>

00000000000c22c7 <pf_jump_0>:
   c22c7:	e9 d4 67 f8 ff       	jmp    48aa0 <pf_callee_0>
   c22cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000c22d0 <pf_call_1>:
   c22d0:	0f 18 15 49 6d f8 ff 	prefetcht1 -0x792b7(%rip)        # 49020 <pf_callee_2>

00000000000c22d7 <pf_jump_1>:
   c22d7:	e9 84 52 f8 ff       	jmp    47560 <pf_callee_1>
   c22dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000c22e0 <pf_call_2>:
   c22e0:	0f 18 15 19 60 f8 ff 	prefetcht1 -0x79fe7(%rip)        # 48300 <pf_callee_5>
   c22e7:	0f 18 15 03 e2 fb ff 	prefetcht1 -0x41dfd(%rip)        # 804f1 <pf_target_2_1>

00000000000c22ee <pf_jump_2>:
   c22ee:	e9 2d 6d f8 ff       	jmp    49020 <pf_callee_2>
   c22f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c22fa:	00 00 00 
   c22fd:	0f 1f 00             	nopl   (%rax)

00000000000c2300 <pf_call_3>:
   c2300:	0f 18 15 be 6c fb ff 	prefetcht1 -0x49342(%rip)        # 78fc5 <pf_target_3_0>
   c2307:	0f 18 15 92 86 fb ff 	prefetcht1 -0x4796e(%rip)        # 7a9a0 <pf_target_3_1>
   c230e:	0f 18 15 5b 85 fb ff 	prefetcht1 -0x47aa5(%rip)        # 7a870 <pf_target_3_2>
   c2315:	0f 18 15 54 68 fb ff 	prefetcht1 -0x497ac(%rip)        # 78b70 <pf_target_3_3>

00000000000c231c <pf_jump_3>:
   c231c:	e9 df 56 f8 ff       	jmp    47a00 <pf_callee_3>
   c2321:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c2328:	00 00 00 
   c232b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000c2330 <pf_call_4>:
   c2330:	0f 18 15 89 12 fb ff 	prefetcht1 -0x4ed77(%rip)        # 735c0 <pf_target_4_0>
   c2337:	0f 18 15 02 55 f8 ff 	prefetcht1 -0x7aafe(%rip)        # 47840 <pf_target_4_1>
   c233e:	0f 18 15 7b f5 fb ff 	prefetcht1 -0x40a85(%rip)        # 818c0 <pf_target_4_2>

00000000000c2345 <pf_jump_4>:
   c2345:	e9 d6 59 f8 ff       	jmp    47d20 <pf_callee_4>
   c234a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000c2350 <pf_call_5>:
   c2350:	0f 18 15 aa ec fb ff 	prefetcht1 -0x41356(%rip)        # 81001 <pf_target_5_0>
   c2357:	0f 18 15 62 f3 fb ff 	prefetcht1 -0x40c9e(%rip)        # 816c0 <pf_target_5_1>
   c235e:	0f 18 15 b0 f5 fb ff 	prefetcht1 -0x40a50(%rip)        # 81915 <pf_target_5_2>
   c2365:	0f 18 15 dc f5 fb ff 	prefetcht1 -0x40a24(%rip)        # 81948 <pf_target_5_3>

00000000000c236c <pf_jump_5>:
   c236c:	e9 8f 5f f8 ff       	jmp    48300 <pf_callee_5>
