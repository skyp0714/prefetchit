
/storage/prefetchit/class_b_temporal_20261001/builds/path64/d2a2d732143c46b04f5ca16733387a5f5713ad8dc218c423def02e91e4025de9/call-stub-kghjlrq7/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000010b340 <pf_call_0>:
  10b340:	0f 18 15 bc 06 f4 ff 	prefetcht1 -0xbf944(%rip)        # 4ba03 <pf_target_0_0>
  10b347:	0f 18 15 f5 06 f4 ff 	prefetcht1 -0xbf90b(%rip)        # 4ba43 <pf_target_0_1>
  10b34e:	0f 18 15 5b 10 f4 ff 	prefetcht1 -0xbefa5(%rip)        # 4c3b0 <pf_target_0_2>
  10b355:	0f 18 15 c4 5c f4 ff 	prefetcht1 -0xba33c(%rip)        # 51020 <pf_target_0_3>

000000000010b35c <pf_jump_0>:
  10b35c:	e9 df c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b361:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b368:	00 00 00 
  10b36b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000010b370 <pf_call_1>:
  10b370:	0f 18 15 99 e2 f2 ff 	prefetcht1 -0xd1d67(%rip)        # 39610 <pf_callee_2>

000000000010b377 <pf_jump_1>:
  10b377:	e9 c4 c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b37c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b380 <pf_call_2>:
  10b380:	41 53                	push   %r11
  10b382:	4c 8b 1d a7 dd ff ff 	mov    -0x2259(%rip),%r11        # 109130 <pf_got_2_0>

000000000010b389 <pf_got_hint_2_0>:
  10b389:	41 0f 18 93 b0 06 00 	prefetcht1 0x6b0(%r11)
  10b390:	00 
  10b391:	4c 8b 1d 18 e2 ff ff 	mov    -0x1de8(%rip),%r11        # 1095b0 <pf_got_2_1>

000000000010b398 <pf_got_hint_2_1>:
  10b398:	41 0f 18 93 c5 1f 00 	prefetcht1 0x1fc5(%r11)
  10b39f:	00 
  10b3a0:	41 5b                	pop    %r11

000000000010b3a2 <pf_jump_2>:
  10b3a2:	e9 69 e2 f2 ff       	jmp    39610 <pf_callee_2>
  10b3a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  10b3ae:	00 00 

000000000010b3b0 <pf_call_3>:
  10b3b0:	41 53                	push   %r11
  10b3b2:	4c 8b 1d f7 e1 ff ff 	mov    -0x1e09(%rip),%r11        # 1095b0 <pf_got_2_1>

000000000010b3b9 <pf_got_hint_3_0>:
  10b3b9:	41 0f 18 93 50 79 00 	prefetcht1 0x7950(%r11)
  10b3c0:	00 
  10b3c1:	41 5b                	pop    %r11

000000000010b3c3 <pf_jump_3>:
  10b3c3:	e9 78 c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b3c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b3cf:	00 

000000000010b3d0 <pf_call_4>:
  10b3d0:	41 53                	push   %r11
  10b3d2:	4c 8b 1d 9f e2 ff ff 	mov    -0x1d61(%rip),%r11        # 109678 <pf_got_4_0>

000000000010b3d9 <pf_got_hint_4_0>:
  10b3d9:	41 0f 18 93 10 61 ff 	prefetcht1 -0x9ef0(%r11)
  10b3e0:	ff 
  10b3e1:	41 5b                	pop    %r11

000000000010b3e3 <pf_jump_4>:
  10b3e3:	e9 08 c8 f1 ff       	jmp    27bf0 <pf_callee_4>
  10b3e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b3ef:	00 

000000000010b3f0 <pf_call_5>:
  10b3f0:	41 53                	push   %r11
  10b3f2:	4c 8b 1d d7 dd ff ff 	mov    -0x2229(%rip),%r11        # 1091d0 <pf_got_5_0>

000000000010b3f9 <pf_got_hint_5_0>:
  10b3f9:	41 0f 18 93 3a 00 00 	prefetcht1 0x3a(%r11)
  10b400:	00 

000000000010b401 <pf_got_hint_5_1>:
  10b401:	41 0f 18 93 80 00 00 	prefetcht1 0x80(%r11)
  10b408:	00 
  10b409:	4c 8b 1d d8 e3 ff ff 	mov    -0x1c28(%rip),%r11        # 1097e8 <pf_got_5_2>

000000000010b410 <pf_got_hint_5_2>:
  10b410:	41 0f 18 93 70 e9 ff 	prefetcht1 -0x1690(%r11)
  10b417:	ff 
  10b418:	41 5b                	pop    %r11

000000000010b41a <pf_jump_5>:
  10b41a:	e9 61 c2 f1 ff       	jmp    27680 <pf_callee_5>
  10b41f:	90                   	nop

000000000010b420 <pf_call_6>:
  10b420:	41 53                	push   %r11
  10b422:	4c 8b 1d bf e3 ff ff 	mov    -0x1c41(%rip),%r11        # 1097e8 <pf_got_5_2>

000000000010b429 <pf_got_hint_6_0>:
  10b429:	41 0f 18 93 15 00 00 	prefetcht1 0x15(%r11)
  10b430:	00 
  10b431:	41 5b                	pop    %r11

000000000010b433 <pf_jump_6>:
  10b433:	e9 98 cb f1 ff       	jmp    27fd0 <pf_callee_6>
  10b438:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b43f:	00 

000000000010b440 <pf_call_7>:
  10b440:	41 53                	push   %r11
  10b442:	4c 8b 1d af de ff ff 	mov    -0x2151(%rip),%r11        # 1092f8 <pf_got_7_0>

000000000010b449 <pf_got_hint_7_0>:
  10b449:	41 0f 18 93 b0 04 00 	prefetcht1 0x4b0(%r11)
  10b450:	00 

000000000010b451 <pf_got_hint_7_1>:
  10b451:	41 0f 18 93 80 53 00 	prefetcht1 0x5380(%r11)
  10b458:	00 
  10b459:	4c 8b 1d e8 e0 ff ff 	mov    -0x1f18(%rip),%r11        # 109548 <pf_got_7_2>

000000000010b460 <pf_got_hint_7_2>:
  10b460:	41 0f 18 93 30 5a 03 	prefetcht1 0x35a30(%r11)
  10b467:	00 
  10b468:	4c 8b 1d 09 e2 ff ff 	mov    -0x1df7(%rip),%r11        # 109678 <pf_got_4_0>

000000000010b46f <pf_got_hint_7_3>:
  10b46f:	41 0f 18 93 60 76 ff 	prefetcht1 -0x89a0(%r11)
  10b476:	ff 
  10b477:	41 5b                	pop    %r11

000000000010b479 <pf_jump_7>:
  10b479:	e9 12 c6 f1 ff       	jmp    27a90 <pf_callee_7>
  10b47e:	66 90                	xchg   %ax,%ax

000000000010b480 <pf_call_8>:
  10b480:	41 53                	push   %r11
  10b482:	4c 8b 1d bf e0 ff ff 	mov    -0x1f41(%rip),%r11        # 109548 <pf_got_7_2>

000000000010b489 <pf_got_hint_8_0>:
  10b489:	41 0f 18 93 b0 89 01 	prefetcht1 0x189b0(%r11)
  10b490:	00 

000000000010b491 <pf_got_hint_8_1>:
  10b491:	41 0f 18 93 b0 57 03 	prefetcht1 0x357b0(%r11)
  10b498:	00 
  10b499:	4c 8b 1d d8 e1 ff ff 	mov    -0x1e28(%rip),%r11        # 109678 <pf_got_4_0>

000000000010b4a0 <pf_got_hint_8_2>:
  10b4a0:	41 0f 18 93 60 50 ff 	prefetcht1 -0xafa0(%r11)
  10b4a7:	ff 
  10b4a8:	41 5b                	pop    %r11

000000000010b4aa <pf_jump_8>:
  10b4aa:	e9 01 bd f1 ff       	jmp    271b0 <pf_callee_16>
  10b4af:	90                   	nop

000000000010b4b0 <pf_call_9>:
  10b4b0:	0f 18 15 c9 5b f4 ff 	prefetcht1 -0xba437(%rip)        # 51080 <pf_target_9_0>

000000000010b4b7 <pf_jump_9>:
  10b4b7:	e9 a4 bd f1 ff       	jmp    27260 <pf_callee_9>
  10b4bc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b4c0 <pf_call_10>:
  10b4c0:	41 53                	push   %r11
  10b4c2:	4c 8b 1d 37 e4 ff ff 	mov    -0x1bc9(%rip),%r11        # 109900 <pf_got_10_0>

000000000010b4c9 <pf_got_hint_10_0>:
  10b4c9:	41 0f 18 93 70 e8 fe 	prefetcht1 -0x11790(%r11)
  10b4d0:	ff 

000000000010b4d1 <pf_got_hint_10_1>:
  10b4d1:	41 0f 18 93 20 26 ff 	prefetcht1 -0xd9e0(%r11)
  10b4d8:	ff 

000000000010b4d9 <pf_got_hint_10_2>:
  10b4d9:	41 0f 18 93 10 29 ff 	prefetcht1 -0xd6f0(%r11)
  10b4e0:	ff 

000000000010b4e1 <pf_got_hint_10_3>:
  10b4e1:	41 0f 18 93 b0 f5 ff 	prefetcht1 -0xa50(%r11)
  10b4e8:	ff 
  10b4e9:	41 5b                	pop    %r11

000000000010b4eb <pf_jump_10>:
  10b4eb:	e9 40 26 f4 ff       	jmp    4db30 <pf_callee_10>

000000000010b4f0 <pf_call_11>:
  10b4f0:	41 53                	push   %r11
  10b4f2:	4c 8b 1d ff e0 ff ff 	mov    -0x1f01(%rip),%r11        # 1095f8 <pf_got_11_0>

000000000010b4f9 <pf_got_hint_11_0>:
  10b4f9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b500:	00 
  10b501:	41 5b                	pop    %r11

000000000010b503 <pf_jump_11>:
  10b503:	e9 28 cd f1 ff       	jmp    28230 <pf_callee_11>
  10b508:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b50f:	00 

000000000010b510 <pf_call_12>:
  10b510:	41 53                	push   %r11
  10b512:	4c 8b 1d d7 de ff ff 	mov    -0x2129(%rip),%r11        # 1093f0 <pf_got_12_0>

000000000010b519 <pf_got_hint_12_0>:
  10b519:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b520:	00 
  10b521:	4c 8b 1d 30 e1 ff ff 	mov    -0x1ed0(%rip),%r11        # 109658 <pf_got_12_1>

000000000010b528 <pf_got_hint_12_1>:
  10b528:	41 0f 18 93 00 fd ff 	prefetcht1 -0x300(%r11)
  10b52f:	ff 
  10b530:	4c 8b 1d e1 e3 ff ff 	mov    -0x1c1f(%rip),%r11        # 109918 <pf_got_12_2>

000000000010b537 <pf_got_hint_12_2>:
  10b537:	41 0f 18 93 d0 f0 ff 	prefetcht1 -0xf30(%r11)
  10b53e:	ff 
  10b53f:	41 5b                	pop    %r11

000000000010b541 <pf_jump_12>:
  10b541:	e9 fa bb f1 ff       	jmp    27140 <pf_callee_12>
  10b546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b54d:	00 00 00 

000000000010b550 <pf_call_13>:
  10b550:	0f 18 15 89 c2 f1 ff 	prefetcht1 -0xe3d77(%rip)        # 277e0 <pf_target_13_0>
  10b557:	41 53                	push   %r11
  10b559:	4c 8b 1d 90 de ff ff 	mov    -0x2170(%rip),%r11        # 1093f0 <pf_got_12_0>

000000000010b560 <pf_got_hint_13_0>:
  10b560:	41 0f 18 93 11 00 00 	prefetcht1 0x11(%r11)
  10b567:	00 
  10b568:	41 5b                	pop    %r11

000000000010b56a <pf_jump_13>:
  10b56a:	e9 d1 bb f1 ff       	jmp    27140 <pf_callee_12>
  10b56f:	90                   	nop

000000000010b570 <pf_call_14>:
  10b570:	0f 18 15 79 bf f1 ff 	prefetcht1 -0xe4087(%rip)        # 274f0 <pf_target_14_0>

000000000010b577 <pf_jump_14>:
  10b577:	e9 64 d2 f3 ff       	jmp    487e0 <pf_callee_14>
  10b57c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b580 <pf_call_15>:
  10b580:	0f 18 15 99 0a f4 ff 	prefetcht1 -0xbf567(%rip)        # 4c020 <pf_target_15_0>
  10b587:	0f 18 15 b5 0a f4 ff 	prefetcht1 -0xbf54b(%rip)        # 4c043 <pf_target_15_1>

000000000010b58e <pf_jump_15>:
  10b58e:	e9 cd 0e f4 ff       	jmp    4c460 <pf_callee_15>
  10b593:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b59a:	00 00 00 
  10b59d:	0f 1f 00             	nopl   (%rax)

000000000010b5a0 <pf_call_16>:
  10b5a0:	0f 18 15 69 23 f4 ff 	prefetcht1 -0xbdc97(%rip)        # 4d910 <pf_target_16_0>

000000000010b5a7 <pf_jump_16>:
  10b5a7:	e9 04 bc f1 ff       	jmp    271b0 <pf_callee_16>
  10b5ac:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b5b0 <pf_call_17>:
  10b5b0:	41 53                	push   %r11
  10b5b2:	4c 8b 1d 47 e3 ff ff 	mov    -0x1cb9(%rip),%r11        # 109900 <pf_got_10_0>

000000000010b5b9 <pf_got_hint_17_0>:
  10b5b9:	41 0f 18 93 b0 3e fe 	prefetcht1 -0x1c150(%r11)
  10b5c0:	ff 

000000000010b5c1 <pf_got_hint_17_1>:
  10b5c1:	41 0f 18 93 40 46 fe 	prefetcht1 -0x1b9c0(%r11)
  10b5c8:	ff 

000000000010b5c9 <pf_got_hint_17_2>:
  10b5c9:	41 0f 18 93 70 46 fe 	prefetcht1 -0x1b990(%r11)
  10b5d0:	ff 
  10b5d1:	41 5b                	pop    %r11

000000000010b5d3 <pf_jump_17>:
  10b5d3:	e9 88 c5 f1 ff       	jmp    27b60 <pf_callee_17>
  10b5d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b5df:	00 

000000000010b5e0 <pf_call_18>:
  10b5e0:	0f 18 15 c9 18 f4 ff 	prefetcht1 -0xbe737(%rip)        # 4ceb0 <pf_target_18_0>
  10b5e7:	0f 18 15 f2 d1 f3 ff 	prefetcht1 -0xc2e0e(%rip)        # 487e0 <pf_callee_14>

000000000010b5ee <pf_jump_18>:
  10b5ee:	e9 ed 1d f4 ff       	jmp    4d3e0 <pf_callee_18>
  10b5f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b5fa:	00 00 00 
  10b5fd:	0f 1f 00             	nopl   (%rax)

000000000010b600 <pf_call_19>:
  10b600:	0f 18 15 29 cc f1 ff 	prefetcht1 -0xe33d7(%rip)        # 28230 <pf_callee_11>
  10b607:	41 53                	push   %r11
  10b609:	4c 8b 1d c8 da ff ff 	mov    -0x2538(%rip),%r11        # 1090d8 <pf_got_19_0>

000000000010b610 <pf_got_hint_19_0>:
  10b610:	41 0f 18 93 90 37 ff 	prefetcht1 -0xc870(%r11)
  10b617:	ff 
  10b618:	41 5b                	pop    %r11

000000000010b61a <pf_jump_19>:
  10b61a:	e9 c1 d1 f3 ff       	jmp    487e0 <pf_callee_14>
  10b61f:	90                   	nop

000000000010b620 <pf_call_20>:
  10b620:	41 53                	push   %r11
  10b622:	4c 8b 1d 2f de ff ff 	mov    -0x21d1(%rip),%r11        # 109458 <pf_got_20_0>

000000000010b629 <pf_got_hint_20_0>:
  10b629:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b630:	00 
  10b631:	41 5b                	pop    %r11

000000000010b633 <pf_jump_20>:
  10b633:	e9 c8 25 f4 ff       	jmp    4dc00 <pf_callee_20>
  10b638:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b63f:	00 

000000000010b640 <pf_call_21>:
  10b640:	0f 18 15 09 cd f1 ff 	prefetcht1 -0xe32f7(%rip)        # 28350 <pf_target_21_0>
  10b647:	41 53                	push   %r11
  10b649:	4c 8b 1d 58 e3 ff ff 	mov    -0x1ca8(%rip),%r11        # 1099a8 <pf_got_21_0>

000000000010b650 <pf_got_hint_21_0>:
  10b650:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b657:	00 
  10b658:	41 5b                	pop    %r11

000000000010b65a <pf_jump_21>:
  10b65a:	e9 f1 62 f4 ff       	jmp    51950 <pf_callee_21>
  10b65f:	90                   	nop

000000000010b660 <pf_call_22>:
  10b660:	0f 18 15 d9 c2 f5 ff 	prefetcht1 -0xa3d27(%rip)        # 67940 <pf_target_22_0>
  10b667:	0f 18 15 b2 c2 f5 ff 	prefetcht1 -0xa3d4e(%rip)        # 67920 <pf_target_22_1>
  10b66e:	0f 18 15 cb b7 f5 ff 	prefetcht1 -0xa4835(%rip)        # 66e40 <pf_target_22_2>

000000000010b675 <pf_jump_22>:
  10b675:	e9 36 bb f1 ff       	jmp    271b0 <pf_callee_16>
  10b67a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000010b680 <pf_call_23>:
  10b680:	0f 18 15 49 c0 f5 ff 	prefetcht1 -0xa3fb7(%rip)        # 676d0 <pf_target_23_0>

000000000010b687 <pf_jump_23>:
  10b687:	e9 14 c2 f1 ff       	jmp    278a0 <pf_callee_23>
  10b68c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b690 <pf_call_24>:
  10b690:	0f 18 15 09 c2 f1 ff 	prefetcht1 -0xe3df7(%rip)        # 278a0 <pf_callee_23>
  10b697:	0f 18 15 0e 39 f6 ff 	prefetcht1 -0x9c6f2(%rip)        # 6efac <pf_target_24_1>
  10b69e:	0f 18 15 2b 03 f6 ff 	prefetcht1 -0x9fcd5(%rip)        # 6b9d0 <pf_target_24_2>
  10b6a5:	0f 18 15 14 cd f1 ff 	prefetcht1 -0xe32ec(%rip)        # 283c0 <pf_callee_27>

000000000010b6ac <pf_jump_24>:
  10b6ac:	e9 3f c7 f5 ff       	jmp    67df0 <pf_callee_24>
  10b6b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b6b8:	00 00 00 
  10b6bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000010b6c0 <pf_call_25>:
  10b6c0:	0f 18 15 d9 40 f6 ff 	prefetcht1 -0x9bf27(%rip)        # 6f7a0 <pf_callee_26>
  10b6c7:	41 53                	push   %r11
  10b6c9:	4c 8b 1d 08 da ff ff 	mov    -0x25f8(%rip),%r11        # 1090d8 <pf_got_19_0>

000000000010b6d0 <pf_got_hint_25_0>:
  10b6d0:	41 0f 18 93 b0 53 ff 	prefetcht1 -0xac50(%r11)
  10b6d7:	ff 
  10b6d8:	41 5b                	pop    %r11

000000000010b6da <pf_jump_25>:
  10b6da:	e9 c1 c1 f1 ff       	jmp    278a0 <pf_callee_23>
  10b6df:	90                   	nop

000000000010b6e0 <pf_call_26>:
  10b6e0:	0f 18 15 89 5f f4 ff 	prefetcht1 -0xba077(%rip)        # 51670 <pf_target_26_0>

000000000010b6e7 <pf_jump_26>:
  10b6e7:	e9 b4 40 f6 ff       	jmp    6f7a0 <pf_callee_26>
  10b6ec:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b6f0 <pf_call_27>:
  10b6f0:	0f 18 15 d9 bb f5 ff 	prefetcht1 -0xa4427(%rip)        # 672d0 <pf_target_27_0>
  10b6f7:	0f 18 15 02 09 f6 ff 	prefetcht1 -0x9f6fe(%rip)        # 6c000 <pf_target_27_1>

000000000010b6fe <pf_jump_27>:
  10b6fe:	e9 bd cc f1 ff       	jmp    283c0 <pf_callee_27>
  10b703:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b70a:	00 00 00 
  10b70d:	0f 1f 00             	nopl   (%rax)

000000000010b710 <pf_call_28>:
  10b710:	0f 18 15 c0 38 f6 ff 	prefetcht1 -0x9c740(%rip)        # 6efd7 <pf_target_28_0>
  10b717:	0f 18 15 c7 07 f6 ff 	prefetcht1 -0x9f839(%rip)        # 6bee5 <pf_target_28_1>
  10b71e:	0f 18 15 3b 38 f6 ff 	prefetcht1 -0x9c7c5(%rip)        # 6ef60 <pf_target_28_2>

000000000010b725 <pf_jump_28>:
  10b725:	e9 96 59 f6 ff       	jmp    710c0 <pf_callee_28>
