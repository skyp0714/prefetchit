
/storage/prefetchit/class_b_temporal_20261001/builds/path64/54771f7236ce5ab22b131b8381b31d23e0a8b2b45695d559a9c47f572e2c3859/call-stub-fsi64uo6/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000113340 <pf_call_0>:
  113340:	0f 18 15 b9 2e f3 ff 	prefetcht1 -0xcd147(%rip)        # 46200 <pf_target_0_0>
  113347:	0f 18 15 d2 85 f3 ff 	prefetcht1 -0xc7a2e(%rip)        # 4b920 <pf_target_0_1>
  11334e:	0f 18 15 4b 2e f3 ff 	prefetcht1 -0xcd1b5(%rip)        # 461a0 <pf_target_0_2>
  113355:	0f 18 15 b4 38 f3 ff 	prefetcht1 -0xcc74c(%rip)        # 46c10 <pf_target_0_3>

000000000011335c <pf_jump_0>:
  11335c:	e9 ef 3f f1 ff       	jmp    27350 <pf_callee_0>
  113361:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  113368:	00 00 00 
  11336b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000113370 <pf_call_1>:
  113370:	41 53                	push   %r11
  113372:	4c 8b 1d 4f e4 ff ff 	mov    -0x1bb1(%rip),%r11        # 1117c8 <pf_got_13_1>

0000000000113379 <pf_got_hint_1_0>:
  113379:	41 0f 18 93 20 23 ff 	prefetcht1 -0xdce0(%r11)
  113380:	ff 
  113381:	41 5b                	pop    %r11

0000000000113383 <pf_jump_1>:
  113383:	e9 58 41 f1 ff       	jmp    274e0 <pf_callee_1>
  113388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11338f:	00 

0000000000113390 <pf_call_2>:
  113390:	41 53                	push   %r11
  113392:	4c 8b 1d f7 e1 ff ff 	mov    -0x1e09(%rip),%r11        # 111590 <pf_got_2_0>

0000000000113399 <pf_got_hint_2_0>:
  113399:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1133a0:	00 
  1133a1:	41 5b                	pop    %r11

00000000001133a3 <pf_jump_2>:
  1133a3:	e9 88 43 f1 ff       	jmp    27730 <pf_callee_2>
  1133a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1133af:	00 

00000000001133b0 <pf_call_3>:
  1133b0:	41 53                	push   %r11
  1133b2:	4c 8b 1d 9f e2 ff ff 	mov    -0x1d61(%rip),%r11        # 111658 <pf_got_3_0>

00000000001133b9 <pf_got_hint_3_0>:
  1133b9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1133c0:	00 
  1133c1:	41 5b                	pop    %r11

00000000001133c3 <pf_jump_3>:
  1133c3:	e9 38 4c f1 ff       	jmp    28000 <pf_callee_3>
  1133c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1133cf:	00 

00000000001133d0 <pf_call_4>:
  1133d0:	0f 18 15 69 cf f7 ff 	prefetcht1 -0x83097(%rip)        # 90340 <pf_target_4_0>
  1133d7:	0f 18 15 62 8d f7 ff 	prefetcht1 -0x8729e(%rip)        # 8c140 <pf_target_4_1>
  1133de:	0f 18 15 eb 96 f7 ff 	prefetcht1 -0x86915(%rip)        # 8cad0 <pf_target_4_2>
  1133e5:	0f 18 15 24 c1 fb ff 	prefetcht1 -0x43edc(%rip)        # cf510 <pf_target_4_3>

00000000001133ec <pf_jump_4>:
  1133ec:	e9 ef 69 f9 ff       	jmp    a9de0 <pf_callee_4>
  1133f1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1133f8:	00 00 00 
  1133fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000113400 <pf_call_5>:
  113400:	0f 18 15 f9 96 f7 ff 	prefetcht1 -0x86907(%rip)        # 8cb00 <pf_target_5_0>
  113407:	0f 18 15 92 3d f8 ff 	prefetcht1 -0x7c26e(%rip)        # 971a0 <pf_callee_11>
  11340e:	0f 18 15 eb 3d f8 ff 	prefetcht1 -0x7c215(%rip)        # 97200 <pf_target_5_2>
  113415:	0f 18 15 c4 2d f7 ff 	prefetcht1 -0x8d23c(%rip)        # 861e0 <pf_target_5_3>

000000000011341c <pf_jump_5>:
  11341c:	e9 df f4 f1 ff       	jmp    32900 <pf_callee_5>
  113421:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  113428:	00 00 00 
  11342b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000113430 <pf_call_6>:
  113430:	0f 18 15 89 ba f4 ff 	prefetcht1 -0xb4577(%rip)        # 5eec0 <pf_target_6_0>
  113437:	0f 18 15 38 0a f2 ff 	prefetcht1 -0xdf5c8(%rip)        # 33e76 <pf_target_6_1>
  11343e:	0f 18 15 eb 9e f5 ff 	prefetcht1 -0xa6115(%rip)        # 6d330 <pf_target_6_2>

0000000000113445 <pf_jump_6>:
  113445:	e9 26 03 f2 ff       	jmp    33770 <pf_callee_6>
  11344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000113450 <pf_call_7>:
  113450:	0f 18 15 f9 ba f4 ff 	prefetcht1 -0xb4507(%rip)        # 5ef50 <pf_target_7_0>

0000000000113457 <pf_jump_7>:
  113457:	e9 74 0e f2 ff       	jmp    342d0 <pf_callee_7>
  11345c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113460 <pf_call_8>:
  113460:	0f 18 15 9a 17 f5 ff 	prefetcht1 -0xae866(%rip)        # 64c01 <pf_target_8_0>

0000000000113467 <pf_jump_8>:
  113467:	e9 04 92 f3 ff       	jmp    4c670 <pf_callee_21>
  11346c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113470 <pf_call_9>:
  113470:	0f 18 15 cd 16 fb ff 	prefetcht1 -0x4e933(%rip)        # c4b44 <pf_target_9_0>
  113477:	0f 18 15 d2 1b fb ff 	prefetcht1 -0x4e42e(%rip)        # c5050 <pf_target_9_1>
  11347e:	0f 18 15 0b 68 f9 ff 	prefetcht1 -0x697f5(%rip)        # a9c90 <pf_target_9_2>
  113485:	0f 18 15 a4 16 fb ff 	prefetcht1 -0x4e95c(%rip)        # c4b30 <pf_target_9_3>

000000000011348c <pf_jump_9>:
  11348c:	e9 9f 8c f7 ff       	jmp    8c130 <pf_callee_9>
  113491:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  113498:	00 00 00 
  11349b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000001134a0 <pf_call_10>:
  1134a0:	41 53                	push   %r11
  1134a2:	4c 8b 1d a7 e3 ff ff 	mov    -0x1c59(%rip),%r11        # 111850 <pf_got_10_0>

00000000001134a9 <pf_got_hint_10_0>:
  1134a9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1134b0:	00 

00000000001134b1 <pf_got_hint_10_1>:
  1134b1:	41 0f 18 93 20 00 00 	prefetcht1 0x20(%r11)
  1134b8:	00 
  1134b9:	41 5b                	pop    %r11

00000000001134bb <pf_jump_10>:
  1134bb:	e9 f0 42 f1 ff       	jmp    277b0 <pf_callee_10>

00000000001134c0 <pf_call_11>:
  1134c0:	0f 18 15 39 d4 f3 ff 	prefetcht1 -0xc2bc7(%rip)        # 50900 <pf_target_11_0>

00000000001134c7 <pf_jump_11>:
  1134c7:	e9 d4 3c f8 ff       	jmp    971a0 <pf_callee_11>
  1134cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001134d0 <pf_call_12>:
  1134d0:	0f 18 15 a9 84 f3 ff 	prefetcht1 -0xc7b57(%rip)        # 4b980 <pf_target_12_0>

00000000001134d7 <pf_jump_12>:
  1134d7:	e9 f4 3c f1 ff       	jmp    271d0 <pf_callee_12>
  1134dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001134e0 <pf_call_13>:
  1134e0:	41 53                	push   %r11
  1134e2:	4c 8b 1d b7 de ff ff 	mov    -0x2149(%rip),%r11        # 1113a0 <pf_got_13_0>

00000000001134e9 <pf_got_hint_13_0>:
  1134e9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1134f0:	00 
  1134f1:	4c 8b 1d d0 e2 ff ff 	mov    -0x1d30(%rip),%r11        # 1117c8 <pf_got_13_1>

00000000001134f8 <pf_got_hint_13_1>:
  1134f8:	41 0f 18 93 10 29 ff 	prefetcht1 -0xd6f0(%r11)
  1134ff:	ff 

0000000000113500 <pf_got_hint_13_2>:
  113500:	41 0f 18 93 a0 f5 ff 	prefetcht1 -0xa60(%r11)
  113507:	ff 

0000000000113508 <pf_got_hint_13_3>:
  113508:	41 0f 18 93 b0 f5 ff 	prefetcht1 -0xa50(%r11)
  11350f:	ff 
  113510:	41 5b                	pop    %r11

0000000000113512 <pf_jump_13>:
  113512:	e9 a9 4e f3 ff       	jmp    483c0 <pf_callee_13>
  113517:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  11351e:	00 00 

0000000000113520 <pf_call_14>:
  113520:	0f 18 15 79 4c f3 ff 	prefetcht1 -0xcb387(%rip)        # 481a0 <pf_target_14_0>

0000000000113527 <pf_jump_14>:
  113527:	e9 14 3c f1 ff       	jmp    27140 <pf_callee_14>
  11352c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113530 <pf_call_15>:
  113530:	0f 18 15 29 49 f1 ff 	prefetcht1 -0xeb6d7(%rip)        # 27e60 <pf_target_15_0>
  113537:	41 53                	push   %r11
  113539:	4c 8b 1d f0 e1 ff ff 	mov    -0x1e10(%rip),%r11        # 111730 <pf_got_15_0>

0000000000113540 <pf_got_hint_15_0>:
  113540:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  113547:	00 
  113548:	41 5b                	pop    %r11

000000000011354a <pf_jump_15>:
  11354a:	e9 f1 3b f1 ff       	jmp    27140 <pf_callee_14>
  11354f:	90                   	nop

0000000000113550 <pf_call_16>:
  113550:	41 53                	push   %r11
  113552:	4c 8b 1d 3f e3 ff ff 	mov    -0x1cc1(%rip),%r11        # 111898 <pf_got_16_0>

0000000000113559 <pf_got_hint_16_0>:
  113559:	41 0f 18 93 c0 2d 00 	prefetcht1 0x2dc0(%r11)
  113560:	00 
  113561:	41 5b                	pop    %r11

0000000000113563 <pf_jump_16>:
  113563:	e9 28 44 f1 ff       	jmp    27990 <pf_callee_16>
  113568:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11356f:	00 

0000000000113570 <pf_call_17>:
  113570:	0f 18 15 c9 fa f2 ff 	prefetcht1 -0xd0537(%rip)        # 43040 <pf_target_17_0>

0000000000113577 <pf_jump_17>:
  113577:	e9 c4 46 f3 ff       	jmp    47c40 <pf_callee_17>
  11357c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113580 <pf_call_18>:
  113580:	41 53                	push   %r11
  113582:	4c 8b 1d 17 db ff ff 	mov    -0x24e9(%rip),%r11        # 1110a0 <pf_got_18_0>

0000000000113589 <pf_got_hint_18_0>:
  113589:	41 0f 18 93 90 37 ff 	prefetcht1 -0xc870(%r11)
  113590:	ff 
  113591:	41 5b                	pop    %r11

0000000000113593 <pf_jump_18>:
  113593:	e9 a8 3b f1 ff       	jmp    27140 <pf_callee_14>
  113598:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11359f:	00 

00000000001135a0 <pf_call_19>:
  1135a0:	0f 18 15 19 4a f1 ff 	prefetcht1 -0xeb5e7(%rip)        # 27fc0 <pf_target_19_0>

00000000001135a7 <pf_jump_19>:
  1135a7:	e9 34 3d f1 ff       	jmp    272e0 <pf_callee_19>
  1135ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001135b0 <pf_call_20>:
  1135b0:	0f 18 15 49 2f f5 ff 	prefetcht1 -0xad0b7(%rip)        # 66500 <pf_target_20_0>

00000000001135b7 <pf_jump_20>:
  1135b7:	e9 84 3b f1 ff       	jmp    27140 <pf_callee_14>
  1135bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001135c0 <pf_call_21>:
  1135c0:	0f 18 15 b0 2f f5 ff 	prefetcht1 -0xad050(%rip)        # 66577 <pf_target_21_0>
  1135c7:	0f 18 15 97 12 f5 ff 	prefetcht1 -0xaed69(%rip)        # 64865 <pf_target_21_1>

00000000001135ce <pf_jump_21>:
  1135ce:	e9 9d 90 f3 ff       	jmp    4c670 <pf_callee_21>
  1135d3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1135da:	00 00 00 
  1135dd:	0f 1f 00             	nopl   (%rax)

00000000001135e0 <pf_call_22>:
  1135e0:	0f 18 15 c9 98 f3 ff 	prefetcht1 -0xc6737(%rip)        # 4ceb0 <pf_target_22_0>
  1135e7:	0f 18 15 12 6e f9 ff 	prefetcht1 -0x691ee(%rip)        # aa400 <pf_target_22_1>

00000000001135ee <pf_jump_22>:
  1135ee:	e9 8d d3 f3 ff       	jmp    50980 <pf_callee_22>
  1135f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1135fa:	00 00 00 
  1135fd:	0f 1f 00             	nopl   (%rax)

0000000000113600 <pf_call_23>:
  113600:	0f 18 15 29 41 f1 ff 	prefetcht1 -0xebed7(%rip)        # 27730 <pf_callee_2>
  113607:	0f 18 15 6f 0d f5 ff 	prefetcht1 -0xaf291(%rip)        # 6437d <pf_target_23_1>
  11360e:	0f 18 15 eb 4a f1 ff 	prefetcht1 -0xeb515(%rip)        # 28100 <pf_callee_25>
  113615:	0f 18 15 64 0d f5 ff 	prefetcht1 -0xaf29c(%rip)        # 64380 <pf_target_23_3>

000000000011361c <pf_jump_23>:
  11361c:	e9 5f cb f4 ff       	jmp    60180 <pf_callee_23>
  113621:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  113628:	00 00 00 
  11362b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000113630 <pf_call_24>:
  113630:	0f 18 15 15 2f f5 ff 	prefetcht1 -0xad0eb(%rip)        # 6654c <pf_target_24_0>

0000000000113637 <pf_jump_24>:
  113637:	e9 f4 40 f1 ff       	jmp    27730 <pf_callee_2>
  11363c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113640 <pf_call_25>:
  113640:	0f 18 15 39 13 f5 ff 	prefetcht1 -0xaecc7(%rip)        # 64980 <pf_target_25_0>
  113647:	0f 18 15 12 c0 f4 ff 	prefetcht1 -0xb3fee(%rip)        # 5f660 <pf_target_25_1>
  11364e:	0f 18 15 1b f8 f4 ff 	prefetcht1 -0xb07e5(%rip)        # 62e70 <pf_target_25_2>

0000000000113655 <pf_jump_25>:
  113655:	e9 a6 4a f1 ff       	jmp    28100 <pf_callee_25>
  11365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000113660 <pf_call_26>:
  113660:	0f 18 15 29 4a f1 ff 	prefetcht1 -0xeb5d7(%rip)        # 28090 <pf_target_26_0>
  113667:	0f 18 15 64 8b f3 ff 	prefetcht1 -0xc749c(%rip)        # 4c1d2 <pf_target_26_1>
  11366e:	0f 18 15 fb 88 f3 ff 	prefetcht1 -0xc7705(%rip)        # 4bf70 <pf_target_26_2>

0000000000113675 <pf_jump_26>:
  113675:	e9 56 3b f1 ff       	jmp    271d0 <pf_callee_12>
  11367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000113680 <pf_call_27>:
  113680:	0f 18 15 fb 74 f5 ff 	prefetcht1 -0xa8b05(%rip)        # 6ab82 <pf_target_27_0>
  113687:	0f 18 15 a2 74 f5 ff 	prefetcht1 -0xa8b5e(%rip)        # 6ab30 <pf_target_27_1>

000000000011368e <pf_jump_27>:
  11368e:	e9 ad 47 f1 ff       	jmp    27e40 <pf_callee_27>
  113693:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11369a:	00 00 00 
  11369d:	0f 1f 00             	nopl   (%rax)

00000000001136a0 <pf_call_28>:
  1136a0:	41 53                	push   %r11
  1136a2:	4c 8b 1d bf d9 ff ff 	mov    -0x2641(%rip),%r11        # 111068 <pf_got_28_0>

00000000001136a9 <pf_got_hint_28_0>:
  1136a9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1136b0:	00 
  1136b1:	41 5b                	pop    %r11

00000000001136b3 <pf_jump_28>:
  1136b3:	e9 c8 80 f6 ff       	jmp    7b780 <pf_callee_28>
