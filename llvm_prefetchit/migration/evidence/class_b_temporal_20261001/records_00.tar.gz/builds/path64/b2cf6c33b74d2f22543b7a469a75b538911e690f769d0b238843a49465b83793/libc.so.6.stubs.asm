
/storage/prefetchit/class_b_temporal_20261001/builds/path64/b2cf6c33b74d2f22543b7a469a75b538911e690f769d0b238843a49465b83793/call-stub-aqia9948/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000229380 <pf_call_0>:
  229380:	0f 18 15 fc d1 e4 ff 	prefetcht1 -0x1b2e04(%rip)        # 76583 <pf_target_0_0>
  229387:	0f 18 15 73 e1 e4 ff 	prefetcht1 -0x1b1e8d(%rip)        # 77501 <pf_target_0_1>
  22938e:	0f 18 15 6d dc e4 ff 	prefetcht1 -0x1b2393(%rip)        # 77002 <pf_target_0_2>
  229395:	0f 18 15 c1 d1 e4 ff 	prefetcht1 -0x1b2e3f(%rip)        # 7655d <pf_target_0_3>

000000000022939c <pf_jump_0>:
  22939c:	e9 8f 0e e3 ff       	jmp    5a230 <pf_callee_0>
  2293a1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2293a8:	00 00 00 
  2293ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000002293b0 <pf_call_1>:
  2293b0:	0f 18 15 89 82 f8 ff 	prefetcht1 -0x77d77(%rip)        # 1b1640 <pf_target_1_0>
  2293b7:	0f 18 15 22 48 e6 ff 	prefetcht1 -0x19b7de(%rip)        # 8dbe0 <pf_callee_5>
  2293be:	0f 18 15 3b bc e4 ff 	prefetcht1 -0x1b43c5(%rip)        # 75000 <pf_target_1_2>
  2293c5:	0f 18 15 d4 51 e6 ff 	prefetcht1 -0x19ae2c(%rip)        # 8e5a0 <pf_callee_4>

00000000002293cc <pf_jump_1>:
  2293cc:	e9 3f 52 e6 ff       	jmp    8e610 <pf_callee_1>
  2293d1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2293d8:	00 00 00 
  2293db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000002293e0 <pf_call_2>:
  2293e0:	0f 18 15 59 0e e3 ff 	prefetcht1 -0x1cf1a7(%rip)        # 5a240 <pf_target_2_0>
  2293e7:	0f 18 15 72 4b e6 ff 	prefetcht1 -0x19b48e(%rip)        # 8df60 <pf_target_2_1>

00000000002293ee <pf_jump_2>:
  2293ee:	e9 7d 65 e6 ff       	jmp    8f970 <pf_callee_2>
  2293f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2293fa:	00 00 00 
  2293fd:	0f 1f 00             	nopl   (%rax)

0000000000229400 <pf_call_3>:
  229400:	0f 18 15 7a 82 f8 ff 	prefetcht1 -0x77d86(%rip)        # 1b1681 <pf_target_3_0>
  229407:	0f 18 15 db d8 e4 ff 	prefetcht1 -0x1b2725(%rip)        # 76ce9 <pf_target_3_1>
  22940e:	0f 18 15 6b 49 e6 ff 	prefetcht1 -0x19b695(%rip)        # 8dd80 <pf_target_3_2>
  229415:	0f 18 15 84 db e4 ff 	prefetcht1 -0x1b247c(%rip)        # 76fa0 <pf_target_3_3>

000000000022941c <pf_jump_3>:
  22941c:	e9 cf bb e4 ff       	jmp    74ff0 <pf_callee_3>
  229421:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229428:	00 00 00 
  22942b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229430 <pf_call_4>:
  229430:	0f 18 15 b9 bb e4 ff 	prefetcht1 -0x1b4447(%rip)        # 74ff0 <pf_callee_3>
  229437:	0f 18 15 32 65 e6 ff 	prefetcht1 -0x199ace(%rip)        # 8f970 <pf_callee_2>
  22943e:	0f 18 15 3b 65 e6 ff 	prefetcht1 -0x199ac5(%rip)        # 8f980 <pf_target_4_2>
  229445:	0f 18 15 f4 bb e4 ff 	prefetcht1 -0x1b440c(%rip)        # 75040 <pf_target_4_3>

000000000022944c <pf_jump_4>:
  22944c:	e9 4f 51 e6 ff       	jmp    8e5a0 <pf_callee_4>
  229451:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229458:	00 00 00 
  22945b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229460 <pf_call_5>:
  229460:	0f 18 15 e9 cb e4 ff 	prefetcht1 -0x1b3417(%rip)        # 76050 <pf_target_5_0>
  229467:	0f 18 15 62 c2 e4 ff 	prefetcht1 -0x1b3d9e(%rip)        # 756d0 <pf_target_5_1>
  22946e:	0f 18 15 83 db e4 ff 	prefetcht1 -0x1b247d(%rip)        # 76ff8 <pf_target_5_2>
  229475:	0f 18 15 b4 0d e3 ff 	prefetcht1 -0x1cf24c(%rip)        # 5a230 <pf_callee_0>

000000000022947c <pf_jump_5>:
  22947c:	e9 5f 47 e6 ff       	jmp    8dbe0 <pf_callee_5>
  229481:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229488:	00 00 00 
  22948b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229490 <pf_call_6>:
  229490:	0f 18 15 06 ae e6 ff 	prefetcht1 -0x1951fa(%rip)        # 9429d <pf_target_6_0>
  229497:	0f 18 15 99 d0 e6 ff 	prefetcht1 -0x192f67(%rip)        # 96537 <pf_target_6_1>

000000000022949e <pf_jump_6>:
  22949e:	e9 7d 75 e6 ff       	jmp    90a20 <pf_callee_19>
  2294a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2294aa:	00 00 00 
  2294ad:	0f 1f 00             	nopl   (%rax)

00000000002294b0 <pf_call_7>:
  2294b0:	0f 18 15 49 7b e6 ff 	prefetcht1 -0x1984b7(%rip)        # 91000 <pf_target_7_0>
  2294b7:	0f 18 15 32 7b e6 ff 	prefetcht1 -0x1984ce(%rip)        # 90ff0 <pf_target_7_1>

00000000002294be <pf_jump_7>:
  2294be:	e9 4d 04 e7 ff       	jmp    99910 <pf_callee_7>
  2294c3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2294ca:	00 00 00 
  2294cd:	0f 1f 00             	nopl   (%rax)

00000000002294d0 <pf_call_8>:
  2294d0:	0f 18 15 19 7b e6 ff 	prefetcht1 -0x1984e7(%rip)        # 90ff0 <pf_target_7_1>

00000000002294d7 <pf_jump_8>:
  2294d7:	e9 34 04 e7 ff       	jmp    99910 <pf_callee_7>
  2294dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002294e0 <pf_call_9>:
  2294e0:	0f 18 15 94 ac e6 ff 	prefetcht1 -0x19536c(%rip)        # 9417b <pf_target_9_0>

00000000002294e7 <pf_jump_9>:
  2294e7:	e9 d4 75 e6 ff       	jmp    90ac0 <pf_callee_15>
  2294ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002294f0 <pf_call_10>:
  2294f0:	0f 18 15 59 c5 ef ff 	prefetcht1 -0x103aa7(%rip)        # 125a50 <pf_target_10_0>
  2294f7:	0f 18 15 b2 d3 ef ff 	prefetcht1 -0x102c4e(%rip)        # 1268b0 <pf_target_10_1>
  2294fe:	0f 18 15 bc d3 ef ff 	prefetcht1 -0x102c44(%rip)        # 1268c1 <pf_target_10_2>

0000000000229505 <pf_jump_10>:
  229505:	e9 f6 d3 ef ff       	jmp    126900 <pf_callee_10>
  22950a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229510 <pf_call_11>:
  229510:	0f 18 15 c9 73 e6 ff 	prefetcht1 -0x198c37(%rip)        # 908e0 <pf_target_11_0>
  229517:	0f 18 15 b2 88 f2 ff 	prefetcht1 -0xd774e(%rip)        # 151dd0 <pf_target_11_1>
  22951e:	0f 18 15 9c f3 f3 ff 	prefetcht1 -0xc0c64(%rip)        # 1688c1 <pf_target_11_2>
  229525:	0f 18 15 84 f3 f3 ff 	prefetcht1 -0xc0c7c(%rip)        # 1688b0 <pf_target_11_3>

000000000022952c <pf_jump_11>:
  22952c:	e9 2f c8 e1 ff       	jmp    45d60 <pf_callee_11>
  229531:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229538:	00 00 00 
  22953b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229540 <pf_call_12>:
  229540:	0f 18 15 39 06 f2 ff 	prefetcht1 -0xdf9c7(%rip)        # 149b80 <pf_target_12_0>
  229547:	0f 18 15 f2 eb e7 ff 	prefetcht1 -0x18140e(%rip)        # a8140 <pf_target_12_1>
  22954e:	0f 18 15 1b ee df ff 	prefetcht1 -0x2011e5(%rip)        # 28370 <pf_target_12_2>

0000000000229555 <pf_jump_12>:
  229555:	e9 56 80 e6 ff       	jmp    915b0 <pf_callee_12>
  22955a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229560 <pf_call_13>:
  229560:	0f 18 15 19 c1 e6 ff 	prefetcht1 -0x193ee7(%rip)        # 95680 <pf_target_13_0>
  229567:	0f 18 15 42 8a e6 ff 	prefetcht1 -0x1975be(%rip)        # 91fb0 <pf_target_13_1>
  22956e:	0f 18 15 eb 55 ef ff 	prefetcht1 -0x10aa15(%rip)        # 11eb60 <pf_target_13_2>

0000000000229575 <pf_jump_13>:
  229575:	e9 b6 c7 e6 ff       	jmp    95d30 <pf_callee_13>
  22957a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229580 <pf_call_14>:
  229580:	0f 18 15 19 ab e6 ff 	prefetcht1 -0x1954e7(%rip)        # 940a0 <pf_target_14_0>

0000000000229587 <pf_jump_14>:
  229587:	e9 54 7d e6 ff       	jmp    912e0 <pf_callee_14>
  22958c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229590 <pf_call_15>:
  229590:	0f 18 15 c9 c7 e1 ff 	prefetcht1 -0x1e3837(%rip)        # 45d60 <pf_callee_11>

0000000000229597 <pf_jump_15>:
  229597:	e9 24 75 e6 ff       	jmp    90ac0 <pf_callee_15>
  22959c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002295a0 <pf_call_16>:
  2295a0:	0f 18 15 b9 c7 e1 ff 	prefetcht1 -0x1e3847(%rip)        # 45d60 <pf_callee_11>

00000000002295a7 <pf_jump_16>:
  2295a7:	e9 c4 a3 e7 ff       	jmp    a3970 <pf_callee_16>
  2295ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002295b0 <pf_call_17>:
  2295b0:	0f 18 15 cb 7a e7 ff 	prefetcht1 -0x188535(%rip)        # a1082 <pf_target_17_0>

00000000002295b7 <pf_jump_17>:
  2295b7:	e9 94 b3 e7 ff       	jmp    a4950 <pf_callee_17>
  2295bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002295c0 <pf_call_18>:
  2295c0:	0f 18 15 f9 56 ef ff 	prefetcht1 -0x10a907(%rip)        # 11ecc0 <pf_target_18_0>

00000000002295c7 <pf_jump_18>:
  2295c7:	e9 d4 bd e7 ff       	jmp    a53a0 <pf_callee_18>
  2295cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002295d0 <pf_call_19>:
  2295d0:	0f 18 15 2a 21 ef ff 	prefetcht1 -0x10ded6(%rip)        # 11b701 <pf_target_19_0>
  2295d7:	0f 18 15 42 b3 ee ff 	prefetcht1 -0x114cbe(%rip)        # 114920 <pf_target_19_1>
  2295de:	0f 18 15 17 21 ef ff 	prefetcht1 -0x10dee9(%rip)        # 11b6fc <pf_target_19_2>
  2295e5:	0f 18 15 64 cf f0 ff 	prefetcht1 -0xf309c(%rip)        # 136550 <pf_target_19_3>

00000000002295ec <pf_jump_19>:
  2295ec:	e9 2f 74 e6 ff       	jmp    90a20 <pf_callee_19>
