
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_aligned/d2a2d732143c46b04f5ca16733387a5f5713ad8dc218c423def02e91e4025de9/call-stub-maoo6u_i/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000010b340 <pf_call_0>:
  10b340:	0f 18 15 bc 06 f4 ff 	prefetcht1 -0xbf944(%rip)        # 4ba03 <pf_target_0_0>
  10b347:	0f 18 15 f5 06 f4 ff 	prefetcht1 -0xbf90b(%rip)        # 4ba43 <pf_target_0_1>
  10b34e:	0f 18 15 5b 10 f4 ff 	prefetcht1 -0xbefa5(%rip)        # 4c3b0 <pf_target_0_2>
  10b355:	0f 18 15 c4 5c f4 ff 	prefetcht1 -0xba33c(%rip)        # 51020 <pf_target_0_3>
  10b35c:	0f 18 15 dd 05 f4 ff 	prefetcht1 -0xbfa23(%rip)        # 4b940 <pf_target_0_4>
  10b363:	0f 18 15 16 5d f4 ff 	prefetcht1 -0xba2ea(%rip)        # 51080 <pf_target_0_5>
  10b36a:	41 53                	push   %r11
  10b36c:	4c 8b 1d ad de ff ff 	mov    -0x2153(%rip),%r11        # 109220 <pf_got_0_0>

000000000010b373 <pf_got_hint_0_0>:
  10b373:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b37a:	00 
  10b37b:	4c 8b 1d 2e e2 ff ff 	mov    -0x1dd2(%rip),%r11        # 1095b0 <pf_got_0_1>

000000000010b382 <pf_got_hint_0_1>:
  10b382:	41 0f 18 93 60 69 00 	prefetcht1 0x6960(%r11)
  10b389:	00 
  10b38a:	41 5b                	pop    %r11

000000000010b38c <pf_jump_0>:
  10b38c:	e9 af c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b391:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b398:	00 00 00 
  10b39b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000010b3a0 <pf_call_1>:
  10b3a0:	0f 18 15 69 e2 f2 ff 	prefetcht1 -0xd1d97(%rip)        # 39610 <pf_callee_2>

000000000010b3a7 <pf_jump_1>:
  10b3a7:	e9 94 c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b3ac:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b3b3:	00 00 00 
  10b3b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b3bd:	00 00 00 

000000000010b3c0 <pf_call_2>:
  10b3c0:	41 53                	push   %r11
  10b3c2:	4c 8b 1d 67 dd ff ff 	mov    -0x2299(%rip),%r11        # 109130 <pf_got_2_0>

000000000010b3c9 <pf_got_hint_2_0>:
  10b3c9:	41 0f 18 93 b0 06 00 	prefetcht1 0x6b0(%r11)
  10b3d0:	00 
  10b3d1:	4c 8b 1d d8 e1 ff ff 	mov    -0x1e28(%rip),%r11        # 1095b0 <pf_got_0_1>

000000000010b3d8 <pf_got_hint_2_1>:
  10b3d8:	41 0f 18 93 c5 1f 00 	prefetcht1 0x1fc5(%r11)
  10b3df:	00 

000000000010b3e0 <pf_got_hint_2_2>:
  10b3e0:	41 0f 18 93 c0 31 00 	prefetcht1 0x31c0(%r11)
  10b3e7:	00 
  10b3e8:	41 5b                	pop    %r11

000000000010b3ea <pf_jump_2>:
  10b3ea:	e9 21 e2 f2 ff       	jmp    39610 <pf_callee_2>
  10b3ef:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b3f6:	00 00 00 
  10b3f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000010b400 <pf_call_3>:
  10b400:	41 53                	push   %r11
  10b402:	4c 8b 1d a7 e1 ff ff 	mov    -0x1e59(%rip),%r11        # 1095b0 <pf_got_0_1>

000000000010b409 <pf_got_hint_3_0>:
  10b409:	41 0f 18 93 50 79 00 	prefetcht1 0x7950(%r11)
  10b410:	00 
  10b411:	4c 8b 1d 98 e4 ff ff 	mov    -0x1b68(%rip),%r11        # 1098b0 <pf_got_3_1>

000000000010b418 <pf_got_hint_3_1>:
  10b418:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b41f:	00 

000000000010b420 <pf_got_hint_3_2>:
  10b420:	41 0f 18 93 34 00 00 	prefetcht1 0x34(%r11)
  10b427:	00 
  10b428:	41 5b                	pop    %r11

000000000010b42a <pf_jump_3>:
  10b42a:	e9 11 c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b42f:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b436:	00 00 00 
  10b439:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000010b440 <pf_call_4>:
  10b440:	41 53                	push   %r11
  10b442:	4c 8b 1d af de ff ff 	mov    -0x2151(%rip),%r11        # 1092f8 <pf_got_4_0>

000000000010b449 <pf_got_hint_4_0>:
  10b449:	41 0f 18 93 d0 d7 00 	prefetcht1 0xd7d0(%r11)
  10b450:	00 
  10b451:	41 5b                	pop    %r11

000000000010b453 <pf_jump_4>:
  10b453:	e9 98 c7 f1 ff       	jmp    27bf0 <pf_callee_4>
  10b458:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b45f:	00 00 00 
  10b462:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b469:	00 00 00 
  10b46c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b473:	00 00 00 
  10b476:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b47d:	00 00 00 

000000000010b480 <pf_call_5>:
  10b480:	41 53                	push   %r11
  10b482:	4c 8b 1d 4f dd ff ff 	mov    -0x22b1(%rip),%r11        # 1091d8 <pf_got_5_0>

000000000010b489 <pf_got_hint_5_0>:
  10b489:	41 0f 18 93 d3 ca 00 	prefetcht1 0xcad3(%r11)
  10b490:	00 
  10b491:	4c 8b 1d 60 de ff ff 	mov    -0x21a0(%rip),%r11        # 1092f8 <pf_got_4_0>

000000000010b498 <pf_got_hint_5_1>:
  10b498:	41 0f 18 93 00 d7 00 	prefetcht1 0xd700(%r11)
  10b49f:	00 
  10b4a0:	41 5b                	pop    %r11

000000000010b4a2 <pf_jump_5>:
  10b4a2:	e9 49 c8 f1 ff       	jmp    27cf0 <pf_callee_5>
  10b4a7:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b4ae:	00 00 00 
  10b4b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b4b8:	00 00 00 
  10b4bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000010b4c0 <pf_call_6>:
  10b4c0:	41 53                	push   %r11
  10b4c2:	4c 8b 1d 1f e3 ff ff 	mov    -0x1ce1(%rip),%r11        # 1097e8 <pf_got_6_0>

000000000010b4c9 <pf_got_hint_6_0>:
  10b4c9:	41 0f 18 93 e0 99 ff 	prefetcht1 -0x6620(%r11)
  10b4d0:	ff 
  10b4d1:	41 5b                	pop    %r11

000000000010b4d3 <pf_jump_6>:
  10b4d3:	e9 68 cc f1 ff       	jmp    28140 <pf_callee_6>
  10b4d8:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b4df:	00 00 00 
  10b4e2:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b4e9:	00 00 00 
  10b4ec:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b4f3:	00 00 00 
  10b4f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b4fd:	00 00 00 

000000000010b500 <pf_call_7>:
  10b500:	41 53                	push   %r11
  10b502:	4c 8b 1d c7 dc ff ff 	mov    -0x2339(%rip),%r11        # 1091d0 <pf_got_7_0>

000000000010b509 <pf_got_hint_7_0>:
  10b509:	41 0f 18 93 3a 00 00 	prefetcht1 0x3a(%r11)
  10b510:	00 

000000000010b511 <pf_got_hint_7_1>:
  10b511:	41 0f 18 93 80 00 00 	prefetcht1 0x80(%r11)
  10b518:	00 
  10b519:	4c 8b 1d c8 e2 ff ff 	mov    -0x1d38(%rip),%r11        # 1097e8 <pf_got_6_0>

000000000010b520 <pf_got_hint_7_2>:
  10b520:	41 0f 18 93 70 e9 ff 	prefetcht1 -0x1690(%r11)
  10b527:	ff 

000000000010b528 <pf_got_hint_7_3>:
  10b528:	41 0f 18 93 91 e9 ff 	prefetcht1 -0x166f(%r11)
  10b52f:	ff 
  10b530:	41 5b                	pop    %r11

000000000010b532 <pf_jump_7>:
  10b532:	e9 49 c1 f1 ff       	jmp    27680 <pf_callee_7>
  10b537:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  10b53e:	00 00 

000000000010b540 <pf_call_8>:
  10b540:	41 53                	push   %r11
  10b542:	4c 8b 1d 9f e2 ff ff 	mov    -0x1d61(%rip),%r11        # 1097e8 <pf_got_6_0>

000000000010b549 <pf_got_hint_8_0>:
  10b549:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b550:	00 

000000000010b551 <pf_got_hint_8_1>:
  10b551:	41 0f 18 93 15 00 00 	prefetcht1 0x15(%r11)
  10b558:	00 

000000000010b559 <pf_got_hint_8_2>:
  10b559:	41 0f 18 93 53 00 00 	prefetcht1 0x53(%r11)
  10b560:	00 
  10b561:	41 5b                	pop    %r11

000000000010b563 <pf_jump_8>:
  10b563:	e9 68 ca f1 ff       	jmp    27fd0 <pf_callee_8>
  10b568:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b56f:	00 00 00 
  10b572:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b579:	00 00 00 
  10b57c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b580 <pf_call_9>:
  10b580:	41 53                	push   %r11
  10b582:	4c 8b 1d 6f dd ff ff 	mov    -0x2291(%rip),%r11        # 1092f8 <pf_got_4_0>

000000000010b589 <pf_got_hint_9_0>:
  10b589:	41 0f 18 93 b0 04 00 	prefetcht1 0x4b0(%r11)
  10b590:	00 

000000000010b591 <pf_got_hint_9_1>:
  10b591:	41 0f 18 93 e0 26 00 	prefetcht1 0x26e0(%r11)
  10b598:	00 

000000000010b599 <pf_got_hint_9_2>:
  10b599:	41 0f 18 93 80 53 00 	prefetcht1 0x5380(%r11)
  10b5a0:	00 
  10b5a1:	4c 8b 1d a0 df ff ff 	mov    -0x2060(%rip),%r11        # 109548 <pf_got_12_0>

000000000010b5a8 <pf_got_hint_9_3>:
  10b5a8:	41 0f 18 93 b0 89 01 	prefetcht1 0x189b0(%r11)
  10b5af:	00 

000000000010b5b0 <pf_got_hint_9_4>:
  10b5b0:	41 0f 18 93 b0 57 03 	prefetcht1 0x357b0(%r11)
  10b5b7:	00 

000000000010b5b8 <pf_got_hint_9_5>:
  10b5b8:	41 0f 18 93 30 5a 03 	prefetcht1 0x35a30(%r11)
  10b5bf:	00 
  10b5c0:	4c 8b 1d b1 e0 ff ff 	mov    -0x1f4f(%rip),%r11        # 109678 <pf_got_9_6>

000000000010b5c7 <pf_got_hint_9_6>:
  10b5c7:	41 0f 18 93 60 50 ff 	prefetcht1 -0xafa0(%r11)
  10b5ce:	ff 

000000000010b5cf <pf_got_hint_9_7>:
  10b5cf:	41 0f 18 93 60 76 ff 	prefetcht1 -0x89a0(%r11)
  10b5d6:	ff 
  10b5d7:	41 5b                	pop    %r11

000000000010b5d9 <pf_jump_9>:
  10b5d9:	e9 b2 c4 f1 ff       	jmp    27a90 <pf_callee_9>
  10b5de:	66 90                	xchg   %ax,%ax

000000000010b5e0 <pf_call_10>:
  10b5e0:	41 53                	push   %r11
  10b5e2:	4c 8b 1d c7 df ff ff 	mov    -0x2039(%rip),%r11        # 1095b0 <pf_got_0_1>

000000000010b5e9 <pf_got_hint_10_0>:
  10b5e9:	41 0f 18 93 20 6f fe 	prefetcht1 -0x190e0(%r11)
  10b5f0:	ff 

000000000010b5f1 <pf_got_hint_10_1>:
  10b5f1:	41 0f 18 93 5a b4 ff 	prefetcht1 -0x4ba6(%r11)
  10b5f8:	ff 
  10b5f9:	41 5b                	pop    %r11

000000000010b5fb <pf_jump_10>:
  10b5fb:	e9 50 cb f1 ff       	jmp    28150 <pf_callee_10>

000000000010b600 <pf_call_11>:
  10b600:	0f 18 15 e9 bf f1 ff 	prefetcht1 -0xe4017(%rip)        # 275f0 <pf_target_11_0>

000000000010b607 <pf_jump_11>:
  10b607:	e9 94 66 f4 ff       	jmp    51ca0 <pf_callee_11>
  10b60c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b613:	00 00 00 
  10b616:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b61d:	00 00 00 

000000000010b620 <pf_call_12>:
  10b620:	41 53                	push   %r11
  10b622:	4c 8b 1d 1f df ff ff 	mov    -0x20e1(%rip),%r11        # 109548 <pf_got_12_0>

000000000010b629 <pf_got_hint_12_0>:
  10b629:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b630:	00 

000000000010b631 <pf_got_hint_12_1>:
  10b631:	41 0f 18 93 f2 89 01 	prefetcht1 0x189f2(%r11)
  10b638:	00 
  10b639:	41 5b                	pop    %r11

000000000010b63b <pf_jump_12>:
  10b63b:	e9 70 bb f1 ff       	jmp    271b0 <pf_callee_12>

000000000010b640 <pf_call_13>:
  10b640:	41 53                	push   %r11
  10b642:	4c 8b 1d 0f de ff ff 	mov    -0x21f1(%rip),%r11        # 109458 <pf_got_13_0>

000000000010b649 <pf_got_hint_13_0>:
  10b649:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b650:	00 
  10b651:	4c 8b 1d a8 e2 ff ff 	mov    -0x1d58(%rip),%r11        # 109900 <pf_got_13_1>

000000000010b658 <pf_got_hint_13_1>:
  10b658:	41 0f 18 93 70 e8 fe 	prefetcht1 -0x11790(%r11)
  10b65f:	ff 

000000000010b660 <pf_got_hint_13_2>:
  10b660:	41 0f 18 93 20 26 ff 	prefetcht1 -0xd9e0(%r11)
  10b667:	ff 

000000000010b668 <pf_got_hint_13_3>:
  10b668:	41 0f 18 93 31 26 ff 	prefetcht1 -0xd9cf(%r11)
  10b66f:	ff 

000000000010b670 <pf_got_hint_13_4>:
  10b670:	41 0f 18 93 10 29 ff 	prefetcht1 -0xd6f0(%r11)
  10b677:	ff 

000000000010b678 <pf_got_hint_13_5>:
  10b678:	41 0f 18 93 a0 f5 ff 	prefetcht1 -0xa60(%r11)
  10b67f:	ff 

000000000010b680 <pf_got_hint_13_6>:
  10b680:	41 0f 18 93 b0 f5 ff 	prefetcht1 -0xa50(%r11)
  10b687:	ff 
  10b688:	41 5b                	pop    %r11

000000000010b68a <pf_jump_13>:
  10b68a:	e9 a1 24 f4 ff       	jmp    4db30 <pf_callee_13>
  10b68f:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b696:	00 00 00 
  10b699:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000010b6a0 <pf_call_14>:
  10b6a0:	41 53                	push   %r11
  10b6a2:	4c 8b 1d 4f df ff ff 	mov    -0x20b1(%rip),%r11        # 1095f8 <pf_got_14_0>

000000000010b6a9 <pf_got_hint_14_0>:
  10b6a9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b6b0:	00 
  10b6b1:	41 5b                	pop    %r11

000000000010b6b3 <pf_jump_14>:
  10b6b3:	e9 78 cb f1 ff       	jmp    28230 <pf_callee_14>
  10b6b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b6bf:	00 

000000000010b6c0 <pf_call_15>:
  10b6c0:	41 53                	push   %r11
  10b6c2:	4c 8b 1d 27 dd ff ff 	mov    -0x22d9(%rip),%r11        # 1093f0 <pf_got_15_0>

000000000010b6c9 <pf_got_hint_15_0>:
  10b6c9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b6d0:	00 
  10b6d1:	41 5b                	pop    %r11

000000000010b6d3 <pf_jump_15>:
  10b6d3:	e9 68 ba f1 ff       	jmp    27140 <pf_callee_15>
  10b6d8:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b6df:	00 00 00 
  10b6e2:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b6e9:	00 00 00 
  10b6ec:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b6f3:	00 00 00 
  10b6f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b6fd:	00 00 00 

000000000010b700 <pf_call_16>:
  10b700:	0f 18 15 d9 c0 f1 ff 	prefetcht1 -0xe3f27(%rip)        # 277e0 <pf_target_16_0>
  10b707:	0f 18 15 b5 08 f4 ff 	prefetcht1 -0xbf74b(%rip)        # 4bfc3 <pf_target_16_1>
  10b70e:	41 53                	push   %r11
  10b710:	4c 8b 1d d9 dc ff ff 	mov    -0x2327(%rip),%r11        # 1093f0 <pf_got_15_0>

000000000010b717 <pf_got_hint_16_0>:
  10b717:	41 0f 18 93 11 00 00 	prefetcht1 0x11(%r11)
  10b71e:	00 
  10b71f:	41 5b                	pop    %r11

000000000010b721 <pf_jump_16>:
  10b721:	e9 1a ba f1 ff       	jmp    27140 <pf_callee_15>
  10b726:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b72d:	00 00 00 
  10b730:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b737:	00 00 00 
  10b73a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000010b740 <pf_call_17>:
  10b740:	0f 18 15 a9 bd f1 ff 	prefetcht1 -0xe4257(%rip)        # 274f0 <pf_target_17_0>
  10b747:	0f 18 15 3c d1 f3 ff 	prefetcht1 -0xc2ec4(%rip)        # 4888a <pf_target_17_1>

000000000010b74e <pf_jump_17>:
  10b74e:	e9 8d d0 f3 ff       	jmp    487e0 <pf_callee_17>
  10b753:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b75a:	00 00 00 
  10b75d:	0f 1f 00             	nopl   (%rax)

000000000010b760 <pf_call_18>:
  10b760:	0f 18 15 b9 08 f4 ff 	prefetcht1 -0xbf747(%rip)        # 4c020 <pf_target_18_0>
  10b767:	0f 18 15 d5 08 f4 ff 	prefetcht1 -0xbf72b(%rip)        # 4c043 <pf_target_18_1>

000000000010b76e <pf_jump_18>:
  10b76e:	e9 ed 0c f4 ff       	jmp    4c460 <pf_callee_18>
  10b773:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b77a:	00 00 00 
  10b77d:	0f 1f 00             	nopl   (%rax)

000000000010b780 <pf_call_19>:
  10b780:	0f 18 15 89 21 f4 ff 	prefetcht1 -0xbde77(%rip)        # 4d910 <pf_target_19_0>

000000000010b787 <pf_jump_19>:
  10b787:	e9 24 ba f1 ff       	jmp    271b0 <pf_callee_12>
  10b78c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b790 <pf_call_20>:
  10b790:	0f 18 15 09 08 f4 ff 	prefetcht1 -0xbf7f7(%rip)        # 4bfa0 <pf_target_20_0>

000000000010b797 <pf_jump_20>:
  10b797:	e9 a4 b9 f1 ff       	jmp    27140 <pf_callee_15>
  10b79c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b7a0 <pf_call_21>:
  10b7a0:	0f 18 15 f9 c8 f1 ff 	prefetcht1 -0xe3707(%rip)        # 280a0 <pf_target_21_0>

000000000010b7a7 <pf_jump_21>:
  10b7a7:	e9 04 ba f1 ff       	jmp    271b0 <pf_callee_12>
  10b7ac:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b7b3:	00 00 00 
  10b7b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b7bd:	00 00 00 

000000000010b7c0 <pf_call_22>:
  10b7c0:	41 53                	push   %r11
  10b7c2:	4c 8b 1d e7 dd ff ff 	mov    -0x2219(%rip),%r11        # 1095b0 <pf_got_0_1>

000000000010b7c9 <pf_got_hint_22_0>:
  10b7c9:	41 0f 18 93 30 56 fe 	prefetcht1 -0x1a9d0(%r11)
  10b7d0:	ff 

000000000010b7d1 <pf_got_hint_22_1>:
  10b7d1:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b7d8:	00 

000000000010b7d9 <pf_got_hint_22_2>:
  10b7d9:	41 0f 18 93 44 00 00 	prefetcht1 0x44(%r11)
  10b7e0:	00 

000000000010b7e1 <pf_got_hint_22_3>:
  10b7e1:	41 0f 18 93 88 00 00 	prefetcht1 0x88(%r11)
  10b7e8:	00 
  10b7e9:	4c 8b 1d 10 e1 ff ff 	mov    -0x1ef0(%rip),%r11        # 109900 <pf_got_13_1>

000000000010b7f0 <pf_got_hint_22_4>:
  10b7f0:	41 0f 18 93 b0 3e fe 	prefetcht1 -0x1c150(%r11)
  10b7f7:	ff 

000000000010b7f8 <pf_got_hint_22_5>:
  10b7f8:	41 0f 18 93 40 46 fe 	prefetcht1 -0x1b9c0(%r11)
  10b7ff:	ff 

000000000010b800 <pf_got_hint_22_6>:
  10b800:	41 0f 18 93 70 46 fe 	prefetcht1 -0x1b990(%r11)
  10b807:	ff 
  10b808:	41 5b                	pop    %r11

000000000010b80a <pf_jump_22>:
  10b80a:	e9 51 c3 f1 ff       	jmp    27b60 <pf_callee_22>
  10b80f:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b816:	00 00 00 
  10b819:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000010b820 <pf_call_23>:
  10b820:	0f 18 15 89 16 f4 ff 	prefetcht1 -0xbe977(%rip)        # 4ceb0 <pf_target_23_0>
  10b827:	0f 18 15 b2 cf f3 ff 	prefetcht1 -0xc304e(%rip)        # 487e0 <pf_callee_17>

000000000010b82e <pf_jump_23>:
  10b82e:	e9 ad 1b f4 ff       	jmp    4d3e0 <pf_callee_23>
  10b833:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b83a:	00 00 00 
  10b83d:	0f 1f 00             	nopl   (%rax)

000000000010b840 <pf_call_24>:
  10b840:	0f 18 15 e9 c9 f1 ff 	prefetcht1 -0xe3617(%rip)        # 28230 <pf_callee_14>
  10b847:	41 53                	push   %r11
  10b849:	4c 8b 1d 88 d8 ff ff 	mov    -0x2778(%rip),%r11        # 1090d8 <pf_got_24_0>

000000000010b850 <pf_got_hint_24_0>:
  10b850:	41 0f 18 93 90 37 ff 	prefetcht1 -0xc870(%r11)
  10b857:	ff 
  10b858:	4c 8b 1d f9 dd ff ff 	mov    -0x2207(%rip),%r11        # 109658 <pf_got_24_1>

000000000010b85f <pf_got_hint_24_1>:
  10b85f:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b866:	00 
  10b867:	41 5b                	pop    %r11

000000000010b869 <pf_jump_24>:
  10b869:	e9 72 cf f3 ff       	jmp    487e0 <pf_callee_17>
  10b86e:	66 90                	xchg   %ax,%ax

000000000010b870 <pf_call_25>:
  10b870:	0f 18 15 19 5b f4 ff 	prefetcht1 -0xba4e7(%rip)        # 51390 <pf_target_25_0>

000000000010b877 <pf_jump_25>:
  10b877:	e9 b4 c3 f1 ff       	jmp    27c30 <pf_callee_25>
  10b87c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b880 <pf_call_26>:
  10b880:	0f 18 15 c9 ca f1 ff 	prefetcht1 -0xe3537(%rip)        # 28350 <pf_target_26_0>
  10b887:	41 53                	push   %r11
  10b889:	4c 8b 1d 18 e1 ff ff 	mov    -0x1ee8(%rip),%r11        # 1099a8 <pf_got_26_0>

000000000010b890 <pf_got_hint_26_0>:
  10b890:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b897:	00 

000000000010b898 <pf_got_hint_26_1>:
  10b898:	41 0f 18 93 a8 02 00 	prefetcht1 0x2a8(%r11)
  10b89f:	00 
  10b8a0:	41 5b                	pop    %r11

000000000010b8a2 <pf_jump_26>:
  10b8a2:	e9 a9 60 f4 ff       	jmp    51950 <pf_callee_26>
  10b8a7:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b8ae:	00 00 00 
  10b8b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b8b8:	00 00 00 
  10b8bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000010b8c0 <pf_call_27>:
  10b8c0:	0f 18 15 79 c0 f5 ff 	prefetcht1 -0xa3f87(%rip)        # 67940 <pf_target_27_0>
  10b8c7:	0f 18 15 52 c0 f5 ff 	prefetcht1 -0xa3fae(%rip)        # 67920 <pf_target_27_1>
  10b8ce:	0f 18 15 6b b5 f5 ff 	prefetcht1 -0xa4a95(%rip)        # 66e40 <pf_target_27_2>
  10b8d5:	0f 18 15 54 0a f6 ff 	prefetcht1 -0x9f5ac(%rip)        # 6c330 <pf_target_27_3>
  10b8dc:	0f 18 15 dd 57 f6 ff 	prefetcht1 -0x9a823(%rip)        # 710c0 <pf_callee_34>

000000000010b8e3 <pf_jump_27>:
  10b8e3:	e9 c8 b8 f1 ff       	jmp    271b0 <pf_callee_12>
  10b8e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b8ef:	00 

000000000010b8f0 <pf_call_28>:
  10b8f0:	0f 18 15 d9 bd f5 ff 	prefetcht1 -0xa4227(%rip)        # 676d0 <pf_target_28_0>

000000000010b8f7 <pf_jump_28>:
  10b8f7:	e9 a4 bf f1 ff       	jmp    278a0 <pf_callee_28>
  10b8fc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b900 <pf_call_29>:
  10b900:	0f 18 15 99 bf f1 ff 	prefetcht1 -0xe4067(%rip)        # 278a0 <pf_callee_28>
  10b907:	0f 18 15 9e 36 f6 ff 	prefetcht1 -0x9c962(%rip)        # 6efac <pf_target_29_1>
  10b90e:	0f 18 15 bb 00 f6 ff 	prefetcht1 -0x9ff45(%rip)        # 6b9d0 <pf_target_29_2>
  10b915:	0f 18 15 a4 ca f1 ff 	prefetcht1 -0xe355c(%rip)        # 283c0 <pf_callee_32>
  10b91c:	41 53                	push   %r11
  10b91e:	4c 8b 1d 2b db ff ff 	mov    -0x24d5(%rip),%r11        # 109450 <pf_got_29_0>

000000000010b925 <pf_got_hint_29_0>:
  10b925:	41 0f 18 93 10 00 00 	prefetcht1 0x10(%r11)
  10b92c:	00 
  10b92d:	41 5b                	pop    %r11

000000000010b92f <pf_jump_29>:
  10b92f:	e9 bc c4 f5 ff       	jmp    67df0 <pf_callee_29>
  10b934:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b93b:	00 00 00 
  10b93e:	66 90                	xchg   %ax,%ax

000000000010b940 <pf_call_30>:
  10b940:	0f 18 15 59 3e f6 ff 	prefetcht1 -0x9c1a7(%rip)        # 6f7a0 <pf_callee_31>
  10b947:	41 53                	push   %r11
  10b949:	4c 8b 1d 88 d7 ff ff 	mov    -0x2878(%rip),%r11        # 1090d8 <pf_got_24_0>

000000000010b950 <pf_got_hint_30_0>:
  10b950:	41 0f 18 93 b0 53 ff 	prefetcht1 -0xac50(%r11)
  10b957:	ff 
  10b958:	41 5b                	pop    %r11

000000000010b95a <pf_jump_30>:
  10b95a:	e9 41 bf f1 ff       	jmp    278a0 <pf_callee_28>
  10b95f:	90                   	nop

000000000010b960 <pf_call_31>:
  10b960:	0f 18 15 09 5d f4 ff 	prefetcht1 -0xba2f7(%rip)        # 51670 <pf_target_31_0>

000000000010b967 <pf_jump_31>:
  10b967:	e9 34 3e f6 ff       	jmp    6f7a0 <pf_callee_31>
  10b96c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b973:	00 00 00 
  10b976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b97d:	00 00 00 

000000000010b980 <pf_call_32>:
  10b980:	0f 18 15 49 b9 f5 ff 	prefetcht1 -0xa46b7(%rip)        # 672d0 <pf_target_32_0>
  10b987:	0f 18 15 72 06 f6 ff 	prefetcht1 -0x9f98e(%rip)        # 6c000 <pf_target_32_1>
  10b98e:	0f 18 15 5b cd f5 ff 	prefetcht1 -0xa32a5(%rip)        # 686f0 <pf_target_32_2>

000000000010b995 <pf_jump_32>:
  10b995:	e9 26 ca f1 ff       	jmp    283c0 <pf_callee_32>
  10b99a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000010b9a0 <pf_call_33>:
  10b9a0:	41 53                	push   %r11
  10b9a2:	4c 8b 1d e7 d6 ff ff 	mov    -0x2919(%rip),%r11        # 109090 <pf_got_33_0>

000000000010b9a9 <pf_got_hint_33_0>:
  10b9a9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b9b0:	00 
  10b9b1:	41 5b                	pop    %r11

000000000010b9b3 <pf_jump_33>:
  10b9b3:	e9 58 a5 f6 ff       	jmp    75f10 <pf_callee_33>
  10b9b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b9bf:	00 

000000000010b9c0 <pf_call_34>:
  10b9c0:	0f 18 15 10 36 f6 ff 	prefetcht1 -0x9c9f0(%rip)        # 6efd7 <pf_target_34_0>
  10b9c7:	0f 18 15 17 05 f6 ff 	prefetcht1 -0x9fae9(%rip)        # 6bee5 <pf_target_34_1>
  10b9ce:	0f 18 15 8b 35 f6 ff 	prefetcht1 -0x9ca75(%rip)        # 6ef60 <pf_target_34_2>
  10b9d5:	0f 18 15 3a 01 f6 ff 	prefetcht1 -0x9fec6(%rip)        # 6bb16 <pf_target_34_3>

000000000010b9dc <pf_jump_34>:
  10b9dc:	e9 df 56 f6 ff       	jmp    710c0 <pf_callee_34>
