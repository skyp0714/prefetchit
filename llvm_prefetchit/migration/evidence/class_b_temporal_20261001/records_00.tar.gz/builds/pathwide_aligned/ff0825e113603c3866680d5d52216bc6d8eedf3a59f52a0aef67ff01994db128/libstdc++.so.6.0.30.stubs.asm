
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_aligned/ff0825e113603c3866680d5d52216bc6d8eedf3a59f52a0aef67ff01994db128/call-stub-1i09_l39/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000022c300 <pf_call_0>:
  22c300:	0f 18 15 d9 e3 ea ff 	prefetcht1 -0x151c27(%rip)        # da6e0 <pf_target_0_0>
  22c307:	0f 18 15 9a a6 e9 ff 	prefetcht1 -0x165966(%rip)        # c69a8 <pf_target_0_1>
  22c30e:	0f 18 15 2d 58 ef ff 	prefetcht1 -0x10a7d3(%rip)        # 121b42 <pf_target_0_2>

000000000022c315 <pf_jump_0>:
  22c315:	e9 b6 2d e7 ff       	jmp    9f0d0 <pf_callee_0>
  22c31a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000022c320 <pf_call_1>:
  22c320:	0f 18 15 d9 54 e7 ff 	prefetcht1 -0x18ab27(%rip)        # a1800 <pf_callee_7>

000000000022c327 <pf_jump_1>:
  22c327:	e9 54 34 e7 ff       	jmp    9f780 <pf_callee_1>
  22c32c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c333:	00 00 00 
  22c336:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c33d:	00 00 00 

000000000022c340 <pf_call_2>:
  22c340:	0f 18 15 e9 e5 ea ff 	prefetcht1 -0x151a17(%rip)        # da930 <pf_target_2_0>
  22c347:	0f 18 15 22 24 e7 ff 	prefetcht1 -0x18dbde(%rip)        # 9e770 <pf_target_2_1>

000000000022c34e <pf_jump_2>:
  22c34e:	e9 5d 40 e7 ff       	jmp    a03b0 <pf_callee_2>
  22c353:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c35a:	00 00 00 
  22c35d:	0f 1f 00             	nopl   (%rax)

000000000022c360 <pf_call_3>:
  22c360:	0f 18 15 9c 86 f1 ff 	prefetcht1 -0xe7964(%rip)        # 144a03 <pf_target_3_0>

000000000022c367 <pf_jump_3>:
  22c367:	e9 a4 5e e7 ff       	jmp    a2210 <pf_callee_3>
  22c36c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c370 <pf_call_4>:
  22c370:	0f 18 15 19 0d f1 ff 	prefetcht1 -0xef2e7(%rip)        # 13d090 <pf_target_4_0>

000000000022c377 <pf_jump_4>:
  22c377:	e9 d4 21 e7 ff       	jmp    9e550 <pf_callee_4>
  22c37c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c380 <pf_call_5>:
  22c380:	0f 18 15 79 1c ef ff 	prefetcht1 -0x10e387(%rip)        # 11e000 <pf_target_5_0>

000000000022c387 <pf_jump_5>:
  22c387:	e9 04 35 e7 ff       	jmp    9f890 <pf_callee_5>
  22c38c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c390 <pf_call_6>:
  22c390:	0f 18 15 ec 37 e9 ff 	prefetcht1 -0x16c814(%rip)        # bfb83 <pf_target_6_0>

000000000022c397 <pf_jump_6>:
  22c397:	e9 a4 52 e7 ff       	jmp    a1640 <pf_callee_6>
  22c39c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c3a3:	00 00 00 
  22c3a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c3ad:	00 00 00 
  22c3b0:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c3b7:	00 00 00 
  22c3ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000022c3c0 <pf_call_7>:
  22c3c0:	0f 18 15 19 bf ef ff 	prefetcht1 -0x1040e7(%rip)        # 1282e0 <pf_target_7_0>
  22c3c7:	0f 18 15 e2 25 e7 ff 	prefetcht1 -0x18da1e(%rip)        # 9e9b0 <pf_target_7_1>
  22c3ce:	0f 18 15 3b bf ef ff 	prefetcht1 -0x1040c5(%rip)        # 128310 <pf_target_7_2>
  22c3d5:	0f 18 15 74 bf ef ff 	prefetcht1 -0x10408c(%rip)        # 128350 <pf_target_7_3>
  22c3dc:	0f 18 15 7d 20 e7 ff 	prefetcht1 -0x18df83(%rip)        # 9e460 <pf_target_7_4>
  22c3e3:	0f 18 15 c6 4d e7 ff 	prefetcht1 -0x18b23a(%rip)        # a11b0 <pf_target_7_5>

000000000022c3ea <pf_jump_7>:
  22c3ea:	e9 11 54 e7 ff       	jmp    a1800 <pf_callee_7>
  22c3ef:	90                   	nop

000000000022c3f0 <pf_call_8>:
  22c3f0:	0f 18 15 ca 0c f1 ff 	prefetcht1 -0xef336(%rip)        # 13d0c1 <pf_target_8_0>

000000000022c3f7 <pf_jump_8>:
  22c3f7:	e9 b4 32 e7 ff       	jmp    9f6b0 <pf_callee_8>
  22c3fc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c400 <pf_call_9>:
  22c400:	0f 18 15 69 66 f1 ff 	prefetcht1 -0xe9997(%rip)        # 142a70 <pf_target_9_0>
  22c407:	0f 18 15 74 66 f1 ff 	prefetcht1 -0xe998c(%rip)        # 142a82 <pf_target_9_1>

000000000022c40e <pf_jump_9>:
  22c40e:	e9 9d 32 e7 ff       	jmp    9f6b0 <pf_callee_8>
  22c413:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c41a:	00 00 00 
  22c41d:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c424:	00 00 00 
  22c427:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c42e:	00 00 00 
  22c431:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c438:	00 00 00 
  22c43b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c440 <pf_call_10>:
  22c440:	0f 18 15 bb e3 f1 ff 	prefetcht1 -0xe1c45(%rip)        # 14a802 <pf_target_10_0>
  22c447:	0f 18 15 a2 e3 f1 ff 	prefetcht1 -0xe1c5e(%rip)        # 14a7f0 <pf_target_10_1>
  22c44e:	0f 18 15 83 66 f1 ff 	prefetcht1 -0xe997d(%rip)        # 142ad8 <pf_target_10_2>
  22c455:	0f 18 15 24 64 f1 ff 	prefetcht1 -0xe9bdc(%rip)        # 142880 <pf_target_10_3>
  22c45c:	0f 18 15 5f 64 f1 ff 	prefetcht1 -0xe9ba1(%rip)        # 1428c2 <pf_target_10_4>
  22c463:	0f 18 15 86 24 f0 ff 	prefetcht1 -0xfdb7a(%rip)        # 12e8f0 <pf_callee_11>

000000000022c46a <pf_jump_10>:
  22c46a:	e9 d1 ed ef ff       	jmp    12b240 <pf_callee_10>
  22c46f:	90                   	nop

000000000022c470 <pf_call_11>:
  22c470:	0f 18 15 19 3a e7 ff 	prefetcht1 -0x18c5e7(%rip)        # 9fe90 <pf_callee_12>

000000000022c477 <pf_jump_11>:
  22c477:	e9 74 24 f0 ff       	jmp    12e8f0 <pf_callee_11>
  22c47c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c480 <pf_call_12>:
  22c480:	0f 18 15 79 05 f1 ff 	prefetcht1 -0xefa87(%rip)        # 13ca00 <pf_target_12_0>
  22c487:	0f 18 15 42 05 f1 ff 	prefetcht1 -0xefabe(%rip)        # 13c9d0 <pf_target_12_1>

000000000022c48e <pf_jump_12>:
  22c48e:	e9 fd 39 e7 ff       	jmp    9fe90 <pf_callee_12>
  22c493:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c49a:	00 00 00 
  22c49d:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c4a4:	00 00 00 
  22c4a7:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c4ae:	00 00 00 
  22c4b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c4b8:	00 00 00 
  22c4bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c4c0 <pf_call_13>:
  22c4c0:	0f 18 15 b9 5d f1 ff 	prefetcht1 -0xea247(%rip)        # 142280 <pf_target_13_0>
  22c4c7:	0f 18 15 12 02 f2 ff 	prefetcht1 -0xdfdee(%rip)        # 14c6e0 <pf_target_13_1>
  22c4ce:	0f 18 15 3b 56 e7 ff 	prefetcht1 -0x18a9c5(%rip)        # a1b10 <pf_target_13_2>
  22c4d5:	0f 18 15 24 05 f1 ff 	prefetcht1 -0xefadc(%rip)        # 13ca00 <pf_target_12_0>

000000000022c4dc <pf_jump_13>:
  22c4dc:	e9 af 39 e7 ff       	jmp    9fe90 <pf_callee_12>
  22c4e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c4e8:	00 00 00 
  22c4eb:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c4f2:	00 00 00 
  22c4f5:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c4fc:	00 00 00 
  22c4ff:	90                   	nop

000000000022c500 <pf_call_14>:
  22c500:	0f 18 15 b9 1a ef ff 	prefetcht1 -0x10e547(%rip)        # 11dfc0 <pf_target_14_0>
  22c507:	0f 18 15 92 50 e7 ff 	prefetcht1 -0x18af6e(%rip)        # a15a0 <pf_callee_15>
  22c50e:	0f 18 15 0b 5e e9 ff 	prefetcht1 -0x16a1f5(%rip)        # c2320 <pf_target_14_2>
  22c515:	0f 18 15 74 5e e9 ff 	prefetcht1 -0x16a18c(%rip)        # c2390 <pf_target_14_3>
  22c51c:	0f 18 15 df e1 ea ff 	prefetcht1 -0x151e21(%rip)        # da702 <pf_target_14_4>
  22c523:	0f 18 15 b6 e1 ea ff 	prefetcht1 -0x151e4a(%rip)        # da6e0 <pf_target_0_0>
  22c52a:	0f 18 15 ff 30 e7 ff 	prefetcht1 -0x18cf01(%rip)        # 9f630 <pf_target_14_6>
  22c531:	0f 18 15 28 36 e9 ff 	prefetcht1 -0x16c9d8(%rip)        # bfb60 <pf_target_14_7>

000000000022c538 <pf_jump_14>:
  22c538:	e9 73 2c e7 ff       	jmp    9f1b0 <pf_callee_14>
  22c53d:	0f 1f 00             	nopl   (%rax)

000000000022c540 <pf_call_15>:
  22c540:	0f 18 15 99 44 e9 ff 	prefetcht1 -0x16bb67(%rip)        # c09e0 <pf_target_15_0>
  22c547:	0f 18 15 02 20 e7 ff 	prefetcht1 -0x18dffe(%rip)        # 9e550 <pf_callee_4>
  22c54e:	0f 18 15 ab 44 e9 ff 	prefetcht1 -0x16bb55(%rip)        # c0a00 <pf_target_15_2>
  22c555:	0f 18 15 24 43 e7 ff 	prefetcht1 -0x18bcdc(%rip)        # a0880 <pf_target_15_3>
  22c55c:	0f 18 15 bd e0 ef ff 	prefetcht1 -0x101f43(%rip)        # 12a620 <pf_target_15_4>
  22c563:	0f 18 15 e6 47 e7 ff 	prefetcht1 -0x18b81a(%rip)        # a0d50 <pf_target_15_5>
  22c56a:	0f 18 15 cf 18 ef ff 	prefetcht1 -0x10e731(%rip)        # 11de40 <pf_target_15_6>
  22c571:	0f 18 15 48 fd ef ff 	prefetcht1 -0x1002b8(%rip)        # 12c2c0 <pf_target_15_7>

000000000022c578 <pf_jump_15>:
  22c578:	e9 23 50 e7 ff       	jmp    a15a0 <pf_callee_15>
  22c57d:	0f 1f 00             	nopl   (%rax)

000000000022c580 <pf_call_16>:
  22c580:	0f 18 15 09 60 f1 ff 	prefetcht1 -0xe9ff7(%rip)        # 142590 <pf_target_16_0>
  22c587:	0f 18 15 34 60 f1 ff 	prefetcht1 -0xe9fcc(%rip)        # 1425c2 <pf_target_16_1>

000000000022c58e <pf_jump_16>:
  22c58e:	e9 4d 41 e7 ff       	jmp    a06e0 <pf_callee_16>
  22c593:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c59a:	00 00 00 
  22c59d:	0f 1f 00             	nopl   (%rax)

000000000022c5a0 <pf_call_17>:
  22c5a0:	0f 18 15 69 f6 f1 ff 	prefetcht1 -0xe0997(%rip)        # 14bc10 <pf_target_17_0>

000000000022c5a7 <pf_jump_17>:
  22c5a7:	e9 34 41 e7 ff       	jmp    a06e0 <pf_callee_16>
  22c5ac:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c5b0 <pf_call_18>:
  22c5b0:	0f 18 15 69 55 ef ff 	prefetcht1 -0x10aa97(%rip)        # 121b20 <pf_target_18_0>

000000000022c5b7 <pf_jump_18>:
  22c5b7:	e9 34 5b e7 ff       	jmp    a20f0 <pf_callee_18>
  22c5bc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c5c0 <pf_call_19>:
  22c5c0:	41 53                	push   %r11
  22c5c2:	4c 8b 1d 57 b3 ff ff 	mov    -0x4ca9(%rip),%r11        # 227920 <pf_got_19_0>

000000000022c5c9 <pf_got_hint_19_0>:
  22c5c9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  22c5d0:	00 
  22c5d1:	41 5b                	pop    %r11

000000000022c5d3 <pf_jump_19>:
  22c5d3:	e9 f8 44 e7 ff       	jmp    a0ad0 <pf_callee_19>
  22c5d8:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c5df:	00 00 00 
  22c5e2:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c5e9:	00 00 00 
  22c5ec:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c5f3:	00 00 00 
  22c5f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c5fd:	00 00 00 

000000000022c600 <pf_call_20>:
  22c600:	0f 18 15 d9 40 e7 ff 	prefetcht1 -0x18bf27(%rip)        # a06e0 <pf_callee_16>
  22c607:	0f 18 15 42 fa f1 ff 	prefetcht1 -0xe05be(%rip)        # 14c050 <pf_target_20_1>
  22c60e:	0f 18 15 6f fa f1 ff 	prefetcht1 -0xe0591(%rip)        # 14c084 <pf_target_20_2>
  22c615:	0f 18 15 54 23 e8 ff 	prefetcht1 -0x17dcac(%rip)        # ae970 <pf_target_20_3>
  22c61c:	0f 18 15 ed f5 f1 ff 	prefetcht1 -0xe0a13(%rip)        # 14bc10 <pf_target_17_0>
  22c623:	0f 18 15 76 25 e7 ff 	prefetcht1 -0x18da8a(%rip)        # 9eba0 <pf_target_20_5>

000000000022c62a <pf_jump_20>:
  22c62a:	e9 a1 59 e7 ff       	jmp    a1fd0 <pf_callee_20>
  22c62f:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c636:	00 00 00 
  22c639:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000022c640 <pf_call_21>:
  22c640:	41 53                	push   %r11
  22c642:	4c 8b 1d 2f a6 ff ff 	mov    -0x59d1(%rip),%r11        # 226c78 <pf_got_21_0>

000000000022c649 <pf_got_hint_21_0>:
  22c649:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  22c650:	00 
  22c651:	41 5b                	pop    %r11

000000000022c653 <pf_jump_21>:
  22c653:	e9 58 35 e7 ff       	jmp    9fbb0 <pf_callee_21>
