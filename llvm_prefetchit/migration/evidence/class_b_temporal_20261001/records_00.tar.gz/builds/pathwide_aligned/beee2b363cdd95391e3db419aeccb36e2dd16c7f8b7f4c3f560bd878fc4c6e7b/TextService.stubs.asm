
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_aligned/beee2b363cdd95391e3db419aeccb36e2dd16c7f8b7f4c3f560bd878fc4c6e7b/call-stub-0cp7ts02/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000110340 <pf_call_0>:
  110340:	0f 18 15 e9 88 f3 ff 	prefetcht1 -0xc7717(%rip)        # 48c30 <pf_target_0_0>
  110347:	0f 18 15 62 31 f3 ff 	prefetcht1 -0xcce9e(%rip)        # 434b0 <pf_target_0_1>
  11034e:	0f 18 15 af 31 f3 ff 	prefetcht1 -0xcce51(%rip)        # 43504 <pf_target_0_2>
  110355:	0f 18 15 c4 3b f3 ff 	prefetcht1 -0xcc43c(%rip)        # 43f20 <pf_target_0_3>
  11035c:	0f 18 15 a1 3c f3 ff 	prefetcht1 -0xcc35f(%rip)        # 44004 <pf_target_0_4>
  110363:	0f 18 15 d8 88 f3 ff 	prefetcht1 -0xc7728(%rip)        # 48c42 <pf_target_0_5>
  11036a:	0f 18 15 11 89 f3 ff 	prefetcht1 -0xc76ef(%rip)        # 48c82 <pf_target_0_6>
  110371:	0f 18 15 4a 32 f3 ff 	prefetcht1 -0xccdb6(%rip)        # 435c2 <pf_target_0_7>

0000000000110378 <pf_jump_0>:
  110378:	e9 a3 5f f1 ff       	jmp    26320 <pf_callee_0>
  11037d:	0f 1f 00             	nopl   (%rax)

0000000000110380 <pf_call_1>:
  110380:	0f 18 15 19 06 f2 ff 	prefetcht1 -0xdf9e7(%rip)        # 309a0 <pf_target_1_0>
  110387:	41 53                	push   %r11
  110389:	4c 8b 1d 50 dd ff ff 	mov    -0x22b0(%rip),%r11        # 10e0e0 <pf_got_1_0>

0000000000110390 <pf_got_hint_1_0>:
  110390:	41 0f 18 93 b0 06 00 	prefetcht1 0x6b0(%r11)
  110397:	00 

0000000000110398 <pf_got_hint_1_1>:
  110398:	41 0f 18 93 d2 06 00 	prefetcht1 0x6d2(%r11)
  11039f:	00 
  1103a0:	4c 8b 1d f1 e0 ff ff 	mov    -0x1f0f(%rip),%r11        # 10e498 <pf_got_17_0>

00000000001103a7 <pf_got_hint_1_2>:
  1103a7:	41 0f 18 93 10 5d fe 	prefetcht1 -0x1a2f0(%r11)
  1103ae:	ff 
  1103af:	41 5b                	pop    %r11

00000000001103b1 <pf_jump_1>:
  1103b1:	e9 6a 5f f1 ff       	jmp    26320 <pf_callee_0>
  1103b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1103bd:	00 00 00 

00000000001103c0 <pf_call_2>:
  1103c0:	41 53                	push   %r11
  1103c2:	4c 8b 1d cf e0 ff ff 	mov    -0x1f31(%rip),%r11        # 10e498 <pf_got_17_0>

00000000001103c9 <pf_got_hint_2_0>:
  1103c9:	41 0f 18 93 50 79 00 	prefetcht1 0x7950(%r11)
  1103d0:	00 
  1103d1:	4c 8b 1d 70 e3 ff ff 	mov    -0x1c90(%rip),%r11        # 10e748 <pf_got_2_1>

00000000001103d8 <pf_got_hint_2_1>:
  1103d8:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1103df:	00 

00000000001103e0 <pf_got_hint_2_2>:
  1103e0:	41 0f 18 93 34 00 00 	prefetcht1 0x34(%r11)
  1103e7:	00 
  1103e8:	41 5b                	pop    %r11

00000000001103ea <pf_jump_2>:
  1103ea:	e9 31 5f f1 ff       	jmp    26320 <pf_callee_0>
  1103ef:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1103f6:	00 00 00 
  1103f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000110400 <pf_call_3>:
  110400:	0f 18 15 f9 8b f5 ff 	prefetcht1 -0xa7407(%rip)        # 69000 <pf_target_3_0>
  110407:	0f 18 15 c2 bd f4 ff 	prefetcht1 -0xb423e(%rip)        # 5c1d0 <pf_target_3_1>

000000000011040e <pf_jump_3>:
  11040e:	e9 bd 06 f2 ff       	jmp    30ad0 <pf_callee_3>
  110413:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11041a:	00 00 00 
  11041d:	0f 1f 00             	nopl   (%rax)

0000000000110420 <pf_call_4>:
  110420:	41 53                	push   %r11
  110422:	4c 8b 1d 6f e0 ff ff 	mov    -0x1f91(%rip),%r11        # 10e498 <pf_got_17_0>

0000000000110429 <pf_got_hint_4_0>:
  110429:	41 0f 18 93 c1 af ff 	prefetcht1 -0x503f(%r11)
  110430:	ff 
  110431:	41 5b                	pop    %r11

0000000000110433 <pf_jump_4>:
  110433:	e9 48 6a f1 ff       	jmp    26e80 <pf_callee_4>
  110438:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11043f:	00 

0000000000110440 <pf_call_5>:
  110440:	0f 18 15 1f 95 f3 ff 	prefetcht1 -0xc6ae1(%rip)        # 49966 <pf_target_5_0>
  110447:	41 53                	push   %r11
  110449:	4c 8b 1d 48 e0 ff ff 	mov    -0x1fb8(%rip),%r11        # 10e498 <pf_got_17_0>

0000000000110450 <pf_got_hint_5_0>:
  110450:	41 0f 18 93 30 f5 ff 	prefetcht1 -0xad0(%r11)
  110457:	ff 

0000000000110458 <pf_got_hint_5_1>:
  110458:	41 0f 18 93 41 f5 ff 	prefetcht1 -0xabf(%r11)
  11045f:	ff 
  110460:	41 5b                	pop    %r11

0000000000110462 <pf_jump_5>:
  110462:	e9 49 94 f3 ff       	jmp    498b0 <pf_callee_5>
  110467:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11046e:	00 00 00 
  110471:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  110478:	00 00 00 
  11047b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000110480 <pf_call_6>:
  110480:	0f 18 15 d9 bd f4 ff 	prefetcht1 -0xb4227(%rip)        # 5c260 <pf_target_6_0>
  110487:	41 53                	push   %r11
  110489:	4c 8b 1d 98 df ff ff 	mov    -0x2068(%rip),%r11        # 10e428 <pf_got_6_0>

0000000000110490 <pf_got_hint_6_0>:
  110490:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110497:	00 
  110498:	41 5b                	pop    %r11

000000000011049a <pf_jump_6>:
  11049a:	e9 71 5e f1 ff       	jmp    26310 <pf_callee_6>
  11049f:	90                   	nop

00000000001104a0 <pf_call_7>:
  1104a0:	0f 18 15 59 31 f3 ff 	prefetcht1 -0xccea7(%rip)        # 43600 <pf_target_7_0>

00000000001104a7 <pf_jump_7>:
  1104a7:	e9 14 5d f1 ff       	jmp    261c0 <pf_callee_7>
  1104ac:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1104b3:	00 00 00 
  1104b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1104bd:	00 00 00 

00000000001104c0 <pf_call_8>:
  1104c0:	41 53                	push   %r11
  1104c2:	4c 8b 1d cf df ff ff 	mov    -0x2031(%rip),%r11        # 10e498 <pf_got_17_0>

00000000001104c9 <pf_got_hint_8_0>:
  1104c9:	41 0f 18 93 20 6f fe 	prefetcht1 -0x190e0(%r11)
  1104d0:	ff 
  1104d1:	41 5b                	pop    %r11

00000000001104d3 <pf_jump_8>:
  1104d3:	e9 78 37 f3 ff       	jmp    43c50 <pf_callee_8>
  1104d8:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1104df:	00 00 00 
  1104e2:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1104e9:	00 00 00 
  1104ec:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1104f3:	00 00 00 
  1104f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1104fd:	00 00 00 

0000000000110500 <pf_call_9>:
  110500:	41 53                	push   %r11
  110502:	4c 8b 1d 6f de ff ff 	mov    -0x2191(%rip),%r11        # 10e378 <pf_got_9_0>

0000000000110509 <pf_got_hint_9_0>:
  110509:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110510:	00 
  110511:	4c 8b 1d 78 e2 ff ff 	mov    -0x1d88(%rip),%r11        # 10e790 <pf_got_17_3>

0000000000110518 <pf_got_hint_9_1>:
  110518:	41 0f 18 93 70 e8 fe 	prefetcht1 -0x11790(%r11)
  11051f:	ff 

0000000000110520 <pf_got_hint_9_2>:
  110520:	41 0f 18 93 20 26 ff 	prefetcht1 -0xd9e0(%r11)
  110527:	ff 

0000000000110528 <pf_got_hint_9_3>:
  110528:	41 0f 18 93 31 26 ff 	prefetcht1 -0xd9cf(%r11)
  11052f:	ff 

0000000000110530 <pf_got_hint_9_4>:
  110530:	41 0f 18 93 10 29 ff 	prefetcht1 -0xd6f0(%r11)
  110537:	ff 

0000000000110538 <pf_got_hint_9_5>:
  110538:	41 0f 18 93 a0 f5 ff 	prefetcht1 -0xa60(%r11)
  11053f:	ff 

0000000000110540 <pf_got_hint_9_6>:
  110540:	41 0f 18 93 b0 f5 ff 	prefetcht1 -0xa50(%r11)
  110547:	ff 
  110548:	41 5b                	pop    %r11

000000000011054a <pf_jump_9>:
  11054a:	e9 81 51 f3 ff       	jmp    456d0 <pf_callee_9>
  11054f:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  110556:	00 00 00 
  110559:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  110560:	00 00 00 
  110563:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11056a:	00 00 00 
  11056d:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  110574:	00 00 00 
  110577:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  11057e:	00 00 

0000000000110580 <pf_call_10>:
  110580:	0f 18 15 a9 60 f1 ff 	prefetcht1 -0xe9f57(%rip)        # 26630 <pf_target_10_0>
  110587:	41 53                	push   %r11
  110589:	4c 8b 1d 88 dd ff ff 	mov    -0x2278(%rip),%r11        # 10e318 <pf_got_10_0>

0000000000110590 <pf_got_hint_10_0>:
  110590:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110597:	00 

0000000000110598 <pf_got_hint_10_1>:
  110598:	41 0f 18 93 11 00 00 	prefetcht1 0x11(%r11)
  11059f:	00 
  1105a0:	41 5b                	pop    %r11

00000000001105a2 <pf_jump_10>:
  1105a2:	e9 39 64 f1 ff       	jmp    269e0 <pf_callee_10>
  1105a7:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1105ae:	00 00 00 
  1105b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1105b8:	00 00 00 
  1105bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000001105c0 <pf_call_11>:
  1105c0:	41 53                	push   %r11
  1105c2:	4c 8b 1d d7 da ff ff 	mov    -0x2529(%rip),%r11        # 10e0a0 <pf_got_11_0>

00000000001105c9 <pf_got_hint_11_0>:
  1105c9:	41 0f 18 93 20 4a ff 	prefetcht1 -0xb5e0(%r11)
  1105d0:	ff 
  1105d1:	41 5b                	pop    %r11

00000000001105d3 <pf_jump_11>:
  1105d3:	e9 18 5b f1 ff       	jmp    260f0 <pf_callee_11>
  1105d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1105df:	00 

00000000001105e0 <pf_call_12>:
  1105e0:	0f 18 15 29 35 f3 ff 	prefetcht1 -0xccad7(%rip)        # 43b10 <pf_target_12_0>

00000000001105e7 <pf_jump_12>:
  1105e7:	e9 04 5b f1 ff       	jmp    260f0 <pf_callee_11>
  1105ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001105f0 <pf_call_13>:
  1105f0:	0f 18 15 89 93 f3 ff 	prefetcht1 -0xc6c77(%rip)        # 49980 <pf_callee_23>

00000000001105f7 <pf_jump_13>:
  1105f7:	e9 54 fd f2 ff       	jmp    40350 <pf_callee_13>
  1105fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110600 <pf_call_14>:
  110600:	0f 18 15 89 35 f3 ff 	prefetcht1 -0xcca77(%rip)        # 43b90 <pf_target_14_0>

0000000000110607 <pf_jump_14>:
  110607:	e9 c4 39 f3 ff       	jmp    43fd0 <pf_callee_14>
  11060c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110610 <pf_call_15>:
  110610:	0f 18 15 99 4e f3 ff 	prefetcht1 -0xcb167(%rip)        # 454b0 <pf_target_15_0>

0000000000110617 <pf_jump_15>:
  110617:	e9 24 5b f1 ff       	jmp    26140 <pf_callee_15>
  11061c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110620 <pf_call_16>:
  110620:	0f 18 15 c9 67 f1 ff 	prefetcht1 -0xe9837(%rip)        # 26df0 <pf_target_16_0>
  110627:	41 53                	push   %r11
  110629:	4c 8b 1d c8 e0 ff ff 	mov    -0x1f38(%rip),%r11        # 10e6f8 <pf_got_16_0>

0000000000110630 <pf_got_hint_16_0>:
  110630:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110637:	00 
  110638:	41 5b                	pop    %r11

000000000011063a <pf_jump_16>:
  11063a:	e9 01 5b f1 ff       	jmp    26140 <pf_callee_15>
  11063f:	90                   	nop

0000000000110640 <pf_call_17>:
  110640:	41 53                	push   %r11
  110642:	4c 8b 1d 4f de ff ff 	mov    -0x21b1(%rip),%r11        # 10e498 <pf_got_17_0>

0000000000110649 <pf_got_hint_17_0>:
  110649:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110650:	00 

0000000000110651 <pf_got_hint_17_1>:
  110651:	41 0f 18 93 44 00 00 	prefetcht1 0x44(%r11)
  110658:	00 

0000000000110659 <pf_got_hint_17_2>:
  110659:	41 0f 18 93 88 00 00 	prefetcht1 0x88(%r11)
  110660:	00 
  110661:	4c 8b 1d 28 e1 ff ff 	mov    -0x1ed8(%rip),%r11        # 10e790 <pf_got_17_3>

0000000000110668 <pf_got_hint_17_3>:
  110668:	41 0f 18 93 b0 3e fe 	prefetcht1 -0x1c150(%r11)
  11066f:	ff 

0000000000110670 <pf_got_hint_17_4>:
  110670:	41 0f 18 93 40 46 fe 	prefetcht1 -0x1b9c0(%r11)
  110677:	ff 

0000000000110678 <pf_got_hint_17_5>:
  110678:	41 0f 18 93 70 46 fe 	prefetcht1 -0x1b990(%r11)
  11067f:	ff 
  110680:	41 5b                	pop    %r11

0000000000110682 <pf_jump_17>:
  110682:	e9 a9 62 f1 ff       	jmp    26930 <pf_callee_17>
  110687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  11068e:	00 00 

0000000000110690 <pf_call_18>:
  110690:	0f 18 15 b9 fc f2 ff 	prefetcht1 -0xd0347(%rip)        # 40350 <pf_callee_13>

0000000000110697 <pf_jump_18>:
  110697:	e9 b4 48 f3 ff       	jmp    44f50 <pf_callee_18>
  11069c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001106a0 <pf_call_19>:
  1106a0:	0f 18 15 79 43 f3 ff 	prefetcht1 -0xcbc87(%rip)        # 44a20 <pf_target_19_0>

00000000001106a7 <pf_jump_19>:
  1106a7:	e9 a4 fc f2 ff       	jmp    40350 <pf_callee_13>
  1106ac:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1106b3:	00 00 00 
  1106b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1106bd:	00 00 00 

00000000001106c0 <pf_call_20>:
  1106c0:	0f 18 15 89 68 f1 ff 	prefetcht1 -0xe9777(%rip)        # 26f50 <pf_target_20_0>
  1106c7:	41 53                	push   %r11
  1106c9:	4c 8b 1d 60 de ff ff 	mov    -0x21a0(%rip),%r11        # 10e530 <pf_got_20_0>

00000000001106d0 <pf_got_hint_20_0>:
  1106d0:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1106d7:	00 
  1106d8:	41 5b                	pop    %r11

00000000001106da <pf_jump_20>:
  1106da:	e9 71 fc f2 ff       	jmp    40350 <pf_callee_13>
  1106df:	90                   	nop

00000000001106e0 <pf_call_21>:
  1106e0:	0f 18 15 39 69 f1 ff 	prefetcht1 -0xe96c7(%rip)        # 27020 <pf_target_21_0>
  1106e7:	41 53                	push   %r11
  1106e9:	4c 8b 1d 20 e1 ff ff 	mov    -0x1ee0(%rip),%r11        # 10e810 <pf_got_21_0>

00000000001106f0 <pf_got_hint_21_0>:
  1106f0:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1106f7:	00 
  1106f8:	41 5b                	pop    %r11

00000000001106fa <pf_jump_21>:
  1106fa:	e9 61 8e f3 ff       	jmp    49560 <pf_callee_21>
  1106ff:	90                   	nop

0000000000110700 <pf_call_22>:
  110700:	0f 18 15 8e 15 f5 ff 	prefetcht1 -0xaea72(%rip)        # 61c95 <pf_target_22_0>
  110707:	0f 18 15 e9 32 f5 ff 	prefetcht1 -0xacd17(%rip)        # 639f7 <pf_target_22_1>
  11070e:	0f 18 15 ab c8 f4 ff 	prefetcht1 -0xb3755(%rip)        # 5cfc0 <pf_target_22_2>
  110715:	0f 18 15 c4 bd f4 ff 	prefetcht1 -0xb423c(%rip)        # 5c4e0 <pf_target_22_3>
  11071c:	0f 18 15 a3 11 f5 ff 	prefetcht1 -0xaee5d(%rip)        # 618c6 <pf_target_22_4>

0000000000110723 <pf_jump_22>:
  110723:	e9 18 5a f1 ff       	jmp    26140 <pf_callee_15>
  110728:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11072f:	00 

0000000000110730 <pf_call_23>:
  110730:	0f 18 15 26 19 f5 ff 	prefetcht1 -0xae6da(%rip)        # 6205d <pf_target_23_0>

0000000000110737 <pf_jump_23>:
  110737:	e9 44 92 f3 ff       	jmp    49980 <pf_callee_23>
  11073c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110740 <pf_call_24>:
  110740:	0f 18 15 29 c6 f4 ff 	prefetcht1 -0xb39d7(%rip)        # 5cd70 <pf_target_24_0>

0000000000110747 <pf_jump_24>:
  110747:	e9 94 5f f1 ff       	jmp    266e0 <pf_callee_24>
  11074c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  110753:	00 00 00 
  110756:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11075d:	00 00 00 
  110760:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  110767:	00 00 00 
  11076a:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  110771:	00 00 00 
  110774:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11077b:	00 00 00 
  11077e:	66 90                	xchg   %ax,%ax

0000000000110780 <pf_call_25>:
  110780:	0f 18 15 39 3a f5 ff 	prefetcht1 -0xac5c7(%rip)        # 641c0 <pf_callee_28>
  110787:	41 53                	push   %r11
  110789:	4c 8b 1d 10 d9 ff ff 	mov    -0x26f0(%rip),%r11        # 10e0a0 <pf_got_11_0>

0000000000110790 <pf_got_hint_25_0>:
  110790:	41 0f 18 93 b0 53 ff 	prefetcht1 -0xac50(%r11)
  110797:	ff 
  110798:	4c 8b 1d 41 d9 ff ff 	mov    -0x26bf(%rip),%r11        # 10e0e0 <pf_got_1_0>

000000000011079f <pf_got_hint_25_1>:
  11079f:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1107a6:	00 
  1107a7:	4c 8b 1d 42 dd ff ff 	mov    -0x22be(%rip),%r11        # 10e4f0 <pf_got_25_2>

00000000001107ae <pf_got_hint_25_2>:
  1107ae:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1107b5:	00 
  1107b6:	41 5b                	pop    %r11

00000000001107b8 <pf_jump_25>:
  1107b8:	e9 d3 cc f4 ff       	jmp    5d490 <pf_callee_25>
  1107bd:	0f 1f 00             	nopl   (%rax)

00000000001107c0 <pf_call_26>:
  1107c0:	0f 18 15 19 5f f1 ff 	prefetcht1 -0xea0e7(%rip)        # 266e0 <pf_callee_24>
  1107c7:	0f 18 15 c2 68 f1 ff 	prefetcht1 -0xe973e(%rip)        # 27090 <pf_callee_29>
  1107ce:	0f 18 15 ab 0f f5 ff 	prefetcht1 -0xaf055(%rip)        # 61780 <pf_target_26_2>
  1107d5:	0f 18 15 f0 31 f5 ff 	prefetcht1 -0xace10(%rip)        # 639cc <pf_target_26_3>
  1107dc:	0f 18 15 ed 65 f1 ff 	prefetcht1 -0xe9a13(%rip)        # 26dd0 <pf_callee_31>
  1107e3:	0f 18 15 e5 8a f5 ff 	prefetcht1 -0xa751b(%rip)        # 692cf <pf_target_26_5>
  1107ea:	41 53                	push   %r11
  1107ec:	4c 8b 1d 7d db ff ff 	mov    -0x2483(%rip),%r11        # 10e370 <pf_got_26_0>

00000000001107f3 <pf_got_hint_26_0>:
  1107f3:	41 0f 18 93 10 00 00 	prefetcht1 0x10(%r11)
  1107fa:	00 

00000000001107fb <pf_got_hint_26_1>:
  1107fb:	41 0f 18 93 d8 01 00 	prefetcht1 0x1d8(%r11)
  110802:	00 
  110803:	41 5b                	pop    %r11

0000000000110805 <pf_jump_26>:
  110805:	e9 86 cc f4 ff       	jmp    5d490 <pf_callee_25>
  11080a:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  110811:	00 00 00 
  110814:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11081b:	00 00 00 
  11081e:	66 90                	xchg   %ax,%ax

0000000000110820 <pf_call_27>:
  110820:	41 53                	push   %r11
  110822:	4c 8b 1d bf de ff ff 	mov    -0x2141(%rip),%r11        # 10e6e8 <pf_got_27_0>

0000000000110829 <pf_got_hint_27_0>:
  110829:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110830:	00 
  110831:	41 5b                	pop    %r11

0000000000110833 <pf_jump_27>:
  110833:	e9 a8 5e f1 ff       	jmp    266e0 <pf_callee_24>
  110838:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11083f:	00 

0000000000110840 <pf_call_28>:
  110840:	0f 18 15 39 8a f3 ff 	prefetcht1 -0xc75c7(%rip)        # 49280 <pf_target_28_0>
  110847:	0f 18 15 2b 8e f3 ff 	prefetcht1 -0xc71d5(%rip)        # 49679 <pf_target_28_1>
  11084e:	0f 18 15 2c 8e f3 ff 	prefetcht1 -0xc71d4(%rip)        # 49681 <pf_target_28_2>

0000000000110855 <pf_jump_28>:
  110855:	e9 66 39 f5 ff       	jmp    641c0 <pf_callee_28>
  11085a:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  110861:	00 00 00 
  110864:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11086b:	00 00 00 
  11086e:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  110875:	00 00 00 
  110878:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11087f:	00 

0000000000110880 <pf_call_29>:
  110880:	0f 18 15 29 15 f5 ff 	prefetcht1 -0xaead7(%rip)        # 61db0 <pf_target_29_0>
  110887:	0f 18 15 02 f9 f4 ff 	prefetcht1 -0xb06fe(%rip)        # 60190 <pf_target_29_1>
  11088e:	0f 18 15 db c0 f4 ff 	prefetcht1 -0xb3f25(%rip)        # 5c970 <pf_target_29_2>
  110895:	0f 18 15 25 15 f5 ff 	prefetcht1 -0xaeadb(%rip)        # 61dc1 <pf_target_29_3>

000000000011089c <pf_jump_29>:
  11089c:	e9 ef 67 f1 ff       	jmp    27090 <pf_callee_29>
  1108a1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1108a8:	00 00 00 
  1108ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000001108b0 <pf_call_30>:
  1108b0:	0f 18 15 c9 30 f5 ff 	prefetcht1 -0xacf37(%rip)        # 63980 <pf_target_30_0>

00000000001108b7 <pf_jump_30>:
  1108b7:	e9 84 58 f1 ff       	jmp    26140 <pf_callee_15>
  1108bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001108c0 <pf_call_31>:
  1108c0:	0f 18 15 29 4b f5 ff 	prefetcht1 -0xab4d7(%rip)        # 653f0 <pf_target_31_0>
  1108c7:	41 53                	push   %r11
  1108c9:	4c 8b 1d d0 d7 ff ff 	mov    -0x2830(%rip),%r11        # 10e0a0 <pf_got_11_0>

00000000001108d0 <pf_got_hint_31_0>:
  1108d0:	41 0f 18 93 e0 48 ff 	prefetcht1 -0xb720(%r11)
  1108d7:	ff 
  1108d8:	4c 8b 1d 09 de ff ff 	mov    -0x21f7(%rip),%r11        # 10e6e8 <pf_got_27_0>

00000000001108df <pf_got_hint_31_1>:
  1108df:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1108e6:	00 
  1108e7:	41 5b                	pop    %r11

00000000001108e9 <pf_jump_31>:
  1108e9:	e9 e2 64 f1 ff       	jmp    26dd0 <pf_callee_31>
  1108ee:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1108f5:	00 00 00 
  1108f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1108ff:	00 

0000000000110900 <pf_call_32>:
  110900:	0f 18 15 da d9 f1 ff 	prefetcht1 -0xe2626(%rip)        # 2e2e1 <pf_target_32_0>
  110907:	0f 18 15 36 0d f2 ff 	prefetcht1 -0xdf2ca(%rip)        # 31644 <pf_target_32_1>
  11090e:	41 53                	push   %r11
  110910:	4c 8b 1d 51 d7 ff ff 	mov    -0x28af(%rip),%r11        # 10e068 <pf_got_32_0>

0000000000110917 <pf_got_hint_32_0>:
  110917:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  11091e:	00 
  11091f:	41 5b                	pop    %r11

0000000000110921 <pf_jump_32>:
  110921:	e9 da 82 f6 ff       	jmp    78c00 <pf_callee_32>
