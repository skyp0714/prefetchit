
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_aligned/7277229c6489da6761bfa3456517c6cf25e006a732d2a0dab69141658d47f872/call-stub-t06tnv49/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000422c0 <pf_call_0>:
   422c0:	0f 18 15 3a 04 fd ff 	prefetcht1 -0x2fbc6(%rip)        # 12701 <pf_target_0_0>

00000000000422c7 <pf_jump_0>:
   422c7:	e9 a4 af fc ff       	jmp    d270 <pf_callee_0>
   422cc:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   422d3:	00 00 00 
   422d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   422dd:	00 00 00 
   422e0:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   422e7:	00 00 00 
   422ea:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   422f1:	00 00 00 
   422f4:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   422fb:	00 00 00 
   422fe:	66 90                	xchg   %ax,%ax

0000000000042300 <pf_call_1>:
   42300:	0f 18 15 99 b9 fc ff 	prefetcht1 -0x34667(%rip)        # dca0 <pf_target_1_0>
   42307:	0f 18 15 33 10 fd ff 	prefetcht1 -0x2efcd(%rip)        # 13341 <pf_target_13_6>
   4230e:	0f 18 15 fb 0f fd ff 	prefetcht1 -0x2f005(%rip)        # 13310 <pf_target_13_2>
   42315:	0f 18 15 d4 0e fd ff 	prefetcht1 -0x2f12c(%rip)        # 131f0 <pf_target_1_3>
   4231c:	0f 18 15 e2 0e fd ff 	prefetcht1 -0x2f11e(%rip)        # 13205 <pf_target_1_4>

0000000000042323 <pf_jump_1>:
   42323:	e9 08 b4 fc ff       	jmp    d730 <pf_callee_1>
   42328:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   4232f:	00 

0000000000042330 <pf_call_2>:
   42330:	0f 18 15 09 cd fc ff 	prefetcht1 -0x332f7(%rip)        # f040 <pf_target_2_0>

0000000000042337 <pf_jump_2>:
   42337:	e9 74 ad fc ff       	jmp    d0b0 <pf_callee_2>
   4233c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042340 <pf_call_3>:
   42340:	0f 18 15 bd dd fc ff 	prefetcht1 -0x32243(%rip)        # 10104 <pf_target_3_0>

0000000000042347 <pf_jump_3>:
   42347:	e9 c4 ad fc ff       	jmp    d110 <pf_callee_3>
   4234c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   42353:	00 00 00 
   42356:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4235d:	00 00 00 

0000000000042360 <pf_call_4>:
   42360:	0f 18 15 a9 c1 fc ff 	prefetcht1 -0x33e57(%rip)        # e510 <pf_target_4_0>
   42367:	0f 18 15 d4 c1 fc ff 	prefetcht1 -0x33e2c(%rip)        # e542 <pf_target_4_1>

000000000004236e <pf_jump_4>:
   4236e:	e9 6d b1 fc ff       	jmp    d4e0 <pf_callee_4>
   42373:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4237a:	00 00 00 
   4237d:	0f 1f 00             	nopl   (%rax)

0000000000042380 <pf_call_5>:
   42380:	0f 18 15 99 00 fd ff 	prefetcht1 -0x2ff67(%rip)        # 12420 <pf_target_5_0>
   42387:	0f 18 15 b2 00 fd ff 	prefetcht1 -0x2ff4e(%rip)        # 12440 <pf_target_5_1>
   4238e:	0f 18 15 0b 02 fd ff 	prefetcht1 -0x2fdf5(%rip)        # 125a0 <pf_target_5_2>
   42395:	0f 18 15 fc c5 fc ff 	prefetcht1 -0x33a04(%rip)        # e998 <pf_target_5_3>

000000000004239c <pf_jump_5>:
   4239c:	e9 cf ab fc ff       	jmp    cf70 <pf_callee_5>
   423a1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   423a8:	00 00 00 
   423ab:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   423b2:	00 00 00 
   423b5:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   423bc:	00 00 00 
   423bf:	90                   	nop

00000000000423c0 <pf_call_6>:
   423c0:	0f 18 15 39 06 fd ff 	prefetcht1 -0x2f9c7(%rip)        # 12a00 <pf_target_6_0>
   423c7:	0f 18 15 73 06 fd ff 	prefetcht1 -0x2f98d(%rip)        # 12a41 <pf_target_6_1>
   423ce:	0f 18 15 4b a7 fc ff 	prefetcht1 -0x358b5(%rip)        # cb20 <pf_target_21_2>

00000000000423d5 <pf_jump_6>:
   423d5:	e9 a6 ad fc ff       	jmp    d180 <pf_callee_10>
   423da:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   423e1:	00 00 00 
   423e4:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   423eb:	00 00 00 
   423ee:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   423f5:	00 00 00 
   423f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   423ff:	00 

0000000000042400 <pf_call_7>:
   42400:	0f 18 15 27 9e fd ff 	prefetcht1 -0x261d9(%rip)        # 1c22e <pf_target_7_0>
   42407:	41 53                	push   %r11
   42409:	4c 8b 1d b8 8d ff ff 	mov    -0x7248(%rip),%r11        # 3b1c8 <pf_got_7_0>

0000000000042410 <pf_got_hint_7_0>:
   42410:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   42417:	00 

0000000000042418 <pf_got_hint_7_1>:
   42418:	41 0f 18 93 22 00 00 	prefetcht1 0x22(%r11)
   4241f:	00 
   42420:	41 5b                	pop    %r11

0000000000042422 <pf_jump_7>:
   42422:	e9 99 aa fc ff       	jmp    cec0 <pf_callee_7>
   42427:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   4242e:	00 00 

0000000000042430 <pf_call_8>:
   42430:	0f 18 15 71 f9 fc ff 	prefetcht1 -0x3068f(%rip)        # 11da8 <pf_target_8_0>

0000000000042437 <pf_jump_8>:
   42437:	e9 b4 db fc ff       	jmp    fff0 <pf_callee_8>
   4243c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042440 <pf_call_9>:
   42440:	0f 18 15 79 0b fd ff 	prefetcht1 -0x2f487(%rip)        # 12fc0 <pf_target_9_0>
   42447:	0f 18 15 f3 05 fd ff 	prefetcht1 -0x2fa0d(%rip)        # 12a41 <pf_target_6_1>
   4244e:	0f 18 15 ab 05 fd ff 	prefetcht1 -0x2fa55(%rip)        # 12a00 <pf_target_6_0>

0000000000042455 <pf_jump_9>:
   42455:	e9 26 ad fc ff       	jmp    d180 <pf_callee_10>
   4245a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000042460 <pf_call_10>:
   42460:	0f 18 15 db b3 fc ff 	prefetcht1 -0x34c25(%rip)        # d842 <pf_target_10_0>

0000000000042467 <pf_jump_10>:
   42467:	e9 14 ad fc ff       	jmp    d180 <pf_callee_10>
   4246c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   42473:	00 00 00 
   42476:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4247d:	00 00 00 

0000000000042480 <pf_call_11>:
   42480:	0f 18 15 99 fd fd ff 	prefetcht1 -0x20267(%rip)        # 22220 <pf_target_11_0>
   42487:	0f 18 15 b2 fd fd ff 	prefetcht1 -0x2024e(%rip)        # 22240 <pf_target_11_1>

000000000004248e <pf_jump_11>:
   4248e:	e9 2d f9 fc ff       	jmp    11dc0 <pf_callee_11>
   42493:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4249a:	00 00 00 
   4249d:	0f 1f 00             	nopl   (%rax)

00000000000424a0 <pf_call_12>:
   424a0:	0f 18 15 29 fa fc ff 	prefetcht1 -0x305d7(%rip)        # 11ed0 <pf_target_12_0>

00000000000424a7 <pf_jump_12>:
   424a7:	e9 14 f9 fc ff       	jmp    11dc0 <pf_callee_11>
   424ac:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   424b3:	00 00 00 
   424b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   424bd:	00 00 00 

00000000000424c0 <pf_call_13>:
   424c0:	0f 18 15 29 db fc ff 	prefetcht1 -0x324d7(%rip)        # fff0 <pf_callee_8>
   424c7:	0f 18 15 37 db fc ff 	prefetcht1 -0x324c9(%rip)        # 10005 <pf_target_13_1>
   424ce:	0f 18 15 3b 0e fd ff 	prefetcht1 -0x2f1c5(%rip)        # 13310 <pf_target_13_2>
   424d5:	0f 18 15 e4 f8 fc ff 	prefetcht1 -0x3071c(%rip)        # 11dc0 <pf_callee_11>
   424dc:	0f 18 15 dd fd fd ff 	prefetcht1 -0x20223(%rip)        # 222c0 <pf_target_13_4>
   424e3:	0f 18 15 2e fb fc ff 	prefetcht1 -0x304d2(%rip)        # 12018 <pf_target_13_5>
   424ea:	0f 18 15 50 0e fd ff 	prefetcht1 -0x2f1b0(%rip)        # 13341 <pf_target_13_6>

00000000000424f1 <pf_jump_13>:
   424f1:	e9 da a6 fc ff       	jmp    cbd0 <pf_callee_13>
   424f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   424fd:	00 00 00 

0000000000042500 <pf_call_14>:
   42500:	0f 18 15 59 f6 fc ff 	prefetcht1 -0x309a7(%rip)        # 11b60 <pf_target_14_0>
   42507:	0f 18 15 73 f6 fc ff 	prefetcht1 -0x3098d(%rip)        # 11b81 <pf_target_14_1>

000000000004250e <pf_jump_14>:
   4250e:	e9 7d af fc ff       	jmp    d490 <pf_callee_14>
   42513:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4251a:	00 00 00 
   4251d:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   42524:	00 00 00 
   42527:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4252e:	00 00 00 
   42531:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   42538:	00 00 00 
   4253b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000042540 <pf_call_15>:
   42540:	0f 18 15 79 95 fd ff 	prefetcht1 -0x26a87(%rip)        # 1bac0 <pf_target_15_0>
   42547:	0f 18 15 62 76 fd ff 	prefetcht1 -0x2899e(%rip)        # 19bb0 <pf_target_15_1>
   4254e:	0f 18 15 b1 95 fd ff 	prefetcht1 -0x26a4f(%rip)        # 1bb06 <pf_target_15_2>
   42555:	0f 18 15 e4 95 fd ff 	prefetcht1 -0x26a1c(%rip)        # 1bb40 <pf_target_15_3>
   4255c:	0f 18 15 c7 77 fd ff 	prefetcht1 -0x28839(%rip)        # 19d2a <pf_target_15_4>
   42563:	0f 18 15 98 76 fd ff 	prefetcht1 -0x28968(%rip)        # 19c02 <pf_target_15_5>

000000000004256a <pf_jump_15>:
   4256a:	e9 31 ad fc ff       	jmp    d2a0 <pf_callee_15>
   4256f:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   42576:	00 00 00 
   42579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000042580 <pf_call_16>:
   42580:	0f 18 15 09 40 fe ff 	prefetcht1 -0x1bff7(%rip)        # 26590 <pf_target_16_0>
   42587:	0f 18 15 62 9d fd ff 	prefetcht1 -0x2629e(%rip)        # 1c2f0 <pf_target_16_1>
   4258e:	0f 18 15 2e 40 fe ff 	prefetcht1 -0x1bfd2(%rip)        # 265c3 <pf_target_16_2>
   42595:	0f 18 15 a4 a8 fc ff 	prefetcht1 -0x3575c(%rip)        # ce40 <pf_callee_19>

000000000004259c <pf_jump_16>:
   4259c:	e9 ff ac fc ff       	jmp    d2a0 <pf_callee_15>
   425a1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   425a8:	00 00 00 
   425ab:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   425b2:	00 00 00 
   425b5:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   425bc:	00 00 00 
   425bf:	90                   	nop

00000000000425c0 <pf_call_17>:
   425c0:	0f 18 15 49 12 fd ff 	prefetcht1 -0x2edb7(%rip)        # 13810 <pf_target_17_0>
   425c7:	0f 18 15 75 12 fd ff 	prefetcht1 -0x2ed8b(%rip)        # 13843 <pf_target_17_1>

00000000000425ce <pf_jump_17>:
   425ce:	e9 bd a7 fc ff       	jmp    cd90 <pf_callee_17>
   425d3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   425da:	00 00 00 
   425dd:	0f 1f 00             	nopl   (%rax)

00000000000425e0 <pf_call_18>:
   425e0:	0f 18 15 db 53 fd ff 	prefetcht1 -0x2ac25(%rip)        # 179c2 <pf_target_18_0>
   425e7:	41 53                	push   %r11
   425e9:	4c 8b 1d 40 8b ff ff 	mov    -0x74c0(%rip),%r11        # 3b130 <pf_got_18_0>

00000000000425f0 <pf_got_hint_18_0>:
   425f0:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   425f7:	00 
   425f8:	41 5b                	pop    %r11

00000000000425fa <pf_jump_18>:
   425fa:	e9 c1 af fc ff       	jmp    d5c0 <pf_callee_18>
   425ff:	90                   	nop

0000000000042600 <pf_call_19>:
   42600:	0f 18 15 89 91 fd ff 	prefetcht1 -0x26e77(%rip)        # 1b790 <pf_target_19_0>
   42607:	0f 18 15 b5 91 fd ff 	prefetcht1 -0x26e4b(%rip)        # 1b7c3 <pf_target_19_1>
   4260e:	41 53                	push   %r11
   42610:	4c 8b 1d 79 8a ff ff 	mov    -0x7587(%rip),%r11        # 3b090 <pf_got_19_0>

0000000000042617 <pf_got_hint_19_0>:
   42617:	41 0f 18 93 12 ff ff 	prefetcht1 -0xee(%r11)
   4261e:	ff 
   4261f:	4c 8b 1d 72 8a ff ff 	mov    -0x758e(%rip),%r11        # 3b098 <pf_got_19_1>

0000000000042626 <pf_got_hint_19_1>:
   42626:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   4262d:	00 

000000000004262e <pf_got_hint_19_2>:
   4262e:	41 0f 18 93 46 00 00 	prefetcht1 0x46(%r11)
   42635:	00 
   42636:	41 5b                	pop    %r11

0000000000042638 <pf_jump_19>:
   42638:	e9 03 a8 fc ff       	jmp    ce40 <pf_callee_19>
   4263d:	0f 1f 00             	nopl   (%rax)

0000000000042640 <pf_call_20>:
   42640:	41 53                	push   %r11
   42642:	4c 8b 1d 47 8a ff ff 	mov    -0x75b9(%rip),%r11        # 3b090 <pf_got_19_0>

0000000000042649 <pf_got_hint_20_0>:
   42649:	41 0f 18 93 b0 fe ff 	prefetcht1 -0x150(%r11)
   42650:	ff 
   42651:	41 5b                	pop    %r11

0000000000042653 <pf_jump_20>:
   42653:	e9 08 a8 fc ff       	jmp    ce60 <pf_callee_20>
   42658:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4265f:	00 00 00 
   42662:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   42669:	00 00 00 
   4266c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   42673:	00 00 00 
   42676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4267d:	00 00 00 

0000000000042680 <pf_call_21>:
   42680:	0f 18 15 9b 76 fd ff 	prefetcht1 -0x28965(%rip)        # 19d22 <pf_target_21_0>
   42687:	0f 18 15 32 84 fd ff 	prefetcht1 -0x27bce(%rip)        # 1aac0 <pf_target_21_1>
   4268e:	0f 18 15 8b a4 fc ff 	prefetcht1 -0x35b75(%rip)        # cb20 <pf_target_21_2>
   42695:	41 53                	push   %r11
   42697:	4c 8b 1d f2 89 ff ff 	mov    -0x760e(%rip),%r11        # 3b090 <pf_got_19_0>

000000000004269e <pf_got_hint_21_0>:
   4269e:	41 0f 18 93 82 fe ff 	prefetcht1 -0x17e(%r11)
   426a5:	ff 

00000000000426a6 <pf_got_hint_21_1>:
   426a6:	41 0f 18 93 f0 fe ff 	prefetcht1 -0x110(%r11)
   426ad:	ff 

00000000000426ae <pf_got_hint_21_2>:
   426ae:	41 0f 18 93 12 ff ff 	prefetcht1 -0xee(%r11)
   426b5:	ff 
   426b6:	41 5b                	pop    %r11

00000000000426b8 <pf_jump_21>:
   426b8:	e9 a3 a5 fc ff       	jmp    cc60 <pf_callee_21>
   426bd:	0f 1f 00             	nopl   (%rax)

00000000000426c0 <pf_call_22>:
   426c0:	0f 18 15 f9 7b fd ff 	prefetcht1 -0x28407(%rip)        # 1a2c0 <pf_target_22_0>

00000000000426c7 <pf_jump_22>:
   426c7:	e9 d4 ab fc ff       	jmp    d2a0 <pf_callee_15>
   426cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000426d0 <pf_call_23>:
   426d0:	0f 18 15 f9 22 fe ff 	prefetcht1 -0x1dd07(%rip)        # 249d0 <pf_target_23_0>

00000000000426d7 <pf_jump_23>:
   426d7:	e9 c4 ab fc ff       	jmp    d2a0 <pf_callee_15>
   426dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000426e0 <pf_call_24>:
   426e0:	0f 18 15 59 82 fd ff 	prefetcht1 -0x27da7(%rip)        # 1a940 <pf_target_24_0>

00000000000426e7 <pf_jump_24>:
   426e7:	e9 b4 a9 fc ff       	jmp    d0a0 <pf_callee_24>
   426ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000426f0 <pf_call_25>:
   426f0:	0f 18 15 99 85 fd ff 	prefetcht1 -0x27a67(%rip)        # 1ac90 <pf_target_25_0>

00000000000426f7 <pf_jump_25>:
   426f7:	e9 84 ae fc ff       	jmp    d580 <pf_callee_25>
   426fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042700 <pf_call_26>:
   42700:	0f 18 15 a9 8e fd ff 	prefetcht1 -0x27157(%rip)        # 1b5b0 <pf_target_26_0>

0000000000042707 <pf_jump_26>:
   42707:	e9 14 aa fc ff       	jmp    d120 <pf_callee_26>
   4270c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   42713:	00 00 00 
   42716:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4271d:	00 00 00 

0000000000042720 <pf_call_27>:
   42720:	0f 18 15 29 eb fc ff 	prefetcht1 -0x314d7(%rip)        # 11250 <pf_target_27_0>
   42727:	0f 18 15 b2 87 fd ff 	prefetcht1 -0x2784e(%rip)        # 1aee0 <pf_target_27_1>

000000000004272e <pf_jump_27>:
   4272e:	e9 ad a5 fc ff       	jmp    cce0 <pf_callee_27>
   42733:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4273a:	00 00 00 
   4273d:	0f 1f 00             	nopl   (%rax)

0000000000042740 <pf_call_28>:
   42740:	0f 18 15 0e 41 fe ff 	prefetcht1 -0x1bef2(%rip)        # 26855 <pf_target_28_0>

0000000000042747 <pf_jump_28>:
   42747:	e9 f4 a6 fc ff       	jmp    ce40 <pf_callee_19>
   4274c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042750 <pf_call_29>:
   42750:	0f 18 15 a9 e6 fc ff 	prefetcht1 -0x31957(%rip)        # 10e00 <pf_target_29_0>

0000000000042757 <pf_jump_29>:
   42757:	e9 24 ad fc ff       	jmp    d480 <pf_callee_29>
   4275c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042760 <pf_call_30>:
   42760:	0f 18 15 c9 53 fd ff 	prefetcht1 -0x2ac37(%rip)        # 17b30 <pf_target_30_0>
   42767:	0f 18 15 42 52 fd ff 	prefetcht1 -0x2adbe(%rip)        # 179b0 <pf_target_30_1>

000000000004276e <pf_jump_30>:
   4276e:	e9 9d aa fc ff       	jmp    d210 <pf_callee_30>
   42773:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4277a:	00 00 00 
   4277d:	0f 1f 00             	nopl   (%rax)

0000000000042780 <pf_call_31>:
   42780:	0f 18 15 99 3e fd ff 	prefetcht1 -0x2c167(%rip)        # 16620 <pf_target_31_0>
   42787:	0f 18 15 b3 3e fd ff 	prefetcht1 -0x2c14d(%rip)        # 16641 <pf_target_31_1>
   4278e:	41 53                	push   %r11
   42790:	4c 8b 1d b1 8d ff ff 	mov    -0x724f(%rip),%r11        # 3b548 <pf_got_31_0>

0000000000042797 <pf_got_hint_31_0>:
   42797:	41 0f 18 93 83 c5 00 	prefetcht1 0xc583(%r11)
   4279e:	00 

000000000004279f <pf_got_hint_31_1>:
   4279f:	41 0f 18 93 04 c6 00 	prefetcht1 0xc604(%r11)
   427a6:	00 
   427a7:	41 5b                	pop    %r11

00000000000427a9 <pf_jump_31>:
   427a9:	e9 22 ae fc ff       	jmp    d5d0 <pf_callee_31>
   427ae:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   427b5:	00 00 00 
   427b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   427bf:	00 

00000000000427c0 <pf_call_32>:
   427c0:	0f 18 15 39 7d fd ff 	prefetcht1 -0x282c7(%rip)        # 1a500 <pf_target_32_0>
   427c7:	0f 18 15 42 7b fd ff 	prefetcht1 -0x284be(%rip)        # 1a310 <pf_target_32_1>
   427ce:	0f 18 15 fb 28 fd ff 	prefetcht1 -0x2d705(%rip)        # 150d0 <pf_target_32_2>
   427d5:	0f 18 15 84 7c fd ff 	prefetcht1 -0x2837c(%rip)        # 1a460 <pf_target_32_3>
   427dc:	0f 18 15 bd 77 fd ff 	prefetcht1 -0x28843(%rip)        # 19fa0 <pf_target_32_4>
   427e3:	0f 18 15 06 7d fd ff 	prefetcht1 -0x282fa(%rip)        # 1a4f0 <pf_target_32_5>
   427ea:	0f 18 15 bf a7 fc ff 	prefetcht1 -0x35841(%rip)        # cfb0 <pf_target_32_6>
   427f1:	0f 18 15 ca 77 fd ff 	prefetcht1 -0x28836(%rip)        # 19fc2 <pf_target_32_7>

00000000000427f8 <pf_jump_32>:
   427f8:	e9 53 a4 fc ff       	jmp    cc50 <pf_callee_32>
   427fd:	0f 1f 00             	nopl   (%rax)

0000000000042800 <pf_call_33>:
   42800:	41 53                	push   %r11
   42802:	4c 8b 1d 1f 8c ff ff 	mov    -0x73e1(%rip),%r11        # 3b428 <pf_got_33_0>

0000000000042809 <pf_got_hint_33_0>:
   42809:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   42810:	00 
   42811:	4c 8b 1d 30 8d ff ff 	mov    -0x72d0(%rip),%r11        # 3b548 <pf_got_31_0>

0000000000042818 <pf_got_hint_33_1>:
   42818:	41 0f 18 93 85 e4 fe 	prefetcht1 -0x11b7b(%r11)
   4281f:	ff 
   42820:	41 5b                	pop    %r11

0000000000042822 <pf_jump_33>:
   42822:	e9 59 ab fc ff       	jmp    d380 <pf_callee_33>
   42827:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4282e:	00 00 00 
   42831:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   42838:	00 00 00 
   4283b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000042840 <pf_call_34>:
   42840:	41 53                	push   %r11
   42842:	4c 8b 1d df 8b ff ff 	mov    -0x7421(%rip),%r11        # 3b428 <pf_got_33_0>

0000000000042849 <pf_got_hint_34_0>:
   42849:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   42850:	00 
   42851:	41 5b                	pop    %r11

0000000000042853 <pf_jump_34>:
   42853:	e9 78 ad fc ff       	jmp    d5d0 <pf_callee_31>
   42858:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4285f:	00 00 00 
   42862:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   42869:	00 00 00 
   4286c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   42873:	00 00 00 
   42876:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4287d:	00 00 00 

0000000000042880 <pf_call_35>:
   42880:	41 53                	push   %r11
   42882:	4c 8b 1d bf 8c ff ff 	mov    -0x7341(%rip),%r11        # 3b548 <pf_got_31_0>

0000000000042889 <pf_got_hint_35_0>:
   42889:	41 0f 18 93 60 bf fd 	prefetcht1 -0x240a0(%r11)
   42890:	ff 

0000000000042891 <pf_got_hint_35_1>:
   42891:	41 0f 18 93 e8 ca fd 	prefetcht1 -0x23518(%r11)
   42898:	ff 

0000000000042899 <pf_got_hint_35_2>:
   42899:	41 0f 18 93 f7 cd fd 	prefetcht1 -0x23209(%r11)
   428a0:	ff 

00000000000428a1 <pf_got_hint_35_3>:
   428a1:	41 0f 18 93 00 ce fd 	prefetcht1 -0x23200(%r11)
   428a8:	ff 

00000000000428a9 <pf_got_hint_35_4>:
   428a9:	41 0f 18 93 30 e4 fe 	prefetcht1 -0x11bd0(%r11)
   428b0:	ff 

00000000000428b1 <pf_got_hint_35_5>:
   428b1:	41 0f 18 93 40 e4 fe 	prefetcht1 -0x11bc0(%r11)
   428b8:	ff 

00000000000428b9 <pf_got_hint_35_6>:
   428b9:	41 0f 18 93 42 46 ff 	prefetcht1 -0xb9be(%r11)
   428c0:	ff 

00000000000428c1 <pf_got_hint_35_7>:
   428c1:	41 0f 18 93 90 46 ff 	prefetcht1 -0xb970(%r11)
   428c8:	ff 
   428c9:	41 5b                	pop    %r11

00000000000428cb <pf_jump_35>:
   428cb:	e9 50 aa fc ff       	jmp    d320 <pf_callee_35>
   428d0:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   428d7:	00 00 00 
   428da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000428e0 <pf_call_36>:
   428e0:	41 53                	push   %r11
   428e2:	4c 8b 1d 5f 8c ff ff 	mov    -0x73a1(%rip),%r11        # 3b548 <pf_got_31_0>

00000000000428e9 <pf_got_hint_36_0>:
   428e9:	41 0f 18 93 85 e4 fe 	prefetcht1 -0x11b7b(%r11)
   428f0:	ff 

00000000000428f1 <pf_got_hint_36_1>:
   428f1:	41 0f 18 93 42 46 ff 	prefetcht1 -0xb9be(%r11)
   428f8:	ff 
   428f9:	41 5b                	pop    %r11

00000000000428fb <pf_jump_36>:
   428fb:	e9 20 aa fc ff       	jmp    d320 <pf_callee_35>
