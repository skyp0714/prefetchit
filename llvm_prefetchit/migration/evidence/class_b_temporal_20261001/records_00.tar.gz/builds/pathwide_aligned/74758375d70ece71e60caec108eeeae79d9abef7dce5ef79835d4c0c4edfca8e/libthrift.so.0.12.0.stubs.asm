
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_aligned/74758375d70ece71e60caec108eeeae79d9abef7dce5ef79835d4c0c4edfca8e/call-stub-qanm_rxw/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000c22c0 <pf_call_0>:
   c22c0:	0f 18 15 b9 00 fa ff 	prefetcht1 -0x5ff47(%rip)        # 62380 <pf_target_0_0>

00000000000c22c7 <pf_jump_0>:
   c22c7:	e9 d4 67 f8 ff       	jmp    48aa0 <pf_callee_0>
   c22cc:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c22d3:	00 00 00 
   c22d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c22dd:	00 00 00 

00000000000c22e0 <pf_call_1>:
   c22e0:	0f 18 15 39 6d f8 ff 	prefetcht1 -0x792c7(%rip)        # 49020 <pf_callee_2>
   c22e7:	0f 18 15 12 57 f8 ff 	prefetcht1 -0x7a8ee(%rip)        # 47a00 <pf_callee_3>
   c22ee:	0f 18 15 bf 69 fb ff 	prefetcht1 -0x49641(%rip)        # 78cb4 <pf_target_1_2>

00000000000c22f5 <pf_jump_1>:
   c22f5:	e9 66 52 f8 ff       	jmp    47560 <pf_callee_1>
   c22fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000c2300 <pf_call_2>:
   c2300:	0f 18 15 f9 5f f8 ff 	prefetcht1 -0x7a007(%rip)        # 48300 <pf_callee_5>
   c2307:	0f 18 15 f2 e1 fb ff 	prefetcht1 -0x41e0e(%rip)        # 80500 <pf_target_2_1>

00000000000c230e <pf_jump_2>:
   c230e:	e9 0d 6d f8 ff       	jmp    49020 <pf_callee_2>
   c2313:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c231a:	00 00 00 
   c231d:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c2324:	00 00 00 
   c2327:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c232e:	00 00 00 
   c2331:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c2338:	00 00 00 
   c233b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000c2340 <pf_call_3>:
   c2340:	0f 18 15 7e 6c fb ff 	prefetcht1 -0x49382(%rip)        # 78fc5 <pf_target_3_0>
   c2347:	0f 18 15 52 86 fb ff 	prefetcht1 -0x479ae(%rip)        # 7a9a0 <pf_target_3_1>
   c234e:	0f 18 15 1b 85 fb ff 	prefetcht1 -0x47ae5(%rip)        # 7a870 <pf_target_3_2>
   c2355:	0f 18 15 14 68 fb ff 	prefetcht1 -0x497ec(%rip)        # 78b70 <pf_target_3_3>
   c235c:	0f 18 15 24 85 fb ff 	prefetcht1 -0x47adc(%rip)        # 7a887 <pf_target_3_4>
   c2363:	0f 18 15 87 e1 fb ff 	prefetcht1 -0x41e79(%rip)        # 804f1 <pf_target_3_5>
   c236a:	0f 18 15 14 68 fb ff 	prefetcht1 -0x497ec(%rip)        # 78b85 <pf_target_3_6>
   c2371:	0f 18 15 f3 e5 fb ff 	prefetcht1 -0x41a0d(%rip)        # 8096b <pf_target_3_7>

00000000000c2378 <pf_jump_3>:
   c2378:	e9 83 56 f8 ff       	jmp    47a00 <pf_callee_3>
   c237d:	0f 1f 00             	nopl   (%rax)

00000000000c2380 <pf_call_4>:
   c2380:	0f 18 15 39 12 fb ff 	prefetcht1 -0x4edc7(%rip)        # 735c0 <pf_target_4_0>
   c2387:	0f 18 15 b2 54 f8 ff 	prefetcht1 -0x7ab4e(%rip)        # 47840 <pf_target_4_1>
   c238e:	0f 18 15 2b f5 fb ff 	prefetcht1 -0x40ad5(%rip)        # 818c0 <pf_target_4_2>
   c2395:	0f 18 15 74 f6 fb ff 	prefetcht1 -0x4098c(%rip)        # 81a10 <pf_target_4_3>

00000000000c239c <pf_jump_4>:
   c239c:	e9 7f 59 f8 ff       	jmp    47d20 <pf_callee_4>
   c23a1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c23a8:	00 00 00 
   c23ab:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c23b2:	00 00 00 
   c23b5:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c23bc:	00 00 00 
   c23bf:	90                   	nop

00000000000c23c0 <pf_call_5>:
   c23c0:	0f 18 15 3a ec fb ff 	prefetcht1 -0x413c6(%rip)        # 81001 <pf_target_5_0>
   c23c7:	0f 18 15 f2 f2 fb ff 	prefetcht1 -0x40d0e(%rip)        # 816c0 <pf_target_5_1>
   c23ce:	0f 18 15 40 f5 fb ff 	prefetcht1 -0x40ac0(%rip)        # 81915 <pf_target_5_2>
   c23d5:	0f 18 15 6c f5 fb ff 	prefetcht1 -0x40a94(%rip)        # 81948 <pf_target_5_3>
   c23dc:	0f 18 15 0d ec fb ff 	prefetcht1 -0x413f3(%rip)        # 80ff0 <pf_target_5_4>
   c23e3:	0f 18 15 16 f3 fb ff 	prefetcht1 -0x40cea(%rip)        # 81700 <pf_target_5_5>
   c23ea:	41 53                	push   %r11
   c23ec:	4c 8b 1d c5 e4 ff ff 	mov    -0x1b3b(%rip),%r11        # c08b8 <pf_got_5_0>

00000000000c23f3 <pf_got_hint_5_0>:
   c23f3:	41 0f 18 93 a0 04 0a 	prefetcht1 0xa04a0(%r11)
   c23fa:	00 

00000000000c23fb <pf_got_hint_5_1>:
   c23fb:	41 0f 18 93 40 06 0a 	prefetcht1 0xa0640(%r11)
   c2402:	00 
   c2403:	41 5b                	pop    %r11

00000000000c2405 <pf_jump_5>:
   c2405:	e9 f6 5e f8 ff       	jmp    48300 <pf_callee_5>
   c240a:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c2411:	00 00 00 
   c2414:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c241b:	00 00 00 
   c241e:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c2425:	00 00 00 
   c2428:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c242f:	00 00 00 
   c2432:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c2439:	00 00 00 
   c243c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000c2440 <pf_call_6>:
   c2440:	0f 18 15 a9 6d fb ff 	prefetcht1 -0x49257(%rip)        # 791f0 <pf_target_6_0>
   c2447:	0f 18 15 32 e0 fb ff 	prefetcht1 -0x41fce(%rip)        # 80480 <pf_target_6_1>
   c244e:	0f 18 15 eb 4c fb ff 	prefetcht1 -0x4b315(%rip)        # 77140 <pf_target_6_2>
   c2455:	0f 18 15 24 4d fb ff 	prefetcht1 -0x4b2dc(%rip)        # 77180 <pf_target_6_3>
   c245c:	0f 18 15 ed 83 fb ff 	prefetcht1 -0x47c13(%rip)        # 7a850 <pf_target_6_4>
   c2463:	0f 18 15 b6 58 f8 ff 	prefetcht1 -0x7a74a(%rip)        # 47d20 <pf_callee_4>
   c246a:	0f 18 15 91 6d fb ff 	prefetcht1 -0x4926f(%rip)        # 79202 <pf_target_6_6>

00000000000c2471 <pf_jump_6>:
   c2471:	e9 8a 5e f8 ff       	jmp    48300 <pf_callee_5>
   c2476:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c247d:	00 00 00 

00000000000c2480 <pf_call_7>:
   c2480:	41 53                	push   %r11
   c2482:	4c 8b 1d 2f e4 ff ff 	mov    -0x1bd1(%rip),%r11        # c08b8 <pf_got_5_0>

00000000000c2489 <pf_got_hint_7_0>:
   c2489:	41 0f 18 93 c0 53 ff 	prefetcht1 -0xac40(%r11)
   c2490:	ff 

00000000000c2491 <pf_got_hint_7_1>:
   c2491:	41 0f 18 93 71 1d 00 	prefetcht1 0x1d71(%r11)
   c2498:	00 
   c2499:	41 5b                	pop    %r11

00000000000c249b <pf_jump_7>:
   c249b:	e9 60 5e f8 ff       	jmp    48300 <pf_callee_5>
