.text
.balign 64
.global pf_call_0
.type pf_call_0,@function
pf_call_0:
.cfi_startproc
prefetcht1 pf_target_0_0(%rip)
prefetcht1 pf_target_0_1(%rip)
prefetcht1 pf_target_0_2(%rip)
prefetcht1 pf_target_0_3(%rip)
prefetcht1 pf_target_0_4(%rip)
prefetcht1 pf_target_0_5(%rip)
.global pf_jump_0
pf_jump_0:
jmp pf_callee_0
.cfi_endproc
.size pf_call_0,.-pf_call_0
.balign 64
.global pf_call_1
.type pf_call_1,@function
pf_call_1:
.cfi_startproc
prefetcht1 pf_target_1_0(%rip)
prefetcht1 pf_target_1_1(%rip)
prefetcht1 pf_target_1_2(%rip)
prefetcht1 pf_target_1_3(%rip)
.global pf_jump_1
pf_jump_1:
jmp pf_callee_1
.cfi_endproc
.size pf_call_1,.-pf_call_1
.balign 32
.global pf_call_2
.type pf_call_2,@function
pf_call_2:
.cfi_startproc
prefetcht1 pf_target_2_0(%rip)
prefetcht1 pf_target_2_1(%rip)
prefetcht1 pf_target_2_2(%rip)
.global pf_jump_2
pf_jump_2:
jmp pf_callee_2
.cfi_endproc
.size pf_call_2,.-pf_call_2
.balign 16
.global pf_call_3
.type pf_call_3,@function
pf_call_3:
.cfi_startproc
prefetcht1 pf_target_3_0(%rip)
.global pf_jump_3
pf_jump_3:
jmp pf_callee_3
.cfi_endproc
.size pf_call_3,.-pf_call_3
.balign 64
.global pf_call_4
.type pf_call_4,@function
pf_call_4:
.cfi_startproc
prefetcht1 pf_target_4_0(%rip)
prefetcht1 pf_target_4_1(%rip)
prefetcht1 pf_target_4_2(%rip)
prefetcht1 pf_target_4_3(%rip)
prefetcht1 pf_target_4_4(%rip)
prefetcht1 pf_target_4_5(%rip)
prefetcht1 pf_target_4_6(%rip)
prefetcht1 pf_target_4_7(%rip)
.global pf_jump_4
pf_jump_4:
jmp pf_callee_4
.cfi_endproc
.size pf_call_4,.-pf_call_4
.balign 64
.global pf_call_5
.type pf_call_5,@function
pf_call_5:
.cfi_startproc
prefetcht1 pf_target_5_0(%rip)
prefetcht1 pf_target_5_1(%rip)
prefetcht1 pf_target_5_2(%rip)
prefetcht1 pf_target_5_3(%rip)
.global pf_jump_5
pf_jump_5:
jmp pf_callee_5
.cfi_endproc
.size pf_call_5,.-pf_call_5
.balign 32
.global pf_call_6
.type pf_call_6,@function
pf_call_6:
.cfi_startproc
prefetcht1 pf_target_6_0(%rip)
prefetcht1 pf_target_6_1(%rip)
prefetcht1 pf_target_6_2(%rip)
.global pf_jump_6
pf_jump_6:
jmp pf_callee_6
.cfi_endproc
.size pf_call_6,.-pf_call_6
.balign 16
.global pf_call_7
.type pf_call_7,@function
pf_call_7:
.cfi_startproc
prefetcht1 pf_target_7_0(%rip)
.global pf_jump_7
pf_jump_7:
jmp pf_callee_7
.cfi_endproc
.size pf_call_7,.-pf_call_7
.balign 32
.global pf_call_8
.type pf_call_8,@function
pf_call_8:
.cfi_startproc
prefetcht1 pf_target_8_0(%rip)
prefetcht1 pf_target_8_1(%rip)
.global pf_jump_8
pf_jump_8:
jmp pf_callee_8
.cfi_endproc
.size pf_call_8,.-pf_call_8
.balign 64
.global pf_call_9
.type pf_call_9,@function
pf_call_9:
.cfi_startproc
prefetcht1 pf_target_9_0(%rip)
prefetcht1 pf_target_9_1(%rip)
prefetcht1 pf_target_9_2(%rip)
prefetcht1 pf_target_9_3(%rip)
prefetcht1 pf_target_9_4(%rip)
.global pf_jump_9
pf_jump_9:
jmp pf_callee_9
.cfi_endproc
.size pf_call_9,.-pf_call_9
.balign 32
.global pf_call_10
.type pf_call_10,@function
pf_call_10:
.cfi_startproc
prefetcht1 pf_target_10_0(%rip)
prefetcht1 pf_target_10_1(%rip)
prefetcht1 pf_target_10_2(%rip)
.global pf_jump_10
pf_jump_10:
jmp pf_callee_10
.cfi_endproc
.size pf_call_10,.-pf_call_10
.balign 32
.global pf_call_11
.type pf_call_11,@function
pf_call_11:
.cfi_startproc
prefetcht1 pf_target_11_0(%rip)
prefetcht1 pf_target_11_1(%rip)
.global pf_jump_11
pf_jump_11:
jmp pf_callee_11
.cfi_endproc
.size pf_call_11,.-pf_call_11
.balign 64
.global pf_call_12
.type pf_call_12,@function
pf_call_12:
.cfi_startproc
prefetcht1 pf_target_12_0(%rip)
prefetcht1 pf_target_12_1(%rip)
prefetcht1 pf_target_12_2(%rip)
prefetcht1 pf_target_12_3(%rip)
.global pf_jump_12
pf_jump_12:
jmp pf_callee_12
.cfi_endproc
.size pf_call_12,.-pf_call_12
.balign 16
.global pf_call_13
.type pf_call_13,@function
pf_call_13:
.cfi_startproc
prefetcht1 pf_target_13_0(%rip)
.global pf_jump_13
pf_jump_13:
jmp pf_callee_13
.cfi_endproc
.size pf_call_13,.-pf_call_13
.balign 64
.global pf_call_14
.type pf_call_14,@function
pf_call_14:
.cfi_startproc
prefetcht1 pf_target_14_0(%rip)
prefetcht1 pf_target_14_1(%rip)
prefetcht1 pf_target_14_2(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_14_0(%rip),%r11
.global pf_got_hint_14_0
pf_got_hint_14_0:
.byte 0x41,0x0f,0x18,0x93
.long 794
.global pf_got_hint_14_1
pf_got_hint_14_1:
.byte 0x41,0x0f,0x18,0x93
.long 1261
.global pf_got_hint_14_2
pf_got_hint_14_2:
.byte 0x41,0x0f,0x18,0x93
.long 1315
.global pf_got_hint_14_3
pf_got_hint_14_3:
.byte 0x41,0x0f,0x18,0x93
.long 1792
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_14
pf_jump_14:
jmp pf_callee_14
.cfi_endproc
.size pf_call_14,.-pf_call_14
.balign 64
.global pf_call_15
.type pf_call_15,@function
pf_call_15:
.cfi_startproc
prefetcht1 pf_target_15_0(%rip)
prefetcht1 pf_target_15_1(%rip)
prefetcht1 pf_target_15_2(%rip)
prefetcht1 pf_target_15_3(%rip)
prefetcht1 pf_target_15_4(%rip)
.global pf_jump_15
pf_jump_15:
jmp pf_callee_15
.cfi_endproc
.size pf_call_15,.-pf_call_15
.balign 64
.global pf_call_16
.type pf_call_16,@function
pf_call_16:
.cfi_startproc
prefetcht1 pf_target_16_0(%rip)
prefetcht1 pf_target_16_1(%rip)
prefetcht1 pf_target_16_2(%rip)
prefetcht1 pf_target_16_3(%rip)
.global pf_jump_16
pf_jump_16:
jmp pf_callee_16
.cfi_endproc
.size pf_call_16,.-pf_call_16
.balign 32
.global pf_call_17
.type pf_call_17,@function
pf_call_17:
.cfi_startproc
prefetcht1 pf_target_17_0(%rip)
prefetcht1 pf_target_17_1(%rip)
.global pf_jump_17
pf_jump_17:
jmp pf_callee_17
.cfi_endproc
.size pf_call_17,.-pf_call_17
.balign 16
.global pf_call_18
.type pf_call_18,@function
pf_call_18:
.cfi_startproc
prefetcht1 pf_target_18_0(%rip)
.global pf_jump_18
pf_jump_18:
jmp pf_callee_18
.cfi_endproc
.size pf_call_18,.-pf_call_18
.balign 64
.global pf_call_19
.type pf_call_19,@function
pf_call_19:
.cfi_startproc
prefetcht1 pf_target_19_0(%rip)
prefetcht1 pf_target_19_1(%rip)
prefetcht1 pf_target_19_2(%rip)
prefetcht1 pf_target_19_3(%rip)
prefetcht1 pf_target_19_4(%rip)
.global pf_jump_19
pf_jump_19:
jmp pf_callee_19
.cfi_endproc
.size pf_call_19,.-pf_call_19
.balign 32
.global pf_call_20
.type pf_call_20,@function
pf_call_20:
.cfi_startproc
prefetcht1 pf_target_20_0(%rip)
prefetcht1 pf_target_20_1(%rip)
prefetcht1 pf_target_20_2(%rip)
.global pf_jump_20
pf_jump_20:
jmp pf_callee_20
.cfi_endproc
.size pf_call_20,.-pf_call_20
.balign 16
.global pf_call_21
.type pf_call_21,@function
pf_call_21:
.cfi_startproc
prefetcht1 pf_target_21_0(%rip)
.global pf_jump_21
pf_jump_21:
jmp pf_callee_21
.cfi_endproc
.size pf_call_21,.-pf_call_21
.balign 32
.global pf_call_22
.type pf_call_22,@function
pf_call_22:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_22_0(%rip),%r11
.global pf_got_hint_22_0
pf_got_hint_22_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_22
pf_jump_22:
jmp pf_callee_22
.cfi_endproc
.size pf_call_22,.-pf_call_22
.balign 32
.global pf_call_23
.type pf_call_23,@function
pf_call_23:
.cfi_startproc
prefetcht1 pf_target_23_0(%rip)
prefetcht1 pf_target_23_1(%rip)
prefetcht1 pf_target_23_2(%rip)
.global pf_jump_23
pf_jump_23:
jmp pf_callee_23
.cfi_endproc
.size pf_call_23,.-pf_call_23
.balign 64
.global pf_call_24
.type pf_call_24,@function
pf_call_24:
.cfi_startproc
prefetcht1 pf_target_24_0(%rip)
prefetcht1 pf_target_24_1(%rip)
prefetcht1 pf_target_24_2(%rip)
prefetcht1 pf_target_24_3(%rip)
prefetcht1 pf_target_24_4(%rip)
prefetcht1 pf_target_24_5(%rip)
.global pf_jump_24
pf_jump_24:
jmp pf_callee_24
.cfi_endproc
.size pf_call_24,.-pf_call_24
.balign 16
.global pf_call_25
.type pf_call_25,@function
pf_call_25:
.cfi_startproc
prefetcht1 pf_target_25_0(%rip)
.global pf_jump_25
pf_jump_25:
jmp pf_callee_25
.cfi_endproc
.size pf_call_25,.-pf_call_25
.balign 64
.global pf_call_26
.type pf_call_26,@function
pf_call_26:
.cfi_startproc
prefetcht1 pf_target_26_0(%rip)
prefetcht1 pf_target_26_1(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_26_0(%rip),%r11
.global pf_got_hint_26_0
pf_got_hint_26_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_26
pf_jump_26:
jmp pf_callee_26
.cfi_endproc
.size pf_call_26,.-pf_call_26
.balign 64
.global pf_call_27
.type pf_call_27,@function
pf_call_27:
.cfi_startproc
prefetcht1 pf_target_27_0(%rip)
prefetcht1 pf_target_27_1(%rip)
prefetcht1 pf_target_27_2(%rip)
prefetcht1 pf_target_27_3(%rip)
prefetcht1 pf_target_27_4(%rip)
prefetcht1 pf_target_27_5(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_27_0(%rip),%r11
.global pf_got_hint_27_0
pf_got_hint_27_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_27_1
pf_got_hint_27_1:
.byte 0x41,0x0f,0x18,0x93
.long 16
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_27
pf_jump_27:
jmp pf_callee_27
.cfi_endproc
.size pf_call_27,.-pf_call_27
.balign 32
.global pf_call_28
.type pf_call_28,@function
pf_call_28:
.cfi_startproc
prefetcht1 pf_target_28_0(%rip)
prefetcht1 pf_target_28_1(%rip)
.global pf_jump_28
pf_jump_28:
jmp pf_callee_28
.cfi_endproc
.size pf_call_28,.-pf_call_28
.balign 16
.global pf_call_29
.type pf_call_29,@function
pf_call_29:
.cfi_startproc
prefetcht1 pf_target_29_0(%rip)
.global pf_jump_29
pf_jump_29:
jmp pf_callee_29
.cfi_endproc
.size pf_call_29,.-pf_call_29
.balign 32
.global pf_call_30
.type pf_call_30,@function
pf_call_30:
.cfi_startproc
prefetcht1 pf_target_30_0(%rip)
prefetcht1 pf_target_30_1(%rip)
.global pf_jump_30
pf_jump_30:
jmp pf_callee_30
.cfi_endproc
.size pf_call_30,.-pf_call_30
.balign 64
.global pf_call_31
.type pf_call_31,@function
pf_call_31:
.cfi_startproc
prefetcht1 pf_target_31_0(%rip)
prefetcht1 pf_target_31_1(%rip)
prefetcht1 pf_target_31_2(%rip)
prefetcht1 pf_target_31_3(%rip)
.global pf_jump_31
pf_jump_31:
jmp pf_callee_31
.cfi_endproc
.size pf_call_31,.-pf_call_31
.balign 64
.global pf_call_32
.type pf_call_32,@function
pf_call_32:
.cfi_startproc
prefetcht1 pf_target_32_0(%rip)
prefetcht1 pf_target_32_1(%rip)
prefetcht1 pf_target_32_2(%rip)
prefetcht1 pf_target_32_3(%rip)
.global pf_jump_32
pf_jump_32:
jmp pf_callee_32
.cfi_endproc
.size pf_call_32,.-pf_call_32
.balign 64
.global pf_call_33
.type pf_call_33,@function
pf_call_33:
.cfi_startproc
prefetcht1 pf_target_33_0(%rip)
prefetcht1 pf_target_33_1(%rip)
prefetcht1 pf_target_33_2(%rip)
prefetcht1 pf_target_33_3(%rip)
prefetcht1 pf_target_33_4(%rip)
prefetcht1 pf_target_33_5(%rip)
prefetcht1 pf_target_33_6(%rip)
.global pf_jump_33
pf_jump_33:
jmp pf_callee_33
.cfi_endproc
.size pf_call_33,.-pf_call_33
.balign 16
.global pf_call_34
.type pf_call_34,@function
pf_call_34:
.cfi_startproc
prefetcht1 pf_target_34_0(%rip)
.global pf_jump_34
pf_jump_34:
jmp pf_callee_34
.cfi_endproc
.size pf_call_34,.-pf_call_34
.balign 64
.global pf_call_35
.type pf_call_35,@function
pf_call_35:
.cfi_startproc
prefetcht1 pf_target_35_0(%rip)
prefetcht1 pf_target_35_1(%rip)
prefetcht1 pf_target_35_2(%rip)
prefetcht1 pf_target_35_3(%rip)
prefetcht1 pf_target_35_4(%rip)
prefetcht1 pf_target_35_5(%rip)
prefetcht1 pf_target_35_6(%rip)
prefetcht1 pf_target_35_7(%rip)
.global pf_jump_35
pf_jump_35:
jmp pf_callee_35
.cfi_endproc
.size pf_call_35,.-pf_call_35
.balign 16
.global pf_call_36
.type pf_call_36,@function
pf_call_36:
.cfi_startproc
prefetcht1 pf_target_36_0(%rip)
.global pf_jump_36
pf_jump_36:
jmp pf_callee_36
.cfi_endproc
.size pf_call_36,.-pf_call_36
.balign 32
.global pf_call_37
.type pf_call_37,@function
pf_call_37:
.cfi_startproc
prefetcht1 pf_target_37_0(%rip)
prefetcht1 pf_target_37_1(%rip)
prefetcht1 pf_target_37_2(%rip)
.global pf_jump_37
pf_jump_37:
jmp pf_callee_37
.cfi_endproc
.size pf_call_37,.-pf_call_37
.balign 32
.global pf_call_38
.type pf_call_38,@function
pf_call_38:
.cfi_startproc
prefetcht1 pf_target_38_0(%rip)
prefetcht1 pf_target_38_1(%rip)
prefetcht1 pf_target_38_2(%rip)
.global pf_jump_38
pf_jump_38:
jmp pf_callee_38
.cfi_endproc
.size pf_call_38,.-pf_call_38
.balign 16
.global pf_call_39
.type pf_call_39,@function
pf_call_39:
.cfi_startproc
prefetcht1 pf_target_39_0(%rip)
.global pf_jump_39
pf_jump_39:
jmp pf_callee_39
.cfi_endproc
.size pf_call_39,.-pf_call_39
.balign 32
.global pf_call_40
.type pf_call_40,@function
pf_call_40:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_40_0(%rip),%r11
.global pf_got_hint_40_0
pf_got_hint_40_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_40
pf_jump_40:
jmp pf_callee_40
.cfi_endproc
.size pf_call_40,.-pf_call_40
.section .note.GNU-stack,"",@progbits
