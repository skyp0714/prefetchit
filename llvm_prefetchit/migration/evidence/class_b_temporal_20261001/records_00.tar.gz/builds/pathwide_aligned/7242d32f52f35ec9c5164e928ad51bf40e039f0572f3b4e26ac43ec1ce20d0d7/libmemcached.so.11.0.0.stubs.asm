
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_aligned/7242d32f52f35ec9c5164e928ad51bf40e039f0572f3b4e26ac43ec1ce20d0d7/call-stub-28rcfh8c/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000312c0 <pf_call_0>:
   312c0:	0f 18 15 a9 5c fd ff 	prefetcht1 -0x2a357(%rip)        # 6f70 <pf_callee_17>
   312c7:	0f 18 15 e2 44 fe ff 	prefetcht1 -0x1bb1e(%rip)        # 157b0 <pf_callee_32>
   312ce:	0f 18 15 db e8 fd ff 	prefetcht1 -0x21725(%rip)        # fbb0 <pf_callee_20>
   312d5:	0f 18 15 25 e9 fd ff 	prefetcht1 -0x216db(%rip)        # fc01 <pf_target_0_3>
   312dc:	0f 18 15 dd e8 fd ff 	prefetcht1 -0x21723(%rip)        # fbc0 <pf_target_0_4>
   312e3:	0f 18 15 dc 44 fe ff 	prefetcht1 -0x1bb24(%rip)        # 157c6 <pf_target_0_5>

00000000000312ea <pf_jump_0>:
   312ea:	e9 81 41 fd ff       	jmp    5470 <pf_callee_0>
   312ef:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   312f6:	00 00 00 
   312f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000031300 <pf_call_1>:
   31300:	0f 18 15 d9 a9 fd ff 	prefetcht1 -0x25627(%rip)        # bce0 <pf_target_1_0>
   31307:	0f 18 15 22 a4 fd ff 	prefetcht1 -0x25bde(%rip)        # b730 <pf_target_1_1>
   3130e:	0f 18 15 5b 41 fd ff 	prefetcht1 -0x2bea5(%rip)        # 5470 <pf_callee_0>
   31315:	0f 18 15 54 40 fe ff 	prefetcht1 -0x1bfac(%rip)        # 15370 <pf_target_1_3>

000000000003131c <pf_jump_1>:
   3131c:	e9 ef 42 fd ff       	jmp    5610 <pf_callee_1>
   31321:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31328:	00 00 00 
   3132b:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31332:	00 00 00 
   31335:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3133c:	00 00 00 
   3133f:	90                   	nop

0000000000031340 <pf_call_2>:
   31340:	0f 18 15 7e a6 fd ff 	prefetcht1 -0x25982(%rip)        # b9c5 <pf_target_2_0>
   31347:	0f 18 15 c2 42 fd ff 	prefetcht1 -0x2bd3e(%rip)        # 5610 <pf_callee_1>
   3134e:	0f 18 15 0b a6 fd ff 	prefetcht1 -0x259f5(%rip)        # b960 <pf_callee_11>

0000000000031355 <pf_jump_2>:
   31355:	e9 06 d5 fe ff       	jmp    1e860 <pf_callee_10>
   3135a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031360 <pf_call_3>:
   31360:	0f 18 15 09 41 fd ff 	prefetcht1 -0x2bef7(%rip)        # 5470 <pf_callee_0>

0000000000031367 <pf_jump_3>:
   31367:	e9 f4 a5 fd ff       	jmp    b960 <pf_callee_11>
   3136c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31373:	00 00 00 
   31376:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3137d:	00 00 00 

0000000000031380 <pf_call_4>:
   31380:	0f 18 15 e9 f5 fd ff 	prefetcht1 -0x20a17(%rip)        # 10970 <pf_target_4_0>
   31387:	0f 18 15 2a 2d fe ff 	prefetcht1 -0x1d2d6(%rip)        # 140b8 <pf_target_27_4>
   3138e:	0f 18 15 cb 7b fe ff 	prefetcht1 -0x18435(%rip)        # 18f60 <pf_target_24_4>
   31395:	0f 18 15 e0 79 fe ff 	prefetcht1 -0x18620(%rip)        # 18d7c <pf_target_24_2>
   3139c:	0f 18 15 d5 b3 fd ff 	prefetcht1 -0x24c2b(%rip)        # c778 <pf_target_4_4>
   313a3:	0f 18 15 d6 f5 fd ff 	prefetcht1 -0x20a2a(%rip)        # 10980 <pf_target_4_5>
   313aa:	0f 18 15 26 2b fe ff 	prefetcht1 -0x1d4da(%rip)        # 13ed7 <pf_target_24_0>
   313b1:	0f 18 15 cf 79 fe ff 	prefetcht1 -0x18631(%rip)        # 18d87 <pf_target_24_3>

00000000000313b8 <pf_jump_4>:
   313b8:	e9 53 42 fd ff       	jmp    5610 <pf_callee_1>
   313bd:	0f 1f 00             	nopl   (%rax)

00000000000313c0 <pf_call_5>:
   313c0:	0f 18 15 ba 26 fe ff 	prefetcht1 -0x1d946(%rip)        # 13a81 <pf_target_5_0>
   313c7:	0f 18 15 3a b2 fd ff 	prefetcht1 -0x24dc6(%rip)        # c608 <pf_target_5_1>
   313ce:	0f 18 15 2d 1f fe ff 	prefetcht1 -0x1e0d3(%rip)        # 13302 <pf_target_5_2>
   313d5:	0f 18 15 a4 1f fe ff 	prefetcht1 -0x1e05c(%rip)        # 13380 <pf_target_5_3>

00000000000313dc <pf_jump_5>:
   313dc:	e9 ff 40 fd ff       	jmp    54e0 <pf_callee_5>
   313e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   313e8:	00 00 00 
   313eb:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   313f2:	00 00 00 
   313f5:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   313fc:	00 00 00 
   313ff:	90                   	nop

0000000000031400 <pf_call_6>:
   31400:	0f 18 15 8f 5b fd ff 	prefetcht1 -0x2a471(%rip)        # 6f96 <pf_target_6_0>
   31407:	0f 18 15 b3 5b fd ff 	prefetcht1 -0x2a44d(%rip)        # 6fc1 <pf_target_6_1>
   3140e:	0f 18 15 f6 f4 fd ff 	prefetcht1 -0x20b0a(%rip)        # 1090b <pf_target_6_2>

0000000000031415 <pf_jump_6>:
   31415:	e9 a6 b1 fd ff       	jmp    c5c0 <pf_callee_6>
   3141a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031420 <pf_call_7>:
   31420:	0f 18 15 dd a5 fd ff 	prefetcht1 -0x25a23(%rip)        # ba04 <pf_target_7_0>

0000000000031427 <pf_jump_7>:
   31427:	e9 c4 3d fe ff       	jmp    151f0 <pf_callee_12>
   3142c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31433:	00 00 00 
   31436:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3143d:	00 00 00 

0000000000031440 <pf_call_8>:
   31440:	0f 18 15 65 d7 fd ff 	prefetcht1 -0x2289b(%rip)        # ebac <pf_target_8_0>
   31447:	0f 18 15 d1 e0 fd ff 	prefetcht1 -0x21f2f(%rip)        # f51f <pf_target_8_1>

000000000003144e <pf_jump_8>:
   3144e:	e9 fd cf fd ff       	jmp    e450 <pf_callee_16>
   31453:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3145a:	00 00 00 
   3145d:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31464:	00 00 00 
   31467:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3146e:	00 00 00 
   31471:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31478:	00 00 00 
   3147b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031480 <pf_call_9>:
   31480:	0f 18 15 98 e0 fd ff 	prefetcht1 -0x21f68(%rip)        # f51f <pf_target_8_1>
   31487:	0f 18 15 c2 c9 fd ff 	prefetcht1 -0x2363e(%rip)        # de50 <pf_callee_13>
   3148e:	0f 18 15 ec d3 fe ff 	prefetcht1 -0x12c14(%rip)        # 1e881 <pf_target_35_5>
   31495:	0f 18 15 c4 d3 fe ff 	prefetcht1 -0x12c3c(%rip)        # 1e860 <pf_callee_10>
   3149c:	0f 18 15 e0 82 fd ff 	prefetcht1 -0x27d20(%rip)        # 9783 <pf_target_33_3>

00000000000314a3 <pf_jump_9>:
   314a3:	e9 a8 cf fd ff       	jmp    e450 <pf_callee_16>
   314a8:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   314af:	00 00 00 
   314b2:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   314b9:	00 00 00 
   314bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000314c0 <pf_call_10>:
   314c0:	0f 18 15 a9 df fd ff 	prefetcht1 -0x22057(%rip)        # f470 <pf_target_10_0>
   314c7:	0f 18 15 42 41 fd ff 	prefetcht1 -0x2bebe(%rip)        # 5610 <pf_callee_1>
   314ce:	0f 18 15 02 e0 fd ff 	prefetcht1 -0x21ffe(%rip)        # f4d7 <pf_target_10_2>

00000000000314d5 <pf_jump_10>:
   314d5:	e9 86 d3 fe ff       	jmp    1e860 <pf_callee_10>
   314da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000314e0 <pf_call_11>:
   314e0:	0f 18 15 50 de fd ff 	prefetcht1 -0x221b0(%rip)        # f337 <pf_target_11_0>
   314e7:	0f 18 15 7a de fd ff 	prefetcht1 -0x22186(%rip)        # f368 <pf_target_11_1>

00000000000314ee <pf_jump_11>:
   314ee:	e9 6d a4 fd ff       	jmp    b960 <pf_callee_11>
   314f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   314fa:	00 00 00 
   314fd:	0f 1f 00             	nopl   (%rax)

0000000000031500 <pf_call_12>:
   31500:	0f 18 15 79 e4 fd ff 	prefetcht1 -0x21b87(%rip)        # f980 <pf_target_12_0>
   31507:	0f 18 15 b2 e4 fd ff 	prefetcht1 -0x21b4e(%rip)        # f9c0 <pf_target_12_1>
   3150e:	0f 18 15 9b e6 fd ff 	prefetcht1 -0x21965(%rip)        # fbb0 <pf_callee_20>
   31515:	0f 18 15 e5 e6 fd ff 	prefetcht1 -0x2191b(%rip)        # fc01 <pf_target_0_3>

000000000003151c <pf_jump_12>:
   3151c:	e9 cf 3c fe ff       	jmp    151f0 <pf_callee_12>
   31521:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31528:	00 00 00 
   3152b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031530 <pf_call_13>:
   31530:	0f 18 15 a0 df fd ff 	prefetcht1 -0x22060(%rip)        # f4d7 <pf_target_10_2>

0000000000031537 <pf_jump_13>:
   31537:	e9 14 c9 fd ff       	jmp    de50 <pf_callee_13>
   3153c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031540 <pf_call_14>:
   31540:	0f 18 15 c9 3a fe ff 	prefetcht1 -0x1c537(%rip)        # 15010 <pf_target_14_0>
   31547:	0f 18 15 fa 1a fe ff 	prefetcht1 -0x1e506(%rip)        # 13048 <pf_target_14_1>
   3154e:	0f 18 15 db 1a fe ff 	prefetcht1 -0x1e525(%rip)        # 13030 <pf_callee_29>
   31555:	41 53                	push   %r11
   31557:	4c 8b 1d 1a eb ff ff 	mov    -0x14e6(%rip),%r11        # 30078 <pf_got_14_0>

000000000003155e <pf_got_hint_14_0>:
   3155e:	41 0f 18 93 1a 03 00 	prefetcht1 0x31a(%r11)
   31565:	00 

0000000000031566 <pf_got_hint_14_1>:
   31566:	41 0f 18 93 ed 04 00 	prefetcht1 0x4ed(%r11)
   3156d:	00 

000000000003156e <pf_got_hint_14_2>:
   3156e:	41 0f 18 93 23 05 00 	prefetcht1 0x523(%r11)
   31575:	00 

0000000000031576 <pf_got_hint_14_3>:
   31576:	41 0f 18 93 00 07 00 	prefetcht1 0x700(%r11)
   3157d:	00 
   3157e:	41 5b                	pop    %r11

0000000000031580 <pf_jump_14>:
   31580:	e9 ab 3f fd ff       	jmp    5530 <pf_callee_14>
   31585:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3158c:	00 00 00 
   3158f:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31596:	00 00 00 
   31599:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   315a0:	00 00 00 
   315a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   315aa:	00 00 00 
   315ad:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   315b4:	00 00 00 
   315b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   315be:	00 00 

00000000000315c0 <pf_call_15>:
   315c0:	0f 18 15 89 ce fd ff 	prefetcht1 -0x23177(%rip)        # e450 <pf_callee_16>
   315c7:	0f 18 15 00 76 fe ff 	prefetcht1 -0x18a00(%rip)        # 18bce <pf_target_15_1>
   315ce:	0f 18 15 ae ce fd ff 	prefetcht1 -0x23152(%rip)        # e483 <pf_target_15_2>
   315d5:	0f 18 15 8e 76 fe ff 	prefetcht1 -0x18972(%rip)        # 18c6a <pf_target_15_3>
   315dc:	0f 18 15 7a cf fd ff 	prefetcht1 -0x23086(%rip)        # e55d <pf_target_15_4>

00000000000315e3 <pf_jump_15>:
   315e3:	e9 98 1c fe ff       	jmp    13280 <pf_callee_15>
   315e8:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   315ef:	00 00 00 
   315f2:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   315f9:	00 00 00 
   315fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031600 <pf_call_16>:
   31600:	0f 18 15 7a a9 fd ff 	prefetcht1 -0x25686(%rip)        # bf81 <pf_target_16_0>
   31607:	0f 18 15 22 a9 fd ff 	prefetcht1 -0x256de(%rip)        # bf30 <pf_target_16_1>
   3160e:	0f 18 15 b0 f2 fd ff 	prefetcht1 -0x20d50(%rip)        # 108c5 <pf_target_16_2>
   31615:	0f 18 15 25 a9 fd ff 	prefetcht1 -0x256db(%rip)        # bf41 <pf_target_16_3>

000000000003161c <pf_jump_16>:
   3161c:	e9 2f ce fd ff       	jmp    e450 <pf_callee_16>
   31621:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31628:	00 00 00 
   3162b:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31632:	00 00 00 
   31635:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3163c:	00 00 00 
   3163f:	90                   	nop

0000000000031640 <pf_call_17>:
   31640:	0f 18 15 09 52 fe ff 	prefetcht1 -0x1adf7(%rip)        # 16850 <pf_target_17_0>
   31647:	0f 18 15 34 52 fe ff 	prefetcht1 -0x1adcc(%rip)        # 16882 <pf_target_17_1>

000000000003164e <pf_jump_17>:
   3164e:	e9 1d 59 fd ff       	jmp    6f70 <pf_callee_17>
   31653:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3165a:	00 00 00 
   3165d:	0f 1f 00             	nopl   (%rax)

0000000000031660 <pf_call_18>:
   31660:	0f 18 15 29 f0 fd ff 	prefetcht1 -0x20fd7(%rip)        # 10690 <pf_callee_19>

0000000000031667 <pf_jump_18>:
   31667:	e9 04 f1 fd ff       	jmp    10770 <pf_callee_18>
   3166c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31673:	00 00 00 
   31676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3167d:	00 00 00 

0000000000031680 <pf_call_19>:
   31680:	0f 18 15 bb d0 fd ff 	prefetcht1 -0x22f45(%rip)        # e742 <pf_target_19_0>
   31687:	0f 18 15 62 d0 fd ff 	prefetcht1 -0x22f9e(%rip)        # e6f0 <pf_target_19_1>
   3168e:	0f 18 15 eb 1b fe ff 	prefetcht1 -0x1e415(%rip)        # 13280 <pf_callee_15>
   31695:	0f 18 15 68 d0 fd ff 	prefetcht1 -0x22f98(%rip)        # e704 <pf_target_19_3>
   3169c:	0f 18 15 e0 cd fd ff 	prefetcht1 -0x23220(%rip)        # e483 <pf_target_15_2>

00000000000316a3 <pf_jump_19>:
   316a3:	e9 e8 ef fd ff       	jmp    10690 <pf_callee_19>
   316a8:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   316af:	00 00 00 
   316b2:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   316b9:	00 00 00 
   316bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000316c0 <pf_call_20>:
   316c0:	0f 18 15 b9 6b fe ff 	prefetcht1 -0x19447(%rip)        # 18280 <pf_target_20_0>
   316c7:	0f 18 15 b2 e2 fd ff 	prefetcht1 -0x21d4e(%rip)        # f980 <pf_target_12_0>
   316ce:	0f 18 15 eb e2 fd ff 	prefetcht1 -0x21d15(%rip)        # f9c0 <pf_target_12_1>

00000000000316d5 <pf_jump_20>:
   316d5:	e9 d6 e4 fd ff       	jmp    fbb0 <pf_callee_20>
   316da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000316e0 <pf_call_21>:
   316e0:	0f 18 15 a9 ef fd ff 	prefetcht1 -0x21057(%rip)        # 10690 <pf_callee_19>

00000000000316e7 <pf_jump_21>:
   316e7:	e9 44 03 fe ff       	jmp    11a30 <pf_callee_21>
   316ec:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   316f3:	00 00 00 
   316f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   316fd:	00 00 00 

0000000000031700 <pf_call_22>:
   31700:	41 53                	push   %r11
   31702:	4c 8b 1d 1f eb ff ff 	mov    -0x14e1(%rip),%r11        # 30228 <pf_got_22_0>

0000000000031709 <pf_got_hint_22_0>:
   31709:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   31710:	00 
   31711:	41 5b                	pop    %r11

0000000000031713 <pf_jump_22>:
   31713:	e9 38 40 fd ff       	jmp    5750 <pf_callee_22>
   31718:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   3171f:	00 

0000000000031720 <pf_call_23>:
   31720:	0f 18 15 d9 93 fd ff 	prefetcht1 -0x26c27(%rip)        # ab00 <pf_target_23_0>
   31727:	0f 18 15 16 94 fd ff 	prefetcht1 -0x26bea(%rip)        # ab44 <pf_target_23_1>
   3172e:	0f 18 15 97 b0 fd ff 	prefetcht1 -0x24f69(%rip)        # c7cc <pf_target_23_2>

0000000000031735 <pf_jump_23>:
   31735:	e9 46 b1 fd ff       	jmp    c880 <pf_callee_23>
   3173a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031740 <pf_call_24>:
   31740:	0f 18 15 90 27 fe ff 	prefetcht1 -0x1d870(%rip)        # 13ed7 <pf_target_24_0>
   31747:	0f 18 15 74 22 fe ff 	prefetcht1 -0x1dd8c(%rip)        # 139c2 <pf_target_24_1>
   3174e:	0f 18 15 27 76 fe ff 	prefetcht1 -0x189d9(%rip)        # 18d7c <pf_target_24_2>
   31755:	0f 18 15 2b 76 fe ff 	prefetcht1 -0x189d5(%rip)        # 18d87 <pf_target_24_3>
   3175c:	0f 18 15 fd 77 fe ff 	prefetcht1 -0x18803(%rip)        # 18f60 <pf_target_24_4>
   31763:	0f 18 15 18 7b fe ff 	prefetcht1 -0x184e8(%rip)        # 19282 <pf_target_24_5>

000000000003176a <pf_jump_24>:
   3176a:	e9 11 b1 fd ff       	jmp    c880 <pf_callee_23>
   3176f:	90                   	nop

0000000000031770 <pf_call_25>:
   31770:	0f 18 15 49 ae fd ff 	prefetcht1 -0x251b7(%rip)        # c5c0 <pf_callee_6>

0000000000031777 <pf_jump_25>:
   31777:	e9 04 1b fe ff       	jmp    13280 <pf_callee_15>
   3177c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031780 <pf_call_26>:
   31780:	0f 18 15 49 53 fd ff 	prefetcht1 -0x2acb7(%rip)        # 6ad0 <pf_target_26_0>
   31787:	0f 18 15 93 23 fe ff 	prefetcht1 -0x1dc6d(%rip)        # 13b21 <pf_target_26_1>
   3178e:	41 53                	push   %r11
   31790:	4c 8b 1d 49 ea ff ff 	mov    -0x15b7(%rip),%r11        # 301e0 <pf_got_26_0>

0000000000031797 <pf_got_hint_26_0>:
   31797:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   3179e:	00 
   3179f:	41 5b                	pop    %r11

00000000000317a1 <pf_jump_26>:
   317a1:	e9 da b0 fd ff       	jmp    c880 <pf_callee_23>
   317a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   317ad:	00 00 00 
   317b0:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   317b7:	00 00 00 
   317ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000317c0 <pf_call_27>:
   317c0:	0f 18 15 69 18 fe ff 	prefetcht1 -0x1e797(%rip)        # 13030 <pf_callee_29>
   317c7:	0f 18 15 42 38 fe ff 	prefetcht1 -0x1c7be(%rip)        # 15010 <pf_target_14_0>
   317ce:	0f 18 15 af 18 fe ff 	prefetcht1 -0x1e751(%rip)        # 13084 <pf_target_27_2>
   317d5:	0f 18 15 6c 18 fe ff 	prefetcht1 -0x1e794(%rip)        # 13048 <pf_target_14_1>
   317dc:	0f 18 15 d5 28 fe ff 	prefetcht1 -0x1d72b(%rip)        # 140b8 <pf_target_27_4>
   317e3:	0f 18 15 2d e2 fd ff 	prefetcht1 -0x21dd3(%rip)        # fa17 <pf_target_27_5>
   317ea:	41 53                	push   %r11
   317ec:	4c 8b 1d 85 e8 ff ff 	mov    -0x177b(%rip),%r11        # 30078 <pf_got_14_0>

00000000000317f3 <pf_got_hint_27_0>:
   317f3:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   317fa:	00 

00000000000317fb <pf_got_hint_27_1>:
   317fb:	41 0f 18 93 10 00 00 	prefetcht1 0x10(%r11)
   31802:	00 
   31803:	41 5b                	pop    %r11

0000000000031805 <pf_jump_27>:
   31805:	e9 76 b0 fd ff       	jmp    c880 <pf_callee_23>
   3180a:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31811:	00 00 00 
   31814:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3181b:	00 00 00 
   3181e:	66 90                	xchg   %ax,%ax

0000000000031820 <pf_call_28>:
   31820:	0f 18 15 31 58 fd ff 	prefetcht1 -0x2a7cf(%rip)        # 7058 <pf_target_28_0>
   31827:	0f 18 15 68 50 fe ff 	prefetcht1 -0x1af98(%rip)        # 16896 <pf_target_28_1>

000000000003182e <pf_jump_28>:
   3182e:	e9 4d b0 fd ff       	jmp    c880 <pf_callee_23>
   31833:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3183a:	00 00 00 
   3183d:	0f 1f 00             	nopl   (%rax)

0000000000031840 <pf_call_29>:
   31840:	0f 18 15 3e 03 fe ff 	prefetcht1 -0x1fcc2(%rip)        # 11b85 <pf_target_29_0>

0000000000031847 <pf_jump_29>:
   31847:	e9 e4 17 fe ff       	jmp    13030 <pf_callee_29>
   3184c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31853:	00 00 00 
   31856:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3185d:	00 00 00 

0000000000031860 <pf_call_30>:
   31860:	0f 18 15 1e 3e fe ff 	prefetcht1 -0x1c1e2(%rip)        # 15685 <pf_target_30_0>
   31867:	0f 18 15 54 26 fe ff 	prefetcht1 -0x1d9ac(%rip)        # 13ec2 <pf_target_30_1>

000000000003186e <pf_jump_30>:
   3186e:	e9 ed a0 fd ff       	jmp    b960 <pf_callee_11>
   31873:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3187a:	00 00 00 
   3187d:	0f 1f 00             	nopl   (%rax)

0000000000031880 <pf_call_31>:
   31880:	0f 18 15 f9 af fd ff 	prefetcht1 -0x25007(%rip)        # c880 <pf_callee_23>
   31887:	0f 18 15 32 b0 fd ff 	prefetcht1 -0x24fce(%rip)        # c8c0 <pf_target_31_1>
   3188e:	0f 18 15 eb 25 fe ff 	prefetcht1 -0x1da15(%rip)        # 13e80 <pf_target_31_2>
   31895:	0f 18 15 24 ad fd ff 	prefetcht1 -0x252dc(%rip)        # c5c0 <pf_callee_6>

000000000003189c <pf_jump_31>:
   3189c:	e9 4f 39 fe ff       	jmp    151f0 <pf_callee_12>
   318a1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   318a8:	00 00 00 
   318ab:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   318b2:	00 00 00 
   318b5:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   318bc:	00 00 00 
   318bf:	90                   	nop

00000000000318c0 <pf_call_32>:
   318c0:	0f 18 15 f9 ac fd ff 	prefetcht1 -0x25307(%rip)        # c5c0 <pf_callee_6>
   318c7:	0f 18 15 b2 af fd ff 	prefetcht1 -0x2504e(%rip)        # c880 <pf_callee_23>
   318ce:	0f 18 15 ab 25 fe ff 	prefetcht1 -0x1da55(%rip)        # 13e80 <pf_target_31_2>
   318d5:	0f 18 15 e4 af fd ff 	prefetcht1 -0x2501c(%rip)        # c8c0 <pf_target_31_1>

00000000000318dc <pf_jump_32>:
   318dc:	e9 cf 3e fe ff       	jmp    157b0 <pf_callee_32>
   318e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   318e8:	00 00 00 
   318eb:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   318f2:	00 00 00 
   318f5:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   318fc:	00 00 00 
   318ff:	90                   	nop

0000000000031900 <pf_call_33>:
   31900:	0f 18 15 49 c5 fd ff 	prefetcht1 -0x23ab7(%rip)        # de50 <pf_callee_13>
   31907:	0f 18 15 72 19 fe ff 	prefetcht1 -0x1e68e(%rip)        # 13280 <pf_callee_15>
   3190e:	0f 18 15 53 c6 fd ff 	prefetcht1 -0x239ad(%rip)        # df68 <pf_target_33_2>
   31915:	0f 18 15 67 7e fd ff 	prefetcht1 -0x28199(%rip)        # 9783 <pf_target_33_3>
   3191c:	0f 18 15 4d 7e fd ff 	prefetcht1 -0x281b3(%rip)        # 9770 <pf_target_33_4>
   31923:	0f 18 15 c6 38 fe ff 	prefetcht1 -0x1c73a(%rip)        # 151f0 <pf_callee_12>
   3192a:	0f 18 15 cf 76 fe ff 	prefetcht1 -0x18931(%rip)        # 19000 <pf_target_33_6>

0000000000031931 <pf_jump_33>:
   31931:	e9 5a ed fd ff       	jmp    10690 <pf_callee_19>
   31936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3193d:	00 00 00 

0000000000031940 <pf_call_34>:
   31940:	0f 18 15 79 cf fe ff 	prefetcht1 -0x13087(%rip)        # 1e8c0 <pf_target_34_0>

0000000000031947 <pf_jump_34>:
   31947:	e9 04 cb fd ff       	jmp    e450 <pf_callee_16>
   3194c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31953:	00 00 00 
   31956:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3195d:	00 00 00 
   31960:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31967:	00 00 00 
   3196a:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31971:	00 00 00 
   31974:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3197b:	00 00 00 
   3197e:	66 90                	xchg   %ax,%ax

0000000000031980 <pf_call_35>:
   31980:	0f 18 15 a9 71 fe ff 	prefetcht1 -0x18e57(%rip)        # 18b30 <pf_target_35_0>
   31987:	0f 18 15 f4 71 fe ff 	prefetcht1 -0x18e0c(%rip)        # 18b82 <pf_target_35_1>
   3198e:	0f 18 15 2b a1 fd ff 	prefetcht1 -0x25ed5(%rip)        # bac0 <pf_target_35_2>
   31995:	0f 18 15 84 73 fe ff 	prefetcht1 -0x18c7c(%rip)        # 18d20 <pf_target_35_3>
   3199c:	0f 18 15 bd ce fe ff 	prefetcht1 -0x13143(%rip)        # 1e860 <pf_callee_10>
   319a3:	0f 18 15 d7 ce fe ff 	prefetcht1 -0x13129(%rip)        # 1e881 <pf_target_35_5>
   319aa:	0f 18 15 91 71 fe ff 	prefetcht1 -0x18e6f(%rip)        # 18b42 <pf_target_35_6>
   319b1:	0f 18 15 8a 73 fe ff 	prefetcht1 -0x18c76(%rip)        # 18d42 <pf_target_35_7>

00000000000319b8 <pf_jump_35>:
   319b8:	e9 93 c4 fd ff       	jmp    de50 <pf_callee_13>
   319bd:	0f 1f 00             	nopl   (%rax)

00000000000319c0 <pf_call_36>:
   319c0:	0f 18 15 c9 ec fd ff 	prefetcht1 -0x21337(%rip)        # 10690 <pf_callee_19>

00000000000319c7 <pf_jump_36>:
   319c7:	e9 24 75 fe ff       	jmp    18ef0 <pf_callee_36>
   319cc:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   319d3:	00 00 00 
   319d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   319dd:	00 00 00 

00000000000319e0 <pf_call_37>:
   319e0:	0f 18 15 c1 d5 fe ff 	prefetcht1 -0x12a3f(%rip)        # 1efa8 <pf_target_37_0>
   319e7:	0f 18 15 82 d5 fe ff 	prefetcht1 -0x12a7e(%rip)        # 1ef70 <pf_target_37_1>
   319ee:	0f 18 15 d1 d5 fe ff 	prefetcht1 -0x12a2f(%rip)        # 1efc6 <pf_target_37_2>

00000000000319f5 <pf_jump_37>:
   319f5:	e9 e6 3d fd ff       	jmp    57e0 <pf_callee_37>
   319fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031a00 <pf_call_38>:
   31a00:	0f 18 15 7a d6 fe ff 	prefetcht1 -0x12986(%rip)        # 1f081 <pf_target_38_0>
   31a07:	0f 18 15 02 e0 fe ff 	prefetcht1 -0x11ffe(%rip)        # 1fa10 <pf_target_38_1>
   31a0e:	0f 18 15 41 d6 fe ff 	prefetcht1 -0x129bf(%rip)        # 1f056 <pf_target_38_2>

0000000000031a15 <pf_jump_38>:
   31a15:	e9 56 3a fd ff       	jmp    5470 <pf_callee_0>
   31a1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031a20 <pf_call_39>:
   31a20:	0f 18 15 5a a0 fd ff 	prefetcht1 -0x25fa6(%rip)        # ba81 <pf_target_39_0>

0000000000031a27 <pf_jump_39>:
   31a27:	e9 84 3d fd ff       	jmp    57b0 <pf_callee_39>
   31a2c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31a33:	00 00 00 
   31a36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31a3d:	00 00 00 

0000000000031a40 <pf_call_40>:
   31a40:	41 53                	push   %r11
   31a42:	4c 8b 1d a7 e6 ff ff 	mov    -0x1959(%rip),%r11        # 300f0 <pf_got_40_0>

0000000000031a49 <pf_got_hint_40_0>:
   31a49:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   31a50:	00 
   31a51:	41 5b                	pop    %r11

0000000000031a53 <pf_jump_40>:
   31a53:	e9 e8 3d fd ff       	jmp    5840 <pf_callee_40>
