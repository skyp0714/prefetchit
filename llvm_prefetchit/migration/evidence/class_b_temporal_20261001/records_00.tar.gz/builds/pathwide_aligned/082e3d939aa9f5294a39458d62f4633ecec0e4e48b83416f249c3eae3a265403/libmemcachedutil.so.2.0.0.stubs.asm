
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_aligned/082e3d939aa9f5294a39458d62f4633ecec0e4e48b83416f249c3eae3a265403/call-stub-8g4_nf3l/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000072c0 <pf_call_0>:
    72c0:	0f 18 15 d9 b0 ff ff 	prefetcht1 -0x4f27(%rip)        # 23a0 <pf_target_0_0>
    72c7:	0f 18 15 f2 af ff ff 	prefetcht1 -0x500e(%rip)        # 22c0 <pf_target_0_1>

00000000000072ce <pf_jump_0>:
    72ce:	e9 6d b2 ff ff       	jmp    2540 <pf_callee_0>
