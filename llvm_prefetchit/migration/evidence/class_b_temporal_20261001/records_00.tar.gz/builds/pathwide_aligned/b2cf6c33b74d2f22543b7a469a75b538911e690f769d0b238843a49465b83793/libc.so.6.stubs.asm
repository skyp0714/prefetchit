
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_aligned/b2cf6c33b74d2f22543b7a469a75b538911e690f769d0b238843a49465b83793/call-stub-tlbaipkc/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000229380 <pf_call_0>:
  229380:	0f 18 15 fc d1 e4 ff 	prefetcht1 -0x1b2e04(%rip)        # 76583 <pf_target_0_0>
  229387:	0f 18 15 73 e1 e4 ff 	prefetcht1 -0x1b1e8d(%rip)        # 77501 <pf_target_0_1>
  22938e:	0f 18 15 6d dc e4 ff 	prefetcht1 -0x1b2393(%rip)        # 77002 <pf_target_0_2>
  229395:	0f 18 15 c1 d1 e4 ff 	prefetcht1 -0x1b2e3f(%rip)        # 7655d <pf_target_0_3>
  22939c:	0f 18 15 dd 4b e6 ff 	prefetcht1 -0x19b423(%rip)        # 8df80 <pf_target_0_4>

00000000002293a3 <pf_jump_0>:
  2293a3:	e9 88 0e e3 ff       	jmp    5a230 <pf_callee_0>
  2293a8:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2293af:	00 00 00 
  2293b2:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2293b9:	00 00 00 
  2293bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002293c0 <pf_call_1>:
  2293c0:	0f 18 15 79 82 f8 ff 	prefetcht1 -0x77d87(%rip)        # 1b1640 <pf_target_1_0>
  2293c7:	0f 18 15 12 48 e6 ff 	prefetcht1 -0x19b7ee(%rip)        # 8dbe0 <pf_target_1_1>
  2293ce:	0f 18 15 2b bc e4 ff 	prefetcht1 -0x1b43d5(%rip)        # 75000 <pf_target_1_2>
  2293d5:	0f 18 15 c4 51 e6 ff 	prefetcht1 -0x19ae3c(%rip)        # 8e5a0 <pf_callee_3>
  2293dc:	0f 18 15 0d bc e4 ff 	prefetcht1 -0x1b43f3(%rip)        # 74ff0 <pf_callee_2>
  2293e3:	0f 18 15 86 65 e6 ff 	prefetcht1 -0x199a7a(%rip)        # 8f970 <pf_target_1_5>
  2293ea:	0f 18 15 8f 65 e6 ff 	prefetcht1 -0x199a71(%rip)        # 8f980 <pf_target_1_6>
  2293f1:	0f 18 15 89 82 f8 ff 	prefetcht1 -0x77d77(%rip)        # 1b1681 <pf_target_1_7>

00000000002293f8 <pf_jump_1>:
  2293f8:	e9 13 52 e6 ff       	jmp    8e610 <pf_callee_1>
  2293fd:	0f 1f 00             	nopl   (%rax)

0000000000229400 <pf_call_2>:
  229400:	0f 18 15 e2 d8 e4 ff 	prefetcht1 -0x1b271e(%rip)        # 76ce9 <pf_target_2_0>
  229407:	0f 18 15 92 db e4 ff 	prefetcht1 -0x1b246e(%rip)        # 76fa0 <pf_target_2_1>
  22940e:	0f 18 15 3b cc e4 ff 	prefetcht1 -0x1b33c5(%rip)        # 76050 <pf_target_2_2>
  229415:	0f 18 15 b4 c2 e4 ff 	prefetcht1 -0x1b3d4c(%rip)        # 756d0 <pf_target_2_3>
  22941c:	0f 18 15 d5 db e4 ff 	prefetcht1 -0x1b242b(%rip)        # 76ff8 <pf_target_2_4>
  229423:	0f 18 15 06 0e e3 ff 	prefetcht1 -0x1cf1fa(%rip)        # 5a230 <pf_callee_0>
  22942a:	0f 18 15 0f 0e e3 ff 	prefetcht1 -0x1cf1f1(%rip)        # 5a240 <pf_target_2_6>
  229431:	0f 18 15 28 4b e6 ff 	prefetcht1 -0x19b4d8(%rip)        # 8df60 <pf_target_2_7>

0000000000229438 <pf_jump_2>:
  229438:	e9 b3 bb e4 ff       	jmp    74ff0 <pf_callee_2>
  22943d:	0f 1f 00             	nopl   (%rax)

0000000000229440 <pf_call_3>:
  229440:	0f 18 15 f9 bb e4 ff 	prefetcht1 -0x1b4407(%rip)        # 75040 <pf_target_3_0>
  229447:	0f 18 15 b3 47 e6 ff 	prefetcht1 -0x19b84d(%rip)        # 8dc01 <pf_target_3_1>
  22944e:	0f 18 15 d5 c5 e4 ff 	prefetcht1 -0x1b3a2b(%rip)        # 75a2a <pf_target_3_2>
  229455:	0f 18 15 67 c0 e4 ff 	prefetcht1 -0x1b3f99(%rip)        # 754c3 <pf_target_3_3>

000000000022945c <pf_jump_3>:
  22945c:	e9 3f 51 e6 ff       	jmp    8e5a0 <pf_callee_3>
  229461:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229468:	00 00 00 
  22946b:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229472:	00 00 00 
  229475:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22947c:	00 00 00 
  22947f:	90                   	nop

0000000000229480 <pf_call_4>:
  229480:	0f 18 15 16 ae e6 ff 	prefetcht1 -0x1951ea(%rip)        # 9429d <pf_target_4_0>
  229487:	0f 18 15 a9 d0 e6 ff 	prefetcht1 -0x192f57(%rip)        # 96537 <pf_target_4_1>
  22948e:	0f 18 15 4f d1 e6 ff 	prefetcht1 -0x192eb1(%rip)        # 965e4 <pf_target_4_2>
  229495:	0f 18 15 64 d1 e6 ff 	prefetcht1 -0x192e9c(%rip)        # 96600 <pf_target_4_3>
  22949c:	0f 18 15 5e a5 e6 ff 	prefetcht1 -0x195aa2(%rip)        # 93a01 <pf_target_4_4>
  2294a3:	0f 18 15 d1 ac e6 ff 	prefetcht1 -0x19532f(%rip)        # 9417b <pf_target_4_5>
  2294aa:	0f 18 15 97 d0 e6 ff 	prefetcht1 -0x192f69(%rip)        # 96548 <pf_target_4_6>

00000000002294b1 <pf_jump_4>:
  2294b1:	e9 6a 75 e6 ff       	jmp    90a20 <pf_callee_28>
  2294b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2294bd:	00 00 00 

00000000002294c0 <pf_call_5>:
  2294c0:	0f 18 15 39 7b e6 ff 	prefetcht1 -0x1984c7(%rip)        # 91000 <pf_target_5_0>

00000000002294c7 <pf_jump_5>:
  2294c7:	e9 44 04 e7 ff       	jmp    99910 <pf_callee_5>
  2294cc:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2294d3:	00 00 00 
  2294d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2294dd:	00 00 00 

00000000002294e0 <pf_call_6>:
  2294e0:	0f 18 15 d9 a3 e6 ff 	prefetcht1 -0x195c27(%rip)        # 938c0 <pf_target_6_0>
  2294e7:	0f 18 15 bc a3 e6 ff 	prefetcht1 -0x195c44(%rip)        # 938aa <pf_target_6_1>

00000000002294ee <pf_jump_6>:
  2294ee:	e9 cd 75 e6 ff       	jmp    90ac0 <pf_callee_18>
  2294f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2294fa:	00 00 00 
  2294fd:	0f 1f 00             	nopl   (%rax)

0000000000229500 <pf_call_7>:
  229500:	0f 18 15 e9 7a e6 ff 	prefetcht1 -0x198517(%rip)        # 90ff0 <pf_target_24_6>
  229507:	0f 18 15 f5 7a e6 ff 	prefetcht1 -0x19850b(%rip)        # 91003 <pf_target_7_1>

000000000022950e <pf_jump_7>:
  22950e:	e9 fd 03 e7 ff       	jmp    99910 <pf_callee_5>
  229513:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22951a:	00 00 00 
  22951d:	0f 1f 00             	nopl   (%rax)

0000000000229520 <pf_call_8>:
  229520:	0f 18 15 54 ac e6 ff 	prefetcht1 -0x1953ac(%rip)        # 9417b <pf_target_4_5>
  229527:	0f 18 15 55 ac e6 ff 	prefetcht1 -0x1953ab(%rip)        # 94183 <pf_target_8_1>
  22952e:	0f 18 15 2b dc e6 ff 	prefetcht1 -0x1923d5(%rip)        # 97160 <pf_target_8_2>

0000000000229535 <pf_jump_8>:
  229535:	e9 86 75 e6 ff       	jmp    90ac0 <pf_callee_18>
  22953a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229540 <pf_call_9>:
  229540:	0f 18 15 09 c5 ef ff 	prefetcht1 -0x103af7(%rip)        # 125a50 <pf_target_9_0>
  229547:	0f 18 15 62 d3 ef ff 	prefetcht1 -0x102c9e(%rip)        # 1268b0 <pf_target_9_1>
  22954e:	0f 18 15 6c d3 ef ff 	prefetcht1 -0x102c94(%rip)        # 1268c1 <pf_target_9_2>
  229555:	0f 18 15 28 c5 ef ff 	prefetcht1 -0x103ad8(%rip)        # 125a84 <pf_target_9_3>

000000000022955c <pf_jump_9>:
  22955c:	e9 9f d3 ef ff       	jmp    126900 <pf_callee_9>
  229561:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229568:	00 00 00 
  22956b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229570 <pf_call_10>:
  229570:	0f 18 15 ca b4 e6 ff 	prefetcht1 -0x194b36(%rip)        # 94a41 <pf_target_10_0>

0000000000229577 <pf_jump_10>:
  229577:	e9 44 0e e1 ff       	jmp    3a3c0 <pf_callee_10>
  22957c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229580 <pf_call_11>:
  229580:	0f 18 15 59 73 e6 ff 	prefetcht1 -0x198ca7(%rip)        # 908e0 <pf_target_11_0>
  229587:	0f 18 15 42 88 f2 ff 	prefetcht1 -0xd77be(%rip)        # 151dd0 <pf_target_11_1>
  22958e:	0f 18 15 2c f3 f3 ff 	prefetcht1 -0xc0cd4(%rip)        # 1688c1 <pf_target_11_2>
  229595:	0f 18 15 14 f3 f3 ff 	prefetcht1 -0xc0cec(%rip)        # 1688b0 <pf_target_11_3>
  22959c:	0f 18 15 9d eb e7 ff 	prefetcht1 -0x181463(%rip)        # a8140 <pf_target_11_4>
  2295a3:	0f 18 15 d6 05 f2 ff 	prefetcht1 -0xdfa2a(%rip)        # 149b80 <pf_target_11_5>
  2295aa:	0f 18 15 bf ed df ff 	prefetcht1 -0x201241(%rip)        # 28370 <pf_target_11_6>
  2295b1:	0f 18 15 08 80 e6 ff 	prefetcht1 -0x197ff8(%rip)        # 915c0 <pf_target_11_7>

00000000002295b8 <pf_jump_11>:
  2295b8:	e9 a3 c7 e1 ff       	jmp    45d60 <pf_callee_11>
  2295bd:	0f 1f 00             	nopl   (%rax)

00000000002295c0 <pf_call_12>:
  2295c0:	0f 18 15 68 88 f2 ff 	prefetcht1 -0xd7798(%rip)        # 151e2f <pf_target_12_0>

00000000002295c7 <pf_jump_12>:
  2295c7:	e9 e4 7f e6 ff       	jmp    915b0 <pf_callee_12>
  2295cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002295d0 <pf_call_13>:
  2295d0:	0f 18 15 b6 b5 e6 ff 	prefetcht1 -0x194a4a(%rip)        # 94b8d <pf_target_13_0>

00000000002295d7 <pf_jump_13>:
  2295d7:	e9 34 1d ef ff       	jmp    11b310 <pf_callee_13>
  2295dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002295e0 <pf_call_14>:
  2295e0:	0f 18 15 d9 89 e6 ff 	prefetcht1 -0x197627(%rip)        # 91fc0 <pf_target_14_0>
  2295e7:	0f 18 15 d4 c0 e6 ff 	prefetcht1 -0x193f2c(%rip)        # 956c2 <pf_target_14_1>
  2295ee:	0f 18 15 8b c0 e6 ff 	prefetcht1 -0x193f75(%rip)        # 95680 <pf_target_14_2>

00000000002295f5 <pf_jump_14>:
  2295f5:	e9 36 c7 e6 ff       	jmp    95d30 <pf_callee_14>
  2295fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229600 <pf_call_15>:
  229600:	0f 18 15 f9 d2 ef ff 	prefetcht1 -0x102d07(%rip)        # 126900 <pf_callee_9>

0000000000229607 <pf_jump_15>:
  229607:	e9 24 7d e6 ff       	jmp    91330 <pf_callee_15>
  22960c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229613:	00 00 00 
  229616:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22961d:	00 00 00 

0000000000229620 <pf_call_16>:
  229620:	0f 18 15 e9 02 e7 ff 	prefetcht1 -0x18fd17(%rip)        # 99910 <pf_callee_5>
  229627:	0f 18 15 95 aa e6 ff 	prefetcht1 -0x19556b(%rip)        # 940c3 <pf_target_16_1>

000000000022962e <pf_jump_16>:
  22962e:	e9 ad 7c e6 ff       	jmp    912e0 <pf_callee_16>
  229633:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22963a:	00 00 00 
  22963d:	0f 1f 00             	nopl   (%rax)

0000000000229640 <pf_call_17>:
  229640:	0f 18 15 29 ce e6 ff 	prefetcht1 -0x1931d7(%rip)        # 96470 <pf_target_17_0>
  229647:	0f 18 15 35 ce e6 ff 	prefetcht1 -0x1931cb(%rip)        # 96483 <pf_target_17_1>

000000000022964e <pf_jump_17>:
  22964e:	e9 3d 74 e6 ff       	jmp    90a90 <pf_callee_17>
  229653:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22965a:	00 00 00 
  22965d:	0f 1f 00             	nopl   (%rax)

0000000000229660 <pf_call_18>:
  229660:	0f 18 15 90 b2 e6 ff 	prefetcht1 -0x194d70(%rip)        # 948f7 <pf_target_18_0>
  229667:	0f 18 15 93 97 e6 ff 	prefetcht1 -0x19686d(%rip)        # 92e01 <pf_target_18_1>
  22966e:	0f 18 15 3b 7f e6 ff 	prefetcht1 -0x1980c5(%rip)        # 915b0 <pf_callee_12>

0000000000229675 <pf_jump_18>:
  229675:	e9 46 74 e6 ff       	jmp    90ac0 <pf_callee_18>
  22967a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229680 <pf_call_19>:
  229680:	0f 18 15 7a b5 f0 ff 	prefetcht1 -0xf4a86(%rip)        # 134c01 <pf_target_19_0>
  229687:	0f 18 15 d2 c6 e1 ff 	prefetcht1 -0x1e392e(%rip)        # 45d60 <pf_callee_11>

000000000022968e <pf_jump_19>:
  22968e:	e9 3d 80 e7 ff       	jmp    a16d0 <pf_callee_19>
  229693:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22969a:	00 00 00 
  22969d:	0f 1f 00             	nopl   (%rax)

00000000002296a0 <pf_call_20>:
  2296a0:	0f 18 15 b9 c6 e1 ff 	prefetcht1 -0x1e3947(%rip)        # 45d60 <pf_callee_11>
  2296a7:	0f 18 15 d5 b3 e6 ff 	prefetcht1 -0x194c2b(%rip)        # 94a83 <pf_target_20_1>

00000000002296ae <pf_jump_20>:
  2296ae:	e9 bd a2 e7 ff       	jmp    a3970 <pf_callee_20>
  2296b3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2296ba:	00 00 00 
  2296bd:	0f 1f 00             	nopl   (%rax)

00000000002296c0 <pf_call_21>:
  2296c0:	0f 18 15 11 7a e7 ff 	prefetcht1 -0x1885ef(%rip)        # a10d8 <pf_target_21_0>

00000000002296c7 <pf_jump_21>:
  2296c7:	e9 84 79 e7 ff       	jmp    a1050 <pf_callee_21>
  2296cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002296d0 <pf_call_22>:
  2296d0:	0f 18 15 49 ef df ff 	prefetcht1 -0x2010b7(%rip)        # 28620 <pf_target_22_0>

00000000002296d7 <pf_jump_22>:
  2296d7:	e9 94 a2 e7 ff       	jmp    a3970 <pf_callee_20>
  2296dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002296e0 <pf_call_23>:
  2296e0:	0f 18 15 1c 80 e7 ff 	prefetcht1 -0x187fe4(%rip)        # a1703 <pf_target_23_0>

00000000002296e7 <pf_jump_23>:
  2296e7:	e9 84 a2 e7 ff       	jmp    a3970 <pf_callee_20>
  2296ec:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2296f3:	00 00 00 
  2296f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2296fd:	00 00 00 

0000000000229700 <pf_call_24>:
  229700:	0f 18 15 3b a1 e6 ff 	prefetcht1 -0x195ec5(%rip)        # 93842 <pf_target_24_0>
  229707:	0f 18 15 b2 54 ef ff 	prefetcht1 -0x10ab4e(%rip)        # 11ebc0 <pf_target_24_1>
  22970e:	0f 18 15 6b 08 e7 ff 	prefetcht1 -0x18f795(%rip)        # 99f80 <pf_target_24_2>
  229715:	0f 18 15 e4 a0 e6 ff 	prefetcht1 -0x195f1c(%rip)        # 93800 <pf_target_24_3>
  22971c:	0f 18 15 df 95 e7 ff 	prefetcht1 -0x186a21(%rip)        # a2d02 <pf_target_24_4>
  229723:	0f 18 15 b6 cd e7 ff 	prefetcht1 -0x18324a(%rip)        # a64e0 <pf_target_24_5>
  22972a:	0f 18 15 bf 78 e6 ff 	prefetcht1 -0x198741(%rip)        # 90ff0 <pf_target_24_6>
  229731:	0f 18 15 89 a2 e6 ff 	prefetcht1 -0x195d77(%rip)        # 939c1 <pf_target_24_7>

0000000000229738 <pf_jump_24>:
  229738:	e9 23 8f e7 ff       	jmp    a2660 <pf_callee_24>
  22973d:	0f 1f 00             	nopl   (%rax)

0000000000229740 <pf_call_25>:
  229740:	0f 18 15 09 79 e7 ff 	prefetcht1 -0x1886f7(%rip)        # a1050 <pf_callee_21>

0000000000229747 <pf_jump_25>:
  229747:	e9 04 b2 e7 ff       	jmp    a4950 <pf_callee_25>
  22974c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229750 <pf_call_26>:
  229750:	0f 18 15 69 55 ef ff 	prefetcht1 -0x10aa97(%rip)        # 11ecc0 <pf_target_26_0>

0000000000229757 <pf_jump_26>:
  229757:	e9 44 bc e7 ff       	jmp    a53a0 <pf_callee_26>
  22975c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229760 <pf_call_27>:
  229760:	0f 18 15 b1 cf e7 ff 	prefetcht1 -0x18304f(%rip)        # a6718 <pf_target_27_0>

0000000000229767 <pf_jump_27>:
  229767:	e9 04 a2 e7 ff       	jmp    a3970 <pf_callee_20>
  22976c:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229773:	00 00 00 
  229776:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22977d:	00 00 00 

0000000000229780 <pf_call_28>:
  229780:	0f 18 15 59 df ef ff 	prefetcht1 -0x1020a7(%rip)        # 1276e0 <pf_target_28_0>
  229787:	0f 18 15 f2 d0 f7 ff 	prefetcht1 -0x82f0e(%rip)        # 1a6880 <pf_target_28_1>

000000000022978e <pf_jump_28>:
  22978e:	e9 8d 72 e6 ff       	jmp    90a20 <pf_callee_28>
  229793:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22979a:	00 00 00 
  22979d:	0f 1f 00             	nopl   (%rax)

00000000002297a0 <pf_call_29>:
  2297a0:	0f 18 15 5a 1f ef ff 	prefetcht1 -0x10e0a6(%rip)        # 11b701 <pf_target_29_0>
  2297a7:	0f 18 15 4e 1f ef ff 	prefetcht1 -0x10e0b2(%rip)        # 11b6fc <pf_target_29_1>

00000000002297ae <pf_jump_29>:
  2297ae:	e9 6d 72 e6 ff       	jmp    90a20 <pf_callee_28>
