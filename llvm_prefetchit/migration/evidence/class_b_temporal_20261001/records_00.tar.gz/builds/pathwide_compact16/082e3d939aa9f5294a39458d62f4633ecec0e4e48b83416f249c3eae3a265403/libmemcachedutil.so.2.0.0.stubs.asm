
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_compact16/082e3d939aa9f5294a39458d62f4633ecec0e4e48b83416f249c3eae3a265403/call-stub-kk9udw6t/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000072c0 <pf_call_0>:
    72c0:	0f 18 15 f9 af ff ff 	prefetcht1 -0x5007(%rip)        # 22c0 <pf_target_0_0>

00000000000072c7 <pf_jump_0>:
    72c7:	e9 74 b2 ff ff       	jmp    2540 <pf_callee_0>
