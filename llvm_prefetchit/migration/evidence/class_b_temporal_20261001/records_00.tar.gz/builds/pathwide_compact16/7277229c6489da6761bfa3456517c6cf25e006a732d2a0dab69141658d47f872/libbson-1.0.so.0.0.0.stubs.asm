
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_compact16/7277229c6489da6761bfa3456517c6cf25e006a732d2a0dab69141658d47f872/call-stub-h2fy2_4c/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000422c0 <pf_call_0>:
   422c0:	0f 18 15 3a 04 fd ff 	prefetcht1 -0x2fbc6(%rip)        # 12701 <pf_target_0_0>

00000000000422c7 <pf_jump_0>:
   422c7:	e9 a4 af fc ff       	jmp    d270 <pf_callee_0>
   422cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000422d0 <pf_call_1>:
   422d0:	0f 18 15 c9 b9 fc ff 	prefetcht1 -0x34637(%rip)        # dca0 <pf_target_1_0>
   422d7:	0f 18 15 63 10 fd ff 	prefetcht1 -0x2ef9d(%rip)        # 13341 <pf_target_1_1>
   422de:	0f 18 15 2b 10 fd ff 	prefetcht1 -0x2efd5(%rip)        # 13310 <pf_target_1_2>
   422e5:	0f 18 15 04 0f fd ff 	prefetcht1 -0x2f0fc(%rip)        # 131f0 <pf_target_1_3>
   422ec:	0f 18 15 12 0f fd ff 	prefetcht1 -0x2f0ee(%rip)        # 13205 <pf_target_1_4>
   422f3:	0f 18 15 0a de fc ff 	prefetcht1 -0x321f6(%rip)        # 10104 <pf_target_1_5>

00000000000422fa <pf_jump_1>:
   422fa:	e9 31 b4 fc ff       	jmp    d730 <pf_callee_1>
   422ff:	90                   	nop

0000000000042300 <pf_call_2>:
   42300:	0f 18 15 39 cd fc ff 	prefetcht1 -0x332c7(%rip)        # f040 <pf_target_2_0>

0000000000042307 <pf_jump_2>:
   42307:	e9 a4 ad fc ff       	jmp    d0b0 <pf_callee_2>
   4230c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042310 <pf_call_3>:
   42310:	0f 18 15 09 01 fd ff 	prefetcht1 -0x2fef7(%rip)        # 12420 <pf_target_3_0>
   42317:	0f 18 15 22 01 fd ff 	prefetcht1 -0x2fede(%rip)        # 12440 <pf_target_3_1>
   4231e:	0f 18 15 7b 02 fd ff 	prefetcht1 -0x2fd85(%rip)        # 125a0 <pf_target_3_2>
   42325:	0f 18 15 6c c6 fc ff 	prefetcht1 -0x33994(%rip)        # e998 <pf_target_3_3>

000000000004232c <pf_jump_3>:
   4232c:	e9 3f ac fc ff       	jmp    cf70 <pf_callee_3>
   42331:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   42338:	00 00 00 
   4233b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000042340 <pf_call_4>:
   42340:	0f 18 15 b9 06 fd ff 	prefetcht1 -0x2f947(%rip)        # 12a00 <pf_target_4_0>
   42347:	0f 18 15 f3 06 fd ff 	prefetcht1 -0x2f90d(%rip)        # 12a41 <pf_target_4_1>

000000000004234e <pf_jump_4>:
   4234e:	e9 2d ae fc ff       	jmp    d180 <pf_callee_4>
   42353:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4235a:	00 00 00 
   4235d:	0f 1f 00             	nopl   (%rax)

0000000000042360 <pf_call_5>:
   42360:	0f 18 15 c7 9e fd ff 	prefetcht1 -0x26139(%rip)        # 1c22e <pf_target_5_0>
   42367:	41 53                	push   %r11
   42369:	4c 8b 1d 58 8e ff ff 	mov    -0x71a8(%rip),%r11        # 3b1c8 <pf_got_26_0>

0000000000042370 <pf_got_hint_5_0>:
   42370:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   42377:	00 

0000000000042378 <pf_got_hint_5_1>:
   42378:	41 0f 18 93 22 00 00 	prefetcht1 0x22(%r11)
   4237f:	00 
   42380:	41 5b                	pop    %r11

0000000000042382 <pf_jump_5>:
   42382:	e9 39 ab fc ff       	jmp    cec0 <pf_callee_5>
   42387:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   4238e:	00 00 

0000000000042390 <pf_call_6>:
   42390:	0f 18 15 11 fa fc ff 	prefetcht1 -0x305ef(%rip)        # 11da8 <pf_target_6_0>

0000000000042397 <pf_jump_6>:
   42397:	e9 54 dc fc ff       	jmp    fff0 <pf_callee_6>
   4239c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000423a0 <pf_call_7>:
   423a0:	0f 18 15 19 0c fd ff 	prefetcht1 -0x2f3e7(%rip)        # 12fc0 <pf_target_7_0>
   423a7:	0f 18 15 93 06 fd ff 	prefetcht1 -0x2f96d(%rip)        # 12a41 <pf_target_4_1>
   423ae:	0f 18 15 4b 06 fd ff 	prefetcht1 -0x2f9b5(%rip)        # 12a00 <pf_target_4_0>

00000000000423b5 <pf_jump_7>:
   423b5:	e9 c6 ad fc ff       	jmp    d180 <pf_callee_4>
   423ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000423c0 <pf_call_8>:
   423c0:	0f 18 15 7b b4 fc ff 	prefetcht1 -0x34b85(%rip)        # d842 <pf_target_8_0>

00000000000423c7 <pf_jump_8>:
   423c7:	e9 b4 ad fc ff       	jmp    d180 <pf_callee_4>
   423cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000423d0 <pf_call_9>:
   423d0:	0f 18 15 49 fe fd ff 	prefetcht1 -0x201b7(%rip)        # 22220 <pf_target_9_0>
   423d7:	0f 18 15 62 fe fd ff 	prefetcht1 -0x2019e(%rip)        # 22240 <pf_target_9_1>

00000000000423de <pf_jump_9>:
   423de:	e9 dd f9 fc ff       	jmp    11dc0 <pf_callee_10>
   423e3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   423ea:	00 00 00 
   423ed:	0f 1f 00             	nopl   (%rax)

00000000000423f0 <pf_call_10>:
   423f0:	0f 18 15 d9 fa fc ff 	prefetcht1 -0x30527(%rip)        # 11ed0 <pf_target_10_0>

00000000000423f7 <pf_jump_10>:
   423f7:	e9 c4 f9 fc ff       	jmp    11dc0 <pf_callee_10>
   423fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042400 <pf_call_11>:
   42400:	0f 18 15 39 97 fd ff 	prefetcht1 -0x268c7(%rip)        # 1bb40 <pf_target_11_0>
   42407:	0f 18 15 b2 96 fd ff 	prefetcht1 -0x2694e(%rip)        # 1bac0 <pf_target_11_1>
   4240e:	0f 18 15 f1 96 fd ff 	prefetcht1 -0x2690f(%rip)        # 1bb06 <pf_target_11_2>

0000000000042415 <pf_jump_11>:
   42415:	e9 86 ae fc ff       	jmp    d2a0 <pf_callee_11>
   4241a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000042420 <pf_call_12>:
   42420:	0f 18 15 69 41 fe ff 	prefetcht1 -0x1be97(%rip)        # 26590 <pf_target_12_0>
   42427:	0f 18 15 c2 9e fd ff 	prefetcht1 -0x2613e(%rip)        # 1c2f0 <pf_target_12_1>
   4242e:	0f 18 15 8e 41 fe ff 	prefetcht1 -0x1be72(%rip)        # 265c3 <pf_target_12_2>
   42435:	0f 18 15 74 77 fd ff 	prefetcht1 -0x2888c(%rip)        # 19bb0 <pf_target_12_3>
   4243c:	0f 18 15 fd a9 fc ff 	prefetcht1 -0x35603(%rip)        # ce40 <pf_callee_13>
   42443:	0f 18 15 e0 78 fd ff 	prefetcht1 -0x28720(%rip)        # 19d2a <pf_target_12_5>
   4244a:	0f 18 15 b1 77 fd ff 	prefetcht1 -0x2884f(%rip)        # 19c02 <pf_target_12_6>

0000000000042451 <pf_jump_12>:
   42451:	e9 4a ae fc ff       	jmp    d2a0 <pf_callee_11>
   42456:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4245d:	00 00 00 

0000000000042460 <pf_call_13>:
   42460:	0f 18 15 29 93 fd ff 	prefetcht1 -0x26cd7(%rip)        # 1b790 <pf_target_13_0>
   42467:	0f 18 15 52 7e fd ff 	prefetcht1 -0x281ae(%rip)        # 1a2c0 <pf_target_13_1>
   4246e:	41 53                	push   %r11
   42470:	4c 8b 1d 19 8c ff ff 	mov    -0x73e7(%rip),%r11        # 3b090 <pf_got_13_0>

0000000000042477 <pf_got_hint_13_0>:
   42477:	41 0f 18 93 12 ff ff 	prefetcht1 -0xee(%r11)
   4247e:	ff 
   4247f:	4c 8b 1d 12 8c ff ff 	mov    -0x73ee(%rip),%r11        # 3b098 <pf_got_13_1>

0000000000042486 <pf_got_hint_13_1>:
   42486:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   4248d:	00 

000000000004248e <pf_got_hint_13_2>:
   4248e:	41 0f 18 93 46 00 00 	prefetcht1 0x46(%r11)
   42495:	00 
   42496:	41 5b                	pop    %r11

0000000000042498 <pf_jump_13>:
   42498:	e9 a3 a9 fc ff       	jmp    ce40 <pf_callee_13>
   4249d:	0f 1f 00             	nopl   (%rax)

00000000000424a0 <pf_call_14>:
   424a0:	0f 18 15 79 a6 fc ff 	prefetcht1 -0x35987(%rip)        # cb20 <pf_target_14_0>
   424a7:	41 53                	push   %r11
   424a9:	4c 8b 1d e0 8b ff ff 	mov    -0x7420(%rip),%r11        # 3b090 <pf_got_13_0>

00000000000424b0 <pf_got_hint_14_0>:
   424b0:	41 0f 18 93 b0 fe ff 	prefetcht1 -0x150(%r11)
   424b7:	ff 
   424b8:	41 5b                	pop    %r11

00000000000424ba <pf_jump_14>:
   424ba:	e9 a1 a9 fc ff       	jmp    ce60 <pf_callee_14>
   424bf:	90                   	nop

00000000000424c0 <pf_call_15>:
   424c0:	0f 18 15 f3 92 fd ff 	prefetcht1 -0x26d0d(%rip)        # 1b7ba <pf_target_15_0>
   424c7:	0f 18 15 f5 92 fd ff 	prefetcht1 -0x26d0b(%rip)        # 1b7c3 <pf_target_15_1>
   424ce:	0f 18 15 4d 78 fd ff 	prefetcht1 -0x287b3(%rip)        # 19d22 <pf_target_15_2>
   424d5:	0f 18 15 e4 85 fd ff 	prefetcht1 -0x27a1c(%rip)        # 1aac0 <pf_target_15_3>
   424dc:	41 53                	push   %r11
   424de:	4c 8b 1d ab 8b ff ff 	mov    -0x7455(%rip),%r11        # 3b090 <pf_got_13_0>

00000000000424e5 <pf_got_hint_15_0>:
   424e5:	41 0f 18 93 82 fe ff 	prefetcht1 -0x17e(%r11)
   424ec:	ff 

00000000000424ed <pf_got_hint_15_1>:
   424ed:	41 0f 18 93 f0 fe ff 	prefetcht1 -0x110(%r11)
   424f4:	ff 

00000000000424f5 <pf_got_hint_15_2>:
   424f5:	41 0f 18 93 12 ff ff 	prefetcht1 -0xee(%r11)
   424fc:	ff 
   424fd:	4c 8b 1d 94 8b ff ff 	mov    -0x746c(%rip),%r11        # 3b098 <pf_got_13_1>

0000000000042504 <pf_got_hint_15_3>:
   42504:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   4250b:	00 
   4250c:	41 5b                	pop    %r11

000000000004250e <pf_jump_15>:
   4250e:	e9 4d a7 fc ff       	jmp    cc60 <pf_callee_15>
   42513:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4251a:	00 00 00 
   4251d:	0f 1f 00             	nopl   (%rax)

0000000000042520 <pf_call_16>:
   42520:	0f 18 15 a9 24 fe ff 	prefetcht1 -0x1db57(%rip)        # 249d0 <pf_target_16_0>

0000000000042527 <pf_jump_16>:
   42527:	e9 74 ad fc ff       	jmp    d2a0 <pf_callee_11>
   4252c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042530 <pf_call_17>:
   42530:	0f 18 15 59 87 fd ff 	prefetcht1 -0x278a7(%rip)        # 1ac90 <pf_target_17_0>

0000000000042537 <pf_jump_17>:
   42537:	e9 44 b0 fc ff       	jmp    d580 <pf_callee_17>
   4253c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042540 <pf_call_18>:
   42540:	0f 18 15 09 ed fc ff 	prefetcht1 -0x312f7(%rip)        # 11250 <pf_target_18_0>
   42547:	0f 18 15 92 89 fd ff 	prefetcht1 -0x2766e(%rip)        # 1aee0 <pf_target_18_1>

000000000004254e <pf_jump_18>:
   4254e:	e9 8d a7 fc ff       	jmp    cce0 <pf_callee_18>
   42553:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4255a:	00 00 00 
   4255d:	0f 1f 00             	nopl   (%rax)

0000000000042560 <pf_call_19>:
   42560:	0f 18 15 99 e8 fc ff 	prefetcht1 -0x31767(%rip)        # 10e00 <pf_target_19_0>
   42567:	0f 18 15 e7 42 fe ff 	prefetcht1 -0x1bd19(%rip)        # 26855 <pf_target_19_1>

000000000004256e <pf_jump_19>:
   4256e:	e9 0d af fc ff       	jmp    d480 <pf_callee_19>
   42573:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4257a:	00 00 00 
   4257d:	0f 1f 00             	nopl   (%rax)

0000000000042580 <pf_call_20>:
   42580:	0f 18 15 a9 55 fd ff 	prefetcht1 -0x2aa57(%rip)        # 17b30 <pf_target_20_0>
   42587:	0f 18 15 34 54 fd ff 	prefetcht1 -0x2abcc(%rip)        # 179c2 <pf_target_20_1>
   4258e:	0f 18 15 7b 12 fd ff 	prefetcht1 -0x2ed85(%rip)        # 13810 <pf_target_20_2>
   42595:	0f 18 15 14 54 fd ff 	prefetcht1 -0x2abec(%rip)        # 179b0 <pf_target_20_3>
   4259c:	0f 18 15 a0 12 fd ff 	prefetcht1 -0x2ed60(%rip)        # 13843 <pf_target_20_4>
   425a3:	41 53                	push   %r11
   425a5:	4c 8b 1d 84 8b ff ff 	mov    -0x747c(%rip),%r11        # 3b130 <pf_got_20_0>

00000000000425ac <pf_got_hint_20_0>:
   425ac:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   425b3:	00 
   425b4:	41 5b                	pop    %r11

00000000000425b6 <pf_jump_20>:
   425b6:	e9 55 ac fc ff       	jmp    d210 <pf_callee_20>
   425bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000425c0 <pf_call_21>:
   425c0:	0f 18 15 59 40 fd ff 	prefetcht1 -0x2bfa7(%rip)        # 16620 <pf_target_21_0>
   425c7:	0f 18 15 73 40 fd ff 	prefetcht1 -0x2bf8d(%rip)        # 16641 <pf_target_21_1>

00000000000425ce <pf_jump_21>:
   425ce:	e9 fd af fc ff       	jmp    d5d0 <pf_callee_21>
   425d3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   425da:	00 00 00 
   425dd:	0f 1f 00             	nopl   (%rax)

00000000000425e0 <pf_call_22>:
   425e0:	41 53                	push   %r11
   425e2:	4c 8b 1d a7 8a ff ff 	mov    -0x7559(%rip),%r11        # 3b090 <pf_got_13_0>

00000000000425e9 <pf_got_hint_22_0>:
   425e9:	41 0f 18 93 51 05 00 	prefetcht1 0x551(%r11)
   425f0:	00 

00000000000425f1 <pf_got_hint_22_1>:
   425f1:	41 0f 18 93 10 06 00 	prefetcht1 0x610(%r11)
   425f8:	00 

00000000000425f9 <pf_got_hint_22_2>:
   425f9:	41 0f 18 93 a0 07 00 	prefetcht1 0x7a0(%r11)
   42600:	00 

0000000000042601 <pf_got_hint_22_3>:
   42601:	41 0f 18 93 00 08 00 	prefetcht1 0x800(%r11)
   42608:	00 
   42609:	41 5b                	pop    %r11

000000000004260b <pf_jump_22>:
   4260b:	e9 40 a6 fc ff       	jmp    cc50 <pf_callee_22>

0000000000042610 <pf_call_23>:
   42610:	41 53                	push   %r11
   42612:	4c 8b 1d 0f 8e ff ff 	mov    -0x71f1(%rip),%r11        # 3b428 <pf_got_23_0>

0000000000042619 <pf_got_hint_23_0>:
   42619:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   42620:	00 
   42621:	4c 8b 1d 20 8f ff ff 	mov    -0x70e0(%rip),%r11        # 3b548 <pf_got_23_1>

0000000000042628 <pf_got_hint_23_1>:
   42628:	41 0f 18 93 30 e4 fe 	prefetcht1 -0x11bd0(%r11)
   4262f:	ff 

0000000000042630 <pf_got_hint_23_2>:
   42630:	41 0f 18 93 40 e4 fe 	prefetcht1 -0x11bc0(%r11)
   42637:	ff 

0000000000042638 <pf_got_hint_23_3>:
   42638:	41 0f 18 93 85 e4 fe 	prefetcht1 -0x11b7b(%r11)
   4263f:	ff 

0000000000042640 <pf_got_hint_23_4>:
   42640:	41 0f 18 93 42 46 ff 	prefetcht1 -0xb9be(%r11)
   42647:	ff 
   42648:	41 5b                	pop    %r11

000000000004264a <pf_jump_23>:
   4264a:	e9 31 ad fc ff       	jmp    d380 <pf_callee_23>
   4264f:	90                   	nop

0000000000042650 <pf_call_24>:
   42650:	41 53                	push   %r11
   42652:	4c 8b 1d cf 8d ff ff 	mov    -0x7231(%rip),%r11        # 3b428 <pf_got_23_0>

0000000000042659 <pf_got_hint_24_0>:
   42659:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   42660:	00 
   42661:	4c 8b 1d e0 8e ff ff 	mov    -0x7120(%rip),%r11        # 3b548 <pf_got_23_1>

0000000000042668 <pf_got_hint_24_1>:
   42668:	41 0f 18 93 42 46 ff 	prefetcht1 -0xb9be(%r11)
   4266f:	ff 
   42670:	41 5b                	pop    %r11

0000000000042672 <pf_jump_24>:
   42672:	e9 59 af fc ff       	jmp    d5d0 <pf_callee_21>
   42677:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   4267e:	00 00 

0000000000042680 <pf_call_25>:
   42680:	41 53                	push   %r11
   42682:	4c 8b 1d bf 8e ff ff 	mov    -0x7141(%rip),%r11        # 3b548 <pf_got_23_1>

0000000000042689 <pf_got_hint_25_0>:
   42689:	41 0f 18 93 70 b0 fd 	prefetcht1 -0x24f90(%r11)
   42690:	ff 

0000000000042691 <pf_got_hint_25_1>:
   42691:	41 0f 18 93 80 b0 fd 	prefetcht1 -0x24f80(%r11)
   42698:	ff 

0000000000042699 <pf_got_hint_25_2>:
   42699:	41 0f 18 93 60 bf fd 	prefetcht1 -0x240a0(%r11)
   426a0:	ff 

00000000000426a1 <pf_got_hint_25_3>:
   426a1:	41 0f 18 93 e8 ca fd 	prefetcht1 -0x23518(%r11)
   426a8:	ff 

00000000000426a9 <pf_got_hint_25_4>:
   426a9:	41 0f 18 93 f7 cd fd 	prefetcht1 -0x23209(%r11)
   426b0:	ff 

00000000000426b1 <pf_got_hint_25_5>:
   426b1:	41 0f 18 93 60 3c ff 	prefetcht1 -0xc3a0(%r11)
   426b8:	ff 

00000000000426b9 <pf_got_hint_25_6>:
   426b9:	41 0f 18 93 20 46 ff 	prefetcht1 -0xb9e0(%r11)
   426c0:	ff 

00000000000426c1 <pf_got_hint_25_7>:
   426c1:	41 0f 18 93 90 46 ff 	prefetcht1 -0xb970(%r11)
   426c8:	ff 
   426c9:	41 5b                	pop    %r11

00000000000426cb <pf_jump_25>:
   426cb:	e9 50 ac fc ff       	jmp    d320 <pf_callee_25>

00000000000426d0 <pf_call_26>:
   426d0:	41 53                	push   %r11
   426d2:	4c 8b 1d ef 8a ff ff 	mov    -0x7511(%rip),%r11        # 3b1c8 <pf_got_26_0>

00000000000426d9 <pf_got_hint_26_0>:
   426d9:	41 0f 18 93 e1 02 00 	prefetcht1 0x2e1(%r11)
   426e0:	00 
   426e1:	4c 8b 1d 40 8d ff ff 	mov    -0x72c0(%rip),%r11        # 3b428 <pf_got_23_0>

00000000000426e8 <pf_got_hint_26_1>:
   426e8:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
   426ef:	00 

00000000000426f0 <pf_got_hint_26_2>:
   426f0:	41 0f 18 93 11 00 00 	prefetcht1 0x11(%r11)
   426f7:	00 
   426f8:	4c 8b 1d 49 8e ff ff 	mov    -0x71b7(%rip),%r11        # 3b548 <pf_got_23_1>

00000000000426ff <pf_got_hint_26_3>:
   426ff:	41 0f 18 93 70 b0 fd 	prefetcht1 -0x24f90(%r11)
   42706:	ff 

0000000000042707 <pf_got_hint_26_4>:
   42707:	41 0f 18 93 50 b7 fd 	prefetcht1 -0x248b0(%r11)
   4270e:	ff 

000000000004270f <pf_got_hint_26_5>:
   4270f:	41 0f 18 93 69 cd fd 	prefetcht1 -0x23297(%r11)
   42716:	ff 

0000000000042717 <pf_got_hint_26_6>:
   42717:	41 0f 18 93 00 3e ff 	prefetcht1 -0xc200(%r11)
   4271e:	ff 

000000000004271f <pf_got_hint_26_7>:
   4271f:	41 0f 18 93 20 46 ff 	prefetcht1 -0xb9e0(%r11)
   42726:	ff 
   42727:	41 5b                	pop    %r11

0000000000042729 <pf_jump_26>:
   42729:	e9 f2 ab fc ff       	jmp    d320 <pf_callee_25>
