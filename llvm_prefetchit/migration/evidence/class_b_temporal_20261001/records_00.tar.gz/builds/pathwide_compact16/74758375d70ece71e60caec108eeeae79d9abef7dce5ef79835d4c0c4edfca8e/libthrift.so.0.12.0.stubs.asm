
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_compact16/74758375d70ece71e60caec108eeeae79d9abef7dce5ef79835d4c0c4edfca8e/call-stub-mu6no7tb/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000c22c0 <pf_call_0>:
   c22c0:	0f 18 15 b9 00 fa ff 	prefetcht1 -0x5ff47(%rip)        # 62380 <pf_target_0_0>
   c22c7:	41 53                	push   %r11
   c22c9:	4c 8b 1d 28 e8 ff ff 	mov    -0x17d8(%rip),%r11        # c0af8 <pf_got_0_0>

00000000000c22d0 <pf_got_hint_0_0>:
   c22d0:	41 0f 18 93 ee da ff 	prefetcht1 -0x2512(%r11)
   c22d7:	ff 
   c22d8:	41 5b                	pop    %r11

00000000000c22da <pf_jump_0>:
   c22da:	e9 c1 67 f8 ff       	jmp    48aa0 <pf_callee_0>
   c22df:	90                   	nop

00000000000c22e0 <pf_call_1>:
   c22e0:	0f 18 15 39 6d f8 ff 	prefetcht1 -0x792c7(%rip)        # 49020 <pf_target_1_0>
   c22e7:	0f 18 15 03 e2 fb ff 	prefetcht1 -0x41dfd(%rip)        # 804f1 <pf_target_1_1>
   c22ee:	0f 18 15 0b 60 f8 ff 	prefetcht1 -0x79ff5(%rip)        # 48300 <pf_callee_4>
   c22f5:	0f 18 15 04 57 f8 ff 	prefetcht1 -0x7a8fc(%rip)        # 47a00 <pf_callee_2>
   c22fc:	0f 18 15 fd e1 fb ff 	prefetcht1 -0x41e03(%rip)        # 80500 <pf_target_1_4>
   c2303:	0f 18 15 aa 69 fb ff 	prefetcht1 -0x49656(%rip)        # 78cb4 <pf_target_1_5>

00000000000c230a <pf_jump_1>:
   c230a:	e9 51 52 f8 ff       	jmp    47560 <pf_callee_1>
   c230f:	90                   	nop

00000000000c2310 <pf_call_2>:
   c2310:	0f 18 15 ae 6c fb ff 	prefetcht1 -0x49352(%rip)        # 78fc5 <pf_target_2_0>
   c2317:	0f 18 15 82 86 fb ff 	prefetcht1 -0x4797e(%rip)        # 7a9a0 <pf_target_2_1>
   c231e:	0f 18 15 4b 85 fb ff 	prefetcht1 -0x47ab5(%rip)        # 7a870 <pf_target_2_2>
   c2325:	0f 18 15 44 68 fb ff 	prefetcht1 -0x497bc(%rip)        # 78b70 <pf_target_2_3>
   c232c:	0f 18 15 54 85 fb ff 	prefetcht1 -0x47aac(%rip)        # 7a887 <pf_target_2_4>
   c2333:	0f 18 15 4b 68 fb ff 	prefetcht1 -0x497b5(%rip)        # 78b85 <pf_target_2_5>
   c233a:	0f 18 15 2a e6 fb ff 	prefetcht1 -0x419d6(%rip)        # 8096b <pf_target_2_6>
   c2341:	0f 18 15 6c 6c fb ff 	prefetcht1 -0x49394(%rip)        # 78fb4 <pf_target_2_7>

00000000000c2348 <pf_jump_2>:
   c2348:	e9 b3 56 f8 ff       	jmp    47a00 <pf_callee_2>
   c234d:	0f 1f 00             	nopl   (%rax)

00000000000c2350 <pf_call_3>:
   c2350:	0f 18 15 69 12 fb ff 	prefetcht1 -0x4ed97(%rip)        # 735c0 <pf_target_3_0>
   c2357:	0f 18 15 e2 54 f8 ff 	prefetcht1 -0x7ab1e(%rip)        # 47840 <pf_target_3_1>
   c235e:	0f 18 15 5b f5 fb ff 	prefetcht1 -0x40aa5(%rip)        # 818c0 <pf_target_3_2>
   c2365:	0f 18 15 a4 f6 fb ff 	prefetcht1 -0x4095c(%rip)        # 81a10 <pf_target_3_3>

00000000000c236c <pf_jump_3>:
   c236c:	e9 af 59 f8 ff       	jmp    47d20 <pf_callee_3>
   c2371:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c2378:	00 00 00 
   c237b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000c2380 <pf_call_4>:
   c2380:	0f 18 15 7a ec fb ff 	prefetcht1 -0x41386(%rip)        # 81001 <pf_target_4_0>
   c2387:	0f 18 15 32 f3 fb ff 	prefetcht1 -0x40cce(%rip)        # 816c0 <pf_target_4_1>
   c238e:	0f 18 15 80 f5 fb ff 	prefetcht1 -0x40a80(%rip)        # 81915 <pf_target_4_2>
   c2395:	0f 18 15 ac f5 fb ff 	prefetcht1 -0x40a54(%rip)        # 81948 <pf_target_4_3>
   c239c:	0f 18 15 4d ec fb ff 	prefetcht1 -0x413b3(%rip)        # 80ff0 <pf_target_4_4>
   c23a3:	0f 18 15 56 f3 fb ff 	prefetcht1 -0x40caa(%rip)        # 81700 <pf_target_4_5>
   c23aa:	41 53                	push   %r11
   c23ac:	4c 8b 1d 05 e5 ff ff 	mov    -0x1afb(%rip),%r11        # c08b8 <pf_got_4_0>

00000000000c23b3 <pf_got_hint_4_0>:
   c23b3:	41 0f 18 93 c0 53 ff 	prefetcht1 -0xac40(%r11)
   c23ba:	ff 

00000000000c23bb <pf_got_hint_4_1>:
   c23bb:	41 0f 18 93 b0 04 0a 	prefetcht1 0xa04b0(%r11)
   c23c2:	00 
   c23c3:	41 5b                	pop    %r11

00000000000c23c5 <pf_jump_4>:
   c23c5:	e9 36 5f f8 ff       	jmp    48300 <pf_callee_4>
   c23ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000c23d0 <pf_call_5>:
   c23d0:	0f 18 15 19 6e fb ff 	prefetcht1 -0x491e7(%rip)        # 791f0 <pf_target_5_0>
   c23d7:	0f 18 15 a2 e0 fb ff 	prefetcht1 -0x41f5e(%rip)        # 80480 <pf_target_5_1>
   c23de:	0f 18 15 5b 4d fb ff 	prefetcht1 -0x4b2a5(%rip)        # 77140 <pf_target_5_2>
   c23e5:	0f 18 15 94 4d fb ff 	prefetcht1 -0x4b26c(%rip)        # 77180 <pf_target_5_3>
   c23ec:	0f 18 15 5d 84 fb ff 	prefetcht1 -0x47ba3(%rip)        # 7a850 <pf_target_5_4>
   c23f3:	0f 18 15 26 59 f8 ff 	prefetcht1 -0x7a6da(%rip)        # 47d20 <pf_callee_3>
   c23fa:	0f 18 15 01 6e fb ff 	prefetcht1 -0x491ff(%rip)        # 79202 <pf_target_5_6>

00000000000c2401 <pf_jump_5>:
   c2401:	e9 fa 5e f8 ff       	jmp    48300 <pf_callee_4>
   c2406:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c240d:	00 00 00 

00000000000c2410 <pf_call_6>:
   c2410:	41 53                	push   %r11
   c2412:	4c 8b 1d 9f e4 ff ff 	mov    -0x1b61(%rip),%r11        # c08b8 <pf_got_4_0>

00000000000c2419 <pf_got_hint_6_0>:
   c2419:	41 0f 18 93 71 1d 00 	prefetcht1 0x1d71(%r11)
   c2420:	00 

00000000000c2421 <pf_got_hint_6_1>:
   c2421:	41 0f 18 93 a0 04 0a 	prefetcht1 0xa04a0(%r11)
   c2428:	00 

00000000000c2429 <pf_got_hint_6_2>:
   c2429:	41 0f 18 93 40 06 0a 	prefetcht1 0xa0640(%r11)
   c2430:	00 
   c2431:	41 5b                	pop    %r11

00000000000c2433 <pf_jump_6>:
   c2433:	e9 c8 5e f8 ff       	jmp    48300 <pf_callee_4>
