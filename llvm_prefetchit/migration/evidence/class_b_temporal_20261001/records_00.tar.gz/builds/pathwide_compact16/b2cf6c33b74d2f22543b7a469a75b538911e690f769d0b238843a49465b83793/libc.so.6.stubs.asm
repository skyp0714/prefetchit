
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_compact16/b2cf6c33b74d2f22543b7a469a75b538911e690f769d0b238843a49465b83793/call-stub-wg7sg0wq/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000229380 <pf_call_0>:
  229380:	0f 18 15 fc d1 e4 ff 	prefetcht1 -0x1b2e04(%rip)        # 76583 <pf_target_0_0>
  229387:	0f 18 15 73 e1 e4 ff 	prefetcht1 -0x1b1e8d(%rip)        # 77501 <pf_target_0_1>
  22938e:	0f 18 15 6d dc e4 ff 	prefetcht1 -0x1b2393(%rip)        # 77002 <pf_target_0_2>
  229395:	0f 18 15 c1 d1 e4 ff 	prefetcht1 -0x1b2e3f(%rip)        # 7655d <pf_target_0_3>
  22939c:	0f 18 15 55 dc e4 ff 	prefetcht1 -0x1b23ab(%rip)        # 76ff8 <pf_target_0_4>
  2293a3:	0f 18 15 d6 4b e6 ff 	prefetcht1 -0x19b42a(%rip)        # 8df80 <pf_target_0_5>

00000000002293aa <pf_jump_0>:
  2293aa:	e9 81 0e e3 ff       	jmp    5a230 <pf_callee_0>
  2293af:	90                   	nop

00000000002293b0 <pf_call_1>:
  2293b0:	0f 18 15 89 bc e4 ff 	prefetcht1 -0x1b4377(%rip)        # 75040 <pf_target_1_0>
  2293b7:	0f 18 15 e2 db e4 ff 	prefetcht1 -0x1b241e(%rip)        # 76fa0 <pf_target_1_1>
  2293be:	0f 18 15 8b cc e4 ff 	prefetcht1 -0x1b3375(%rip)        # 76050 <pf_target_1_2>
  2293c5:	0f 18 15 64 0e e3 ff 	prefetcht1 -0x1cf19c(%rip)        # 5a230 <pf_callee_0>
  2293cc:	0f 18 15 6d 0e e3 ff 	prefetcht1 -0x1cf193(%rip)        # 5a240 <pf_target_1_4>
  2293d3:	0f 18 15 a6 65 e6 ff 	prefetcht1 -0x199a5a(%rip)        # 8f980 <pf_target_1_5>
  2293da:	0f 18 15 8f 65 e6 ff 	prefetcht1 -0x199a71(%rip)        # 8f970 <pf_target_1_6>
  2293e1:	0f 18 15 58 82 f8 ff 	prefetcht1 -0x77da8(%rip)        # 1b1640 <pf_target_1_7>

00000000002293e8 <pf_jump_1>:
  2293e8:	e9 23 52 e6 ff       	jmp    8e610 <pf_callee_1>
  2293ed:	0f 1f 00             	nopl   (%rax)

00000000002293f0 <pf_call_2>:
  2293f0:	0f 18 15 69 4b e6 ff 	prefetcht1 -0x19b497(%rip)        # 8df60 <pf_target_2_0>
  2293f7:	0f 18 15 83 82 f8 ff 	prefetcht1 -0x77d7d(%rip)        # 1b1681 <pf_target_2_1>
  2293fe:	0f 18 15 7b d9 e4 ff 	prefetcht1 -0x1b2685(%rip)        # 76d80 <pf_target_2_2>
  229405:	0f 18 15 1e c6 e4 ff 	prefetcht1 -0x1b39e2(%rip)        # 75a2a <pf_target_2_3>
  22940c:	0f 18 15 e5 db e4 ff 	prefetcht1 -0x1b241b(%rip)        # 76ff8 <pf_target_0_4>
  229413:	0f 18 15 a9 c0 e4 ff 	prefetcht1 -0x1b3f57(%rip)        # 754c3 <pf_target_2_5>

000000000022941a <pf_jump_2>:
  22941a:	e9 d1 bb e4 ff       	jmp    74ff0 <pf_callee_2>
  22941f:	90                   	nop

0000000000229420 <pf_call_3>:
  229420:	0f 18 15 76 ae e6 ff 	prefetcht1 -0x19518a(%rip)        # 9429d <pf_target_3_0>
  229427:	0f 18 15 09 d1 e6 ff 	prefetcht1 -0x192ef7(%rip)        # 96537 <pf_target_3_1>
  22942e:	0f 18 15 af d1 e6 ff 	prefetcht1 -0x192e51(%rip)        # 965e4 <pf_target_3_2>
  229435:	0f 18 15 c4 d1 e6 ff 	prefetcht1 -0x192e3c(%rip)        # 96600 <pf_target_3_3>
  22943c:	0f 18 15 be a5 e6 ff 	prefetcht1 -0x195a42(%rip)        # 93a01 <pf_target_3_4>
  229443:	0f 18 15 76 a4 e6 ff 	prefetcht1 -0x195b8a(%rip)        # 938c0 <pf_target_3_5>
  22944a:	0f 18 15 59 a4 e6 ff 	prefetcht1 -0x195ba7(%rip)        # 938aa <pf_target_3_6>
  229451:	0f 18 15 23 ad e6 ff 	prefetcht1 -0x1952dd(%rip)        # 9417b <pf_target_3_7>

0000000000229458 <pf_jump_3>:
  229458:	e9 c3 75 e6 ff       	jmp    90a20 <pf_callee_24>
  22945d:	0f 1f 00             	nopl   (%rax)

0000000000229460 <pf_call_4>:
  229460:	0f 18 15 14 ad e6 ff 	prefetcht1 -0x1952ec(%rip)        # 9417b <pf_target_3_7>
  229467:	0f 18 15 15 ad e6 ff 	prefetcht1 -0x1952eb(%rip)        # 94183 <pf_target_4_1>
  22946e:	0f 18 15 eb dc e6 ff 	prefetcht1 -0x192315(%rip)        # 97160 <pf_target_4_2>

0000000000229475 <pf_jump_4>:
  229475:	e9 46 76 e6 ff       	jmp    90ac0 <pf_callee_14>
  22947a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229480 <pf_call_5>:
  229480:	0f 18 15 c9 c5 ef ff 	prefetcht1 -0x103a37(%rip)        # 125a50 <pf_target_5_0>
  229487:	0f 18 15 22 d4 ef ff 	prefetcht1 -0x102bde(%rip)        # 1268b0 <pf_target_5_1>
  22948e:	0f 18 15 2c d4 ef ff 	prefetcht1 -0x102bd4(%rip)        # 1268c1 <pf_target_5_2>
  229495:	0f 18 15 e8 c5 ef ff 	prefetcht1 -0x103a18(%rip)        # 125a84 <pf_target_5_3>

000000000022949c <pf_jump_5>:
  22949c:	e9 5f d4 ef ff       	jmp    126900 <pf_callee_5>
  2294a1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2294a8:	00 00 00 
  2294ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000002294b0 <pf_call_6>:
  2294b0:	0f 18 15 8a b5 e6 ff 	prefetcht1 -0x194a76(%rip)        # 94a41 <pf_target_6_0>

00000000002294b7 <pf_jump_6>:
  2294b7:	e9 04 0f e1 ff       	jmp    3a3c0 <pf_callee_6>
  2294bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002294c0 <pf_call_7>:
  2294c0:	0f 18 15 19 74 e6 ff 	prefetcht1 -0x198be7(%rip)        # 908e0 <pf_target_7_0>
  2294c7:	0f 18 15 02 89 f2 ff 	prefetcht1 -0xd76fe(%rip)        # 151dd0 <pf_target_7_1>
  2294ce:	0f 18 15 ab 06 f2 ff 	prefetcht1 -0xdf955(%rip)        # 149b80 <pf_target_7_2>
  2294d5:	0f 18 15 d4 f3 f3 ff 	prefetcht1 -0xc0c2c(%rip)        # 1688b0 <pf_target_7_3>
  2294dc:	0f 18 15 de f3 f3 ff 	prefetcht1 -0xc0c22(%rip)        # 1688c1 <pf_target_7_4>
  2294e3:	0f 18 15 86 ee df ff 	prefetcht1 -0x20117a(%rip)        # 28370 <pf_target_7_5>
  2294ea:	0f 18 15 4f ec e7 ff 	prefetcht1 -0x1813b1(%rip)        # a8140 <pf_target_7_6>
  2294f1:	0f 18 15 c8 80 e6 ff 	prefetcht1 -0x197f38(%rip)        # 915c0 <pf_target_7_7>

00000000002294f8 <pf_jump_7>:
  2294f8:	e9 63 c8 e1 ff       	jmp    45d60 <pf_callee_7>
  2294fd:	0f 1f 00             	nopl   (%rax)

0000000000229500 <pf_call_8>:
  229500:	0f 18 15 28 89 f2 ff 	prefetcht1 -0xd76d8(%rip)        # 151e2f <pf_target_8_0>

0000000000229507 <pf_jump_8>:
  229507:	e9 a4 80 e6 ff       	jmp    915b0 <pf_callee_8>
  22950c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229510 <pf_call_9>:
  229510:	0f 18 15 a9 8a e6 ff 	prefetcht1 -0x197557(%rip)        # 91fc0 <pf_target_9_0>
  229517:	0f 18 15 a4 c1 e6 ff 	prefetcht1 -0x193e5c(%rip)        # 956c2 <pf_target_9_1>
  22951e:	0f 18 15 5b c1 e6 ff 	prefetcht1 -0x193ea5(%rip)        # 95680 <pf_target_9_2>

0000000000229525 <pf_jump_9>:
  229525:	e9 06 c8 e6 ff       	jmp    95d30 <pf_callee_9>
  22952a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229530 <pf_call_10>:
  229530:	0f 18 15 4c cf e6 ff 	prefetcht1 -0x1930b4(%rip)        # 96483 <pf_target_10_0>

0000000000229537 <pf_jump_10>:
  229537:	e9 84 8b e6 ff       	jmp    920c0 <pf_callee_10>
  22953c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229540 <pf_call_11>:
  229540:	0f 18 15 b9 d3 ef ff 	prefetcht1 -0x102c47(%rip)        # 126900 <pf_callee_5>

0000000000229547 <pf_jump_11>:
  229547:	e9 e4 7d e6 ff       	jmp    91330 <pf_callee_11>
  22954c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229550 <pf_call_12>:
  229550:	0f 18 15 b9 03 e7 ff 	prefetcht1 -0x18fc47(%rip)        # 99910 <pf_target_12_0>

0000000000229557 <pf_jump_12>:
  229557:	e9 84 7d e6 ff       	jmp    912e0 <pf_callee_12>
  22955c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229560 <pf_call_13>:
  229560:	0f 18 15 09 cf e6 ff 	prefetcht1 -0x1930f7(%rip)        # 96470 <pf_target_13_0>

0000000000229567 <pf_jump_13>:
  229567:	e9 24 75 e6 ff       	jmp    90a90 <pf_callee_13>
  22956c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229570 <pf_call_14>:
  229570:	0f 18 15 80 b3 e6 ff 	prefetcht1 -0x194c80(%rip)        # 948f7 <pf_target_14_0>
  229577:	0f 18 15 83 98 e6 ff 	prefetcht1 -0x19677d(%rip)        # 92e01 <pf_target_14_1>
  22957e:	0f 18 15 2b 80 e6 ff 	prefetcht1 -0x197fd5(%rip)        # 915b0 <pf_callee_8>

0000000000229585 <pf_jump_14>:
  229585:	e9 36 75 e6 ff       	jmp    90ac0 <pf_callee_14>
  22958a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229590 <pf_call_15>:
  229590:	0f 18 15 6a b6 f0 ff 	prefetcht1 -0xf4996(%rip)        # 134c01 <pf_target_15_0>
  229597:	0f 18 15 c2 c7 e1 ff 	prefetcht1 -0x1e383e(%rip)        # 45d60 <pf_callee_7>

000000000022959e <pf_jump_15>:
  22959e:	e9 2d 81 e7 ff       	jmp    a16d0 <pf_callee_15>
  2295a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2295aa:	00 00 00 
  2295ad:	0f 1f 00             	nopl   (%rax)

00000000002295b0 <pf_call_16>:
  2295b0:	0f 18 15 a9 c7 e1 ff 	prefetcht1 -0x1e3857(%rip)        # 45d60 <pf_callee_7>
  2295b7:	0f 18 15 c5 b4 e6 ff 	prefetcht1 -0x194b3b(%rip)        # 94a83 <pf_target_16_1>

00000000002295be <pf_jump_16>:
  2295be:	e9 ad a3 e7 ff       	jmp    a3970 <pf_callee_16>
  2295c3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2295ca:	00 00 00 
  2295cd:	0f 1f 00             	nopl   (%rax)

00000000002295d0 <pf_call_17>:
  2295d0:	0f 18 15 01 7b e7 ff 	prefetcht1 -0x1884ff(%rip)        # a10d8 <pf_target_17_0>

00000000002295d7 <pf_jump_17>:
  2295d7:	e9 74 7a e7 ff       	jmp    a1050 <pf_callee_17>
  2295dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002295e0 <pf_call_18>:
  2295e0:	0f 18 15 39 f0 df ff 	prefetcht1 -0x200fc7(%rip)        # 28620 <pf_target_18_0>

00000000002295e7 <pf_jump_18>:
  2295e7:	e9 84 a3 e7 ff       	jmp    a3970 <pf_callee_16>
  2295ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002295f0 <pf_call_19>:
  2295f0:	0f 18 15 0c 81 e7 ff 	prefetcht1 -0x187ef4(%rip)        # a1703 <pf_target_19_0>

00000000002295f7 <pf_jump_19>:
  2295f7:	e9 74 a3 e7 ff       	jmp    a3970 <pf_callee_16>
  2295fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229600 <pf_call_20>:
  229600:	0f 18 15 3b a2 e6 ff 	prefetcht1 -0x195dc5(%rip)        # 93842 <pf_target_20_0>
  229607:	0f 18 15 b2 55 ef ff 	prefetcht1 -0x10aa4e(%rip)        # 11ebc0 <pf_target_20_1>
  22960e:	0f 18 15 6b 09 e7 ff 	prefetcht1 -0x18f695(%rip)        # 99f80 <pf_target_20_2>
  229615:	0f 18 15 e4 a1 e6 ff 	prefetcht1 -0x195e1c(%rip)        # 93800 <pf_target_20_3>
  22961c:	0f 18 15 df 96 e7 ff 	prefetcht1 -0x186921(%rip)        # a2d02 <pf_target_20_4>
  229623:	0f 18 15 b6 ce e7 ff 	prefetcht1 -0x18314a(%rip)        # a64e0 <pf_target_20_5>
  22962a:	0f 18 15 bf 79 e6 ff 	prefetcht1 -0x198641(%rip)        # 90ff0 <pf_target_20_6>
  229631:	0f 18 15 89 a3 e6 ff 	prefetcht1 -0x195c77(%rip)        # 939c1 <pf_target_20_7>

0000000000229638 <pf_jump_20>:
  229638:	e9 23 90 e7 ff       	jmp    a2660 <pf_callee_20>
  22963d:	0f 1f 00             	nopl   (%rax)

0000000000229640 <pf_call_21>:
  229640:	0f 18 15 09 7a e7 ff 	prefetcht1 -0x1885f7(%rip)        # a1050 <pf_callee_17>

0000000000229647 <pf_jump_21>:
  229647:	e9 04 b3 e7 ff       	jmp    a4950 <pf_callee_21>
  22964c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229650 <pf_call_22>:
  229650:	0f 18 15 69 56 ef ff 	prefetcht1 -0x10a997(%rip)        # 11ecc0 <pf_target_22_0>
  229657:	0f 18 15 2f b5 e6 ff 	prefetcht1 -0x194ad1(%rip)        # 94b8d <pf_target_22_1>

000000000022965e <pf_jump_22>:
  22965e:	e9 3d bd e7 ff       	jmp    a53a0 <pf_callee_22>
  229663:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22966a:	00 00 00 
  22966d:	0f 1f 00             	nopl   (%rax)

0000000000229670 <pf_call_23>:
  229670:	0f 18 15 a1 d0 e7 ff 	prefetcht1 -0x182f5f(%rip)        # a6718 <pf_target_23_0>

0000000000229677 <pf_jump_23>:
  229677:	e9 f4 a2 e7 ff       	jmp    a3970 <pf_callee_16>
  22967c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229680 <pf_call_24>:
  229680:	0f 18 15 59 e0 ef ff 	prefetcht1 -0x101fa7(%rip)        # 1276e0 <pf_target_24_0>
  229687:	0f 18 15 f2 d1 f7 ff 	prefetcht1 -0x82e0e(%rip)        # 1a6880 <pf_target_24_1>

000000000022968e <pf_jump_24>:
  22968e:	e9 8d 73 e6 ff       	jmp    90a20 <pf_callee_24>
  229693:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22969a:	00 00 00 
  22969d:	0f 1f 00             	nopl   (%rax)

00000000002296a0 <pf_call_25>:
  2296a0:	0f 18 15 5a 20 ef ff 	prefetcht1 -0x10dfa6(%rip)        # 11b701 <pf_target_25_0>
  2296a7:	0f 18 15 4e 20 ef ff 	prefetcht1 -0x10dfb2(%rip)        # 11b6fc <pf_target_25_1>
  2296ae:	0f 18 15 9b ce f0 ff 	prefetcht1 -0xf3165(%rip)        # 136550 <pf_target_25_2>

00000000002296b5 <pf_jump_25>:
  2296b5:	e9 66 73 e6 ff       	jmp    90a20 <pf_callee_24>
