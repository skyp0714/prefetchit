
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_neighbor/beee2b363cdd95391e3db419aeccb36e2dd16c7f8b7f4c3f560bd878fc4c6e7b/call-stub-sotia959/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000110340 <pf_call_0>:
  110340:	0f 18 15 e9 88 f3 ff 	prefetcht1 -0xc7717(%rip)        # 48c30 <pf_target_0_0>
  110347:	0f 18 15 62 31 f3 ff 	prefetcht1 -0xcce9e(%rip)        # 434b0 <pf_target_0_1>
  11034e:	0f 18 15 af 31 f3 ff 	prefetcht1 -0xcce51(%rip)        # 43504 <pf_target_0_2>
  110355:	0f 18 15 c4 3b f3 ff 	prefetcht1 -0xcc43c(%rip)        # 43f20 <pf_target_0_3>
  11035c:	0f 18 15 a1 3c f3 ff 	prefetcht1 -0xcc35f(%rip)        # 44004 <pf_target_0_4>
  110363:	0f 18 15 d8 88 f3 ff 	prefetcht1 -0xc7728(%rip)        # 48c42 <pf_target_0_5>
  11036a:	0f 18 15 11 89 f3 ff 	prefetcht1 -0xc76ef(%rip)        # 48c82 <pf_target_0_6>
  110371:	0f 18 15 4a 32 f3 ff 	prefetcht1 -0xccdb6(%rip)        # 435c2 <pf_target_0_7>

0000000000110378 <pf_jump_0>:
  110378:	e9 a3 5f f1 ff       	jmp    26320 <pf_callee_0>
  11037d:	0f 1f 00             	nopl   (%rax)

0000000000110380 <pf_call_1>:
  110380:	0f 18 15 19 06 f2 ff 	prefetcht1 -0xdf9e7(%rip)        # 309a0 <pf_target_1_0>
  110387:	0f 18 15 32 06 f2 ff 	prefetcht1 -0xdf9ce(%rip)        # 309c0 <pf_target_1_1>
  11038e:	41 53                	push   %r11
  110390:	4c 8b 1d 49 dd ff ff 	mov    -0x22b7(%rip),%r11        # 10e0e0 <pf_got_1_0>

0000000000110397 <pf_got_hint_1_0>:
  110397:	41 0f 18 93 b0 06 00 	prefetcht1 0x6b0(%r11)
  11039e:	00 

000000000011039f <pf_got_hint_1_1>:
  11039f:	41 0f 18 93 d2 06 00 	prefetcht1 0x6d2(%r11)
  1103a6:	00 
  1103a7:	4c 8b 1d ea e0 ff ff 	mov    -0x1f16(%rip),%r11        # 10e498 <pf_got_17_0>

00000000001103ae <pf_got_hint_1_2>:
  1103ae:	41 0f 18 93 10 5d fe 	prefetcht1 -0x1a2f0(%r11)
  1103b5:	ff 
  1103b6:	41 5b                	pop    %r11

00000000001103b8 <pf_jump_1>:
  1103b8:	e9 63 5f f1 ff       	jmp    26320 <pf_callee_0>
  1103bd:	0f 1f 00             	nopl   (%rax)

00000000001103c0 <pf_call_2>:
  1103c0:	41 53                	push   %r11
  1103c2:	4c 8b 1d cf e0 ff ff 	mov    -0x1f31(%rip),%r11        # 10e498 <pf_got_17_0>

00000000001103c9 <pf_got_hint_2_0>:
  1103c9:	41 0f 18 93 50 79 00 	prefetcht1 0x7950(%r11)
  1103d0:	00 
  1103d1:	4c 8b 1d 70 e3 ff ff 	mov    -0x1c90(%rip),%r11        # 10e748 <pf_got_2_1>

00000000001103d8 <pf_got_hint_2_1>:
  1103d8:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1103df:	00 

00000000001103e0 <pf_got_hint_2_2>:
  1103e0:	41 0f 18 93 34 00 00 	prefetcht1 0x34(%r11)
  1103e7:	00 
  1103e8:	41 5b                	pop    %r11

00000000001103ea <pf_jump_2>:
  1103ea:	e9 31 5f f1 ff       	jmp    26320 <pf_callee_0>
  1103ef:	90                   	nop

00000000001103f0 <pf_call_3>:
  1103f0:	0f 18 15 09 8c f5 ff 	prefetcht1 -0xa73f7(%rip)        # 69000 <pf_target_3_0>
  1103f7:	0f 18 15 d2 bd f4 ff 	prefetcht1 -0xb422e(%rip)        # 5c1d0 <pf_target_3_1>

00000000001103fe <pf_jump_3>:
  1103fe:	e9 cd 06 f2 ff       	jmp    30ad0 <pf_callee_3>
  110403:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11040a:	00 00 00 
  11040d:	0f 1f 00             	nopl   (%rax)

0000000000110410 <pf_call_4>:
  110410:	41 53                	push   %r11
  110412:	4c 8b 1d 7f e0 ff ff 	mov    -0x1f81(%rip),%r11        # 10e498 <pf_got_17_0>

0000000000110419 <pf_got_hint_4_0>:
  110419:	41 0f 18 93 c1 af ff 	prefetcht1 -0x503f(%r11)
  110420:	ff 
  110421:	41 5b                	pop    %r11

0000000000110423 <pf_jump_4>:
  110423:	e9 58 6a f1 ff       	jmp    26e80 <pf_callee_4>
  110428:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11042f:	00 

0000000000110430 <pf_call_5>:
  110430:	0f 18 15 2f 95 f3 ff 	prefetcht1 -0xc6ad1(%rip)        # 49966 <pf_target_5_0>
  110437:	41 53                	push   %r11
  110439:	4c 8b 1d 58 e0 ff ff 	mov    -0x1fa8(%rip),%r11        # 10e498 <pf_got_17_0>

0000000000110440 <pf_got_hint_5_0>:
  110440:	41 0f 18 93 30 f5 ff 	prefetcht1 -0xad0(%r11)
  110447:	ff 

0000000000110448 <pf_got_hint_5_1>:
  110448:	41 0f 18 93 41 f5 ff 	prefetcht1 -0xabf(%r11)
  11044f:	ff 
  110450:	41 5b                	pop    %r11

0000000000110452 <pf_jump_5>:
  110452:	e9 59 94 f3 ff       	jmp    498b0 <pf_callee_5>
  110457:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  11045e:	00 00 

0000000000110460 <pf_call_6>:
  110460:	0f 18 15 f9 bd f4 ff 	prefetcht1 -0xb4207(%rip)        # 5c260 <pf_target_6_0>
  110467:	41 53                	push   %r11
  110469:	4c 8b 1d b8 df ff ff 	mov    -0x2048(%rip),%r11        # 10e428 <pf_got_6_0>

0000000000110470 <pf_got_hint_6_0>:
  110470:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110477:	00 
  110478:	41 5b                	pop    %r11

000000000011047a <pf_jump_6>:
  11047a:	e9 91 5e f1 ff       	jmp    26310 <pf_callee_6>
  11047f:	90                   	nop

0000000000110480 <pf_call_7>:
  110480:	0f 18 15 79 31 f3 ff 	prefetcht1 -0xcce87(%rip)        # 43600 <pf_target_7_0>

0000000000110487 <pf_jump_7>:
  110487:	e9 34 5d f1 ff       	jmp    261c0 <pf_callee_7>
  11048c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110490 <pf_call_8>:
  110490:	41 53                	push   %r11
  110492:	4c 8b 1d ff df ff ff 	mov    -0x2001(%rip),%r11        # 10e498 <pf_got_17_0>

0000000000110499 <pf_got_hint_8_0>:
  110499:	41 0f 18 93 20 6f fe 	prefetcht1 -0x190e0(%r11)
  1104a0:	ff 
  1104a1:	41 5b                	pop    %r11

00000000001104a3 <pf_jump_8>:
  1104a3:	e9 a8 37 f3 ff       	jmp    43c50 <pf_callee_8>
  1104a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1104af:	00 

00000000001104b0 <pf_call_9>:
  1104b0:	41 53                	push   %r11
  1104b2:	4c 8b 1d bf de ff ff 	mov    -0x2141(%rip),%r11        # 10e378 <pf_got_9_0>

00000000001104b9 <pf_got_hint_9_0>:
  1104b9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1104c0:	00 
  1104c1:	4c 8b 1d c8 e2 ff ff 	mov    -0x1d38(%rip),%r11        # 10e790 <pf_got_17_4>

00000000001104c8 <pf_got_hint_9_1>:
  1104c8:	41 0f 18 93 70 e8 fe 	prefetcht1 -0x11790(%r11)
  1104cf:	ff 

00000000001104d0 <pf_got_hint_9_2>:
  1104d0:	41 0f 18 93 20 26 ff 	prefetcht1 -0xd9e0(%r11)
  1104d7:	ff 

00000000001104d8 <pf_got_hint_9_3>:
  1104d8:	41 0f 18 93 31 26 ff 	prefetcht1 -0xd9cf(%r11)
  1104df:	ff 

00000000001104e0 <pf_got_hint_9_4>:
  1104e0:	41 0f 18 93 10 29 ff 	prefetcht1 -0xd6f0(%r11)
  1104e7:	ff 

00000000001104e8 <pf_got_hint_9_5>:
  1104e8:	41 0f 18 93 a0 f5 ff 	prefetcht1 -0xa60(%r11)
  1104ef:	ff 

00000000001104f0 <pf_got_hint_9_6>:
  1104f0:	41 0f 18 93 b0 f5 ff 	prefetcht1 -0xa50(%r11)
  1104f7:	ff 
  1104f8:	41 5b                	pop    %r11

00000000001104fa <pf_jump_9>:
  1104fa:	e9 d1 51 f3 ff       	jmp    456d0 <pf_callee_9>
  1104ff:	90                   	nop

0000000000110500 <pf_call_10>:
  110500:	0f 18 15 29 61 f1 ff 	prefetcht1 -0xe9ed7(%rip)        # 26630 <pf_target_10_0>
  110507:	41 53                	push   %r11
  110509:	4c 8b 1d 08 de ff ff 	mov    -0x21f8(%rip),%r11        # 10e318 <pf_got_10_0>

0000000000110510 <pf_got_hint_10_0>:
  110510:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110517:	00 

0000000000110518 <pf_got_hint_10_1>:
  110518:	41 0f 18 93 11 00 00 	prefetcht1 0x11(%r11)
  11051f:	00 
  110520:	41 5b                	pop    %r11

0000000000110522 <pf_jump_10>:
  110522:	e9 b9 64 f1 ff       	jmp    269e0 <pf_callee_10>
  110527:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  11052e:	00 00 

0000000000110530 <pf_call_11>:
  110530:	41 53                	push   %r11
  110532:	4c 8b 1d 67 db ff ff 	mov    -0x2499(%rip),%r11        # 10e0a0 <pf_got_11_0>

0000000000110539 <pf_got_hint_11_0>:
  110539:	41 0f 18 93 20 4a ff 	prefetcht1 -0xb5e0(%r11)
  110540:	ff 
  110541:	41 5b                	pop    %r11

0000000000110543 <pf_jump_11>:
  110543:	e9 a8 5b f1 ff       	jmp    260f0 <pf_callee_11>
  110548:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11054f:	00 

0000000000110550 <pf_call_12>:
  110550:	0f 18 15 b9 35 f3 ff 	prefetcht1 -0xcca47(%rip)        # 43b10 <pf_target_12_0>
  110557:	0f 18 15 e6 35 f3 ff 	prefetcht1 -0xcca1a(%rip)        # 43b44 <pf_target_12_1>

000000000011055e <pf_jump_12>:
  11055e:	e9 8d 5b f1 ff       	jmp    260f0 <pf_callee_11>
  110563:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11056a:	00 00 00 
  11056d:	0f 1f 00             	nopl   (%rax)

0000000000110570 <pf_call_13>:
  110570:	0f 18 15 09 94 f3 ff 	prefetcht1 -0xc6bf7(%rip)        # 49980 <pf_callee_23>

0000000000110577 <pf_jump_13>:
  110577:	e9 d4 fd f2 ff       	jmp    40350 <pf_callee_13>
  11057c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110580 <pf_call_14>:
  110580:	0f 18 15 09 36 f3 ff 	prefetcht1 -0xcc9f7(%rip)        # 43b90 <pf_target_14_0>

0000000000110587 <pf_jump_14>:
  110587:	e9 44 3a f3 ff       	jmp    43fd0 <pf_callee_14>
  11058c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110590 <pf_call_15>:
  110590:	0f 18 15 19 4f f3 ff 	prefetcht1 -0xcb0e7(%rip)        # 454b0 <pf_target_15_0>
  110597:	0f 18 15 24 4f f3 ff 	prefetcht1 -0xcb0dc(%rip)        # 454c2 <pf_target_15_1>

000000000011059e <pf_jump_15>:
  11059e:	e9 9d 5b f1 ff       	jmp    26140 <pf_callee_15>
  1105a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1105aa:	00 00 00 
  1105ad:	0f 1f 00             	nopl   (%rax)

00000000001105b0 <pf_call_16>:
  1105b0:	0f 18 15 39 68 f1 ff 	prefetcht1 -0xe97c7(%rip)        # 26df0 <pf_target_16_0>
  1105b7:	41 53                	push   %r11
  1105b9:	4c 8b 1d 38 e1 ff ff 	mov    -0x1ec8(%rip),%r11        # 10e6f8 <pf_got_16_0>

00000000001105c0 <pf_got_hint_16_0>:
  1105c0:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1105c7:	00 
  1105c8:	41 5b                	pop    %r11

00000000001105ca <pf_jump_16>:
  1105ca:	e9 71 5b f1 ff       	jmp    26140 <pf_callee_15>
  1105cf:	90                   	nop

00000000001105d0 <pf_call_17>:
  1105d0:	41 53                	push   %r11
  1105d2:	4c 8b 1d bf de ff ff 	mov    -0x2141(%rip),%r11        # 10e498 <pf_got_17_0>

00000000001105d9 <pf_got_hint_17_0>:
  1105d9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  1105e0:	00 

00000000001105e1 <pf_got_hint_17_1>:
  1105e1:	41 0f 18 93 44 00 00 	prefetcht1 0x44(%r11)
  1105e8:	00 

00000000001105e9 <pf_got_hint_17_2>:
  1105e9:	41 0f 18 93 88 00 00 	prefetcht1 0x88(%r11)
  1105f0:	00 

00000000001105f1 <pf_got_hint_17_3>:
  1105f1:	41 0f 18 93 c3 00 00 	prefetcht1 0xc3(%r11)
  1105f8:	00 
  1105f9:	4c 8b 1d 90 e1 ff ff 	mov    -0x1e70(%rip),%r11        # 10e790 <pf_got_17_4>

0000000000110600 <pf_got_hint_17_4>:
  110600:	41 0f 18 93 b0 3e fe 	prefetcht1 -0x1c150(%r11)
  110607:	ff 

0000000000110608 <pf_got_hint_17_5>:
  110608:	41 0f 18 93 40 46 fe 	prefetcht1 -0x1b9c0(%r11)
  11060f:	ff 

0000000000110610 <pf_got_hint_17_6>:
  110610:	41 0f 18 93 70 46 fe 	prefetcht1 -0x1b990(%r11)
  110617:	ff 
  110618:	41 5b                	pop    %r11

000000000011061a <pf_jump_17>:
  11061a:	e9 11 63 f1 ff       	jmp    26930 <pf_callee_17>
  11061f:	90                   	nop

0000000000110620 <pf_call_18>:
  110620:	0f 18 15 29 fd f2 ff 	prefetcht1 -0xd02d7(%rip)        # 40350 <pf_callee_13>

0000000000110627 <pf_jump_18>:
  110627:	e9 24 49 f3 ff       	jmp    44f50 <pf_callee_18>
  11062c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110630 <pf_call_19>:
  110630:	0f 18 15 e9 43 f3 ff 	prefetcht1 -0xcbc17(%rip)        # 44a20 <pf_target_19_0>

0000000000110637 <pf_jump_19>:
  110637:	e9 14 fd f2 ff       	jmp    40350 <pf_callee_13>
  11063c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110640 <pf_call_20>:
  110640:	0f 18 15 09 69 f1 ff 	prefetcht1 -0xe96f7(%rip)        # 26f50 <pf_target_20_0>
  110647:	41 53                	push   %r11
  110649:	4c 8b 1d e0 de ff ff 	mov    -0x2120(%rip),%r11        # 10e530 <pf_got_20_0>

0000000000110650 <pf_got_hint_20_0>:
  110650:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110657:	00 
  110658:	41 5b                	pop    %r11

000000000011065a <pf_jump_20>:
  11065a:	e9 f1 fc f2 ff       	jmp    40350 <pf_callee_13>
  11065f:	90                   	nop

0000000000110660 <pf_call_21>:
  110660:	0f 18 15 b9 69 f1 ff 	prefetcht1 -0xe9647(%rip)        # 27020 <pf_target_21_0>
  110667:	41 53                	push   %r11
  110669:	4c 8b 1d a0 e1 ff ff 	mov    -0x1e60(%rip),%r11        # 10e810 <pf_got_21_0>

0000000000110670 <pf_got_hint_21_0>:
  110670:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110677:	00 
  110678:	41 5b                	pop    %r11

000000000011067a <pf_jump_21>:
  11067a:	e9 e1 8e f3 ff       	jmp    49560 <pf_callee_21>
  11067f:	90                   	nop

0000000000110680 <pf_call_22>:
  110680:	0f 18 15 0e 16 f5 ff 	prefetcht1 -0xae9f2(%rip)        # 61c95 <pf_target_22_0>
  110687:	0f 18 15 69 33 f5 ff 	prefetcht1 -0xacc97(%rip)        # 639f7 <pf_target_22_1>
  11068e:	0f 18 15 2b c9 f4 ff 	prefetcht1 -0xb36d5(%rip)        # 5cfc0 <pf_target_22_2>
  110695:	0f 18 15 44 be f4 ff 	prefetcht1 -0xb41bc(%rip)        # 5c4e0 <pf_target_22_3>
  11069c:	0f 18 15 23 12 f5 ff 	prefetcht1 -0xaeddd(%rip)        # 618c6 <pf_target_22_4>

00000000001106a3 <pf_jump_22>:
  1106a3:	e9 98 5a f1 ff       	jmp    26140 <pf_callee_15>
  1106a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1106af:	00 

00000000001106b0 <pf_call_23>:
  1106b0:	0f 18 15 a6 19 f5 ff 	prefetcht1 -0xae65a(%rip)        # 6205d <pf_target_23_0>

00000000001106b7 <pf_jump_23>:
  1106b7:	e9 c4 92 f3 ff       	jmp    49980 <pf_callee_23>
  1106bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001106c0 <pf_call_24>:
  1106c0:	0f 18 15 a9 c6 f4 ff 	prefetcht1 -0xb3957(%rip)        # 5cd70 <pf_target_24_0>
  1106c7:	0f 18 15 b6 c6 f4 ff 	prefetcht1 -0xb394a(%rip)        # 5cd84 <pf_target_24_1>

00000000001106ce <pf_jump_24>:
  1106ce:	e9 0d 60 f1 ff       	jmp    266e0 <pf_callee_24>
  1106d3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1106da:	00 00 00 
  1106dd:	0f 1f 00             	nopl   (%rax)

00000000001106e0 <pf_call_25>:
  1106e0:	0f 18 15 d9 3a f5 ff 	prefetcht1 -0xac527(%rip)        # 641c0 <pf_callee_28>
  1106e7:	41 53                	push   %r11
  1106e9:	4c 8b 1d b0 d9 ff ff 	mov    -0x2650(%rip),%r11        # 10e0a0 <pf_got_11_0>

00000000001106f0 <pf_got_hint_25_0>:
  1106f0:	41 0f 18 93 b0 53 ff 	prefetcht1 -0xac50(%r11)
  1106f7:	ff 
  1106f8:	4c 8b 1d e1 d9 ff ff 	mov    -0x261f(%rip),%r11        # 10e0e0 <pf_got_1_0>

00000000001106ff <pf_got_hint_25_1>:
  1106ff:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110706:	00 
  110707:	4c 8b 1d e2 dd ff ff 	mov    -0x221e(%rip),%r11        # 10e4f0 <pf_got_25_2>

000000000011070e <pf_got_hint_25_2>:
  11070e:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110715:	00 
  110716:	41 5b                	pop    %r11

0000000000110718 <pf_jump_25>:
  110718:	e9 73 cd f4 ff       	jmp    5d490 <pf_callee_25>
  11071d:	0f 1f 00             	nopl   (%rax)

0000000000110720 <pf_call_26>:
  110720:	0f 18 15 b9 5f f1 ff 	prefetcht1 -0xea047(%rip)        # 266e0 <pf_callee_24>
  110727:	0f 18 15 62 69 f1 ff 	prefetcht1 -0xe969e(%rip)        # 27090 <pf_callee_29>
  11072e:	0f 18 15 4b 10 f5 ff 	prefetcht1 -0xaefb5(%rip)        # 61780 <pf_target_26_2>
  110735:	0f 18 15 90 32 f5 ff 	prefetcht1 -0xacd70(%rip)        # 639cc <pf_target_26_3>
  11073c:	0f 18 15 8d 66 f1 ff 	prefetcht1 -0xe9973(%rip)        # 26dd0 <pf_callee_31>
  110743:	0f 18 15 85 8b f5 ff 	prefetcht1 -0xa747b(%rip)        # 692cf <pf_target_26_5>
  11074a:	41 53                	push   %r11
  11074c:	4c 8b 1d 1d dc ff ff 	mov    -0x23e3(%rip),%r11        # 10e370 <pf_got_26_0>

0000000000110753 <pf_got_hint_26_0>:
  110753:	41 0f 18 93 10 00 00 	prefetcht1 0x10(%r11)
  11075a:	00 

000000000011075b <pf_got_hint_26_1>:
  11075b:	41 0f 18 93 d8 01 00 	prefetcht1 0x1d8(%r11)
  110762:	00 
  110763:	41 5b                	pop    %r11

0000000000110765 <pf_jump_26>:
  110765:	e9 26 cd f4 ff       	jmp    5d490 <pf_callee_25>
  11076a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000110770 <pf_call_27>:
  110770:	41 53                	push   %r11
  110772:	4c 8b 1d 6f df ff ff 	mov    -0x2091(%rip),%r11        # 10e6e8 <pf_got_27_0>

0000000000110779 <pf_got_hint_27_0>:
  110779:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  110780:	00 
  110781:	41 5b                	pop    %r11

0000000000110783 <pf_jump_27>:
  110783:	e9 58 5f f1 ff       	jmp    266e0 <pf_callee_24>
  110788:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11078f:	00 

0000000000110790 <pf_call_28>:
  110790:	0f 18 15 e9 8a f3 ff 	prefetcht1 -0xc7517(%rip)        # 49280 <pf_target_28_0>
  110797:	0f 18 15 db 8e f3 ff 	prefetcht1 -0xc7125(%rip)        # 49679 <pf_target_28_1>
  11079e:	0f 18 15 dc 8e f3 ff 	prefetcht1 -0xc7124(%rip)        # 49681 <pf_target_28_2>

00000000001107a5 <pf_jump_28>:
  1107a5:	e9 16 3a f5 ff       	jmp    641c0 <pf_callee_28>
  1107aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000001107b0 <pf_call_29>:
  1107b0:	0f 18 15 f9 15 f5 ff 	prefetcht1 -0xaea07(%rip)        # 61db0 <pf_target_29_0>
  1107b7:	0f 18 15 d2 f9 f4 ff 	prefetcht1 -0xb062e(%rip)        # 60190 <pf_target_29_1>
  1107be:	0f 18 15 ab c1 f4 ff 	prefetcht1 -0xb3e55(%rip)        # 5c970 <pf_target_29_2>
  1107c5:	0f 18 15 f5 15 f5 ff 	prefetcht1 -0xaea0b(%rip)        # 61dc1 <pf_target_29_3>
  1107cc:	0f 18 15 f1 f9 f4 ff 	prefetcht1 -0xb060f(%rip)        # 601c4 <pf_target_29_4>

00000000001107d3 <pf_jump_29>:
  1107d3:	e9 b8 68 f1 ff       	jmp    27090 <pf_callee_29>
  1107d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1107df:	00 

00000000001107e0 <pf_call_30>:
  1107e0:	0f 18 15 99 31 f5 ff 	prefetcht1 -0xace67(%rip)        # 63980 <pf_target_30_0>

00000000001107e7 <pf_jump_30>:
  1107e7:	e9 54 59 f1 ff       	jmp    26140 <pf_callee_15>
  1107ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001107f0 <pf_call_31>:
  1107f0:	0f 18 15 f9 4b f5 ff 	prefetcht1 -0xab407(%rip)        # 653f0 <pf_target_31_0>
  1107f7:	0f 18 15 05 4c f5 ff 	prefetcht1 -0xab3fb(%rip)        # 65403 <pf_target_31_1>
  1107fe:	41 53                	push   %r11
  110800:	4c 8b 1d 99 d8 ff ff 	mov    -0x2767(%rip),%r11        # 10e0a0 <pf_got_11_0>

0000000000110807 <pf_got_hint_31_0>:
  110807:	41 0f 18 93 e0 48 ff 	prefetcht1 -0xb720(%r11)
  11080e:	ff 
  11080f:	4c 8b 1d d2 de ff ff 	mov    -0x212e(%rip),%r11        # 10e6e8 <pf_got_27_0>

0000000000110816 <pf_got_hint_31_1>:
  110816:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  11081d:	00 
  11081e:	41 5b                	pop    %r11

0000000000110820 <pf_jump_31>:
  110820:	e9 ab 65 f1 ff       	jmp    26dd0 <pf_callee_31>
  110825:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11082c:	00 00 00 
  11082f:	90                   	nop

0000000000110830 <pf_call_32>:
  110830:	0f 18 15 aa da f1 ff 	prefetcht1 -0xe2556(%rip)        # 2e2e1 <pf_target_32_0>
  110837:	0f 18 15 06 0e f2 ff 	prefetcht1 -0xdf1fa(%rip)        # 31644 <pf_target_32_1>
  11083e:	41 53                	push   %r11
  110840:	4c 8b 1d 21 d8 ff ff 	mov    -0x27df(%rip),%r11        # 10e068 <pf_got_32_0>

0000000000110847 <pf_got_hint_32_0>:
  110847:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  11084e:	00 
  11084f:	41 5b                	pop    %r11

0000000000110851 <pf_jump_32>:
  110851:	e9 aa 83 f6 ff       	jmp    78c00 <pf_callee_32>
