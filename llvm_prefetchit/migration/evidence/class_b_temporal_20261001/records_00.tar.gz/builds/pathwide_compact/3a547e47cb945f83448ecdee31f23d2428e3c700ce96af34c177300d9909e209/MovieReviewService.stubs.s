.text
.balign 16
.global pf_call_0
.type pf_call_0,@function
pf_call_0:
.cfi_startproc
prefetcht1 pf_target_0_0(%rip)
prefetcht1 pf_target_0_1(%rip)
prefetcht1 pf_target_0_2(%rip)
prefetcht1 pf_target_0_3(%rip)
prefetcht1 pf_target_0_4(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_0_0(%rip),%r11
.global pf_got_hint_0_0
pf_got_hint_0_0:
.byte 0x41,0x0f,0x18,0x93
.long -105040
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_0
pf_jump_0:
jmp pf_callee_0
.cfi_endproc
.size pf_call_0,.-pf_call_0
.balign 16
.global pf_call_1
.type pf_call_1,@function
pf_call_1:
.cfi_startproc
prefetcht1 pf_target_1_0(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_1_0(%rip),%r11
.global pf_got_hint_1_0
pf_got_hint_1_0:
.byte 0x41,0x0f,0x18,0x93
.long 1712
.global pf_got_hint_1_1
pf_got_hint_1_1:
.byte 0x41,0x0f,0x18,0x93
.long 1746
mov pf_got_1_2(%rip),%r11
.global pf_got_hint_1_2
pf_got_hint_1_2:
.byte 0x41,0x0f,0x18,0x93
.long 8133
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_1
pf_jump_1:
jmp pf_callee_1
.cfi_endproc
.size pf_call_1,.-pf_call_1
.balign 16
.global pf_call_2
.type pf_call_2,@function
pf_call_2:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_2_0(%rip),%r11
.global pf_got_hint_2_0
pf_got_hint_2_0:
.byte 0x41,0x0f,0x18,0x93
.long 93568
.global pf_got_hint_2_1
pf_got_hint_2_1:
.byte 0x41,0x0f,0x18,0x93
.long 93584
mov pf_got_2_2(%rip),%r11
.global pf_got_hint_2_2
pf_got_hint_2_2:
.byte 0x41,0x0f,0x18,0x93
.long -40688
.global pf_got_hint_2_3
pf_got_hint_2_3:
.byte 0x41,0x0f,0x18,0x93
.long -40192
.global pf_got_hint_2_4
pf_got_hint_2_4:
.byte 0x41,0x0f,0x18,0x93
.long -34864
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_2
pf_jump_2:
jmp pf_callee_2
.cfi_endproc
.size pf_call_2,.-pf_call_2
.balign 16
.global pf_call_3
.type pf_call_3,@function
pf_call_3:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_3_0(%rip),%r11
.global pf_got_hint_3_0
pf_got_hint_3_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_3_1
pf_got_hint_3_1:
.byte 0x41,0x0f,0x18,0x93
.long 128
mov pf_got_3_2(%rip),%r11
.global pf_got_hint_3_2
pf_got_hint_3_2:
.byte 0x41,0x0f,0x18,0x93
.long 54944
mov pf_got_3_3(%rip),%r11
.global pf_got_hint_3_3
pf_got_hint_3_3:
.byte 0x41,0x0f,0x18,0x93
.long 320
.global pf_got_hint_3_4
pf_got_hint_3_4:
.byte 0x41,0x0f,0x18,0x93
.long 341
.global pf_got_hint_3_5
pf_got_hint_3_5:
.byte 0x41,0x0f,0x18,0x93
.long 7344
.global pf_got_hint_3_6
pf_got_hint_3_6:
.byte 0x41,0x0f,0x18,0x93
.long 7377
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_3
pf_jump_3:
jmp pf_callee_3
.cfi_endproc
.size pf_call_3,.-pf_call_3
.balign 16
.global pf_call_4
.type pf_call_4,@function
pf_call_4:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_4_0(%rip),%r11
.global pf_got_hint_4_0
pf_got_hint_4_0:
.byte 0x41,0x0f,0x18,0x93
.long 2560
mov pf_got_4_1(%rip),%r11
.global pf_got_hint_4_1
pf_got_hint_4_1:
.byte 0x41,0x0f,0x18,0x93
.long 288
.global pf_got_hint_4_2
pf_got_hint_4_2:
.byte 0x41,0x0f,0x18,0x93
.long 152832
.global pf_got_hint_4_3
pf_got_hint_4_3:
.byte 0x41,0x0f,0x18,0x93
.long 170192
mov pf_got_4_4(%rip),%r11
.global pf_got_hint_4_4
pf_got_hint_4_4:
.byte 0x41,0x0f,0x18,0x93
.long -45168
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_4
pf_jump_4:
jmp pf_callee_4
.cfi_endproc
.size pf_call_4,.-pf_call_4
.balign 16
.global pf_call_5
.type pf_call_5,@function
pf_call_5:
.cfi_startproc
prefetcht1 pf_target_5_0(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_5_0(%rip),%r11
.global pf_got_hint_5_0
pf_got_hint_5_0:
.byte 0x41,0x0f,0x18,0x93
.long 3584
.global pf_got_hint_5_1
pf_got_hint_5_1:
.byte 0x41,0x0f,0x18,0x93
.long 3634
mov pf_got_5_2(%rip),%r11
.global pf_got_hint_5_2
pf_got_hint_5_2:
.byte 0x41,0x0f,0x18,0x93
.long -336
.global pf_got_hint_5_3
pf_got_hint_5_3:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_5_4
pf_got_hint_5_4:
.byte 0x41,0x0f,0x18,0x93
.long 19
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_5
pf_jump_5:
jmp pf_callee_5
.cfi_endproc
.size pf_call_5,.-pf_call_5
.balign 16
.global pf_call_6
.type pf_call_6,@function
pf_call_6:
.cfi_startproc
prefetcht1 pf_target_6_0(%rip)
prefetcht1 pf_target_6_1(%rip)
.global pf_jump_6
pf_jump_6:
jmp pf_callee_6
.cfi_endproc
.size pf_call_6,.-pf_call_6
.balign 16
.global pf_call_7
.type pf_call_7,@function
pf_call_7:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_7_0(%rip),%r11
.global pf_got_hint_7_0
pf_got_hint_7_0:
.byte 0x41,0x0f,0x18,0x93
.long 1712
.global pf_got_hint_7_1
pf_got_hint_7_1:
.byte 0x41,0x0f,0x18,0x93
.long 1746
mov pf_got_7_2(%rip),%r11
.global pf_got_hint_7_2
pf_got_hint_7_2:
.byte 0x41,0x0f,0x18,0x93
.long 7520
.global pf_got_hint_7_3
pf_got_hint_7_3:
.byte 0x41,0x0f,0x18,0x93
.long 8133
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_7
pf_jump_7:
jmp pf_callee_7
.cfi_endproc
.size pf_call_7,.-pf_call_7
.balign 16
.global pf_call_8
.type pf_call_8,@function
pf_call_8:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_8_0(%rip),%r11
.global pf_got_hint_8_0
pf_got_hint_8_0:
.byte 0x41,0x0f,0x18,0x93
.long 50563
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_8
pf_jump_8:
jmp pf_callee_8
.cfi_endproc
.size pf_call_8,.-pf_call_8
.balign 16
.global pf_call_9
.type pf_call_9,@function
pf_call_9:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_9_0(%rip),%r11
.global pf_got_hint_9_0
pf_got_hint_9_0:
.byte 0x41,0x0f,0x18,0x93
.long -102624
.global pf_got_hint_9_1
pf_got_hint_9_1:
.byte 0x41,0x0f,0x18,0x93
.long -21232
.global pf_got_hint_9_2
pf_got_hint_9_2:
.byte 0x41,0x0f,0x18,0x93
.long -21183
.global pf_got_hint_9_3
pf_got_hint_9_3:
.byte 0x41,0x0f,0x18,0x93
.long 355760
mov pf_got_9_4(%rip),%r11
.global pf_got_hint_9_4
pf_got_hint_9_4:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_9
pf_jump_9:
jmp pf_callee_9
.cfi_endproc
.size pf_call_9,.-pf_call_9
.balign 16
.global pf_call_10
.type pf_call_10,@function
pf_call_10:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_10_0(%rip),%r11
.global pf_got_hint_10_0
pf_got_hint_10_0:
.byte 0x41,0x0f,0x18,0x93
.long -2768
.global pf_got_hint_10_1
pf_got_hint_10_1:
.byte 0x41,0x0f,0x18,0x93
.long -2751
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_10
pf_jump_10:
jmp pf_callee_10
.cfi_endproc
.size pf_call_10,.-pf_call_10
.balign 16
.global pf_call_11
.type pf_call_11,@function
pf_call_11:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_11_0(%rip),%r11
.global pf_got_hint_11_0
pf_got_hint_11_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
mov pf_got_11_1(%rip),%r11
.global pf_got_hint_11_1
pf_got_hint_11_1:
.byte 0x41,0x0f,0x18,0x93
.long 11776
.global pf_got_hint_11_2
pf_got_hint_11_2:
.byte 0x41,0x0f,0x18,0x93
.long 11792
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_11
pf_jump_11:
jmp pf_callee_11
.cfi_endproc
.size pf_call_11,.-pf_call_11
.balign 16
.global pf_call_12
.type pf_call_12,@function
pf_call_12:
.cfi_startproc
prefetcht1 pf_target_12_0(%rip)
prefetcht1 pf_target_12_1(%rip)
.global pf_jump_12
pf_jump_12:
jmp pf_callee_12
.cfi_endproc
.size pf_call_12,.-pf_call_12
.balign 16
.global pf_call_13
.type pf_call_13,@function
pf_call_13:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_13_0(%rip),%r11
.global pf_got_hint_13_0
pf_got_hint_13_0:
.byte 0x41,0x0f,0x18,0x93
.long 1712
.global pf_got_hint_13_1
pf_got_hint_13_1:
.byte 0x41,0x0f,0x18,0x93
.long 1746
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_13
pf_jump_13:
jmp pf_callee_13
.cfi_endproc
.size pf_call_13,.-pf_call_13
.balign 16
.global pf_call_14
.type pf_call_14,@function
pf_call_14:
.cfi_startproc
prefetcht1 pf_target_14_0(%rip)
prefetcht1 pf_target_14_1(%rip)
prefetcht1 pf_target_14_2(%rip)
.global pf_jump_14
pf_jump_14:
jmp pf_callee_14
.cfi_endproc
.size pf_call_14,.-pf_call_14
.balign 16
.global pf_call_15
.type pf_call_15,@function
pf_call_15:
.cfi_startproc
prefetcht1 pf_target_15_0(%rip)
prefetcht1 pf_target_15_1(%rip)
prefetcht1 pf_target_15_2(%rip)
prefetcht1 pf_target_15_3(%rip)
prefetcht1 pf_target_15_4(%rip)
.global pf_jump_15
pf_jump_15:
jmp pf_callee_15
.cfi_endproc
.size pf_call_15,.-pf_call_15
.balign 16
.global pf_call_16
.type pf_call_16,@function
pf_call_16:
.cfi_startproc
prefetcht1 pf_target_16_0(%rip)
prefetcht1 pf_target_16_1(%rip)
prefetcht1 pf_target_16_2(%rip)
prefetcht1 pf_target_16_3(%rip)
prefetcht1 pf_target_16_4(%rip)
prefetcht1 pf_target_16_5(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_16_0(%rip),%r11
.global pf_got_hint_16_0
pf_got_hint_16_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_16
pf_jump_16:
jmp pf_callee_16
.cfi_endproc
.size pf_call_16,.-pf_call_16
.balign 16
.global pf_call_17
.type pf_call_17,@function
pf_call_17:
.cfi_startproc
prefetcht1 pf_target_17_0(%rip)
.global pf_jump_17
pf_jump_17:
jmp pf_callee_17
.cfi_endproc
.size pf_call_17,.-pf_call_17
.balign 16
.global pf_call_18
.type pf_call_18,@function
pf_call_18:
.cfi_startproc
prefetcht1 pf_target_18_0(%rip)
prefetcht1 pf_target_18_1(%rip)
prefetcht1 pf_target_18_2(%rip)
.global pf_jump_18
pf_jump_18:
jmp pf_callee_18
.cfi_endproc
.size pf_call_18,.-pf_call_18
.balign 16
.global pf_call_19
.type pf_call_19,@function
pf_call_19:
.cfi_startproc
prefetcht1 pf_target_19_0(%rip)
.global pf_jump_19
pf_jump_19:
jmp pf_callee_19
.cfi_endproc
.size pf_call_19,.-pf_call_19
.balign 16
.global pf_call_20
.type pf_call_20,@function
pf_call_20:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_20_0(%rip),%r11
.global pf_got_hint_20_0
pf_got_hint_20_0:
.byte 0x41,0x0f,0x18,0x93
.long -19366
.global pf_got_hint_20_1
pf_got_hint_20_1:
.byte 0x41,0x0f,0x18,0x93
.long 355760
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_20
pf_jump_20:
jmp pf_callee_20
.cfi_endproc
.size pf_call_20,.-pf_call_20
.balign 16
.global pf_call_21
.type pf_call_21,@function
pf_call_21:
.cfi_startproc
prefetcht1 pf_target_21_0(%rip)
prefetcht1 pf_target_21_1(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_21_0(%rip),%r11
.global pf_got_hint_21_0
pf_got_hint_21_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_21_1
pf_got_hint_21_1:
.byte 0x41,0x0f,0x18,0x93
.long 50
mov pf_got_21_2(%rip),%r11
.global pf_got_hint_21_2
pf_got_hint_21_2:
.byte 0x41,0x0f,0x18,0x93
.long 31056
mov pf_got_21_3(%rip),%r11
.global pf_got_hint_21_3
pf_got_hint_21_3:
.byte 0x41,0x0f,0x18,0x93
.long 11504
mov pf_got_21_4(%rip),%r11
.global pf_got_hint_21_4
pf_got_hint_21_4:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_21_5
pf_got_hint_21_5:
.byte 0x41,0x0f,0x18,0x93
.long 16
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_21
pf_jump_21:
jmp pf_callee_21
.cfi_endproc
.size pf_call_21,.-pf_call_21
.balign 16
.global pf_call_22
.type pf_call_22,@function
pf_call_22:
.cfi_startproc
prefetcht1 pf_target_22_0(%rip)
prefetcht1 pf_target_22_1(%rip)
prefetcht1 pf_target_22_2(%rip)
prefetcht1 pf_target_22_3(%rip)
prefetcht1 pf_target_22_4(%rip)
prefetcht1 pf_target_22_5(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_22_0(%rip),%r11
.global pf_got_hint_22_0
pf_got_hint_22_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_22
pf_jump_22:
jmp pf_callee_22
.cfi_endproc
.size pf_call_22,.-pf_call_22
.balign 16
.global pf_call_23
.type pf_call_23,@function
pf_call_23:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_23_0(%rip),%r11
.global pf_got_hint_23_0
pf_got_hint_23_0:
.byte 0x41,0x0f,0x18,0x93
.long -105888
.global pf_got_hint_23_1
pf_got_hint_23_1:
.byte 0x41,0x0f,0x18,0x93
.long 27136
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_23
pf_jump_23:
jmp pf_callee_23
.cfi_endproc
.size pf_call_23,.-pf_call_23
.balign 16
.global pf_call_24
.type pf_call_24,@function
pf_call_24:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_24_0(%rip),%r11
.global pf_got_hint_24_0
pf_got_hint_24_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_24_1
pf_got_hint_24_1:
.byte 0x41,0x0f,0x18,0x93
.long 52
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_24
pf_jump_24:
jmp pf_callee_24
.cfi_endproc
.size pf_call_24,.-pf_call_24
.balign 16
.global pf_call_25
.type pf_call_25,@function
pf_call_25:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_25_0(%rip),%r11
.global pf_got_hint_25_0
pf_got_hint_25_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
mov pf_got_25_1(%rip),%r11
.global pf_got_hint_25_1
pf_got_hint_25_1:
.byte 0x41,0x0f,0x18,0x93
.long -55776
.global pf_got_hint_25_2
pf_got_hint_25_2:
.byte 0x41,0x0f,0x18,0x93
.long -55759
.global pf_got_hint_25_3
pf_got_hint_25_3:
.byte 0x41,0x0f,0x18,0x93
.long -55024
.global pf_got_hint_25_4
pf_got_hint_25_4:
.byte 0x41,0x0f,0x18,0x93
.long -2656
.global pf_got_hint_25_5
pf_got_hint_25_5:
.byte 0x41,0x0f,0x18,0x93
.long -2640
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_25
pf_jump_25:
jmp pf_callee_25
.cfi_endproc
.size pf_call_25,.-pf_call_25
.balign 16
.global pf_call_26
.type pf_call_26,@function
pf_call_26:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_26_0(%rip),%r11
.global pf_got_hint_26_0
pf_got_hint_26_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_26
pf_jump_26:
jmp pf_callee_26
.cfi_endproc
.size pf_call_26,.-pf_call_26
.balign 16
.global pf_call_27
.type pf_call_27,@function
pf_call_27:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_27_0(%rip),%r11
.global pf_got_hint_27_0
pf_got_hint_27_0:
.byte 0x41,0x0f,0x18,0x93
.long -54752
.global pf_got_hint_27_1
pf_got_hint_27_1:
.byte 0x41,0x0f,0x18,0x93
.long -46704
mov pf_got_27_2(%rip),%r11
.global pf_got_hint_27_2
pf_got_hint_27_2:
.byte 0x41,0x0f,0x18,0x93
.long -768
mov pf_got_27_3(%rip),%r11
.global pf_got_hint_27_3
pf_got_hint_27_3:
.byte 0x41,0x0f,0x18,0x93
.long -125456
mov pf_got_27_4(%rip),%r11
.global pf_got_hint_27_4
pf_got_hint_27_4:
.byte 0x41,0x0f,0x18,0x93
.long -3888
.global pf_got_hint_27_5
pf_got_hint_27_5:
.byte 0x41,0x0f,0x18,0x93
.long -3853
.global pf_got_hint_27_6
pf_got_hint_27_6:
.byte 0x41,0x0f,0x18,0x93
.long 6288
.global pf_got_hint_27_7
pf_got_hint_27_7:
.byte 0x41,0x0f,0x18,0x93
.long 6400
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_27
pf_jump_27:
jmp pf_callee_27
.cfi_endproc
.size pf_call_27,.-pf_call_27
.balign 16
.global pf_call_28
.type pf_call_28,@function
pf_call_28:
.cfi_startproc
prefetcht1 pf_target_28_0(%rip)
prefetcht1 pf_target_28_1(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_28_0(%rip),%r11
.global pf_got_hint_28_0
pf_got_hint_28_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_28_1
pf_got_hint_28_1:
.byte 0x41,0x0f,0x18,0x93
.long 17
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_28
pf_jump_28:
jmp pf_callee_28
.cfi_endproc
.size pf_call_28,.-pf_call_28
.balign 16
.global pf_call_29
.type pf_call_29,@function
pf_call_29:
.cfi_startproc
prefetcht1 pf_target_29_0(%rip)
.global pf_jump_29
pf_jump_29:
jmp pf_callee_29
.cfi_endproc
.size pf_call_29,.-pf_call_29
.balign 16
.global pf_call_30
.type pf_call_30,@function
pf_call_30:
.cfi_startproc
prefetcht1 pf_target_30_0(%rip)
.global pf_jump_30
pf_jump_30:
jmp pf_callee_30
.cfi_endproc
.size pf_call_30,.-pf_call_30
.balign 16
.global pf_call_31
.type pf_call_31,@function
pf_call_31:
.cfi_startproc
prefetcht1 pf_target_31_0(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_31_0(%rip),%r11
.global pf_got_hint_31_0
pf_got_hint_31_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_31
pf_jump_31:
jmp pf_callee_31
.cfi_endproc
.size pf_call_31,.-pf_call_31
.balign 16
.global pf_call_32
.type pf_call_32,@function
pf_call_32:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_32_0(%rip),%r11
.global pf_got_hint_32_0
pf_got_hint_32_0:
.byte 0x41,0x0f,0x18,0x93
.long -103520
.global pf_got_hint_32_1
pf_got_hint_32_1:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_32_2
pf_got_hint_32_2:
.byte 0x41,0x0f,0x18,0x93
.long 68
.global pf_got_hint_32_3
pf_got_hint_32_3:
.byte 0x41,0x0f,0x18,0x93
.long 136
.global pf_got_hint_32_4
pf_got_hint_32_4:
.byte 0x41,0x0f,0x18,0x93
.long 5824
.global pf_got_hint_32_5
pf_got_hint_32_5:
.byte 0x41,0x0f,0x18,0x93
.long 5888
mov pf_got_32_6(%rip),%r11
.global pf_got_hint_32_6
pf_got_hint_32_6:
.byte 0x41,0x0f,0x18,0x93
.long -115024
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_32
pf_jump_32:
jmp pf_callee_32
.cfi_endproc
.size pf_call_32,.-pf_call_32
.balign 16
.global pf_call_33
.type pf_call_33,@function
pf_call_33:
.cfi_startproc
prefetcht1 pf_target_33_0(%rip)
prefetcht1 pf_target_33_1(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_33_0(%rip),%r11
.global pf_got_hint_33_0
pf_got_hint_33_0:
.byte 0x41,0x0f,0x18,0x93
.long 611
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_33
pf_jump_33:
jmp pf_callee_33
.cfi_endproc
.size pf_call_33,.-pf_call_33
.balign 16
.global pf_call_34
.type pf_call_34,@function
pf_call_34:
.cfi_startproc
prefetcht1 pf_target_34_0(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_34_0(%rip),%r11
.global pf_got_hint_34_0
pf_got_hint_34_0:
.byte 0x41,0x0f,0x18,0x93
.long -51296
mov pf_got_34_1(%rip),%r11
.global pf_got_hint_34_1
pf_got_hint_34_1:
.byte 0x41,0x0f,0x18,0x93
.long -176
.global pf_got_hint_34_2
pf_got_hint_34_2:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_34
pf_jump_34:
jmp pf_callee_34
.cfi_endproc
.size pf_call_34,.-pf_call_34
.balign 16
.global pf_call_35
.type pf_call_35,@function
pf_call_35:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_35_0(%rip),%r11
.global pf_got_hint_35_0
pf_got_hint_35_0:
.byte 0x41,0x0f,0x18,0x93
.long -107248
.global pf_got_hint_35_1
pf_got_hint_35_1:
.byte 0x41,0x0f,0x18,0x93
.long 7553
.global pf_got_hint_35_2
pf_got_hint_35_2:
.byte 0x41,0x0f,0x18,0x93
.long 12688
.global pf_got_hint_35_3
pf_got_hint_35_3:
.byte 0x41,0x0f,0x18,0x93
.long 12736
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_35
pf_jump_35:
jmp pf_callee_35
.cfi_endproc
.size pf_call_35,.-pf_call_35
.balign 16
.global pf_call_36
.type pf_call_36,@function
pf_call_36:
.cfi_startproc
prefetcht1 pf_target_36_0(%rip)
prefetcht1 pf_target_36_1(%rip)
prefetcht1 pf_target_36_2(%rip)
prefetcht1 pf_target_36_3(%rip)
.global pf_jump_36
pf_jump_36:
jmp pf_callee_36
.cfi_endproc
.size pf_call_36,.-pf_call_36
.balign 16
.global pf_call_37
.type pf_call_37,@function
pf_call_37:
.cfi_startproc
prefetcht1 pf_target_37_0(%rip)
prefetcht1 pf_target_37_1(%rip)
prefetcht1 pf_target_37_2(%rip)
prefetcht1 pf_target_37_3(%rip)
.global pf_jump_37
pf_jump_37:
jmp pf_callee_37
.cfi_endproc
.size pf_call_37,.-pf_call_37
.balign 16
.global pf_call_38
.type pf_call_38,@function
pf_call_38:
.cfi_startproc
prefetcht1 pf_target_38_0(%rip)
.global pf_jump_38
pf_jump_38:
jmp pf_callee_38
.cfi_endproc
.size pf_call_38,.-pf_call_38
.balign 16
.global pf_call_39
.type pf_call_39,@function
pf_call_39:
.cfi_startproc
prefetcht1 pf_target_39_0(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_39_0(%rip),%r11
.global pf_got_hint_39_0
pf_got_hint_39_0:
.byte 0x41,0x0f,0x18,0x93
.long -44096
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_39
pf_jump_39:
jmp pf_callee_39
.cfi_endproc
.size pf_call_39,.-pf_call_39
.balign 16
.global pf_call_40
.type pf_call_40,@function
pf_call_40:
.cfi_startproc
prefetcht1 pf_target_40_0(%rip)
.global pf_jump_40
pf_jump_40:
jmp pf_callee_40
.cfi_endproc
.size pf_call_40,.-pf_call_40
.balign 16
.global pf_call_41
.type pf_call_41,@function
pf_call_41:
.cfi_startproc
prefetcht1 pf_target_41_0(%rip)
prefetcht1 pf_target_41_1(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_41_0(%rip),%r11
.global pf_got_hint_41_0
pf_got_hint_41_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_41_1
pf_got_hint_41_1:
.byte 0x41,0x0f,0x18,0x93
.long 680
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_41
pf_jump_41:
jmp pf_callee_41
.cfi_endproc
.size pf_call_41,.-pf_call_41
.balign 16
.global pf_call_42
.type pf_call_42,@function
pf_call_42:
.cfi_startproc
prefetcht1 pf_target_42_0(%rip)
.global pf_jump_42
pf_jump_42:
jmp pf_callee_42
.cfi_endproc
.size pf_call_42,.-pf_call_42
.balign 16
.global pf_call_43
.type pf_call_43,@function
pf_call_43:
.cfi_startproc
prefetcht1 pf_target_43_0(%rip)
prefetcht1 pf_target_43_1(%rip)
.global pf_jump_43
pf_jump_43:
jmp pf_callee_43
.cfi_endproc
.size pf_call_43,.-pf_call_43
.balign 16
.global pf_call_44
.type pf_call_44,@function
pf_call_44:
.cfi_startproc
prefetcht1 pf_target_44_0(%rip)
prefetcht1 pf_target_44_1(%rip)
prefetcht1 pf_target_44_2(%rip)
.global pf_jump_44
pf_jump_44:
jmp pf_callee_44
.cfi_endproc
.size pf_call_44,.-pf_call_44
.balign 16
.global pf_call_45
.type pf_call_45,@function
pf_call_45:
.cfi_startproc
prefetcht1 pf_target_45_0(%rip)
.global pf_jump_45
pf_jump_45:
jmp pf_callee_45
.cfi_endproc
.size pf_call_45,.-pf_call_45
.balign 16
.global pf_call_46
.type pf_call_46,@function
pf_call_46:
.cfi_startproc
prefetcht1 pf_target_46_0(%rip)
prefetcht1 pf_target_46_1(%rip)
prefetcht1 pf_target_46_2(%rip)
.global pf_jump_46
pf_jump_46:
jmp pf_callee_46
.cfi_endproc
.size pf_call_46,.-pf_call_46
.balign 16
.global pf_call_47
.type pf_call_47,@function
pf_call_47:
.cfi_startproc
prefetcht1 pf_target_47_0(%rip)
prefetcht1 pf_target_47_1(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_47_0(%rip),%r11
.global pf_got_hint_47_0
pf_got_hint_47_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_47_1
pf_got_hint_47_1:
.byte 0x41,0x0f,0x18,0x93
.long 20
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_47
pf_jump_47:
jmp pf_callee_47
.cfi_endproc
.size pf_call_47,.-pf_call_47
.balign 16
.global pf_call_48
.type pf_call_48,@function
pf_call_48:
.cfi_startproc
prefetcht1 pf_target_48_0(%rip)
prefetcht1 pf_target_48_1(%rip)
.global pf_jump_48
pf_jump_48:
jmp pf_callee_48
.cfi_endproc
.size pf_call_48,.-pf_call_48
.balign 16
.global pf_call_49
.type pf_call_49,@function
pf_call_49:
.cfi_startproc
prefetcht1 pf_target_49_0(%rip)
prefetcht1 pf_target_49_1(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_49_0(%rip),%r11
.global pf_got_hint_49_0
pf_got_hint_49_0:
.byte 0x41,0x0f,0x18,0x93
.long -52208
mov pf_got_49_1(%rip),%r11
.global pf_got_hint_49_1
pf_got_hint_49_1:
.byte 0x41,0x0f,0x18,0x93
.long 880
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_49
pf_jump_49:
jmp pf_callee_49
.cfi_endproc
.size pf_call_49,.-pf_call_49
.balign 16
.global pf_call_50
.type pf_call_50,@function
pf_call_50:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_50_0(%rip),%r11
.global pf_got_hint_50_0
pf_got_hint_50_0:
.byte 0x41,0x0f,0x18,0x93
.long -20718
mov pf_got_50_1(%rip),%r11
.global pf_got_hint_50_1
pf_got_hint_50_1:
.byte 0x41,0x0f,0x18,0x93
.long -44176
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_50
pf_jump_50:
jmp pf_callee_50
.cfi_endproc
.size pf_call_50,.-pf_call_50
.balign 16
.global pf_call_51
.type pf_call_51,@function
pf_call_51:
.cfi_startproc
prefetcht1 pf_target_51_0(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_51_0(%rip),%r11
.global pf_got_hint_51_0
pf_got_hint_51_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_51
pf_jump_51:
jmp pf_callee_51
.cfi_endproc
.size pf_call_51,.-pf_call_51
.balign 16
.global pf_call_52
.type pf_call_52,@function
pf_call_52:
.cfi_startproc
prefetcht1 pf_target_52_0(%rip)
prefetcht1 pf_target_52_1(%rip)
prefetcht1 pf_target_52_2(%rip)
prefetcht1 pf_target_52_3(%rip)
prefetcht1 pf_target_52_4(%rip)
prefetcht1 pf_target_52_5(%rip)
.global pf_jump_52
pf_jump_52:
jmp pf_callee_52
.cfi_endproc
.size pf_call_52,.-pf_call_52
.balign 16
.global pf_call_53
.type pf_call_53,@function
pf_call_53:
.cfi_startproc
prefetcht1 pf_target_53_0(%rip)
prefetcht1 pf_target_53_1(%rip)
prefetcht1 pf_target_53_2(%rip)
prefetcht1 pf_target_53_3(%rip)
prefetcht1 pf_target_53_4(%rip)
prefetcht1 pf_target_53_5(%rip)
prefetcht1 pf_target_53_6(%rip)
.global pf_jump_53
pf_jump_53:
jmp pf_callee_53
.cfi_endproc
.size pf_call_53,.-pf_call_53
.balign 16
.global pf_call_54
.type pf_call_54,@function
pf_call_54:
.cfi_startproc
prefetcht1 pf_target_54_0(%rip)
prefetcht1 pf_target_54_1(%rip)
.global pf_jump_54
pf_jump_54:
jmp pf_callee_54
.cfi_endproc
.size pf_call_54,.-pf_call_54
.balign 16
.global pf_call_55
.type pf_call_55,@function
pf_call_55:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_55_0(%rip),%r11
.global pf_got_hint_55_0
pf_got_hint_55_0:
.byte 0x41,0x0f,0x18,0x93
.long -288
mov pf_got_55_1(%rip),%r11
.global pf_got_hint_55_1
pf_got_hint_55_1:
.byte 0x41,0x0f,0x18,0x93
.long -28352
.global pf_got_hint_55_2
pf_got_hint_55_2:
.byte 0x41,0x0f,0x18,0x93
.long -28336
.global pf_got_hint_55_3
pf_got_hint_55_3:
.byte 0x41,0x0f,0x18,0x93
.long -17696
.global pf_got_hint_55_4
pf_got_hint_55_4:
.byte 0x41,0x0f,0x18,0x93
.long -17647
mov pf_got_55_5(%rip),%r11
.global pf_got_hint_55_5
pf_got_hint_55_5:
.byte 0x41,0x0f,0x18,0x93
.long -47264
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_55
pf_jump_55:
jmp pf_callee_55
.cfi_endproc
.size pf_call_55,.-pf_call_55
.balign 16
.global pf_call_56
.type pf_call_56,@function
pf_call_56:
.cfi_startproc
prefetcht1 pf_target_56_0(%rip)
prefetcht1 pf_target_56_1(%rip)
prefetcht1 pf_target_56_2(%rip)
.global pf_jump_56
pf_jump_56:
jmp pf_callee_56
.cfi_endproc
.size pf_call_56,.-pf_call_56
.balign 16
.global pf_call_57
.type pf_call_57,@function
pf_call_57:
.cfi_startproc
prefetcht1 pf_target_57_0(%rip)
.global pf_jump_57
pf_jump_57:
jmp pf_callee_57
.cfi_endproc
.size pf_call_57,.-pf_call_57
.balign 16
.global pf_call_58
.type pf_call_58,@function
pf_call_58:
.cfi_startproc
prefetcht1 pf_target_58_0(%rip)
prefetcht1 pf_target_58_1(%rip)
.global pf_jump_58
pf_jump_58:
jmp pf_callee_58
.cfi_endproc
.size pf_call_58,.-pf_call_58
.balign 16
.global pf_call_59
.type pf_call_59,@function
pf_call_59:
.cfi_startproc
prefetcht1 pf_target_59_0(%rip)
prefetcht1 pf_target_59_1(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_59_0(%rip),%r11
.global pf_got_hint_59_0
pf_got_hint_59_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_59_1
pf_got_hint_59_1:
.byte 0x41,0x0f,0x18,0x93
.long 34
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_59
pf_jump_59:
jmp pf_callee_59
.cfi_endproc
.size pf_call_59,.-pf_call_59
.balign 16
.global pf_call_60
.type pf_call_60,@function
pf_call_60:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_60_0(%rip),%r11
.global pf_got_hint_60_0
pf_got_hint_60_0:
.byte 0x41,0x0f,0x18,0x93
.long -44096
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_60
pf_jump_60:
jmp pf_callee_60
.cfi_endproc
.size pf_call_60,.-pf_call_60
.balign 16
.global pf_call_61
.type pf_call_61,@function
pf_call_61:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_61_0(%rip),%r11
.global pf_got_hint_61_0
pf_got_hint_61_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_61
pf_jump_61:
jmp pf_callee_61
.cfi_endproc
.size pf_call_61,.-pf_call_61
.balign 16
.global pf_call_62
.type pf_call_62,@function
pf_call_62:
.cfi_startproc
prefetcht1 pf_target_62_0(%rip)
prefetcht1 pf_target_62_1(%rip)
.global pf_jump_62
pf_jump_62:
jmp pf_callee_62
.cfi_endproc
.size pf_call_62,.-pf_call_62
.balign 16
.global pf_call_63
.type pf_call_63,@function
pf_call_63:
.cfi_startproc
prefetcht1 pf_target_63_0(%rip)
prefetcht1 pf_target_63_1(%rip)
prefetcht1 pf_target_63_2(%rip)
prefetcht1 pf_target_63_3(%rip)
prefetcht1 pf_target_63_4(%rip)
prefetcht1 pf_target_63_5(%rip)
prefetcht1 pf_target_63_6(%rip)
prefetcht1 pf_target_63_7(%rip)
.global pf_jump_63
pf_jump_63:
jmp pf_callee_63
.cfi_endproc
.size pf_call_63,.-pf_call_63
.balign 16
.global pf_call_64
.type pf_call_64,@function
pf_call_64:
.cfi_startproc
prefetcht1 pf_target_64_0(%rip)
prefetcht1 pf_target_64_1(%rip)
prefetcht1 pf_target_64_2(%rip)
prefetcht1 pf_target_64_3(%rip)
prefetcht1 pf_target_64_4(%rip)
.global pf_jump_64
pf_jump_64:
jmp pf_callee_64
.cfi_endproc
.size pf_call_64,.-pf_call_64
.balign 16
.global pf_call_65
.type pf_call_65,@function
pf_call_65:
.cfi_startproc
prefetcht1 pf_target_65_0(%rip)
prefetcht1 pf_target_65_1(%rip)
.global pf_jump_65
pf_jump_65:
jmp pf_callee_65
.cfi_endproc
.size pf_call_65,.-pf_call_65
.balign 16
.global pf_call_66
.type pf_call_66,@function
pf_call_66:
.cfi_startproc
prefetcht1 pf_target_66_0(%rip)
prefetcht1 pf_target_66_1(%rip)
prefetcht1 pf_target_66_2(%rip)
.global pf_jump_66
pf_jump_66:
jmp pf_callee_66
.cfi_endproc
.size pf_call_66,.-pf_call_66
.balign 16
.global pf_call_67
.type pf_call_67,@function
pf_call_67:
.cfi_startproc
prefetcht1 pf_target_67_0(%rip)
.global pf_jump_67
pf_jump_67:
jmp pf_callee_67
.cfi_endproc
.size pf_call_67,.-pf_call_67
.balign 16
.global pf_call_68
.type pf_call_68,@function
pf_call_68:
.cfi_startproc
prefetcht1 pf_target_68_0(%rip)
.global pf_jump_68
pf_jump_68:
jmp pf_callee_68
.cfi_endproc
.size pf_call_68,.-pf_call_68
.balign 16
.global pf_call_69
.type pf_call_69,@function
pf_call_69:
.cfi_startproc
prefetcht1 pf_target_69_0(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_69_0(%rip),%r11
.global pf_got_hint_69_0
pf_got_hint_69_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
mov pf_got_69_1(%rip),%r11
.global pf_got_hint_69_1
pf_got_hint_69_1:
.byte 0x41,0x0f,0x18,0x93
.long -49472
mov pf_got_69_2(%rip),%r11
.global pf_got_hint_69_2
pf_got_hint_69_2:
.byte 0x41,0x0f,0x18,0x93
.long -768
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_69
pf_jump_69:
jmp pf_callee_69
.cfi_endproc
.size pf_call_69,.-pf_call_69
.balign 16
.global pf_call_70
.type pf_call_70,@function
pf_call_70:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_70_0(%rip),%r11
.global pf_got_hint_70_0
pf_got_hint_70_0:
.byte 0x41,0x0f,0x18,0x93
.long -46864
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_70
pf_jump_70:
jmp pf_callee_70
.cfi_endproc
.size pf_call_70,.-pf_call_70
.balign 16
.global pf_call_71
.type pf_call_71,@function
pf_call_71:
.cfi_startproc
prefetcht1 pf_target_71_0(%rip)
.global pf_jump_71
pf_jump_71:
jmp pf_callee_71
.cfi_endproc
.size pf_call_71,.-pf_call_71
.balign 16
.global pf_call_72
.type pf_call_72,@function
pf_call_72:
.cfi_startproc
prefetcht1 pf_target_72_0(%rip)
prefetcht1 pf_target_72_1(%rip)
.global pf_jump_72
pf_jump_72:
jmp pf_callee_72
.cfi_endproc
.size pf_call_72,.-pf_call_72
.balign 16
.global pf_call_73
.type pf_call_73,@function
pf_call_73:
.cfi_startproc
prefetcht1 pf_target_73_0(%rip)
prefetcht1 pf_target_73_1(%rip)
prefetcht1 pf_target_73_2(%rip)
prefetcht1 pf_target_73_3(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_73_0(%rip),%r11
.global pf_got_hint_73_0
pf_got_hint_73_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_73
pf_jump_73:
jmp pf_callee_73
.cfi_endproc
.size pf_call_73,.-pf_call_73
.balign 16
.global pf_call_74
.type pf_call_74,@function
pf_call_74:
.cfi_startproc
prefetcht1 pf_target_74_0(%rip)
prefetcht1 pf_target_74_1(%rip)
prefetcht1 pf_target_74_2(%rip)
prefetcht1 pf_target_74_3(%rip)
prefetcht1 pf_target_74_4(%rip)
prefetcht1 pf_target_74_5(%rip)
.global pf_jump_74
pf_jump_74:
jmp pf_callee_74
.cfi_endproc
.size pf_call_74,.-pf_call_74
.balign 16
.global pf_call_75
.type pf_call_75,@function
pf_call_75:
.cfi_startproc
prefetcht1 pf_target_75_0(%rip)
prefetcht1 pf_target_75_1(%rip)
.global pf_jump_75
pf_jump_75:
jmp pf_callee_75
.cfi_endproc
.size pf_call_75,.-pf_call_75
.balign 16
.global pf_call_76
.type pf_call_76,@function
pf_call_76:
.cfi_startproc
prefetcht1 pf_target_76_0(%rip)
prefetcht1 pf_target_76_1(%rip)
.global pf_jump_76
pf_jump_76:
jmp pf_callee_76
.cfi_endproc
.size pf_call_76,.-pf_call_76
.balign 16
.global pf_call_77
.type pf_call_77,@function
pf_call_77:
.cfi_startproc
prefetcht1 pf_target_77_0(%rip)
.global pf_jump_77
pf_jump_77:
jmp pf_callee_77
.cfi_endproc
.size pf_call_77,.-pf_call_77
.balign 16
.global pf_call_78
.type pf_call_78,@function
pf_call_78:
.cfi_startproc
prefetcht1 pf_target_78_0(%rip)
.global pf_jump_78
pf_jump_78:
jmp pf_callee_78
.cfi_endproc
.size pf_call_78,.-pf_call_78
.balign 16
.global pf_call_79
.type pf_call_79,@function
pf_call_79:
.cfi_startproc
prefetcht1 pf_target_79_0(%rip)
prefetcht1 pf_target_79_1(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_79_0(%rip),%r11
.global pf_got_hint_79_0
pf_got_hint_79_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
mov pf_got_79_1(%rip),%r11
.global pf_got_hint_79_1
pf_got_hint_79_1:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_79
pf_jump_79:
jmp pf_callee_79
.cfi_endproc
.size pf_call_79,.-pf_call_79
.balign 16
.global pf_call_80
.type pf_call_80,@function
pf_call_80:
.cfi_startproc
prefetcht1 pf_target_80_0(%rip)
.global pf_jump_80
pf_jump_80:
jmp pf_callee_80
.cfi_endproc
.size pf_call_80,.-pf_call_80
.balign 16
.global pf_call_81
.type pf_call_81,@function
pf_call_81:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_81_0(%rip),%r11
.global pf_got_hint_81_0
pf_got_hint_81_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_81
pf_jump_81:
jmp pf_callee_81
.cfi_endproc
.size pf_call_81,.-pf_call_81
.balign 16
.global pf_call_82
.type pf_call_82,@function
pf_call_82:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_82_0(%rip),%r11
.global pf_got_hint_82_0
pf_got_hint_82_0:
.byte 0x41,0x0f,0x18,0x93
.long 16
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_82
pf_jump_82:
jmp pf_callee_82
.cfi_endproc
.size pf_call_82,.-pf_call_82
.balign 16
.global pf_call_84
.type pf_call_84,@function
pf_call_84:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_84_0(%rip),%r11
.global pf_got_hint_84_0
pf_got_hint_84_0:
.byte 0x41,0x0f,0x18,0x93
.long 16
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_84
pf_jump_84:
jmp pf_callee_84
.cfi_endproc
.size pf_call_84,.-pf_call_84
.balign 16
.global pf_call_85
.type pf_call_85,@function
pf_call_85:
.cfi_startproc
prefetcht1 pf_target_85_0(%rip)
prefetcht1 pf_target_85_1(%rip)
prefetcht1 pf_target_85_2(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_85_0(%rip),%r11
.global pf_got_hint_85_0
pf_got_hint_85_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_85
pf_jump_85:
jmp pf_callee_85
.cfi_endproc
.size pf_call_85,.-pf_call_85
.balign 16
.global pf_call_86
.type pf_call_86,@function
pf_call_86:
.cfi_startproc
prefetcht1 pf_target_86_0(%rip)
.global pf_jump_86
pf_jump_86:
jmp pf_callee_86
.cfi_endproc
.size pf_call_86,.-pf_call_86
.balign 16
.global pf_call_87
.type pf_call_87,@function
pf_call_87:
.cfi_startproc
prefetcht1 pf_target_87_0(%rip)
prefetcht1 pf_target_87_1(%rip)
prefetcht1 pf_target_87_2(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_87_0(%rip),%r11
.global pf_got_hint_87_0
pf_got_hint_87_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_87
pf_jump_87:
jmp pf_callee_87
.cfi_endproc
.size pf_call_87,.-pf_call_87
.balign 16
.global pf_call_88
.type pf_call_88,@function
pf_call_88:
.cfi_startproc
prefetcht1 pf_target_88_0(%rip)
prefetcht1 pf_target_88_1(%rip)
prefetcht1 pf_target_88_2(%rip)
prefetcht1 pf_target_88_3(%rip)
prefetcht1 pf_target_88_4(%rip)
prefetcht1 pf_target_88_5(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_88_0(%rip),%r11
.global pf_got_hint_88_0
pf_got_hint_88_0:
.byte 0x41,0x0f,0x18,0x93
.long 34
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_88
pf_jump_88:
jmp pf_callee_88
.cfi_endproc
.size pf_call_88,.-pf_call_88
.balign 16
.global pf_call_89
.type pf_call_89,@function
pf_call_89:
.cfi_startproc
prefetcht1 pf_target_89_0(%rip)
prefetcht1 pf_target_89_1(%rip)
prefetcht1 pf_target_89_2(%rip)
prefetcht1 pf_target_89_3(%rip)
.global pf_jump_89
pf_jump_89:
jmp pf_callee_89
.cfi_endproc
.size pf_call_89,.-pf_call_89
.balign 16
.global pf_call_90
.type pf_call_90,@function
pf_call_90:
.cfi_startproc
prefetcht1 pf_target_90_0(%rip)
.global pf_jump_90
pf_jump_90:
jmp pf_callee_90
.cfi_endproc
.size pf_call_90,.-pf_call_90
.balign 16
.global pf_call_91
.type pf_call_91,@function
pf_call_91:
.cfi_startproc
prefetcht1 pf_target_91_0(%rip)
.global pf_jump_91
pf_jump_91:
jmp pf_callee_91
.cfi_endproc
.size pf_call_91,.-pf_call_91
.balign 16
.global pf_call_92
.type pf_call_92,@function
pf_call_92:
.cfi_startproc
prefetcht1 pf_target_92_0(%rip)
.global pf_jump_92
pf_jump_92:
jmp pf_callee_92
.cfi_endproc
.size pf_call_92,.-pf_call_92
.balign 16
.global pf_call_93
.type pf_call_93,@function
pf_call_93:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_93_0(%rip),%r11
.global pf_got_hint_93_0
pf_got_hint_93_0:
.byte 0x41,0x0f,0x18,0x93
.long -18112
.global pf_got_hint_93_1
pf_got_hint_93_1:
.byte 0x41,0x0f,0x18,0x93
.long -18096
mov pf_got_93_2(%rip),%r11
.global pf_got_hint_93_2
pf_got_hint_93_2:
.byte 0x41,0x0f,0x18,0x93
.long -47264
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_93
pf_jump_93:
jmp pf_callee_93
.cfi_endproc
.size pf_call_93,.-pf_call_93
.balign 16
.global pf_call_94
.type pf_call_94,@function
pf_call_94:
.cfi_startproc
prefetcht1 pf_target_94_0(%rip)
prefetcht1 pf_target_94_1(%rip)
.global pf_jump_94
pf_jump_94:
jmp pf_callee_94
.cfi_endproc
.size pf_call_94,.-pf_call_94
.balign 16
.global pf_call_95
.type pf_call_95,@function
pf_call_95:
.cfi_startproc
prefetcht1 pf_target_95_0(%rip)
prefetcht1 pf_target_95_1(%rip)
.global pf_jump_95
pf_jump_95:
jmp pf_callee_95
.cfi_endproc
.size pf_call_95,.-pf_call_95
.section .note.GNU-stack,"",@progbits
