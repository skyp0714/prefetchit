
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_compact/d2a2d732143c46b04f5ca16733387a5f5713ad8dc218c423def02e91e4025de9/call-stub-vdnb2k37/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000010b340 <pf_call_0>:
  10b340:	0f 18 15 bc 06 f4 ff 	prefetcht1 -0xbf944(%rip)        # 4ba03 <pf_target_0_0>
  10b347:	0f 18 15 f5 06 f4 ff 	prefetcht1 -0xbf90b(%rip)        # 4ba43 <pf_target_0_1>
  10b34e:	0f 18 15 5b 10 f4 ff 	prefetcht1 -0xbefa5(%rip)        # 4c3b0 <pf_target_0_2>
  10b355:	0f 18 15 c4 5c f4 ff 	prefetcht1 -0xba33c(%rip)        # 51020 <pf_target_0_3>
  10b35c:	0f 18 15 dd 05 f4 ff 	prefetcht1 -0xbfa23(%rip)        # 4b940 <pf_target_0_4>
  10b363:	0f 18 15 16 5d f4 ff 	prefetcht1 -0xba2ea(%rip)        # 51080 <pf_target_0_5>
  10b36a:	41 53                	push   %r11
  10b36c:	4c 8b 1d ad de ff ff 	mov    -0x2153(%rip),%r11        # 109220 <pf_got_0_0>

000000000010b373 <pf_got_hint_0_0>:
  10b373:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b37a:	00 
  10b37b:	4c 8b 1d 2e e2 ff ff 	mov    -0x1dd2(%rip),%r11        # 1095b0 <pf_got_0_1>

000000000010b382 <pf_got_hint_0_1>:
  10b382:	41 0f 18 93 60 69 00 	prefetcht1 0x6960(%r11)
  10b389:	00 
  10b38a:	41 5b                	pop    %r11

000000000010b38c <pf_jump_0>:
  10b38c:	e9 af c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b391:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b398:	00 00 00 
  10b39b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000010b3a0 <pf_call_1>:
  10b3a0:	0f 18 15 69 e2 f2 ff 	prefetcht1 -0xd1d97(%rip)        # 39610 <pf_callee_2>

000000000010b3a7 <pf_jump_1>:
  10b3a7:	e9 94 c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b3ac:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b3b0 <pf_call_2>:
  10b3b0:	41 53                	push   %r11
  10b3b2:	4c 8b 1d 77 dd ff ff 	mov    -0x2289(%rip),%r11        # 109130 <pf_got_2_0>

000000000010b3b9 <pf_got_hint_2_0>:
  10b3b9:	41 0f 18 93 b0 06 00 	prefetcht1 0x6b0(%r11)
  10b3c0:	00 
  10b3c1:	4c 8b 1d e8 e1 ff ff 	mov    -0x1e18(%rip),%r11        # 1095b0 <pf_got_0_1>

000000000010b3c8 <pf_got_hint_2_1>:
  10b3c8:	41 0f 18 93 c5 1f 00 	prefetcht1 0x1fc5(%r11)
  10b3cf:	00 

000000000010b3d0 <pf_got_hint_2_2>:
  10b3d0:	41 0f 18 93 c0 31 00 	prefetcht1 0x31c0(%r11)
  10b3d7:	00 
  10b3d8:	41 5b                	pop    %r11

000000000010b3da <pf_jump_2>:
  10b3da:	e9 31 e2 f2 ff       	jmp    39610 <pf_callee_2>
  10b3df:	90                   	nop

000000000010b3e0 <pf_call_3>:
  10b3e0:	41 53                	push   %r11
  10b3e2:	4c 8b 1d c7 e1 ff ff 	mov    -0x1e39(%rip),%r11        # 1095b0 <pf_got_0_1>

000000000010b3e9 <pf_got_hint_3_0>:
  10b3e9:	41 0f 18 93 50 79 00 	prefetcht1 0x7950(%r11)
  10b3f0:	00 
  10b3f1:	4c 8b 1d b8 e4 ff ff 	mov    -0x1b48(%rip),%r11        # 1098b0 <pf_got_3_1>

000000000010b3f8 <pf_got_hint_3_1>:
  10b3f8:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b3ff:	00 

000000000010b400 <pf_got_hint_3_2>:
  10b400:	41 0f 18 93 34 00 00 	prefetcht1 0x34(%r11)
  10b407:	00 
  10b408:	41 5b                	pop    %r11

000000000010b40a <pf_jump_3>:
  10b40a:	e9 31 c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b40f:	90                   	nop

000000000010b410 <pf_call_4>:
  10b410:	41 53                	push   %r11
  10b412:	4c 8b 1d df de ff ff 	mov    -0x2121(%rip),%r11        # 1092f8 <pf_got_4_0>

000000000010b419 <pf_got_hint_4_0>:
  10b419:	41 0f 18 93 d0 d7 00 	prefetcht1 0xd7d0(%r11)
  10b420:	00 
  10b421:	4c 8b 1d 50 e2 ff ff 	mov    -0x1db0(%rip),%r11        # 109678 <pf_got_13_3>

000000000010b428 <pf_got_hint_4_1>:
  10b428:	41 0f 18 93 d0 77 ff 	prefetcht1 -0x8830(%r11)
  10b42f:	ff 
  10b430:	41 5b                	pop    %r11

000000000010b432 <pf_jump_4>:
  10b432:	e9 b9 c7 f1 ff       	jmp    27bf0 <pf_callee_4>
  10b437:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  10b43e:	00 00 

000000000010b440 <pf_call_5>:
  10b440:	41 53                	push   %r11
  10b442:	4c 8b 1d 9f e3 ff ff 	mov    -0x1c61(%rip),%r11        # 1097e8 <pf_got_5_0>

000000000010b449 <pf_got_hint_5_0>:
  10b449:	41 0f 18 93 00 ce ff 	prefetcht1 -0x3200(%r11)
  10b450:	ff 

000000000010b451 <pf_got_hint_5_1>:
  10b451:	41 0f 18 93 15 ce ff 	prefetcht1 -0x31eb(%r11)
  10b458:	ff 

000000000010b459 <pf_got_hint_5_2>:
  10b459:	41 0f 18 93 d0 eb ff 	prefetcht1 -0x1430(%r11)
  10b460:	ff 

000000000010b461 <pf_got_hint_5_3>:
  10b461:	41 0f 18 93 28 ee ff 	prefetcht1 -0x11d8(%r11)
  10b468:	ff 
  10b469:	41 5b                	pop    %r11

000000000010b46b <pf_jump_5>:
  10b46b:	e9 90 c6 f1 ff       	jmp    27b00 <pf_callee_5>

000000000010b470 <pf_call_6>:
  10b470:	41 53                	push   %r11
  10b472:	4c 8b 1d 57 dd ff ff 	mov    -0x22a9(%rip),%r11        # 1091d0 <pf_got_6_0>

000000000010b479 <pf_got_hint_6_0>:
  10b479:	41 0f 18 93 3a 00 00 	prefetcht1 0x3a(%r11)
  10b480:	00 

000000000010b481 <pf_got_hint_6_1>:
  10b481:	41 0f 18 93 80 00 00 	prefetcht1 0x80(%r11)
  10b488:	00 
  10b489:	4c 8b 1d 58 e3 ff ff 	mov    -0x1ca8(%rip),%r11        # 1097e8 <pf_got_5_0>

000000000010b490 <pf_got_hint_6_2>:
  10b490:	41 0f 18 93 70 e9 ff 	prefetcht1 -0x1690(%r11)
  10b497:	ff 

000000000010b498 <pf_got_hint_6_3>:
  10b498:	41 0f 18 93 91 e9 ff 	prefetcht1 -0x166f(%r11)
  10b49f:	ff 
  10b4a0:	41 5b                	pop    %r11

000000000010b4a2 <pf_jump_6>:
  10b4a2:	e9 d9 c1 f1 ff       	jmp    27680 <pf_callee_6>
  10b4a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  10b4ae:	00 00 

000000000010b4b0 <pf_call_7>:
  10b4b0:	41 53                	push   %r11
  10b4b2:	4c 8b 1d 2f e3 ff ff 	mov    -0x1cd1(%rip),%r11        # 1097e8 <pf_got_5_0>

000000000010b4b9 <pf_got_hint_7_0>:
  10b4b9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b4c0:	00 

000000000010b4c1 <pf_got_hint_7_1>:
  10b4c1:	41 0f 18 93 15 00 00 	prefetcht1 0x15(%r11)
  10b4c8:	00 

000000000010b4c9 <pf_got_hint_7_2>:
  10b4c9:	41 0f 18 93 53 00 00 	prefetcht1 0x53(%r11)
  10b4d0:	00 
  10b4d1:	41 5b                	pop    %r11

000000000010b4d3 <pf_jump_7>:
  10b4d3:	e9 f8 ca f1 ff       	jmp    27fd0 <pf_callee_7>
  10b4d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b4df:	00 

000000000010b4e0 <pf_call_8>:
  10b4e0:	41 53                	push   %r11
  10b4e2:	4c 8b 1d 0f de ff ff 	mov    -0x21f1(%rip),%r11        # 1092f8 <pf_got_4_0>

000000000010b4e9 <pf_got_hint_8_0>:
  10b4e9:	41 0f 18 93 b0 04 00 	prefetcht1 0x4b0(%r11)
  10b4f0:	00 

000000000010b4f1 <pf_got_hint_8_1>:
  10b4f1:	41 0f 18 93 e0 26 00 	prefetcht1 0x26e0(%r11)
  10b4f8:	00 

000000000010b4f9 <pf_got_hint_8_2>:
  10b4f9:	41 0f 18 93 80 53 00 	prefetcht1 0x5380(%r11)
  10b500:	00 
  10b501:	4c 8b 1d 40 e0 ff ff 	mov    -0x1fc0(%rip),%r11        # 109548 <pf_got_11_0>

000000000010b508 <pf_got_hint_8_3>:
  10b508:	41 0f 18 93 b0 89 01 	prefetcht1 0x189b0(%r11)
  10b50f:	00 

000000000010b510 <pf_got_hint_8_4>:
  10b510:	41 0f 18 93 b0 57 03 	prefetcht1 0x357b0(%r11)
  10b517:	00 

000000000010b518 <pf_got_hint_8_5>:
  10b518:	41 0f 18 93 30 5a 03 	prefetcht1 0x35a30(%r11)
  10b51f:	00 
  10b520:	4c 8b 1d 51 e1 ff ff 	mov    -0x1eaf(%rip),%r11        # 109678 <pf_got_13_3>

000000000010b527 <pf_got_hint_8_6>:
  10b527:	41 0f 18 93 60 50 ff 	prefetcht1 -0xafa0(%r11)
  10b52e:	ff 

000000000010b52f <pf_got_hint_8_7>:
  10b52f:	41 0f 18 93 60 76 ff 	prefetcht1 -0x89a0(%r11)
  10b536:	ff 
  10b537:	41 5b                	pop    %r11

000000000010b539 <pf_jump_8>:
  10b539:	e9 52 c5 f1 ff       	jmp    27a90 <pf_callee_8>
  10b53e:	66 90                	xchg   %ax,%ax

000000000010b540 <pf_call_9>:
  10b540:	41 53                	push   %r11
  10b542:	4c 8b 1d 67 e0 ff ff 	mov    -0x1f99(%rip),%r11        # 1095b0 <pf_got_0_1>

000000000010b549 <pf_got_hint_9_0>:
  10b549:	41 0f 18 93 20 6f fe 	prefetcht1 -0x190e0(%r11)
  10b550:	ff 

000000000010b551 <pf_got_hint_9_1>:
  10b551:	41 0f 18 93 5a b4 ff 	prefetcht1 -0x4ba6(%r11)
  10b558:	ff 

000000000010b559 <pf_got_hint_9_2>:
  10b559:	41 0f 18 93 b0 6d 05 	prefetcht1 0x56db0(%r11)
  10b560:	00 
  10b561:	41 5b                	pop    %r11

000000000010b563 <pf_jump_9>:
  10b563:	e9 e8 cb f1 ff       	jmp    28150 <pf_callee_9>
  10b568:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b56f:	00 

000000000010b570 <pf_call_10>:
  10b570:	0f 18 15 79 c0 f1 ff 	prefetcht1 -0xe3f87(%rip)        # 275f0 <pf_target_10_0>

000000000010b577 <pf_jump_10>:
  10b577:	e9 24 67 f4 ff       	jmp    51ca0 <pf_callee_10>
  10b57c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b580 <pf_call_11>:
  10b580:	41 53                	push   %r11
  10b582:	4c 8b 1d bf df ff ff 	mov    -0x2041(%rip),%r11        # 109548 <pf_got_11_0>

000000000010b589 <pf_got_hint_11_0>:
  10b589:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b590:	00 

000000000010b591 <pf_got_hint_11_1>:
  10b591:	41 0f 18 93 f2 89 01 	prefetcht1 0x189f2(%r11)
  10b598:	00 
  10b599:	41 5b                	pop    %r11

000000000010b59b <pf_jump_11>:
  10b59b:	e9 10 bc f1 ff       	jmp    271b0 <pf_callee_11>

000000000010b5a0 <pf_call_12>:
  10b5a0:	41 53                	push   %r11
  10b5a2:	4c 8b 1d af de ff ff 	mov    -0x2151(%rip),%r11        # 109458 <pf_got_12_0>

000000000010b5a9 <pf_got_hint_12_0>:
  10b5a9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b5b0:	00 
  10b5b1:	4c 8b 1d 48 e3 ff ff 	mov    -0x1cb8(%rip),%r11        # 109900 <pf_got_12_1>

000000000010b5b8 <pf_got_hint_12_1>:
  10b5b8:	41 0f 18 93 70 e8 fe 	prefetcht1 -0x11790(%r11)
  10b5bf:	ff 

000000000010b5c0 <pf_got_hint_12_2>:
  10b5c0:	41 0f 18 93 20 26 ff 	prefetcht1 -0xd9e0(%r11)
  10b5c7:	ff 

000000000010b5c8 <pf_got_hint_12_3>:
  10b5c8:	41 0f 18 93 31 26 ff 	prefetcht1 -0xd9cf(%r11)
  10b5cf:	ff 

000000000010b5d0 <pf_got_hint_12_4>:
  10b5d0:	41 0f 18 93 10 29 ff 	prefetcht1 -0xd6f0(%r11)
  10b5d7:	ff 

000000000010b5d8 <pf_got_hint_12_5>:
  10b5d8:	41 0f 18 93 a0 f5 ff 	prefetcht1 -0xa60(%r11)
  10b5df:	ff 

000000000010b5e0 <pf_got_hint_12_6>:
  10b5e0:	41 0f 18 93 b0 f5 ff 	prefetcht1 -0xa50(%r11)
  10b5e7:	ff 
  10b5e8:	41 5b                	pop    %r11

000000000010b5ea <pf_jump_12>:
  10b5ea:	e9 41 25 f4 ff       	jmp    4db30 <pf_callee_12>
  10b5ef:	90                   	nop

000000000010b5f0 <pf_call_13>:
  10b5f0:	41 53                	push   %r11
  10b5f2:	4c 8b 1d 4f df ff ff 	mov    -0x20b1(%rip),%r11        # 109548 <pf_got_11_0>

000000000010b5f9 <pf_got_hint_13_0>:
  10b5f9:	41 0f 18 93 e0 c4 01 	prefetcht1 0x1c4e0(%r11)
  10b600:	00 

000000000010b601 <pf_got_hint_13_1>:
  10b601:	41 0f 18 93 f0 c4 01 	prefetcht1 0x1c4f0(%r11)
  10b608:	00 
  10b609:	4c 8b 1d e8 df ff ff 	mov    -0x2018(%rip),%r11        # 1095f8 <pf_got_13_2>

000000000010b610 <pf_got_hint_13_2>:
  10b610:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b617:	00 
  10b618:	4c 8b 1d 59 e0 ff ff 	mov    -0x1fa7(%rip),%r11        # 109678 <pf_got_13_3>

000000000010b61f <pf_got_hint_13_3>:
  10b61f:	41 0f 18 93 10 61 ff 	prefetcht1 -0x9ef0(%r11)
  10b626:	ff 

000000000010b627 <pf_got_hint_13_4>:
  10b627:	41 0f 18 93 00 63 ff 	prefetcht1 -0x9d00(%r11)
  10b62e:	ff 
  10b62f:	41 5b                	pop    %r11

000000000010b631 <pf_jump_13>:
  10b631:	e9 fa cb f1 ff       	jmp    28230 <pf_callee_13>
  10b636:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b63d:	00 00 00 

000000000010b640 <pf_call_14>:
  10b640:	41 53                	push   %r11
  10b642:	4c 8b 1d 0f e0 ff ff 	mov    -0x1ff1(%rip),%r11        # 109658 <pf_got_14_0>

000000000010b649 <pf_got_hint_14_0>:
  10b649:	41 0f 18 93 00 fd ff 	prefetcht1 -0x300(%r11)
  10b650:	ff 
  10b651:	4c 8b 1d a8 e2 ff ff 	mov    -0x1d58(%rip),%r11        # 109900 <pf_got_12_1>

000000000010b658 <pf_got_hint_14_1>:
  10b658:	41 0f 18 93 f0 15 fe 	prefetcht1 -0x1ea10(%r11)
  10b65f:	ff 
  10b660:	4c 8b 1d b1 e2 ff ff 	mov    -0x1d4f(%rip),%r11        # 109918 <pf_got_14_2>

000000000010b667 <pf_got_hint_14_2>:
  10b667:	41 0f 18 93 d0 f0 ff 	prefetcht1 -0xf30(%r11)
  10b66e:	ff 

000000000010b66f <pf_got_hint_14_3>:
  10b66f:	41 0f 18 93 00 19 00 	prefetcht1 0x1900(%r11)
  10b676:	00 
  10b677:	41 5b                	pop    %r11

000000000010b679 <pf_jump_14>:
  10b679:	e9 c2 ba f1 ff       	jmp    27140 <pf_callee_14>
  10b67e:	66 90                	xchg   %ax,%ax

000000000010b680 <pf_call_15>:
  10b680:	0f 18 15 59 c1 f1 ff 	prefetcht1 -0xe3ea7(%rip)        # 277e0 <pf_target_15_0>
  10b687:	0f 18 15 12 09 f4 ff 	prefetcht1 -0xbf6ee(%rip)        # 4bfa0 <pf_target_15_1>
  10b68e:	0f 18 15 2e 09 f4 ff 	prefetcht1 -0xbf6d2(%rip)        # 4bfc3 <pf_target_15_2>
  10b695:	41 53                	push   %r11
  10b697:	4c 8b 1d 52 dd ff ff 	mov    -0x22ae(%rip),%r11        # 1093f0 <pf_got_15_0>

000000000010b69e <pf_got_hint_15_0>:
  10b69e:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b6a5:	00 

000000000010b6a6 <pf_got_hint_15_1>:
  10b6a6:	41 0f 18 93 11 00 00 	prefetcht1 0x11(%r11)
  10b6ad:	00 
  10b6ae:	41 5b                	pop    %r11

000000000010b6b0 <pf_jump_15>:
  10b6b0:	e9 8b ba f1 ff       	jmp    27140 <pf_callee_14>
  10b6b5:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b6bc:	00 00 00 
  10b6bf:	90                   	nop

000000000010b6c0 <pf_call_16>:
  10b6c0:	0f 18 15 29 be f1 ff 	prefetcht1 -0xe41d7(%rip)        # 274f0 <pf_target_16_0>
  10b6c7:	0f 18 15 bc d1 f3 ff 	prefetcht1 -0xc2e44(%rip)        # 4888a <pf_target_16_1>

000000000010b6ce <pf_jump_16>:
  10b6ce:	e9 0d d1 f3 ff       	jmp    487e0 <pf_callee_16>
  10b6d3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b6da:	00 00 00 
  10b6dd:	0f 1f 00             	nopl   (%rax)

000000000010b6e0 <pf_call_17>:
  10b6e0:	0f 18 15 39 09 f4 ff 	prefetcht1 -0xbf6c7(%rip)        # 4c020 <pf_target_17_0>
  10b6e7:	0f 18 15 55 09 f4 ff 	prefetcht1 -0xbf6ab(%rip)        # 4c043 <pf_target_17_1>

000000000010b6ee <pf_jump_17>:
  10b6ee:	e9 6d 0d f4 ff       	jmp    4c460 <pf_callee_17>
  10b6f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b6fa:	00 00 00 
  10b6fd:	0f 1f 00             	nopl   (%rax)

000000000010b700 <pf_call_18>:
  10b700:	0f 18 15 09 22 f4 ff 	prefetcht1 -0xbddf7(%rip)        # 4d910 <pf_target_18_0>

000000000010b707 <pf_jump_18>:
  10b707:	e9 a4 ba f1 ff       	jmp    271b0 <pf_callee_11>
  10b70c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b710 <pf_call_19>:
  10b710:	0f 18 15 89 c9 f1 ff 	prefetcht1 -0xe3677(%rip)        # 280a0 <pf_target_19_0>

000000000010b717 <pf_jump_19>:
  10b717:	e9 94 ba f1 ff       	jmp    271b0 <pf_callee_11>
  10b71c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b720 <pf_call_20>:
  10b720:	41 53                	push   %r11
  10b722:	4c 8b 1d 87 de ff ff 	mov    -0x2179(%rip),%r11        # 1095b0 <pf_got_0_1>

000000000010b729 <pf_got_hint_20_0>:
  10b729:	41 0f 18 93 a0 6b fe 	prefetcht1 -0x19460(%r11)
  10b730:	ff 

000000000010b731 <pf_got_hint_20_1>:
  10b731:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b738:	00 

000000000010b739 <pf_got_hint_20_2>:
  10b739:	41 0f 18 93 44 00 00 	prefetcht1 0x44(%r11)
  10b740:	00 

000000000010b741 <pf_got_hint_20_3>:
  10b741:	41 0f 18 93 c0 16 00 	prefetcht1 0x16c0(%r11)
  10b748:	00 

000000000010b749 <pf_got_hint_20_4>:
  10b749:	41 0f 18 93 00 17 00 	prefetcht1 0x1700(%r11)
  10b750:	00 
  10b751:	4c 8b 1d a8 e1 ff ff 	mov    -0x1e58(%rip),%r11        # 109900 <pf_got_12_1>

000000000010b758 <pf_got_hint_20_5>:
  10b758:	41 0f 18 93 b0 3e fe 	prefetcht1 -0x1c150(%r11)
  10b75f:	ff 

000000000010b760 <pf_got_hint_20_6>:
  10b760:	41 0f 18 93 40 46 fe 	prefetcht1 -0x1b9c0(%r11)
  10b767:	ff 

000000000010b768 <pf_got_hint_20_7>:
  10b768:	41 0f 18 93 70 46 fe 	prefetcht1 -0x1b990(%r11)
  10b76f:	ff 
  10b770:	41 5b                	pop    %r11

000000000010b772 <pf_jump_20>:
  10b772:	e9 e9 c3 f1 ff       	jmp    27b60 <pf_callee_20>
  10b777:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  10b77e:	00 00 

000000000010b780 <pf_call_21>:
  10b780:	0f 18 15 29 17 f4 ff 	prefetcht1 -0xbe8d7(%rip)        # 4ceb0 <pf_target_21_0>
  10b787:	0f 18 15 52 d0 f3 ff 	prefetcht1 -0xc2fae(%rip)        # 487e0 <pf_callee_16>

000000000010b78e <pf_jump_21>:
  10b78e:	e9 4d 1c f4 ff       	jmp    4d3e0 <pf_callee_21>
  10b793:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b79a:	00 00 00 
  10b79d:	0f 1f 00             	nopl   (%rax)

000000000010b7a0 <pf_call_22>:
  10b7a0:	0f 18 15 89 ca f1 ff 	prefetcht1 -0xe3577(%rip)        # 28230 <pf_callee_13>
  10b7a7:	41 53                	push   %r11
  10b7a9:	4c 8b 1d 28 d9 ff ff 	mov    -0x26d8(%rip),%r11        # 1090d8 <pf_got_22_0>

000000000010b7b0 <pf_got_hint_22_0>:
  10b7b0:	41 0f 18 93 90 37 ff 	prefetcht1 -0xc870(%r11)
  10b7b7:	ff 
  10b7b8:	4c 8b 1d 99 de ff ff 	mov    -0x2167(%rip),%r11        # 109658 <pf_got_14_0>

000000000010b7bf <pf_got_hint_22_1>:
  10b7bf:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b7c6:	00 
  10b7c7:	41 5b                	pop    %r11

000000000010b7c9 <pf_jump_22>:
  10b7c9:	e9 12 d0 f3 ff       	jmp    487e0 <pf_callee_16>
  10b7ce:	66 90                	xchg   %ax,%ax

000000000010b7d0 <pf_call_23>:
  10b7d0:	0f 18 15 b9 5b f4 ff 	prefetcht1 -0xba447(%rip)        # 51390 <pf_target_23_0>

000000000010b7d7 <pf_jump_23>:
  10b7d7:	e9 54 c4 f1 ff       	jmp    27c30 <pf_callee_23>
  10b7dc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b7e0 <pf_call_24>:
  10b7e0:	0f 18 15 69 cb f1 ff 	prefetcht1 -0xe3497(%rip)        # 28350 <pf_target_24_0>
  10b7e7:	41 53                	push   %r11
  10b7e9:	4c 8b 1d b8 e1 ff ff 	mov    -0x1e48(%rip),%r11        # 1099a8 <pf_got_24_0>

000000000010b7f0 <pf_got_hint_24_0>:
  10b7f0:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b7f7:	00 

000000000010b7f8 <pf_got_hint_24_1>:
  10b7f8:	41 0f 18 93 a8 02 00 	prefetcht1 0x2a8(%r11)
  10b7ff:	00 
  10b800:	41 5b                	pop    %r11

000000000010b802 <pf_jump_24>:
  10b802:	e9 49 61 f4 ff       	jmp    51950 <pf_callee_24>
  10b807:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  10b80e:	00 00 

000000000010b810 <pf_call_25>:
  10b810:	0f 18 15 29 c1 f5 ff 	prefetcht1 -0xa3ed7(%rip)        # 67940 <pf_target_25_0>
  10b817:	0f 18 15 02 c1 f5 ff 	prefetcht1 -0xa3efe(%rip)        # 67920 <pf_target_25_1>
  10b81e:	0f 18 15 1b b6 f5 ff 	prefetcht1 -0xa49e5(%rip)        # 66e40 <pf_target_25_2>
  10b825:	0f 18 15 04 0b f6 ff 	prefetcht1 -0x9f4fc(%rip)        # 6c330 <pf_target_25_3>
  10b82c:	0f 18 15 8d 58 f6 ff 	prefetcht1 -0x9a773(%rip)        # 710c0 <pf_callee_32>

000000000010b833 <pf_jump_25>:
  10b833:	e9 78 b9 f1 ff       	jmp    271b0 <pf_callee_11>
  10b838:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b83f:	00 

000000000010b840 <pf_call_26>:
  10b840:	0f 18 15 89 be f5 ff 	prefetcht1 -0xa4177(%rip)        # 676d0 <pf_target_26_0>

000000000010b847 <pf_jump_26>:
  10b847:	e9 54 c0 f1 ff       	jmp    278a0 <pf_callee_26>
  10b84c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b850 <pf_call_27>:
  10b850:	0f 18 15 49 c0 f1 ff 	prefetcht1 -0xe3fb7(%rip)        # 278a0 <pf_callee_26>
  10b857:	0f 18 15 4e 37 f6 ff 	prefetcht1 -0x9c8b2(%rip)        # 6efac <pf_target_27_1>
  10b85e:	0f 18 15 6b 01 f6 ff 	prefetcht1 -0x9fe95(%rip)        # 6b9d0 <pf_target_27_2>
  10b865:	0f 18 15 54 cb f1 ff 	prefetcht1 -0xe34ac(%rip)        # 283c0 <pf_callee_30>
  10b86c:	41 53                	push   %r11
  10b86e:	4c 8b 1d db db ff ff 	mov    -0x2425(%rip),%r11        # 109450 <pf_got_27_0>

000000000010b875 <pf_got_hint_27_0>:
  10b875:	41 0f 18 93 10 00 00 	prefetcht1 0x10(%r11)
  10b87c:	00 
  10b87d:	41 5b                	pop    %r11

000000000010b87f <pf_jump_27>:
  10b87f:	e9 6c c5 f5 ff       	jmp    67df0 <pf_callee_27>
  10b884:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b88b:	00 00 00 
  10b88e:	66 90                	xchg   %ax,%ax

000000000010b890 <pf_call_28>:
  10b890:	0f 18 15 09 3f f6 ff 	prefetcht1 -0x9c0f7(%rip)        # 6f7a0 <pf_callee_29>
  10b897:	41 53                	push   %r11
  10b899:	4c 8b 1d 38 d8 ff ff 	mov    -0x27c8(%rip),%r11        # 1090d8 <pf_got_22_0>

000000000010b8a0 <pf_got_hint_28_0>:
  10b8a0:	41 0f 18 93 b0 53 ff 	prefetcht1 -0xac50(%r11)
  10b8a7:	ff 
  10b8a8:	41 5b                	pop    %r11

000000000010b8aa <pf_jump_28>:
  10b8aa:	e9 f1 bf f1 ff       	jmp    278a0 <pf_callee_26>
  10b8af:	90                   	nop

000000000010b8b0 <pf_call_29>:
  10b8b0:	0f 18 15 b9 5d f4 ff 	prefetcht1 -0xba247(%rip)        # 51670 <pf_target_29_0>

000000000010b8b7 <pf_jump_29>:
  10b8b7:	e9 e4 3e f6 ff       	jmp    6f7a0 <pf_callee_29>
  10b8bc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b8c0 <pf_call_30>:
  10b8c0:	0f 18 15 09 ba f5 ff 	prefetcht1 -0xa45f7(%rip)        # 672d0 <pf_target_30_0>
  10b8c7:	0f 18 15 32 07 f6 ff 	prefetcht1 -0x9f8ce(%rip)        # 6c000 <pf_target_30_1>
  10b8ce:	0f 18 15 1b ce f5 ff 	prefetcht1 -0xa31e5(%rip)        # 686f0 <pf_target_30_2>

000000000010b8d5 <pf_jump_30>:
  10b8d5:	e9 e6 ca f1 ff       	jmp    283c0 <pf_callee_30>
  10b8da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000010b8e0 <pf_call_31>:
  10b8e0:	41 53                	push   %r11
  10b8e2:	4c 8b 1d a7 d7 ff ff 	mov    -0x2859(%rip),%r11        # 109090 <pf_got_31_0>

000000000010b8e9 <pf_got_hint_31_0>:
  10b8e9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b8f0:	00 
  10b8f1:	41 5b                	pop    %r11

000000000010b8f3 <pf_jump_31>:
  10b8f3:	e9 18 a6 f6 ff       	jmp    75f10 <pf_callee_31>
  10b8f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b8ff:	00 

000000000010b900 <pf_call_32>:
  10b900:	0f 18 15 d0 36 f6 ff 	prefetcht1 -0x9c930(%rip)        # 6efd7 <pf_target_32_0>
  10b907:	0f 18 15 d7 05 f6 ff 	prefetcht1 -0x9fa29(%rip)        # 6bee5 <pf_target_32_1>
  10b90e:	0f 18 15 4b 36 f6 ff 	prefetcht1 -0x9c9b5(%rip)        # 6ef60 <pf_target_32_2>
  10b915:	0f 18 15 fa 01 f6 ff 	prefetcht1 -0x9fe06(%rip)        # 6bb16 <pf_target_32_3>

000000000010b91c <pf_jump_32>:
  10b91c:	e9 9f 57 f6 ff       	jmp    710c0 <pf_callee_32>
