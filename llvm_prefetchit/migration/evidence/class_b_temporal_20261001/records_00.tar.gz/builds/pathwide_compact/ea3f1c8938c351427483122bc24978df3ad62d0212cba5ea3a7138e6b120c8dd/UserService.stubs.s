.text
.balign 16
.global pf_call_0
.type pf_call_0,@function
pf_call_0:
.cfi_startproc
prefetcht1 pf_target_0_0(%rip)
prefetcht1 pf_target_0_1(%rip)
prefetcht1 pf_target_0_2(%rip)
prefetcht1 pf_target_0_3(%rip)
prefetcht1 pf_target_0_4(%rip)
prefetcht1 pf_target_0_5(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_0_0(%rip),%r11
.global pf_got_hint_0_0
pf_got_hint_0_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
mov pf_got_0_1(%rip),%r11
.global pf_got_hint_0_1
pf_got_hint_0_1:
.byte 0x41,0x0f,0x18,0x93
.long 26976
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_0
pf_jump_0:
jmp pf_callee_0
.cfi_endproc
.size pf_call_0,.-pf_call_0
.balign 16
.global pf_call_1
.type pf_call_1,@function
pf_call_1:
.cfi_startproc
prefetcht1 pf_target_1_0(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_1_0(%rip),%r11
.global pf_got_hint_1_0
pf_got_hint_1_0:
.byte 0x41,0x0f,0x18,0x93
.long 1712
.global pf_got_hint_1_1
pf_got_hint_1_1:
.byte 0x41,0x0f,0x18,0x93
.long 1746
mov pf_got_1_2(%rip),%r11
.global pf_got_hint_1_2
pf_got_hint_1_2:
.byte 0x41,0x0f,0x18,0x93
.long -107248
.global pf_got_hint_1_3
pf_got_hint_1_3:
.byte 0x41,0x0f,0x18,0x93
.long 8133
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_1
pf_jump_1:
jmp pf_callee_1
.cfi_endproc
.size pf_call_1,.-pf_call_1
.balign 16
.global pf_call_2
.type pf_call_2,@function
pf_call_2:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_2_0(%rip),%r11
.global pf_got_hint_2_0
pf_got_hint_2_0:
.byte 0x41,0x0f,0x18,0x93
.long 52
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_2
pf_jump_2:
jmp pf_callee_2
.cfi_endproc
.size pf_call_2,.-pf_call_2
.balign 16
.global pf_call_3
.type pf_call_3,@function
pf_call_3:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_3_0(%rip),%r11
.global pf_got_hint_3_0
pf_got_hint_3_0:
.byte 0x41,0x0f,0x18,0x93
.long -3296
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_3
pf_jump_3:
jmp pf_callee_3
.cfi_endproc
.size pf_call_3,.-pf_call_3
.balign 16
.global pf_call_4
.type pf_call_4,@function
pf_call_4:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_4_0(%rip),%r11
.global pf_got_hint_4_0
pf_got_hint_4_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_4_1
pf_got_hint_4_1:
.byte 0x41,0x0f,0x18,0x93
.long 34
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_4
pf_jump_4:
jmp pf_callee_4
.cfi_endproc
.size pf_call_4,.-pf_call_4
.balign 16
.global pf_call_5
.type pf_call_5,@function
pf_call_5:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_5_0(%rip),%r11
.global pf_got_hint_5_0
pf_got_hint_5_0:
.byte 0x41,0x0f,0x18,0x93
.long -14624
.global pf_got_hint_5_1
pf_got_hint_5_1:
.byte 0x41,0x0f,0x18,0x93
.long -13870
.global pf_got_hint_5_2
pf_got_hint_5_2:
.byte 0x41,0x0f,0x18,0x93
.long -5856
.global pf_got_hint_5_3
pf_got_hint_5_3:
.byte 0x41,0x0f,0x18,0x93
.long -832
.global pf_got_hint_5_4
pf_got_hint_5_4:
.byte 0x41,0x0f,0x18,0x93
.long -813
.global pf_got_hint_5_5
pf_got_hint_5_5:
.byte 0x41,0x0f,0x18,0x93
.long -751
.global pf_got_hint_5_6
pf_got_hint_5_6:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_5_7
pf_got_hint_5_7:
.byte 0x41,0x0f,0x18,0x93
.long 16
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_5
pf_jump_5:
jmp pf_callee_5
.cfi_endproc
.size pf_call_5,.-pf_call_5
.balign 16
.global pf_call_6
.type pf_call_6,@function
pf_call_6:
.cfi_startproc
prefetcht1 pf_target_6_0(%rip)
.global pf_jump_6
pf_jump_6:
jmp pf_callee_6
.cfi_endproc
.size pf_call_6,.-pf_call_6
.balign 16
.global pf_call_7
.type pf_call_7,@function
pf_call_7:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_7_0(%rip),%r11
.global pf_got_hint_7_0
pf_got_hint_7_0:
.byte 0x41,0x0f,0x18,0x93
.long -102624
.global pf_got_hint_7_1
pf_got_hint_7_1:
.byte 0x41,0x0f,0x18,0x93
.long -19366
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_7
pf_jump_7:
jmp pf_callee_7
.cfi_endproc
.size pf_call_7,.-pf_call_7
.balign 16
.global pf_call_8
.type pf_call_8,@function
pf_call_8:
.cfi_startproc
prefetcht1 pf_target_8_0(%rip)
prefetcht1 pf_target_8_1(%rip)
prefetcht1 pf_target_8_2(%rip)
prefetcht1 pf_target_8_3(%rip)
prefetcht1 pf_target_8_4(%rip)
prefetcht1 pf_target_8_5(%rip)
prefetcht1 pf_target_8_6(%rip)
prefetcht1 pf_target_8_7(%rip)
.global pf_jump_8
pf_jump_8:
jmp pf_callee_8
.cfi_endproc
.size pf_call_8,.-pf_call_8
.balign 16
.global pf_call_9
.type pf_call_9,@function
pf_call_9:
.cfi_startproc
prefetcht1 pf_target_9_0(%rip)
prefetcht1 pf_target_9_1(%rip)
prefetcht1 pf_target_9_2(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_9_0(%rip),%r11
.global pf_got_hint_9_0
pf_got_hint_9_0:
.byte 0x41,0x0f,0x18,0x93
.long 112
mov pf_got_9_1(%rip),%r11
.global pf_got_hint_9_1
pf_got_hint_9_1:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_9_2
pf_got_hint_9_2:
.byte 0x41,0x0f,0x18,0x93
.long 32
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_9
pf_jump_9:
jmp pf_callee_9
.cfi_endproc
.size pf_call_9,.-pf_call_9
.balign 16
.global pf_call_10
.type pf_call_10,@function
pf_call_10:
.cfi_startproc
prefetcht1 pf_target_10_0(%rip)
.global pf_jump_10
pf_jump_10:
jmp pf_callee_10
.cfi_endproc
.size pf_call_10,.-pf_call_10
.balign 16
.global pf_call_11
.type pf_call_11,@function
pf_call_11:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_11_0(%rip),%r11
.global pf_got_hint_11_0
pf_got_hint_11_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_11_1
pf_got_hint_11_1:
.byte 0x41,0x0f,0x18,0x93
.long 1360
.global pf_got_hint_11_2
pf_got_hint_11_2:
.byte 0x41,0x0f,0x18,0x93
.long 1444
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_11
pf_jump_11:
jmp pf_callee_11
.cfi_endproc
.size pf_call_11,.-pf_call_11
.balign 16
.global pf_call_12
.type pf_call_12,@function
pf_call_12:
.cfi_startproc
prefetcht1 pf_target_12_0(%rip)
.global pf_jump_12
pf_jump_12:
jmp pf_callee_12
.cfi_endproc
.size pf_call_12,.-pf_call_12
.balign 16
.global pf_call_13
.type pf_call_13,@function
pf_call_13:
.cfi_startproc
prefetcht1 pf_target_13_0(%rip)
.global pf_jump_13
pf_jump_13:
jmp pf_callee_13
.cfi_endproc
.size pf_call_13,.-pf_call_13
.balign 16
.global pf_call_14
.type pf_call_14,@function
pf_call_14:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_14_0(%rip),%r11
.global pf_got_hint_14_0
pf_got_hint_14_0:
.byte 0x41,0x0f,0x18,0x93
.long 355760
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_14
pf_jump_14:
jmp pf_callee_14
.cfi_endproc
.size pf_call_14,.-pf_call_14
.balign 16
.global pf_call_15
.type pf_call_15,@function
pf_call_15:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_15_0(%rip),%r11
.global pf_got_hint_15_0
pf_got_hint_15_0:
.byte 0x41,0x0f,0x18,0x93
.long -2768
.global pf_got_hint_15_1
pf_got_hint_15_1:
.byte 0x41,0x0f,0x18,0x93
.long -2751
.global pf_got_hint_15_2
pf_got_hint_15_2:
.byte 0x41,0x0f,0x18,0x93
.long -2687
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_15
pf_jump_15:
jmp pf_callee_15
.cfi_endproc
.size pf_call_15,.-pf_call_15
.balign 16
.global pf_call_16
.type pf_call_16,@function
pf_call_16:
.cfi_startproc
prefetcht1 pf_target_16_0(%rip)
.global pf_jump_16
pf_jump_16:
jmp pf_callee_16
.cfi_endproc
.size pf_call_16,.-pf_call_16
.balign 16
.global pf_call_17
.type pf_call_17,@function
pf_call_17:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_17_0(%rip),%r11
.global pf_got_hint_17_0
pf_got_hint_17_0:
.byte 0x41,0x0f,0x18,0x93
.long 31056
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_17
pf_jump_17:
jmp pf_callee_17
.cfi_endproc
.size pf_call_17,.-pf_call_17
.balign 16
.global pf_call_18
.type pf_call_18,@function
pf_call_18:
.cfi_startproc
prefetcht1 pf_target_18_0(%rip)
prefetcht1 pf_target_18_1(%rip)
.global pf_jump_18
pf_jump_18:
jmp pf_callee_18
.cfi_endproc
.size pf_call_18,.-pf_call_18
.balign 16
.global pf_call_19
.type pf_call_19,@function
pf_call_19:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_19_0(%rip),%r11
.global pf_got_hint_19_0
pf_got_hint_19_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_19_1
pf_got_hint_19_1:
.byte 0x41,0x0f,0x18,0x93
.long 52
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_19
pf_jump_19:
jmp pf_callee_19
.cfi_endproc
.size pf_call_19,.-pf_call_19
.balign 16
.global pf_call_20
.type pf_call_20,@function
pf_call_20:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_20_0(%rip),%r11
.global pf_got_hint_20_0
pf_got_hint_20_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
mov pf_got_20_1(%rip),%r11
.global pf_got_hint_20_1
pf_got_hint_20_1:
.byte 0x41,0x0f,0x18,0x93
.long -71568
.global pf_got_hint_20_2
pf_got_hint_20_2:
.byte 0x41,0x0f,0x18,0x93
.long -55776
.global pf_got_hint_20_3
pf_got_hint_20_3:
.byte 0x41,0x0f,0x18,0x93
.long -55759
.global pf_got_hint_20_4
pf_got_hint_20_4:
.byte 0x41,0x0f,0x18,0x93
.long -55024
.global pf_got_hint_20_5
pf_got_hint_20_5:
.byte 0x41,0x0f,0x18,0x93
.long -2656
.global pf_got_hint_20_6
pf_got_hint_20_6:
.byte 0x41,0x0f,0x18,0x93
.long -2640
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_20
pf_jump_20:
jmp pf_callee_20
.cfi_endproc
.size pf_call_20,.-pf_call_20
.balign 16
.global pf_call_21
.type pf_call_21,@function
pf_call_21:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_21_0(%rip),%r11
.global pf_got_hint_21_0
pf_got_hint_21_0:
.byte 0x41,0x0f,0x18,0x93
.long 34
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_21
pf_jump_21:
jmp pf_callee_21
.cfi_endproc
.size pf_call_21,.-pf_call_21
.balign 16
.global pf_call_22
.type pf_call_22,@function
pf_call_22:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_22_0(%rip),%r11
.global pf_got_hint_22_0
pf_got_hint_22_0:
.byte 0x41,0x0f,0x18,0x93
.long -46720
mov pf_got_22_1(%rip),%r11
.global pf_got_hint_22_1
pf_got_hint_22_1:
.byte 0x41,0x0f,0x18,0x93
.long -734
mov pf_got_22_2(%rip),%r11
.global pf_got_hint_22_2
pf_got_hint_22_2:
.byte 0x41,0x0f,0x18,0x93
.long -125456
mov pf_got_22_3(%rip),%r11
.global pf_got_hint_22_3
pf_got_hint_22_3:
.byte 0x41,0x0f,0x18,0x93
.long -3853
.global pf_got_hint_22_4
pf_got_hint_22_4:
.byte 0x41,0x0f,0x18,0x93
.long 6288
.global pf_got_hint_22_5
pf_got_hint_22_5:
.byte 0x41,0x0f,0x18,0x93
.long 6400
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_22
pf_jump_22:
jmp pf_callee_22
.cfi_endproc
.size pf_call_22,.-pf_call_22
.balign 16
.global pf_call_23
.type pf_call_23,@function
pf_call_23:
.cfi_startproc
prefetcht1 pf_target_23_0(%rip)
prefetcht1 pf_target_23_1(%rip)
prefetcht1 pf_target_23_2(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_23_0(%rip),%r11
.global pf_got_hint_23_0
pf_got_hint_23_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_23_1
pf_got_hint_23_1:
.byte 0x41,0x0f,0x18,0x93
.long 17
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_23
pf_jump_23:
jmp pf_callee_23
.cfi_endproc
.size pf_call_23,.-pf_call_23
.balign 16
.global pf_call_24
.type pf_call_24,@function
pf_call_24:
.cfi_startproc
prefetcht1 pf_target_24_0(%rip)
.global pf_jump_24
pf_jump_24:
jmp pf_callee_24
.cfi_endproc
.size pf_call_24,.-pf_call_24
.balign 16
.global pf_call_25
.type pf_call_25,@function
pf_call_25:
.cfi_startproc
prefetcht1 pf_target_25_0(%rip)
.global pf_jump_25
pf_jump_25:
jmp pf_callee_25
.cfi_endproc
.size pf_call_25,.-pf_call_25
.balign 16
.global pf_call_26
.type pf_call_26,@function
pf_call_26:
.cfi_startproc
prefetcht1 pf_target_26_0(%rip)
.global pf_jump_26
pf_jump_26:
jmp pf_callee_26
.cfi_endproc
.size pf_call_26,.-pf_call_26
.balign 16
.global pf_call_27
.type pf_call_27,@function
pf_call_27:
.cfi_startproc
prefetcht1 pf_target_27_0(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_27_0(%rip),%r11
.global pf_got_hint_27_0
pf_got_hint_27_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_27
pf_jump_27:
jmp pf_callee_27
.cfi_endproc
.size pf_call_27,.-pf_call_27
.balign 16
.global pf_call_28
.type pf_call_28,@function
pf_call_28:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_28_0(%rip),%r11
.global pf_got_hint_28_0
pf_got_hint_28_0:
.byte 0x41,0x0f,0x18,0x93
.long -109008
.global pf_got_hint_28_1
pf_got_hint_28_1:
.byte 0x41,0x0f,0x18,0x93
.long -103520
.global pf_got_hint_28_2
pf_got_hint_28_2:
.byte 0x41,0x0f,0x18,0x93
.long 136
.global pf_got_hint_28_3
pf_got_hint_28_3:
.byte 0x41,0x0f,0x18,0x93
.long 5824
.global pf_got_hint_28_4
pf_got_hint_28_4:
.byte 0x41,0x0f,0x18,0x93
.long 5888
mov pf_got_28_5(%rip),%r11
.global pf_got_hint_28_5
pf_got_hint_28_5:
.byte 0x41,0x0f,0x18,0x93
.long -115024
.global pf_got_hint_28_6
pf_got_hint_28_6:
.byte 0x41,0x0f,0x18,0x93
.long -113040
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_28
pf_jump_28:
jmp pf_callee_28
.cfi_endproc
.size pf_call_28,.-pf_call_28
.balign 16
.global pf_call_29
.type pf_call_29,@function
pf_call_29:
.cfi_startproc
prefetcht1 pf_target_29_0(%rip)
prefetcht1 pf_target_29_1(%rip)
prefetcht1 pf_target_29_2(%rip)
prefetcht1 pf_target_29_3(%rip)
prefetcht1 pf_target_29_4(%rip)
.global pf_jump_29
pf_jump_29:
jmp pf_callee_29
.cfi_endproc
.size pf_call_29,.-pf_call_29
.balign 16
.global pf_call_30
.type pf_call_30,@function
pf_call_30:
.cfi_startproc
prefetcht1 pf_target_30_0(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_30_0(%rip),%r11
.global pf_got_hint_30_0
pf_got_hint_30_0:
.byte 0x41,0x0f,0x18,0x93
.long -51312
mov pf_got_30_1(%rip),%r11
.global pf_got_hint_30_1
pf_got_hint_30_1:
.byte 0x41,0x0f,0x18,0x93
.long -176
.global pf_got_hint_30_2
pf_got_hint_30_2:
.byte 0x41,0x0f,0x18,0x93
.long -159
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_30
pf_jump_30:
jmp pf_callee_30
.cfi_endproc
.size pf_call_30,.-pf_call_30
.balign 16
.global pf_call_31
.type pf_call_31,@function
pf_call_31:
.cfi_startproc
prefetcht1 pf_target_31_0(%rip)
prefetcht1 pf_target_31_1(%rip)
prefetcht1 pf_target_31_2(%rip)
prefetcht1 pf_target_31_3(%rip)
prefetcht1 pf_target_31_4(%rip)
.global pf_jump_31
pf_jump_31:
jmp pf_callee_31
.cfi_endproc
.size pf_call_31,.-pf_call_31
.balign 16
.global pf_call_32
.type pf_call_32,@function
pf_call_32:
.cfi_startproc
prefetcht1 pf_target_32_0(%rip)
prefetcht1 pf_target_32_1(%rip)
prefetcht1 pf_target_32_2(%rip)
.global pf_jump_32
pf_jump_32:
jmp pf_callee_32
.cfi_endproc
.size pf_call_32,.-pf_call_32
.balign 16
.global pf_call_33
.type pf_call_33,@function
pf_call_33:
.cfi_startproc
prefetcht1 pf_target_33_0(%rip)
prefetcht1 pf_target_33_1(%rip)
prefetcht1 pf_target_33_2(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_33_0(%rip),%r11
.global pf_got_hint_33_0
pf_got_hint_33_0:
.byte 0x41,0x0f,0x18,0x93
.long -44112
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_33
pf_jump_33:
jmp pf_callee_33
.cfi_endproc
.size pf_call_33,.-pf_call_33
.balign 16
.global pf_call_34
.type pf_call_34,@function
pf_call_34:
.cfi_startproc
prefetcht1 pf_target_34_0(%rip)
.global pf_jump_34
pf_jump_34:
jmp pf_callee_34
.cfi_endproc
.size pf_call_34,.-pf_call_34
.balign 16
.global pf_call_35
.type pf_call_35,@function
pf_call_35:
.cfi_startproc
prefetcht1 pf_target_35_0(%rip)
prefetcht1 pf_target_35_1(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_35_0(%rip),%r11
.global pf_got_hint_35_0
pf_got_hint_35_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_35_1
pf_got_hint_35_1:
.byte 0x41,0x0f,0x18,0x93
.long 680
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_35
pf_jump_35:
jmp pf_callee_35
.cfi_endproc
.size pf_call_35,.-pf_call_35
.balign 16
.global pf_call_36
.type pf_call_36,@function
pf_call_36:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_36_0(%rip),%r11
.global pf_got_hint_36_0
pf_got_hint_36_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_36
pf_jump_36:
jmp pf_callee_36
.cfi_endproc
.size pf_call_36,.-pf_call_36
.balign 16
.global pf_call_37
.type pf_call_37,@function
pf_call_37:
.cfi_startproc
prefetcht1 pf_target_37_0(%rip)
prefetcht1 pf_target_37_1(%rip)
prefetcht1 pf_target_37_2(%rip)
prefetcht1 pf_target_37_3(%rip)
prefetcht1 pf_target_37_4(%rip)
.global pf_jump_37
pf_jump_37:
jmp pf_callee_37
.cfi_endproc
.size pf_call_37,.-pf_call_37
.balign 16
.global pf_call_38
.type pf_call_38,@function
pf_call_38:
.cfi_startproc
prefetcht1 pf_target_38_0(%rip)
.global pf_jump_38
pf_jump_38:
jmp pf_callee_38
.cfi_endproc
.size pf_call_38,.-pf_call_38
.balign 16
.global pf_call_39
.type pf_call_39,@function
pf_call_39:
.cfi_startproc
prefetcht1 pf_target_39_0(%rip)
.global pf_jump_39
pf_jump_39:
jmp pf_callee_39
.cfi_endproc
.size pf_call_39,.-pf_call_39
.balign 16
.global pf_call_40
.type pf_call_40,@function
pf_call_40:
.cfi_startproc
prefetcht1 pf_target_40_0(%rip)
prefetcht1 pf_target_40_1(%rip)
prefetcht1 pf_target_40_2(%rip)
prefetcht1 pf_target_40_3(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_40_0(%rip),%r11
.global pf_got_hint_40_0
pf_got_hint_40_0:
.byte 0x41,0x0f,0x18,0x93
.long -46880
mov pf_got_40_1(%rip),%r11
.global pf_got_hint_40_1
pf_got_hint_40_1:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_40
pf_jump_40:
jmp pf_callee_40
.cfi_endproc
.size pf_call_40,.-pf_call_40
.balign 16
.global pf_call_41
.type pf_call_41,@function
pf_call_41:
.cfi_startproc
prefetcht1 pf_target_41_0(%rip)
prefetcht1 pf_target_41_1(%rip)
prefetcht1 pf_target_41_2(%rip)
prefetcht1 pf_target_41_3(%rip)
prefetcht1 pf_target_41_4(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_41_0(%rip),%r11
.global pf_got_hint_41_0
pf_got_hint_41_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
mov pf_got_41_1(%rip),%r11
.global pf_got_hint_41_1
pf_got_hint_41_1:
.byte 0x41,0x0f,0x18,0x93
.long 0
mov pf_got_41_2(%rip),%r11
.global pf_got_hint_41_2
pf_got_hint_41_2:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_41
pf_jump_41:
jmp pf_callee_41
.cfi_endproc
.size pf_call_41,.-pf_call_41
.balign 16
.global pf_call_42
.type pf_call_42,@function
pf_call_42:
.cfi_startproc
prefetcht1 pf_target_42_0(%rip)
.global pf_jump_42
pf_jump_42:
jmp pf_callee_42
.cfi_endproc
.size pf_call_42,.-pf_call_42
.balign 16
.global pf_call_43
.type pf_call_43,@function
pf_call_43:
.cfi_startproc
prefetcht1 pf_target_43_0(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_43_0(%rip),%r11
.global pf_got_hint_43_0
pf_got_hint_43_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_43_1
pf_got_hint_43_1:
.byte 0x41,0x0f,0x18,0x93
.long 49
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_43
pf_jump_43:
jmp pf_callee_43
.cfi_endproc
.size pf_call_43,.-pf_call_43
.section .note.GNU-stack,"",@progbits
