
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_compact/ff0825e113603c3866680d5d52216bc6d8eedf3a59f52a0aef67ff01994db128/call-stub-gtt4goqd/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000022c300 <pf_call_0>:
  22c300:	0f 18 15 a1 a6 e9 ff 	prefetcht1 -0x16595f(%rip)        # c69a8 <pf_target_0_0>
  22c307:	0f 18 15 34 58 ef ff 	prefetcht1 -0x10a7cc(%rip)        # 121b42 <pf_target_0_1>
  22c30e:	0f 18 15 ed e3 ea ff 	prefetcht1 -0x151c13(%rip)        # da702 <pf_target_0_2>

000000000022c315 <pf_jump_0>:
  22c315:	e9 b6 2d e7 ff       	jmp    9f0d0 <pf_callee_0>
  22c31a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000022c320 <pf_call_1>:
  22c320:	0f 18 15 d9 54 e7 ff 	prefetcht1 -0x18ab27(%rip)        # a1800 <pf_callee_4>

000000000022c327 <pf_jump_1>:
  22c327:	e9 54 34 e7 ff       	jmp    9f780 <pf_callee_1>
  22c32c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c330 <pf_call_2>:
  22c330:	0f 18 15 39 24 e7 ff 	prefetcht1 -0x18dbc7(%rip)        # 9e770 <pf_target_2_0>

000000000022c337 <pf_jump_2>:
  22c337:	e9 74 40 e7 ff       	jmp    a03b0 <pf_callee_2>
  22c33c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c340 <pf_call_3>:
  22c340:	0f 18 15 49 0d f1 ff 	prefetcht1 -0xef2b7(%rip)        # 13d090 <pf_target_3_0>
  22c347:	0f 18 15 b2 1c ef ff 	prefetcht1 -0x10e34e(%rip)        # 11e000 <pf_target_3_1>
  22c34e:	0f 18 15 6c 0d f1 ff 	prefetcht1 -0xef294(%rip)        # 13d0c1 <pf_target_3_2>
  22c355:	0f 18 15 a7 86 f1 ff 	prefetcht1 -0xe7959(%rip)        # 144a03 <pf_target_3_3>

000000000022c35c <pf_jump_3>:
  22c35c:	e9 ef 21 e7 ff       	jmp    9e550 <pf_callee_3>
  22c361:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c368:	00 00 00 
  22c36b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c370 <pf_call_4>:
  22c370:	0f 18 15 69 bf ef ff 	prefetcht1 -0x104097(%rip)        # 1282e0 <pf_target_4_0>
  22c377:	0f 18 15 32 26 e7 ff 	prefetcht1 -0x18d9ce(%rip)        # 9e9b0 <pf_target_4_1>
  22c37e:	0f 18 15 8b bf ef ff 	prefetcht1 -0x104075(%rip)        # 128310 <pf_target_4_2>
  22c385:	0f 18 15 c4 bf ef ff 	prefetcht1 -0x10403c(%rip)        # 128350 <pf_target_4_3>
  22c38c:	0f 18 15 cd 20 e7 ff 	prefetcht1 -0x18df33(%rip)        # 9e460 <pf_target_4_4>
  22c393:	0f 18 15 16 4e e7 ff 	prefetcht1 -0x18b1ea(%rip)        # a11b0 <pf_target_4_5>

000000000022c39a <pf_jump_4>:
  22c39a:	e9 61 54 e7 ff       	jmp    a1800 <pf_callee_4>
  22c39f:	90                   	nop

000000000022c3a0 <pf_call_5>:
  22c3a0:	0f 18 15 c9 66 f1 ff 	prefetcht1 -0xe9937(%rip)        # 142a70 <pf_target_5_0>
  22c3a7:	0f 18 15 d4 66 f1 ff 	prefetcht1 -0xe992c(%rip)        # 142a82 <pf_target_5_1>

000000000022c3ae <pf_jump_5>:
  22c3ae:	e9 fd 32 e7 ff       	jmp    9f6b0 <pf_callee_5>
  22c3b3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c3ba:	00 00 00 
  22c3bd:	0f 1f 00             	nopl   (%rax)

000000000022c3c0 <pf_call_6>:
  22c3c0:	0f 18 15 3b e4 f1 ff 	prefetcht1 -0xe1bc5(%rip)        # 14a802 <pf_target_6_0>
  22c3c7:	0f 18 15 22 e4 f1 ff 	prefetcht1 -0xe1bde(%rip)        # 14a7f0 <pf_target_6_1>
  22c3ce:	0f 18 15 03 67 f1 ff 	prefetcht1 -0xe98fd(%rip)        # 142ad8 <pf_target_6_2>
  22c3d5:	0f 18 15 a4 64 f1 ff 	prefetcht1 -0xe9b5c(%rip)        # 142880 <pf_target_6_3>
  22c3dc:	0f 18 15 df 64 f1 ff 	prefetcht1 -0xe9b21(%rip)        # 1428c2 <pf_target_6_4>
  22c3e3:	0f 18 15 06 25 f0 ff 	prefetcht1 -0xfdafa(%rip)        # 12e8f0 <pf_callee_7>

000000000022c3ea <pf_jump_6>:
  22c3ea:	e9 51 ee ef ff       	jmp    12b240 <pf_callee_6>
  22c3ef:	90                   	nop

000000000022c3f0 <pf_call_7>:
  22c3f0:	0f 18 15 99 3a e7 ff 	prefetcht1 -0x18c567(%rip)        # 9fe90 <pf_callee_8>

000000000022c3f7 <pf_jump_7>:
  22c3f7:	e9 f4 24 f0 ff       	jmp    12e8f0 <pf_callee_7>
  22c3fc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c400 <pf_call_8>:
  22c400:	0f 18 15 f9 05 f1 ff 	prefetcht1 -0xefa07(%rip)        # 13ca00 <pf_target_8_0>
  22c407:	0f 18 15 c2 05 f1 ff 	prefetcht1 -0xefa3e(%rip)        # 13c9d0 <pf_target_8_1>

000000000022c40e <pf_jump_8>:
  22c40e:	e9 7d 3a e7 ff       	jmp    9fe90 <pf_callee_8>
  22c413:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c41a:	00 00 00 
  22c41d:	0f 1f 00             	nopl   (%rax)

000000000022c420 <pf_call_9>:
  22c420:	0f 18 15 59 5e f1 ff 	prefetcht1 -0xea1a7(%rip)        # 142280 <pf_target_9_0>
  22c427:	0f 18 15 b2 02 f2 ff 	prefetcht1 -0xdfd4e(%rip)        # 14c6e0 <pf_target_9_1>
  22c42e:	0f 18 15 db 56 e7 ff 	prefetcht1 -0x18a925(%rip)        # a1b10 <pf_target_9_2>
  22c435:	0f 18 15 c4 05 f1 ff 	prefetcht1 -0xefa3c(%rip)        # 13ca00 <pf_target_8_0>

000000000022c43c <pf_jump_9>:
  22c43c:	e9 4f 3a e7 ff       	jmp    9fe90 <pf_callee_8>
  22c441:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c448:	00 00 00 
  22c44b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c450 <pf_call_10>:
  22c450:	0f 18 15 09 37 e9 ff 	prefetcht1 -0x16c8f7(%rip)        # bfb60 <pf_target_10_0>
  22c457:	0f 18 15 25 37 e9 ff 	prefetcht1 -0x16c8db(%rip)        # bfb83 <pf_target_10_1>
  22c45e:	0f 18 15 cb 31 e7 ff 	prefetcht1 -0x18ce35(%rip)        # 9f630 <pf_target_10_2>

000000000022c465 <pf_jump_10>:
  22c465:	e9 46 2d e7 ff       	jmp    9f1b0 <pf_callee_10>
  22c46a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000022c470 <pf_call_11>:
  22c470:	0f 18 15 69 45 e9 ff 	prefetcht1 -0x16ba97(%rip)        # c09e0 <pf_target_11_0>
  22c477:	0f 18 15 d2 20 e7 ff 	prefetcht1 -0x18df2e(%rip)        # 9e550 <pf_callee_3>
  22c47e:	0f 18 15 7b 45 e9 ff 	prefetcht1 -0x16ba85(%rip)        # c0a00 <pf_target_11_2>
  22c485:	0f 18 15 f4 43 e7 ff 	prefetcht1 -0x18bc0c(%rip)        # a0880 <pf_target_11_3>
  22c48c:	0f 18 15 8d e1 ef ff 	prefetcht1 -0x101e73(%rip)        # 12a620 <pf_target_11_4>
  22c493:	0f 18 15 b6 48 e7 ff 	prefetcht1 -0x18b74a(%rip)        # a0d50 <pf_target_11_5>
  22c49a:	0f 18 15 9f 19 ef ff 	prefetcht1 -0x10e661(%rip)        # 11de40 <pf_target_11_6>
  22c4a1:	0f 18 15 18 fe ef ff 	prefetcht1 -0x1001e8(%rip)        # 12c2c0 <pf_target_11_7>

000000000022c4a8 <pf_jump_11>:
  22c4a8:	e9 f3 50 e7 ff       	jmp    a15a0 <pf_callee_11>
  22c4ad:	0f 1f 00             	nopl   (%rax)

000000000022c4b0 <pf_call_12>:
  22c4b0:	0f 18 15 d9 60 f1 ff 	prefetcht1 -0xe9f27(%rip)        # 142590 <pf_target_12_0>
  22c4b7:	0f 18 15 04 61 f1 ff 	prefetcht1 -0xe9efc(%rip)        # 1425c2 <pf_target_12_1>

000000000022c4be <pf_jump_12>:
  22c4be:	e9 1d 42 e7 ff       	jmp    a06e0 <pf_callee_12>
  22c4c3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c4ca:	00 00 00 
  22c4cd:	0f 1f 00             	nopl   (%rax)

000000000022c4d0 <pf_call_13>:
  22c4d0:	0f 18 15 49 56 ef ff 	prefetcht1 -0x10a9b7(%rip)        # 121b20 <pf_target_13_0>

000000000022c4d7 <pf_jump_13>:
  22c4d7:	e9 14 5c e7 ff       	jmp    a20f0 <pf_callee_13>
  22c4dc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c4e0 <pf_call_14>:
  22c4e0:	41 53                	push   %r11
  22c4e2:	4c 8b 1d 37 b4 ff ff 	mov    -0x4bc9(%rip),%r11        # 227920 <pf_got_14_0>

000000000022c4e9 <pf_got_hint_14_0>:
  22c4e9:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  22c4f0:	00 
  22c4f1:	41 5b                	pop    %r11

000000000022c4f3 <pf_jump_14>:
  22c4f3:	e9 d8 45 e7 ff       	jmp    a0ad0 <pf_callee_14>
  22c4f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  22c4ff:	00 

000000000022c500 <pf_call_15>:
  22c500:	0f 18 15 d9 41 e7 ff 	prefetcht1 -0x18be27(%rip)        # a06e0 <pf_callee_12>
  22c507:	0f 18 15 42 fb f1 ff 	prefetcht1 -0xe04be(%rip)        # 14c050 <pf_target_15_1>
  22c50e:	0f 18 15 5b 24 e8 ff 	prefetcht1 -0x17dba5(%rip)        # ae970 <pf_target_15_2>
  22c515:	0f 18 15 f4 f6 f1 ff 	prefetcht1 -0xe090c(%rip)        # 14bc10 <pf_target_15_3>
  22c51c:	0f 18 15 7d 26 e7 ff 	prefetcht1 -0x18d983(%rip)        # 9eba0 <pf_target_15_4>

000000000022c523 <pf_jump_15>:
  22c523:	e9 a8 5a e7 ff       	jmp    a1fd0 <pf_callee_15>
  22c528:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  22c52f:	00 

000000000022c530 <pf_call_16>:
  22c530:	41 53                	push   %r11
  22c532:	4c 8b 1d 3f a7 ff ff 	mov    -0x58c1(%rip),%r11        # 226c78 <pf_got_16_0>

000000000022c539 <pf_got_hint_16_0>:
  22c539:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  22c540:	00 
  22c541:	41 5b                	pop    %r11

000000000022c543 <pf_jump_16>:
  22c543:	e9 68 36 e7 ff       	jmp    9fbb0 <pf_callee_16>
