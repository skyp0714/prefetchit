
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_compact/b2cf6c33b74d2f22543b7a469a75b538911e690f769d0b238843a49465b83793/call-stub-f3ppu0ur/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000229380 <pf_call_0>:
  229380:	0f 18 15 fc d1 e4 ff 	prefetcht1 -0x1b2e04(%rip)        # 76583 <pf_target_0_0>
  229387:	0f 18 15 73 e1 e4 ff 	prefetcht1 -0x1b1e8d(%rip)        # 77501 <pf_target_0_1>
  22938e:	0f 18 15 6d dc e4 ff 	prefetcht1 -0x1b2393(%rip)        # 77002 <pf_target_0_2>
  229395:	0f 18 15 c1 d1 e4 ff 	prefetcht1 -0x1b2e3f(%rip)        # 7655d <pf_target_0_3>
  22939c:	0f 18 15 55 dc e4 ff 	prefetcht1 -0x1b23ab(%rip)        # 76ff8 <pf_target_0_4>
  2293a3:	0f 18 15 d6 4b e6 ff 	prefetcht1 -0x19b42a(%rip)        # 8df80 <pf_target_0_5>

00000000002293aa <pf_jump_0>:
  2293aa:	e9 81 0e e3 ff       	jmp    5a230 <pf_callee_0>
  2293af:	90                   	nop

00000000002293b0 <pf_call_1>:
  2293b0:	0f 18 15 c9 65 e6 ff 	prefetcht1 -0x199a37(%rip)        # 8f980 <pf_target_1_0>
  2293b7:	0f 18 15 04 52 e6 ff 	prefetcht1 -0x19adfc(%rip)        # 8e5c2 <pf_target_1_1>
  2293be:	0f 18 15 7b bc e4 ff 	prefetcht1 -0x1b4385(%rip)        # 75040 <pf_target_1_2>
  2293c5:	0f 18 15 d4 db e4 ff 	prefetcht1 -0x1b242c(%rip)        # 76fa0 <pf_target_1_3>
  2293cc:	0f 18 15 7d cc e4 ff 	prefetcht1 -0x1b3383(%rip)        # 76050 <pf_target_1_4>
  2293d3:	0f 18 15 56 0e e3 ff 	prefetcht1 -0x1cf1aa(%rip)        # 5a230 <pf_callee_0>
  2293da:	0f 18 15 5f 0e e3 ff 	prefetcht1 -0x1cf1a1(%rip)        # 5a240 <pf_target_1_6>
  2293e1:	0f 18 15 88 65 e6 ff 	prefetcht1 -0x199a78(%rip)        # 8f970 <pf_target_1_7>

00000000002293e8 <pf_jump_1>:
  2293e8:	e9 23 52 e6 ff       	jmp    8e610 <pf_callee_1>
  2293ed:	0f 1f 00             	nopl   (%rax)

00000000002293f0 <pf_call_2>:
  2293f0:	0f 18 15 49 82 f8 ff 	prefetcht1 -0x77db7(%rip)        # 1b1640 <pf_target_2_0>
  2293f7:	0f 18 15 62 4b e6 ff 	prefetcht1 -0x19b49e(%rip)        # 8df60 <pf_target_2_1>
  2293fe:	0f 18 15 7c 82 f8 ff 	prefetcht1 -0x77d84(%rip)        # 1b1681 <pf_target_2_2>
  229405:	0f 18 15 74 d9 e4 ff 	prefetcht1 -0x1b268c(%rip)        # 76d80 <pf_target_2_3>
  22940c:	0f 18 15 17 c6 e4 ff 	prefetcht1 -0x1b39e9(%rip)        # 75a2a <pf_target_2_4>
  229413:	0f 18 15 de db e4 ff 	prefetcht1 -0x1b2422(%rip)        # 76ff8 <pf_target_0_4>
  22941a:	0f 18 15 a2 c0 e4 ff 	prefetcht1 -0x1b3f5e(%rip)        # 754c3 <pf_target_2_6>

0000000000229421 <pf_jump_2>:
  229421:	e9 ca bb e4 ff       	jmp    74ff0 <pf_callee_2>
  229426:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22942d:	00 00 00 

0000000000229430 <pf_call_3>:
  229430:	0f 18 15 66 ae e6 ff 	prefetcht1 -0x19519a(%rip)        # 9429d <pf_target_3_0>
  229437:	0f 18 15 f9 d0 e6 ff 	prefetcht1 -0x192f07(%rip)        # 96537 <pf_target_3_1>
  22943e:	0f 18 15 9f d1 e6 ff 	prefetcht1 -0x192e61(%rip)        # 965e4 <pf_target_3_2>
  229445:	0f 18 15 b4 d1 e6 ff 	prefetcht1 -0x192e4c(%rip)        # 96600 <pf_target_3_3>
  22944c:	0f 18 15 ae a5 e6 ff 	prefetcht1 -0x195a52(%rip)        # 93a01 <pf_target_3_4>
  229453:	0f 18 15 66 a4 e6 ff 	prefetcht1 -0x195b9a(%rip)        # 938c0 <pf_target_3_5>
  22945a:	0f 18 15 49 a4 e6 ff 	prefetcht1 -0x195bb7(%rip)        # 938aa <pf_target_3_6>
  229461:	0f 18 15 13 ad e6 ff 	prefetcht1 -0x1952ed(%rip)        # 9417b <pf_target_3_7>

0000000000229468 <pf_jump_3>:
  229468:	e9 b3 75 e6 ff       	jmp    90a20 <pf_callee_24>
  22946d:	0f 1f 00             	nopl   (%rax)

0000000000229470 <pf_call_4>:
  229470:	0f 18 15 04 ad e6 ff 	prefetcht1 -0x1952fc(%rip)        # 9417b <pf_target_3_7>
  229477:	0f 18 15 05 ad e6 ff 	prefetcht1 -0x1952fb(%rip)        # 94183 <pf_target_4_1>
  22947e:	0f 18 15 db dc e6 ff 	prefetcht1 -0x192325(%rip)        # 97160 <pf_target_4_2>

0000000000229485 <pf_jump_4>:
  229485:	e9 36 76 e6 ff       	jmp    90ac0 <pf_callee_14>
  22948a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229490 <pf_call_5>:
  229490:	0f 18 15 b9 c5 ef ff 	prefetcht1 -0x103a47(%rip)        # 125a50 <pf_target_5_0>
  229497:	0f 18 15 12 d4 ef ff 	prefetcht1 -0x102bee(%rip)        # 1268b0 <pf_target_5_1>
  22949e:	0f 18 15 1c d4 ef ff 	prefetcht1 -0x102be4(%rip)        # 1268c1 <pf_target_5_2>
  2294a5:	0f 18 15 d8 c5 ef ff 	prefetcht1 -0x103a28(%rip)        # 125a84 <pf_target_5_3>

00000000002294ac <pf_jump_5>:
  2294ac:	e9 4f d4 ef ff       	jmp    126900 <pf_callee_5>
  2294b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2294b8:	00 00 00 
  2294bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000002294c0 <pf_call_6>:
  2294c0:	0f 18 15 7a b5 e6 ff 	prefetcht1 -0x194a86(%rip)        # 94a41 <pf_target_6_0>

00000000002294c7 <pf_jump_6>:
  2294c7:	e9 f4 0e e1 ff       	jmp    3a3c0 <pf_callee_6>
  2294cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002294d0 <pf_call_7>:
  2294d0:	0f 18 15 09 74 e6 ff 	prefetcht1 -0x198bf7(%rip)        # 908e0 <pf_target_7_0>
  2294d7:	0f 18 15 f2 88 f2 ff 	prefetcht1 -0xd770e(%rip)        # 151dd0 <pf_target_7_1>
  2294de:	0f 18 15 9b 06 f2 ff 	prefetcht1 -0xdf965(%rip)        # 149b80 <pf_target_7_2>
  2294e5:	0f 18 15 c4 f3 f3 ff 	prefetcht1 -0xc0c3c(%rip)        # 1688b0 <pf_target_7_3>
  2294ec:	0f 18 15 ce f3 f3 ff 	prefetcht1 -0xc0c32(%rip)        # 1688c1 <pf_target_7_4>
  2294f3:	0f 18 15 76 ee df ff 	prefetcht1 -0x20118a(%rip)        # 28370 <pf_target_7_5>
  2294fa:	0f 18 15 3f ec e7 ff 	prefetcht1 -0x1813c1(%rip)        # a8140 <pf_target_7_6>
  229501:	0f 18 15 b8 80 e6 ff 	prefetcht1 -0x197f48(%rip)        # 915c0 <pf_target_7_7>

0000000000229508 <pf_jump_7>:
  229508:	e9 53 c8 e1 ff       	jmp    45d60 <pf_callee_7>
  22950d:	0f 1f 00             	nopl   (%rax)

0000000000229510 <pf_call_8>:
  229510:	0f 18 15 18 89 f2 ff 	prefetcht1 -0xd76e8(%rip)        # 151e2f <pf_target_8_0>

0000000000229517 <pf_jump_8>:
  229517:	e9 94 80 e6 ff       	jmp    915b0 <pf_callee_8>
  22951c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229520 <pf_call_9>:
  229520:	0f 18 15 99 8a e6 ff 	prefetcht1 -0x197567(%rip)        # 91fc0 <pf_target_9_0>
  229527:	0f 18 15 94 c1 e6 ff 	prefetcht1 -0x193e6c(%rip)        # 956c2 <pf_target_9_1>
  22952e:	0f 18 15 4b c1 e6 ff 	prefetcht1 -0x193eb5(%rip)        # 95680 <pf_target_9_2>

0000000000229535 <pf_jump_9>:
  229535:	e9 f6 c7 e6 ff       	jmp    95d30 <pf_callee_9>
  22953a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229540 <pf_call_10>:
  229540:	0f 18 15 3c cf e6 ff 	prefetcht1 -0x1930c4(%rip)        # 96483 <pf_target_10_0>

0000000000229547 <pf_jump_10>:
  229547:	e9 74 8b e6 ff       	jmp    920c0 <pf_callee_10>
  22954c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229550 <pf_call_11>:
  229550:	0f 18 15 a9 d3 ef ff 	prefetcht1 -0x102c57(%rip)        # 126900 <pf_callee_5>

0000000000229557 <pf_jump_11>:
  229557:	e9 d4 7d e6 ff       	jmp    91330 <pf_callee_11>
  22955c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229560 <pf_call_12>:
  229560:	0f 18 15 a9 03 e7 ff 	prefetcht1 -0x18fc57(%rip)        # 99910 <pf_target_12_0>

0000000000229567 <pf_jump_12>:
  229567:	e9 74 7d e6 ff       	jmp    912e0 <pf_callee_12>
  22956c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229570 <pf_call_13>:
  229570:	0f 18 15 f9 ce e6 ff 	prefetcht1 -0x193107(%rip)        # 96470 <pf_target_13_0>

0000000000229577 <pf_jump_13>:
  229577:	e9 14 75 e6 ff       	jmp    90a90 <pf_callee_13>
  22957c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229580 <pf_call_14>:
  229580:	0f 18 15 70 b3 e6 ff 	prefetcht1 -0x194c90(%rip)        # 948f7 <pf_target_14_0>
  229587:	0f 18 15 73 98 e6 ff 	prefetcht1 -0x19678d(%rip)        # 92e01 <pf_target_14_1>
  22958e:	0f 18 15 1b 80 e6 ff 	prefetcht1 -0x197fe5(%rip)        # 915b0 <pf_callee_8>

0000000000229595 <pf_jump_14>:
  229595:	e9 26 75 e6 ff       	jmp    90ac0 <pf_callee_14>
  22959a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000002295a0 <pf_call_15>:
  2295a0:	0f 18 15 5a b6 f0 ff 	prefetcht1 -0xf49a6(%rip)        # 134c01 <pf_target_15_0>
  2295a7:	0f 18 15 b2 c7 e1 ff 	prefetcht1 -0x1e384e(%rip)        # 45d60 <pf_callee_7>

00000000002295ae <pf_jump_15>:
  2295ae:	e9 1d 81 e7 ff       	jmp    a16d0 <pf_callee_15>
  2295b3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2295ba:	00 00 00 
  2295bd:	0f 1f 00             	nopl   (%rax)

00000000002295c0 <pf_call_16>:
  2295c0:	0f 18 15 99 c7 e1 ff 	prefetcht1 -0x1e3867(%rip)        # 45d60 <pf_callee_7>
  2295c7:	0f 18 15 b5 b4 e6 ff 	prefetcht1 -0x194b4b(%rip)        # 94a83 <pf_target_16_1>

00000000002295ce <pf_jump_16>:
  2295ce:	e9 9d a3 e7 ff       	jmp    a3970 <pf_callee_16>
  2295d3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2295da:	00 00 00 
  2295dd:	0f 1f 00             	nopl   (%rax)

00000000002295e0 <pf_call_17>:
  2295e0:	0f 18 15 f1 7a e7 ff 	prefetcht1 -0x18850f(%rip)        # a10d8 <pf_target_17_0>

00000000002295e7 <pf_jump_17>:
  2295e7:	e9 64 7a e7 ff       	jmp    a1050 <pf_callee_17>
  2295ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002295f0 <pf_call_18>:
  2295f0:	0f 18 15 29 f0 df ff 	prefetcht1 -0x200fd7(%rip)        # 28620 <pf_target_18_0>

00000000002295f7 <pf_jump_18>:
  2295f7:	e9 74 a3 e7 ff       	jmp    a3970 <pf_callee_16>
  2295fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229600 <pf_call_19>:
  229600:	0f 18 15 fc 80 e7 ff 	prefetcht1 -0x187f04(%rip)        # a1703 <pf_target_19_0>

0000000000229607 <pf_jump_19>:
  229607:	e9 64 a3 e7 ff       	jmp    a3970 <pf_callee_16>
  22960c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229610 <pf_call_20>:
  229610:	0f 18 15 2b a2 e6 ff 	prefetcht1 -0x195dd5(%rip)        # 93842 <pf_target_20_0>
  229617:	0f 18 15 a2 55 ef ff 	prefetcht1 -0x10aa5e(%rip)        # 11ebc0 <pf_target_20_1>
  22961e:	0f 18 15 5b 09 e7 ff 	prefetcht1 -0x18f6a5(%rip)        # 99f80 <pf_target_20_2>
  229625:	0f 18 15 d4 a1 e6 ff 	prefetcht1 -0x195e2c(%rip)        # 93800 <pf_target_20_3>
  22962c:	0f 18 15 cf 96 e7 ff 	prefetcht1 -0x186931(%rip)        # a2d02 <pf_target_20_4>
  229633:	0f 18 15 a6 ce e7 ff 	prefetcht1 -0x18315a(%rip)        # a64e0 <pf_target_20_5>
  22963a:	0f 18 15 af 79 e6 ff 	prefetcht1 -0x198651(%rip)        # 90ff0 <pf_target_20_6>
  229641:	0f 18 15 79 a3 e6 ff 	prefetcht1 -0x195c87(%rip)        # 939c1 <pf_target_20_7>

0000000000229648 <pf_jump_20>:
  229648:	e9 13 90 e7 ff       	jmp    a2660 <pf_callee_20>
  22964d:	0f 1f 00             	nopl   (%rax)

0000000000229650 <pf_call_21>:
  229650:	0f 18 15 f9 79 e7 ff 	prefetcht1 -0x188607(%rip)        # a1050 <pf_callee_17>

0000000000229657 <pf_jump_21>:
  229657:	e9 f4 b2 e7 ff       	jmp    a4950 <pf_callee_21>
  22965c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229660 <pf_call_22>:
  229660:	0f 18 15 59 56 ef ff 	prefetcht1 -0x10a9a7(%rip)        # 11ecc0 <pf_target_22_0>
  229667:	0f 18 15 1f b5 e6 ff 	prefetcht1 -0x194ae1(%rip)        # 94b8d <pf_target_22_1>

000000000022966e <pf_jump_22>:
  22966e:	e9 2d bd e7 ff       	jmp    a53a0 <pf_callee_22>
  229673:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22967a:	00 00 00 
  22967d:	0f 1f 00             	nopl   (%rax)

0000000000229680 <pf_call_23>:
  229680:	0f 18 15 91 d0 e7 ff 	prefetcht1 -0x182f6f(%rip)        # a6718 <pf_target_23_0>

0000000000229687 <pf_jump_23>:
  229687:	e9 e4 a2 e7 ff       	jmp    a3970 <pf_callee_16>
  22968c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229690 <pf_call_24>:
  229690:	0f 18 15 49 e0 ef ff 	prefetcht1 -0x101fb7(%rip)        # 1276e0 <pf_target_24_0>
  229697:	0f 18 15 e2 d1 f7 ff 	prefetcht1 -0x82e1e(%rip)        # 1a6880 <pf_target_24_1>

000000000022969e <pf_jump_24>:
  22969e:	e9 7d 73 e6 ff       	jmp    90a20 <pf_callee_24>
  2296a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2296aa:	00 00 00 
  2296ad:	0f 1f 00             	nopl   (%rax)

00000000002296b0 <pf_call_25>:
  2296b0:	0f 18 15 4a 20 ef ff 	prefetcht1 -0x10dfb6(%rip)        # 11b701 <pf_target_25_0>
  2296b7:	0f 18 15 3e 20 ef ff 	prefetcht1 -0x10dfc2(%rip)        # 11b6fc <pf_target_25_1>

00000000002296be <pf_jump_25>:
  2296be:	e9 5d 73 e6 ff       	jmp    90a20 <pf_callee_24>
