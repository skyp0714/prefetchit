
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_repair/b2cf6c33b74d2f22543b7a469a75b538911e690f769d0b238843a49465b83793/call-stub-hhox6lll/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000229380 <pf_call_0>:
  229380:	0f 18 15 fc d1 e4 ff 	prefetcht1 -0x1b2e04(%rip)        # 76583 <pf_target_0_0>
  229387:	0f 18 15 73 e1 e4 ff 	prefetcht1 -0x1b1e8d(%rip)        # 77501 <pf_target_0_1>
  22938e:	0f 18 15 6d dc e4 ff 	prefetcht1 -0x1b2393(%rip)        # 77002 <pf_target_0_2>
  229395:	0f 18 15 c1 d1 e4 ff 	prefetcht1 -0x1b2e3f(%rip)        # 7655d <pf_target_0_3>
  22939c:	0f 18 15 dd 4b e6 ff 	prefetcht1 -0x19b423(%rip)        # 8df80 <pf_target_0_4>

00000000002293a3 <pf_jump_0>:
  2293a3:	e9 88 0e e3 ff       	jmp    5a230 <pf_callee_0>
  2293a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  2293af:	00 

00000000002293b0 <pf_call_1>:
  2293b0:	0f 18 15 89 82 f8 ff 	prefetcht1 -0x77d77(%rip)        # 1b1640 <pf_target_1_0>
  2293b7:	0f 18 15 22 48 e6 ff 	prefetcht1 -0x19b7de(%rip)        # 8dbe0 <pf_target_1_1>
  2293be:	0f 18 15 3b bc e4 ff 	prefetcht1 -0x1b43c5(%rip)        # 75000 <pf_target_1_2>
  2293c5:	0f 18 15 d4 51 e6 ff 	prefetcht1 -0x19ae2c(%rip)        # 8e5a0 <pf_callee_3>
  2293cc:	0f 18 15 1d bc e4 ff 	prefetcht1 -0x1b43e3(%rip)        # 74ff0 <pf_callee_2>
  2293d3:	0f 18 15 96 65 e6 ff 	prefetcht1 -0x199a6a(%rip)        # 8f970 <pf_target_1_5>
  2293da:	0f 18 15 9f 65 e6 ff 	prefetcht1 -0x199a61(%rip)        # 8f980 <pf_target_1_6>
  2293e1:	0f 18 15 99 82 f8 ff 	prefetcht1 -0x77d67(%rip)        # 1b1681 <pf_target_1_7>

00000000002293e8 <pf_jump_1>:
  2293e8:	e9 23 52 e6 ff       	jmp    8e610 <pf_callee_1>
  2293ed:	0f 1f 00             	nopl   (%rax)

00000000002293f0 <pf_call_2>:
  2293f0:	0f 18 15 f2 d8 e4 ff 	prefetcht1 -0x1b270e(%rip)        # 76ce9 <pf_target_2_0>
  2293f7:	0f 18 15 a2 db e4 ff 	prefetcht1 -0x1b245e(%rip)        # 76fa0 <pf_target_2_1>
  2293fe:	0f 18 15 4b cc e4 ff 	prefetcht1 -0x1b33b5(%rip)        # 76050 <pf_target_2_2>
  229405:	0f 18 15 c4 c2 e4 ff 	prefetcht1 -0x1b3d3c(%rip)        # 756d0 <pf_target_2_3>
  22940c:	0f 18 15 e5 db e4 ff 	prefetcht1 -0x1b241b(%rip)        # 76ff8 <pf_target_2_4>
  229413:	0f 18 15 16 0e e3 ff 	prefetcht1 -0x1cf1ea(%rip)        # 5a230 <pf_callee_0>
  22941a:	0f 18 15 1f 0e e3 ff 	prefetcht1 -0x1cf1e1(%rip)        # 5a240 <pf_target_2_6>
  229421:	0f 18 15 38 4b e6 ff 	prefetcht1 -0x19b4c8(%rip)        # 8df60 <pf_target_2_7>

0000000000229428 <pf_jump_2>:
  229428:	e9 c3 bb e4 ff       	jmp    74ff0 <pf_callee_2>
  22942d:	0f 1f 00             	nopl   (%rax)

0000000000229430 <pf_call_3>:
  229430:	0f 18 15 09 bc e4 ff 	prefetcht1 -0x1b43f7(%rip)        # 75040 <pf_target_3_0>
  229437:	0f 18 15 c3 47 e6 ff 	prefetcht1 -0x19b83d(%rip)        # 8dc01 <pf_target_3_1>
  22943e:	0f 18 15 e5 c5 e4 ff 	prefetcht1 -0x1b3a1b(%rip)        # 75a2a <pf_target_3_2>
  229445:	0f 18 15 77 c0 e4 ff 	prefetcht1 -0x1b3f89(%rip)        # 754c3 <pf_target_3_3>
  22944c:	0f 18 15 ae c2 e4 ff 	prefetcht1 -0x1b3d52(%rip)        # 75701 <pf_target_3_4>

0000000000229453 <pf_jump_3>:
  229453:	e9 48 51 e6 ff       	jmp    8e5a0 <pf_callee_3>
  229458:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  22945f:	00 

0000000000229460 <pf_call_4>:
  229460:	0f 18 15 36 ae e6 ff 	prefetcht1 -0x1951ca(%rip)        # 9429d <pf_target_4_0>
  229467:	0f 18 15 c9 d0 e6 ff 	prefetcht1 -0x192f37(%rip)        # 96537 <pf_target_4_1>
  22946e:	0f 18 15 6f d1 e6 ff 	prefetcht1 -0x192e91(%rip)        # 965e4 <pf_target_4_2>
  229475:	0f 18 15 84 d1 e6 ff 	prefetcht1 -0x192e7c(%rip)        # 96600 <pf_target_4_3>
  22947c:	0f 18 15 7e a5 e6 ff 	prefetcht1 -0x195a82(%rip)        # 93a01 <pf_target_4_4>
  229483:	0f 18 15 f1 ac e6 ff 	prefetcht1 -0x19530f(%rip)        # 9417b <pf_target_4_5>
  22948a:	0f 18 15 b7 d0 e6 ff 	prefetcht1 -0x192f49(%rip)        # 96548 <pf_target_4_6>
  229491:	0f 18 15 b1 7b e6 ff 	prefetcht1 -0x19844f(%rip)        # 91049 <pf_target_4_7>

0000000000229498 <pf_jump_4>:
  229498:	e9 83 75 e6 ff       	jmp    90a20 <pf_callee_28>
  22949d:	0f 1f 00             	nopl   (%rax)

00000000002294a0 <pf_call_5>:
  2294a0:	0f 18 15 59 7b e6 ff 	prefetcht1 -0x1984a7(%rip)        # 91000 <pf_target_17_2>

00000000002294a7 <pf_jump_5>:
  2294a7:	e9 64 04 e7 ff       	jmp    99910 <pf_callee_5>
  2294ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002294b0 <pf_call_6>:
  2294b0:	0f 18 15 09 a4 e6 ff 	prefetcht1 -0x195bf7(%rip)        # 938c0 <pf_target_6_0>
  2294b7:	0f 18 15 ec a3 e6 ff 	prefetcht1 -0x195c14(%rip)        # 938aa <pf_target_6_1>

00000000002294be <pf_jump_6>:
  2294be:	e9 fd 75 e6 ff       	jmp    90ac0 <pf_callee_18>
  2294c3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2294ca:	00 00 00 
  2294cd:	0f 1f 00             	nopl   (%rax)

00000000002294d0 <pf_call_7>:
  2294d0:	0f 18 15 19 7b e6 ff 	prefetcht1 -0x1984e7(%rip)        # 90ff0 <pf_target_24_6>
  2294d7:	0f 18 15 25 7b e6 ff 	prefetcht1 -0x1984db(%rip)        # 91003 <pf_target_7_1>

00000000002294de <pf_jump_7>:
  2294de:	e9 2d 04 e7 ff       	jmp    99910 <pf_callee_5>
  2294e3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2294ea:	00 00 00 
  2294ed:	0f 1f 00             	nopl   (%rax)

00000000002294f0 <pf_call_8>:
  2294f0:	0f 18 15 84 ac e6 ff 	prefetcht1 -0x19537c(%rip)        # 9417b <pf_target_4_5>
  2294f7:	0f 18 15 85 ac e6 ff 	prefetcht1 -0x19537b(%rip)        # 94183 <pf_target_8_1>
  2294fe:	0f 18 15 5b dc e6 ff 	prefetcht1 -0x1923a5(%rip)        # 97160 <pf_target_8_2>
  229505:	0f 18 15 74 dc e6 ff 	prefetcht1 -0x19238c(%rip)        # 97180 <pf_target_8_3>

000000000022950c <pf_jump_8>:
  22950c:	e9 af 75 e6 ff       	jmp    90ac0 <pf_callee_18>
  229511:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229518:	00 00 00 
  22951b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229520 <pf_call_9>:
  229520:	0f 18 15 29 c5 ef ff 	prefetcht1 -0x103ad7(%rip)        # 125a50 <pf_target_9_0>
  229527:	0f 18 15 82 d3 ef ff 	prefetcht1 -0x102c7e(%rip)        # 1268b0 <pf_target_9_1>
  22952e:	0f 18 15 8c d3 ef ff 	prefetcht1 -0x102c74(%rip)        # 1268c1 <pf_target_9_2>
  229535:	0f 18 15 48 c5 ef ff 	prefetcht1 -0x103ab8(%rip)        # 125a84 <pf_target_9_3>
  22953c:	0f 18 15 bd d3 ef ff 	prefetcht1 -0x102c43(%rip)        # 126900 <pf_callee_9>

0000000000229543 <pf_jump_9>:
  229543:	e9 b8 d3 ef ff       	jmp    126900 <pf_callee_9>
  229548:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  22954f:	00 

0000000000229550 <pf_call_10>:
  229550:	0f 18 15 ea b4 e6 ff 	prefetcht1 -0x194b16(%rip)        # 94a41 <pf_target_10_0>

0000000000229557 <pf_jump_10>:
  229557:	e9 64 0e e1 ff       	jmp    3a3c0 <pf_callee_10>
  22955c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229560 <pf_call_11>:
  229560:	0f 18 15 79 73 e6 ff 	prefetcht1 -0x198c87(%rip)        # 908e0 <pf_target_11_0>
  229567:	0f 18 15 62 88 f2 ff 	prefetcht1 -0xd779e(%rip)        # 151dd0 <pf_target_11_1>
  22956e:	0f 18 15 4c f3 f3 ff 	prefetcht1 -0xc0cb4(%rip)        # 1688c1 <pf_target_11_2>
  229575:	0f 18 15 34 f3 f3 ff 	prefetcht1 -0xc0ccc(%rip)        # 1688b0 <pf_target_11_3>
  22957c:	0f 18 15 bd eb e7 ff 	prefetcht1 -0x181443(%rip)        # a8140 <pf_target_11_4>
  229583:	0f 18 15 f6 05 f2 ff 	prefetcht1 -0xdfa0a(%rip)        # 149b80 <pf_target_11_5>
  22958a:	0f 18 15 df ed df ff 	prefetcht1 -0x201221(%rip)        # 28370 <pf_target_11_6>
  229591:	0f 18 15 28 80 e6 ff 	prefetcht1 -0x197fd8(%rip)        # 915c0 <pf_target_11_7>

0000000000229598 <pf_jump_11>:
  229598:	e9 c3 c7 e1 ff       	jmp    45d60 <pf_callee_11>
  22959d:	0f 1f 00             	nopl   (%rax)

00000000002295a0 <pf_call_12>:
  2295a0:	0f 18 15 88 88 f2 ff 	prefetcht1 -0xd7778(%rip)        # 151e2f <pf_target_12_0>

00000000002295a7 <pf_jump_12>:
  2295a7:	e9 04 80 e6 ff       	jmp    915b0 <pf_callee_12>
  2295ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002295b0 <pf_call_13>:
  2295b0:	0f 18 15 d6 b5 e6 ff 	prefetcht1 -0x194a2a(%rip)        # 94b8d <pf_target_13_0>

00000000002295b7 <pf_jump_13>:
  2295b7:	e9 54 1d ef ff       	jmp    11b310 <pf_callee_13>
  2295bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002295c0 <pf_call_14>:
  2295c0:	0f 18 15 f9 89 e6 ff 	prefetcht1 -0x197607(%rip)        # 91fc0 <pf_target_14_0>
  2295c7:	0f 18 15 f4 c0 e6 ff 	prefetcht1 -0x193f0c(%rip)        # 956c2 <pf_target_14_1>
  2295ce:	0f 18 15 ab c0 e6 ff 	prefetcht1 -0x193f55(%rip)        # 95680 <pf_target_14_2>

00000000002295d5 <pf_jump_14>:
  2295d5:	e9 56 c7 e6 ff       	jmp    95d30 <pf_callee_14>
  2295da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000002295e0 <pf_call_15>:
  2295e0:	0f 18 15 19 d3 ef ff 	prefetcht1 -0x102ce7(%rip)        # 126900 <pf_callee_9>

00000000002295e7 <pf_jump_15>:
  2295e7:	e9 44 7d e6 ff       	jmp    91330 <pf_callee_15>
  2295ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002295f0 <pf_call_16>:
  2295f0:	0f 18 15 19 03 e7 ff 	prefetcht1 -0x18fce7(%rip)        # 99910 <pf_callee_5>
  2295f7:	0f 18 15 c5 aa e6 ff 	prefetcht1 -0x19553b(%rip)        # 940c3 <pf_target_16_1>

00000000002295fe <pf_jump_16>:
  2295fe:	e9 dd 7c e6 ff       	jmp    912e0 <pf_callee_16>
  229603:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22960a:	00 00 00 
  22960d:	0f 1f 00             	nopl   (%rax)

0000000000229610 <pf_call_17>:
  229610:	0f 18 15 59 ce e6 ff 	prefetcht1 -0x1931a7(%rip)        # 96470 <pf_target_17_0>
  229617:	0f 18 15 65 ce e6 ff 	prefetcht1 -0x19319b(%rip)        # 96483 <pf_target_17_1>
  22961e:	0f 18 15 db 79 e6 ff 	prefetcht1 -0x198625(%rip)        # 91000 <pf_target_17_2>

0000000000229625 <pf_jump_17>:
  229625:	e9 66 74 e6 ff       	jmp    90a90 <pf_callee_17>
  22962a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229630 <pf_call_18>:
  229630:	0f 18 15 c0 b2 e6 ff 	prefetcht1 -0x194d40(%rip)        # 948f7 <pf_target_18_0>
  229637:	0f 18 15 c3 97 e6 ff 	prefetcht1 -0x19683d(%rip)        # 92e01 <pf_target_18_1>
  22963e:	0f 18 15 6b 7f e6 ff 	prefetcht1 -0x198095(%rip)        # 915b0 <pf_callee_12>

0000000000229645 <pf_jump_18>:
  229645:	e9 76 74 e6 ff       	jmp    90ac0 <pf_callee_18>
  22964a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229650 <pf_call_19>:
  229650:	0f 18 15 aa b5 f0 ff 	prefetcht1 -0xf4a56(%rip)        # 134c01 <pf_target_19_0>
  229657:	0f 18 15 02 c7 e1 ff 	prefetcht1 -0x1e38fe(%rip)        # 45d60 <pf_callee_11>

000000000022965e <pf_jump_19>:
  22965e:	e9 6d 80 e7 ff       	jmp    a16d0 <pf_callee_19>
  229663:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22966a:	00 00 00 
  22966d:	0f 1f 00             	nopl   (%rax)

0000000000229670 <pf_call_20>:
  229670:	0f 18 15 e9 c6 e1 ff 	prefetcht1 -0x1e3917(%rip)        # 45d60 <pf_callee_11>
  229677:	0f 18 15 05 b4 e6 ff 	prefetcht1 -0x194bfb(%rip)        # 94a83 <pf_target_20_1>

000000000022967e <pf_jump_20>:
  22967e:	e9 ed a2 e7 ff       	jmp    a3970 <pf_callee_20>
  229683:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22968a:	00 00 00 
  22968d:	0f 1f 00             	nopl   (%rax)

0000000000229690 <pf_call_21>:
  229690:	0f 18 15 41 7a e7 ff 	prefetcht1 -0x1885bf(%rip)        # a10d8 <pf_target_21_0>

0000000000229697 <pf_jump_21>:
  229697:	e9 b4 79 e7 ff       	jmp    a1050 <pf_callee_21>
  22969c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002296a0 <pf_call_22>:
  2296a0:	0f 18 15 79 ef df ff 	prefetcht1 -0x201087(%rip)        # 28620 <pf_target_22_0>

00000000002296a7 <pf_jump_22>:
  2296a7:	e9 c4 a2 e7 ff       	jmp    a3970 <pf_callee_20>
  2296ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002296b0 <pf_call_23>:
  2296b0:	0f 18 15 4c 80 e7 ff 	prefetcht1 -0x187fb4(%rip)        # a1703 <pf_target_23_0>

00000000002296b7 <pf_jump_23>:
  2296b7:	e9 b4 a2 e7 ff       	jmp    a3970 <pf_callee_20>
  2296bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002296c0 <pf_call_24>:
  2296c0:	0f 18 15 7b a1 e6 ff 	prefetcht1 -0x195e85(%rip)        # 93842 <pf_target_24_0>
  2296c7:	0f 18 15 f2 54 ef ff 	prefetcht1 -0x10ab0e(%rip)        # 11ebc0 <pf_target_24_1>
  2296ce:	0f 18 15 ab 08 e7 ff 	prefetcht1 -0x18f755(%rip)        # 99f80 <pf_target_24_2>
  2296d5:	0f 18 15 24 a1 e6 ff 	prefetcht1 -0x195edc(%rip)        # 93800 <pf_target_24_3>
  2296dc:	0f 18 15 1f 96 e7 ff 	prefetcht1 -0x1869e1(%rip)        # a2d02 <pf_target_24_4>
  2296e3:	0f 18 15 f6 cd e7 ff 	prefetcht1 -0x18320a(%rip)        # a64e0 <pf_target_24_5>
  2296ea:	0f 18 15 ff 78 e6 ff 	prefetcht1 -0x198701(%rip)        # 90ff0 <pf_target_24_6>
  2296f1:	0f 18 15 c9 a2 e6 ff 	prefetcht1 -0x195d37(%rip)        # 939c1 <pf_target_24_7>

00000000002296f8 <pf_jump_24>:
  2296f8:	e9 63 8f e7 ff       	jmp    a2660 <pf_callee_24>
  2296fd:	0f 1f 00             	nopl   (%rax)

0000000000229700 <pf_call_25>:
  229700:	0f 18 15 49 79 e7 ff 	prefetcht1 -0x1886b7(%rip)        # a1050 <pf_callee_21>

0000000000229707 <pf_jump_25>:
  229707:	e9 44 b2 e7 ff       	jmp    a4950 <pf_callee_25>
  22970c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229710 <pf_call_26>:
  229710:	0f 18 15 a9 55 ef ff 	prefetcht1 -0x10aa57(%rip)        # 11ecc0 <pf_target_26_0>

0000000000229717 <pf_jump_26>:
  229717:	e9 84 bc e7 ff       	jmp    a53a0 <pf_callee_26>
  22971c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229720 <pf_call_27>:
  229720:	0f 18 15 f1 cf e7 ff 	prefetcht1 -0x18300f(%rip)        # a6718 <pf_target_27_0>

0000000000229727 <pf_jump_27>:
  229727:	e9 44 a2 e7 ff       	jmp    a3970 <pf_callee_20>
  22972c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229730 <pf_call_28>:
  229730:	0f 18 15 a9 df ef ff 	prefetcht1 -0x102057(%rip)        # 1276e0 <pf_target_28_0>
  229737:	0f 18 15 42 d1 f7 ff 	prefetcht1 -0x82ebe(%rip)        # 1a6880 <pf_target_28_1>
  22973e:	0f 18 15 8b f5 ee ff 	prefetcht1 -0x110a75(%rip)        # 118cd0 <pf_target_28_2>

0000000000229745 <pf_jump_28>:
  229745:	e9 d6 72 e6 ff       	jmp    90a20 <pf_callee_28>
  22974a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229750 <pf_call_29>:
  229750:	0f 18 15 aa 1f ef ff 	prefetcht1 -0x10e056(%rip)        # 11b701 <pf_target_29_0>
  229757:	0f 18 15 9e 1f ef ff 	prefetcht1 -0x10e062(%rip)        # 11b6fc <pf_target_29_1>

000000000022975e <pf_jump_29>:
  22975e:	e9 bd 72 e6 ff       	jmp    90a20 <pf_callee_28>
