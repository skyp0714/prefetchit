
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_repair/74758375d70ece71e60caec108eeeae79d9abef7dce5ef79835d4c0c4edfca8e/call-stub-sd1p9k8m/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000c22c0 <pf_call_0>:
   c22c0:	0f 18 15 b9 00 fa ff 	prefetcht1 -0x5ff47(%rip)        # 62380 <pf_target_0_0>

00000000000c22c7 <pf_jump_0>:
   c22c7:	e9 d4 67 f8 ff       	jmp    48aa0 <pf_callee_0>
   c22cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000c22d0 <pf_call_1>:
   c22d0:	0f 18 15 49 6d f8 ff 	prefetcht1 -0x792b7(%rip)        # 49020 <pf_callee_2>
   c22d7:	0f 18 15 22 57 f8 ff 	prefetcht1 -0x7a8de(%rip)        # 47a00 <pf_callee_3>
   c22de:	0f 18 15 cf 69 fb ff 	prefetcht1 -0x49631(%rip)        # 78cb4 <pf_target_1_2>

00000000000c22e5 <pf_jump_1>:
   c22e5:	e9 76 52 f8 ff       	jmp    47560 <pf_callee_1>
   c22ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000c22f0 <pf_call_2>:
   c22f0:	0f 18 15 09 60 f8 ff 	prefetcht1 -0x79ff7(%rip)        # 48300 <pf_callee_5>
   c22f7:	0f 18 15 02 e2 fb ff 	prefetcht1 -0x41dfe(%rip)        # 80500 <pf_target_2_1>

00000000000c22fe <pf_jump_2>:
   c22fe:	e9 1d 6d f8 ff       	jmp    49020 <pf_callee_2>
   c2303:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c230a:	00 00 00 
   c230d:	0f 1f 00             	nopl   (%rax)

00000000000c2310 <pf_call_3>:
   c2310:	0f 18 15 ae 6c fb ff 	prefetcht1 -0x49352(%rip)        # 78fc5 <pf_target_3_0>
   c2317:	0f 18 15 82 86 fb ff 	prefetcht1 -0x4797e(%rip)        # 7a9a0 <pf_target_3_1>
   c231e:	0f 18 15 4b 85 fb ff 	prefetcht1 -0x47ab5(%rip)        # 7a870 <pf_target_3_2>
   c2325:	0f 18 15 44 68 fb ff 	prefetcht1 -0x497bc(%rip)        # 78b70 <pf_target_3_3>
   c232c:	0f 18 15 54 85 fb ff 	prefetcht1 -0x47aac(%rip)        # 7a887 <pf_target_3_4>
   c2333:	0f 18 15 b7 e1 fb ff 	prefetcht1 -0x41e49(%rip)        # 804f1 <pf_target_3_5>
   c233a:	0f 18 15 44 68 fb ff 	prefetcht1 -0x497bc(%rip)        # 78b85 <pf_target_3_6>
   c2341:	0f 18 15 23 e6 fb ff 	prefetcht1 -0x419dd(%rip)        # 8096b <pf_target_3_7>

00000000000c2348 <pf_jump_3>:
   c2348:	e9 b3 56 f8 ff       	jmp    47a00 <pf_callee_3>
   c234d:	0f 1f 00             	nopl   (%rax)

00000000000c2350 <pf_call_4>:
   c2350:	0f 18 15 69 12 fb ff 	prefetcht1 -0x4ed97(%rip)        # 735c0 <pf_target_4_0>
   c2357:	0f 18 15 e2 54 f8 ff 	prefetcht1 -0x7ab1e(%rip)        # 47840 <pf_target_4_1>
   c235e:	0f 18 15 5b f5 fb ff 	prefetcht1 -0x40aa5(%rip)        # 818c0 <pf_target_4_2>
   c2365:	0f 18 15 a4 f6 fb ff 	prefetcht1 -0x4095c(%rip)        # 81a10 <pf_target_4_3>
   c236c:	41 53                	push   %r11
   c236e:	4c 8b 1d 43 e5 ff ff 	mov    -0x1abd(%rip),%r11        # c08b8 <pf_got_4_0>

00000000000c2375 <pf_got_hint_4_0>:
   c2375:	41 0f 18 93 40 07 00 	prefetcht1 0x740(%r11)
   c237c:	00 
   c237d:	41 5b                	pop    %r11

00000000000c237f <pf_jump_4>:
   c237f:	e9 9c 59 f8 ff       	jmp    47d20 <pf_callee_4>
   c2384:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c238b:	00 00 00 
   c238e:	66 90                	xchg   %ax,%ax

00000000000c2390 <pf_call_5>:
   c2390:	0f 18 15 6a ec fb ff 	prefetcht1 -0x41396(%rip)        # 81001 <pf_target_5_0>
   c2397:	0f 18 15 22 f3 fb ff 	prefetcht1 -0x40cde(%rip)        # 816c0 <pf_target_5_1>
   c239e:	0f 18 15 70 f5 fb ff 	prefetcht1 -0x40a90(%rip)        # 81915 <pf_target_5_2>
   c23a5:	0f 18 15 9c f5 fb ff 	prefetcht1 -0x40a64(%rip)        # 81948 <pf_target_5_3>
   c23ac:	0f 18 15 3d ec fb ff 	prefetcht1 -0x413c3(%rip)        # 80ff0 <pf_target_5_4>
   c23b3:	0f 18 15 46 f3 fb ff 	prefetcht1 -0x40cba(%rip)        # 81700 <pf_target_5_5>
   c23ba:	41 53                	push   %r11
   c23bc:	4c 8b 1d f5 e4 ff ff 	mov    -0x1b0b(%rip),%r11        # c08b8 <pf_got_4_0>

00000000000c23c3 <pf_got_hint_5_0>:
   c23c3:	41 0f 18 93 a0 04 0a 	prefetcht1 0xa04a0(%r11)
   c23ca:	00 

00000000000c23cb <pf_got_hint_5_1>:
   c23cb:	41 0f 18 93 40 06 0a 	prefetcht1 0xa0640(%r11)
   c23d2:	00 
   c23d3:	41 5b                	pop    %r11

00000000000c23d5 <pf_jump_5>:
   c23d5:	e9 26 5f f8 ff       	jmp    48300 <pf_callee_5>
   c23da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000c23e0 <pf_call_6>:
   c23e0:	0f 18 15 09 6e fb ff 	prefetcht1 -0x491f7(%rip)        # 791f0 <pf_target_6_0>
   c23e7:	0f 18 15 92 e0 fb ff 	prefetcht1 -0x41f6e(%rip)        # 80480 <pf_target_6_1>
   c23ee:	0f 18 15 4b 4d fb ff 	prefetcht1 -0x4b2b5(%rip)        # 77140 <pf_target_6_2>
   c23f5:	0f 18 15 84 4d fb ff 	prefetcht1 -0x4b27c(%rip)        # 77180 <pf_target_6_3>
   c23fc:	0f 18 15 4d 84 fb ff 	prefetcht1 -0x47bb3(%rip)        # 7a850 <pf_target_6_4>
   c2403:	0f 18 15 16 59 f8 ff 	prefetcht1 -0x7a6ea(%rip)        # 47d20 <pf_callee_4>
   c240a:	0f 18 15 f1 6d fb ff 	prefetcht1 -0x4920f(%rip)        # 79202 <pf_target_6_6>

00000000000c2411 <pf_jump_6>:
   c2411:	e9 ea 5e f8 ff       	jmp    48300 <pf_callee_5>
   c2416:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   c241d:	00 00 00 

00000000000c2420 <pf_call_7>:
   c2420:	41 53                	push   %r11
   c2422:	4c 8b 1d 8f e4 ff ff 	mov    -0x1b71(%rip),%r11        # c08b8 <pf_got_4_0>

00000000000c2429 <pf_got_hint_7_0>:
   c2429:	41 0f 18 93 c0 53 ff 	prefetcht1 -0xac40(%r11)
   c2430:	ff 

00000000000c2431 <pf_got_hint_7_1>:
   c2431:	41 0f 18 93 71 1d 00 	prefetcht1 0x1d71(%r11)
   c2438:	00 

00000000000c2439 <pf_got_hint_7_2>:
   c2439:	41 0f 18 93 f2 04 0a 	prefetcht1 0xa04f2(%r11)
   c2440:	00 
   c2441:	41 5b                	pop    %r11

00000000000c2443 <pf_jump_7>:
   c2443:	e9 b8 5e f8 ff       	jmp    48300 <pf_callee_5>
