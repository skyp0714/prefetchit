
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_repair/ff0825e113603c3866680d5d52216bc6d8eedf3a59f52a0aef67ff01994db128/call-stub-15a8rl93/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000022c300 <pf_call_0>:
  22c300:	0f 18 15 d9 e3 ea ff 	prefetcht1 -0x151c27(%rip)        # da6e0 <pf_target_0_0>
  22c307:	0f 18 15 9a a6 e9 ff 	prefetcht1 -0x165966(%rip)        # c69a8 <pf_target_0_1>
  22c30e:	0f 18 15 2d 58 ef ff 	prefetcht1 -0x10a7d3(%rip)        # 121b42 <pf_target_0_2>
  22c315:	0f 18 15 64 34 e7 ff 	prefetcht1 -0x18cb9c(%rip)        # 9f780 <pf_callee_1>

000000000022c31c <pf_jump_0>:
  22c31c:	e9 af 2d e7 ff       	jmp    9f0d0 <pf_callee_0>
  22c321:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c328:	00 00 00 
  22c32b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c330 <pf_call_1>:
  22c330:	0f 18 15 c9 54 e7 ff 	prefetcht1 -0x18ab37(%rip)        # a1800 <pf_callee_7>

000000000022c337 <pf_jump_1>:
  22c337:	e9 44 34 e7 ff       	jmp    9f780 <pf_callee_1>
  22c33c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c340 <pf_call_2>:
  22c340:	0f 18 15 e9 e5 ea ff 	prefetcht1 -0x151a17(%rip)        # da930 <pf_target_2_0>
  22c347:	0f 18 15 22 24 e7 ff 	prefetcht1 -0x18dbde(%rip)        # 9e770 <pf_target_2_1>

000000000022c34e <pf_jump_2>:
  22c34e:	e9 5d 40 e7 ff       	jmp    a03b0 <pf_callee_2>
  22c353:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c35a:	00 00 00 
  22c35d:	0f 1f 00             	nopl   (%rax)

000000000022c360 <pf_call_3>:
  22c360:	0f 18 15 9c 86 f1 ff 	prefetcht1 -0xe7964(%rip)        # 144a03 <pf_target_3_0>

000000000022c367 <pf_jump_3>:
  22c367:	e9 a4 5e e7 ff       	jmp    a2210 <pf_callee_3>
  22c36c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c370 <pf_call_4>:
  22c370:	0f 18 15 19 0d f1 ff 	prefetcht1 -0xef2e7(%rip)        # 13d090 <pf_target_4_0>

000000000022c377 <pf_jump_4>:
  22c377:	e9 d4 21 e7 ff       	jmp    9e550 <pf_callee_4>
  22c37c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c380 <pf_call_5>:
  22c380:	0f 18 15 79 1c ef ff 	prefetcht1 -0x10e387(%rip)        # 11e000 <pf_target_5_0>

000000000022c387 <pf_jump_5>:
  22c387:	e9 04 35 e7 ff       	jmp    9f890 <pf_callee_5>
  22c38c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c390 <pf_call_6>:
  22c390:	0f 18 15 ec 37 e9 ff 	prefetcht1 -0x16c814(%rip)        # bfb83 <pf_target_6_0>

000000000022c397 <pf_jump_6>:
  22c397:	e9 a4 52 e7 ff       	jmp    a1640 <pf_callee_6>
  22c39c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c3a0 <pf_call_7>:
  22c3a0:	0f 18 15 39 bf ef ff 	prefetcht1 -0x1040c7(%rip)        # 1282e0 <pf_target_7_0>
  22c3a7:	0f 18 15 02 26 e7 ff 	prefetcht1 -0x18d9fe(%rip)        # 9e9b0 <pf_target_7_1>
  22c3ae:	0f 18 15 5b bf ef ff 	prefetcht1 -0x1040a5(%rip)        # 128310 <pf_target_7_2>
  22c3b5:	0f 18 15 94 bf ef ff 	prefetcht1 -0x10406c(%rip)        # 128350 <pf_target_7_3>
  22c3bc:	0f 18 15 9d 20 e7 ff 	prefetcht1 -0x18df63(%rip)        # 9e460 <pf_target_7_4>
  22c3c3:	0f 18 15 e6 4d e7 ff 	prefetcht1 -0x18b21a(%rip)        # a11b0 <pf_target_7_5>
  22c3ca:	0f 18 15 bf 34 e7 ff 	prefetcht1 -0x18cb41(%rip)        # 9f890 <pf_callee_5>

000000000022c3d1 <pf_jump_7>:
  22c3d1:	e9 2a 54 e7 ff       	jmp    a1800 <pf_callee_7>
  22c3d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c3dd:	00 00 00 

000000000022c3e0 <pf_call_8>:
  22c3e0:	0f 18 15 da 0c f1 ff 	prefetcht1 -0xef326(%rip)        # 13d0c1 <pf_target_8_0>

000000000022c3e7 <pf_jump_8>:
  22c3e7:	e9 c4 32 e7 ff       	jmp    9f6b0 <pf_callee_8>
  22c3ec:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c3f0 <pf_call_9>:
  22c3f0:	0f 18 15 79 66 f1 ff 	prefetcht1 -0xe9987(%rip)        # 142a70 <pf_target_9_0>
  22c3f7:	0f 18 15 84 66 f1 ff 	prefetcht1 -0xe997c(%rip)        # 142a82 <pf_target_9_1>
  22c3fe:	0f 18 15 72 28 f0 ff 	prefetcht1 -0xfd78e(%rip)        # 12ec77 <pf_target_9_2>

000000000022c405 <pf_jump_9>:
  22c405:	e9 a6 32 e7 ff       	jmp    9f6b0 <pf_callee_8>
  22c40a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000022c410 <pf_call_10>:
  22c410:	0f 18 15 eb e3 f1 ff 	prefetcht1 -0xe1c15(%rip)        # 14a802 <pf_target_10_0>
  22c417:	0f 18 15 d2 e3 f1 ff 	prefetcht1 -0xe1c2e(%rip)        # 14a7f0 <pf_target_10_1>
  22c41e:	0f 18 15 b3 66 f1 ff 	prefetcht1 -0xe994d(%rip)        # 142ad8 <pf_target_10_2>
  22c425:	0f 18 15 54 64 f1 ff 	prefetcht1 -0xe9bac(%rip)        # 142880 <pf_target_10_3>
  22c42c:	0f 18 15 8f 64 f1 ff 	prefetcht1 -0xe9b71(%rip)        # 1428c2 <pf_target_10_4>
  22c433:	0f 18 15 b6 24 f0 ff 	prefetcht1 -0xfdb4a(%rip)        # 12e8f0 <pf_callee_11>

000000000022c43a <pf_jump_10>:
  22c43a:	e9 01 ee ef ff       	jmp    12b240 <pf_callee_10>
  22c43f:	90                   	nop

000000000022c440 <pf_call_11>:
  22c440:	0f 18 15 49 3a e7 ff 	prefetcht1 -0x18c5b7(%rip)        # 9fe90 <pf_callee_12>

000000000022c447 <pf_jump_11>:
  22c447:	e9 a4 24 f0 ff       	jmp    12e8f0 <pf_callee_11>
  22c44c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c450 <pf_call_12>:
  22c450:	0f 18 15 a9 05 f1 ff 	prefetcht1 -0xefa57(%rip)        # 13ca00 <pf_target_12_0>
  22c457:	0f 18 15 72 05 f1 ff 	prefetcht1 -0xefa8e(%rip)        # 13c9d0 <pf_target_12_1>

000000000022c45e <pf_jump_12>:
  22c45e:	e9 2d 3a e7 ff       	jmp    9fe90 <pf_callee_12>
  22c463:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c46a:	00 00 00 
  22c46d:	0f 1f 00             	nopl   (%rax)

000000000022c470 <pf_call_13>:
  22c470:	0f 18 15 09 5e f1 ff 	prefetcht1 -0xea1f7(%rip)        # 142280 <pf_target_13_0>
  22c477:	0f 18 15 62 02 f2 ff 	prefetcht1 -0xdfd9e(%rip)        # 14c6e0 <pf_target_13_1>
  22c47e:	0f 18 15 8b 56 e7 ff 	prefetcht1 -0x18a975(%rip)        # a1b10 <pf_target_13_2>
  22c485:	0f 18 15 74 05 f1 ff 	prefetcht1 -0xefa8c(%rip)        # 13ca00 <pf_target_12_0>
  22c48c:	0f 18 15 6e 65 f1 ff 	prefetcht1 -0xe9a92(%rip)        # 142a01 <pf_target_13_4>

000000000022c493 <pf_jump_13>:
  22c493:	e9 f8 39 e7 ff       	jmp    9fe90 <pf_callee_12>
  22c498:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  22c49f:	00 

000000000022c4a0 <pf_call_14>:
  22c4a0:	0f 18 15 19 1b ef ff 	prefetcht1 -0x10e4e7(%rip)        # 11dfc0 <pf_target_14_0>
  22c4a7:	0f 18 15 f2 50 e7 ff 	prefetcht1 -0x18af0e(%rip)        # a15a0 <pf_callee_15>
  22c4ae:	0f 18 15 6b 5e e9 ff 	prefetcht1 -0x16a195(%rip)        # c2320 <pf_target_14_2>
  22c4b5:	0f 18 15 d4 5e e9 ff 	prefetcht1 -0x16a12c(%rip)        # c2390 <pf_target_14_3>
  22c4bc:	0f 18 15 3f e2 ea ff 	prefetcht1 -0x151dc1(%rip)        # da702 <pf_target_14_4>
  22c4c3:	0f 18 15 16 e2 ea ff 	prefetcht1 -0x151dea(%rip)        # da6e0 <pf_target_0_0>
  22c4ca:	0f 18 15 5f 31 e7 ff 	prefetcht1 -0x18cea1(%rip)        # 9f630 <pf_target_14_6>
  22c4d1:	0f 18 15 88 36 e9 ff 	prefetcht1 -0x16c978(%rip)        # bfb60 <pf_target_14_7>

000000000022c4d8 <pf_jump_14>:
  22c4d8:	e9 d3 2c e7 ff       	jmp    9f1b0 <pf_callee_14>
  22c4dd:	0f 1f 00             	nopl   (%rax)

000000000022c4e0 <pf_call_15>:
  22c4e0:	0f 18 15 f9 44 e9 ff 	prefetcht1 -0x16bb07(%rip)        # c09e0 <pf_target_15_0>
  22c4e7:	0f 18 15 62 20 e7 ff 	prefetcht1 -0x18df9e(%rip)        # 9e550 <pf_callee_4>
  22c4ee:	0f 18 15 0b 45 e9 ff 	prefetcht1 -0x16baf5(%rip)        # c0a00 <pf_target_15_2>
  22c4f5:	0f 18 15 84 43 e7 ff 	prefetcht1 -0x18bc7c(%rip)        # a0880 <pf_target_15_3>
  22c4fc:	0f 18 15 1d e1 ef ff 	prefetcht1 -0x101ee3(%rip)        # 12a620 <pf_target_15_4>
  22c503:	0f 18 15 46 48 e7 ff 	prefetcht1 -0x18b7ba(%rip)        # a0d50 <pf_target_15_5>
  22c50a:	0f 18 15 2f 19 ef ff 	prefetcht1 -0x10e6d1(%rip)        # 11de40 <pf_target_15_6>
  22c511:	0f 18 15 a8 fd ef ff 	prefetcht1 -0x100258(%rip)        # 12c2c0 <pf_target_15_7>

000000000022c518 <pf_jump_15>:
  22c518:	e9 83 50 e7 ff       	jmp    a15a0 <pf_callee_15>
  22c51d:	0f 1f 00             	nopl   (%rax)

000000000022c520 <pf_call_16>:
  22c520:	0f 18 15 69 60 f1 ff 	prefetcht1 -0xe9f97(%rip)        # 142590 <pf_target_16_0>
  22c527:	0f 18 15 94 60 f1 ff 	prefetcht1 -0xe9f6c(%rip)        # 1425c2 <pf_target_16_1>

000000000022c52e <pf_jump_16>:
  22c52e:	e9 ad 41 e7 ff       	jmp    a06e0 <pf_callee_16>
  22c533:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c53a:	00 00 00 
  22c53d:	0f 1f 00             	nopl   (%rax)

000000000022c540 <pf_call_17>:
  22c540:	0f 18 15 c9 f6 f1 ff 	prefetcht1 -0xe0937(%rip)        # 14bc10 <pf_target_17_0>

000000000022c547 <pf_jump_17>:
  22c547:	e9 94 41 e7 ff       	jmp    a06e0 <pf_callee_16>
  22c54c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c550 <pf_call_18>:
  22c550:	0f 18 15 c9 55 ef ff 	prefetcht1 -0x10aa37(%rip)        # 121b20 <pf_target_18_0>

000000000022c557 <pf_jump_18>:
  22c557:	e9 94 5b e7 ff       	jmp    a20f0 <pf_callee_18>
  22c55c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c560 <pf_call_19>:
  22c560:	41 53                	push   %r11
  22c562:	4c 8b 1d cf a6 ff ff 	mov    -0x5931(%rip),%r11        # 226c38 <pf_got_19_0>

000000000022c569 <pf_got_hint_19_0>:
  22c569:	41 0f 18 93 20 95 10 	prefetcht1 0x109520(%r11)
  22c570:	00 
  22c571:	41 5b                	pop    %r11

000000000022c573 <pf_jump_19>:
  22c573:	e9 58 45 e7 ff       	jmp    a0ad0 <pf_callee_19>
  22c578:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  22c57f:	00 

000000000022c580 <pf_call_20>:
  22c580:	0f 18 15 59 41 e7 ff 	prefetcht1 -0x18bea7(%rip)        # a06e0 <pf_callee_16>
  22c587:	0f 18 15 c2 fa f1 ff 	prefetcht1 -0xe053e(%rip)        # 14c050 <pf_target_20_1>
  22c58e:	0f 18 15 ef fa f1 ff 	prefetcht1 -0xe0511(%rip)        # 14c084 <pf_target_20_2>
  22c595:	0f 18 15 d4 23 e8 ff 	prefetcht1 -0x17dc2c(%rip)        # ae970 <pf_target_20_3>
  22c59c:	0f 18 15 6d f6 f1 ff 	prefetcht1 -0xe0993(%rip)        # 14bc10 <pf_target_17_0>
  22c5a3:	0f 18 15 f6 25 e7 ff 	prefetcht1 -0x18da0a(%rip)        # 9eba0 <pf_target_20_5>

000000000022c5aa <pf_jump_20>:
  22c5aa:	e9 21 5a e7 ff       	jmp    a1fd0 <pf_callee_20>
  22c5af:	90                   	nop

000000000022c5b0 <pf_call_21>:
  22c5b0:	41 53                	push   %r11
  22c5b2:	4c 8b 1d 7f a6 ff ff 	mov    -0x5981(%rip),%r11        # 226c38 <pf_got_19_0>

000000000022c5b9 <pf_got_hint_21_0>:
  22c5b9:	41 0f 18 93 c0 cd 10 	prefetcht1 0x10cdc0(%r11)
  22c5c0:	00 
  22c5c1:	41 5b                	pop    %r11

000000000022c5c3 <pf_jump_21>:
  22c5c3:	e9 e8 35 e7 ff       	jmp    9fbb0 <pf_callee_21>
