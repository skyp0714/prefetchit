
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_repair/7242d32f52f35ec9c5164e928ad51bf40e039f0572f3b4e26ac43ec1ce20d0d7/call-stub-7196fmyc/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000312c0 <pf_call_0>:
   312c0:	0f 18 15 a9 5c fd ff 	prefetcht1 -0x2a357(%rip)        # 6f70 <pf_callee_17>
   312c7:	0f 18 15 e2 44 fe ff 	prefetcht1 -0x1bb1e(%rip)        # 157b0 <pf_callee_32>
   312ce:	0f 18 15 db e8 fd ff 	prefetcht1 -0x21725(%rip)        # fbb0 <pf_callee_20>
   312d5:	0f 18 15 25 e9 fd ff 	prefetcht1 -0x216db(%rip)        # fc01 <pf_target_0_3>
   312dc:	0f 18 15 dd e8 fd ff 	prefetcht1 -0x21723(%rip)        # fbc0 <pf_target_0_4>
   312e3:	0f 18 15 dc 44 fe ff 	prefetcht1 -0x1bb24(%rip)        # 157c6 <pf_target_0_5>

00000000000312ea <pf_jump_0>:
   312ea:	e9 81 41 fd ff       	jmp    5470 <pf_callee_0>
   312ef:	90                   	nop

00000000000312f0 <pf_call_1>:
   312f0:	0f 18 15 e9 a9 fd ff 	prefetcht1 -0x25617(%rip)        # bce0 <pf_target_1_0>
   312f7:	0f 18 15 32 a4 fd ff 	prefetcht1 -0x25bce(%rip)        # b730 <pf_target_1_1>
   312fe:	0f 18 15 6b 41 fd ff 	prefetcht1 -0x2be95(%rip)        # 5470 <pf_callee_0>
   31305:	0f 18 15 64 40 fe ff 	prefetcht1 -0x1bf9c(%rip)        # 15370 <pf_target_1_3>

000000000003130c <pf_jump_1>:
   3130c:	e9 ff 42 fd ff       	jmp    5610 <pf_callee_1>
   31311:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31318:	00 00 00 
   3131b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031320 <pf_call_2>:
   31320:	0f 18 15 9e a6 fd ff 	prefetcht1 -0x25962(%rip)        # b9c5 <pf_target_2_0>
   31327:	0f 18 15 e2 42 fd ff 	prefetcht1 -0x2bd1e(%rip)        # 5610 <pf_callee_1>
   3132e:	0f 18 15 2b a6 fd ff 	prefetcht1 -0x259d5(%rip)        # b960 <pf_callee_11>

0000000000031335 <pf_jump_2>:
   31335:	e9 26 d5 fe ff       	jmp    1e860 <pf_callee_10>
   3133a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031340 <pf_call_3>:
   31340:	0f 18 15 29 41 fd ff 	prefetcht1 -0x2bed7(%rip)        # 5470 <pf_callee_0>

0000000000031347 <pf_jump_3>:
   31347:	e9 14 a6 fd ff       	jmp    b960 <pf_callee_11>
   3134c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031350 <pf_call_4>:
   31350:	0f 18 15 19 f6 fd ff 	prefetcht1 -0x209e7(%rip)        # 10970 <pf_target_4_0>
   31357:	0f 18 15 5a 2d fe ff 	prefetcht1 -0x1d2a6(%rip)        # 140b8 <pf_target_27_4>
   3135e:	0f 18 15 fb 7b fe ff 	prefetcht1 -0x18405(%rip)        # 18f60 <pf_target_24_4>
   31365:	0f 18 15 10 7a fe ff 	prefetcht1 -0x185f0(%rip)        # 18d7c <pf_target_24_2>
   3136c:	0f 18 15 05 b4 fd ff 	prefetcht1 -0x24bfb(%rip)        # c778 <pf_target_4_4>
   31373:	0f 18 15 06 f6 fd ff 	prefetcht1 -0x209fa(%rip)        # 10980 <pf_target_4_5>
   3137a:	0f 18 15 56 2b fe ff 	prefetcht1 -0x1d4aa(%rip)        # 13ed7 <pf_target_24_0>
   31381:	0f 18 15 ff 79 fe ff 	prefetcht1 -0x18601(%rip)        # 18d87 <pf_target_24_3>

0000000000031388 <pf_jump_4>:
   31388:	e9 83 42 fd ff       	jmp    5610 <pf_callee_1>
   3138d:	0f 1f 00             	nopl   (%rax)

0000000000031390 <pf_call_5>:
   31390:	0f 18 15 ea 26 fe ff 	prefetcht1 -0x1d916(%rip)        # 13a81 <pf_target_5_0>
   31397:	0f 18 15 6a b2 fd ff 	prefetcht1 -0x24d96(%rip)        # c608 <pf_target_5_1>
   3139e:	0f 18 15 5d 1f fe ff 	prefetcht1 -0x1e0a3(%rip)        # 13302 <pf_target_5_2>
   313a5:	0f 18 15 d4 1f fe ff 	prefetcht1 -0x1e02c(%rip)        # 13380 <pf_target_5_3>

00000000000313ac <pf_jump_5>:
   313ac:	e9 2f 41 fd ff       	jmp    54e0 <pf_callee_5>
   313b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   313b8:	00 00 00 
   313bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000313c0 <pf_call_6>:
   313c0:	0f 18 15 cf 5b fd ff 	prefetcht1 -0x2a431(%rip)        # 6f96 <pf_target_6_0>
   313c7:	0f 18 15 f3 5b fd ff 	prefetcht1 -0x2a40d(%rip)        # 6fc1 <pf_target_6_1>
   313ce:	0f 18 15 36 f5 fd ff 	prefetcht1 -0x20aca(%rip)        # 1090b <pf_target_6_2>
   313d5:	0f 18 15 e5 2c fe ff 	prefetcht1 -0x1d31b(%rip)        # 140c1 <pf_target_6_3>

00000000000313dc <pf_jump_6>:
   313dc:	e9 df b1 fd ff       	jmp    c5c0 <pf_callee_6>
   313e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   313e8:	00 00 00 
   313eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000313f0 <pf_call_7>:
   313f0:	0f 18 15 0d a6 fd ff 	prefetcht1 -0x259f3(%rip)        # ba04 <pf_target_7_0>

00000000000313f7 <pf_jump_7>:
   313f7:	e9 f4 3d fe ff       	jmp    151f0 <pf_callee_12>
   313fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031400 <pf_call_8>:
   31400:	0f 18 15 a5 d7 fd ff 	prefetcht1 -0x2285b(%rip)        # ebac <pf_target_8_0>
   31407:	0f 18 15 11 e1 fd ff 	prefetcht1 -0x21eef(%rip)        # f51f <pf_target_8_1>

000000000003140e <pf_jump_8>:
   3140e:	e9 3d d0 fd ff       	jmp    e450 <pf_callee_16>
   31413:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3141a:	00 00 00 
   3141d:	0f 1f 00             	nopl   (%rax)

0000000000031420 <pf_call_9>:
   31420:	0f 18 15 f8 e0 fd ff 	prefetcht1 -0x21f08(%rip)        # f51f <pf_target_8_1>
   31427:	0f 18 15 22 ca fd ff 	prefetcht1 -0x235de(%rip)        # de50 <pf_callee_13>
   3142e:	0f 18 15 4c d4 fe ff 	prefetcht1 -0x12bb4(%rip)        # 1e881 <pf_target_35_5>
   31435:	0f 18 15 24 d4 fe ff 	prefetcht1 -0x12bdc(%rip)        # 1e860 <pf_callee_10>
   3143c:	0f 18 15 40 83 fd ff 	prefetcht1 -0x27cc0(%rip)        # 9783 <pf_target_33_3>
   31443:	0f 18 15 37 ca fd ff 	prefetcht1 -0x235c9(%rip)        # de81 <pf_target_33_7>

000000000003144a <pf_jump_9>:
   3144a:	e9 01 d0 fd ff       	jmp    e450 <pf_callee_16>
   3144f:	90                   	nop

0000000000031450 <pf_call_10>:
   31450:	0f 18 15 19 e0 fd ff 	prefetcht1 -0x21fe7(%rip)        # f470 <pf_target_10_0>
   31457:	0f 18 15 b2 41 fd ff 	prefetcht1 -0x2be4e(%rip)        # 5610 <pf_callee_1>
   3145e:	0f 18 15 72 e0 fd ff 	prefetcht1 -0x21f8e(%rip)        # f4d7 <pf_target_10_2>

0000000000031465 <pf_jump_10>:
   31465:	e9 f6 d3 fe ff       	jmp    1e860 <pf_callee_10>
   3146a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031470 <pf_call_11>:
   31470:	0f 18 15 c0 de fd ff 	prefetcht1 -0x22140(%rip)        # f337 <pf_target_11_0>
   31477:	0f 18 15 ea de fd ff 	prefetcht1 -0x22116(%rip)        # f368 <pf_target_11_1>

000000000003147e <pf_jump_11>:
   3147e:	e9 dd a4 fd ff       	jmp    b960 <pf_callee_11>
   31483:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3148a:	00 00 00 
   3148d:	0f 1f 00             	nopl   (%rax)

0000000000031490 <pf_call_12>:
   31490:	0f 18 15 e9 e4 fd ff 	prefetcht1 -0x21b17(%rip)        # f980 <pf_target_12_0>
   31497:	0f 18 15 22 e5 fd ff 	prefetcht1 -0x21ade(%rip)        # f9c0 <pf_target_12_1>
   3149e:	0f 18 15 0b e7 fd ff 	prefetcht1 -0x218f5(%rip)        # fbb0 <pf_callee_20>
   314a5:	0f 18 15 55 e7 fd ff 	prefetcht1 -0x218ab(%rip)        # fc01 <pf_target_0_3>

00000000000314ac <pf_jump_12>:
   314ac:	e9 3f 3d fe ff       	jmp    151f0 <pf_callee_12>
   314b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   314b8:	00 00 00 
   314bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000314c0 <pf_call_13>:
   314c0:	0f 18 15 10 e0 fd ff 	prefetcht1 -0x21ff0(%rip)        # f4d7 <pf_target_10_2>

00000000000314c7 <pf_jump_13>:
   314c7:	e9 84 c9 fd ff       	jmp    de50 <pf_callee_13>
   314cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000314d0 <pf_call_14>:
   314d0:	0f 18 15 39 3b fe ff 	prefetcht1 -0x1c4c7(%rip)        # 15010 <pf_target_14_0>
   314d7:	0f 18 15 6a 1b fe ff 	prefetcht1 -0x1e496(%rip)        # 13048 <pf_target_14_1>
   314de:	0f 18 15 4b 1b fe ff 	prefetcht1 -0x1e4b5(%rip)        # 13030 <pf_callee_29>
   314e5:	41 53                	push   %r11
   314e7:	4c 8b 1d fa eb ff ff 	mov    -0x1406(%rip),%r11        # 300e8 <pf_got_14_0>

00000000000314ee <pf_got_hint_14_0>:
   314ee:	41 0f 18 93 0a ce 00 	prefetcht1 0xce0a(%r11)
   314f5:	00 

00000000000314f6 <pf_got_hint_14_1>:
   314f6:	41 0f 18 93 dd cf 00 	prefetcht1 0xcfdd(%r11)
   314fd:	00 

00000000000314fe <pf_got_hint_14_2>:
   314fe:	41 0f 18 93 13 d0 00 	prefetcht1 0xd013(%r11)
   31505:	00 

0000000000031506 <pf_got_hint_14_3>:
   31506:	41 0f 18 93 41 d0 00 	prefetcht1 0xd041(%r11)
   3150d:	00 

000000000003150e <pf_got_hint_14_4>:
   3150e:	41 0f 18 93 f0 d1 00 	prefetcht1 0xd1f0(%r11)
   31515:	00 
   31516:	41 5b                	pop    %r11

0000000000031518 <pf_jump_14>:
   31518:	e9 13 40 fd ff       	jmp    5530 <pf_callee_14>
   3151d:	0f 1f 00             	nopl   (%rax)

0000000000031520 <pf_call_15>:
   31520:	0f 18 15 29 cf fd ff 	prefetcht1 -0x230d7(%rip)        # e450 <pf_callee_16>
   31527:	0f 18 15 a0 76 fe ff 	prefetcht1 -0x18960(%rip)        # 18bce <pf_target_15_1>
   3152e:	0f 18 15 4e cf fd ff 	prefetcht1 -0x230b2(%rip)        # e483 <pf_target_15_2>
   31535:	0f 18 15 2e 77 fe ff 	prefetcht1 -0x188d2(%rip)        # 18c6a <pf_target_15_3>
   3153c:	0f 18 15 1a d0 fd ff 	prefetcht1 -0x22fe6(%rip)        # e55d <pf_target_15_4>

0000000000031543 <pf_jump_15>:
   31543:	e9 38 1d fe ff       	jmp    13280 <pf_callee_15>
   31548:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   3154f:	00 

0000000000031550 <pf_call_16>:
   31550:	0f 18 15 2a aa fd ff 	prefetcht1 -0x255d6(%rip)        # bf81 <pf_target_16_0>
   31557:	0f 18 15 d2 a9 fd ff 	prefetcht1 -0x2562e(%rip)        # bf30 <pf_target_16_1>
   3155e:	0f 18 15 60 f3 fd ff 	prefetcht1 -0x20ca0(%rip)        # 108c5 <pf_target_16_2>
   31565:	0f 18 15 d5 a9 fd ff 	prefetcht1 -0x2562b(%rip)        # bf41 <pf_target_16_3>

000000000003156c <pf_jump_16>:
   3156c:	e9 df ce fd ff       	jmp    e450 <pf_callee_16>
   31571:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31578:	00 00 00 
   3157b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031580 <pf_call_17>:
   31580:	0f 18 15 c9 52 fe ff 	prefetcht1 -0x1ad37(%rip)        # 16850 <pf_target_17_0>
   31587:	0f 18 15 f4 52 fe ff 	prefetcht1 -0x1ad0c(%rip)        # 16882 <pf_target_17_1>
   3158e:	0f 18 15 8e 5a fd ff 	prefetcht1 -0x2a572(%rip)        # 7023 <pf_target_17_2>

0000000000031595 <pf_jump_17>:
   31595:	e9 d6 59 fd ff       	jmp    6f70 <pf_callee_17>
   3159a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000315a0 <pf_call_18>:
   315a0:	0f 18 15 e9 f0 fd ff 	prefetcht1 -0x20f17(%rip)        # 10690 <pf_callee_19>

00000000000315a7 <pf_jump_18>:
   315a7:	e9 c4 f1 fd ff       	jmp    10770 <pf_callee_18>
   315ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000315b0 <pf_call_19>:
   315b0:	0f 18 15 8b d1 fd ff 	prefetcht1 -0x22e75(%rip)        # e742 <pf_target_19_0>
   315b7:	0f 18 15 32 d1 fd ff 	prefetcht1 -0x22ece(%rip)        # e6f0 <pf_target_19_1>
   315be:	0f 18 15 bb 1c fe ff 	prefetcht1 -0x1e345(%rip)        # 13280 <pf_callee_15>
   315c5:	0f 18 15 38 d1 fd ff 	prefetcht1 -0x22ec8(%rip)        # e704 <pf_target_19_3>
   315cc:	0f 18 15 b0 ce fd ff 	prefetcht1 -0x23150(%rip)        # e483 <pf_target_15_2>
   315d3:	0f 18 15 16 3c fe ff 	prefetcht1 -0x1c3ea(%rip)        # 151f0 <pf_callee_12>

00000000000315da <pf_jump_19>:
   315da:	e9 b1 f0 fd ff       	jmp    10690 <pf_callee_19>
   315df:	90                   	nop

00000000000315e0 <pf_call_20>:
   315e0:	0f 18 15 99 6c fe ff 	prefetcht1 -0x19367(%rip)        # 18280 <pf_target_20_0>
   315e7:	0f 18 15 92 e3 fd ff 	prefetcht1 -0x21c6e(%rip)        # f980 <pf_target_12_0>
   315ee:	0f 18 15 cb e3 fd ff 	prefetcht1 -0x21c35(%rip)        # f9c0 <pf_target_12_1>

00000000000315f5 <pf_jump_20>:
   315f5:	e9 b6 e5 fd ff       	jmp    fbb0 <pf_callee_20>
   315fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031600 <pf_call_21>:
   31600:	0f 18 15 89 f0 fd ff 	prefetcht1 -0x20f77(%rip)        # 10690 <pf_callee_19>

0000000000031607 <pf_jump_21>:
   31607:	e9 24 04 fe ff       	jmp    11a30 <pf_callee_21>
   3160c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031610 <pf_call_22>:
   31610:	41 53                	push   %r11
   31612:	4c 8b 1d cf ea ff ff 	mov    -0x1531(%rip),%r11        # 300e8 <pf_got_14_0>

0000000000031619 <pf_got_hint_22_0>:
   31619:	41 0f 18 93 20 e8 f6 	prefetcht1 -0x917e0(%r11)
   31620:	ff 
   31621:	41 5b                	pop    %r11

0000000000031623 <pf_jump_22>:
   31623:	e9 28 41 fd ff       	jmp    5750 <pf_callee_22>
   31628:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   3162f:	00 

0000000000031630 <pf_call_23>:
   31630:	0f 18 15 c9 94 fd ff 	prefetcht1 -0x26b37(%rip)        # ab00 <pf_target_23_0>
   31637:	0f 18 15 06 95 fd ff 	prefetcht1 -0x26afa(%rip)        # ab44 <pf_target_23_1>
   3163e:	0f 18 15 87 b1 fd ff 	prefetcht1 -0x24e79(%rip)        # c7cc <pf_target_23_2>
   31645:	0f 18 15 b5 af fd ff 	prefetcht1 -0x2504b(%rip)        # c601 <pf_target_23_3>

000000000003164c <pf_jump_23>:
   3164c:	e9 2f b2 fd ff       	jmp    c880 <pf_callee_23>
   31651:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31658:	00 00 00 
   3165b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031660 <pf_call_24>:
   31660:	0f 18 15 70 28 fe ff 	prefetcht1 -0x1d790(%rip)        # 13ed7 <pf_target_24_0>
   31667:	0f 18 15 54 23 fe ff 	prefetcht1 -0x1dcac(%rip)        # 139c2 <pf_target_24_1>
   3166e:	0f 18 15 07 77 fe ff 	prefetcht1 -0x188f9(%rip)        # 18d7c <pf_target_24_2>
   31675:	0f 18 15 0b 77 fe ff 	prefetcht1 -0x188f5(%rip)        # 18d87 <pf_target_24_3>
   3167c:	0f 18 15 dd 78 fe ff 	prefetcht1 -0x18723(%rip)        # 18f60 <pf_target_24_4>
   31683:	0f 18 15 f8 7b fe ff 	prefetcht1 -0x18408(%rip)        # 19282 <pf_target_24_5>

000000000003168a <pf_jump_24>:
   3168a:	e9 f1 b1 fd ff       	jmp    c880 <pf_callee_23>
   3168f:	90                   	nop

0000000000031690 <pf_call_25>:
   31690:	0f 18 15 29 af fd ff 	prefetcht1 -0x250d7(%rip)        # c5c0 <pf_callee_6>

0000000000031697 <pf_jump_25>:
   31697:	e9 e4 1b fe ff       	jmp    13280 <pf_callee_15>
   3169c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000316a0 <pf_call_26>:
   316a0:	0f 18 15 29 54 fd ff 	prefetcht1 -0x2abd7(%rip)        # 6ad0 <pf_target_26_0>
   316a7:	0f 18 15 73 24 fe ff 	prefetcht1 -0x1db8d(%rip)        # 13b21 <pf_target_26_1>
   316ae:	41 53                	push   %r11
   316b0:	4c 8b 1d 31 ea ff ff 	mov    -0x15cf(%rip),%r11        # 300e8 <pf_got_14_0>

00000000000316b7 <pf_got_hint_26_0>:
   316b7:	41 0f 18 93 80 ee ef 	prefetcht1 -0x101180(%r11)
   316be:	ff 
   316bf:	41 5b                	pop    %r11

00000000000316c1 <pf_jump_26>:
   316c1:	e9 ba b1 fd ff       	jmp    c880 <pf_callee_23>
   316c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   316cd:	00 00 00 

00000000000316d0 <pf_call_27>:
   316d0:	0f 18 15 59 19 fe ff 	prefetcht1 -0x1e6a7(%rip)        # 13030 <pf_callee_29>
   316d7:	0f 18 15 32 39 fe ff 	prefetcht1 -0x1c6ce(%rip)        # 15010 <pf_target_14_0>
   316de:	0f 18 15 9f 19 fe ff 	prefetcht1 -0x1e661(%rip)        # 13084 <pf_target_27_2>
   316e5:	0f 18 15 5c 19 fe ff 	prefetcht1 -0x1e6a4(%rip)        # 13048 <pf_target_14_1>
   316ec:	0f 18 15 c5 29 fe ff 	prefetcht1 -0x1d63b(%rip)        # 140b8 <pf_target_27_4>
   316f3:	0f 18 15 1d e3 fd ff 	prefetcht1 -0x21ce3(%rip)        # fa17 <pf_target_27_5>
   316fa:	41 53                	push   %r11
   316fc:	4c 8b 1d e5 e9 ff ff 	mov    -0x161b(%rip),%r11        # 300e8 <pf_got_14_0>

0000000000031703 <pf_got_hint_27_0>:
   31703:	41 0f 18 93 f0 ca 00 	prefetcht1 0xcaf0(%r11)
   3170a:	00 

000000000003170b <pf_got_hint_27_1>:
   3170b:	41 0f 18 93 00 cb 00 	prefetcht1 0xcb00(%r11)
   31712:	00 
   31713:	41 5b                	pop    %r11

0000000000031715 <pf_jump_27>:
   31715:	e9 66 b1 fd ff       	jmp    c880 <pf_callee_23>
   3171a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031720 <pf_call_28>:
   31720:	0f 18 15 31 59 fd ff 	prefetcht1 -0x2a6cf(%rip)        # 7058 <pf_target_28_0>
   31727:	0f 18 15 68 51 fe ff 	prefetcht1 -0x1ae98(%rip)        # 16896 <pf_target_28_1>

000000000003172e <pf_jump_28>:
   3172e:	e9 4d b1 fd ff       	jmp    c880 <pf_callee_23>
   31733:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3173a:	00 00 00 
   3173d:	0f 1f 00             	nopl   (%rax)

0000000000031740 <pf_call_29>:
   31740:	0f 18 15 3e 04 fe ff 	prefetcht1 -0x1fbc2(%rip)        # 11b85 <pf_target_29_0>

0000000000031747 <pf_jump_29>:
   31747:	e9 e4 18 fe ff       	jmp    13030 <pf_callee_29>
   3174c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031750 <pf_call_30>:
   31750:	0f 18 15 2e 3f fe ff 	prefetcht1 -0x1c0d2(%rip)        # 15685 <pf_target_30_0>
   31757:	0f 18 15 64 27 fe ff 	prefetcht1 -0x1d89c(%rip)        # 13ec2 <pf_target_30_1>

000000000003175e <pf_jump_30>:
   3175e:	e9 fd a1 fd ff       	jmp    b960 <pf_callee_11>
   31763:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3176a:	00 00 00 
   3176d:	0f 1f 00             	nopl   (%rax)

0000000000031770 <pf_call_31>:
   31770:	0f 18 15 09 b1 fd ff 	prefetcht1 -0x24ef7(%rip)        # c880 <pf_callee_23>
   31777:	0f 18 15 42 b1 fd ff 	prefetcht1 -0x24ebe(%rip)        # c8c0 <pf_target_31_1>
   3177e:	0f 18 15 fb 26 fe ff 	prefetcht1 -0x1d905(%rip)        # 13e80 <pf_target_31_2>
   31785:	0f 18 15 34 ae fd ff 	prefetcht1 -0x251cc(%rip)        # c5c0 <pf_callee_6>

000000000003178c <pf_jump_31>:
   3178c:	e9 5f 3a fe ff       	jmp    151f0 <pf_callee_12>
   31791:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31798:	00 00 00 
   3179b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000317a0 <pf_call_32>:
   317a0:	0f 18 15 19 ae fd ff 	prefetcht1 -0x251e7(%rip)        # c5c0 <pf_callee_6>
   317a7:	0f 18 15 d2 b0 fd ff 	prefetcht1 -0x24f2e(%rip)        # c880 <pf_callee_23>
   317ae:	0f 18 15 cb 26 fe ff 	prefetcht1 -0x1d935(%rip)        # 13e80 <pf_target_31_2>
   317b5:	0f 18 15 04 b1 fd ff 	prefetcht1 -0x24efc(%rip)        # c8c0 <pf_target_31_1>

00000000000317bc <pf_jump_32>:
   317bc:	e9 ef 3f fe ff       	jmp    157b0 <pf_callee_32>
   317c1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   317c8:	00 00 00 
   317cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000317d0 <pf_call_33>:
   317d0:	0f 18 15 79 c6 fd ff 	prefetcht1 -0x23987(%rip)        # de50 <pf_callee_13>
   317d7:	0f 18 15 a2 1a fe ff 	prefetcht1 -0x1e55e(%rip)        # 13280 <pf_callee_15>
   317de:	0f 18 15 83 c7 fd ff 	prefetcht1 -0x2387d(%rip)        # df68 <pf_target_33_2>
   317e5:	0f 18 15 97 7f fd ff 	prefetcht1 -0x28069(%rip)        # 9783 <pf_target_33_3>
   317ec:	0f 18 15 7d 7f fd ff 	prefetcht1 -0x28083(%rip)        # 9770 <pf_target_33_4>
   317f3:	0f 18 15 f6 39 fe ff 	prefetcht1 -0x1c60a(%rip)        # 151f0 <pf_callee_12>
   317fa:	0f 18 15 ff 77 fe ff 	prefetcht1 -0x18801(%rip)        # 19000 <pf_target_33_6>
   31801:	0f 18 15 79 c6 fd ff 	prefetcht1 -0x23987(%rip)        # de81 <pf_target_33_7>

0000000000031808 <pf_jump_33>:
   31808:	e9 83 ee fd ff       	jmp    10690 <pf_callee_19>
   3180d:	0f 1f 00             	nopl   (%rax)

0000000000031810 <pf_call_34>:
   31810:	0f 18 15 a9 d0 fe ff 	prefetcht1 -0x12f57(%rip)        # 1e8c0 <pf_target_34_0>

0000000000031817 <pf_jump_34>:
   31817:	e9 34 cc fd ff       	jmp    e450 <pf_callee_16>
   3181c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031820 <pf_call_35>:
   31820:	0f 18 15 09 73 fe ff 	prefetcht1 -0x18cf7(%rip)        # 18b30 <pf_target_35_0>
   31827:	0f 18 15 54 73 fe ff 	prefetcht1 -0x18cac(%rip)        # 18b82 <pf_target_35_1>
   3182e:	0f 18 15 8b a2 fd ff 	prefetcht1 -0x25d75(%rip)        # bac0 <pf_target_35_2>
   31835:	0f 18 15 e4 74 fe ff 	prefetcht1 -0x18b1c(%rip)        # 18d20 <pf_target_35_3>
   3183c:	0f 18 15 1d d0 fe ff 	prefetcht1 -0x12fe3(%rip)        # 1e860 <pf_callee_10>
   31843:	0f 18 15 37 d0 fe ff 	prefetcht1 -0x12fc9(%rip)        # 1e881 <pf_target_35_5>
   3184a:	0f 18 15 f1 72 fe ff 	prefetcht1 -0x18d0f(%rip)        # 18b42 <pf_target_35_6>
   31851:	0f 18 15 ea 74 fe ff 	prefetcht1 -0x18b16(%rip)        # 18d42 <pf_target_35_7>

0000000000031858 <pf_jump_35>:
   31858:	e9 f3 c5 fd ff       	jmp    de50 <pf_callee_13>
   3185d:	0f 1f 00             	nopl   (%rax)

0000000000031860 <pf_call_36>:
   31860:	0f 18 15 29 ee fd ff 	prefetcht1 -0x211d7(%rip)        # 10690 <pf_callee_19>

0000000000031867 <pf_jump_36>:
   31867:	e9 84 76 fe ff       	jmp    18ef0 <pf_callee_36>
   3186c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031870 <pf_call_37>:
   31870:	0f 18 15 31 d7 fe ff 	prefetcht1 -0x128cf(%rip)        # 1efa8 <pf_target_37_0>
   31877:	0f 18 15 f2 d6 fe ff 	prefetcht1 -0x1290e(%rip)        # 1ef70 <pf_target_37_1>
   3187e:	0f 18 15 41 d7 fe ff 	prefetcht1 -0x128bf(%rip)        # 1efc6 <pf_target_37_2>

0000000000031885 <pf_jump_37>:
   31885:	e9 56 3f fd ff       	jmp    57e0 <pf_callee_37>
   3188a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031890 <pf_call_38>:
   31890:	0f 18 15 ea d7 fe ff 	prefetcht1 -0x12816(%rip)        # 1f081 <pf_target_38_0>
   31897:	0f 18 15 72 e1 fe ff 	prefetcht1 -0x11e8e(%rip)        # 1fa10 <pf_target_38_1>
   3189e:	0f 18 15 b1 d7 fe ff 	prefetcht1 -0x1284f(%rip)        # 1f056 <pf_target_38_2>

00000000000318a5 <pf_jump_38>:
   318a5:	e9 c6 3b fd ff       	jmp    5470 <pf_callee_0>
   318aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000318b0 <pf_call_39>:
   318b0:	0f 18 15 ca a1 fd ff 	prefetcht1 -0x25e36(%rip)        # ba81 <pf_target_39_0>

00000000000318b7 <pf_jump_39>:
   318b7:	e9 f4 3e fd ff       	jmp    57b0 <pf_callee_39>
   318bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000318c0 <pf_call_40>:
   318c0:	41 53                	push   %r11
   318c2:	4c 8b 1d 1f e8 ff ff 	mov    -0x17e1(%rip),%r11        # 300e8 <pf_got_14_0>

00000000000318c9 <pf_got_hint_40_0>:
   318c9:	41 0f 18 93 f0 0c f8 	prefetcht1 -0x7f310(%r11)
   318d0:	ff 
   318d1:	41 5b                	pop    %r11

00000000000318d3 <pf_jump_40>:
   318d3:	e9 68 3f fd ff       	jmp    5840 <pf_callee_40>
