
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_repair/beee2b363cdd95391e3db419aeccb36e2dd16c7f8b7f4c3f560bd878fc4c6e7b/call-stub-acdnhh1b/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000110340 <pf_call_0>:
  110340:	0f 18 15 e9 88 f3 ff 	prefetcht1 -0xc7717(%rip)        # 48c30 <pf_target_0_0>
  110347:	0f 18 15 62 31 f3 ff 	prefetcht1 -0xcce9e(%rip)        # 434b0 <pf_target_0_1>
  11034e:	0f 18 15 af 31 f3 ff 	prefetcht1 -0xcce51(%rip)        # 43504 <pf_target_0_2>
  110355:	0f 18 15 c4 3b f3 ff 	prefetcht1 -0xcc43c(%rip)        # 43f20 <pf_target_0_3>
  11035c:	0f 18 15 a1 3c f3 ff 	prefetcht1 -0xcc35f(%rip)        # 44004 <pf_target_0_4>
  110363:	0f 18 15 d8 88 f3 ff 	prefetcht1 -0xc7728(%rip)        # 48c42 <pf_target_0_5>
  11036a:	0f 18 15 11 89 f3 ff 	prefetcht1 -0xc76ef(%rip)        # 48c82 <pf_target_0_6>
  110371:	0f 18 15 4a 32 f3 ff 	prefetcht1 -0xccdb6(%rip)        # 435c2 <pf_target_0_7>

0000000000110378 <pf_jump_0>:
  110378:	e9 a3 5f f1 ff       	jmp    26320 <pf_callee_0>
  11037d:	0f 1f 00             	nopl   (%rax)

0000000000110380 <pf_call_1>:
  110380:	0f 18 15 19 06 f2 ff 	prefetcht1 -0xdf9e7(%rip)        # 309a0 <pf_target_1_0>
  110387:	0f 18 15 32 06 f2 ff 	prefetcht1 -0xdf9ce(%rip)        # 309c0 <pf_target_1_1>
  11038e:	41 53                	push   %r11
  110390:	4c 8b 1d 09 dd ff ff 	mov    -0x22f7(%rip),%r11        # 10e0a0 <pf_got_10_0>

0000000000110397 <pf_got_hint_1_0>:
  110397:	41 0f 18 93 00 24 00 	prefetcht1 0x2400(%r11)
  11039e:	00 

000000000011039f <pf_got_hint_1_1>:
  11039f:	41 0f 18 93 22 24 00 	prefetcht1 0x2422(%r11)
  1103a6:	00 
  1103a7:	4c 8b 1d e2 dd ff ff 	mov    -0x221e(%rip),%r11        # 10e190 <pf_got_17_3>

00000000001103ae <pf_got_hint_1_2>:
  1103ae:	41 0f 18 93 60 ec f2 	prefetcht1 -0xd13a0(%r11)
  1103b5:	ff 
  1103b6:	41 5b                	pop    %r11

00000000001103b8 <pf_jump_1>:
  1103b8:	e9 63 5f f1 ff       	jmp    26320 <pf_callee_0>
  1103bd:	0f 1f 00             	nopl   (%rax)

00000000001103c0 <pf_call_2>:
  1103c0:	41 53                	push   %r11
  1103c2:	4c 8b 1d d7 dc ff ff 	mov    -0x2329(%rip),%r11        # 10e0a0 <pf_got_10_0>

00000000001103c9 <pf_got_hint_2_0>:
  1103c9:	41 0f 18 93 30 7d 09 	prefetcht1 0x97d30(%r11)
  1103d0:	00 

00000000001103d1 <pf_got_hint_2_1>:
  1103d1:	41 0f 18 93 64 7d 09 	prefetcht1 0x97d64(%r11)
  1103d8:	00 
  1103d9:	4c 8b 1d b0 dd ff ff 	mov    -0x2250(%rip),%r11        # 10e190 <pf_got_17_3>

00000000001103e0 <pf_got_hint_2_2>:
  1103e0:	41 0f 18 93 a0 08 f5 	prefetcht1 -0xaf760(%r11)
  1103e7:	ff 
  1103e8:	41 5b                	pop    %r11

00000000001103ea <pf_jump_2>:
  1103ea:	e9 31 5f f1 ff       	jmp    26320 <pf_callee_0>
  1103ef:	90                   	nop

00000000001103f0 <pf_call_3>:
  1103f0:	0f 18 15 09 8c f5 ff 	prefetcht1 -0xa73f7(%rip)        # 69000 <pf_target_3_0>
  1103f7:	0f 18 15 d2 bd f4 ff 	prefetcht1 -0xb422e(%rip)        # 5c1d0 <pf_target_3_1>

00000000001103fe <pf_jump_3>:
  1103fe:	e9 cd 06 f2 ff       	jmp    30ad0 <pf_callee_3>
  110403:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11040a:	00 00 00 
  11040d:	0f 1f 00             	nopl   (%rax)

0000000000110410 <pf_call_4>:
  110410:	41 53                	push   %r11
  110412:	4c 8b 1d 77 dd ff ff 	mov    -0x2289(%rip),%r11        # 10e190 <pf_got_17_3>

0000000000110419 <pf_got_hint_4_0>:
  110419:	41 0f 18 93 11 3f f4 	prefetcht1 -0xbc0ef(%r11)
  110420:	ff 
  110421:	41 5b                	pop    %r11

0000000000110423 <pf_jump_4>:
  110423:	e9 58 6a f1 ff       	jmp    26e80 <pf_callee_4>
  110428:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11042f:	00 

0000000000110430 <pf_call_5>:
  110430:	0f 18 15 2f 95 f3 ff 	prefetcht1 -0xc6ad1(%rip)        # 49966 <pf_target_5_0>
  110437:	41 53                	push   %r11
  110439:	4c 8b 1d 50 dd ff ff 	mov    -0x22b0(%rip),%r11        # 10e190 <pf_got_17_3>

0000000000110440 <pf_got_hint_5_0>:
  110440:	41 0f 18 93 80 84 f4 	prefetcht1 -0xb7b80(%r11)
  110447:	ff 

0000000000110448 <pf_got_hint_5_1>:
  110448:	41 0f 18 93 91 84 f4 	prefetcht1 -0xb7b6f(%r11)
  11044f:	ff 
  110450:	41 5b                	pop    %r11

0000000000110452 <pf_jump_5>:
  110452:	e9 59 94 f3 ff       	jmp    498b0 <pf_callee_5>
  110457:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  11045e:	00 00 

0000000000110460 <pf_call_6>:
  110460:	0f 18 15 f9 bd f4 ff 	prefetcht1 -0xb4207(%rip)        # 5c260 <pf_target_6_0>
  110467:	41 53                	push   %r11
  110469:	4c 8b 1d 30 dc ff ff 	mov    -0x23d0(%rip),%r11        # 10e0a0 <pf_got_10_0>

0000000000110470 <pf_got_hint_6_0>:
  110470:	41 0f 18 93 c0 86 02 	prefetcht1 0x286c0(%r11)
  110477:	00 
  110478:	41 5b                	pop    %r11

000000000011047a <pf_jump_6>:
  11047a:	e9 91 5e f1 ff       	jmp    26310 <pf_callee_6>
  11047f:	90                   	nop

0000000000110480 <pf_call_7>:
  110480:	0f 18 15 79 31 f3 ff 	prefetcht1 -0xcce87(%rip)        # 43600 <pf_target_7_0>

0000000000110487 <pf_jump_7>:
  110487:	e9 34 5d f1 ff       	jmp    261c0 <pf_callee_7>
  11048c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110490 <pf_call_8>:
  110490:	41 53                	push   %r11
  110492:	4c 8b 1d f7 dc ff ff 	mov    -0x2309(%rip),%r11        # 10e190 <pf_got_17_3>

0000000000110499 <pf_got_hint_8_0>:
  110499:	41 0f 18 93 70 fe f2 	prefetcht1 -0xd0190(%r11)
  1104a0:	ff 
  1104a1:	41 5b                	pop    %r11

00000000001104a3 <pf_jump_8>:
  1104a3:	e9 a8 37 f3 ff       	jmp    43c50 <pf_callee_8>
  1104a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1104af:	00 

00000000001104b0 <pf_call_9>:
  1104b0:	41 53                	push   %r11
  1104b2:	4c 8b 1d e7 db ff ff 	mov    -0x2419(%rip),%r11        # 10e0a0 <pf_got_10_0>

00000000001104b9 <pf_got_hint_9_0>:
  1104b9:	41 0f 18 93 20 e6 07 	prefetcht1 0x7e620(%r11)
  1104c0:	00 

00000000001104c1 <pf_got_hint_9_1>:
  1104c1:	41 0f 18 93 d0 23 08 	prefetcht1 0x823d0(%r11)
  1104c8:	00 

00000000001104c9 <pf_got_hint_9_2>:
  1104c9:	41 0f 18 93 e1 23 08 	prefetcht1 0x823e1(%r11)
  1104d0:	00 

00000000001104d1 <pf_got_hint_9_3>:
  1104d1:	41 0f 18 93 c0 26 08 	prefetcht1 0x826c0(%r11)
  1104d8:	00 

00000000001104d9 <pf_got_hint_9_4>:
  1104d9:	41 0f 18 93 50 f3 08 	prefetcht1 0x8f350(%r11)
  1104e0:	00 

00000000001104e1 <pf_got_hint_9_5>:
  1104e1:	41 0f 18 93 60 f3 08 	prefetcht1 0x8f360(%r11)
  1104e8:	00 

00000000001104e9 <pf_got_hint_9_6>:
  1104e9:	41 0f 18 93 20 07 09 	prefetcht1 0x90720(%r11)
  1104f0:	00 
  1104f1:	41 5b                	pop    %r11

00000000001104f3 <pf_jump_9>:
  1104f3:	e9 d8 51 f3 ff       	jmp    456d0 <pf_callee_9>
  1104f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1104ff:	00 

0000000000110500 <pf_call_10>:
  110500:	0f 18 15 29 61 f1 ff 	prefetcht1 -0xe9ed7(%rip)        # 26630 <pf_target_10_0>
  110507:	41 53                	push   %r11
  110509:	4c 8b 1d 90 db ff ff 	mov    -0x2470(%rip),%r11        # 10e0a0 <pf_got_10_0>

0000000000110510 <pf_got_hint_10_0>:
  110510:	41 0f 18 93 50 74 09 	prefetcht1 0x97450(%r11)
  110517:	00 

0000000000110518 <pf_got_hint_10_1>:
  110518:	41 0f 18 93 61 74 09 	prefetcht1 0x97461(%r11)
  11051f:	00 
  110520:	41 5b                	pop    %r11

0000000000110522 <pf_jump_10>:
  110522:	e9 b9 64 f1 ff       	jmp    269e0 <pf_callee_10>
  110527:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  11052e:	00 00 

0000000000110530 <pf_call_11>:
  110530:	41 53                	push   %r11
  110532:	4c 8b 1d 67 db ff ff 	mov    -0x2499(%rip),%r11        # 10e0a0 <pf_got_10_0>

0000000000110539 <pf_got_hint_11_0>:
  110539:	41 0f 18 93 20 4a ff 	prefetcht1 -0xb5e0(%r11)
  110540:	ff 
  110541:	41 5b                	pop    %r11

0000000000110543 <pf_jump_11>:
  110543:	e9 a8 5b f1 ff       	jmp    260f0 <pf_callee_11>
  110548:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11054f:	00 

0000000000110550 <pf_call_12>:
  110550:	0f 18 15 b9 35 f3 ff 	prefetcht1 -0xcca47(%rip)        # 43b10 <pf_target_12_0>
  110557:	0f 18 15 e6 35 f3 ff 	prefetcht1 -0xcca1a(%rip)        # 43b44 <pf_target_12_1>

000000000011055e <pf_jump_12>:
  11055e:	e9 8d 5b f1 ff       	jmp    260f0 <pf_callee_11>
  110563:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11056a:	00 00 00 
  11056d:	0f 1f 00             	nopl   (%rax)

0000000000110570 <pf_call_13>:
  110570:	0f 18 15 09 94 f3 ff 	prefetcht1 -0xc6bf7(%rip)        # 49980 <pf_callee_23>

0000000000110577 <pf_jump_13>:
  110577:	e9 d4 fd f2 ff       	jmp    40350 <pf_callee_13>
  11057c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110580 <pf_call_14>:
  110580:	0f 18 15 09 36 f3 ff 	prefetcht1 -0xcc9f7(%rip)        # 43b90 <pf_target_14_0>

0000000000110587 <pf_jump_14>:
  110587:	e9 44 3a f3 ff       	jmp    43fd0 <pf_callee_14>
  11058c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110590 <pf_call_15>:
  110590:	0f 18 15 19 4f f3 ff 	prefetcht1 -0xcb0e7(%rip)        # 454b0 <pf_target_15_0>
  110597:	0f 18 15 24 4f f3 ff 	prefetcht1 -0xcb0dc(%rip)        # 454c2 <pf_target_15_1>

000000000011059e <pf_jump_15>:
  11059e:	e9 9d 5b f1 ff       	jmp    26140 <pf_callee_15>
  1105a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1105aa:	00 00 00 
  1105ad:	0f 1f 00             	nopl   (%rax)

00000000001105b0 <pf_call_16>:
  1105b0:	0f 18 15 39 68 f1 ff 	prefetcht1 -0xe97c7(%rip)        # 26df0 <pf_target_16_0>
  1105b7:	41 53                	push   %r11
  1105b9:	4c 8b 1d e0 da ff ff 	mov    -0x2520(%rip),%r11        # 10e0a0 <pf_got_10_0>

00000000001105c0 <pf_got_hint_16_0>:
  1105c0:	41 0f 18 93 10 99 01 	prefetcht1 0x19910(%r11)
  1105c7:	00 
  1105c8:	41 5b                	pop    %r11

00000000001105ca <pf_jump_16>:
  1105ca:	e9 71 5b f1 ff       	jmp    26140 <pf_callee_15>
  1105cf:	90                   	nop

00000000001105d0 <pf_call_17>:
  1105d0:	41 53                	push   %r11
  1105d2:	4c 8b 1d c7 da ff ff 	mov    -0x2539(%rip),%r11        # 10e0a0 <pf_got_10_0>

00000000001105d9 <pf_got_hint_17_0>:
  1105d9:	41 0f 18 93 60 3c 07 	prefetcht1 0x73c60(%r11)
  1105e0:	00 

00000000001105e1 <pf_got_hint_17_1>:
  1105e1:	41 0f 18 93 f0 43 07 	prefetcht1 0x743f0(%r11)
  1105e8:	00 

00000000001105e9 <pf_got_hint_17_2>:
  1105e9:	41 0f 18 93 20 44 07 	prefetcht1 0x74420(%r11)
  1105f0:	00 
  1105f1:	4c 8b 1d 98 db ff ff 	mov    -0x2468(%rip),%r11        # 10e190 <pf_got_17_3>

00000000001105f8 <pf_got_hint_17_3>:
  1105f8:	41 0f 18 93 50 8f f4 	prefetcht1 -0xb70b0(%r11)
  1105ff:	ff 

0000000000110600 <pf_got_hint_17_4>:
  110600:	41 0f 18 93 94 8f f4 	prefetcht1 -0xb706c(%r11)
  110607:	ff 

0000000000110608 <pf_got_hint_17_5>:
  110608:	41 0f 18 93 d8 8f f4 	prefetcht1 -0xb7028(%r11)
  11060f:	ff 
  110610:	41 5b                	pop    %r11

0000000000110612 <pf_jump_17>:
  110612:	e9 19 63 f1 ff       	jmp    26930 <pf_callee_17>
  110617:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  11061e:	00 00 

0000000000110620 <pf_call_18>:
  110620:	0f 18 15 29 fd f2 ff 	prefetcht1 -0xd02d7(%rip)        # 40350 <pf_callee_13>

0000000000110627 <pf_jump_18>:
  110627:	e9 24 49 f3 ff       	jmp    44f50 <pf_callee_18>
  11062c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110630 <pf_call_19>:
  110630:	0f 18 15 e9 43 f3 ff 	prefetcht1 -0xcbc17(%rip)        # 44a20 <pf_target_19_0>

0000000000110637 <pf_jump_19>:
  110637:	e9 14 fd f2 ff       	jmp    40350 <pf_callee_13>
  11063c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110640 <pf_call_20>:
  110640:	0f 18 15 09 69 f1 ff 	prefetcht1 -0xe96f7(%rip)        # 26f50 <pf_target_20_0>
  110647:	41 53                	push   %r11
  110649:	4c 8b 1d 50 da ff ff 	mov    -0x25b0(%rip),%r11        # 10e0a0 <pf_got_10_0>

0000000000110650 <pf_got_hint_20_0>:
  110650:	41 0f 18 93 c0 dd 02 	prefetcht1 0x2ddc0(%r11)
  110657:	00 
  110658:	41 5b                	pop    %r11

000000000011065a <pf_jump_20>:
  11065a:	e9 f1 fc f2 ff       	jmp    40350 <pf_callee_13>
  11065f:	90                   	nop

0000000000110660 <pf_call_21>:
  110660:	0f 18 15 b9 69 f1 ff 	prefetcht1 -0xe9647(%rip)        # 27020 <pf_target_21_0>
  110667:	41 53                	push   %r11
  110669:	4c 8b 1d 30 da ff ff 	mov    -0x25d0(%rip),%r11        # 10e0a0 <pf_got_10_0>

0000000000110670 <pf_got_hint_21_0>:
  110670:	41 0f 18 93 e0 9a 01 	prefetcht1 0x19ae0(%r11)
  110677:	00 
  110678:	41 5b                	pop    %r11

000000000011067a <pf_jump_21>:
  11067a:	e9 e1 8e f3 ff       	jmp    49560 <pf_callee_21>
  11067f:	90                   	nop

0000000000110680 <pf_call_22>:
  110680:	0f 18 15 0e 16 f5 ff 	prefetcht1 -0xae9f2(%rip)        # 61c95 <pf_target_22_0>
  110687:	0f 18 15 69 33 f5 ff 	prefetcht1 -0xacc97(%rip)        # 639f7 <pf_target_22_1>
  11068e:	0f 18 15 2b c9 f4 ff 	prefetcht1 -0xb36d5(%rip)        # 5cfc0 <pf_target_22_2>
  110695:	0f 18 15 44 be f4 ff 	prefetcht1 -0xb41bc(%rip)        # 5c4e0 <pf_target_22_3>
  11069c:	0f 18 15 23 12 f5 ff 	prefetcht1 -0xaeddd(%rip)        # 618c6 <pf_target_22_4>

00000000001106a3 <pf_jump_22>:
  1106a3:	e9 98 5a f1 ff       	jmp    26140 <pf_callee_15>
  1106a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1106af:	00 

00000000001106b0 <pf_call_23>:
  1106b0:	0f 18 15 a6 19 f5 ff 	prefetcht1 -0xae65a(%rip)        # 6205d <pf_target_23_0>

00000000001106b7 <pf_jump_23>:
  1106b7:	e9 c4 92 f3 ff       	jmp    49980 <pf_callee_23>
  1106bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001106c0 <pf_call_24>:
  1106c0:	0f 18 15 a9 c6 f4 ff 	prefetcht1 -0xb3957(%rip)        # 5cd70 <pf_target_24_0>
  1106c7:	0f 18 15 b6 c6 f4 ff 	prefetcht1 -0xb394a(%rip)        # 5cd84 <pf_target_24_1>

00000000001106ce <pf_jump_24>:
  1106ce:	e9 0d 60 f1 ff       	jmp    266e0 <pf_callee_24>
  1106d3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1106da:	00 00 00 
  1106dd:	0f 1f 00             	nopl   (%rax)

00000000001106e0 <pf_call_25>:
  1106e0:	0f 18 15 d9 3a f5 ff 	prefetcht1 -0xac527(%rip)        # 641c0 <pf_callee_28>
  1106e7:	41 53                	push   %r11
  1106e9:	4c 8b 1d b0 d9 ff ff 	mov    -0x2650(%rip),%r11        # 10e0a0 <pf_got_10_0>

00000000001106f0 <pf_got_hint_25_0>:
  1106f0:	41 0f 18 93 b0 53 ff 	prefetcht1 -0xac50(%r11)
  1106f7:	ff 

00000000001106f8 <pf_got_hint_25_1>:
  1106f8:	41 0f 18 93 50 1d 00 	prefetcht1 0x1d50(%r11)
  1106ff:	00 

0000000000110700 <pf_got_hint_25_2>:
  110700:	41 0f 18 93 f0 ef 09 	prefetcht1 0x9eff0(%r11)
  110707:	00 
  110708:	41 5b                	pop    %r11

000000000011070a <pf_jump_25>:
  11070a:	e9 81 cd f4 ff       	jmp    5d490 <pf_callee_25>
  11070f:	90                   	nop

0000000000110710 <pf_call_26>:
  110710:	0f 18 15 c9 5f f1 ff 	prefetcht1 -0xea037(%rip)        # 266e0 <pf_callee_24>
  110717:	0f 18 15 72 69 f1 ff 	prefetcht1 -0xe968e(%rip)        # 27090 <pf_callee_29>
  11071e:	0f 18 15 5b 10 f5 ff 	prefetcht1 -0xaefa5(%rip)        # 61780 <pf_target_26_2>
  110725:	0f 18 15 a0 32 f5 ff 	prefetcht1 -0xacd60(%rip)        # 639cc <pf_target_26_3>
  11072c:	0f 18 15 9d 66 f1 ff 	prefetcht1 -0xe9963(%rip)        # 26dd0 <pf_callee_31>
  110733:	0f 18 15 95 8b f5 ff 	prefetcht1 -0xa746b(%rip)        # 692cf <pf_target_26_5>
  11073a:	41 53                	push   %r11
  11073c:	4c 8b 1d 5d d9 ff ff 	mov    -0x26a3(%rip),%r11        # 10e0a0 <pf_got_10_0>

0000000000110743 <pf_got_hint_26_0>:
  110743:	41 0f 18 93 a0 04 0a 	prefetcht1 0xa04a0(%r11)
  11074a:	00 

000000000011074b <pf_got_hint_26_1>:
  11074b:	41 0f 18 93 68 06 0a 	prefetcht1 0xa0668(%r11)
  110752:	00 
  110753:	41 5b                	pop    %r11

0000000000110755 <pf_jump_26>:
  110755:	e9 36 cd f4 ff       	jmp    5d490 <pf_callee_25>
  11075a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000110760 <pf_call_27>:
  110760:	0f 18 15 5f 10 f5 ff 	prefetcht1 -0xaefa1(%rip)        # 617c6 <pf_target_27_0>
  110767:	41 53                	push   %r11
  110769:	4c 8b 1d 30 d9 ff ff 	mov    -0x26d0(%rip),%r11        # 10e0a0 <pf_got_10_0>

0000000000110770 <pf_got_hint_27_0>:
  110770:	41 0f 18 93 70 1f 0a 	prefetcht1 0xa1f70(%r11)
  110777:	00 
  110778:	41 5b                	pop    %r11

000000000011077a <pf_jump_27>:
  11077a:	e9 61 5f f1 ff       	jmp    266e0 <pf_callee_24>
  11077f:	90                   	nop

0000000000110780 <pf_call_28>:
  110780:	0f 18 15 f9 8a f3 ff 	prefetcht1 -0xc7507(%rip)        # 49280 <pf_target_28_0>
  110787:	0f 18 15 eb 8e f3 ff 	prefetcht1 -0xc7115(%rip)        # 49679 <pf_target_28_1>
  11078e:	0f 18 15 ec 8e f3 ff 	prefetcht1 -0xc7114(%rip)        # 49681 <pf_target_28_2>

0000000000110795 <pf_jump_28>:
  110795:	e9 26 3a f5 ff       	jmp    641c0 <pf_callee_28>
  11079a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000001107a0 <pf_call_29>:
  1107a0:	0f 18 15 09 16 f5 ff 	prefetcht1 -0xae9f7(%rip)        # 61db0 <pf_target_29_0>
  1107a7:	0f 18 15 e2 f9 f4 ff 	prefetcht1 -0xb061e(%rip)        # 60190 <pf_target_29_1>
  1107ae:	0f 18 15 bb c1 f4 ff 	prefetcht1 -0xb3e45(%rip)        # 5c970 <pf_target_29_2>
  1107b5:	0f 18 15 05 16 f5 ff 	prefetcht1 -0xae9fb(%rip)        # 61dc1 <pf_target_29_3>
  1107bc:	0f 18 15 01 fa f4 ff 	prefetcht1 -0xb05ff(%rip)        # 601c4 <pf_target_29_4>

00000000001107c3 <pf_jump_29>:
  1107c3:	e9 c8 68 f1 ff       	jmp    27090 <pf_callee_29>
  1107c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1107cf:	00 

00000000001107d0 <pf_call_30>:
  1107d0:	0f 18 15 a9 31 f5 ff 	prefetcht1 -0xace57(%rip)        # 63980 <pf_target_30_0>

00000000001107d7 <pf_jump_30>:
  1107d7:	e9 64 59 f1 ff       	jmp    26140 <pf_callee_15>
  1107dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001107e0 <pf_call_31>:
  1107e0:	0f 18 15 09 4c f5 ff 	prefetcht1 -0xab3f7(%rip)        # 653f0 <pf_target_31_0>
  1107e7:	41 53                	push   %r11
  1107e9:	4c 8b 1d b0 d8 ff ff 	mov    -0x2750(%rip),%r11        # 10e0a0 <pf_got_10_0>

00000000001107f0 <pf_got_hint_31_0>:
  1107f0:	41 0f 18 93 e0 48 ff 	prefetcht1 -0xb720(%r11)
  1107f7:	ff 

00000000001107f8 <pf_got_hint_31_1>:
  1107f8:	41 0f 18 93 70 1f 0a 	prefetcht1 0xa1f70(%r11)
  1107ff:	00 
  110800:	41 5b                	pop    %r11

0000000000110802 <pf_jump_31>:
  110802:	e9 c9 65 f1 ff       	jmp    26dd0 <pf_callee_31>
  110807:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  11080e:	00 00 

0000000000110810 <pf_call_32>:
  110810:	0f 18 15 ca da f1 ff 	prefetcht1 -0xe2536(%rip)        # 2e2e1 <pf_target_32_0>
  110817:	0f 18 15 26 0e f2 ff 	prefetcht1 -0xdf1da(%rip)        # 31644 <pf_target_32_1>
  11081e:	41 53                	push   %r11
  110820:	4c 8b 1d 79 d8 ff ff 	mov    -0x2787(%rip),%r11        # 10e0a0 <pf_got_10_0>

0000000000110827 <pf_got_hint_32_0>:
  110827:	41 0f 18 93 30 07 00 	prefetcht1 0x730(%r11)
  11082e:	00 
  11082f:	41 5b                	pop    %r11

0000000000110831 <pf_jump_32>:
  110831:	e9 ca 83 f6 ff       	jmp    78c00 <pf_callee_32>
