import json,subprocess,time
from pathlib import Path
r=Path('/storage/prefetchit/class_b_temporal_20261001')
while not (r/'initial_profiles_complete.json').exists():
 time.sleep(20)
for script in ('temporal_path_analysis.py','temporal_path_build.py'):
 cmd=['python3','/home/hnpark2/prefetchit/llvm_prefetchit/scripts/class_b/'+script,str(r)]
 print(json.dumps(dict(command=cmd)),flush=True)
 subprocess.run(cmd,check=True)
(r/'initial_candidates_built.json').write_text(json.dumps(dict(valid=True))+'\n')
