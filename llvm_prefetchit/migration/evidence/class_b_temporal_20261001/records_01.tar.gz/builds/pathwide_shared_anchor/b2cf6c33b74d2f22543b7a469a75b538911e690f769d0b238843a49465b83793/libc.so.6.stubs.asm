
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_shared_anchor/b2cf6c33b74d2f22543b7a469a75b538911e690f769d0b238843a49465b83793/call-stub-scdzwqld/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000229380 <pf_call_0>:
  229380:	0f 18 15 fc d1 e4 ff 	prefetcht1 -0x1b2e04(%rip)        # 76583 <pf_target_0_0>
  229387:	0f 18 15 73 e1 e4 ff 	prefetcht1 -0x1b1e8d(%rip)        # 77501 <pf_target_0_1>
  22938e:	0f 18 15 6d dc e4 ff 	prefetcht1 -0x1b2393(%rip)        # 77002 <pf_target_0_2>
  229395:	0f 18 15 c1 d1 e4 ff 	prefetcht1 -0x1b2e3f(%rip)        # 7655d <pf_target_0_3>
  22939c:	0f 18 15 dd 4b e6 ff 	prefetcht1 -0x19b423(%rip)        # 8df80 <pf_target_0_4>

00000000002293a3 <pf_jump_0>:
  2293a3:	e9 88 0e e3 ff       	jmp    5a230 <pf_callee_0>
  2293a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  2293af:	00 

00000000002293b0 <pf_call_1>:
  2293b0:	0f 18 15 89 82 f8 ff 	prefetcht1 -0x77d77(%rip)        # 1b1640 <pf_target_1_0>
  2293b7:	0f 18 15 22 48 e6 ff 	prefetcht1 -0x19b7de(%rip)        # 8dbe0 <pf_target_1_1>
  2293be:	0f 18 15 3b bc e4 ff 	prefetcht1 -0x1b43c5(%rip)        # 75000 <pf_target_1_2>
  2293c5:	0f 18 15 d4 51 e6 ff 	prefetcht1 -0x19ae2c(%rip)        # 8e5a0 <pf_callee_3>
  2293cc:	0f 18 15 1d bc e4 ff 	prefetcht1 -0x1b43e3(%rip)        # 74ff0 <pf_callee_2>
  2293d3:	0f 18 15 96 65 e6 ff 	prefetcht1 -0x199a6a(%rip)        # 8f970 <pf_target_1_5>
  2293da:	0f 18 15 9f 65 e6 ff 	prefetcht1 -0x199a61(%rip)        # 8f980 <pf_target_1_6>
  2293e1:	0f 18 15 99 82 f8 ff 	prefetcht1 -0x77d67(%rip)        # 1b1681 <pf_target_1_7>

00000000002293e8 <pf_jump_1>:
  2293e8:	e9 23 52 e6 ff       	jmp    8e610 <pf_callee_1>
  2293ed:	0f 1f 00             	nopl   (%rax)

00000000002293f0 <pf_call_2>:
  2293f0:	0f 18 15 f2 d8 e4 ff 	prefetcht1 -0x1b270e(%rip)        # 76ce9 <pf_target_2_0>
  2293f7:	0f 18 15 a2 db e4 ff 	prefetcht1 -0x1b245e(%rip)        # 76fa0 <pf_target_2_1>
  2293fe:	0f 18 15 4b cc e4 ff 	prefetcht1 -0x1b33b5(%rip)        # 76050 <pf_target_2_2>
  229405:	0f 18 15 c4 c2 e4 ff 	prefetcht1 -0x1b3d3c(%rip)        # 756d0 <pf_target_2_3>
  22940c:	0f 18 15 e5 db e4 ff 	prefetcht1 -0x1b241b(%rip)        # 76ff8 <pf_target_2_4>
  229413:	0f 18 15 16 0e e3 ff 	prefetcht1 -0x1cf1ea(%rip)        # 5a230 <pf_callee_0>
  22941a:	0f 18 15 1f 0e e3 ff 	prefetcht1 -0x1cf1e1(%rip)        # 5a240 <pf_target_2_6>
  229421:	0f 18 15 38 4b e6 ff 	prefetcht1 -0x19b4c8(%rip)        # 8df60 <pf_target_2_7>

0000000000229428 <pf_jump_2>:
  229428:	e9 c3 bb e4 ff       	jmp    74ff0 <pf_callee_2>
  22942d:	0f 1f 00             	nopl   (%rax)

0000000000229430 <pf_call_3>:
  229430:	0f 18 15 09 bc e4 ff 	prefetcht1 -0x1b43f7(%rip)        # 75040 <pf_target_3_0>
  229437:	0f 18 15 c3 47 e6 ff 	prefetcht1 -0x19b83d(%rip)        # 8dc01 <pf_target_3_1>
  22943e:	0f 18 15 e5 c5 e4 ff 	prefetcht1 -0x1b3a1b(%rip)        # 75a2a <pf_target_3_2>
  229445:	0f 18 15 77 c0 e4 ff 	prefetcht1 -0x1b3f89(%rip)        # 754c3 <pf_target_3_3>

000000000022944c <pf_jump_3>:
  22944c:	e9 4f 51 e6 ff       	jmp    8e5a0 <pf_callee_3>
  229451:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229458:	00 00 00 
  22945b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229460 <pf_call_4>:
  229460:	0f 18 15 36 ae e6 ff 	prefetcht1 -0x1951ca(%rip)        # 9429d <pf_target_4_0>
  229467:	0f 18 15 c9 d0 e6 ff 	prefetcht1 -0x192f37(%rip)        # 96537 <pf_target_4_1>
  22946e:	0f 18 15 6f d1 e6 ff 	prefetcht1 -0x192e91(%rip)        # 965e4 <pf_target_4_2>
  229475:	0f 18 15 84 d1 e6 ff 	prefetcht1 -0x192e7c(%rip)        # 96600 <pf_target_4_3>
  22947c:	0f 18 15 7e a5 e6 ff 	prefetcht1 -0x195a82(%rip)        # 93a01 <pf_target_4_4>
  229483:	0f 18 15 f1 ac e6 ff 	prefetcht1 -0x19530f(%rip)        # 9417b <pf_target_4_5>
  22948a:	0f 18 15 b7 d0 e6 ff 	prefetcht1 -0x192f49(%rip)        # 96548 <pf_target_4_6>

0000000000229491 <pf_jump_4>:
  229491:	e9 8a 75 e6 ff       	jmp    90a20 <pf_callee_28>
  229496:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22949d:	00 00 00 

00000000002294a0 <pf_call_5>:
  2294a0:	0f 18 15 59 7b e6 ff 	prefetcht1 -0x1984a7(%rip)        # 91000 <pf_target_5_0>

00000000002294a7 <pf_jump_5>:
  2294a7:	e9 64 04 e7 ff       	jmp    99910 <pf_callee_5>
  2294ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002294b0 <pf_call_6>:
  2294b0:	0f 18 15 09 a4 e6 ff 	prefetcht1 -0x195bf7(%rip)        # 938c0 <pf_target_6_0>
  2294b7:	0f 18 15 ec a3 e6 ff 	prefetcht1 -0x195c14(%rip)        # 938aa <pf_target_6_1>

00000000002294be <pf_jump_6>:
  2294be:	e9 fd 75 e6 ff       	jmp    90ac0 <pf_callee_18>
  2294c3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2294ca:	00 00 00 
  2294cd:	0f 1f 00             	nopl   (%rax)

00000000002294d0 <pf_call_7>:
  2294d0:	0f 18 15 19 7b e6 ff 	prefetcht1 -0x1984e7(%rip)        # 90ff0 <pf_target_24_6>
  2294d7:	0f 18 15 25 7b e6 ff 	prefetcht1 -0x1984db(%rip)        # 91003 <pf_target_7_1>

00000000002294de <pf_jump_7>:
  2294de:	e9 2d 04 e7 ff       	jmp    99910 <pf_callee_5>
  2294e3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2294ea:	00 00 00 
  2294ed:	0f 1f 00             	nopl   (%rax)

00000000002294f0 <pf_call_8>:
  2294f0:	0f 18 15 84 ac e6 ff 	prefetcht1 -0x19537c(%rip)        # 9417b <pf_target_4_5>
  2294f7:	0f 18 15 85 ac e6 ff 	prefetcht1 -0x19537b(%rip)        # 94183 <pf_target_8_1>
  2294fe:	0f 18 15 5b dc e6 ff 	prefetcht1 -0x1923a5(%rip)        # 97160 <pf_target_8_2>

0000000000229505 <pf_jump_8>:
  229505:	e9 b6 75 e6 ff       	jmp    90ac0 <pf_callee_18>
  22950a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229510 <pf_call_9>:
  229510:	0f 18 15 39 c5 ef ff 	prefetcht1 -0x103ac7(%rip)        # 125a50 <pf_target_9_0>
  229517:	0f 18 15 92 d3 ef ff 	prefetcht1 -0x102c6e(%rip)        # 1268b0 <pf_target_9_1>
  22951e:	0f 18 15 9c d3 ef ff 	prefetcht1 -0x102c64(%rip)        # 1268c1 <pf_target_9_2>
  229525:	0f 18 15 58 c5 ef ff 	prefetcht1 -0x103aa8(%rip)        # 125a84 <pf_target_9_3>

000000000022952c <pf_jump_9>:
  22952c:	e9 cf d3 ef ff       	jmp    126900 <pf_callee_9>
  229531:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229538:	00 00 00 
  22953b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229540 <pf_call_10>:
  229540:	0f 18 15 fa b4 e6 ff 	prefetcht1 -0x194b06(%rip)        # 94a41 <pf_target_10_0>

0000000000229547 <pf_jump_10>:
  229547:	e9 74 0e e1 ff       	jmp    3a3c0 <pf_callee_10>
  22954c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229550 <pf_call_11>:
  229550:	0f 18 15 89 73 e6 ff 	prefetcht1 -0x198c77(%rip)        # 908e0 <pf_target_11_0>
  229557:	0f 18 15 72 88 f2 ff 	prefetcht1 -0xd778e(%rip)        # 151dd0 <pf_target_11_1>
  22955e:	0f 18 15 5c f3 f3 ff 	prefetcht1 -0xc0ca4(%rip)        # 1688c1 <pf_target_11_2>
  229565:	0f 18 15 44 f3 f3 ff 	prefetcht1 -0xc0cbc(%rip)        # 1688b0 <pf_target_11_3>
  22956c:	0f 18 15 cd eb e7 ff 	prefetcht1 -0x181433(%rip)        # a8140 <pf_target_11_4>
  229573:	0f 18 15 06 06 f2 ff 	prefetcht1 -0xdf9fa(%rip)        # 149b80 <pf_target_11_5>
  22957a:	0f 18 15 ef ed df ff 	prefetcht1 -0x201211(%rip)        # 28370 <pf_target_11_6>
  229581:	0f 18 15 38 80 e6 ff 	prefetcht1 -0x197fc8(%rip)        # 915c0 <pf_target_11_7>

0000000000229588 <pf_jump_11>:
  229588:	e9 d3 c7 e1 ff       	jmp    45d60 <pf_callee_11>
  22958d:	0f 1f 00             	nopl   (%rax)

0000000000229590 <pf_call_12>:
  229590:	0f 18 15 98 88 f2 ff 	prefetcht1 -0xd7768(%rip)        # 151e2f <pf_target_12_0>

0000000000229597 <pf_jump_12>:
  229597:	e9 14 80 e6 ff       	jmp    915b0 <pf_callee_12>
  22959c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002295a0 <pf_call_13>:
  2295a0:	0f 18 15 e6 b5 e6 ff 	prefetcht1 -0x194a1a(%rip)        # 94b8d <pf_target_13_0>

00000000002295a7 <pf_jump_13>:
  2295a7:	e9 64 1d ef ff       	jmp    11b310 <pf_callee_13>
  2295ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002295b0 <pf_call_14>:
  2295b0:	0f 18 15 09 8a e6 ff 	prefetcht1 -0x1975f7(%rip)        # 91fc0 <pf_target_14_0>
  2295b7:	0f 18 15 04 c1 e6 ff 	prefetcht1 -0x193efc(%rip)        # 956c2 <pf_target_14_1>
  2295be:	0f 18 15 bb c0 e6 ff 	prefetcht1 -0x193f45(%rip)        # 95680 <pf_target_14_2>

00000000002295c5 <pf_jump_14>:
  2295c5:	e9 66 c7 e6 ff       	jmp    95d30 <pf_callee_14>
  2295ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000002295d0 <pf_call_15>:
  2295d0:	0f 18 15 29 d3 ef ff 	prefetcht1 -0x102cd7(%rip)        # 126900 <pf_callee_9>

00000000002295d7 <pf_jump_15>:
  2295d7:	e9 54 7d e6 ff       	jmp    91330 <pf_callee_15>
  2295dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002295e0 <pf_call_16>:
  2295e0:	0f 18 15 29 03 e7 ff 	prefetcht1 -0x18fcd7(%rip)        # 99910 <pf_callee_5>
  2295e7:	0f 18 15 d5 aa e6 ff 	prefetcht1 -0x19552b(%rip)        # 940c3 <pf_target_16_1>

00000000002295ee <pf_jump_16>:
  2295ee:	e9 ed 7c e6 ff       	jmp    912e0 <pf_callee_16>
  2295f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2295fa:	00 00 00 
  2295fd:	0f 1f 00             	nopl   (%rax)

0000000000229600 <pf_call_17>:
  229600:	0f 18 15 69 ce e6 ff 	prefetcht1 -0x193197(%rip)        # 96470 <pf_target_17_0>
  229607:	0f 18 15 75 ce e6 ff 	prefetcht1 -0x19318b(%rip)        # 96483 <pf_target_17_1>

000000000022960e <pf_jump_17>:
  22960e:	e9 7d 74 e6 ff       	jmp    90a90 <pf_callee_17>
  229613:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22961a:	00 00 00 
  22961d:	0f 1f 00             	nopl   (%rax)

0000000000229620 <pf_call_18>:
  229620:	0f 18 15 d0 b2 e6 ff 	prefetcht1 -0x194d30(%rip)        # 948f7 <pf_target_18_0>
  229627:	0f 18 15 d3 97 e6 ff 	prefetcht1 -0x19682d(%rip)        # 92e01 <pf_target_18_1>
  22962e:	0f 18 15 7b 7f e6 ff 	prefetcht1 -0x198085(%rip)        # 915b0 <pf_callee_12>

0000000000229635 <pf_jump_18>:
  229635:	e9 86 74 e6 ff       	jmp    90ac0 <pf_callee_18>
  22963a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229640 <pf_call_19>:
  229640:	0f 18 15 ba b5 f0 ff 	prefetcht1 -0xf4a46(%rip)        # 134c01 <pf_target_19_0>
  229647:	0f 18 15 12 c7 e1 ff 	prefetcht1 -0x1e38ee(%rip)        # 45d60 <pf_callee_11>

000000000022964e <pf_jump_19>:
  22964e:	e9 7d 80 e7 ff       	jmp    a16d0 <pf_callee_19>
  229653:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22965a:	00 00 00 
  22965d:	0f 1f 00             	nopl   (%rax)

0000000000229660 <pf_call_20>:
  229660:	0f 18 15 f9 c6 e1 ff 	prefetcht1 -0x1e3907(%rip)        # 45d60 <pf_callee_11>
  229667:	0f 18 15 15 b4 e6 ff 	prefetcht1 -0x194beb(%rip)        # 94a83 <pf_target_20_1>

000000000022966e <pf_jump_20>:
  22966e:	e9 fd a2 e7 ff       	jmp    a3970 <pf_callee_20>
  229673:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22967a:	00 00 00 
  22967d:	0f 1f 00             	nopl   (%rax)

0000000000229680 <pf_call_21>:
  229680:	0f 18 15 51 7a e7 ff 	prefetcht1 -0x1885af(%rip)        # a10d8 <pf_target_21_0>

0000000000229687 <pf_jump_21>:
  229687:	e9 c4 79 e7 ff       	jmp    a1050 <pf_callee_21>
  22968c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229690 <pf_call_22>:
  229690:	0f 18 15 89 ef df ff 	prefetcht1 -0x201077(%rip)        # 28620 <pf_target_22_0>

0000000000229697 <pf_jump_22>:
  229697:	e9 d4 a2 e7 ff       	jmp    a3970 <pf_callee_20>
  22969c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002296a0 <pf_call_23>:
  2296a0:	0f 18 15 5c 80 e7 ff 	prefetcht1 -0x187fa4(%rip)        # a1703 <pf_target_23_0>

00000000002296a7 <pf_jump_23>:
  2296a7:	e9 c4 a2 e7 ff       	jmp    a3970 <pf_callee_20>
  2296ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002296b0 <pf_call_24>:
  2296b0:	0f 18 15 8b a1 e6 ff 	prefetcht1 -0x195e75(%rip)        # 93842 <pf_target_24_0>
  2296b7:	0f 18 15 02 55 ef ff 	prefetcht1 -0x10aafe(%rip)        # 11ebc0 <pf_target_24_1>
  2296be:	0f 18 15 bb 08 e7 ff 	prefetcht1 -0x18f745(%rip)        # 99f80 <pf_target_24_2>
  2296c5:	0f 18 15 34 a1 e6 ff 	prefetcht1 -0x195ecc(%rip)        # 93800 <pf_target_24_3>
  2296cc:	0f 18 15 2f 96 e7 ff 	prefetcht1 -0x1869d1(%rip)        # a2d02 <pf_target_24_4>
  2296d3:	0f 18 15 06 ce e7 ff 	prefetcht1 -0x1831fa(%rip)        # a64e0 <pf_target_24_5>
  2296da:	0f 18 15 0f 79 e6 ff 	prefetcht1 -0x1986f1(%rip)        # 90ff0 <pf_target_24_6>
  2296e1:	0f 18 15 d9 a2 e6 ff 	prefetcht1 -0x195d27(%rip)        # 939c1 <pf_target_24_7>

00000000002296e8 <pf_jump_24>:
  2296e8:	e9 73 8f e7 ff       	jmp    a2660 <pf_callee_24>
  2296ed:	0f 1f 00             	nopl   (%rax)

00000000002296f0 <pf_call_25>:
  2296f0:	0f 18 15 59 79 e7 ff 	prefetcht1 -0x1886a7(%rip)        # a1050 <pf_callee_21>

00000000002296f7 <pf_jump_25>:
  2296f7:	e9 54 b2 e7 ff       	jmp    a4950 <pf_callee_25>
  2296fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229700 <pf_call_26>:
  229700:	0f 18 15 b9 55 ef ff 	prefetcht1 -0x10aa47(%rip)        # 11ecc0 <pf_target_26_0>

0000000000229707 <pf_jump_26>:
  229707:	e9 94 bc e7 ff       	jmp    a53a0 <pf_callee_26>
  22970c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229710 <pf_call_27>:
  229710:	0f 18 15 01 d0 e7 ff 	prefetcht1 -0x182fff(%rip)        # a6718 <pf_target_27_0>

0000000000229717 <pf_jump_27>:
  229717:	e9 54 a2 e7 ff       	jmp    a3970 <pf_callee_20>
  22971c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229720 <pf_call_28>:
  229720:	0f 18 15 b9 df ef ff 	prefetcht1 -0x102047(%rip)        # 1276e0 <pf_target_28_0>
  229727:	0f 18 15 52 d1 f7 ff 	prefetcht1 -0x82eae(%rip)        # 1a6880 <pf_target_28_1>

000000000022972e <pf_jump_28>:
  22972e:	e9 ed 72 e6 ff       	jmp    90a20 <pf_callee_28>
  229733:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22973a:	00 00 00 
  22973d:	0f 1f 00             	nopl   (%rax)

0000000000229740 <pf_call_29>:
  229740:	0f 18 15 ba 1f ef ff 	prefetcht1 -0x10e046(%rip)        # 11b701 <pf_target_29_0>
  229747:	0f 18 15 ae 1f ef ff 	prefetcht1 -0x10e052(%rip)        # 11b6fc <pf_target_29_1>

000000000022974e <pf_jump_29>:
  22974e:	e9 cd 72 e6 ff       	jmp    90a20 <pf_callee_28>
