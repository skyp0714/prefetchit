
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_shared_anchor/ff0825e113603c3866680d5d52216bc6d8eedf3a59f52a0aef67ff01994db128/call-stub-f8eh1zbi/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000022c300 <pf_call_0>:
  22c300:	0f 18 15 d9 e3 ea ff 	prefetcht1 -0x151c27(%rip)        # da6e0 <pf_target_0_0>
  22c307:	0f 18 15 9a a6 e9 ff 	prefetcht1 -0x165966(%rip)        # c69a8 <pf_target_0_1>
  22c30e:	0f 18 15 2d 58 ef ff 	prefetcht1 -0x10a7d3(%rip)        # 121b42 <pf_target_0_2>

000000000022c315 <pf_jump_0>:
  22c315:	e9 b6 2d e7 ff       	jmp    9f0d0 <pf_callee_0>
  22c31a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000022c320 <pf_call_1>:
  22c320:	0f 18 15 d9 54 e7 ff 	prefetcht1 -0x18ab27(%rip)        # a1800 <pf_callee_7>

000000000022c327 <pf_jump_1>:
  22c327:	e9 54 34 e7 ff       	jmp    9f780 <pf_callee_1>
  22c32c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c330 <pf_call_2>:
  22c330:	0f 18 15 f9 e5 ea ff 	prefetcht1 -0x151a07(%rip)        # da930 <pf_target_2_0>
  22c337:	0f 18 15 32 24 e7 ff 	prefetcht1 -0x18dbce(%rip)        # 9e770 <pf_target_2_1>

000000000022c33e <pf_jump_2>:
  22c33e:	e9 6d 40 e7 ff       	jmp    a03b0 <pf_callee_2>
  22c343:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c34a:	00 00 00 
  22c34d:	0f 1f 00             	nopl   (%rax)

000000000022c350 <pf_call_3>:
  22c350:	0f 18 15 ac 86 f1 ff 	prefetcht1 -0xe7954(%rip)        # 144a03 <pf_target_3_0>

000000000022c357 <pf_jump_3>:
  22c357:	e9 b4 5e e7 ff       	jmp    a2210 <pf_callee_3>
  22c35c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c360 <pf_call_4>:
  22c360:	0f 18 15 29 0d f1 ff 	prefetcht1 -0xef2d7(%rip)        # 13d090 <pf_target_4_0>

000000000022c367 <pf_jump_4>:
  22c367:	e9 e4 21 e7 ff       	jmp    9e550 <pf_callee_4>
  22c36c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c370 <pf_call_5>:
  22c370:	0f 18 15 89 1c ef ff 	prefetcht1 -0x10e377(%rip)        # 11e000 <pf_target_5_0>

000000000022c377 <pf_jump_5>:
  22c377:	e9 14 35 e7 ff       	jmp    9f890 <pf_callee_5>
  22c37c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c380 <pf_call_6>:
  22c380:	0f 18 15 fc 37 e9 ff 	prefetcht1 -0x16c804(%rip)        # bfb83 <pf_target_6_0>

000000000022c387 <pf_jump_6>:
  22c387:	e9 b4 52 e7 ff       	jmp    a1640 <pf_callee_6>
  22c38c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c390 <pf_call_7>:
  22c390:	0f 18 15 49 bf ef ff 	prefetcht1 -0x1040b7(%rip)        # 1282e0 <pf_target_7_0>
  22c397:	0f 18 15 12 26 e7 ff 	prefetcht1 -0x18d9ee(%rip)        # 9e9b0 <pf_target_7_1>
  22c39e:	0f 18 15 6b bf ef ff 	prefetcht1 -0x104095(%rip)        # 128310 <pf_target_7_2>
  22c3a5:	0f 18 15 a4 bf ef ff 	prefetcht1 -0x10405c(%rip)        # 128350 <pf_target_7_3>
  22c3ac:	0f 18 15 ad 20 e7 ff 	prefetcht1 -0x18df53(%rip)        # 9e460 <pf_target_7_4>
  22c3b3:	0f 18 15 f6 4d e7 ff 	prefetcht1 -0x18b20a(%rip)        # a11b0 <pf_target_7_5>

000000000022c3ba <pf_jump_7>:
  22c3ba:	e9 41 54 e7 ff       	jmp    a1800 <pf_callee_7>
  22c3bf:	90                   	nop

000000000022c3c0 <pf_call_8>:
  22c3c0:	0f 18 15 fa 0c f1 ff 	prefetcht1 -0xef306(%rip)        # 13d0c1 <pf_target_8_0>

000000000022c3c7 <pf_jump_8>:
  22c3c7:	e9 e4 32 e7 ff       	jmp    9f6b0 <pf_callee_8>
  22c3cc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c3d0 <pf_call_9>:
  22c3d0:	0f 18 15 99 66 f1 ff 	prefetcht1 -0xe9967(%rip)        # 142a70 <pf_target_9_0>
  22c3d7:	0f 18 15 a4 66 f1 ff 	prefetcht1 -0xe995c(%rip)        # 142a82 <pf_target_9_1>

000000000022c3de <pf_jump_9>:
  22c3de:	e9 cd 32 e7 ff       	jmp    9f6b0 <pf_callee_8>
  22c3e3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c3ea:	00 00 00 
  22c3ed:	0f 1f 00             	nopl   (%rax)

000000000022c3f0 <pf_call_10>:
  22c3f0:	0f 18 15 0b e4 f1 ff 	prefetcht1 -0xe1bf5(%rip)        # 14a802 <pf_target_10_0>
  22c3f7:	0f 18 15 f2 e3 f1 ff 	prefetcht1 -0xe1c0e(%rip)        # 14a7f0 <pf_target_10_1>
  22c3fe:	0f 18 15 d3 66 f1 ff 	prefetcht1 -0xe992d(%rip)        # 142ad8 <pf_target_10_2>
  22c405:	0f 18 15 74 64 f1 ff 	prefetcht1 -0xe9b8c(%rip)        # 142880 <pf_target_10_3>
  22c40c:	0f 18 15 af 64 f1 ff 	prefetcht1 -0xe9b51(%rip)        # 1428c2 <pf_target_10_4>
  22c413:	0f 18 15 d6 24 f0 ff 	prefetcht1 -0xfdb2a(%rip)        # 12e8f0 <pf_callee_11>

000000000022c41a <pf_jump_10>:
  22c41a:	e9 21 ee ef ff       	jmp    12b240 <pf_callee_10>
  22c41f:	90                   	nop

000000000022c420 <pf_call_11>:
  22c420:	0f 18 15 69 3a e7 ff 	prefetcht1 -0x18c597(%rip)        # 9fe90 <pf_callee_12>

000000000022c427 <pf_jump_11>:
  22c427:	e9 c4 24 f0 ff       	jmp    12e8f0 <pf_callee_11>
  22c42c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c430 <pf_call_12>:
  22c430:	0f 18 15 c9 05 f1 ff 	prefetcht1 -0xefa37(%rip)        # 13ca00 <pf_target_12_0>
  22c437:	0f 18 15 92 05 f1 ff 	prefetcht1 -0xefa6e(%rip)        # 13c9d0 <pf_target_12_1>

000000000022c43e <pf_jump_12>:
  22c43e:	e9 4d 3a e7 ff       	jmp    9fe90 <pf_callee_12>
  22c443:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c44a:	00 00 00 
  22c44d:	0f 1f 00             	nopl   (%rax)

000000000022c450 <pf_call_13>:
  22c450:	0f 18 15 29 5e f1 ff 	prefetcht1 -0xea1d7(%rip)        # 142280 <pf_target_13_0>
  22c457:	0f 18 15 82 02 f2 ff 	prefetcht1 -0xdfd7e(%rip)        # 14c6e0 <pf_target_13_1>
  22c45e:	0f 18 15 ab 56 e7 ff 	prefetcht1 -0x18a955(%rip)        # a1b10 <pf_target_13_2>
  22c465:	0f 18 15 94 05 f1 ff 	prefetcht1 -0xefa6c(%rip)        # 13ca00 <pf_target_12_0>

000000000022c46c <pf_jump_13>:
  22c46c:	e9 1f 3a e7 ff       	jmp    9fe90 <pf_callee_12>
  22c471:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c478:	00 00 00 
  22c47b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c480 <pf_call_14>:
  22c480:	0f 18 15 39 1b ef ff 	prefetcht1 -0x10e4c7(%rip)        # 11dfc0 <pf_target_14_0>
  22c487:	0f 18 15 12 51 e7 ff 	prefetcht1 -0x18aeee(%rip)        # a15a0 <pf_callee_15>
  22c48e:	0f 18 15 8b 5e e9 ff 	prefetcht1 -0x16a175(%rip)        # c2320 <pf_target_14_2>
  22c495:	0f 18 15 f4 5e e9 ff 	prefetcht1 -0x16a10c(%rip)        # c2390 <pf_target_14_3>
  22c49c:	0f 18 15 5f e2 ea ff 	prefetcht1 -0x151da1(%rip)        # da702 <pf_target_14_4>
  22c4a3:	0f 18 15 36 e2 ea ff 	prefetcht1 -0x151dca(%rip)        # da6e0 <pf_target_0_0>
  22c4aa:	0f 18 15 7f 31 e7 ff 	prefetcht1 -0x18ce81(%rip)        # 9f630 <pf_target_14_6>
  22c4b1:	0f 18 15 a8 36 e9 ff 	prefetcht1 -0x16c958(%rip)        # bfb60 <pf_target_14_7>

000000000022c4b8 <pf_jump_14>:
  22c4b8:	e9 f3 2c e7 ff       	jmp    9f1b0 <pf_callee_14>
  22c4bd:	0f 1f 00             	nopl   (%rax)

000000000022c4c0 <pf_call_15>:
  22c4c0:	0f 18 15 19 45 e9 ff 	prefetcht1 -0x16bae7(%rip)        # c09e0 <pf_target_15_0>
  22c4c7:	0f 18 15 82 20 e7 ff 	prefetcht1 -0x18df7e(%rip)        # 9e550 <pf_callee_4>
  22c4ce:	0f 18 15 2b 45 e9 ff 	prefetcht1 -0x16bad5(%rip)        # c0a00 <pf_target_15_2>
  22c4d5:	0f 18 15 a4 43 e7 ff 	prefetcht1 -0x18bc5c(%rip)        # a0880 <pf_target_15_3>
  22c4dc:	0f 18 15 3d e1 ef ff 	prefetcht1 -0x101ec3(%rip)        # 12a620 <pf_target_15_4>
  22c4e3:	0f 18 15 66 48 e7 ff 	prefetcht1 -0x18b79a(%rip)        # a0d50 <pf_target_15_5>
  22c4ea:	0f 18 15 4f 19 ef ff 	prefetcht1 -0x10e6b1(%rip)        # 11de40 <pf_target_15_6>
  22c4f1:	0f 18 15 c8 fd ef ff 	prefetcht1 -0x100238(%rip)        # 12c2c0 <pf_target_15_7>

000000000022c4f8 <pf_jump_15>:
  22c4f8:	e9 a3 50 e7 ff       	jmp    a15a0 <pf_callee_15>
  22c4fd:	0f 1f 00             	nopl   (%rax)

000000000022c500 <pf_call_16>:
  22c500:	0f 18 15 89 60 f1 ff 	prefetcht1 -0xe9f77(%rip)        # 142590 <pf_target_16_0>
  22c507:	0f 18 15 b4 60 f1 ff 	prefetcht1 -0xe9f4c(%rip)        # 1425c2 <pf_target_16_1>

000000000022c50e <pf_jump_16>:
  22c50e:	e9 cd 41 e7 ff       	jmp    a06e0 <pf_callee_16>
  22c513:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c51a:	00 00 00 
  22c51d:	0f 1f 00             	nopl   (%rax)

000000000022c520 <pf_call_17>:
  22c520:	0f 18 15 e9 f6 f1 ff 	prefetcht1 -0xe0917(%rip)        # 14bc10 <pf_target_17_0>

000000000022c527 <pf_jump_17>:
  22c527:	e9 b4 41 e7 ff       	jmp    a06e0 <pf_callee_16>
  22c52c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c530 <pf_call_18>:
  22c530:	0f 18 15 e9 55 ef ff 	prefetcht1 -0x10aa17(%rip)        # 121b20 <pf_target_18_0>

000000000022c537 <pf_jump_18>:
  22c537:	e9 b4 5b e7 ff       	jmp    a20f0 <pf_callee_18>
  22c53c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c540 <pf_call_19>:
  22c540:	41 53                	push   %r11
  22c542:	4c 8b 1d ef a6 ff ff 	mov    -0x5911(%rip),%r11        # 226c38 <pf_got_19_0>

000000000022c549 <pf_got_hint_19_0>:
  22c549:	41 0f 18 93 20 95 10 	prefetcht1 0x109520(%r11)
  22c550:	00 
  22c551:	41 5b                	pop    %r11

000000000022c553 <pf_jump_19>:
  22c553:	e9 78 45 e7 ff       	jmp    a0ad0 <pf_callee_19>
  22c558:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  22c55f:	00 

000000000022c560 <pf_call_20>:
  22c560:	0f 18 15 79 41 e7 ff 	prefetcht1 -0x18be87(%rip)        # a06e0 <pf_callee_16>
  22c567:	0f 18 15 e2 fa f1 ff 	prefetcht1 -0xe051e(%rip)        # 14c050 <pf_target_20_1>
  22c56e:	0f 18 15 0f fb f1 ff 	prefetcht1 -0xe04f1(%rip)        # 14c084 <pf_target_20_2>
  22c575:	0f 18 15 f4 23 e8 ff 	prefetcht1 -0x17dc0c(%rip)        # ae970 <pf_target_20_3>
  22c57c:	0f 18 15 8d f6 f1 ff 	prefetcht1 -0xe0973(%rip)        # 14bc10 <pf_target_17_0>
  22c583:	0f 18 15 16 26 e7 ff 	prefetcht1 -0x18d9ea(%rip)        # 9eba0 <pf_target_20_5>

000000000022c58a <pf_jump_20>:
  22c58a:	e9 41 5a e7 ff       	jmp    a1fd0 <pf_callee_20>
  22c58f:	90                   	nop

000000000022c590 <pf_call_21>:
  22c590:	41 53                	push   %r11
  22c592:	4c 8b 1d 9f a6 ff ff 	mov    -0x5961(%rip),%r11        # 226c38 <pf_got_19_0>

000000000022c599 <pf_got_hint_21_0>:
  22c599:	41 0f 18 93 c0 cd 10 	prefetcht1 0x10cdc0(%r11)
  22c5a0:	00 
  22c5a1:	41 5b                	pop    %r11

000000000022c5a3 <pf_jump_21>:
  22c5a3:	e9 08 36 e7 ff       	jmp    9fbb0 <pf_callee_21>
