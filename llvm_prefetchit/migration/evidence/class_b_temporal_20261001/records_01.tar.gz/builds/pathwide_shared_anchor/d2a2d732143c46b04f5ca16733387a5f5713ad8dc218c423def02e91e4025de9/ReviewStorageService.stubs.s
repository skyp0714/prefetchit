.text
.balign 16
.global pf_call_0
.type pf_call_0,@function
pf_call_0:
.cfi_startproc
prefetcht1 pf_target_0_0(%rip)
prefetcht1 pf_target_0_1(%rip)
prefetcht1 pf_target_0_2(%rip)
prefetcht1 pf_target_0_3(%rip)
prefetcht1 pf_target_0_4(%rip)
prefetcht1 pf_target_0_5(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_0_0(%rip),%r11
.global pf_got_hint_0_0
pf_got_hint_0_0:
.byte 0x41,0x0f,0x18,0x93
.long -722768
.global pf_got_hint_0_1
pf_got_hint_0_1:
.byte 0x41,0x0f,0x18,0x93
.long 0
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_0
pf_jump_0:
jmp pf_callee_0
.cfi_endproc
.size pf_call_0,.-pf_call_0
.balign 16
.global pf_call_1
.type pf_call_1,@function
pf_call_1:
.cfi_startproc
prefetcht1 pf_target_1_0(%rip)
.global pf_jump_1
pf_jump_1:
jmp pf_callee_1
.cfi_endproc
.size pf_call_1,.-pf_call_1
.balign 16
.global pf_call_2
.type pf_call_2,@function
pf_call_2:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_2_0(%rip),%r11
.global pf_got_hint_2_0
pf_got_hint_2_0:
.byte 0x41,0x0f,0x18,0x93
.long 9216
mov pf_got_2_1(%rip),%r11
.global pf_got_hint_2_1
pf_got_hint_2_1:
.byte 0x41,0x0f,0x18,0x93
.long -741611
.global pf_got_hint_2_2
pf_got_hint_2_2:
.byte 0x41,0x0f,0x18,0x93
.long -737008
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_2
pf_jump_2:
jmp pf_callee_2
.cfi_endproc
.size pf_call_2,.-pf_call_2
.balign 16
.global pf_call_3
.type pf_call_3,@function
pf_call_3:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_3_0(%rip),%r11
.global pf_got_hint_3_0
pf_got_hint_3_0:
.byte 0x41,0x0f,0x18,0x93
.long 621872
.global pf_got_hint_3_1
pf_got_hint_3_1:
.byte 0x41,0x0f,0x18,0x93
.long 621924
mov pf_got_3_2(%rip),%r11
.global pf_got_hint_3_2
pf_got_hint_3_2:
.byte 0x41,0x0f,0x18,0x93
.long -718688
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_3
pf_jump_3:
jmp pf_callee_3
.cfi_endproc
.size pf_call_3,.-pf_call_3
.balign 16
.global pf_call_4
.type pf_call_4,@function
pf_call_4:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_4_0(%rip),%r11
.global pf_got_hint_4_0
pf_got_hint_4_0:
.byte 0x41,0x0f,0x18,0x93
.long 61664
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_4
pf_jump_4:
jmp pf_callee_4
.cfi_endproc
.size pf_call_4,.-pf_call_4
.balign 16
.global pf_call_5
.type pf_call_5,@function
pf_call_5:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_5_0(%rip),%r11
.global pf_got_hint_5_0
pf_got_hint_5_0:
.byte 0x41,0x0f,0x18,0x93
.long -1049469
mov pf_got_5_1(%rip),%r11
.global pf_got_hint_5_1
pf_got_hint_5_1:
.byte 0x41,0x0f,0x18,0x93
.long 61456
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_5
pf_jump_5:
jmp pf_callee_5
.cfi_endproc
.size pf_call_5,.-pf_call_5
.balign 16
.global pf_call_6
.type pf_call_6,@function
pf_call_6:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_6_0(%rip),%r11
.global pf_got_hint_6_0
pf_got_hint_6_0:
.byte 0x41,0x0f,0x18,0x93
.long -26432
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_6
pf_jump_6:
jmp pf_callee_6
.cfi_endproc
.size pf_call_6,.-pf_call_6
.balign 16
.global pf_call_7
.type pf_call_7,@function
pf_call_7:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_7_0(%rip),%r11
.global pf_got_hint_7_0
pf_got_hint_7_0:
.byte 0x41,0x0f,0x18,0x93
.long -6064
.global pf_got_hint_7_1
pf_got_hint_7_1:
.byte 0x41,0x0f,0x18,0x93
.long -6031
.global pf_got_hint_7_2
pf_got_hint_7_2:
.byte 0x41,0x0f,0x18,0x93
.long 2154
.global pf_got_hint_7_3
pf_got_hint_7_3:
.byte 0x41,0x0f,0x18,0x93
.long 2224
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_7
pf_jump_7:
jmp pf_callee_7
.cfi_endproc
.size pf_call_7,.-pf_call_7
.balign 16
.global pf_call_8
.type pf_call_8,@function
pf_call_8:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_8_0(%rip),%r11
.global pf_got_hint_8_0
pf_got_hint_8_0:
.byte 0x41,0x0f,0x18,0x93
.long -288
.global pf_got_hint_8_1
pf_got_hint_8_1:
.byte 0x41,0x0f,0x18,0x93
.long -267
.global pf_got_hint_8_2
pf_got_hint_8_2:
.byte 0x41,0x0f,0x18,0x93
.long -205
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_8
pf_jump_8:
jmp pf_callee_8
.cfi_endproc
.size pf_call_8,.-pf_call_8
.balign 16
.global pf_call_9
.type pf_call_9,@function
pf_call_9:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_9_0(%rip),%r11
.global pf_got_hint_9_0
pf_got_hint_9_0:
.byte 0x41,0x0f,0x18,0x93
.long -92304
.global pf_got_hint_9_1
pf_got_hint_9_1:
.byte 0x41,0x0f,0x18,0x93
.long -82576
.global pf_got_hint_9_2
pf_got_hint_9_2:
.byte 0x41,0x0f,0x18,0x93
.long 100784
.global pf_got_hint_9_3
pf_got_hint_9_3:
.byte 0x41,0x0f,0x18,0x93
.long 219056
.global pf_got_hint_9_4
pf_got_hint_9_4:
.byte 0x41,0x0f,0x18,0x93
.long 219696
mov pf_got_9_5(%rip),%r11
.global pf_got_hint_9_5
pf_got_hint_9_5:
.byte 0x41,0x0f,0x18,0x93
.long 7616
.global pf_got_hint_9_6
pf_got_hint_9_6:
.byte 0x41,0x0f,0x18,0x93
.long 16368
.global pf_got_hint_9_7
pf_got_hint_9_7:
.byte 0x41,0x0f,0x18,0x93
.long 27792
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_9
pf_jump_9:
jmp pf_callee_9
.cfi_endproc
.size pf_call_9,.-pf_call_9
.balign 16
.global pf_call_10
.type pf_call_10,@function
pf_call_10:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_10_0(%rip),%r11
.global pf_got_hint_10_0
pf_got_hint_10_0:
.byte 0x41,0x0f,0x18,0x93
.long -852368
.global pf_got_hint_10_1
pf_got_hint_10_1:
.byte 0x41,0x0f,0x18,0x93
.long -769110
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_10
pf_jump_10:
jmp pf_callee_10
.cfi_endproc
.size pf_call_10,.-pf_call_10
.balign 16
.global pf_call_11
.type pf_call_11,@function
pf_call_11:
.cfi_startproc
prefetcht1 pf_target_11_0(%rip)
.global pf_jump_11
pf_jump_11:
jmp pf_callee_11
.cfi_endproc
.size pf_call_11,.-pf_call_11
.balign 16
.global pf_call_12
.type pf_call_12,@function
pf_call_12:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_12_0(%rip),%r11
.global pf_got_hint_12_0
pf_got_hint_12_0:
.byte 0x41,0x0f,0x18,0x93
.long 0
.global pf_got_hint_12_1
pf_got_hint_12_1:
.byte 0x41,0x0f,0x18,0x93
.long 100850
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_12
pf_jump_12:
jmp pf_callee_12
.cfi_endproc
.size pf_call_12,.-pf_call_12
.balign 16
.global pf_call_13
.type pf_call_13,@function
pf_call_13:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_13_0(%rip),%r11
.global pf_got_hint_13_0
pf_got_hint_13_0:
.byte 0x41,0x0f,0x18,0x93
.long 517664
.global pf_got_hint_13_1
pf_got_hint_13_1:
.byte 0x41,0x0f,0x18,0x93
.long 533456
.global pf_got_hint_13_2
pf_got_hint_13_2:
.byte 0x41,0x0f,0x18,0x93
.long 533473
.global pf_got_hint_13_3
pf_got_hint_13_3:
.byte 0x41,0x0f,0x18,0x93
.long 534208
.global pf_got_hint_13_4
pf_got_hint_13_4:
.byte 0x41,0x0f,0x18,0x93
.long 586576
.global pf_got_hint_13_5
pf_got_hint_13_5:
.byte 0x41,0x0f,0x18,0x93
.long 586592
.global pf_got_hint_13_6
pf_got_hint_13_6:
.byte 0x41,0x0f,0x18,0x93
.long 591648
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_13
pf_jump_13:
jmp pf_callee_13
.cfi_endproc
.size pf_call_13,.-pf_call_13
.balign 16
.global pf_call_14
.type pf_call_14,@function
pf_call_14:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_14_0(%rip),%r11
.global pf_got_hint_14_0
pf_got_hint_14_0:
.byte 0x41,0x0f,0x18,0x93
.long -36592
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_14
pf_jump_14:
jmp pf_callee_14
.cfi_endproc
.size pf_call_14,.-pf_call_14
.balign 16
.global pf_call_15
.type pf_call_15,@function
pf_call_15:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_15_0(%rip),%r11
.global pf_got_hint_15_0
pf_got_hint_15_0:
.byte 0x41,0x0f,0x18,0x93
.long 619600
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_15
pf_jump_15:
jmp pf_callee_15
.cfi_endproc
.size pf_call_15,.-pf_call_15
.balign 16
.global pf_call_16
.type pf_call_16,@function
pf_call_16:
.cfi_startproc
prefetcht1 pf_target_16_0(%rip)
prefetcht1 pf_target_16_1(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_16_0(%rip),%r11
.global pf_got_hint_16_0
pf_got_hint_16_0:
.byte 0x41,0x0f,0x18,0x93
.long 619617
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_16
pf_jump_16:
jmp pf_callee_16
.cfi_endproc
.size pf_call_16,.-pf_call_16
.balign 16
.global pf_call_17
.type pf_call_17,@function
pf_call_17:
.cfi_startproc
prefetcht1 pf_target_17_0(%rip)
prefetcht1 pf_target_17_1(%rip)
.global pf_jump_17
pf_jump_17:
jmp pf_callee_17
.cfi_endproc
.size pf_call_17,.-pf_call_17
.balign 16
.global pf_call_18
.type pf_call_18,@function
pf_call_18:
.cfi_startproc
prefetcht1 pf_target_18_0(%rip)
prefetcht1 pf_target_18_1(%rip)
.global pf_jump_18
pf_jump_18:
jmp pf_callee_18
.cfi_endproc
.size pf_call_18,.-pf_call_18
.balign 16
.global pf_call_19
.type pf_call_19,@function
pf_call_19:
.cfi_startproc
prefetcht1 pf_target_19_0(%rip)
.global pf_jump_19
pf_jump_19:
jmp pf_callee_19
.cfi_endproc
.size pf_call_19,.-pf_call_19
.balign 16
.global pf_call_20
.type pf_call_20,@function
pf_call_20:
.cfi_startproc
prefetcht1 pf_target_20_0(%rip)
.global pf_jump_20
pf_jump_20:
jmp pf_callee_20
.cfi_endproc
.size pf_call_20,.-pf_call_20
.balign 16
.global pf_call_21
.type pf_call_21,@function
pf_call_21:
.cfi_startproc
prefetcht1 pf_target_21_0(%rip)
.global pf_jump_21
pf_jump_21:
jmp pf_callee_21
.cfi_endproc
.size pf_call_21,.-pf_call_21
.balign 16
.global pf_call_22
.type pf_call_22,@function
pf_call_22:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_22_0(%rip),%r11
.global pf_got_hint_22_0
pf_got_hint_22_0:
.byte 0x41,0x0f,0x18,0x93
.long 474208
.global pf_got_hint_22_1
pf_got_hint_22_1:
.byte 0x41,0x0f,0x18,0x93
.long 476144
.global pf_got_hint_22_2
pf_got_hint_22_2:
.byte 0x41,0x0f,0x18,0x93
.long 476192
mov pf_got_22_3(%rip),%r11
.global pf_got_hint_22_3
pf_got_hint_22_3:
.byte 0x41,0x0f,0x18,0x93
.long -858752
.global pf_got_hint_22_4
pf_got_hint_22_4:
.byte 0x41,0x0f,0x18,0x93
.long -749744
.global pf_got_hint_22_5
pf_got_hint_22_5:
.byte 0x41,0x0f,0x18,0x93
.long -749676
.global pf_got_hint_22_6
pf_got_hint_22_6:
.byte 0x41,0x0f,0x18,0x93
.long -749608
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_22
pf_jump_22:
jmp pf_callee_22
.cfi_endproc
.size pf_call_22,.-pf_call_22
.balign 16
.global pf_call_23
.type pf_call_23,@function
pf_call_23:
.cfi_startproc
prefetcht1 pf_target_23_0(%rip)
prefetcht1 pf_target_23_1(%rip)
.global pf_jump_23
pf_jump_23:
jmp pf_callee_23
.cfi_endproc
.size pf_call_23,.-pf_call_23
.balign 16
.global pf_call_24
.type pf_call_24,@function
pf_call_24:
.cfi_startproc
prefetcht1 pf_target_24_0(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_24_0(%rip),%r11
.global pf_got_hint_24_0
pf_got_hint_24_0:
.byte 0x41,0x0f,0x18,0x93
.long -51312
.global pf_got_hint_24_1
pf_got_hint_24_1:
.byte 0x41,0x0f,0x18,0x93
.long 187840
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_24
pf_jump_24:
jmp pf_callee_24
.cfi_endproc
.size pf_call_24,.-pf_call_24
.balign 16
.global pf_call_25
.type pf_call_25,@function
pf_call_25:
.cfi_startproc
prefetcht1 pf_target_25_0(%rip)
.global pf_jump_25
pf_jump_25:
jmp pf_callee_25
.cfi_endproc
.size pf_call_25,.-pf_call_25
.balign 16
.global pf_call_26
.type pf_call_26,@function
pf_call_26:
.cfi_startproc
prefetcht1 pf_target_26_0(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_26_0(%rip),%r11
.global pf_got_hint_26_0
pf_got_hint_26_0:
.byte 0x41,0x0f,0x18,0x93
.long 105184
.global pf_got_hint_26_1
pf_got_hint_26_1:
.byte 0x41,0x0f,0x18,0x93
.long 105864
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_26
pf_jump_26:
jmp pf_callee_26
.cfi_endproc
.size pf_call_26,.-pf_call_26
.balign 16
.global pf_call_27
.type pf_call_27,@function
pf_call_27:
.cfi_startproc
prefetcht1 pf_target_27_0(%rip)
prefetcht1 pf_target_27_1(%rip)
prefetcht1 pf_target_27_2(%rip)
prefetcht1 pf_target_27_3(%rip)
prefetcht1 pf_target_27_4(%rip)
.global pf_jump_27
pf_jump_27:
jmp pf_callee_27
.cfi_endproc
.size pf_call_27,.-pf_call_27
.balign 16
.global pf_call_28
.type pf_call_28,@function
pf_call_28:
.cfi_startproc
prefetcht1 pf_target_28_0(%rip)
.global pf_jump_28
pf_jump_28:
jmp pf_callee_28
.cfi_endproc
.size pf_call_28,.-pf_call_28
.balign 16
.global pf_call_29
.type pf_call_29,@function
pf_call_29:
.cfi_startproc
prefetcht1 pf_target_29_0(%rip)
prefetcht1 pf_target_29_1(%rip)
prefetcht1 pf_target_29_2(%rip)
prefetcht1 pf_target_29_3(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_29_0(%rip),%r11
.global pf_got_hint_29_0
pf_got_hint_29_0:
.byte 0x41,0x0f,0x18,0x93
.long 656544
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_29
pf_jump_29:
jmp pf_callee_29
.cfi_endproc
.size pf_call_29,.-pf_call_29
.balign 16
.global pf_call_30
.type pf_call_30,@function
pf_call_30:
.cfi_startproc
prefetcht1 pf_target_30_0(%rip)
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_30_0(%rip),%r11
.global pf_got_hint_30_0
pf_got_hint_30_0:
.byte 0x41,0x0f,0x18,0x93
.long -44112
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_30
pf_jump_30:
jmp pf_callee_30
.cfi_endproc
.size pf_call_30,.-pf_call_30
.balign 16
.global pf_call_31
.type pf_call_31,@function
pf_call_31:
.cfi_startproc
prefetcht1 pf_target_31_0(%rip)
.global pf_jump_31
pf_jump_31:
jmp pf_callee_31
.cfi_endproc
.size pf_call_31,.-pf_call_31
.balign 16
.global pf_call_32
.type pf_call_32,@function
pf_call_32:
.cfi_startproc
prefetcht1 pf_target_32_0(%rip)
prefetcht1 pf_target_32_1(%rip)
prefetcht1 pf_target_32_2(%rip)
.global pf_jump_32
pf_jump_32:
jmp pf_callee_32
.cfi_endproc
.size pf_call_32,.-pf_call_32
.balign 16
.global pf_call_33
.type pf_call_33,@function
pf_call_33:
.cfi_startproc
push %r11
.cfi_adjust_cfa_offset 8
.cfi_offset %r11,-16
mov pf_got_33_0(%rip),%r11
.global pf_got_hint_33_0
pf_got_hint_33_0:
.byte 0x41,0x0f,0x18,0x93
.long 1840
pop %r11
.cfi_adjust_cfa_offset -8
.cfi_restore %r11
.global pf_jump_33
pf_jump_33:
jmp pf_callee_33
.cfi_endproc
.size pf_call_33,.-pf_call_33
.balign 16
.global pf_call_34
.type pf_call_34,@function
pf_call_34:
.cfi_startproc
prefetcht1 pf_target_34_0(%rip)
prefetcht1 pf_target_34_1(%rip)
prefetcht1 pf_target_34_2(%rip)
prefetcht1 pf_target_34_3(%rip)
.global pf_jump_34
pf_jump_34:
jmp pf_callee_34
.cfi_endproc
.size pf_call_34,.-pf_call_34
.section .note.GNU-stack,"",@progbits
