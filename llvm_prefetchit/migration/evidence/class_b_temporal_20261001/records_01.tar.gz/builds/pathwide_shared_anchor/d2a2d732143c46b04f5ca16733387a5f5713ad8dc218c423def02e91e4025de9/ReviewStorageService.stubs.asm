
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_shared_anchor/d2a2d732143c46b04f5ca16733387a5f5713ad8dc218c423def02e91e4025de9/call-stub-tebi84h1/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000010b340 <pf_call_0>:
  10b340:	0f 18 15 bc 06 f4 ff 	prefetcht1 -0xbf944(%rip)        # 4ba03 <pf_target_0_0>
  10b347:	0f 18 15 f5 06 f4 ff 	prefetcht1 -0xbf90b(%rip)        # 4ba43 <pf_target_0_1>
  10b34e:	0f 18 15 5b 10 f4 ff 	prefetcht1 -0xbefa5(%rip)        # 4c3b0 <pf_target_0_2>
  10b355:	0f 18 15 c4 5c f4 ff 	prefetcht1 -0xba33c(%rip)        # 51020 <pf_target_0_3>
  10b35c:	0f 18 15 dd 05 f4 ff 	prefetcht1 -0xbfa23(%rip)        # 4b940 <pf_target_0_4>
  10b363:	0f 18 15 16 5d f4 ff 	prefetcht1 -0xba2ea(%rip)        # 51080 <pf_target_0_5>
  10b36a:	41 53                	push   %r11
  10b36c:	4c 8b 1d ad de ff ff 	mov    -0x2153(%rip),%r11        # 109220 <pf_got_0_0>

000000000010b373 <pf_got_hint_0_0>:
  10b373:	41 0f 18 93 b0 f8 f4 	prefetcht1 -0xb0750(%r11)
  10b37a:	ff 

000000000010b37b <pf_got_hint_0_1>:
  10b37b:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b382:	00 
  10b383:	41 5b                	pop    %r11

000000000010b385 <pf_jump_0>:
  10b385:	e9 b6 c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b38a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000010b390 <pf_call_1>:
  10b390:	0f 18 15 79 e2 f2 ff 	prefetcht1 -0xd1d87(%rip)        # 39610 <pf_callee_2>

000000000010b397 <pf_jump_1>:
  10b397:	e9 a4 c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b39c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b3a0 <pf_call_2>:
  10b3a0:	41 53                	push   %r11
  10b3a2:	4c 8b 1d 2f dd ff ff 	mov    -0x22d1(%rip),%r11        # 1090d8 <pf_got_13_0>

000000000010b3a9 <pf_got_hint_2_0>:
  10b3a9:	41 0f 18 93 00 24 00 	prefetcht1 0x2400(%r11)
  10b3b0:	00 
  10b3b1:	4c 8b 1d 68 de ff ff 	mov    -0x2198(%rip),%r11        # 109220 <pf_got_0_0>

000000000010b3b8 <pf_got_hint_2_1>:
  10b3b8:	41 0f 18 93 15 af f4 	prefetcht1 -0xb50eb(%r11)
  10b3bf:	ff 

000000000010b3c0 <pf_got_hint_2_2>:
  10b3c0:	41 0f 18 93 10 c1 f4 	prefetcht1 -0xb3ef0(%r11)
  10b3c7:	ff 
  10b3c8:	41 5b                	pop    %r11

000000000010b3ca <pf_jump_2>:
  10b3ca:	e9 41 e2 f2 ff       	jmp    39610 <pf_callee_2>
  10b3cf:	90                   	nop

000000000010b3d0 <pf_call_3>:
  10b3d0:	41 53                	push   %r11
  10b3d2:	4c 8b 1d ff dc ff ff 	mov    -0x2301(%rip),%r11        # 1090d8 <pf_got_13_0>

000000000010b3d9 <pf_got_hint_3_0>:
  10b3d9:	41 0f 18 93 30 7d 09 	prefetcht1 0x97d30(%r11)
  10b3e0:	00 

000000000010b3e1 <pf_got_hint_3_1>:
  10b3e1:	41 0f 18 93 64 7d 09 	prefetcht1 0x97d64(%r11)
  10b3e8:	00 
  10b3e9:	4c 8b 1d 30 de ff ff 	mov    -0x21d0(%rip),%r11        # 109220 <pf_got_0_0>

000000000010b3f0 <pf_got_hint_3_2>:
  10b3f0:	41 0f 18 93 a0 08 f5 	prefetcht1 -0xaf760(%r11)
  10b3f7:	ff 
  10b3f8:	41 5b                	pop    %r11

000000000010b3fa <pf_jump_3>:
  10b3fa:	e9 41 c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b3ff:	90                   	nop

000000000010b400 <pf_call_4>:
  10b400:	41 53                	push   %r11
  10b402:	4c 8b 1d 77 e1 ff ff 	mov    -0x1e89(%rip),%r11        # 109580 <pf_got_4_0>

000000000010b409 <pf_got_hint_4_0>:
  10b409:	41 0f 18 93 e0 f0 00 	prefetcht1 0xf0e0(%r11)
  10b410:	00 
  10b411:	41 5b                	pop    %r11

000000000010b413 <pf_jump_4>:
  10b413:	e9 d8 c7 f1 ff       	jmp    27bf0 <pf_callee_4>
  10b418:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b41f:	00 

000000000010b420 <pf_call_5>:
  10b420:	41 53                	push   %r11
  10b422:	4c 8b 1d 77 dc ff ff 	mov    -0x2389(%rip),%r11        # 1090a0 <pf_got_5_0>

000000000010b429 <pf_got_hint_5_0>:
  10b429:	41 0f 18 93 83 fc ef 	prefetcht1 -0x10037d(%r11)
  10b430:	ff 
  10b431:	4c 8b 1d 48 e1 ff ff 	mov    -0x1eb8(%rip),%r11        # 109580 <pf_got_4_0>

000000000010b438 <pf_got_hint_5_1>:
  10b438:	41 0f 18 93 10 f0 00 	prefetcht1 0xf010(%r11)
  10b43f:	00 
  10b440:	41 5b                	pop    %r11

000000000010b442 <pf_jump_5>:
  10b442:	e9 a9 c8 f1 ff       	jmp    27cf0 <pf_callee_5>
  10b447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  10b44e:	00 00 

000000000010b450 <pf_call_6>:
  10b450:	41 53                	push   %r11
  10b452:	4c 8b 1d 27 e1 ff ff 	mov    -0x1ed9(%rip),%r11        # 109580 <pf_got_4_0>

000000000010b459 <pf_got_hint_6_0>:
  10b459:	41 0f 18 93 c0 98 ff 	prefetcht1 -0x6740(%r11)
  10b460:	ff 
  10b461:	41 5b                	pop    %r11

000000000010b463 <pf_jump_6>:
  10b463:	e9 d8 cc f1 ff       	jmp    28140 <pf_callee_6>
  10b468:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b46f:	00 

000000000010b470 <pf_call_7>:
  10b470:	41 53                	push   %r11
  10b472:	4c 8b 1d 07 e1 ff ff 	mov    -0x1ef9(%rip),%r11        # 109580 <pf_got_4_0>

000000000010b479 <pf_got_hint_7_0>:
  10b479:	41 0f 18 93 50 e8 ff 	prefetcht1 -0x17b0(%r11)
  10b480:	ff 

000000000010b481 <pf_got_hint_7_1>:
  10b481:	41 0f 18 93 71 e8 ff 	prefetcht1 -0x178f(%r11)
  10b488:	ff 

000000000010b489 <pf_got_hint_7_2>:
  10b489:	41 0f 18 93 6a 08 00 	prefetcht1 0x86a(%r11)
  10b490:	00 

000000000010b491 <pf_got_hint_7_3>:
  10b491:	41 0f 18 93 b0 08 00 	prefetcht1 0x8b0(%r11)
  10b498:	00 
  10b499:	41 5b                	pop    %r11

000000000010b49b <pf_jump_7>:
  10b49b:	e9 e0 c1 f1 ff       	jmp    27680 <pf_callee_7>

000000000010b4a0 <pf_call_8>:
  10b4a0:	41 53                	push   %r11
  10b4a2:	4c 8b 1d d7 e0 ff ff 	mov    -0x1f29(%rip),%r11        # 109580 <pf_got_4_0>

000000000010b4a9 <pf_got_hint_8_0>:
  10b4a9:	41 0f 18 93 e0 fe ff 	prefetcht1 -0x120(%r11)
  10b4b0:	ff 

000000000010b4b1 <pf_got_hint_8_1>:
  10b4b1:	41 0f 18 93 f5 fe ff 	prefetcht1 -0x10b(%r11)
  10b4b8:	ff 

000000000010b4b9 <pf_got_hint_8_2>:
  10b4b9:	41 0f 18 93 33 ff ff 	prefetcht1 -0xcd(%r11)
  10b4c0:	ff 
  10b4c1:	41 5b                	pop    %r11

000000000010b4c3 <pf_jump_8>:
  10b4c3:	e9 08 cb f1 ff       	jmp    27fd0 <pf_callee_8>
  10b4c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b4cf:	00 

000000000010b4d0 <pf_call_9>:
  10b4d0:	41 53                	push   %r11
  10b4d2:	4c 8b 1d 6f e0 ff ff 	mov    -0x1f91(%rip),%r11        # 109548 <pf_got_12_0>

000000000010b4d9 <pf_got_hint_9_0>:
  10b4d9:	41 0f 18 93 70 97 fe 	prefetcht1 -0x16890(%r11)
  10b4e0:	ff 

000000000010b4e1 <pf_got_hint_9_1>:
  10b4e1:	41 0f 18 93 70 bd fe 	prefetcht1 -0x14290(%r11)
  10b4e8:	ff 

000000000010b4e9 <pf_got_hint_9_2>:
  10b4e9:	41 0f 18 93 b0 89 01 	prefetcht1 0x189b0(%r11)
  10b4f0:	00 

000000000010b4f1 <pf_got_hint_9_3>:
  10b4f1:	41 0f 18 93 b0 57 03 	prefetcht1 0x357b0(%r11)
  10b4f8:	00 

000000000010b4f9 <pf_got_hint_9_4>:
  10b4f9:	41 0f 18 93 30 5a 03 	prefetcht1 0x35a30(%r11)
  10b500:	00 
  10b501:	4c 8b 1d 78 e0 ff ff 	mov    -0x1f88(%rip),%r11        # 109580 <pf_got_4_0>

000000000010b508 <pf_got_hint_9_5>:
  10b508:	41 0f 18 93 c0 1d 00 	prefetcht1 0x1dc0(%r11)
  10b50f:	00 

000000000010b510 <pf_got_hint_9_6>:
  10b510:	41 0f 18 93 f0 3f 00 	prefetcht1 0x3ff0(%r11)
  10b517:	00 

000000000010b518 <pf_got_hint_9_7>:
  10b518:	41 0f 18 93 90 6c 00 	prefetcht1 0x6c90(%r11)
  10b51f:	00 
  10b520:	41 5b                	pop    %r11

000000000010b522 <pf_jump_9>:
  10b522:	e9 69 c5 f1 ff       	jmp    27a90 <pf_callee_9>
  10b527:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  10b52e:	00 00 

000000000010b530 <pf_call_10>:
  10b530:	41 53                	push   %r11
  10b532:	4c 8b 1d e7 dc ff ff 	mov    -0x2319(%rip),%r11        # 109220 <pf_got_0_0>

000000000010b539 <pf_got_hint_10_0>:
  10b539:	41 0f 18 93 70 fe f2 	prefetcht1 -0xd0190(%r11)
  10b540:	ff 

000000000010b541 <pf_got_hint_10_1>:
  10b541:	41 0f 18 93 aa 43 f4 	prefetcht1 -0xbbc56(%r11)
  10b548:	ff 
  10b549:	41 5b                	pop    %r11

000000000010b54b <pf_jump_10>:
  10b54b:	e9 00 cc f1 ff       	jmp    28150 <pf_callee_10>

000000000010b550 <pf_call_11>:
  10b550:	0f 18 15 99 c0 f1 ff 	prefetcht1 -0xe3f67(%rip)        # 275f0 <pf_target_11_0>

000000000010b557 <pf_jump_11>:
  10b557:	e9 44 67 f4 ff       	jmp    51ca0 <pf_callee_11>
  10b55c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b560 <pf_call_12>:
  10b560:	41 53                	push   %r11
  10b562:	4c 8b 1d df df ff ff 	mov    -0x2021(%rip),%r11        # 109548 <pf_got_12_0>

000000000010b569 <pf_got_hint_12_0>:
  10b569:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  10b570:	00 

000000000010b571 <pf_got_hint_12_1>:
  10b571:	41 0f 18 93 f2 89 01 	prefetcht1 0x189f2(%r11)
  10b578:	00 
  10b579:	41 5b                	pop    %r11

000000000010b57b <pf_jump_12>:
  10b57b:	e9 30 bc f1 ff       	jmp    271b0 <pf_callee_12>

000000000010b580 <pf_call_13>:
  10b580:	41 53                	push   %r11
  10b582:	4c 8b 1d 4f db ff ff 	mov    -0x24b1(%rip),%r11        # 1090d8 <pf_got_13_0>

000000000010b589 <pf_got_hint_13_0>:
  10b589:	41 0f 18 93 20 e6 07 	prefetcht1 0x7e620(%r11)
  10b590:	00 

000000000010b591 <pf_got_hint_13_1>:
  10b591:	41 0f 18 93 d0 23 08 	prefetcht1 0x823d0(%r11)
  10b598:	00 

000000000010b599 <pf_got_hint_13_2>:
  10b599:	41 0f 18 93 e1 23 08 	prefetcht1 0x823e1(%r11)
  10b5a0:	00 

000000000010b5a1 <pf_got_hint_13_3>:
  10b5a1:	41 0f 18 93 c0 26 08 	prefetcht1 0x826c0(%r11)
  10b5a8:	00 

000000000010b5a9 <pf_got_hint_13_4>:
  10b5a9:	41 0f 18 93 50 f3 08 	prefetcht1 0x8f350(%r11)
  10b5b0:	00 

000000000010b5b1 <pf_got_hint_13_5>:
  10b5b1:	41 0f 18 93 60 f3 08 	prefetcht1 0x8f360(%r11)
  10b5b8:	00 

000000000010b5b9 <pf_got_hint_13_6>:
  10b5b9:	41 0f 18 93 20 07 09 	prefetcht1 0x90720(%r11)
  10b5c0:	00 
  10b5c1:	41 5b                	pop    %r11

000000000010b5c3 <pf_jump_13>:
  10b5c3:	e9 68 25 f4 ff       	jmp    4db30 <pf_callee_13>
  10b5c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b5cf:	00 

000000000010b5d0 <pf_call_14>:
  10b5d0:	41 53                	push   %r11
  10b5d2:	4c 8b 1d 6f df ff ff 	mov    -0x2091(%rip),%r11        # 109548 <pf_got_12_0>

000000000010b5d9 <pf_got_hint_14_0>:
  10b5d9:	41 0f 18 93 10 71 ff 	prefetcht1 -0x8ef0(%r11)
  10b5e0:	ff 
  10b5e1:	41 5b                	pop    %r11

000000000010b5e3 <pf_jump_14>:
  10b5e3:	e9 48 cc f1 ff       	jmp    28230 <pf_callee_14>
  10b5e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b5ef:	00 

000000000010b5f0 <pf_call_15>:
  10b5f0:	41 53                	push   %r11
  10b5f2:	4c 8b 1d df da ff ff 	mov    -0x2521(%rip),%r11        # 1090d8 <pf_got_13_0>

000000000010b5f9 <pf_got_hint_15_0>:
  10b5f9:	41 0f 18 93 50 74 09 	prefetcht1 0x97450(%r11)
  10b600:	00 
  10b601:	41 5b                	pop    %r11

000000000010b603 <pf_jump_15>:
  10b603:	e9 38 bb f1 ff       	jmp    27140 <pf_callee_15>
  10b608:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b60f:	00 

000000000010b610 <pf_call_16>:
  10b610:	0f 18 15 c9 c1 f1 ff 	prefetcht1 -0xe3e37(%rip)        # 277e0 <pf_target_16_0>
  10b617:	0f 18 15 a5 09 f4 ff 	prefetcht1 -0xbf65b(%rip)        # 4bfc3 <pf_target_16_1>
  10b61e:	41 53                	push   %r11
  10b620:	4c 8b 1d b1 da ff ff 	mov    -0x254f(%rip),%r11        # 1090d8 <pf_got_13_0>

000000000010b627 <pf_got_hint_16_0>:
  10b627:	41 0f 18 93 61 74 09 	prefetcht1 0x97461(%r11)
  10b62e:	00 
  10b62f:	41 5b                	pop    %r11

000000000010b631 <pf_jump_16>:
  10b631:	e9 0a bb f1 ff       	jmp    27140 <pf_callee_15>
  10b636:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b63d:	00 00 00 

000000000010b640 <pf_call_17>:
  10b640:	0f 18 15 a9 be f1 ff 	prefetcht1 -0xe4157(%rip)        # 274f0 <pf_target_17_0>
  10b647:	0f 18 15 3c d2 f3 ff 	prefetcht1 -0xc2dc4(%rip)        # 4888a <pf_target_17_1>

000000000010b64e <pf_jump_17>:
  10b64e:	e9 8d d1 f3 ff       	jmp    487e0 <pf_callee_17>
  10b653:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b65a:	00 00 00 
  10b65d:	0f 1f 00             	nopl   (%rax)

000000000010b660 <pf_call_18>:
  10b660:	0f 18 15 b9 09 f4 ff 	prefetcht1 -0xbf647(%rip)        # 4c020 <pf_target_18_0>
  10b667:	0f 18 15 d5 09 f4 ff 	prefetcht1 -0xbf62b(%rip)        # 4c043 <pf_target_18_1>

000000000010b66e <pf_jump_18>:
  10b66e:	e9 ed 0d f4 ff       	jmp    4c460 <pf_callee_18>
  10b673:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b67a:	00 00 00 
  10b67d:	0f 1f 00             	nopl   (%rax)

000000000010b680 <pf_call_19>:
  10b680:	0f 18 15 89 22 f4 ff 	prefetcht1 -0xbdd77(%rip)        # 4d910 <pf_target_19_0>

000000000010b687 <pf_jump_19>:
  10b687:	e9 24 bb f1 ff       	jmp    271b0 <pf_callee_12>
  10b68c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b690 <pf_call_20>:
  10b690:	0f 18 15 09 09 f4 ff 	prefetcht1 -0xbf6f7(%rip)        # 4bfa0 <pf_target_20_0>

000000000010b697 <pf_jump_20>:
  10b697:	e9 a4 ba f1 ff       	jmp    27140 <pf_callee_15>
  10b69c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b6a0 <pf_call_21>:
  10b6a0:	0f 18 15 f9 c9 f1 ff 	prefetcht1 -0xe3607(%rip)        # 280a0 <pf_target_21_0>

000000000010b6a7 <pf_jump_21>:
  10b6a7:	e9 04 bb f1 ff       	jmp    271b0 <pf_callee_12>
  10b6ac:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b6b0 <pf_call_22>:
  10b6b0:	41 53                	push   %r11
  10b6b2:	4c 8b 1d 1f da ff ff 	mov    -0x25e1(%rip),%r11        # 1090d8 <pf_got_13_0>

000000000010b6b9 <pf_got_hint_22_0>:
  10b6b9:	41 0f 18 93 60 3c 07 	prefetcht1 0x73c60(%r11)
  10b6c0:	00 

000000000010b6c1 <pf_got_hint_22_1>:
  10b6c1:	41 0f 18 93 f0 43 07 	prefetcht1 0x743f0(%r11)
  10b6c8:	00 

000000000010b6c9 <pf_got_hint_22_2>:
  10b6c9:	41 0f 18 93 20 44 07 	prefetcht1 0x74420(%r11)
  10b6d0:	00 
  10b6d1:	4c 8b 1d 48 db ff ff 	mov    -0x24b8(%rip),%r11        # 109220 <pf_got_0_0>

000000000010b6d8 <pf_got_hint_22_3>:
  10b6d8:	41 0f 18 93 80 e5 f2 	prefetcht1 -0xd1a80(%r11)
  10b6df:	ff 

000000000010b6e0 <pf_got_hint_22_4>:
  10b6e0:	41 0f 18 93 50 8f f4 	prefetcht1 -0xb70b0(%r11)
  10b6e7:	ff 

000000000010b6e8 <pf_got_hint_22_5>:
  10b6e8:	41 0f 18 93 94 8f f4 	prefetcht1 -0xb706c(%r11)
  10b6ef:	ff 

000000000010b6f0 <pf_got_hint_22_6>:
  10b6f0:	41 0f 18 93 d8 8f f4 	prefetcht1 -0xb7028(%r11)
  10b6f7:	ff 
  10b6f8:	41 5b                	pop    %r11

000000000010b6fa <pf_jump_22>:
  10b6fa:	e9 61 c4 f1 ff       	jmp    27b60 <pf_callee_22>
  10b6ff:	90                   	nop

000000000010b700 <pf_call_23>:
  10b700:	0f 18 15 a9 17 f4 ff 	prefetcht1 -0xbe857(%rip)        # 4ceb0 <pf_target_23_0>
  10b707:	0f 18 15 d2 d0 f3 ff 	prefetcht1 -0xc2f2e(%rip)        # 487e0 <pf_callee_17>

000000000010b70e <pf_jump_23>:
  10b70e:	e9 cd 1c f4 ff       	jmp    4d3e0 <pf_callee_23>
  10b713:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b71a:	00 00 00 
  10b71d:	0f 1f 00             	nopl   (%rax)

000000000010b720 <pf_call_24>:
  10b720:	0f 18 15 09 cb f1 ff 	prefetcht1 -0xe34f7(%rip)        # 28230 <pf_callee_14>
  10b727:	41 53                	push   %r11
  10b729:	4c 8b 1d a8 d9 ff ff 	mov    -0x2658(%rip),%r11        # 1090d8 <pf_got_13_0>

000000000010b730 <pf_got_hint_24_0>:
  10b730:	41 0f 18 93 90 37 ff 	prefetcht1 -0xc870(%r11)
  10b737:	ff 

000000000010b738 <pf_got_hint_24_1>:
  10b738:	41 0f 18 93 c0 dd 02 	prefetcht1 0x2ddc0(%r11)
  10b73f:	00 
  10b740:	41 5b                	pop    %r11

000000000010b742 <pf_jump_24>:
  10b742:	e9 99 d0 f3 ff       	jmp    487e0 <pf_callee_17>
  10b747:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  10b74e:	00 00 

000000000010b750 <pf_call_25>:
  10b750:	0f 18 15 39 5c f4 ff 	prefetcht1 -0xba3c7(%rip)        # 51390 <pf_target_25_0>

000000000010b757 <pf_jump_25>:
  10b757:	e9 d4 c4 f1 ff       	jmp    27c30 <pf_callee_25>
  10b75c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b760 <pf_call_26>:
  10b760:	0f 18 15 e9 cb f1 ff 	prefetcht1 -0xe3417(%rip)        # 28350 <pf_target_26_0>
  10b767:	41 53                	push   %r11
  10b769:	4c 8b 1d 68 d9 ff ff 	mov    -0x2698(%rip),%r11        # 1090d8 <pf_got_13_0>

000000000010b770 <pf_got_hint_26_0>:
  10b770:	41 0f 18 93 e0 9a 01 	prefetcht1 0x19ae0(%r11)
  10b777:	00 

000000000010b778 <pf_got_hint_26_1>:
  10b778:	41 0f 18 93 88 9d 01 	prefetcht1 0x19d88(%r11)
  10b77f:	00 
  10b780:	41 5b                	pop    %r11

000000000010b782 <pf_jump_26>:
  10b782:	e9 c9 61 f4 ff       	jmp    51950 <pf_callee_26>
  10b787:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  10b78e:	00 00 

000000000010b790 <pf_call_27>:
  10b790:	0f 18 15 a9 c1 f5 ff 	prefetcht1 -0xa3e57(%rip)        # 67940 <pf_target_27_0>
  10b797:	0f 18 15 82 c1 f5 ff 	prefetcht1 -0xa3e7e(%rip)        # 67920 <pf_target_27_1>
  10b79e:	0f 18 15 9b b6 f5 ff 	prefetcht1 -0xa4965(%rip)        # 66e40 <pf_target_27_2>
  10b7a5:	0f 18 15 84 0b f6 ff 	prefetcht1 -0x9f47c(%rip)        # 6c330 <pf_target_27_3>
  10b7ac:	0f 18 15 0d 59 f6 ff 	prefetcht1 -0x9a6f3(%rip)        # 710c0 <pf_callee_34>

000000000010b7b3 <pf_jump_27>:
  10b7b3:	e9 f8 b9 f1 ff       	jmp    271b0 <pf_callee_12>
  10b7b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b7bf:	00 

000000000010b7c0 <pf_call_28>:
  10b7c0:	0f 18 15 09 bf f5 ff 	prefetcht1 -0xa40f7(%rip)        # 676d0 <pf_target_28_0>

000000000010b7c7 <pf_jump_28>:
  10b7c7:	e9 d4 c0 f1 ff       	jmp    278a0 <pf_callee_28>
  10b7cc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b7d0 <pf_call_29>:
  10b7d0:	0f 18 15 c9 c0 f1 ff 	prefetcht1 -0xe3f37(%rip)        # 278a0 <pf_callee_28>
  10b7d7:	0f 18 15 ce 37 f6 ff 	prefetcht1 -0x9c832(%rip)        # 6efac <pf_target_29_1>
  10b7de:	0f 18 15 eb 01 f6 ff 	prefetcht1 -0x9fe15(%rip)        # 6b9d0 <pf_target_29_2>
  10b7e5:	0f 18 15 d4 cb f1 ff 	prefetcht1 -0xe342c(%rip)        # 283c0 <pf_callee_32>
  10b7ec:	41 53                	push   %r11
  10b7ee:	4c 8b 1d e3 d8 ff ff 	mov    -0x271d(%rip),%r11        # 1090d8 <pf_got_13_0>

000000000010b7f5 <pf_got_hint_29_0>:
  10b7f5:	41 0f 18 93 a0 04 0a 	prefetcht1 0xa04a0(%r11)
  10b7fc:	00 
  10b7fd:	41 5b                	pop    %r11

000000000010b7ff <pf_jump_29>:
  10b7ff:	e9 ec c5 f5 ff       	jmp    67df0 <pf_callee_29>
  10b804:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b80b:	00 00 00 
  10b80e:	66 90                	xchg   %ax,%ax

000000000010b810 <pf_call_30>:
  10b810:	0f 18 15 89 3f f6 ff 	prefetcht1 -0x9c077(%rip)        # 6f7a0 <pf_callee_31>
  10b817:	41 53                	push   %r11
  10b819:	4c 8b 1d b8 d8 ff ff 	mov    -0x2748(%rip),%r11        # 1090d8 <pf_got_13_0>

000000000010b820 <pf_got_hint_30_0>:
  10b820:	41 0f 18 93 b0 53 ff 	prefetcht1 -0xac50(%r11)
  10b827:	ff 
  10b828:	41 5b                	pop    %r11

000000000010b82a <pf_jump_30>:
  10b82a:	e9 71 c0 f1 ff       	jmp    278a0 <pf_callee_28>
  10b82f:	90                   	nop

000000000010b830 <pf_call_31>:
  10b830:	0f 18 15 39 5e f4 ff 	prefetcht1 -0xba1c7(%rip)        # 51670 <pf_target_31_0>

000000000010b837 <pf_jump_31>:
  10b837:	e9 64 3f f6 ff       	jmp    6f7a0 <pf_callee_31>
  10b83c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b840 <pf_call_32>:
  10b840:	0f 18 15 89 ba f5 ff 	prefetcht1 -0xa4577(%rip)        # 672d0 <pf_target_32_0>
  10b847:	0f 18 15 b2 07 f6 ff 	prefetcht1 -0x9f84e(%rip)        # 6c000 <pf_target_32_1>
  10b84e:	0f 18 15 9b ce f5 ff 	prefetcht1 -0xa3165(%rip)        # 686f0 <pf_target_32_2>

000000000010b855 <pf_jump_32>:
  10b855:	e9 66 cb f1 ff       	jmp    283c0 <pf_callee_32>
  10b85a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000010b860 <pf_call_33>:
  10b860:	41 53                	push   %r11
  10b862:	4c 8b 1d 6f d8 ff ff 	mov    -0x2791(%rip),%r11        # 1090d8 <pf_got_13_0>

000000000010b869 <pf_got_hint_33_0>:
  10b869:	41 0f 18 93 30 07 00 	prefetcht1 0x730(%r11)
  10b870:	00 
  10b871:	41 5b                	pop    %r11

000000000010b873 <pf_jump_33>:
  10b873:	e9 98 a6 f6 ff       	jmp    75f10 <pf_callee_33>
  10b878:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b87f:	00 

000000000010b880 <pf_call_34>:
  10b880:	0f 18 15 50 37 f6 ff 	prefetcht1 -0x9c8b0(%rip)        # 6efd7 <pf_target_34_0>
  10b887:	0f 18 15 57 06 f6 ff 	prefetcht1 -0x9f9a9(%rip)        # 6bee5 <pf_target_34_1>
  10b88e:	0f 18 15 cb 36 f6 ff 	prefetcht1 -0x9c935(%rip)        # 6ef60 <pf_target_34_2>
  10b895:	0f 18 15 7a 02 f6 ff 	prefetcht1 -0x9fd86(%rip)        # 6bb16 <pf_target_34_3>

000000000010b89c <pf_jump_34>:
  10b89c:	e9 1f 58 f6 ff       	jmp    710c0 <pf_callee_34>
