
/storage/prefetchit/class_b_temporal_20261001/builds/pathwide_shared_anchor/7277229c6489da6761bfa3456517c6cf25e006a732d2a0dab69141658d47f872/call-stub-8pipjnmh/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000422c0 <pf_call_0>:
   422c0:	0f 18 15 3a 04 fd ff 	prefetcht1 -0x2fbc6(%rip)        # 12701 <pf_target_0_0>

00000000000422c7 <pf_jump_0>:
   422c7:	e9 a4 af fc ff       	jmp    d270 <pf_callee_0>
   422cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000422d0 <pf_call_1>:
   422d0:	0f 18 15 c9 b9 fc ff 	prefetcht1 -0x34637(%rip)        # dca0 <pf_target_1_0>
   422d7:	0f 18 15 63 10 fd ff 	prefetcht1 -0x2ef9d(%rip)        # 13341 <pf_target_13_6>
   422de:	0f 18 15 2b 10 fd ff 	prefetcht1 -0x2efd5(%rip)        # 13310 <pf_target_13_2>
   422e5:	0f 18 15 04 0f fd ff 	prefetcht1 -0x2f0fc(%rip)        # 131f0 <pf_target_1_3>
   422ec:	0f 18 15 12 0f fd ff 	prefetcht1 -0x2f0ee(%rip)        # 13205 <pf_target_1_4>

00000000000422f3 <pf_jump_1>:
   422f3:	e9 38 b4 fc ff       	jmp    d730 <pf_callee_1>
   422f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   422ff:	00 

0000000000042300 <pf_call_2>:
   42300:	0f 18 15 39 cd fc ff 	prefetcht1 -0x332c7(%rip)        # f040 <pf_target_2_0>

0000000000042307 <pf_jump_2>:
   42307:	e9 a4 ad fc ff       	jmp    d0b0 <pf_callee_2>
   4230c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042310 <pf_call_3>:
   42310:	0f 18 15 ed dd fc ff 	prefetcht1 -0x32213(%rip)        # 10104 <pf_target_3_0>

0000000000042317 <pf_jump_3>:
   42317:	e9 f4 ad fc ff       	jmp    d110 <pf_callee_3>
   4231c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042320 <pf_call_4>:
   42320:	0f 18 15 e9 c1 fc ff 	prefetcht1 -0x33e17(%rip)        # e510 <pf_target_4_0>
   42327:	0f 18 15 14 c2 fc ff 	prefetcht1 -0x33dec(%rip)        # e542 <pf_target_4_1>

000000000004232e <pf_jump_4>:
   4232e:	e9 ad b1 fc ff       	jmp    d4e0 <pf_callee_4>
   42333:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4233a:	00 00 00 
   4233d:	0f 1f 00             	nopl   (%rax)

0000000000042340 <pf_call_5>:
   42340:	0f 18 15 d9 00 fd ff 	prefetcht1 -0x2ff27(%rip)        # 12420 <pf_target_5_0>
   42347:	0f 18 15 f2 00 fd ff 	prefetcht1 -0x2ff0e(%rip)        # 12440 <pf_target_5_1>
   4234e:	0f 18 15 4b 02 fd ff 	prefetcht1 -0x2fdb5(%rip)        # 125a0 <pf_target_5_2>
   42355:	0f 18 15 3c c6 fc ff 	prefetcht1 -0x339c4(%rip)        # e998 <pf_target_5_3>

000000000004235c <pf_jump_5>:
   4235c:	e9 0f ac fc ff       	jmp    cf70 <pf_callee_5>
   42361:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   42368:	00 00 00 
   4236b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000042370 <pf_call_6>:
   42370:	0f 18 15 89 06 fd ff 	prefetcht1 -0x2f977(%rip)        # 12a00 <pf_target_6_0>
   42377:	0f 18 15 c3 06 fd ff 	prefetcht1 -0x2f93d(%rip)        # 12a41 <pf_target_6_1>
   4237e:	0f 18 15 9b a7 fc ff 	prefetcht1 -0x35865(%rip)        # cb20 <pf_target_21_2>

0000000000042385 <pf_jump_6>:
   42385:	e9 f6 ad fc ff       	jmp    d180 <pf_callee_10>
   4238a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000042390 <pf_call_7>:
   42390:	0f 18 15 97 9e fd ff 	prefetcht1 -0x26169(%rip)        # 1c22e <pf_target_7_0>
   42397:	41 53                	push   %r11
   42399:	4c 8b 1d 88 8f ff ff 	mov    -0x7078(%rip),%r11        # 3b328 <pf_got_18_0>

00000000000423a0 <pf_got_hint_7_0>:
   423a0:	41 0f 18 93 20 ab 00 	prefetcht1 0xab20(%r11)
   423a7:	00 

00000000000423a8 <pf_got_hint_7_1>:
   423a8:	41 0f 18 93 42 ab 00 	prefetcht1 0xab42(%r11)
   423af:	00 
   423b0:	41 5b                	pop    %r11

00000000000423b2 <pf_jump_7>:
   423b2:	e9 09 ab fc ff       	jmp    cec0 <pf_callee_7>
   423b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   423be:	00 00 

00000000000423c0 <pf_call_8>:
   423c0:	0f 18 15 e1 f9 fc ff 	prefetcht1 -0x3061f(%rip)        # 11da8 <pf_target_8_0>

00000000000423c7 <pf_jump_8>:
   423c7:	e9 24 dc fc ff       	jmp    fff0 <pf_callee_8>
   423cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000423d0 <pf_call_9>:
   423d0:	0f 18 15 e9 0b fd ff 	prefetcht1 -0x2f417(%rip)        # 12fc0 <pf_target_9_0>
   423d7:	0f 18 15 63 06 fd ff 	prefetcht1 -0x2f99d(%rip)        # 12a41 <pf_target_6_1>
   423de:	0f 18 15 1b 06 fd ff 	prefetcht1 -0x2f9e5(%rip)        # 12a00 <pf_target_6_0>

00000000000423e5 <pf_jump_9>:
   423e5:	e9 96 ad fc ff       	jmp    d180 <pf_callee_10>
   423ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000423f0 <pf_call_10>:
   423f0:	0f 18 15 4b b4 fc ff 	prefetcht1 -0x34bb5(%rip)        # d842 <pf_target_10_0>

00000000000423f7 <pf_jump_10>:
   423f7:	e9 84 ad fc ff       	jmp    d180 <pf_callee_10>
   423fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042400 <pf_call_11>:
   42400:	0f 18 15 19 fe fd ff 	prefetcht1 -0x201e7(%rip)        # 22220 <pf_target_11_0>
   42407:	0f 18 15 32 fe fd ff 	prefetcht1 -0x201ce(%rip)        # 22240 <pf_target_11_1>

000000000004240e <pf_jump_11>:
   4240e:	e9 ad f9 fc ff       	jmp    11dc0 <pf_callee_11>
   42413:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4241a:	00 00 00 
   4241d:	0f 1f 00             	nopl   (%rax)

0000000000042420 <pf_call_12>:
   42420:	0f 18 15 a9 fa fc ff 	prefetcht1 -0x30557(%rip)        # 11ed0 <pf_target_12_0>

0000000000042427 <pf_jump_12>:
   42427:	e9 94 f9 fc ff       	jmp    11dc0 <pf_callee_11>
   4242c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042430 <pf_call_13>:
   42430:	0f 18 15 b9 db fc ff 	prefetcht1 -0x32447(%rip)        # fff0 <pf_callee_8>
   42437:	0f 18 15 c7 db fc ff 	prefetcht1 -0x32439(%rip)        # 10005 <pf_target_13_1>
   4243e:	0f 18 15 cb 0e fd ff 	prefetcht1 -0x2f135(%rip)        # 13310 <pf_target_13_2>
   42445:	0f 18 15 74 f9 fc ff 	prefetcht1 -0x3068c(%rip)        # 11dc0 <pf_callee_11>
   4244c:	0f 18 15 6d fe fd ff 	prefetcht1 -0x20193(%rip)        # 222c0 <pf_target_13_4>
   42453:	0f 18 15 be fb fc ff 	prefetcht1 -0x30442(%rip)        # 12018 <pf_target_13_5>
   4245a:	0f 18 15 e0 0e fd ff 	prefetcht1 -0x2f120(%rip)        # 13341 <pf_target_13_6>

0000000000042461 <pf_jump_13>:
   42461:	e9 6a a7 fc ff       	jmp    cbd0 <pf_callee_13>
   42466:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4246d:	00 00 00 

0000000000042470 <pf_call_14>:
   42470:	0f 18 15 e9 f6 fc ff 	prefetcht1 -0x30917(%rip)        # 11b60 <pf_target_14_0>
   42477:	0f 18 15 03 f7 fc ff 	prefetcht1 -0x308fd(%rip)        # 11b81 <pf_target_14_1>

000000000004247e <pf_jump_14>:
   4247e:	e9 0d b0 fc ff       	jmp    d490 <pf_callee_14>
   42483:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4248a:	00 00 00 
   4248d:	0f 1f 00             	nopl   (%rax)

0000000000042490 <pf_call_15>:
   42490:	0f 18 15 29 96 fd ff 	prefetcht1 -0x269d7(%rip)        # 1bac0 <pf_target_15_0>
   42497:	0f 18 15 12 77 fd ff 	prefetcht1 -0x288ee(%rip)        # 19bb0 <pf_target_15_1>
   4249e:	0f 18 15 61 96 fd ff 	prefetcht1 -0x2699f(%rip)        # 1bb06 <pf_target_15_2>
   424a5:	0f 18 15 94 96 fd ff 	prefetcht1 -0x2696c(%rip)        # 1bb40 <pf_target_15_3>
   424ac:	0f 18 15 77 78 fd ff 	prefetcht1 -0x28789(%rip)        # 19d2a <pf_target_15_4>
   424b3:	0f 18 15 48 77 fd ff 	prefetcht1 -0x288b8(%rip)        # 19c02 <pf_target_15_5>

00000000000424ba <pf_jump_15>:
   424ba:	e9 e1 ad fc ff       	jmp    d2a0 <pf_callee_15>
   424bf:	90                   	nop

00000000000424c0 <pf_call_16>:
   424c0:	0f 18 15 c9 40 fe ff 	prefetcht1 -0x1bf37(%rip)        # 26590 <pf_target_16_0>
   424c7:	0f 18 15 22 9e fd ff 	prefetcht1 -0x261de(%rip)        # 1c2f0 <pf_target_16_1>
   424ce:	0f 18 15 ee 40 fe ff 	prefetcht1 -0x1bf12(%rip)        # 265c3 <pf_target_16_2>
   424d5:	0f 18 15 64 a9 fc ff 	prefetcht1 -0x3569c(%rip)        # ce40 <pf_callee_19>

00000000000424dc <pf_jump_16>:
   424dc:	e9 bf ad fc ff       	jmp    d2a0 <pf_callee_15>
   424e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   424e8:	00 00 00 
   424eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000424f0 <pf_call_17>:
   424f0:	0f 18 15 19 13 fd ff 	prefetcht1 -0x2ece7(%rip)        # 13810 <pf_target_17_0>
   424f7:	0f 18 15 45 13 fd ff 	prefetcht1 -0x2ecbb(%rip)        # 13843 <pf_target_17_1>

00000000000424fe <pf_jump_17>:
   424fe:	e9 8d a8 fc ff       	jmp    cd90 <pf_callee_17>
   42503:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4250a:	00 00 00 
   4250d:	0f 1f 00             	nopl   (%rax)

0000000000042510 <pf_call_18>:
   42510:	0f 18 15 ab 54 fd ff 	prefetcht1 -0x2ab55(%rip)        # 179c2 <pf_target_18_0>
   42517:	41 53                	push   %r11
   42519:	4c 8b 1d 08 8e ff ff 	mov    -0x71f8(%rip),%r11        # 3b328 <pf_got_18_0>

0000000000042520 <pf_got_hint_18_0>:
   42520:	41 0f 18 93 80 57 f4 	prefetcht1 -0xba880(%r11)
   42527:	ff 
   42528:	41 5b                	pop    %r11

000000000004252a <pf_jump_18>:
   4252a:	e9 91 b0 fc ff       	jmp    d5c0 <pf_callee_18>
   4252f:	90                   	nop

0000000000042530 <pf_call_19>:
   42530:	0f 18 15 59 92 fd ff 	prefetcht1 -0x26da7(%rip)        # 1b790 <pf_target_19_0>
   42537:	0f 18 15 85 92 fd ff 	prefetcht1 -0x26d7b(%rip)        # 1b7c3 <pf_target_19_1>
   4253e:	41 53                	push   %r11
   42540:	4c 8b 1d e1 8d ff ff 	mov    -0x721f(%rip),%r11        # 3b328 <pf_got_18_0>

0000000000042547 <pf_got_hint_19_0>:
   42547:	41 0f 18 93 80 c5 00 	prefetcht1 0xc580(%r11)
   4254e:	00 

000000000004254f <pf_got_hint_19_1>:
   4254f:	41 0f 18 93 c6 c5 00 	prefetcht1 0xc5c6(%r11)
   42556:	00 

0000000000042557 <pf_got_hint_19_2>:
   42557:	41 0f 18 93 02 ca 00 	prefetcht1 0xca02(%r11)
   4255e:	00 
   4255f:	41 5b                	pop    %r11

0000000000042561 <pf_jump_19>:
   42561:	e9 da a8 fc ff       	jmp    ce40 <pf_callee_19>
   42566:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4256d:	00 00 00 

0000000000042570 <pf_call_20>:
   42570:	41 53                	push   %r11
   42572:	4c 8b 1d af 8d ff ff 	mov    -0x7251(%rip),%r11        # 3b328 <pf_got_18_0>

0000000000042579 <pf_got_hint_20_0>:
   42579:	41 0f 18 93 a0 c9 00 	prefetcht1 0xc9a0(%r11)
   42580:	00 
   42581:	41 5b                	pop    %r11

0000000000042583 <pf_jump_20>:
   42583:	e9 d8 a8 fc ff       	jmp    ce60 <pf_callee_20>
   42588:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   4258f:	00 

0000000000042590 <pf_call_21>:
   42590:	0f 18 15 8b 77 fd ff 	prefetcht1 -0x28875(%rip)        # 19d22 <pf_target_21_0>
   42597:	0f 18 15 22 85 fd ff 	prefetcht1 -0x27ade(%rip)        # 1aac0 <pf_target_21_1>
   4259e:	0f 18 15 7b a5 fc ff 	prefetcht1 -0x35a85(%rip)        # cb20 <pf_target_21_2>
   425a5:	41 53                	push   %r11
   425a7:	4c 8b 1d 7a 8d ff ff 	mov    -0x7286(%rip),%r11        # 3b328 <pf_got_18_0>

00000000000425ae <pf_got_hint_21_0>:
   425ae:	41 0f 18 93 72 c9 00 	prefetcht1 0xc972(%r11)
   425b5:	00 

00000000000425b6 <pf_got_hint_21_1>:
   425b6:	41 0f 18 93 e0 c9 00 	prefetcht1 0xc9e0(%r11)
   425bd:	00 

00000000000425be <pf_got_hint_21_2>:
   425be:	41 0f 18 93 02 ca 00 	prefetcht1 0xca02(%r11)
   425c5:	00 
   425c6:	41 5b                	pop    %r11

00000000000425c8 <pf_jump_21>:
   425c8:	e9 93 a6 fc ff       	jmp    cc60 <pf_callee_21>
   425cd:	0f 1f 00             	nopl   (%rax)

00000000000425d0 <pf_call_22>:
   425d0:	0f 18 15 e9 7c fd ff 	prefetcht1 -0x28317(%rip)        # 1a2c0 <pf_target_22_0>

00000000000425d7 <pf_jump_22>:
   425d7:	e9 c4 ac fc ff       	jmp    d2a0 <pf_callee_15>
   425dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000425e0 <pf_call_23>:
   425e0:	0f 18 15 e9 23 fe ff 	prefetcht1 -0x1dc17(%rip)        # 249d0 <pf_target_23_0>

00000000000425e7 <pf_jump_23>:
   425e7:	e9 b4 ac fc ff       	jmp    d2a0 <pf_callee_15>
   425ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000425f0 <pf_call_24>:
   425f0:	0f 18 15 49 83 fd ff 	prefetcht1 -0x27cb7(%rip)        # 1a940 <pf_target_24_0>

00000000000425f7 <pf_jump_24>:
   425f7:	e9 a4 aa fc ff       	jmp    d0a0 <pf_callee_24>
   425fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042600 <pf_call_25>:
   42600:	0f 18 15 89 86 fd ff 	prefetcht1 -0x27977(%rip)        # 1ac90 <pf_target_25_0>

0000000000042607 <pf_jump_25>:
   42607:	e9 74 af fc ff       	jmp    d580 <pf_callee_25>
   4260c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042610 <pf_call_26>:
   42610:	0f 18 15 99 8f fd ff 	prefetcht1 -0x27067(%rip)        # 1b5b0 <pf_target_26_0>

0000000000042617 <pf_jump_26>:
   42617:	e9 04 ab fc ff       	jmp    d120 <pf_callee_26>
   4261c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042620 <pf_call_27>:
   42620:	0f 18 15 29 ec fc ff 	prefetcht1 -0x313d7(%rip)        # 11250 <pf_target_27_0>
   42627:	0f 18 15 b2 88 fd ff 	prefetcht1 -0x2774e(%rip)        # 1aee0 <pf_target_27_1>

000000000004262e <pf_jump_27>:
   4262e:	e9 ad a6 fc ff       	jmp    cce0 <pf_callee_27>
   42633:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4263a:	00 00 00 
   4263d:	0f 1f 00             	nopl   (%rax)

0000000000042640 <pf_call_28>:
   42640:	0f 18 15 0e 42 fe ff 	prefetcht1 -0x1bdf2(%rip)        # 26855 <pf_target_28_0>

0000000000042647 <pf_jump_28>:
   42647:	e9 f4 a7 fc ff       	jmp    ce40 <pf_callee_19>
   4264c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042650 <pf_call_29>:
   42650:	0f 18 15 a9 e7 fc ff 	prefetcht1 -0x31857(%rip)        # 10e00 <pf_target_29_0>

0000000000042657 <pf_jump_29>:
   42657:	e9 24 ae fc ff       	jmp    d480 <pf_callee_29>
   4265c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000042660 <pf_call_30>:
   42660:	0f 18 15 c9 54 fd ff 	prefetcht1 -0x2ab37(%rip)        # 17b30 <pf_target_30_0>
   42667:	0f 18 15 42 53 fd ff 	prefetcht1 -0x2acbe(%rip)        # 179b0 <pf_target_30_1>

000000000004266e <pf_jump_30>:
   4266e:	e9 9d ab fc ff       	jmp    d210 <pf_callee_30>
   42673:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   4267a:	00 00 00 
   4267d:	0f 1f 00             	nopl   (%rax)

0000000000042680 <pf_call_31>:
   42680:	0f 18 15 99 3f fd ff 	prefetcht1 -0x2c067(%rip)        # 16620 <pf_target_31_0>
   42687:	0f 18 15 b3 3f fd ff 	prefetcht1 -0x2c04d(%rip)        # 16641 <pf_target_31_1>
   4268e:	41 53                	push   %r11
   42690:	4c 8b 1d 91 8c ff ff 	mov    -0x736f(%rip),%r11        # 3b328 <pf_got_18_0>

0000000000042697 <pf_got_hint_31_0>:
   42697:	41 0f 18 93 83 fc ef 	prefetcht1 -0x10037d(%r11)
   4269e:	ff 

000000000004269f <pf_got_hint_31_1>:
   4269f:	41 0f 18 93 04 fd ef 	prefetcht1 -0x1002fc(%r11)
   426a6:	ff 
   426a7:	41 5b                	pop    %r11

00000000000426a9 <pf_jump_31>:
   426a9:	e9 22 af fc ff       	jmp    d5d0 <pf_callee_31>
   426ae:	66 90                	xchg   %ax,%ax

00000000000426b0 <pf_call_32>:
   426b0:	0f 18 15 49 7e fd ff 	prefetcht1 -0x281b7(%rip)        # 1a500 <pf_target_32_0>
   426b7:	0f 18 15 52 7c fd ff 	prefetcht1 -0x283ae(%rip)        # 1a310 <pf_target_32_1>
   426be:	0f 18 15 0b 2a fd ff 	prefetcht1 -0x2d5f5(%rip)        # 150d0 <pf_target_32_2>
   426c5:	0f 18 15 94 7d fd ff 	prefetcht1 -0x2826c(%rip)        # 1a460 <pf_target_32_3>
   426cc:	0f 18 15 cd 78 fd ff 	prefetcht1 -0x28733(%rip)        # 19fa0 <pf_target_32_4>
   426d3:	0f 18 15 16 7e fd ff 	prefetcht1 -0x281ea(%rip)        # 1a4f0 <pf_target_32_5>
   426da:	0f 18 15 cf a8 fc ff 	prefetcht1 -0x35731(%rip)        # cfb0 <pf_target_32_6>
   426e1:	0f 18 15 da 78 fd ff 	prefetcht1 -0x28726(%rip)        # 19fc2 <pf_target_32_7>

00000000000426e8 <pf_jump_32>:
   426e8:	e9 63 a5 fc ff       	jmp    cc50 <pf_callee_32>
   426ed:	0f 1f 00             	nopl   (%rax)

00000000000426f0 <pf_call_33>:
   426f0:	41 53                	push   %r11
   426f2:	4c 8b 1d 2f 8c ff ff 	mov    -0x73d1(%rip),%r11        # 3b328 <pf_got_18_0>

00000000000426f9 <pf_got_hint_33_0>:
   426f9:	41 0f 18 93 85 1b ee 	prefetcht1 -0x11e47b(%r11)
   42700:	ff 

0000000000042701 <pf_got_hint_33_1>:
   42701:	41 0f 18 93 70 e3 f8 	prefetcht1 -0x71c90(%r11)
   42708:	ff 
   42709:	41 5b                	pop    %r11

000000000004270b <pf_jump_33>:
   4270b:	e9 70 ac fc ff       	jmp    d380 <pf_callee_33>

0000000000042710 <pf_call_34>:
   42710:	41 53                	push   %r11
   42712:	4c 8b 1d 0f 8c ff ff 	mov    -0x73f1(%rip),%r11        # 3b328 <pf_got_18_0>

0000000000042719 <pf_got_hint_34_0>:
   42719:	41 0f 18 93 70 e3 f8 	prefetcht1 -0x71c90(%r11)
   42720:	ff 
   42721:	41 5b                	pop    %r11

0000000000042723 <pf_jump_34>:
   42723:	e9 a8 ae fc ff       	jmp    d5d0 <pf_callee_31>
   42728:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   4272f:	00 

0000000000042730 <pf_call_35>:
   42730:	41 53                	push   %r11
   42732:	4c 8b 1d ef 8b ff ff 	mov    -0x7411(%rip),%r11        # 3b328 <pf_got_18_0>

0000000000042739 <pf_got_hint_35_0>:
   42739:	41 0f 18 93 60 f6 ec 	prefetcht1 -0x1309a0(%r11)
   42740:	ff 

0000000000042741 <pf_got_hint_35_1>:
   42741:	41 0f 18 93 e8 01 ed 	prefetcht1 -0x12fe18(%r11)
   42748:	ff 

0000000000042749 <pf_got_hint_35_2>:
   42749:	41 0f 18 93 f7 04 ed 	prefetcht1 -0x12fb09(%r11)
   42750:	ff 

0000000000042751 <pf_got_hint_35_3>:
   42751:	41 0f 18 93 00 05 ed 	prefetcht1 -0x12fb00(%r11)
   42758:	ff 

0000000000042759 <pf_got_hint_35_4>:
   42759:	41 0f 18 93 30 1b ee 	prefetcht1 -0x11e4d0(%r11)
   42760:	ff 

0000000000042761 <pf_got_hint_35_5>:
   42761:	41 0f 18 93 40 1b ee 	prefetcht1 -0x11e4c0(%r11)
   42768:	ff 

0000000000042769 <pf_got_hint_35_6>:
   42769:	41 0f 18 93 42 7d ee 	prefetcht1 -0x1182be(%r11)
   42770:	ff 

0000000000042771 <pf_got_hint_35_7>:
   42771:	41 0f 18 93 90 7d ee 	prefetcht1 -0x118270(%r11)
   42778:	ff 
   42779:	41 5b                	pop    %r11

000000000004277b <pf_jump_35>:
   4277b:	e9 a0 ab fc ff       	jmp    d320 <pf_callee_35>

0000000000042780 <pf_call_36>:
   42780:	41 53                	push   %r11
   42782:	4c 8b 1d 9f 8b ff ff 	mov    -0x7461(%rip),%r11        # 3b328 <pf_got_18_0>

0000000000042789 <pf_got_hint_36_0>:
   42789:	41 0f 18 93 85 1b ee 	prefetcht1 -0x11e47b(%r11)
   42790:	ff 

0000000000042791 <pf_got_hint_36_1>:
   42791:	41 0f 18 93 42 7d ee 	prefetcht1 -0x1182be(%r11)
   42798:	ff 
   42799:	41 5b                	pop    %r11

000000000004279b <pf_jump_36>:
   4279b:	e9 80 ab fc ff       	jmp    d320 <pf_callee_35>
