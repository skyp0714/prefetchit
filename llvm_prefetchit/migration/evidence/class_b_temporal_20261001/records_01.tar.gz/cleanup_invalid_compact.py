import hashlib,json,shutil,time
from pathlib import Path
r=Path('/storage/prefetchit/class_b_temporal_20261001')
base=r/'invalid_profiles/train_mongo_scanner82/train_mongo'
files=[]
for p in sorted(base.glob('*/*/observations.json.gz')):
 assert not p.is_symlink() and not any(q.is_symlink() for q in p.parents)
 assert (p.parent/'locations.json').is_file() and (p.parent/'timeline.json').is_file()
 stats=json.loads((p.parent/'locations.json').read_text())
 files.append(dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),samples=stats['samples']))
record=dict(epoch=time.time(),reason='Retention audit: unused per-sample decoded duplicates from rejected scanner82 capture. Compact timelines, aggregated locations/edges, quality failure, settings, commands, catalogs, source records and hashes retained; valid training captures remain intact.',files=files,bytes_removed=sum(v['bytes'] for v in files),free_before=shutil.disk_usage(r).free,complete=False)
out=r/'invalid_compact_cleanup.json'
assert not out.exists()
out.write_text(json.dumps(record,indent=2)+'\n')
for v in files:Path(v['path']).unlink()
record.update(complete=True,free_after=shutil.disk_usage(r).free)
out.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(files=len(files),bytes_removed=record['bytes_removed'],complete=True)))
