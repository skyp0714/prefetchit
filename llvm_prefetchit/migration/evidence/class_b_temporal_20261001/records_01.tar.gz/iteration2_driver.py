import json,subprocess,sys,time
from pathlib import Path
scripts=Path('/home/hnpark2/prefetchit/llvm_prefetchit/scripts/class_b')
sys.path.insert(0,str(scripts))
import dense_build as b
import media_system_study as system
from e2e_lbr import remove_generated

root=Path('/storage/prefetchit/class_b_temporal_20261001')
assert json.loads((root/'screen1/complete.json').read_text())['valid']
assert json.loads((root/'tests_alignment_result.json').read_text())['valid']
decision=json.loads((root/'screen1_decision.json').read_text());base=decision['continue']
prepared=json.loads((root/'prepared_candidates.json').read_text())
arms=json.loads((root/'arms.json').read_text());arms[base]=prepared[base]['arm']
def binaries(arm):
 paths=set(arm['overrides'].values())|{arm['mongo_binary']}
 for group in arm.get('libraries',{}).values():paths.update(group.values())
 return {Path(p) for p in paths}
keep=binaries(arms['original'])|binaries(arms['mongo'])|binaries(arms[base])|binaries(prepared[base]['nop'])
obsolete=set()
for name in decision['rejected']:
 if name in prepared:obsolete.update(binaries(prepared[name]['arm'])|binaries(prepared[name]['nop']))
 else:obsolete.update(binaries(arms[name])|binaries(arms[name+'_nop']))
obsolete={p for p in obsolete-keep if p.is_relative_to(root) and p.is_file()}
if obsolete:
 remove_generated(sorted(obsolete),root/'screen1_rejected_cleanup.json',
     'Completed exploratory screen: rejected or superseded generated ELFs only. Preserve decisions, all measurements, source snapshots, plans, exact patches, assembly and binary hashes. Keep original, Mongo-only, chosen path policy and its NOP control.')
def run(name,command):
 b.space(root)
 print(json.dumps(dict(stage=name,epoch=time.time(),command=list(map(str,command)))),flush=True)
 with (root/(name+'.log')).open('w') as stream:subprocess.run(list(map(str,command)),stdout=stream,stderr=subprocess.STDOUT,check=True)

for group,services in [('native',list(system.NATIVE)),('mongo',list(system.MONGO))]:
 name='best1_'+group;spec=root/(name+'_spec.json')
 b.save(spec,dict(arms[base],root=str(root),out=str(root/'profiles'/name),services=services,
     kinds=['l2','lat128'],capture_s=8,seed=1001401,phase='best1',arm=base))
 run(name,['python3',scripts/'temporal_path_study.py','platform_capture',spec])
 assert json.loads((root/'profiles'/name/'complete.json').read_text())['valid']

for arm,suite in [('original','core'),(base,'core'),(base,'extra'),('original','extra')]:
 name='pmu1_'+arm+'_'+suite;spec=root/(name+'_spec.json')
 b.save(spec,dict(arms[arm],root=str(root),out=str(root/'diagnostics'/name),suite=suite,seed=1001501,arm=arm))
 run(name,['python3',scripts/'temporal_path_pmu.py','platform_trial',spec])
 assert json.loads((root/'diagnostics'/name/'result.json').read_text())['valid']

run('pmu1_summary',['python3',scripts/'temporal_path_metrics.py',root])
run('best1_residual',['python3',scripts/'temporal_path_residual.py',root,'--phase','best1'])
run('best1_figures',['python3',scripts/'temporal_path_report.py',root,'--plot'])
run('refine_'+base,['python3',scripts/'temporal_path_refine.py',root,'--base',base,'--phase','best1'])
refinement=json.loads((root/'refinement'/base/'complete.json').read_text());assert refinement['valid']
prepared=json.loads((root/'prepared_candidates.json').read_text())
for i,name in enumerate(refinement['variants']):
 spec=root/('smoke_'+name+'_spec.json')
 b.save(spec,dict(prepared[name]['arm'],root=str(root),out=str(root/'smokes'/name),candidate=name,seed=1001601+i))
 run('smoke_'+name,['python3',scripts/'temporal_path_campaign.py','platform_smoke',spec])
 assert json.loads((root/'smokes'/name/'result.json').read_text())['valid']
b.save(root/'iteration2_prepared.json',dict(valid=True,base=base,variants=refinement['variants'],epoch=time.time()))
