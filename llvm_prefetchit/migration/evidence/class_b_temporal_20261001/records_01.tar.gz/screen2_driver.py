import json,subprocess,sys,time
from pathlib import Path
scripts=Path('/home/hnpark2/prefetchit/llvm_prefetchit/scripts/class_b')
sys.path.insert(0,str(scripts))
import dense_build as b
import media_system_study as system
root=Path('/storage/prefetchit/class_b_temporal_20261001')
ready=json.loads((root/'iteration2_prepared.json').read_text());assert ready['valid']
original=json.loads((root/'arms.json').read_text())['original']
def run(name,command):
 b.space(root);print(json.dumps(dict(stage=name,epoch=time.time(),command=list(map(str,command)))),flush=True)
 with (root/(name+'.log')).open('w') as stream:subprocess.run(list(map(str,command)),stdout=stream,stderr=subprocess.STDOUT,check=True)

compact_name=ready['base']+'_compact16'
run('prepare_'+compact_name,['python3',scripts/'temporal_path_compact.py',root,'--base',ready['base'],
    '--site-overhead','16','--tag',compact_name,'--respect-retained-capacity'])
if json.loads((root/'candidates'/compact_name/'model_decision.json').read_text())['eligible']:
 prepared=json.loads((root/'prepared_candidates.json').read_text());spec=root/('smoke_'+compact_name+'_spec.json')
 b.save(spec,dict(prepared[compact_name]['arm'],root=str(root),out=str(root/'smokes'/compact_name),candidate=compact_name,seed=1001609))
 run('smoke_'+compact_name,['python3',scripts/'temporal_path_campaign.py','platform_smoke',spec])
 assert json.loads((root/'smokes'/compact_name/'result.json').read_text())['valid']
 ready['variants'].append(compact_name)
b.save(root/'iteration2_extended_prepared.json',ready)
run('final_pmu_preflight_driver',['python3',scripts/'temporal_path_final_pmu.py','preflight',root])
for group,services in [('native',list(system.NATIVE)),('mongo',list(system.MONGO))]:
 name='baseline2_'+group;spec=root/(name+'_spec.json')
 b.save(spec,dict(original,root=str(root),out=str(root/'profiles'/name),services=services,
     kinds=['l2','lat128'],capture_s=8,seed=1001401,phase='baseline2',arm='original',
     purpose='Repeat baseline after the observed external background-load change; retain all earlier captures.'))
 run(name,['python3',scripts/'temporal_path_study.py','platform_capture',spec])
 assert json.loads((root/'profiles'/name/'complete.json').read_text())['valid']

for group,services in [('native',list(system.NATIVE)),('mongo',list(system.MONGO))]:
 name='baseline2_l1_'+group;spec=root/(name+'_spec.json')
 b.save(spec,dict(original,root=str(root),out=str(root/'profiles'/name),services=services,
     kinds=['l1'],capture_s=8,seed=1001401,phase='baseline2',arm='original',
     purpose='Time-resolved L1I control after PMU found increased L1I misses despite fewer L2 misses. Final selected policy receives the same L1I capture.'))
 run(name,['python3',scripts/'temporal_path_study.py','platform_capture',spec])
 assert json.loads((root/'profiles'/name/'complete.json').read_text())['valid']

prepared=json.loads((root/'prepared_candidates.json').read_text())
names=[ready['base'],*ready['variants']];arms={'original':original,**{name:prepared[name]['arm'] for name in names}}
for name in names:assert json.loads((root/'smokes'/name/'result.json').read_text())['valid']
spec=root/'screen2_spec.json'
b.save(spec,dict(root=str(root),out=str(root/'screen2'),arms=arms,blocks=2,seedbase=1001701,order_seed=1001700,
    trial_script=str(scripts/'temporal_path_trial.py'),
    background_audit=dict(source=str(root/'background_cpu_watch.py'),source_sha256=b.sha(root/'background_cpu_watch.py'),
        interval_s=1,affinity='84',kind='Coarse /proc last-CPU reads, no perf or scheduler tracing',
        change_record=str(root/'environment_amendment.json')),
    scope='Two exploratory blocks across eligible refinements plus pathwide and original. Reserve independent confirmation and the repeated temporal baseline for the changed shared-host background.',
    selection_rule='After all frozen trials, choose the highest geometric-mean throughput refinement with mean CPU/request no more than 0.5% and mean p99 no more than 2% above pathwide; otherwise continue pathwide. This is exploratory selection, not promotion. Include pathwide and exact-layout NOP in independent confirmation if a refinement is selected. No performance exclusions or retries.'))
run('screen2',['python3',scripts/'temporal_path_campaign.py','campaign',spec])
