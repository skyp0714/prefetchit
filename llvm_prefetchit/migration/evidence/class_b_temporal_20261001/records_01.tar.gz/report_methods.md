측정 범위는 DeathStarBench Media의 compose-review 전체 요청이다. MovieId를 포함한 앱 서버 9개, 그 안에서 실행되는 공유 라이브러리 8종, MongoDB 실행 파일을 함께 수정했다. 같은 MongoDB 파일을 MongoDB 컨테이너 8개에 배포했고, 세부 PMU·시간대별 추적은 이 요청에서 바쁜 UserReview·MovieReview·ReviewStorage DB 3개에서 수집했다. Nginx·Redis·Memcached·Jaeger 서버와 커널 텍스트는 이번 정책에서 수정하지 않았다. 이들의 CPU 비용은 전체 요청 성능에 포함된다.

운영점은 balanced C4 지속 HTTP 연결, 서버 CPU 32–39의 8개 코어, 2GHz, tracing 100%다. 각 실행마다 스택과 데이터를 새로 만들고 50초 워밍업 후 60초를 계측했다. 이전에 정한 CPU 활용률 약 80–90%의 운영점을 사용했으며, 최대 처리량을 찾는 새 부하 스윕이나 다른 Media API 검증은 아니다. 동일한 closed-loop 동시성에서는 처리량과 평균 지연이 서로 연관되므로 둘을 별개의 독립 증거로 세지 않았다.

실제 retired-branch history와 각 ELF의 정적 direct-call/CFG를 함께 사용했다. 같은 함수에서 해석 가능한 normal CFG의 dominator와 함수·DSO를 넘는 관측 경로를 구별했다. 전체 프로그램의 dominance가 증명됐다고 주장하지 않는다. call 빈도는 원본의 별도 near-call 표본에서 추정했고, 코드 미스 표본으로 빈도를 대신하지 않았다. 훈련과 heldout 원본 스택을 분리했다. 잔여 미스 프로파일을 사용한 보강은 새 훈련으로 취급하고, 이후 새 스택의 처리량·지연으로 검증했다.

원래 direct call을 hint stub으로 연결한 뒤 원래 callee로 이동한다. 기존 명령의 주소와 return address를 유지한다. DSO 간 타깃은 실행 시 GOT 주소에 검증된 ELF 상대 오프셋을 더해서 구한다. 레지스터·flags·CFI 보존과 실제 로딩 주소를 검사했다. lazy GOT가 아직 해석되지 않은 항목은 따로 기록했다. NOP 대조군은 분기·GOT 접근·코드 배치를 유지하고 추가한 힌트만 같은 길이의 NOP으로 바꾼다.

현재 정책은 사용자 코드의 여러 호출 지점에서 반복 발행한다. 커널을 수정한 schedule-in burst나 시간 게이트를 배포한 정책은 아니다. 10–20µs를 모든 프로그램에 동일하게 적용하지 않았다. 앱과 DB의 실행 구간 길이가 달랐고, MongoDB의 미스는 더 늦은 구간에도 많이 분포했다. 시간 그래프는 scheduler 선택부터 표본 명령의 retirement까지이며 fetch 시점 자체는 아니다. LBR의 completed-branch cycle 간격도 정확한 hint-to-fetch lead-time이 아니다.

시간대별 비교의 주 대조군은 공유 호스트 부하 변화 이후 다시 얻은 baseline2다. 03:57 UTC경 별도 사용자의 CPU 작업 40개가 시작됐다. 해당 작업은 변경하지 않았고, 기존 측정도 제외하지 않았다. clean ROI에서는 controller CPU의 1초 간격 /proc 관찰만 사용했다. 순간적인 CPU 겹침과 공유 캐시·메모리 간섭을 완전히 배제할 수 없으므로 완전 격리 호스트의 결과라고 해석하지 않는다. 초기 탐색과 독립 재검증은 합쳐서 성능 수치를 계산하지 않았다.

L2 code-read miss와 retired L2 true-miss 태그는 서로 다른 이벤트다. I-cache data/tag stall은 원래 cycle 카운터이며, stall 구간 시작 횟수는 data-stall에 cmask=1·edge=1을 적용해 별도로 측정했다. recovery와 clear-resteer도 분리했다. unknown-branch bubble 비중은 BTB 점유율이나 BTB miss 비율이 아니다. 이벤트 인코딩과 정의는 [Intel Granite Rapids PMU 문서](https://perfmon-events.intel.com/platforms/graniterapids/core-events/core/) 및 [Intel perfmon 원본](https://github.com/intel/perfmon/blob/main/GNR/events/graniterapids_core.json)을 확인하고 버전·해시를 보존했다.

Jaeger 요청 trace도 수집했지만 일부 parent span이 누락돼 있어 exclusive critical path를 계산하지 않았다. 실제 힌트 배치에는 LBR 경로를 사용했다. stripped 라이브러리의 가까운 export symbol 이름을 정확한 소스 함수 이름으로 단정하지 않았다.
