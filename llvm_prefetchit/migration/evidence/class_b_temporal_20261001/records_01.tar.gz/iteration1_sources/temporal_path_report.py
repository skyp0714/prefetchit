#!/usr/bin/env python3
"""Compact age distributions and request-normalized before/after figures."""
import argparse
import collections
import json
from pathlib import Path

import dense_build as b
from temporal_path_common import EDGES


def summarize(root):
    rows=[]
    for path in sorted((root/'profiles').glob('*/*/*/timeline.json')):
        data=json.loads(path.read_text());window=json.loads((path.parent/'request_window.json').read_text())
        protocol=json.loads((path.parents[2]/'protocol.json').read_text());n=window['completed_requests']
        total=sum(v['estimated_events'] for v in data['bins'])
        rows.append(dict(run=path.parents[2].name,arm=protocol.get('arm'),phase=protocol.get('phase'),
            service=path.parents[1].name,kind=data['kind'],samples=data['quality']['complete_samples'],
            joined_pct=data['quality']['complete_sample_pct'],period=data['period'],requests=n,
            events_per_request=total/n,median_run_us=data['median_run_us'],
            early20_pct=100*sum(v['estimated_events'] for v in data['bins'] if v['lo_us']<20)/total,
            bins=[dict(v,events_per_request=v['estimated_events']/n) for v in data['bins']],
            origins={key:dict(value,events_per_request=value['estimated_events']/n) for key,value in data['origins'].items()}))
    result=dict(rows=rows,bins_us=EDGES,
        limitation='Separate perturbing diagnostic captures. PEBS retirement age since scheduler selection is not fetch time. Period-weighted/request and scheduled-exposure normalizations are estimates. Never infer clean speedup from these windows.')
    b.save(root/'analysis/temporal_summary.json',result)
    return result


def plot(root,data):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    plt.rcParams.update({'font.size':9,'svg.hashsalt':'class-b-temporal-20261001'})
    services=['movie','compose','rating','unique','text','user','storage','userreview','moviereview','mongo_user','mongo_movie','mongo_storage']
    arms=list(dict.fromkeys(row['arm'] for row in data['rows'] if row['kind']=='l2'))
    colors={arm:plt.get_cmap('tab10')(i) for i,arm in enumerate(arms)}
    for mode in ['per_request','exposure']:
        fig,axes=plt.subplots(4,3,figsize=(14,12),sharex=True)
        for service,ax in zip(services,axes.flat):
            for arm in arms:
                selected=[r for r in data['rows'] if r['kind']=='l2' and r['service']==service and r['arm']==arm]
                if not selected:continue
                values=[];x=[]
                for i,lo in enumerate(EDGES[:-1]):
                    hi=EDGES[i+1]
                    if hi>100:break
                    x.append((lo+hi)/2)
                    if mode=='per_request':
                        values.append(np.mean([r['bins'][i]['events_per_request']/(hi-lo) for r in selected]))
                    else:
                        values.append(np.mean([r['bins'][i]['estimated_events']/r['bins'][i]['exposure_us'] if r['bins'][i]['exposure_us'] else 0 for r in selected]))
                ax.plot(x,values,marker='.',label=arm,color=colors[arm],linewidth=1.5)
            ax.axvspan(10,20,color='#999999',alpha=.12);ax.set_title(service);ax.grid(alpha=.2)
            ax.set_xlim(0,100);ax.set_ylim(bottom=0)
        handles,labels=axes.flat[0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',ncol=len(labels))
        fig.supxlabel('Sample retirement age after sched_switch selection (µs)')
        fig.supylabel('Estimated retired L2 events / request / age-bin µs' if mode=='per_request' else 'Estimated retired L2 events / scheduled µs')
        fig.suptitle('Media instruction misses before/after prefetch — diagnostic captures',y=.995)
        fig.tight_layout(rect=(.025,.025,1,.95))
        for suffix in ['png','svg']:fig.savefig(root/'analysis'/('miss_age_'+mode+'.'+suffix),dpi=160)
        plt.close(fig)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root',type=Path);p.add_argument('--plot',action='store_true');a=p.parse_args()
    data=summarize(a.root)
    if a.plot:plot(a.root,data)
