import json,sys
from pathlib import Path
sys.path.insert(0,'/home/hnpark2/prefetchit/llvm_prefetchit/scripts/class_b')
import fullset as h
import dense_build as b
import temporal_path_study as study
root=Path('/storage/prefetchit/class_b_temporal_20261001')
failed=root/'profiles/train_mongo'
if failed.exists() and not (failed/'complete.json').exists():
 b.save(failed/'exclusion.json',dict(reason='First decoder rejected perf type82 before binary-parser validation. Exclude full training stack; preserve remaining compact captures then re-run same seed. No performance-based selection.'))
 for data in sorted(failed.glob('*/*/perf.data')):
  try:study.decode(data.parent)
  except Exception as error:print(json.dumps(dict(stage='rejected_decode',path=str(data),error=repr(error))),flush=True)
 destination=root/'invalid_profiles/train_mongo_scanner82';destination.mkdir(parents=True,exist_ok=False)
 for path in sorted(failed.parent.glob('train_mongo*')):path.rename(destination/path.name)
 checks=[]
 for before in destination.rglob('*_before.json'):
  after=before.with_name(before.name.replace('_before','_restored'))
  checks.append(after.exists() and json.loads(before.read_text())==json.loads(after.read_text()))
 b.save(destination/'restoration_audit.json',dict(comparisons=len(checks),restored=all(checks)));assert checks and all(checks)
for value in json.loads((root/'initial_profile_queue.json').read_text())['specs']:
 p=Path(value);s=json.loads(p.read_text());out=Path(s['out'])
 if (out/'complete.json').exists():continue
 assert not out.exists();b.space(root)
 print(json.dumps(dict(stage='start',path=str(out))),flush=True)
 h.platform(out,['python3','/home/hnpark2/prefetchit/llvm_prefetchit/scripts/class_b/temporal_path_study.py','capture',p])
 print(json.dumps(dict(stage='complete',path=str(out))),flush=True)
b.save(root/'initial_profiles_complete.json',dict(valid=True))
