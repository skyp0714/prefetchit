
/storage/prefetchit/class_b_temporal_20261001/tests_got_witness/test_external_anchor_preserves1/call-stub-mpwgamrn/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000005340 <pf_call_0>:
    5340:	41 53                	push   %r11
    5342:	4c 8b 1d bf ec ff ff 	mov    -0x1341(%rip),%r11        # 4008 <pf_got_0_0>

0000000000005349 <pf_got_hint_0_0>:
    5349:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
    5350:	00 

0000000000005351 <pf_got_hint_0_1>:
    5351:	41 0f 18 93 40 00 00 	prefetcht1 0x40(%r11)
    5358:	00 
    5359:	41 5b                	pop    %r11

000000000000535b <pf_jump_0>:
    535b:	e9 de be ff ff       	jmp    123e <pf_callee_0>
