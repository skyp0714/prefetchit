
.text
.global invoke
.type invoke,@function
invoke:
.cfi_startproc
sub $8,%rsp
.cfi_adjust_cfa_offset 8
mov $12345,%r11
stc
.global call_probe
call_probe:
call entry
add $8,%rsp
.cfi_adjust_cfa_offset -8
ret
.cfi_endproc
.size invoke,.-invoke
.type entry,@function
entry:
.cfi_startproc
jnc failed
cmp $12345,%r11
jne failed
jmp target@PLT
failed:
mov $-100,%rax
ret
.cfi_endproc
.size entry,.-entry
.section .note.GNU-stack,"",@progbits
