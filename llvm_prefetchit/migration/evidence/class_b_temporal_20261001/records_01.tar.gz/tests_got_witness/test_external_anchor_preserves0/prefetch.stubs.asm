
/storage/prefetchit/class_b_temporal_20261001/tests_got_witness/test_external_anchor_preserves0/call-stub-c6ymqp38/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000405340 <pf_call_0>:
  405340:	41 53                	push   %r11
  405342:	4c 8b 1d bf ec ff ff 	mov    -0x1341(%rip),%r11        # 404008 <pf_got_0_0>

0000000000405349 <pf_got_hint_0_0>:
  405349:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  405350:	00 

0000000000405351 <pf_got_hint_0_1>:
  405351:	41 0f 18 93 40 00 00 	prefetcht1 0x40(%r11)
  405358:	00 
  405359:	41 5b                	pop    %r11

000000000040535b <pf_jump_0>:
  40535b:	e9 ce be ff ff       	jmp    40122e <pf_callee_0>
