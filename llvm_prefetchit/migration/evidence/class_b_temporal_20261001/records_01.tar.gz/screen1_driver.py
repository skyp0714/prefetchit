import json,subprocess
from pathlib import Path
r=Path('/storage/prefetchit/class_b_temporal_20261001')
s=Path('/home/hnpark2/prefetchit/llvm_prefetchit/scripts/class_b')
assert json.loads((r/'initial_profiles_complete.json').read_text())['valid']
assert json.loads((r/'initial_candidates_built.json').read_text())['valid']
def run(name,args):
 print(json.dumps(dict(stage=name,command=list(map(str,args)))),flush=True)
 with (r/(name+'.log')).open('w') as log:subprocess.run(list(map(str,args)),stdout=log,stderr=subprocess.STDOUT,check=True)
run('residual_analysis',['python3',s/'temporal_path_residual.py',r])
run('baseline_path_analysis',['python3',s/'temporal_path_residual.py',r,'--phase','heldout'])
run('initial_temporal_figures',['python3',s/'temporal_path_report.py',r,'--plot'])
run('extra_pmu_preflight_driver',['python3',s/'temporal_path_pmu.py','preflight',r])
for name in ('path64','path512','pathwide'):
 run('smoke_'+name,['python3',s/'temporal_path_campaign.py','platform_smoke',r/('smoke_'+name+'_spec.json')])
 assert json.loads((r/'smokes'/name/'result.json').read_text())['valid']
run('screen1',['python3',s/'temporal_path_campaign.py','campaign',r/'screen1_spec.json'])
