import json,sys
from pathlib import Path
sys.path.insert(0,'/home/hnpark2/prefetchit/llvm_prefetchit/scripts/class_b')
import fullset as h
import dense_build as b
root=Path('/storage/prefetchit/class_b_temporal_20261001')
for value in json.loads((root/'initial_profile_queue.json').read_text())['specs']:
 p=Path(value);s=json.loads(p.read_text());out=Path(s['out']);b.space(root)
 print(json.dumps(dict(stage='start',path=str(out))),flush=True)
 h.platform(out,['python3','/home/hnpark2/prefetchit/llvm_prefetchit/scripts/class_b/temporal_path_study.py','capture',p])
 print(json.dumps(dict(stage='complete',path=str(out))),flush=True)
b.save(root/'initial_profiles_complete.json',dict(valid=True))
