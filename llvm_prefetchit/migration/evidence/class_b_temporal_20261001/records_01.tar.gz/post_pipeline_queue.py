import datetime, json, subprocess, time
from pathlib import Path
root = Path('/storage/prefetchit/class_b_temporal_20261001')
scripts = Path('/home/hnpark2/prefetchit/llvm_prefetchit/scripts/class_b')
deadline = datetime.datetime.fromisoformat('2026-10-01T08:51:30+00:00').timestamp()
while not (root / 'confirmation_and_diagnostics_complete.json').exists():
    if time.time() >= deadline:
        raise TimeoutError('Primary pipeline has not completed before publication reserve ends')
    time.sleep(2)
for script in ['temporal_path_final_audit.py', 'temporal_path_write_report.py']:
    print(json.dumps(dict(stage=script, epoch=time.time())), flush=True)
    subprocess.run(['python3', str(scripts / script), str(root)], check=True)
(root / 'local_report_prepared.json').write_text(json.dumps(dict(valid=True, epoch=time.time(), publication_pending=True), indent=2) + '\n')
print('Report and audit prepared; manual figure/report review and publication remain.', flush=True)
