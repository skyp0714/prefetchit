
/storage/prefetchit/class_b_temporal_20261001/controls/libraries/b2cf6c33b74d2f22543b7a469a75b538911e690f769d0b238843a49465b83793/call-stub-0x5wu8ls/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000229380 <pf_call_0>:
  229380:	0f 18 15 d6 d1 e4 ff 	prefetcht1 -0x1b2e2a(%rip)        # 7655d <pf_target_0_0>
  229387:	0f 18 15 73 e1 e4 ff 	prefetcht1 -0x1b1e8d(%rip)        # 77501 <pf_target_0_1>
  22938e:	0f 18 15 eb d1 e4 ff 	prefetcht1 -0x1b2e15(%rip)        # 76580 <pf_target_0_2>
  229395:	0f 18 15 66 dc e4 ff 	prefetcht1 -0x1b239a(%rip)        # 77002 <pf_target_0_3>
  22939c:	e9 8f 0e e3 ff       	jmp    5a230 <pf_callee_0>
  2293a1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2293a8:	00 00 00 
  2293ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000002293b0 <pf_call_1>:
  2293b0:	0f 18 15 e9 51 e6 ff 	prefetcht1 -0x19ae17(%rip)        # 8e5a0 <pf_callee_4>
  2293b7:	0f 18 15 04 52 e6 ff 	prefetcht1 -0x19adfc(%rip)        # 8e5c2 <pf_target_1_1>
  2293be:	0f 18 15 1b cb e4 ff 	prefetcht1 -0x1b34e5(%rip)        # 75ee0 <pf_target_1_2>
  2293c5:	0f 18 15 35 48 e6 ff 	prefetcht1 -0x19b7cb(%rip)        # 8dc01 <pf_target_1_3>
  2293cc:	e9 3f 52 e6 ff       	jmp    8e610 <pf_callee_1>
  2293d1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2293d8:	00 00 00 
  2293db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000002293e0 <pf_call_2>:
  2293e0:	0f 18 15 d9 c0 e4 ff 	prefetcht1 -0x1b3f27(%rip)        # 754c0 <pf_target_2_0>
  2293e7:	0f 18 15 02 bc e4 ff 	prefetcht1 -0x1b43fe(%rip)        # 74ff0 <pf_callee_3>
  2293ee:	0f 18 15 4b 82 f8 ff 	prefetcht1 -0x77db5(%rip)        # 1b1640 <pf_target_2_2>
  2293f5:	0f 18 15 ed d8 e4 ff 	prefetcht1 -0x1b2713(%rip)        # 76ce9 <pf_target_2_3>
  2293fc:	e9 6f 65 e6 ff       	jmp    8f970 <pf_callee_2>
  229401:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229408:	00 00 00 
  22940b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229410 <pf_call_3>:
  229410:	0f 18 15 89 db e4 ff 	prefetcht1 -0x1b2477(%rip)        # 76fa0 <pf_target_3_0>
  229417:	0f 18 15 b2 c2 e4 ff 	prefetcht1 -0x1b3d4e(%rip)        # 756d0 <pf_target_3_1>
  22941e:	0f 18 15 43 d6 e4 ff 	prefetcht1 -0x1b29bd(%rip)        # 76a68 <pf_target_3_2>
  229425:	0f 18 15 55 82 f8 ff 	prefetcht1 -0x77dab(%rip)        # 1b1681 <pf_target_3_3>
  22942c:	e9 bf bb e4 ff       	jmp    74ff0 <pf_callee_3>
  229431:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229438:	00 00 00 
  22943b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229440 <pf_call_4>:
  229440:	0f 18 15 99 47 e6 ff 	prefetcht1 -0x19b867(%rip)        # 8dbe0 <pf_callee_5>
  229447:	0f 18 15 b2 bb e4 ff 	prefetcht1 -0x1b444e(%rip)        # 75000 <pf_target_4_1>
  22944e:	0f 18 15 2b 65 e6 ff 	prefetcht1 -0x199ad5(%rip)        # 8f980 <pf_target_4_2>
  229455:	0f 18 15 14 65 e6 ff 	prefetcht1 -0x199aec(%rip)        # 8f970 <pf_callee_2>
  22945c:	e9 3f 51 e6 ff       	jmp    8e5a0 <pf_callee_4>
  229461:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229468:	00 00 00 
  22946b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229470 <pf_call_5>:
  229470:	0f 18 15 c9 bb e4 ff 	prefetcht1 -0x1b4437(%rip)        # 75040 <pf_target_5_0>
  229477:	0f 18 15 02 49 e6 ff 	prefetcht1 -0x19b6fe(%rip)        # 8dd80 <pf_target_5_1>
  22947e:	0f 18 15 ab 0d e3 ff 	prefetcht1 -0x1cf255(%rip)        # 5a230 <pf_callee_0>
  229485:	0f 18 15 36 db e4 ff 	prefetcht1 -0x1b24ca(%rip)        # 76fc2 <pf_target_5_3>
  22948c:	e9 4f 47 e6 ff       	jmp    8dbe0 <pf_callee_5>
  229491:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229498:	00 00 00 
  22949b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000002294a0 <pf_call_6>:
  2294a0:	0f 18 15 49 7b e6 ff 	prefetcht1 -0x1984b7(%rip)        # 90ff0 <pf_target_22_2>
  2294a7:	0f 18 15 52 7b e6 ff 	prefetcht1 -0x1984ae(%rip)        # 91000 <pf_target_6_1>
  2294ae:	0f 18 15 db a4 e6 ff 	prefetcht1 -0x195b25(%rip)        # 93990 <pf_target_6_2>
  2294b5:	0f 18 15 05 a5 e6 ff 	prefetcht1 -0x195afb(%rip)        # 939c1 <pf_target_6_3>
  2294bc:	e9 4f 04 e7 ff       	jmp    99910 <pf_callee_6>
  2294c1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2294c8:	00 00 00 
  2294cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000002294d0 <pf_call_7>:
  2294d0:	0f 18 15 d3 a3 e6 ff 	prefetcht1 -0x195c2d(%rip)        # 938aa <pf_target_7_0>
  2294d7:	0f 18 15 e2 a3 e6 ff 	prefetcht1 -0x195c1e(%rip)        # 938c0 <pf_target_7_1>
  2294de:	e9 dd 75 e6 ff       	jmp    90ac0 <pf_callee_20>
  2294e3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2294ea:	00 00 00 
  2294ed:	0f 1f 00             	nopl   (%rax)

00000000002294f0 <pf_call_8>:
  2294f0:	0f 18 15 09 7b e6 ff 	prefetcht1 -0x1984f7(%rip)        # 91000 <pf_target_6_1>
  2294f7:	0f 18 15 f2 7a e6 ff 	prefetcht1 -0x19850e(%rip)        # 90ff0 <pf_target_22_2>
  2294fe:	e9 0d 04 e7 ff       	jmp    99910 <pf_callee_6>
  229503:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22950a:	00 00 00 
  22950d:	0f 1f 00             	nopl   (%rax)

0000000000229510 <pf_call_9>:
  229510:	0f 18 15 64 ac e6 ff 	prefetcht1 -0x19539c(%rip)        # 9417b <pf_target_9_0>
  229517:	0f 18 15 65 ac e6 ff 	prefetcht1 -0x19539b(%rip)        # 94183 <pf_target_9_1>
  22951e:	e9 9d 75 e6 ff       	jmp    90ac0 <pf_callee_20>
  229523:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22952a:	00 00 00 
  22952d:	0f 1f 00             	nopl   (%rax)

0000000000229530 <pf_call_10>:
  229530:	0f 18 15 19 c5 ef ff 	prefetcht1 -0x103ae7(%rip)        # 125a50 <pf_target_10_0>
  229537:	0f 18 15 72 d3 ef ff 	prefetcht1 -0x102c8e(%rip)        # 1268b0 <pf_target_10_1>
  22953e:	0f 18 15 41 c5 ef ff 	prefetcht1 -0x103abf(%rip)        # 125a86 <pf_target_10_2>
  229545:	e9 b6 d3 ef ff       	jmp    126900 <pf_callee_10>
  22954a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229550 <pf_call_11>:
  229550:	0f 18 15 69 08 e7 ff 	prefetcht1 -0x18f797(%rip)        # 99dc0 <pf_target_11_0>
  229557:	0f 18 15 22 0a e7 ff 	prefetcht1 -0x18f5de(%rip)        # 99f80 <pf_target_11_1>
  22955e:	e9 5d 0e e1 ff       	jmp    3a3c0 <pf_callee_11>
  229563:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22956a:	00 00 00 
  22956d:	0f 1f 00             	nopl   (%rax)

0000000000229570 <pf_call_12>:
  229570:	0f 18 15 39 f3 f3 ff 	prefetcht1 -0xc0cc7(%rip)        # 1688b0 <pf_target_12_0>
  229577:	0f 18 15 62 73 e6 ff 	prefetcht1 -0x198c9e(%rip)        # 908e0 <pf_target_12_1>
  22957e:	0f 18 15 bb eb e7 ff 	prefetcht1 -0x181445(%rip)        # a8140 <pf_callee_14>
  229585:	0f 18 15 35 f3 f3 ff 	prefetcht1 -0xc0ccb(%rip)        # 1688c1 <pf_target_12_3>
  22958c:	e9 cf c7 e1 ff       	jmp    45d60 <pf_callee_12>
  229591:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229598:	00 00 00 
  22959b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000002295a0 <pf_call_13>:
  2295a0:	0f 18 15 d9 05 f2 ff 	prefetcht1 -0xdfa27(%rip)        # 149b80 <pf_target_13_0>
  2295a7:	0f 18 15 22 88 f2 ff 	prefetcht1 -0xd77de(%rip)        # 151dd0 <pf_target_13_1>
  2295ae:	0f 18 15 bb ed df ff 	prefetcht1 -0x201245(%rip)        # 28370 <pf_target_13_2>
  2295b5:	0f 18 15 8d f3 f3 ff 	prefetcht1 -0xc0c73(%rip)        # 168949 <pf_target_13_3>
  2295bc:	e9 ef 7f e6 ff       	jmp    915b0 <pf_callee_13>
  2295c1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2295c8:	00 00 00 
  2295cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000002295d0 <pf_call_14>:
  2295d0:	0f 18 15 58 88 f2 ff 	prefetcht1 -0xd77a8(%rip)        # 151e2f <pf_target_14_0>
  2295d7:	0f 18 15 a3 eb e7 ff 	prefetcht1 -0x18145d(%rip)        # a8181 <pf_target_14_1>
  2295de:	e9 5d eb e7 ff       	jmp    a8140 <pf_callee_14>
  2295e3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2295ea:	00 00 00 
  2295ed:	0f 1f 00             	nopl   (%rax)

00000000002295f0 <pf_call_15>:
  2295f0:	0f 18 15 89 c2 e6 ff 	prefetcht1 -0x193d77(%rip)        # 95880 <pf_target_15_0>
  2295f7:	0f 18 15 b2 89 e6 ff 	prefetcht1 -0x19764e(%rip)        # 91fb0 <pf_callee_19>
  2295fe:	0f 18 15 bb 89 e6 ff 	prefetcht1 -0x197645(%rip)        # 91fc0 <pf_target_15_2>
  229605:	0f 18 15 54 55 ef ff 	prefetcht1 -0x10aaac(%rip)        # 11eb60 <pf_target_15_3>
  22960c:	e9 1f c7 e6 ff       	jmp    95d30 <pf_callee_15>
  229611:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229618:	00 00 00 
  22961b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229620 <pf_call_16>:
  229620:	0f 18 15 dc ce e7 ff 	prefetcht1 -0x183124(%rip)        # a6503 <pf_target_16_0>
  229627:	0f 18 15 b2 ce e7 ff 	prefetcht1 -0x18314e(%rip)        # a64e0 <pf_target_16_1>
  22962e:	0f 18 15 4f cf e7 ff 	prefetcht1 -0x1830b1(%rip)        # a6584 <pf_target_16_2>
  229635:	e9 d6 1c ef ff       	jmp    11b310 <pf_callee_16>
  22963a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229640 <pf_call_17>:
  229640:	0f 18 15 7a d2 ef ff 	prefetcht1 -0x102d86(%rip)        # 1268c1 <pf_target_17_0>
  229647:	e9 54 af e6 ff       	jmp    945a0 <pf_callee_17>
  22964c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229650 <pf_call_18>:
  229650:	0f 18 15 ee ce e7 ff 	prefetcht1 -0x183112(%rip)        # a6545 <pf_target_18_0>
  229657:	e9 94 55 ef ff       	jmp    11ebf0 <pf_callee_18>
  22965c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229660 <pf_call_19>:
  229660:	0f 18 15 19 c0 e6 ff 	prefetcht1 -0x193fe7(%rip)        # 95680 <pf_target_19_0>
  229667:	0f 18 15 54 c0 e6 ff 	prefetcht1 -0x193fac(%rip)        # 956c2 <pf_target_19_1>
  22966e:	0f 18 15 9b 1c ef ff 	prefetcht1 -0x10e365(%rip)        # 11b310 <pf_callee_16>
  229675:	e9 36 89 e6 ff       	jmp    91fb0 <pf_callee_19>
  22967a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000229680 <pf_call_20>:
  229680:	0f 18 15 b0 ce e6 ff 	prefetcht1 -0x193150(%rip)        # 96537 <pf_target_20_0>
  229687:	e9 34 74 e6 ff       	jmp    90ac0 <pf_callee_20>
  22968c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229690 <pf_call_21>:
  229690:	0f 18 15 6c aa e6 ff 	prefetcht1 -0x195594(%rip)        # 94103 <pf_target_21_0>
  229697:	0f 18 15 02 aa e6 ff 	prefetcht1 -0x1955fe(%rip)        # 940a0 <pf_target_21_1>
  22969e:	0f 18 15 1e aa e6 ff 	prefetcht1 -0x1955e2(%rip)        # 940c3 <pf_target_21_2>
  2296a5:	0f 18 15 64 02 e7 ff 	prefetcht1 -0x18fd9c(%rip)        # 99910 <pf_callee_6>
  2296ac:	e9 2f 7c e6 ff       	jmp    912e0 <pf_callee_21>
  2296b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2296b8:	00 00 00 
  2296bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000002296c0 <pf_call_22>:
  2296c0:	0f 18 15 a9 cd e6 ff 	prefetcht1 -0x193257(%rip)        # 96470 <pf_target_22_0>
  2296c7:	0f 18 15 b5 cd e6 ff 	prefetcht1 -0x19324b(%rip)        # 96483 <pf_target_22_1>
  2296ce:	0f 18 15 1b 79 e6 ff 	prefetcht1 -0x1986e5(%rip)        # 90ff0 <pf_target_22_2>
  2296d5:	0f 18 15 e6 cd e6 ff 	prefetcht1 -0x19321a(%rip)        # 964c2 <pf_target_22_3>
  2296dc:	e9 af 73 e6 ff       	jmp    90a90 <pf_callee_22>
  2296e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2296e8:	00 00 00 
  2296eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000002296f0 <pf_call_23>:
  2296f0:	0f 18 15 b9 96 e6 ff 	prefetcht1 -0x196947(%rip)        # 92db0 <pf_target_23_0>
  2296f7:	0f 18 15 62 c6 e1 ff 	prefetcht1 -0x1e399e(%rip)        # 45d60 <pf_callee_12>
  2296fe:	0f 18 15 bd 96 e6 ff 	prefetcht1 -0x196943(%rip)        # 92dc2 <pf_target_23_2>
  229705:	0f 18 15 b4 7e e6 ff 	prefetcht1 -0x19814c(%rip)        # 915c0 <pf_target_23_3>
  22970c:	e9 af 73 e6 ff       	jmp    90ac0 <pf_callee_20>
  229711:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229718:	00 00 00 
  22971b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229720 <pf_call_24>:
  229720:	0f 18 15 89 ec e5 ff 	prefetcht1 -0x1a1377(%rip)        # 883b0 <pf_target_24_0>
  229727:	0f 18 15 c2 b4 f0 ff 	prefetcht1 -0xf4b3e(%rip)        # 134bf0 <pf_target_24_1>
  22972e:	0f 18 15 db 4e e6 ff 	prefetcht1 -0x19b125(%rip)        # 8e610 <pf_callee_1>
  229735:	0f 18 15 c5 b4 f0 ff 	prefetcht1 -0xf4b3b(%rip)        # 134c01 <pf_target_24_3>
  22973c:	e9 8f 7f e7 ff       	jmp    a16d0 <pf_callee_24>
  229741:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229748:	00 00 00 
  22974b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229750 <pf_call_25>:
  229750:	0f 18 15 09 c6 e1 ff 	prefetcht1 -0x1e39f7(%rip)        # 45d60 <pf_callee_12>
  229757:	0f 18 15 25 b3 e6 ff 	prefetcht1 -0x194cdb(%rip)        # 94a83 <pf_target_25_1>
  22975e:	0f 18 15 92 b1 e6 ff 	prefetcht1 -0x194e6e(%rip)        # 948f7 <pf_target_25_2>
  229765:	0f 18 15 44 7e e6 ff 	prefetcht1 -0x1981bc(%rip)        # 915b0 <pf_callee_13>
  22976c:	e9 ff a1 e7 ff       	jmp    a3970 <pf_callee_25>
  229771:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229778:	00 00 00 
  22977b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229780 <pf_call_26>:
  229780:	0f 18 15 7a 79 e7 ff 	prefetcht1 -0x188686(%rip)        # a1101 <pf_target_26_0>
  229787:	0f 18 15 32 7e e6 ff 	prefetcht1 -0x1981ce(%rip)        # 915c0 <pf_target_23_3>
  22978e:	0f 18 15 43 79 e7 ff 	prefetcht1 -0x1886bd(%rip)        # a10d8 <pf_target_26_2>
  229795:	e9 b6 78 e7 ff       	jmp    a1050 <pf_callee_26>
  22979a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000002297a0 <pf_call_27>:
  2297a0:	0f 18 15 79 ee df ff 	prefetcht1 -0x201187(%rip)        # 28620 <pf_target_27_0>
  2297a7:	e9 c4 a1 e7 ff       	jmp    a3970 <pf_callee_25>
  2297ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000002297b0 <pf_call_28>:
  2297b0:	0f 18 15 4c 7f e7 ff 	prefetcht1 -0x1880b4(%rip)        # a1703 <pf_target_28_0>
  2297b7:	0f 18 15 12 7f e7 ff 	prefetcht1 -0x1880ee(%rip)        # a16d0 <pf_callee_24>
  2297be:	e9 ad a1 e7 ff       	jmp    a3970 <pf_callee_25>
  2297c3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2297ca:	00 00 00 
  2297cd:	0f 1f 00             	nopl   (%rax)

00000000002297d0 <pf_call_29>:
  2297d0:	0f 18 15 ab 78 e7 ff 	prefetcht1 -0x188755(%rip)        # a1082 <pf_target_29_0>
  2297d7:	0f 18 15 72 78 e7 ff 	prefetcht1 -0x18878e(%rip)        # a1050 <pf_callee_26>
  2297de:	e9 6d b1 e7 ff       	jmp    a4950 <pf_callee_29>
  2297e3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  2297ea:	00 00 00 
  2297ed:	0f 1f 00             	nopl   (%rax)

00000000002297f0 <pf_call_30>:
  2297f0:	0f 18 15 09 a0 e6 ff 	prefetcht1 -0x195ff7(%rip)        # 93800 <pf_target_30_0>
  2297f7:	0f 18 15 f2 9f e6 ff 	prefetcht1 -0x19600e(%rip)        # 937f0 <pf_target_30_1>
  2297fe:	0f 18 15 0b 01 e7 ff 	prefetcht1 -0x18fef5(%rip)        # 99910 <pf_callee_6>
  229805:	0f 18 15 04 17 e7 ff 	prefetcht1 -0x18e8fc(%rip)        # 9af10 <pf_target_30_3>
  22980c:	e9 4f 8e e7 ff       	jmp    a2660 <pf_callee_30>
  229811:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  229818:	00 00 00 
  22981b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000229820 <pf_call_31>:
  229820:	0f 18 15 29 78 e7 ff 	prefetcht1 -0x1887d7(%rip)        # a1050 <pf_callee_26>
  229827:	0f 18 15 54 78 e7 ff 	prefetcht1 -0x1887ac(%rip)        # a1082 <pf_target_29_0>
  22982e:	e9 1d b1 e7 ff       	jmp    a4950 <pf_callee_29>
  229833:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22983a:	00 00 00 
  22983d:	0f 1f 00             	nopl   (%rax)

0000000000229840 <pf_call_32>:
  229840:	0f 18 15 79 54 ef ff 	prefetcht1 -0x10ab87(%rip)        # 11ecc0 <pf_target_32_0>
  229847:	e9 54 bb e7 ff       	jmp    a53a0 <pf_callee_32>
  22984c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229850 <pf_call_33>:
  229850:	0f 18 15 b9 4d e6 ff 	prefetcht1 -0x19b247(%rip)        # 8e610 <pf_callee_1>
  229857:	e9 14 a1 e7 ff       	jmp    a3970 <pf_callee_25>
  22985c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000229860 <pf_call_34>:
  229860:	0f 18 15 69 f4 ee ff 	prefetcht1 -0x110b97(%rip)        # 118cd0 <pf_target_34_0>
  229867:	0f 18 15 62 d3 f7 ff 	prefetcht1 -0x82c9e(%rip)        # 1a6bd0 <pf_target_34_1>
  22986e:	e9 3d 71 e6 ff       	jmp    909b0 <pf_callee_34>
  229873:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22987a:	00 00 00 
  22987d:	0f 1f 00             	nopl   (%rax)

0000000000229880 <pf_call_35>:
  229880:	0f 18 15 19 b8 ee ff 	prefetcht1 -0x1147e7(%rip)        # 1150a0 <pf_target_35_0>
  229887:	e9 24 71 e6 ff       	jmp    909b0 <pf_callee_34>
