
/storage/prefetchit/class_b_temporal_20261001/controls/libraries/ff0825e113603c3866680d5d52216bc6d8eedf3a59f52a0aef67ff01994db128/call-stub-hicig9f7/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000022c300 <pf_call_0>:
  22c300:	0f 18 15 19 2d e8 ff 	prefetcht1 -0x17d2e7(%rip)        # af020 <pf_target_0_0>
  22c307:	0f 18 15 62 7d f1 ff 	prefetcht1 -0xe829e(%rip)        # 144070 <pf_target_0_1>
  22c30e:	e9 bd 2d e7 ff       	jmp    9f0d0 <pf_callee_0>
  22c313:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c31a:	00 00 00 
  22c31d:	0f 1f 00             	nopl   (%rax)

000000000022c320 <pf_call_1>:
  22c320:	0f 18 15 29 4a e7 ff 	prefetcht1 -0x18b5d7(%rip)        # a0d50 <pf_callee_2>
  22c327:	0f 18 15 22 22 e7 ff 	prefetcht1 -0x18ddde(%rip)        # 9e550 <pf_target_1_1>
  22c32e:	e9 4d 34 e7 ff       	jmp    9f780 <pf_callee_1>
  22c333:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c33a:	00 00 00 
  22c33d:	0f 1f 00             	nopl   (%rax)

000000000022c340 <pf_call_2>:
  22c340:	0f 18 15 69 4e e7 ff 	prefetcht1 -0x18b197(%rip)        # a11b0 <pf_callee_7>
  22c347:	e9 04 4a e7 ff       	jmp    a0d50 <pf_callee_2>
  22c34c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c350 <pf_call_3>:
  22c350:	0f 18 15 49 52 e7 ff 	prefetcht1 -0x18adb7(%rip)        # a15a0 <pf_callee_21>
  22c357:	0f 18 15 d2 32 e7 ff 	prefetcht1 -0x18cd2e(%rip)        # 9f630 <pf_target_3_1>
  22c35e:	e9 bd 5f e9 ff       	jmp    c2320 <pf_callee_3>
  22c363:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c36a:	00 00 00 
  22c36d:	0f 1f 00             	nopl   (%rax)

000000000022c370 <pf_call_4>:
  22c370:	0f 18 15 79 94 f1 ff 	prefetcht1 -0xe6b87(%rip)        # 1457f0 <pf_target_4_0>
  22c377:	0f 18 15 82 94 f1 ff 	prefetcht1 -0xe6b7e(%rip)        # 145800 <pf_target_4_1>
  22c37e:	e9 8d 27 e7 ff       	jmp    9eb10 <pf_callee_4>
  22c383:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c38a:	00 00 00 
  22c38d:	0f 1f 00             	nopl   (%rax)

000000000022c390 <pf_call_5>:
  22c390:	0f 18 15 6c 5d ea ff 	prefetcht1 -0x15a294(%rip)        # d2103 <pf_target_5_0>
  22c397:	0f 18 15 52 5d ea ff 	prefetcht1 -0x15a2ae(%rip)        # d20f0 <pf_target_5_1>
  22c39e:	e9 6d 27 e7 ff       	jmp    9eb10 <pf_callee_4>
  22c3a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c3aa:	00 00 00 
  22c3ad:	0f 1f 00             	nopl   (%rax)

000000000022c3b0 <pf_call_6>:
  22c3b0:	0f 18 15 79 e5 ea ff 	prefetcht1 -0x151a87(%rip)        # da930 <pf_target_6_0>
  22c3b7:	0f 18 15 83 e5 ea ff 	prefetcht1 -0x151a7d(%rip)        # da941 <pf_target_6_1>
  22c3be:	0f 18 15 ab 23 e7 ff 	prefetcht1 -0x18dc55(%rip)        # 9e770 <pf_target_6_2>
  22c3c5:	0f 18 15 84 49 e7 ff 	prefetcht1 -0x18b67c(%rip)        # a0d50 <pf_callee_2>
  22c3cc:	e9 df 3f e7 ff       	jmp    a03b0 <pf_callee_6>
  22c3d1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c3d8:	00 00 00 
  22c3db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c3e0 <pf_call_7>:
  22c3e0:	0f 18 15 99 44 ef ff 	prefetcht1 -0x10bb67(%rip)        # 120880 <pf_target_7_0>
  22c3e7:	0f 18 15 52 4c ef ff 	prefetcht1 -0x10b3ae(%rip)        # 121040 <pf_target_7_1>
  22c3ee:	0f 18 15 9b 55 e7 ff 	prefetcht1 -0x18aa65(%rip)        # a1990 <pf_callee_11>
  22c3f5:	e9 b6 4d e7 ff       	jmp    a11b0 <pf_callee_7>
  22c3fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000022c400 <pf_call_8>:
  22c400:	0f 18 15 7c 10 f1 ff 	prefetcht1 -0xeef84(%rip)        # 13d483 <pf_target_8_0>
  22c407:	e9 84 34 e7 ff       	jmp    9f890 <pf_callee_8>
  22c40c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c410 <pf_call_9>:
  22c410:	0f 18 15 c9 45 e9 ff 	prefetcht1 -0x16ba37(%rip)        # c09e0 <pf_target_9_0>
  22c417:	0f 18 15 65 37 e9 ff 	prefetcht1 -0x16c89b(%rip)        # bfb83 <pf_target_9_1>
  22c41e:	0f 18 15 5b 44 e7 ff 	prefetcht1 -0x18bba5(%rip)        # a0880 <pf_target_9_2>
  22c425:	0f 18 15 34 37 e9 ff 	prefetcht1 -0x16c8cc(%rip)        # bfb60 <pf_target_9_3>
  22c42c:	e9 0f 52 e7 ff       	jmp    a1640 <pf_callee_9>
  22c431:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c438:	00 00 00 
  22c43b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c440 <pf_call_10>:
  22c440:	0f 18 15 99 be ef ff 	prefetcht1 -0x104167(%rip)        # 1282e0 <pf_target_10_0>
  22c447:	0f 18 15 c2 be ef ff 	prefetcht1 -0x10413e(%rip)        # 128310 <pf_target_10_1>
  22c44e:	0f 18 15 fb be ef ff 	prefetcht1 -0x104105(%rip)        # 128350 <pf_target_10_2>
  22c455:	0f 18 15 54 25 e7 ff 	prefetcht1 -0x18daac(%rip)        # 9e9b0 <pf_target_10_3>
  22c45c:	e9 9f 53 e7 ff       	jmp    a1800 <pf_callee_10>
  22c461:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c468:	00 00 00 
  22c46b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c470 <pf_call_11>:
  22c470:	0f 18 15 49 e4 f1 ff 	prefetcht1 -0xe1bb7(%rip)        # 14a8c0 <pf_target_11_0>
  22c477:	e9 14 55 e7 ff       	jmp    a1990 <pf_callee_11>
  22c47c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c480 <pf_call_12>:
  22c480:	0f 18 15 f9 fa f0 ff 	prefetcht1 -0xf0507(%rip)        # 13bf80 <pf_target_12_0>
  22c487:	0f 18 15 e2 fa f0 ff 	prefetcht1 -0xf051e(%rip)        # 13bf70 <pf_target_12_1>
  22c48e:	0f 18 15 7b 4b ef ff 	prefetcht1 -0x10b485(%rip)        # 121010 <pf_target_12_2>
  22c495:	0f 18 15 a4 0e f1 ff 	prefetcht1 -0xef15c(%rip)        # 13d340 <pf_target_12_3>
  22c49c:	e9 0f 32 e7 ff       	jmp    9f6b0 <pf_callee_12>
  22c4a1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c4a8:	00 00 00 
  22c4ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c4b0 <pf_call_13>:
  22c4b0:	0f 18 15 a9 1f e7 ff 	prefetcht1 -0x18e057(%rip)        # 9e460 <pf_target_13_0>
  22c4b7:	0f 18 15 42 1b ef ff 	prefetcht1 -0x10e4be(%rip)        # 11e000 <pf_target_13_1>
  22c4be:	0f 18 15 cb 0b f1 ff 	prefetcht1 -0xef435(%rip)        # 13d090 <pf_target_13_2>
  22c4c5:	0f 18 15 f5 0b f1 ff 	prefetcht1 -0xef40b(%rip)        # 13d0c1 <pf_target_13_3>
  22c4cc:	e9 df 31 e7 ff       	jmp    9f6b0 <pf_callee_12>
  22c4d1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c4d8:	00 00 00 
  22c4db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c4e0 <pf_call_14>:
  22c4e0:	0f 18 15 99 63 f1 ff 	prefetcht1 -0xe9c67(%rip)        # 142880 <pf_target_14_0>
  22c4e7:	0f 18 15 d4 63 f1 ff 	prefetcht1 -0xe9c2c(%rip)        # 1428c2 <pf_target_14_1>
  22c4ee:	0f 18 15 fb 23 f0 ff 	prefetcht1 -0xfdc05(%rip)        # 12e8f0 <pf_callee_15>
  22c4f5:	e9 b6 31 e7 ff       	jmp    9f6b0 <pf_callee_12>
  22c4fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000022c500 <pf_call_15>:
  22c500:	0f 18 15 fb e2 f1 ff 	prefetcht1 -0xe1d05(%rip)        # 14a802 <pf_target_15_0>
  22c507:	0f 18 15 e2 e2 f1 ff 	prefetcht1 -0xe1d1e(%rip)        # 14a7f0 <pf_target_15_1>
  22c50e:	0f 18 15 c3 65 f1 ff 	prefetcht1 -0xe9a3d(%rip)        # 142ad8 <pf_target_15_2>
  22c515:	0f 18 15 54 65 f1 ff 	prefetcht1 -0xe9aac(%rip)        # 142a70 <pf_target_15_3>
  22c51c:	e9 cf 23 f0 ff       	jmp    12e8f0 <pf_callee_15>
  22c521:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c528:	00 00 00 
  22c52b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c530 <pf_call_16>:
  22c530:	0f 18 15 b9 27 f0 ff 	prefetcht1 -0xfd847(%rip)        # 12ecf0 <pf_target_16_0>
  22c537:	0f 18 15 a2 45 e7 ff 	prefetcht1 -0x18ba5e(%rip)        # a0ae0 <pf_target_16_1>
  22c53e:	e9 ad 5c e7 ff       	jmp    a21f0 <pf_callee_16>
  22c543:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c54a:	00 00 00 
  22c54d:	0f 1f 00             	nopl   (%rax)

000000000022c550 <pf_call_17>:
  22c550:	0f 18 15 89 2d f0 ff 	prefetcht1 -0xfd277(%rip)        # 12f2e0 <pf_target_17_0>
  22c557:	0f 18 15 a3 2a f0 ff 	prefetcht1 -0xfd55d(%rip)        # 12f001 <pf_target_17_1>
  22c55e:	0f 18 15 8b 2a f0 ff 	prefetcht1 -0xfd575(%rip)        # 12eff0 <pf_target_17_2>
  22c565:	0f 18 15 d4 ec ef ff 	prefetcht1 -0x10132c(%rip)        # 12b240 <pf_target_17_3>
  22c56c:	e9 7f 5c e7 ff       	jmp    a21f0 <pf_callee_16>
  22c571:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c578:	00 00 00 
  22c57b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c580 <pf_call_18>:
  22c580:	0f 18 15 49 04 f1 ff 	prefetcht1 -0xefbb7(%rip)        # 13c9d0 <pf_target_18_0>
  22c587:	0f 18 15 72 04 f1 ff 	prefetcht1 -0xefb8e(%rip)        # 13ca00 <pf_target_18_1>
  22c58e:	0f 18 15 bb 05 f1 ff 	prefetcht1 -0xefa45(%rip)        # 13cb50 <pf_target_18_2>
  22c595:	e9 f6 38 e7 ff       	jmp    9fe90 <pf_callee_18>
  22c59a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000022c5a0 <pf_call_19>:
  22c5a0:	0f 18 15 d9 5c f1 ff 	prefetcht1 -0xea327(%rip)        # 142280 <pf_target_19_0>
  22c5a7:	0f 18 15 52 04 f1 ff 	prefetcht1 -0xefbae(%rip)        # 13ca00 <pf_target_18_1>
  22c5ae:	0f 18 15 1b 04 f1 ff 	prefetcht1 -0xefbe5(%rip)        # 13c9d0 <pf_target_18_0>
  22c5b5:	e9 d6 38 e7 ff       	jmp    9fe90 <pf_callee_18>
  22c5ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000022c5c0 <pf_call_20>:
  22c5c0:	0f 18 15 f9 19 ef ff 	prefetcht1 -0x10e607(%rip)        # 11dfc0 <pf_target_20_0>
  22c5c7:	0f 18 15 c2 5d e9 ff 	prefetcht1 -0x16a23e(%rip)        # c2390 <pf_target_20_1>
  22c5ce:	0f 18 15 2d e1 ea ff 	prefetcht1 -0x151ed3(%rip)        # da702 <pf_target_20_2>
  22c5d5:	0f 18 15 44 5d e9 ff 	prefetcht1 -0x16a2bc(%rip)        # c2320 <pf_callee_3>
  22c5dc:	e9 cf 2b e7 ff       	jmp    9f1b0 <pf_callee_20>
  22c5e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c5e8:	00 00 00 
  22c5eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c5f0 <pf_call_21>:
  22c5f0:	0f 18 15 09 44 e9 ff 	prefetcht1 -0x16bbf7(%rip)        # c0a00 <pf_target_21_0>
  22c5f7:	0f 18 15 42 18 ef ff 	prefetcht1 -0x10e7be(%rip)        # 11de40 <pf_target_21_1>
  22c5fe:	0f 18 15 bb fc ef ff 	prefetcht1 -0x100345(%rip)        # 12c2c0 <pf_target_21_2>
  22c605:	0f 18 15 14 e0 ef ff 	prefetcht1 -0x101fec(%rip)        # 12a620 <pf_target_21_3>
  22c60c:	e9 8f 4f e7 ff       	jmp    a15a0 <pf_callee_21>
  22c611:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c618:	00 00 00 
  22c61b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c620 <pf_call_22>:
  22c620:	0f 18 15 69 5f f1 ff 	prefetcht1 -0xea097(%rip)        # 142590 <pf_target_22_0>
  22c627:	0f 18 15 94 5f f1 ff 	prefetcht1 -0xea06c(%rip)        # 1425c2 <pf_target_22_1>
  22c62e:	e9 ad 40 e7 ff       	jmp    a06e0 <pf_callee_22>
  22c633:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c63a:	00 00 00 
  22c63d:	0f 1f 00             	nopl   (%rax)

000000000022c640 <pf_call_23>:
  22c640:	0f 18 15 99 00 f2 ff 	prefetcht1 -0xdff67(%rip)        # 14c6e0 <pf_target_23_0>
  22c647:	e9 a4 5a e7 ff       	jmp    a20f0 <pf_callee_23>
  22c64c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c650 <pf_call_24>:
  22c650:	0f 18 15 ab 14 f2 ff 	prefetcht1 -0xdeb55(%rip)        # 14db02 <pf_target_24_0>
  22c657:	0f 18 15 82 14 f2 ff 	prefetcht1 -0xdeb7e(%rip)        # 14dae0 <pf_target_24_1>
  22c65e:	e9 2d 21 e7 ff       	jmp    9e790 <pf_callee_24>
  22c663:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c66a:	00 00 00 
  22c66d:	0f 1f 00             	nopl   (%rax)

000000000022c670 <pf_call_25>:
  22c670:	0f 18 15 99 f5 f1 ff 	prefetcht1 -0xe0a67(%rip)        # 14bc10 <pf_target_25_0>
  22c677:	e9 64 40 e7 ff       	jmp    a06e0 <pf_callee_22>
  22c67c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c680 <pf_call_27>:
  22c680:	0f 18 15 39 14 ef ff 	prefetcht1 -0x10ebc7(%rip)        # 11dac0 <pf_target_27_0>
  22c687:	0f 18 15 92 54 ef ff 	prefetcht1 -0x10ab6e(%rip)        # 121b20 <pf_target_27_1>
  22c68e:	0f 18 15 ad 54 ef ff 	prefetcht1 -0x10ab53(%rip)        # 121b42 <pf_target_27_2>
  22c695:	e9 56 5a e7 ff       	jmp    a20f0 <pf_callee_23>
  22c69a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000022c6a0 <pf_call_28>:
  22c6a0:	0f 18 15 39 1d f2 ff 	prefetcht1 -0xde2c7(%rip)        # 14e3e0 <pf_target_28_0>
  22c6a7:	0f 18 15 57 1d f2 ff 	prefetcht1 -0xde2a9(%rip)        # 14e405 <pf_target_28_1>
  22c6ae:	0f 18 15 4b 4e e7 ff 	prefetcht1 -0x18b1b5(%rip)        # a1500 <pf_target_28_2>
  22c6b5:	0f 18 15 f4 23 e7 ff 	prefetcht1 -0x18dc0c(%rip)        # 9eab0 <pf_target_28_3>
  22c6bc:	e9 0f 44 e7 ff       	jmp    a0ad0 <pf_callee_28>
  22c6c1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c6c8:	00 00 00 
  22c6cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c6d0 <pf_call_29>:
  22c6d0:	0f 18 15 f9 58 e7 ff 	prefetcht1 -0x18a707(%rip)        # a1fd0 <pf_callee_31>
  22c6d7:	e9 f4 43 e7 ff       	jmp    a0ad0 <pf_callee_28>
  22c6dc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c6e0 <pf_call_30>:
  22c6e0:	0f 18 15 a9 24 f2 ff 	prefetcht1 -0xddb57(%rip)        # 14eb90 <pf_target_30_0>
  22c6e7:	0f 18 15 c2 34 e7 ff 	prefetcht1 -0x18cb3e(%rip)        # 9fbb0 <pf_callee_34>
  22c6ee:	e9 fd 59 e7 ff       	jmp    a20f0 <pf_callee_23>
  22c6f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c6fa:	00 00 00 
  22c6fd:	0f 1f 00             	nopl   (%rax)

000000000022c700 <pf_call_31>:
  22c700:	0f 18 15 09 f5 f1 ff 	prefetcht1 -0xe0af7(%rip)        # 14bc10 <pf_target_25_0>
  22c707:	0f 18 15 d2 3f e7 ff 	prefetcht1 -0x18c02e(%rip)        # a06e0 <pf_callee_22>
  22c70e:	0f 18 15 8b 24 e7 ff 	prefetcht1 -0x18db75(%rip)        # 9eba0 <pf_target_31_2>
  22c715:	0f 18 15 68 f9 f1 ff 	prefetcht1 -0xe0698(%rip)        # 14c084 <pf_target_31_3>
  22c71c:	e9 af 58 e7 ff       	jmp    a1fd0 <pf_callee_31>
  22c721:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  22c728:	00 00 00 
  22c72b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000022c730 <pf_call_32>:
  22c730:	0f 18 15 a9 43 e7 ff 	prefetcht1 -0x18bc57(%rip)        # a0ae0 <pf_target_16_1>
  22c737:	0f 18 15 92 58 e7 ff 	prefetcht1 -0x18a76e(%rip)        # a1fd0 <pf_callee_31>
  22c73e:	0f 18 15 7e fa f1 ff 	prefetcht1 -0xe0582(%rip)        # 14c1c3 <pf_target_32_2>
  22c745:	e9 a6 59 e7 ff       	jmp    a20f0 <pf_callee_23>
  22c74a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000022c750 <pf_call_33>:
  22c750:	0f 18 15 b9 f4 f1 ff 	prefetcht1 -0xe0b47(%rip)        # 14bc10 <pf_target_25_0>
  22c757:	e9 74 58 e7 ff       	jmp    a1fd0 <pf_callee_31>
  22c75c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000022c760 <pf_call_34>:
  22c760:	0f 18 15 99 4d e7 ff 	prefetcht1 -0x18b267(%rip)        # a1500 <pf_target_28_2>
  22c767:	e9 44 34 e7 ff       	jmp    9fbb0 <pf_callee_34>
