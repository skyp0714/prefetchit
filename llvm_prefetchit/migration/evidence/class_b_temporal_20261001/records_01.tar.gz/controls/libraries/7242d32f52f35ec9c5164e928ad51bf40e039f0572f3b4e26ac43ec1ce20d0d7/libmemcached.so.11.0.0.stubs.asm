
/storage/prefetchit/class_b_temporal_20261001/controls/libraries/7242d32f52f35ec9c5164e928ad51bf40e039f0572f3b4e26ac43ec1ce20d0d7/call-stub-fepji4wm/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000312c0 <pf_call_0>:
   312c0:	0f 18 15 a9 5c fd ff 	prefetcht1 -0x2a357(%rip)        # 6f70 <pf_callee_16>
   312c7:	0f 18 15 e2 e8 fd ff 	prefetcht1 -0x2171e(%rip)        # fbb0 <pf_callee_18>
   312ce:	0f 18 15 db 44 fe ff 	prefetcht1 -0x1bb25(%rip)        # 157b0 <pf_callee_28>
   312d5:	e9 96 41 fd ff       	jmp    5470 <pf_callee_0>
   312da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000312e0 <pf_call_1>:
   312e0:	0f 18 15 29 43 fd ff 	prefetcht1 -0x2bcd7(%rip)        # 5610 <pf_target_1_0>
   312e7:	0f 18 15 72 a6 fd ff 	prefetcht1 -0x2598e(%rip)        # b960 <pf_callee_7>
   312ee:	e9 6d d5 fe ff       	jmp    1e860 <pf_callee_1>
   312f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   312fa:	00 00 00 
   312fd:	0f 1f 00             	nopl   (%rax)

0000000000031300 <pf_call_2>:
   31300:	0f 18 15 01 b3 fd ff 	prefetcht1 -0x24cff(%rip)        # c608 <pf_target_2_0>
   31307:	0f 18 15 f4 1f fe ff 	prefetcht1 -0x1e00c(%rip)        # 13302 <pf_target_2_1>
   3130e:	e9 cd 41 fd ff       	jmp    54e0 <pf_callee_2>
   31313:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3131a:	00 00 00 
   3131d:	0f 1f 00             	nopl   (%rax)

0000000000031320 <pf_call_3>:
   31320:	0f 18 15 39 d5 fe ff 	prefetcht1 -0x12ac7(%rip)        # 1e860 <pf_callee_1>
   31327:	0f 18 15 53 d5 fe ff 	prefetcht1 -0x12aad(%rip)        # 1e881 <pf_target_3_1>
   3132e:	e9 bd 3e fe ff       	jmp    151f0 <pf_callee_27>
   31333:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3133a:	00 00 00 
   3133d:	0f 1f 00             	nopl   (%rax)

0000000000031340 <pf_call_4>:
   31340:	0f 18 15 d8 e1 fd ff 	prefetcht1 -0x21e28(%rip)        # f51f <pf_target_4_0>
   31347:	0f 18 15 5e d8 fd ff 	prefetcht1 -0x227a2(%rip)        # ebac <pf_target_4_1>
   3134e:	e9 fd d0 fd ff       	jmp    e450 <pf_callee_30>
   31353:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3135a:	00 00 00 
   3135d:	0f 1f 00             	nopl   (%rax)

0000000000031360 <pf_call_5>:
   31360:	0f 18 15 e9 ca fd ff 	prefetcht1 -0x23517(%rip)        # de50 <pf_callee_10>
   31367:	0f 18 15 02 84 fd ff 	prefetcht1 -0x27bfe(%rip)        # 9770 <pf_target_14_2>
   3136e:	0f 18 15 aa e1 fd ff 	prefetcht1 -0x21e56(%rip)        # f51f <pf_target_4_0>
   31375:	0f 18 15 07 84 fd ff 	prefetcht1 -0x27bf9(%rip)        # 9783 <pf_target_33_2>
   3137c:	e9 cf d0 fd ff       	jmp    e450 <pf_callee_30>
   31381:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31388:	00 00 00 
   3138b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031390 <pf_call_6>:
   31390:	0f 18 15 40 e1 fd ff 	prefetcht1 -0x21ec0(%rip)        # f4d7 <pf_target_10_0>
   31397:	0f 18 15 72 42 fd ff 	prefetcht1 -0x2bd8e(%rip)        # 5610 <pf_target_1_0>
   3139e:	e9 bd d4 fe ff       	jmp    1e860 <pf_callee_1>
   313a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   313aa:	00 00 00 
   313ad:	0f 1f 00             	nopl   (%rax)

00000000000313b0 <pf_call_7>:
   313b0:	0f 18 15 b9 e0 fd ff 	prefetcht1 -0x21f47(%rip)        # f470 <pf_target_7_0>
   313b7:	0f 18 15 85 df fd ff 	prefetcht1 -0x2207b(%rip)        # f343 <pf_target_7_1>
   313be:	0f 18 15 72 df fd ff 	prefetcht1 -0x2208e(%rip)        # f337 <pf_target_7_2>
   313c5:	e9 96 a5 fd ff       	jmp    b960 <pf_callee_7>
   313ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000313d0 <pf_call_8>:
   313d0:	0f 18 15 99 40 fd ff 	prefetcht1 -0x2bf67(%rip)        # 5470 <pf_callee_0>
   313d7:	e9 84 a5 fd ff       	jmp    b960 <pf_callee_7>
   313dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000313e0 <pf_call_9>:
   313e0:	0f 18 15 c9 e7 fd ff 	prefetcht1 -0x21837(%rip)        # fbb0 <pf_callee_18>
   313e7:	0f 18 15 92 e5 fd ff 	prefetcht1 -0x21a6e(%rip)        # f980 <pf_callee_11>
   313ee:	0f 18 15 0c e8 fd ff 	prefetcht1 -0x217f4(%rip)        # fc01 <pf_target_9_2>
   313f5:	0f 18 15 c4 e7 fd ff 	prefetcht1 -0x2183c(%rip)        # fbc0 <pf_target_9_3>
   313fc:	e9 ef 3d fe ff       	jmp    151f0 <pf_callee_27>
   31401:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31408:	00 00 00 
   3140b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031410 <pf_call_10>:
   31410:	0f 18 15 c0 e0 fd ff 	prefetcht1 -0x21f40(%rip)        # f4d7 <pf_target_10_0>
   31417:	e9 34 ca fd ff       	jmp    de50 <pf_callee_10>
   3141c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031420 <pf_call_11>:
   31420:	0f 18 15 59 6e fe ff 	prefetcht1 -0x191a7(%rip)        # 18280 <pf_target_11_0>
   31427:	e9 54 e5 fd ff       	jmp    f980 <pf_callee_11>
   3142c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031430 <pf_call_12>:
   31430:	0f 18 15 d9 3b fe ff 	prefetcht1 -0x1c427(%rip)        # 15010 <pf_callee_13>
   31437:	e9 f4 40 fd ff       	jmp    5530 <pf_callee_12>
   3143c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031440 <pf_call_13>:
   31440:	0f 18 15 e9 1b fe ff 	prefetcht1 -0x1e417(%rip)        # 13030 <pf_callee_25>
   31447:	0f 18 15 fa 1b fe ff 	prefetcht1 -0x1e406(%rip)        # 13048 <pf_target_13_1>
   3144e:	0f 18 15 2f 1c fe ff 	prefetcht1 -0x1e3d1(%rip)        # 13084 <pf_target_13_2>
   31455:	e9 b6 3b fe ff       	jmp    15010 <pf_callee_13>
   3145a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031460 <pf_call_14>:
   31460:	0f 18 15 e9 c9 fd ff 	prefetcht1 -0x23617(%rip)        # de50 <pf_callee_10>
   31467:	0f 18 15 e2 cf fd ff 	prefetcht1 -0x2301e(%rip)        # e450 <pf_callee_30>
   3146e:	0f 18 15 fb 82 fd ff 	prefetcht1 -0x27d05(%rip)        # 9770 <pf_target_14_2>
   31475:	0f 18 15 c6 76 fe ff 	prefetcht1 -0x1893a(%rip)        # 18b42 <pf_target_14_3>
   3147c:	e9 ff 1d fe ff       	jmp    13280 <pf_callee_14>
   31481:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31488:	00 00 00 
   3148b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031490 <pf_call_15>:
   31490:	0f 18 15 ea aa fd ff 	prefetcht1 -0x25516(%rip)        # bf81 <pf_target_15_0>
   31497:	0f 18 15 92 aa fd ff 	prefetcht1 -0x2556e(%rip)        # bf30 <pf_target_15_1>
   3149e:	e9 ad c9 fd ff       	jmp    de50 <pf_callee_10>
   314a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   314aa:	00 00 00 
   314ad:	0f 1f 00             	nopl   (%rax)

00000000000314b0 <pf_call_16>:
   314b0:	0f 18 15 99 53 fe ff 	prefetcht1 -0x1ac67(%rip)        # 16850 <pf_target_16_0>
   314b7:	0f 18 15 c4 53 fe ff 	prefetcht1 -0x1ac3c(%rip)        # 16882 <pf_target_16_1>
   314be:	0f 18 15 fd 53 fe ff 	prefetcht1 -0x1ac03(%rip)        # 168c2 <pf_target_16_2>
   314c5:	e9 a6 5a fd ff       	jmp    6f70 <pf_callee_16>
   314ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000314d0 <pf_call_17>:
   314d0:	0f 18 15 6b d2 fd ff 	prefetcht1 -0x22d95(%rip)        # e742 <pf_target_17_0>
   314d7:	0f 18 15 12 d2 fd ff 	prefetcht1 -0x22dee(%rip)        # e6f0 <pf_target_17_1>
   314de:	0f 18 15 1f d2 fd ff 	prefetcht1 -0x22de1(%rip)        # e704 <pf_target_17_2>
   314e5:	0f 18 15 94 1d fe ff 	prefetcht1 -0x1e26c(%rip)        # 13280 <pf_callee_14>
   314ec:	e9 9f f1 fd ff       	jmp    10690 <pf_callee_17>
   314f1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   314f8:	00 00 00 
   314fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031500 <pf_call_18>:
   31500:	0f 18 15 79 e4 fd ff 	prefetcht1 -0x21b87(%rip)        # f980 <pf_callee_11>
   31507:	0f 18 15 b2 e4 fd ff 	prefetcht1 -0x21b4e(%rip)        # f9c0 <pf_target_18_1>
   3150e:	e9 9d e6 fd ff       	jmp    fbb0 <pf_callee_18>
   31513:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3151a:	00 00 00 
   3151d:	0f 1f 00             	nopl   (%rax)

0000000000031520 <pf_call_19>:
   31520:	0f 18 15 69 f1 fd ff 	prefetcht1 -0x20e97(%rip)        # 10690 <pf_callee_17>
   31527:	0f 18 15 c2 3c fe ff 	prefetcht1 -0x1c33e(%rip)        # 151f0 <pf_callee_27>
   3152e:	e9 fd 04 fe ff       	jmp    11a30 <pf_callee_19>
   31533:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3153a:	00 00 00 
   3153d:	0f 1f 00             	nopl   (%rax)

0000000000031540 <pf_call_20>:
   31540:	0f 18 15 b9 95 fd ff 	prefetcht1 -0x26a47(%rip)        # ab00 <pf_target_20_0>
   31547:	0f 18 15 f6 95 fd ff 	prefetcht1 -0x26a0a(%rip)        # ab44 <pf_target_20_1>
   3154e:	e9 2d b3 fd ff       	jmp    c880 <pf_callee_20>
   31553:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3155a:	00 00 00 
   3155d:	0f 1f 00             	nopl   (%rax)

0000000000031560 <pf_call_21>:
   31560:	0f 18 15 5b 24 fe ff 	prefetcht1 -0x1dba5(%rip)        # 139c2 <pf_target_21_0>
   31567:	0f 18 15 f2 79 fe ff 	prefetcht1 -0x1860e(%rip)        # 18f60 <pf_target_21_1>
   3156e:	0f 18 15 12 78 fe ff 	prefetcht1 -0x187ee(%rip)        # 18d87 <pf_target_21_2>
   31575:	0f 18 15 00 78 fe ff 	prefetcht1 -0x18800(%rip)        # 18d7c <pf_target_21_3>
   3157c:	e9 ff b2 fd ff       	jmp    c880 <pf_callee_20>
   31581:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31588:	00 00 00 
   3158b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031590 <pf_call_22>:
   31590:	0f 18 15 39 55 fd ff 	prefetcht1 -0x2aac7(%rip)        # 6ad0 <pf_target_22_0>
   31597:	0f 18 15 83 25 fe ff 	prefetcht1 -0x1da7d(%rip)        # 13b21 <pf_target_22_1>
   3159e:	e9 dd b2 fd ff       	jmp    c880 <pf_callee_20>
   315a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   315aa:	00 00 00 
   315ad:	0f 1f 00             	nopl   (%rax)

00000000000315b0 <pf_call_23>:
   315b0:	0f 18 15 59 3a fe ff 	prefetcht1 -0x1c5a7(%rip)        # 15010 <pf_callee_13>
   315b7:	0f 18 15 46 e4 fd ff 	prefetcht1 -0x21bba(%rip)        # fa04 <pf_target_23_1>
   315be:	e9 bd b2 fd ff       	jmp    c880 <pf_callee_20>
   315c3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   315ca:	00 00 00 
   315cd:	0f 1f 00             	nopl   (%rax)

00000000000315d0 <pf_call_24>:
   315d0:	0f 18 15 ab 52 fe ff 	prefetcht1 -0x1ad55(%rip)        # 16882 <pf_target_16_1>
   315d7:	e9 a4 b2 fd ff       	jmp    c880 <pf_callee_20>
   315dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000315e0 <pf_call_25>:
   315e0:	0f 18 15 9e 05 fe ff 	prefetcht1 -0x1fa62(%rip)        # 11b85 <pf_target_25_0>
   315e7:	0f 18 15 52 05 fe ff 	prefetcht1 -0x1faae(%rip)        # 11b40 <pf_target_25_1>
   315ee:	e9 3d 1a fe ff       	jmp    13030 <pf_callee_25>
   315f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   315fa:	00 00 00 
   315fd:	0f 1f 00             	nopl   (%rax)

0000000000031600 <pf_call_26>:
   31600:	0f 18 15 19 17 fe ff 	prefetcht1 -0x1e8e7(%rip)        # 12d20 <pf_target_26_0>
   31607:	e9 84 f0 fd ff       	jmp    10690 <pf_callee_17>
   3160c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031610 <pf_call_27>:
   31610:	0f 18 15 69 b2 fd ff 	prefetcht1 -0x24d97(%rip)        # c880 <pf_callee_20>
   31617:	0f 18 15 a2 b2 fd ff 	prefetcht1 -0x24d5e(%rip)        # c8c0 <pf_target_27_1>
   3161e:	e9 cd 3b fe ff       	jmp    151f0 <pf_callee_27>
   31623:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3162a:	00 00 00 
   3162d:	0f 1f 00             	nopl   (%rax)

0000000000031630 <pf_call_28>:
   31630:	0f 18 15 49 b2 fd ff 	prefetcht1 -0x24db7(%rip)        # c880 <pf_callee_20>
   31637:	0f 18 15 82 af fd ff 	prefetcht1 -0x2507e(%rip)        # c5c0 <pf_target_28_1>
   3163e:	0f 18 15 3b 28 fe ff 	prefetcht1 -0x1d7c5(%rip)        # 13e80 <pf_target_28_2>
   31645:	0f 18 15 74 b2 fd ff 	prefetcht1 -0x24d8c(%rip)        # c8c0 <pf_target_27_1>
   3164c:	e9 5f 41 fe ff       	jmp    157b0 <pf_callee_28>
   31651:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   31658:	00 00 00 
   3165b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000031660 <pf_call_29>:
   31660:	0f 18 15 19 1c fe ff 	prefetcht1 -0x1e3e7(%rip)        # 13280 <pf_callee_14>
   31667:	e9 24 f0 fd ff       	jmp    10690 <pf_callee_17>
   3166c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031670 <pf_call_30>:
   31670:	0f 18 15 05 77 fe ff 	prefetcht1 -0x188fb(%rip)        # 18d7c <pf_target_21_3>
   31677:	e9 d4 cd fd ff       	jmp    e450 <pf_callee_30>
   3167c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000031680 <pf_call_31>:
   31680:	0f 18 15 a9 74 fe ff 	prefetcht1 -0x18b57(%rip)        # 18b30 <pf_target_31_0>
   31687:	0f 18 15 f4 74 fe ff 	prefetcht1 -0x18b0c(%rip)        # 18b82 <pf_target_31_1>
   3168e:	0f 18 15 2b a4 fd ff 	prefetcht1 -0x25bd5(%rip)        # bac0 <pf_target_31_2>
   31695:	0f 18 15 84 76 fe ff 	prefetcht1 -0x1897c(%rip)        # 18d20 <pf_target_31_3>
   3169c:	e9 af c7 fd ff       	jmp    de50 <pf_callee_10>
   316a1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   316a8:	00 00 00 
   316ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000316b0 <pf_call_32>:
   316b0:	0f 18 15 d9 ef fd ff 	prefetcht1 -0x21027(%rip)        # 10690 <pf_callee_17>
   316b7:	e9 34 78 fe ff       	jmp    18ef0 <pf_callee_32>
   316bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000316c0 <pf_call_33>:
   316c0:	0f 18 15 c9 ef fd ff 	prefetcht1 -0x21037(%rip)        # 10690 <pf_callee_17>
   316c7:	0f 18 15 22 3b fe ff 	prefetcht1 -0x1c4de(%rip)        # 151f0 <pf_callee_27>
   316ce:	0f 18 15 ae 80 fd ff 	prefetcht1 -0x27f52(%rip)        # 9783 <pf_target_33_2>
   316d5:	0f 18 15 81 ce fd ff 	prefetcht1 -0x2317f(%rip)        # e55d <pf_target_33_3>
   316dc:	e9 0f 78 fe ff       	jmp    18ef0 <pf_callee_32>
   316e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   316e8:	00 00 00 
   316eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000316f0 <pf_call_34>:
   316f0:	0f 18 15 b1 d8 fe ff 	prefetcht1 -0x1274f(%rip)        # 1efa8 <pf_target_34_0>
   316f7:	0f 18 15 c8 d8 fe ff 	prefetcht1 -0x12738(%rip)        # 1efc6 <pf_target_34_1>
   316fe:	0f 18 15 6b d8 fe ff 	prefetcht1 -0x12795(%rip)        # 1ef70 <pf_target_34_2>
   31705:	e9 d6 40 fd ff       	jmp    57e0 <pf_callee_34>
   3170a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000031710 <pf_call_35>:
   31710:	0f 18 15 f7 e2 fe ff 	prefetcht1 -0x11d09(%rip)        # 1fa0e <pf_target_35_0>
   31717:	0f 18 15 aa d6 fe ff 	prefetcht1 -0x12956(%rip)        # 1edc8 <pf_target_35_1>
   3171e:	0f 18 15 9c e4 fe ff 	prefetcht1 -0x11b64(%rip)        # 1fbc1 <pf_target_35_2>
   31725:	e9 46 3d fd ff       	jmp    5470 <pf_callee_0>
