
/storage/prefetchit/class_b_temporal_20261001/controls/native/user/call-stub-nmff45p0/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000013f340 <pf_call_0>:
  13f340:	0f 18 15 b4 68 f1 ff 	prefetcht1 -0xe974c(%rip)        # 55bfb <pf_target_0_0>
  13f347:	0f 18 15 a2 72 f1 ff 	prefetcht1 -0xe8d5e(%rip)        # 565f0 <pf_target_0_1>
  13f34e:	0f 18 15 2b 68 f1 ff 	prefetcht1 -0xe97d5(%rip)        # 55b80 <pf_target_0_2>
  13f355:	e9 f6 a0 ee ff       	jmp    29450 <pf_callee_0>
  13f35a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000013f360 <pf_call_1>:
  13f360:	0f 18 15 f9 39 f0 ff 	prefetcht1 -0xfc607(%rip)        # 42d60 <pf_target_1_0>
  13f367:	e9 e4 a0 ee ff       	jmp    29450 <pf_callee_0>
  13f36c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f370 <pf_call_2>:
  13f370:	0f 18 15 49 25 f0 ff 	prefetcht1 -0xfdab7(%rip)        # 418c0 <pf_callee_4>
  13f377:	0f 18 15 52 da f8 ff 	prefetcht1 -0x725ae(%rip)        # ccdd0 <pf_callee_3>
  13f37e:	0f 18 15 9b fd f6 ff 	prefetcht1 -0x90265(%rip)        # af120 <pf_target_2_2>
  13f385:	e9 e6 9c ee ff       	jmp    29070 <pf_callee_2>
  13f38a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000013f390 <pf_call_3>:
  13f390:	0f 18 15 f9 ad f7 ff 	prefetcht1 -0x85207(%rip)        # ba190 <pf_target_3_0>
  13f397:	0f 18 15 92 3f f7 ff 	prefetcht1 -0x8c06e(%rip)        # b3330 <pf_target_3_1>
  13f39e:	0f 18 15 1b 07 f7 ff 	prefetcht1 -0x8f8e5(%rip)        # afac0 <pf_target_3_2>
  13f3a5:	0f 18 15 74 87 fa ff 	prefetcht1 -0x5788c(%rip)        # e7b20 <pf_target_3_3>
  13f3ac:	e9 1f da f8 ff       	jmp    ccdd0 <pf_callee_3>
  13f3b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f3b8:	00 00 00 
  13f3bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000013f3c0 <pf_call_4>:
  13f3c0:	0f 18 15 79 3f f7 ff 	prefetcht1 -0x8c087(%rip)        # b3340 <pf_target_4_0>
  13f3c7:	0f 18 15 72 8c fa ff 	prefetcht1 -0x5738e(%rip)        # e8040 <pf_target_4_1>
  13f3ce:	0f 18 15 2b 31 fb ff 	prefetcht1 -0x4ced5(%rip)        # f2500 <pf_target_4_2>
  13f3d5:	0f 18 15 a4 d8 f8 ff 	prefetcht1 -0x7275c(%rip)        # ccc80 <pf_target_4_3>
  13f3dc:	e9 df 24 f0 ff       	jmp    418c0 <pf_callee_4>
  13f3e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f3e8:	00 00 00 
  13f3eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000013f3f0 <pf_call_5>:
  13f3f0:	0f 18 15 59 74 f3 ff 	prefetcht1 -0xc8ba7(%rip)        # 76850 <pf_target_5_0>
  13f3f7:	e9 e4 9d ee ff       	jmp    291e0 <pf_callee_13>
  13f3fc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f400 <pf_call_6>:
  13f400:	0f 18 15 d9 74 f3 ff 	prefetcht1 -0xc8b27(%rip)        # 768e0 <pf_target_6_0>
  13f407:	0f 18 15 42 a3 ee ff 	prefetcht1 -0x115cbe(%rip)        # 29750 <pf_callee_7>
  13f40e:	e9 1d 46 f0 ff       	jmp    43a30 <pf_callee_6>
  13f413:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f41a:	00 00 00 
  13f41d:	0f 1f 00             	nopl   (%rax)

000000000013f420 <pf_call_7>:
  13f420:	0f 18 15 2b 8b ef ff 	prefetcht1 -0x1074d5(%rip)        # 37f52 <pf_target_7_0>
  13f427:	e9 24 a3 ee ff       	jmp    29750 <pf_callee_7>
  13f42c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f430 <pf_call_8>:
  13f430:	0f 18 15 16 61 f4 ff 	prefetcht1 -0xb9eea(%rip)        # 8554d <pf_target_8_0>
  13f437:	e9 a4 cb f1 ff       	jmp    5bfe0 <pf_callee_8>
  13f43c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f440 <pf_call_9>:
  13f440:	0f 18 15 89 9d f6 ff 	prefetcht1 -0x96277(%rip)        # a91d0 <pf_target_9_0>
  13f447:	e9 a4 a4 ee ff       	jmp    298f0 <pf_callee_9>
  13f44c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f450 <pf_call_10>:
  13f450:	0f 18 15 b9 16 f5 ff 	prefetcht1 -0xae947(%rip)        # 90b10 <pf_target_10_0>
  13f457:	e9 e4 9f ee ff       	jmp    29440 <pf_callee_10>
  13f45c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f460 <pf_call_11>:
  13f460:	0f 18 15 29 be f1 ff 	prefetcht1 -0xe41d7(%rip)        # 5b290 <pf_target_11_0>
  13f467:	e9 04 9e ee ff       	jmp    29270 <pf_callee_11>
  13f46c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f470 <pf_call_12>:
  13f470:	0f 18 15 49 a3 ee ff 	prefetcht1 -0x115cb7(%rip)        # 297c0 <pf_target_12_0>
  13f477:	e9 f4 a7 ee ff       	jmp    29c70 <pf_callee_12>
  13f47c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f480 <pf_call_13>:
  13f480:	0f 18 15 f9 86 f1 ff 	prefetcht1 -0xe7907(%rip)        # 57b80 <pf_target_13_0>
  13f487:	e9 54 9d ee ff       	jmp    291e0 <pf_callee_13>
  13f48c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f490 <pf_call_14>:
  13f490:	0f 18 15 c9 6d f1 ff 	prefetcht1 -0xe9237(%rip)        # 56260 <pf_target_14_0>
  13f497:	e9 d4 9c ee ff       	jmp    29170 <pf_callee_14>
  13f49c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f4a0 <pf_call_15>:
  13f4a0:	0f 18 15 39 6d f1 ff 	prefetcht1 -0xe92c7(%rip)        # 561e0 <pf_target_15_0>
  13f4a7:	e9 c4 9c ee ff       	jmp    29170 <pf_callee_14>
  13f4ac:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f4b0 <pf_call_16>:
  13f4b0:	0f 18 15 09 ac ee ff 	prefetcht1 -0x1153f7(%rip)        # 2a0c0 <pf_callee_31>
  13f4b7:	e9 24 9d ee ff       	jmp    291e0 <pf_callee_13>
  13f4bc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f4c0 <pf_call_17>:
  13f4c0:	0f 18 15 59 35 f1 ff 	prefetcht1 -0xecaa7(%rip)        # 52a20 <pf_callee_18>
  13f4c7:	e9 54 81 f1 ff       	jmp    57620 <pf_callee_17>
  13f4cc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f4d0 <pf_call_18>:
  13f4d0:	0f 18 15 19 7c f1 ff 	prefetcht1 -0xe83e7(%rip)        # 570f0 <pf_target_18_0>
  13f4d7:	e9 44 35 f1 ff       	jmp    52a20 <pf_callee_18>
  13f4dc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f4e0 <pf_call_19>:
  13f4e0:	0f 18 15 c9 ad ee ff 	prefetcht1 -0x115237(%rip)        # 2a2b0 <pf_target_19_0>
  13f4e7:	e9 34 35 f1 ff       	jmp    52a20 <pf_callee_18>
  13f4ec:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f4f0 <pf_call_20>:
  13f4f0:	0f 18 15 99 a2 ee ff 	prefetcht1 -0x115d67(%rip)        # 29790 <pf_target_20_0>
  13f4f7:	e9 44 9f ee ff       	jmp    29440 <pf_callee_10>
  13f4fc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f500 <pf_call_21>:
  13f500:	0f 18 15 7e 38 f4 ff 	prefetcht1 -0xbc782(%rip)        # 82d85 <pf_target_21_0>
  13f507:	0f 18 15 a8 34 f4 ff 	prefetcht1 -0xbcb58(%rip)        # 829b6 <pf_target_21_1>
  13f50e:	e9 cd 9c ee ff       	jmp    291e0 <pf_callee_13>
  13f513:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f51a:	00 00 00 
  13f51d:	0f 1f 00             	nopl   (%rax)

000000000013f520 <pf_call_22>:
  13f520:	0f 18 15 c9 de f8 ff 	prefetcht1 -0x72137(%rip)        # cd3f0 <pf_target_22_0>
  13f527:	0f 18 15 32 43 f2 ff 	prefetcht1 -0xdbcce(%rip)        # 63860 <pf_target_22_1>
  13f52e:	0f 18 15 4b 43 f2 ff 	prefetcht1 -0xdbcb5(%rip)        # 63880 <pf_target_22_2>
  13f535:	e9 36 a0 f6 ff       	jmp    a9570 <pf_callee_22>
  13f53a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000013f540 <pf_call_23>:
  13f540:	0f 18 15 39 a3 ee ff 	prefetcht1 -0x115cc7(%rip)        # 29880 <pf_target_23_0>
  13f547:	e9 c4 85 f3 ff       	jmp    77b10 <pf_callee_23>
  13f54c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f550 <pf_call_24>:
  13f550:	0f 18 15 89 c3 f1 ff 	prefetcht1 -0xe3c77(%rip)        # 5b8e0 <pf_target_24_0>
  13f557:	0f 18 15 82 ae ee ff 	prefetcht1 -0x11517e(%rip)        # 2a3e0 <pf_target_24_1>
  13f55e:	e9 cd a7 f4 ff       	jmp    89d30 <pf_callee_24>
  13f563:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f56a:	00 00 00 
  13f56d:	0f 1f 00             	nopl   (%rax)

000000000013f570 <pf_call_25>:
  13f570:	0f 18 15 49 fb f3 ff 	prefetcht1 -0xc04b7(%rip)        # 7f0c0 <pf_callee_26>
  13f577:	0f 18 15 72 7a f3 ff 	prefetcht1 -0xc858e(%rip)        # 76ff0 <pf_target_25_1>
  13f57e:	0f 18 15 1b 5d f4 ff 	prefetcht1 -0xba2e5(%rip)        # 852a0 <pf_target_25_2>
  13f585:	e9 c6 ae ee ff       	jmp    2a450 <pf_callee_25>
  13f58a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000013f590 <pf_call_26>:
  13f590:	0f 18 15 59 7e f3 ff 	prefetcht1 -0xc81a7(%rip)        # 773f0 <pf_target_26_0>
  13f597:	e9 24 fb f3 ff       	jmp    7f0c0 <pf_callee_26>
  13f59c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f5a0 <pf_call_27>:
  13f5a0:	0f 18 15 99 80 f3 ff 	prefetcht1 -0xc7f67(%rip)        # 77640 <pf_target_27_0>
  13f5a7:	0f 18 15 b2 75 f3 ff 	prefetcht1 -0xc8a4e(%rip)        # 76b60 <pf_target_27_1>
  13f5ae:	e9 bd a6 ee ff       	jmp    29c70 <pf_callee_12>
  13f5b3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f5ba:	00 00 00 
  13f5bd:	0f 1f 00             	nopl   (%rax)

000000000013f5c0 <pf_call_28>:
  13f5c0:	0f 18 15 29 9f f4 ff 	prefetcht1 -0xb60d7(%rip)        # 894f0 <pf_target_28_0>
  13f5c7:	e9 14 9c ee ff       	jmp    291e0 <pf_callee_13>
  13f5cc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f5d0 <pf_call_29>:
  13f5d0:	0f 18 15 19 7a f3 ff 	prefetcht1 -0xc85e7(%rip)        # 76ff0 <pf_target_25_1>
  13f5d7:	0f 18 15 1e f4 f4 ff 	prefetcht1 -0xb0be2(%rip)        # 8e9fc <pf_target_29_1>
  13f5de:	0f 18 15 cb f3 f4 ff 	prefetcht1 -0xb0c35(%rip)        # 8e9b0 <pf_target_29_2>
  13f5e5:	0f 18 15 0f 1a f5 ff 	prefetcht1 -0xae5f1(%rip)        # 90ffb <pf_target_29_3>
  13f5ec:	e9 df aa ee ff       	jmp    2a0d0 <pf_callee_29>
  13f5f1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f5f8:	00 00 00 
  13f5fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000013f600 <pf_call_30>:
  13f600:	0f 18 15 29 44 f0 ff 	prefetcht1 -0xfbbd7(%rip)        # 43a30 <pf_callee_6>
  13f607:	0f 18 15 d1 82 ef ff 	prefetcht1 -0x107d2f(%rip)        # 378df <pf_target_30_1>
  13f60e:	e9 5d f1 f5 ff       	jmp    9e770 <pf_callee_30>
  13f613:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f61a:	00 00 00 
  13f61d:	0f 1f 00             	nopl   (%rax)

000000000013f620 <pf_call_31>:
  13f620:	0f 18 15 89 7c f2 ff 	prefetcht1 -0xd8377(%rip)        # 672b0 <pf_target_31_0>
  13f627:	e9 94 aa ee ff       	jmp    2a0c0 <pf_callee_31>
