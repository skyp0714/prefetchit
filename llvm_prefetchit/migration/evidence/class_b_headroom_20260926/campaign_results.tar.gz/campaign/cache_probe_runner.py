import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

os.sched_setaffinity(0,{84,85})
repo=Path('/home/hnpark2/prefetchit')
out=Path('/storage/prefetchit/class_b_headroom_20260926')
module=repo/'llvm_prefetchit/kernel/wake_prefetch'
while True:
    try:os.kill(2664750,0)
    except ProcessLookupError:break
    print('Waiting for application confirmation to exit before any build',flush=True)
    time.sleep(50)
assert (out/'confirmation_complete.json').exists()
assert not Path('/sys/module/wake_prefetch').exists()
assert shutil.disk_usage(repo).free>2*1024**3
assert shutil.disk_usage(out).free>2*1024**3
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
(out/'cache_probe_runner.py').write_bytes(Path(__file__).read_bytes())
before={p for p in module.iterdir() if p.is_file()}
record=dict(free_before_build=shutil.disk_usage(repo).free,
    source_sha256={str(module/name):sha(module/name) for name in
        ['wake_prefetch.c','wake_prefetch.h','Makefile','control.py','cache_probe.py']},commands=[])
try:
    command=['make','-C',str(module),'-j4'];record['commands'].append(command)
    with (out/'cache_probe_build.log').open('w') as log:
        subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
    record['module_sha256']=sha(module/'wake_prefetch.ko')
    record['modinfo']=subprocess.check_output(['modinfo',str(module/'wake_prefetch.ko')],text=True)
    assert shutil.disk_usage(repo).free>2*1024**3
    command=['python3',str(repo/'llvm_prefetchit/results/class_b_extension_20260926/run_platform.py'),
        '--out',str(out/'platform_cache_probe'),'--cpus','42','python3',str(module/'cache_probe.py'),
        '--out',str(out/'kernel_cache_probe'),'--cpu','42']
    record['commands'].append(command)
    with (out/'cache_probe_run.log').open('w') as log:
        subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=180)
    record['passed']=True
except BaseException as error:
    record.update(passed=False,error=repr(error));raise
finally:
    record['module_unloaded']=not Path('/sys/module/wake_prefetch').exists()
    generated=[p for p in module.iterdir() if p.is_file() and not p.is_symlink() and p not in before]
    assert all(p.suffix in {'.ko','.o','.cmd','.mod','.c','.symvers'} or p.name=='modules.order' for p in generated),generated
    record['cleanup']=dict(reason='Functional diagnostic complete; application kernel policies were rejected',
        free_before=shutil.disk_usage(repo).free,
        removed=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in generated])
    save(out/'cache_probe_build_cleanup.json',record)
    assert record['module_unloaded'],'preserve active module build until it is unloaded'
    for p in generated:p.unlink()
    record['cleanup']['free_after']=shutil.disk_usage(repo).free
    save(out/'cache_probe_build_cleanup.json',record)
print(json.dumps(dict(passed=record['passed'],module_unloaded=record['module_unloaded'],
    removed_bytes=sum(x['bytes'] for x in record['cleanup']['removed']))),flush=True)
