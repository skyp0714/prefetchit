
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <x86intrin.h>
extern unsigned char cold_line[];
__asm__(".pushsection .text\n.p2align 12\n.globl cold_line\n"
        ".type cold_line,@function\ncold_line:\n.fill 64,1,0x90\nret\n"
        ".size cold_line,.-cold_line\n.popsection\n");
static unsigned long long samples[500];
int main(int argc,char **argv) {
    int positive=argc>1 && atoi(argv[1]);
    struct timespec req={.tv_sec=0,.tv_nsec=1000000};
    puts("ready");fflush(stdout);if(getchar()!='g')return 2;
    for(int i=0;i<500;i++) {
        __asm__ volatile("clflush (%0)\n\tmfence"::"r"(cold_line):"memory");
        if(positive)__asm__ volatile("prefetcht1 (%0)"::"r"(cold_line):"memory");
        if(syscall(SYS_clock_nanosleep,CLOCK_MONOTONIC,0,&req,0))return 3;
        unsigned a,b;
        _mm_lfence();unsigned long long start=__rdtscp(&a);_mm_lfence();
        unsigned char value=*(volatile unsigned char*)cold_line;
        _mm_lfence();unsigned long long end=__rdtscp(&b);_mm_lfence();
        if(value!=0x90 || a!=b)return 4;
        samples[i]=end-start;
    }
    for(int i=0;i<500;i++)printf("%llu\n",samples[i]);
    return 0;
}
