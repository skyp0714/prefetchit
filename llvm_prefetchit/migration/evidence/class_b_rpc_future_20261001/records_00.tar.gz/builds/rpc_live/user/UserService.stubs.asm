
/storage/prefetchit/class_b_rpc_future_20261001/builds/rpc_live/user/call-stub-4gfml6_m/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000013f340 <pf_call_0>:
  13f340:	0f 18 15 bc 68 f1 ff 	prefetcht1 -0xe9744(%rip)        # 55c03 <pf_target_0_0>
  13f347:	0f 18 15 a2 72 f1 ff 	prefetcht1 -0xe8d5e(%rip)        # 565f0 <pf_target_0_1>
  13f34e:	0f 18 15 2b 68 f1 ff 	prefetcht1 -0xe97d5(%rip)        # 55b80 <pf_target_0_2>
  13f355:	0f 18 15 a6 bf f1 ff 	prefetcht1 -0xe405a(%rip)        # 5b302 <pf_target_0_3>
  13f35c:	0f 18 15 2d bf f1 ff 	prefetcht1 -0xe40d3(%rip)        # 5b290 <pf_target_0_4>
  13f363:	0f 18 15 58 bf f1 ff 	prefetcht1 -0xe40a8(%rip)        # 5b2c2 <pf_target_0_5>

000000000013f36a <pf_jump_0>:
  13f36a:	e9 e1 a0 ee ff       	jmp    29450 <pf_callee_0>
  13f36f:	90                   	nop

000000000013f370 <pf_call_1>:
  13f370:	0f 18 15 e9 39 f0 ff 	prefetcht1 -0xfc617(%rip)        # 42d60 <pf_target_1_0>

000000000013f377 <pf_jump_1>:
  13f377:	e9 d4 a0 ee ff       	jmp    29450 <pf_callee_0>
  13f37c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f380 <pf_call_2>:
  13f380:	0f 18 15 49 ae ee ff 	prefetcht1 -0x1151b7(%rip)        # 2a1d0 <pf_target_2_0>

000000000013f387 <pf_jump_2>:
  13f387:	e9 54 9e ee ff       	jmp    291e0 <pf_callee_16>
  13f38c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f390 <pf_call_3>:
  13f390:	0f 18 15 99 3f f7 ff 	prefetcht1 -0x8c067(%rip)        # b3330 <pf_target_3_0>
  13f397:	0f 18 15 f2 ad f7 ff 	prefetcht1 -0x8520e(%rip)        # ba190 <pf_target_3_1>
  13f39e:	0f 18 15 1b 07 f7 ff 	prefetcht1 -0x8f8e5(%rip)        # afac0 <pf_target_3_2>
  13f3a5:	0f 18 15 24 da f8 ff 	prefetcht1 -0x725dc(%rip)        # ccdd0 <pf_callee_5>
  13f3ac:	0f 18 15 3d b0 ee ff 	prefetcht1 -0x114fc3(%rip)        # 2a3f0 <pf_target_3_4>
  13f3b3:	0f 18 15 0b ae f7 ff 	prefetcht1 -0x851f5(%rip)        # ba1c5 <pf_target_3_5>
  13f3ba:	0f 18 15 7f 3f f7 ff 	prefetcht1 -0x8c081(%rip)        # b3340 <pf_target_3_6>
  13f3c1:	0f 18 15 b8 d8 f8 ff 	prefetcht1 -0x72748(%rip)        # ccc80 <pf_target_3_7>

000000000013f3c8 <pf_jump_3>:
  13f3c8:	e9 43 cb f1 ff       	jmp    5bf10 <pf_callee_3>
  13f3cd:	0f 1f 00             	nopl   (%rax)

000000000013f3d0 <pf_call_4>:
  13f3d0:	0f 18 15 49 87 fa ff 	prefetcht1 -0x578b7(%rip)        # e7b20 <pf_target_4_0>
  13f3d7:	0f 18 15 22 31 fb ff 	prefetcht1 -0x4cede(%rip)        # f2500 <pf_target_4_1>
  13f3de:	0f 18 15 5b 8c fa ff 	prefetcht1 -0x573a5(%rip)        # e8040 <pf_target_4_2>

000000000013f3e5 <pf_jump_4>:
  13f3e5:	e9 86 9c ee ff       	jmp    29070 <pf_callee_4>
  13f3ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000013f3f0 <pf_call_5>:
  13f3f0:	0f 18 15 d9 9d f6 ff 	prefetcht1 -0x96227(%rip)        # a91d0 <pf_target_5_0>

000000000013f3f7 <pf_jump_5>:
  13f3f7:	e9 d4 d9 f8 ff       	jmp    ccdd0 <pf_callee_5>
  13f3fc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f400 <pf_call_6>:
  13f400:	0f 18 15 c9 3a f0 ff 	prefetcht1 -0xfc537(%rip)        # 42ed0 <pf_target_6_0>

000000000013f407 <pf_jump_6>:
  13f407:	e9 d4 9d ee ff       	jmp    291e0 <pf_callee_16>
  13f40c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f410 <pf_call_7>:
  13f410:	0f 18 15 c9 74 f3 ff 	prefetcht1 -0xc8b37(%rip)        # 768e0 <pf_target_7_0>
  13f417:	0f 18 15 32 a3 ee ff 	prefetcht1 -0x115cce(%rip)        # 29750 <pf_callee_8>

000000000013f41e <pf_jump_7>:
  13f41e:	e9 0d 46 f0 ff       	jmp    43a30 <pf_callee_7>
  13f423:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f42a:	00 00 00 
  13f42d:	0f 1f 00             	nopl   (%rax)

000000000013f430 <pf_call_8>:
  13f430:	0f 18 15 1b 8b ef ff 	prefetcht1 -0x1074e5(%rip)        # 37f52 <pf_target_8_0>

000000000013f437 <pf_jump_8>:
  13f437:	e9 14 a3 ee ff       	jmp    29750 <pf_callee_8>
  13f43c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f440 <pf_call_9>:
  13f440:	0f 18 15 06 61 f4 ff 	prefetcht1 -0xb9efa(%rip)        # 8554d <pf_target_9_0>

000000000013f447 <pf_jump_9>:
  13f447:	e9 94 cb f1 ff       	jmp    5bfe0 <pf_callee_9>
  13f44c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f450 <pf_call_10>:
  13f450:	0f 18 15 39 a2 ee ff 	prefetcht1 -0x115dc7(%rip)        # 29690 <pf_target_10_0>

000000000013f457 <pf_jump_10>:
  13f457:	e9 74 ab ee ff       	jmp    29fd0 <pf_callee_10>
  13f45c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f460 <pf_call_11>:
  13f460:	0f 18 15 e9 73 f3 ff 	prefetcht1 -0xc8c17(%rip)        # 76850 <pf_target_11_0>
  13f467:	0f 18 15 d2 81 f3 ff 	prefetcht1 -0xc7e2e(%rip)        # 77640 <pf_target_11_1>

000000000013f46e <pf_jump_11>:
  13f46e:	e9 cd 9f ee ff       	jmp    29440 <pf_callee_11>
  13f473:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f47a:	00 00 00 
  13f47d:	0f 1f 00             	nopl   (%rax)

000000000013f480 <pf_call_12>:
  13f480:	0f 18 15 39 a3 ee ff 	prefetcht1 -0x115cc7(%rip)        # 297c0 <pf_target_12_0>

000000000013f487 <pf_jump_12>:
  13f487:	e9 e4 a7 ee ff       	jmp    29c70 <pf_callee_12>
  13f48c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f490 <pf_call_13>:
  13f490:	0f 18 15 49 6d f1 ff 	prefetcht1 -0xe92b7(%rip)        # 561e0 <pf_target_13_0>
  13f497:	0f 18 15 65 6d f1 ff 	prefetcht1 -0xe929b(%rip)        # 56203 <pf_target_13_1>

000000000013f49e <pf_jump_13>:
  13f49e:	e9 cd 9c ee ff       	jmp    29170 <pf_callee_13>
  13f4a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f4aa:	00 00 00 
  13f4ad:	0f 1f 00             	nopl   (%rax)

000000000013f4b0 <pf_call_14>:
  13f4b0:	0f 18 15 5e cb f1 ff 	prefetcht1 -0xe34a2(%rip)        # 5c015 <pf_target_14_0>

000000000013f4b7 <pf_jump_14>:
  13f4b7:	e9 64 35 f1 ff       	jmp    52a20 <pf_callee_14>
  13f4bc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f4c0 <pf_call_15>:
  13f4c0:	0f 18 15 bc 6d f1 ff 	prefetcht1 -0xe9244(%rip)        # 56283 <pf_target_15_0>

000000000013f4c7 <pf_jump_15>:
  13f4c7:	e9 d4 71 f1 ff       	jmp    566a0 <pf_callee_15>
  13f4cc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f4d0 <pf_call_16>:
  13f4d0:	0f 18 15 a9 86 f1 ff 	prefetcht1 -0xe7957(%rip)        # 57b80 <pf_target_16_0>

000000000013f4d7 <pf_jump_16>:
  13f4d7:	e9 04 9d ee ff       	jmp    291e0 <pf_callee_16>
  13f4dc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f4e0 <pf_call_17>:
  13f4e0:	0f 18 15 09 ac ee ff 	prefetcht1 -0x1153f7(%rip)        # 2a0f0 <pf_target_17_0>

000000000013f4e7 <pf_jump_17>:
  13f4e7:	e9 f4 9c ee ff       	jmp    291e0 <pf_callee_16>
  13f4ec:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f4f0 <pf_call_18>:
  13f4f0:	0f 18 15 f9 7b f1 ff 	prefetcht1 -0xe8407(%rip)        # 570f0 <pf_target_18_0>
  13f4f7:	0f 18 15 92 a2 ee ff 	prefetcht1 -0x115d6e(%rip)        # 29790 <pf_target_18_1>
  13f4fe:	0f 18 15 00 7c f1 ff 	prefetcht1 -0xe8400(%rip)        # 57105 <pf_target_18_2>
  13f505:	0f 18 15 14 35 f1 ff 	prefetcht1 -0xecaec(%rip)        # 52a20 <pf_callee_14>
  13f50c:	0f 18 15 30 35 f1 ff 	prefetcht1 -0xecad0(%rip)        # 52a43 <pf_target_18_4>

000000000013f513 <pf_jump_18>:
  13f513:	e9 08 81 f1 ff       	jmp    57620 <pf_callee_18>
  13f518:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  13f51f:	00 

000000000013f520 <pf_call_19>:
  13f520:	0f 18 15 89 ad ee ff 	prefetcht1 -0x115277(%rip)        # 2a2b0 <pf_target_19_0>

000000000013f527 <pf_jump_19>:
  13f527:	e9 f4 34 f1 ff       	jmp    52a20 <pf_callee_14>
  13f52c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f530 <pf_call_20>:
  13f530:	0f 18 15 30 a0 f4 ff 	prefetcht1 -0xb5fd0(%rip)        # 89567 <pf_target_20_0>
  13f537:	0f 18 15 47 38 f4 ff 	prefetcht1 -0xbc7b9(%rip)        # 82d85 <pf_target_20_1>
  13f53e:	0f 18 15 1b 76 f3 ff 	prefetcht1 -0xc89e5(%rip)        # 76b60 <pf_target_20_2>
  13f545:	0f 18 15 6a 34 f4 ff 	prefetcht1 -0xbcb96(%rip)        # 829b6 <pf_target_20_3>
  13f54c:	0f 18 15 ed 80 f3 ff 	prefetcht1 -0xc7f13(%rip)        # 77640 <pf_target_11_1>

000000000013f553 <pf_jump_20>:
  13f553:	e9 88 9c ee ff       	jmp    291e0 <pf_callee_16>
  13f558:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  13f55f:	00 

000000000013f560 <pf_call_21>:
  13f560:	0f 18 15 19 43 f2 ff 	prefetcht1 -0xdbce7(%rip)        # 63880 <pf_target_21_0>
  13f567:	0f 18 15 82 de f8 ff 	prefetcht1 -0x7217e(%rip)        # cd3f0 <pf_target_21_1>
  13f56e:	0f 18 15 eb 42 f2 ff 	prefetcht1 -0xdbd15(%rip)        # 63860 <pf_target_21_2>

000000000013f575 <pf_jump_21>:
  13f575:	e9 b6 7d f2 ff       	jmp    67330 <pf_callee_21>
  13f57a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000013f580 <pf_call_22>:
  13f580:	0f 18 15 f9 a2 ee ff 	prefetcht1 -0x115d07(%rip)        # 29880 <pf_callee_23>

000000000013f587 <pf_jump_22>:
  13f587:	e9 84 85 f3 ff       	jmp    77b10 <pf_callee_22>
  13f58c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f590 <pf_call_23>:
  13f590:	0f 18 15 39 ab ee ff 	prefetcht1 -0x1154c7(%rip)        # 2a0d0 <pf_callee_32>
  13f597:	0f 18 15 92 a7 f4 ff 	prefetcht1 -0xb586e(%rip)        # 89d30 <pf_callee_24>
  13f59e:	0f 18 15 3a 18 f5 ff 	prefetcht1 -0xae7c6(%rip)        # 90ddf <pf_target_23_2>

000000000013f5a5 <pf_jump_23>:
  13f5a5:	e9 d6 a2 ee ff       	jmp    29880 <pf_callee_23>
  13f5aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000013f5b0 <pf_call_24>:
  13f5b0:	0f 18 15 29 ae ee ff 	prefetcht1 -0x1151d7(%rip)        # 2a3e0 <pf_target_24_0>
  13f5b7:	0f 18 15 22 c3 f1 ff 	prefetcht1 -0xe3cde(%rip)        # 5b8e0 <pf_target_24_1>

000000000013f5be <pf_jump_24>:
  13f5be:	e9 6d a7 f4 ff       	jmp    89d30 <pf_callee_24>
  13f5c3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f5ca:	00 00 00 
  13f5cd:	0f 1f 00             	nopl   (%rax)

000000000013f5d0 <pf_call_25>:
  13f5d0:	0f 18 15 e9 fa f3 ff 	prefetcht1 -0xc0517(%rip)        # 7f0c0 <pf_callee_30>
  13f5d7:	0f 18 15 12 7a f3 ff 	prefetcht1 -0xc85ee(%rip)        # 76ff0 <pf_target_25_1>
  13f5de:	0f 18 15 bb 5c f4 ff 	prefetcht1 -0xba345(%rip)        # 852a0 <pf_target_25_2>
  13f5e5:	0f 18 15 15 7a f3 ff 	prefetcht1 -0xc85eb(%rip)        # 77001 <pf_target_25_3>
  13f5ec:	0f 18 15 cf 5c f4 ff 	prefetcht1 -0xba331(%rip)        # 852c2 <pf_target_25_4>

000000000013f5f3 <pf_jump_25>:
  13f5f3:	e9 58 ae ee ff       	jmp    2a450 <pf_callee_25>
  13f5f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  13f5ff:	00 

000000000013f600 <pf_call_26>:
  13f600:	41 53                	push   %r11
  13f602:	4d 89 e3             	mov    %r12,%r11
  13f605:	4d 8b 9b 18 00 00 00 	mov    0x18(%r11),%r11
  13f60c:	4d 8b 9b 00 00 00 00 	mov    0x0(%r11),%r11
  13f613:	4d 8b 9b 10 00 00 00 	mov    0x10(%r11),%r11

000000000013f61a <pf_runtime_hint_26_0>:
  13f61a:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  13f621:	00 

000000000013f622 <pf_runtime_hint_26_1>:
  13f622:	41 0f 18 93 40 00 00 	prefetcht1 0x40(%r11)
  13f629:	00 

000000000013f62a <pf_runtime_hint_26_2>:
  13f62a:	41 0f 18 93 80 00 00 	prefetcht1 0x80(%r11)
  13f631:	00 

000000000013f632 <pf_runtime_hint_26_3>:
  13f632:	41 0f 18 93 c0 00 00 	prefetcht1 0xc0(%r11)
  13f639:	00 
  13f63a:	41 5b                	pop    %r11

000000000013f63c <pf_jump_26>:
  13f63c:	e9 0f b8 f3 ff       	jmp    7ae50 <pf_callee_26>
  13f641:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f648:	00 00 00 
  13f64b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000013f650 <pf_call_27>:
  13f650:	41 53                	push   %r11
  13f652:	4d 89 e3             	mov    %r12,%r11
  13f655:	4d 8b 9b 18 00 00 00 	mov    0x18(%r11),%r11
  13f65c:	4d 8b 9b 00 00 00 00 	mov    0x0(%r11),%r11
  13f663:	4d 8b 9b 18 00 00 00 	mov    0x18(%r11),%r11

000000000013f66a <pf_runtime_hint_27_0>:
  13f66a:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  13f671:	00 

000000000013f672 <pf_runtime_hint_27_1>:
  13f672:	41 0f 18 93 40 00 00 	prefetcht1 0x40(%r11)
  13f679:	00 

000000000013f67a <pf_runtime_hint_27_2>:
  13f67a:	41 0f 18 93 80 00 00 	prefetcht1 0x80(%r11)
  13f681:	00 

000000000013f682 <pf_runtime_hint_27_3>:
  13f682:	41 0f 18 93 c0 00 00 	prefetcht1 0xc0(%r11)
  13f689:	00 
  13f68a:	41 5b                	pop    %r11

000000000013f68c <pf_jump_27>:
  13f68c:	e9 2f c9 f3 ff       	jmp    7bfc0 <pf_callee_27>
  13f691:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f698:	00 00 00 
  13f69b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000013f6a0 <pf_call_28>:
  13f6a0:	41 53                	push   %r11
  13f6a2:	4d 89 e3             	mov    %r12,%r11
  13f6a5:	4d 8b 9b 18 00 00 00 	mov    0x18(%r11),%r11
  13f6ac:	4d 8b 9b 00 00 00 00 	mov    0x0(%r11),%r11
  13f6b3:	4d 8b 9b 20 00 00 00 	mov    0x20(%r11),%r11

000000000013f6ba <pf_runtime_hint_28_0>:
  13f6ba:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  13f6c1:	00 

000000000013f6c2 <pf_runtime_hint_28_1>:
  13f6c2:	41 0f 18 93 40 00 00 	prefetcht1 0x40(%r11)
  13f6c9:	00 

000000000013f6ca <pf_runtime_hint_28_2>:
  13f6ca:	41 0f 18 93 80 00 00 	prefetcht1 0x80(%r11)
  13f6d1:	00 

000000000013f6d2 <pf_runtime_hint_28_3>:
  13f6d2:	41 0f 18 93 c0 00 00 	prefetcht1 0xc0(%r11)
  13f6d9:	00 
  13f6da:	41 5b                	pop    %r11

000000000013f6dc <pf_jump_28>:
  13f6dc:	e9 2f db f3 ff       	jmp    7d210 <pf_callee_28>
  13f6e1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f6e8:	00 00 00 
  13f6eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000013f6f0 <pf_call_29>:
  13f6f0:	41 53                	push   %r11
  13f6f2:	4d 89 eb             	mov    %r13,%r11
  13f6f5:	4d 8b 9b 18 00 00 00 	mov    0x18(%r11),%r11
  13f6fc:	4d 8b 9b 00 00 00 00 	mov    0x0(%r11),%r11
  13f703:	4d 8b 9b 28 00 00 00 	mov    0x28(%r11),%r11

000000000013f70a <pf_runtime_hint_29_0>:
  13f70a:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  13f711:	00 

000000000013f712 <pf_runtime_hint_29_1>:
  13f712:	41 0f 18 93 40 00 00 	prefetcht1 0x40(%r11)
  13f719:	00 

000000000013f71a <pf_runtime_hint_29_2>:
  13f71a:	41 0f 18 93 80 00 00 	prefetcht1 0x80(%r11)
  13f721:	00 

000000000013f722 <pf_runtime_hint_29_3>:
  13f722:	41 0f 18 93 c0 00 00 	prefetcht1 0xc0(%r11)
  13f729:	00 
  13f72a:	41 5b                	pop    %r11

000000000013f72c <pf_jump_29>:
  13f72c:	e9 df ea f3 ff       	jmp    7e210 <pf_callee_29>
  13f731:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f738:	00 00 00 
  13f73b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000013f740 <pf_call_30>:
  13f740:	41 53                	push   %r11
  13f742:	4d 89 eb             	mov    %r13,%r11
  13f745:	4d 8b 9b 18 00 00 00 	mov    0x18(%r11),%r11
  13f74c:	4d 8b 9b 00 00 00 00 	mov    0x0(%r11),%r11
  13f753:	4d 8b 9b 30 00 00 00 	mov    0x30(%r11),%r11

000000000013f75a <pf_runtime_hint_30_0>:
  13f75a:	41 0f 18 93 00 00 00 	prefetcht1 0x0(%r11)
  13f761:	00 

000000000013f762 <pf_runtime_hint_30_1>:
  13f762:	41 0f 18 93 40 00 00 	prefetcht1 0x40(%r11)
  13f769:	00 

000000000013f76a <pf_runtime_hint_30_2>:
  13f76a:	41 0f 18 93 80 00 00 	prefetcht1 0x80(%r11)
  13f771:	00 

000000000013f772 <pf_runtime_hint_30_3>:
  13f772:	41 0f 18 93 c0 00 00 	prefetcht1 0xc0(%r11)
  13f779:	00 
  13f77a:	41 5b                	pop    %r11

000000000013f77c <pf_jump_30>:
  13f77c:	e9 3f f9 f3 ff       	jmp    7f0c0 <pf_callee_30>
  13f781:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f788:	00 00 00 
  13f78b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000013f790 <pf_call_31>:
  13f790:	0f 18 15 59 9d f4 ff 	prefetcht1 -0xb62a7(%rip)        # 894f0 <pf_target_31_0>

000000000013f797 <pf_jump_31>:
  13f797:	e9 44 9a ee ff       	jmp    291e0 <pf_callee_16>
  13f79c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f7a0 <pf_call_32>:
  13f7a0:	0f 18 15 5b f2 f4 ff 	prefetcht1 -0xb0da5(%rip)        # 8ea02 <pf_target_32_0>
  13f7a7:	0f 18 15 02 f2 f4 ff 	prefetcht1 -0xb0dfe(%rip)        # 8e9b0 <pf_target_32_1>
  13f7ae:	0f 18 15 4c 78 f3 ff 	prefetcht1 -0xc87b4(%rip)        # 77001 <pf_target_25_3>
  13f7b5:	0f 18 15 47 18 f5 ff 	prefetcht1 -0xae7b9(%rip)        # 91003 <pf_target_32_3>

000000000013f7bc <pf_jump_32>:
  13f7bc:	e9 0f a9 ee ff       	jmp    2a0d0 <pf_callee_32>
  13f7c1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f7c8:	00 00 00 
  13f7cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000013f7d0 <pf_call_33>:
  13f7d0:	0f 18 15 08 81 ef ff 	prefetcht1 -0x107ef8(%rip)        # 378df <pf_target_33_0>
  13f7d7:	0f 18 15 62 9c ee ff 	prefetcht1 -0x11639e(%rip)        # 29440 <pf_callee_11>
  13f7de:	0f 18 15 4b 42 f0 ff 	prefetcht1 -0xfbdb5(%rip)        # 43a30 <pf_callee_7>

000000000013f7e5 <pf_jump_33>:
  13f7e5:	e9 86 ef f5 ff       	jmp    9e770 <pf_callee_33>
  13f7ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000013f7f0 <pf_call_34>:
  13f7f0:	0f 18 15 b9 7a f2 ff 	prefetcht1 -0xd8547(%rip)        # 672b0 <pf_target_34_0>

000000000013f7f7 <pf_jump_34>:
  13f7f7:	e9 c4 a8 ee ff       	jmp    2a0c0 <pf_callee_34>
