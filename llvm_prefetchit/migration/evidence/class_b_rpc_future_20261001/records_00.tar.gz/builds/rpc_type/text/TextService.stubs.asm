
/storage/prefetchit/class_b_rpc_future_20261001/builds/rpc_type/text/call-stub-vi928l74/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000110340 <pf_call_0>:
  110340:	0f 18 15 e9 88 f3 ff 	prefetcht1 -0xc7717(%rip)        # 48c30 <pf_target_0_0>
  110347:	0f 18 15 62 31 f3 ff 	prefetcht1 -0xcce9e(%rip)        # 434b0 <pf_target_0_1>
  11034e:	0f 18 15 af 31 f3 ff 	prefetcht1 -0xcce51(%rip)        # 43504 <pf_target_0_2>
  110355:	0f 18 15 c4 3b f3 ff 	prefetcht1 -0xcc43c(%rip)        # 43f20 <pf_target_0_3>
  11035c:	0f 18 15 a1 3c f3 ff 	prefetcht1 -0xcc35f(%rip)        # 44004 <pf_target_0_4>
  110363:	0f 18 15 d8 88 f3 ff 	prefetcht1 -0xc7728(%rip)        # 48c42 <pf_target_0_5>
  11036a:	0f 18 15 11 89 f3 ff 	prefetcht1 -0xc76ef(%rip)        # 48c82 <pf_target_0_6>
  110371:	0f 18 15 4a 32 f3 ff 	prefetcht1 -0xccdb6(%rip)        # 435c2 <pf_target_0_7>

0000000000110378 <pf_jump_0>:
  110378:	e9 a3 5f f1 ff       	jmp    26320 <pf_callee_0>
  11037d:	0f 1f 00             	nopl   (%rax)

0000000000110380 <pf_call_1>:
  110380:	0f 18 15 19 06 f2 ff 	prefetcht1 -0xdf9e7(%rip)        # 309a0 <pf_target_1_0>

0000000000110387 <pf_jump_1>:
  110387:	e9 94 5f f1 ff       	jmp    26320 <pf_callee_0>
  11038c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110390 <pf_call_2>:
  110390:	0f 18 15 69 8c f5 ff 	prefetcht1 -0xa7397(%rip)        # 69000 <pf_target_2_0>
  110397:	0f 18 15 32 be f4 ff 	prefetcht1 -0xb41ce(%rip)        # 5c1d0 <pf_target_2_1>

000000000011039e <pf_jump_2>:
  11039e:	e9 2d 07 f2 ff       	jmp    30ad0 <pf_callee_2>
  1103a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1103aa:	00 00 00 
  1103ad:	0f 1f 00             	nopl   (%rax)

00000000001103b0 <pf_call_3>:
  1103b0:	0f 18 15 af 95 f3 ff 	prefetcht1 -0xc6a51(%rip)        # 49966 <pf_target_3_0>

00000000001103b7 <pf_jump_3>:
  1103b7:	e9 f4 94 f3 ff       	jmp    498b0 <pf_callee_3>
  1103bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001103c0 <pf_call_4>:
  1103c0:	0f 18 15 99 be f4 ff 	prefetcht1 -0xb4167(%rip)        # 5c260 <pf_target_4_0>

00000000001103c7 <pf_jump_4>:
  1103c7:	e9 44 5f f1 ff       	jmp    26310 <pf_callee_4>
  1103cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001103d0 <pf_call_5>:
  1103d0:	0f 18 15 29 32 f3 ff 	prefetcht1 -0xccdd7(%rip)        # 43600 <pf_target_5_0>

00000000001103d7 <pf_jump_5>:
  1103d7:	e9 e4 5d f1 ff       	jmp    261c0 <pf_callee_5>
  1103dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001103e0 <pf_call_6>:
  1103e0:	0f 18 15 49 62 f1 ff 	prefetcht1 -0xe9db7(%rip)        # 26630 <pf_target_6_0>

00000000001103e7 <pf_jump_6>:
  1103e7:	e9 f4 65 f1 ff       	jmp    269e0 <pf_callee_6>
  1103ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001103f0 <pf_call_7>:
  1103f0:	0f 18 15 19 37 f3 ff 	prefetcht1 -0xcc8e7(%rip)        # 43b10 <pf_target_7_0>

00000000001103f7 <pf_jump_7>:
  1103f7:	e9 f4 5c f1 ff       	jmp    260f0 <pf_callee_7>
  1103fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110400 <pf_call_8>:
  110400:	0f 18 15 79 95 f3 ff 	prefetcht1 -0xc6a87(%rip)        # 49980 <pf_callee_17>

0000000000110407 <pf_jump_8>:
  110407:	e9 44 ff f2 ff       	jmp    40350 <pf_callee_13>
  11040c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110410 <pf_call_9>:
  110410:	0f 18 15 79 37 f3 ff 	prefetcht1 -0xcc887(%rip)        # 43b90 <pf_target_9_0>

0000000000110417 <pf_jump_9>:
  110417:	e9 b4 3b f3 ff       	jmp    43fd0 <pf_callee_9>
  11041c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110420 <pf_call_10>:
  110420:	0f 18 15 89 50 f3 ff 	prefetcht1 -0xcaf77(%rip)        # 454b0 <pf_target_10_0>

0000000000110427 <pf_jump_10>:
  110427:	e9 14 5d f1 ff       	jmp    26140 <pf_callee_10>
  11042c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110430 <pf_call_11>:
  110430:	0f 18 15 b9 69 f1 ff 	prefetcht1 -0xe9647(%rip)        # 26df0 <pf_target_11_0>

0000000000110437 <pf_jump_11>:
  110437:	e9 04 5d f1 ff       	jmp    26140 <pf_callee_10>
  11043c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110440 <pf_call_12>:
  110440:	0f 18 15 09 ff f2 ff 	prefetcht1 -0xd00f7(%rip)        # 40350 <pf_callee_13>

0000000000110447 <pf_jump_12>:
  110447:	e9 04 4b f3 ff       	jmp    44f50 <pf_callee_12>
  11044c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110450 <pf_call_13>:
  110450:	0f 18 15 c9 45 f3 ff 	prefetcht1 -0xcba37(%rip)        # 44a20 <pf_target_13_0>

0000000000110457 <pf_jump_13>:
  110457:	e9 f4 fe f2 ff       	jmp    40350 <pf_callee_13>
  11045c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110460 <pf_call_14>:
  110460:	0f 18 15 e9 6a f1 ff 	prefetcht1 -0xe9517(%rip)        # 26f50 <pf_target_14_0>

0000000000110467 <pf_jump_14>:
  110467:	e9 e4 fe f2 ff       	jmp    40350 <pf_callee_13>
  11046c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110470 <pf_call_15>:
  110470:	0f 18 15 a9 6b f1 ff 	prefetcht1 -0xe9457(%rip)        # 27020 <pf_target_15_0>

0000000000110477 <pf_jump_15>:
  110477:	e9 e4 90 f3 ff       	jmp    49560 <pf_callee_15>
  11047c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110480 <pf_call_16>:
  110480:	0f 18 15 0e 18 f5 ff 	prefetcht1 -0xae7f2(%rip)        # 61c95 <pf_target_16_0>
  110487:	0f 18 15 69 35 f5 ff 	prefetcht1 -0xaca97(%rip)        # 639f7 <pf_target_16_1>
  11048e:	0f 18 15 2b cb f4 ff 	prefetcht1 -0xb34d5(%rip)        # 5cfc0 <pf_target_16_2>
  110495:	0f 18 15 44 c0 f4 ff 	prefetcht1 -0xb3fbc(%rip)        # 5c4e0 <pf_target_16_3>
  11049c:	0f 18 15 23 14 f5 ff 	prefetcht1 -0xaebdd(%rip)        # 618c6 <pf_target_16_4>

00000000001104a3 <pf_jump_16>:
  1104a3:	e9 98 5c f1 ff       	jmp    26140 <pf_callee_10>
  1104a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1104af:	00 

00000000001104b0 <pf_call_17>:
  1104b0:	0f 18 15 a6 1b f5 ff 	prefetcht1 -0xae45a(%rip)        # 6205d <pf_target_17_0>

00000000001104b7 <pf_jump_17>:
  1104b7:	e9 c4 94 f3 ff       	jmp    49980 <pf_callee_17>
  1104bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001104c0 <pf_call_18>:
  1104c0:	0f 18 15 a9 c8 f4 ff 	prefetcht1 -0xb3757(%rip)        # 5cd70 <pf_target_18_0>

00000000001104c7 <pf_jump_18>:
  1104c7:	e9 14 62 f1 ff       	jmp    266e0 <pf_callee_18>
  1104cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001104d0 <pf_call_19>:
  1104d0:	0f 18 15 e9 3c f5 ff 	prefetcht1 -0xac317(%rip)        # 641c0 <pf_callee_21>

00000000001104d7 <pf_jump_19>:
  1104d7:	e9 b4 cf f4 ff       	jmp    5d490 <pf_callee_19>
  1104dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001104e0 <pf_call_20>:
  1104e0:	0f 18 15 f9 61 f1 ff 	prefetcht1 -0xe9e07(%rip)        # 266e0 <pf_callee_18>
  1104e7:	0f 18 15 a2 6b f1 ff 	prefetcht1 -0xe945e(%rip)        # 27090 <pf_callee_22>
  1104ee:	0f 18 15 8b 12 f5 ff 	prefetcht1 -0xaed75(%rip)        # 61780 <pf_target_20_2>
  1104f5:	0f 18 15 d0 34 f5 ff 	prefetcht1 -0xacb30(%rip)        # 639cc <pf_target_20_3>
  1104fc:	0f 18 15 cd 68 f1 ff 	prefetcht1 -0xe9733(%rip)        # 26dd0 <pf_callee_25>
  110503:	0f 18 15 c5 8d f5 ff 	prefetcht1 -0xa723b(%rip)        # 692cf <pf_target_20_5>

000000000011050a <pf_jump_20>:
  11050a:	e9 81 cf f4 ff       	jmp    5d490 <pf_callee_19>
  11050f:	90                   	nop

0000000000110510 <pf_call_21>:
  110510:	0f 18 15 69 8d f3 ff 	prefetcht1 -0xc7297(%rip)        # 49280 <pf_target_21_0>
  110517:	0f 18 15 5b 91 f3 ff 	prefetcht1 -0xc6ea5(%rip)        # 49679 <pf_target_21_1>
  11051e:	0f 18 15 5c 91 f3 ff 	prefetcht1 -0xc6ea4(%rip)        # 49681 <pf_target_21_2>

0000000000110525 <pf_jump_21>:
  110525:	e9 96 3c f5 ff       	jmp    641c0 <pf_callee_21>
  11052a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000110530 <pf_call_22>:
  110530:	0f 18 15 79 18 f5 ff 	prefetcht1 -0xae787(%rip)        # 61db0 <pf_target_22_0>
  110537:	0f 18 15 52 fc f4 ff 	prefetcht1 -0xb03ae(%rip)        # 60190 <pf_callee_23>
  11053e:	0f 18 15 2b c4 f4 ff 	prefetcht1 -0xb3bd5(%rip)        # 5c970 <pf_target_22_2>
  110545:	0f 18 15 75 18 f5 ff 	prefetcht1 -0xae78b(%rip)        # 61dc1 <pf_target_22_3>

000000000011054c <pf_jump_22>:
  11054c:	e9 3f 6b f1 ff       	jmp    27090 <pf_callee_22>
  110551:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  110558:	00 00 00 
  11055b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000110560 <pf_call_23>:
  110560:	0f 18 15 c9 da f1 ff 	prefetcht1 -0xe2537(%rip)        # 2e030 <pf_target_23_0>
  110567:	0f 18 15 d3 da f1 ff 	prefetcht1 -0xe252d(%rip)        # 2e041 <pf_target_23_1>
  11056e:	0f 18 15 4b dd f1 ff 	prefetcht1 -0xe22b5(%rip)        # 2e2c0 <pf_target_23_2>
  110575:	0f 18 15 44 db f1 ff 	prefetcht1 -0xe24bc(%rip)        # 2e0c0 <pf_target_23_3>
  11057c:	0f 18 15 fd da f1 ff 	prefetcht1 -0xe2503(%rip)        # 2e080 <pf_target_23_4>
  110583:	0f 18 15 b6 db f1 ff 	prefetcht1 -0xe244a(%rip)        # 2e140 <pf_target_23_5>

000000000011058a <pf_jump_23>:
  11058a:	e9 01 fc f4 ff       	jmp    60190 <pf_callee_23>
  11058f:	90                   	nop

0000000000110590 <pf_call_24>:
  110590:	0f 18 15 e9 33 f5 ff 	prefetcht1 -0xacc17(%rip)        # 63980 <pf_target_24_0>

0000000000110597 <pf_jump_24>:
  110597:	e9 a4 5b f1 ff       	jmp    26140 <pf_callee_10>
  11059c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001105a0 <pf_call_25>:
  1105a0:	0f 18 15 49 4e f5 ff 	prefetcht1 -0xab1b7(%rip)        # 653f0 <pf_target_25_0>

00000000001105a7 <pf_jump_25>:
  1105a7:	e9 24 68 f1 ff       	jmp    26dd0 <pf_callee_25>
  1105ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001105b0 <pf_call_26>:
  1105b0:	0f 18 15 2a dd f1 ff 	prefetcht1 -0xe22d6(%rip)        # 2e2e1 <pf_target_26_0>
  1105b7:	0f 18 15 86 10 f2 ff 	prefetcht1 -0xdef7a(%rip)        # 31644 <pf_target_26_1>

00000000001105be <pf_jump_26>:
  1105be:	e9 3d 86 f6 ff       	jmp    78c00 <pf_callee_26>
