
/storage/prefetchit/class_b_rpc_future_20261001/builds/no_dso/unique/call-stub-vnptunl3/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000113340 <pf_call_0>:
  113340:	0f 18 15 b9 2e f3 ff 	prefetcht1 -0xcd147(%rip)        # 46200 <pf_target_0_0>
  113347:	0f 18 15 d2 85 f3 ff 	prefetcht1 -0xc7a2e(%rip)        # 4b920 <pf_target_0_1>
  11334e:	0f 18 15 4b 2e f3 ff 	prefetcht1 -0xcd1b5(%rip)        # 461a0 <pf_target_0_2>
  113355:	0f 18 15 b4 38 f3 ff 	prefetcht1 -0xcc74c(%rip)        # 46c10 <pf_target_0_3>
  11335c:	0f 18 15 e4 2e f3 ff 	prefetcht1 -0xcd11c(%rip)        # 46247 <pf_target_0_4>
  113363:	0f 18 15 16 86 f3 ff 	prefetcht1 -0xc79ea(%rip)        # 4b980 <pf_target_0_5>
  11336a:	0f 18 15 d0 85 f3 ff 	prefetcht1 -0xc7a30(%rip)        # 4b941 <pf_target_0_6>

0000000000113371 <pf_jump_0>:
  113371:	e9 da 3f f1 ff       	jmp    27350 <pf_callee_0>
  113376:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11337d:	00 00 00 

0000000000113380 <pf_call_1>:
  113380:	0f 18 15 b9 02 f2 ff 	prefetcht1 -0xdfd47(%rip)        # 33640 <pf_target_1_0>
  113387:	0f 18 15 b3 90 f3 ff 	prefetcht1 -0xc6f4d(%rip)        # 4c441 <pf_target_1_1>

000000000011338e <pf_jump_1>:
  11338e:	e9 bd 3f f1 ff       	jmp    27350 <pf_callee_0>
  113393:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11339a:	00 00 00 
  11339d:	0f 1f 00             	nopl   (%rax)

00000000001133a0 <pf_call_2>:
  1133a0:	0f 18 15 99 cf f7 ff 	prefetcht1 -0x83067(%rip)        # 90340 <pf_target_2_0>
  1133a7:	0f 18 15 92 8d f7 ff 	prefetcht1 -0x8726e(%rip)        # 8c140 <pf_target_2_1>
  1133ae:	0f 18 15 1b 97 f7 ff 	prefetcht1 -0x868e5(%rip)        # 8cad0 <pf_target_2_2>
  1133b5:	0f 18 15 54 c1 fb ff 	prefetcht1 -0x43eac(%rip)        # cf510 <pf_target_2_3>
  1133bc:	0f 18 15 3d 97 f7 ff 	prefetcht1 -0x868c3(%rip)        # 8cb00 <pf_target_2_4>
  1133c3:	0f 18 15 d6 3d f8 ff 	prefetcht1 -0x7c22a(%rip)        # 971a0 <pf_callee_7>
  1133ca:	0f 18 15 2f 3e f8 ff 	prefetcht1 -0x7c1d1(%rip)        # 97200 <pf_target_2_6>
  1133d1:	0f 18 15 08 2e f7 ff 	prefetcht1 -0x8d1f8(%rip)        # 861e0 <pf_target_2_7>

00000000001133d8 <pf_jump_2>:
  1133d8:	e9 03 6a f9 ff       	jmp    a9de0 <pf_callee_2>
  1133dd:	0f 1f 00             	nopl   (%rax)

00000000001133e0 <pf_call_3>:
  1133e0:	0f 18 15 5d 17 fb ff 	prefetcht1 -0x4e8a3(%rip)        # c4b44 <pf_target_3_0>
  1133e7:	0f 18 15 62 1c fb ff 	prefetcht1 -0x4e39e(%rip)        # c5050 <pf_target_3_1>
  1133ee:	0f 18 15 9b 68 f9 ff 	prefetcht1 -0x69765(%rip)        # a9c90 <pf_target_3_2>
  1133f5:	0f 18 15 34 17 fb ff 	prefetcht1 -0x4e8cc(%rip)        # c4b30 <pf_target_3_3>
  1133fc:	0f 18 15 2d 8d f7 ff 	prefetcht1 -0x872d3(%rip)        # 8c130 <pf_target_3_4>

0000000000113403 <pf_jump_3>:
  113403:	e9 f8 f4 f1 ff       	jmp    32900 <pf_callee_3>
  113408:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  11340f:	00 

0000000000113410 <pf_call_4>:
  113410:	0f 18 15 a9 ba f4 ff 	prefetcht1 -0xb4557(%rip)        # 5eec0 <pf_target_4_0>
  113417:	0f 18 15 58 0a f2 ff 	prefetcht1 -0xdf5a8(%rip)        # 33e76 <pf_target_4_1>
  11341e:	0f 18 15 0b 9f f5 ff 	prefetcht1 -0xa60f5(%rip)        # 6d330 <pf_target_4_2>

0000000000113425 <pf_jump_4>:
  113425:	e9 46 03 f2 ff       	jmp    33770 <pf_callee_4>
  11342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000113430 <pf_call_5>:
  113430:	0f 18 15 19 bb f4 ff 	prefetcht1 -0xb44e7(%rip)        # 5ef50 <pf_target_5_0>

0000000000113437 <pf_jump_5>:
  113437:	e9 94 0e f2 ff       	jmp    342d0 <pf_callee_5>
  11343c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113440 <pf_call_6>:
  113440:	0f 18 15 ba 17 f5 ff 	prefetcht1 -0xae846(%rip)        # 64c01 <pf_target_6_0>

0000000000113447 <pf_jump_6>:
  113447:	e9 24 92 f3 ff       	jmp    4c670 <pf_callee_15>
  11344c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113450 <pf_call_7>:
  113450:	0f 18 15 a9 d4 f3 ff 	prefetcht1 -0xc2b57(%rip)        # 50900 <pf_target_7_0>

0000000000113457 <pf_jump_7>:
  113457:	e9 44 3d f8 ff       	jmp    971a0 <pf_callee_7>
  11345c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113460 <pf_call_8>:
  113460:	0f 18 15 99 33 f3 ff 	prefetcht1 -0xccc67(%rip)        # 46800 <pf_target_8_0>

0000000000113467 <pf_jump_8>:
  113467:	e9 84 3c f1 ff       	jmp    270f0 <pf_callee_8>
  11346c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113470 <pf_call_9>:
  113470:	0f 18 15 09 34 f3 ff 	prefetcht1 -0xccbf7(%rip)        # 46880 <pf_target_9_0>

0000000000113477 <pf_jump_9>:
  113477:	e9 44 38 f3 ff       	jmp    46cc0 <pf_callee_9>
  11347c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113480 <pf_call_10>:
  113480:	0f 18 15 19 4d f3 ff 	prefetcht1 -0xcb2e7(%rip)        # 481a0 <pf_target_10_0>

0000000000113487 <pf_jump_10>:
  113487:	e9 b4 3c f1 ff       	jmp    27140 <pf_callee_10>
  11348c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113490 <pf_call_11>:
  113490:	0f 18 15 c9 49 f1 ff 	prefetcht1 -0xeb637(%rip)        # 27e60 <pf_target_11_0>

0000000000113497 <pf_jump_11>:
  113497:	e9 a4 3c f1 ff       	jmp    27140 <pf_callee_10>
  11349c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001134a0 <pf_call_12>:
  1134a0:	0f 18 15 99 fb f2 ff 	prefetcht1 -0xd0467(%rip)        # 43040 <pf_target_12_0>
  1134a7:	0f 18 15 62 42 f3 ff 	prefetcht1 -0xcbd9e(%rip)        # 47710 <pf_target_12_1>

00000000001134ae <pf_jump_12>:
  1134ae:	e9 8d 47 f3 ff       	jmp    47c40 <pf_callee_12>
  1134b3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1134ba:	00 00 00 
  1134bd:	0f 1f 00             	nopl   (%rax)

00000000001134c0 <pf_call_13>:
  1134c0:	0f 18 15 f9 4a f1 ff 	prefetcht1 -0xeb507(%rip)        # 27fc0 <pf_target_13_0>

00000000001134c7 <pf_jump_13>:
  1134c7:	e9 14 3e f1 ff       	jmp    272e0 <pf_callee_13>
  1134cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001134d0 <pf_call_14>:
  1134d0:	0f 18 15 29 30 f5 ff 	prefetcht1 -0xacfd7(%rip)        # 66500 <pf_target_14_0>

00000000001134d7 <pf_jump_14>:
  1134d7:	e9 64 3c f1 ff       	jmp    27140 <pf_callee_10>
  1134dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001134e0 <pf_call_15>:
  1134e0:	0f 18 15 90 30 f5 ff 	prefetcht1 -0xacf70(%rip)        # 66577 <pf_target_15_0>
  1134e7:	0f 18 15 77 13 f5 ff 	prefetcht1 -0xaec89(%rip)        # 64865 <pf_target_15_1>
  1134ee:	0f 18 15 bb c7 f4 ff 	prefetcht1 -0xb3845(%rip)        # 5fcb0 <pf_target_15_2>
  1134f5:	0f 18 15 9a 0f f5 ff 	prefetcht1 -0xaf066(%rip)        # 64496 <pf_target_15_3>

00000000001134fc <pf_jump_15>:
  1134fc:	e9 6f 91 f3 ff       	jmp    4c670 <pf_callee_15>
  113501:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  113508:	00 00 00 
  11350b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000113510 <pf_call_16>:
  113510:	0f 18 15 99 99 f3 ff 	prefetcht1 -0xc6667(%rip)        # 4ceb0 <pf_target_16_0>
  113517:	0f 18 15 e2 6e f9 ff 	prefetcht1 -0x6911e(%rip)        # aa400 <pf_target_16_1>
  11351e:	0f 18 15 9b 99 f3 ff 	prefetcht1 -0xc6665(%rip)        # 4cec0 <pf_target_16_2>

0000000000113525 <pf_jump_16>:
  113525:	e9 56 d4 f3 ff       	jmp    50980 <pf_callee_16>
  11352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000113530 <pf_call_17>:
  113530:	0f 18 15 f9 41 f1 ff 	prefetcht1 -0xebe07(%rip)        # 27730 <pf_callee_18>
  113537:	0f 18 15 3f 0e f5 ff 	prefetcht1 -0xaf1c1(%rip)        # 6437d <pf_target_17_1>
  11353e:	0f 18 15 bb 4b f1 ff 	prefetcht1 -0xeb445(%rip)        # 28100 <pf_callee_20>
  113545:	0f 18 15 34 0e f5 ff 	prefetcht1 -0xaf1cc(%rip)        # 64380 <pf_target_17_3>
  11354c:	0f 18 15 f9 2f f5 ff 	prefetcht1 -0xad007(%rip)        # 6654c <pf_target_17_4>
  113553:	0f 18 15 e6 48 f1 ff 	prefetcht1 -0xeb71a(%rip)        # 27e40 <pf_callee_23>
  11355a:	0f 18 15 ae a0 f5 ff 	prefetcht1 -0xa5f52(%rip)        # 6d60f <pf_target_17_6>

0000000000113561 <pf_jump_17>:
  113561:	e9 1a cc f4 ff       	jmp    60180 <pf_callee_17>
  113566:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11356d:	00 00 00 

0000000000113570 <pf_call_18>:
  113570:	0f 18 15 c9 37 f5 ff 	prefetcht1 -0xac837(%rip)        # 66d40 <pf_target_18_0>

0000000000113577 <pf_jump_18>:
  113577:	e9 b4 41 f1 ff       	jmp    27730 <pf_callee_18>
  11357c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113580 <pf_call_19>:
  113580:	0f 18 15 65 91 f3 ff 	prefetcht1 -0xc6e9b(%rip)        # 4c6ec <pf_target_19_0>

0000000000113587 <pf_jump_19>:
  113587:	e9 e4 90 f3 ff       	jmp    4c670 <pf_callee_15>
  11358c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113590 <pf_call_20>:
  113590:	0f 18 15 e9 13 f5 ff 	prefetcht1 -0xaec17(%rip)        # 64980 <pf_target_20_0>
  113597:	0f 18 15 c2 c0 f4 ff 	prefetcht1 -0xb3f3e(%rip)        # 5f660 <pf_target_20_1>
  11359e:	0f 18 15 cb f8 f4 ff 	prefetcht1 -0xb0735(%rip)        # 62e70 <pf_callee_21>
  1135a5:	0f 18 15 17 f9 f4 ff 	prefetcht1 -0xb06e9(%rip)        # 62ec3 <pf_target_20_3>

00000000001135ac <pf_jump_20>:
  1135ac:	e9 4f 4b f1 ff       	jmp    28100 <pf_callee_20>
  1135b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1135b8:	00 00 00 
  1135bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000001135c0 <pf_call_21>:
  1135c0:	0f 18 15 99 c4 f4 ff 	prefetcht1 -0xb3b67(%rip)        # 5fa60 <pf_target_21_0>

00000000001135c7 <pf_jump_21>:
  1135c7:	e9 a4 f8 f4 ff       	jmp    62e70 <pf_callee_21>
  1135cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001135d0 <pf_call_22>:
  1135d0:	0f 18 15 b9 4a f1 ff 	prefetcht1 -0xeb547(%rip)        # 28090 <pf_target_22_0>
  1135d7:	0f 18 15 f4 8b f3 ff 	prefetcht1 -0xc740c(%rip)        # 4c1d2 <pf_target_22_1>
  1135de:	0f 18 15 8b 89 f3 ff 	prefetcht1 -0xc7675(%rip)        # 4bf70 <pf_target_22_2>

00000000001135e5 <pf_jump_22>:
  1135e5:	e9 e6 3b f1 ff       	jmp    271d0 <pf_callee_22>
  1135ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000001135f0 <pf_call_23>:
  1135f0:	0f 18 15 8b 75 f5 ff 	prefetcht1 -0xa8a75(%rip)        # 6ab82 <pf_target_23_0>
  1135f7:	0f 18 15 32 75 f5 ff 	prefetcht1 -0xa8ace(%rip)        # 6ab30 <pf_target_23_1>
  1135fe:	0f 18 15 5b c0 f4 ff 	prefetcht1 -0xb3fa5(%rip)        # 5f660 <pf_target_20_1>

0000000000113605 <pf_jump_23>:
  113605:	e9 36 48 f1 ff       	jmp    27e40 <pf_callee_23>
  11360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000113610 <pf_call_24>:
  113610:	0f 18 15 07 c6 f1 ff 	prefetcht1 -0xe39f9(%rip)        # 2fc1e <pf_target_24_0>

0000000000113617 <pf_jump_24>:
  113617:	e9 64 81 f6 ff       	jmp    7b780 <pf_callee_24>
  11361c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113620 <pf_call_25>:
  113620:	0f 18 15 da 2f f7 ff 	prefetcht1 -0x8d026(%rip)        # 86601 <pf_target_25_0>

0000000000113627 <pf_jump_25>:
  113627:	e9 04 48 f1 ff       	jmp    27e30 <pf_callee_25>
