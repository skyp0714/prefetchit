
/storage/prefetchit/class_b_rpc_future_20261001/builds/no_dso/storage/call-stub-50dwp47w/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000010b340 <pf_call_0>:
  10b340:	0f 18 15 bc 06 f4 ff 	prefetcht1 -0xbf944(%rip)        # 4ba03 <pf_target_0_0>
  10b347:	0f 18 15 f5 06 f4 ff 	prefetcht1 -0xbf90b(%rip)        # 4ba43 <pf_target_0_1>
  10b34e:	0f 18 15 5b 10 f4 ff 	prefetcht1 -0xbefa5(%rip)        # 4c3b0 <pf_target_0_2>
  10b355:	0f 18 15 c4 5c f4 ff 	prefetcht1 -0xba33c(%rip)        # 51020 <pf_target_0_3>
  10b35c:	0f 18 15 dd 05 f4 ff 	prefetcht1 -0xbfa23(%rip)        # 4b940 <pf_target_0_4>
  10b363:	0f 18 15 16 5d f4 ff 	prefetcht1 -0xba2ea(%rip)        # 51080 <pf_target_0_5>

000000000010b36a <pf_jump_0>:
  10b36a:	e9 d1 c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b36f:	90                   	nop

000000000010b370 <pf_call_1>:
  10b370:	0f 18 15 99 e2 f2 ff 	prefetcht1 -0xd1d67(%rip)        # 39610 <pf_target_1_0>

000000000010b377 <pf_jump_1>:
  10b377:	e9 c4 c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b37c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b380 <pf_call_2>:
  10b380:	0f 18 15 69 c2 f1 ff 	prefetcht1 -0xe3d97(%rip)        # 275f0 <pf_target_2_0>

000000000010b387 <pf_jump_2>:
  10b387:	e9 14 69 f4 ff       	jmp    51ca0 <pf_callee_2>
  10b38c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b390 <pf_call_3>:
  10b390:	0f 18 15 49 c4 f1 ff 	prefetcht1 -0xe3bb7(%rip)        # 277e0 <pf_target_3_0>
  10b397:	0f 18 15 25 0c f4 ff 	prefetcht1 -0xbf3db(%rip)        # 4bfc3 <pf_target_3_1>

000000000010b39e <pf_jump_3>:
  10b39e:	e9 9d bd f1 ff       	jmp    27140 <pf_callee_3>
  10b3a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b3aa:	00 00 00 
  10b3ad:	0f 1f 00             	nopl   (%rax)

000000000010b3b0 <pf_call_4>:
  10b3b0:	0f 18 15 39 c1 f1 ff 	prefetcht1 -0xe3ec7(%rip)        # 274f0 <pf_target_4_0>
  10b3b7:	0f 18 15 cc d4 f3 ff 	prefetcht1 -0xc2b34(%rip)        # 4888a <pf_target_4_1>

000000000010b3be <pf_jump_4>:
  10b3be:	e9 1d d4 f3 ff       	jmp    487e0 <pf_callee_10>
  10b3c3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b3ca:	00 00 00 
  10b3cd:	0f 1f 00             	nopl   (%rax)

000000000010b3d0 <pf_call_5>:
  10b3d0:	0f 18 15 49 0c f4 ff 	prefetcht1 -0xbf3b7(%rip)        # 4c020 <pf_target_5_0>
  10b3d7:	0f 18 15 65 0c f4 ff 	prefetcht1 -0xbf39b(%rip)        # 4c043 <pf_target_5_1>

000000000010b3de <pf_jump_5>:
  10b3de:	e9 7d 10 f4 ff       	jmp    4c460 <pf_callee_5>
  10b3e3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b3ea:	00 00 00 
  10b3ed:	0f 1f 00             	nopl   (%rax)

000000000010b3f0 <pf_call_6>:
  10b3f0:	0f 18 15 19 25 f4 ff 	prefetcht1 -0xbdae7(%rip)        # 4d910 <pf_target_6_0>

000000000010b3f7 <pf_jump_6>:
  10b3f7:	e9 b4 bd f1 ff       	jmp    271b0 <pf_callee_13>
  10b3fc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b400 <pf_call_7>:
  10b400:	0f 18 15 99 0b f4 ff 	prefetcht1 -0xbf467(%rip)        # 4bfa0 <pf_target_7_0>

000000000010b407 <pf_jump_7>:
  10b407:	e9 34 bd f1 ff       	jmp    27140 <pf_callee_3>
  10b40c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b410 <pf_call_8>:
  10b410:	0f 18 15 89 cc f1 ff 	prefetcht1 -0xe3377(%rip)        # 280a0 <pf_target_8_0>

000000000010b417 <pf_jump_8>:
  10b417:	e9 94 bd f1 ff       	jmp    271b0 <pf_callee_13>
  10b41c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b420 <pf_call_9>:
  10b420:	0f 18 15 89 1a f4 ff 	prefetcht1 -0xbe577(%rip)        # 4ceb0 <pf_target_9_0>
  10b427:	0f 18 15 b2 d3 f3 ff 	prefetcht1 -0xc2c4e(%rip)        # 487e0 <pf_callee_10>

000000000010b42e <pf_jump_9>:
  10b42e:	e9 ad 1f f4 ff       	jmp    4d3e0 <pf_callee_9>
  10b433:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b43a:	00 00 00 
  10b43d:	0f 1f 00             	nopl   (%rax)

000000000010b440 <pf_call_10>:
  10b440:	0f 18 15 e9 cd f1 ff 	prefetcht1 -0xe3217(%rip)        # 28230 <pf_target_10_0>

000000000010b447 <pf_jump_10>:
  10b447:	e9 94 d3 f3 ff       	jmp    487e0 <pf_callee_10>
  10b44c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b450 <pf_call_11>:
  10b450:	0f 18 15 39 5f f4 ff 	prefetcht1 -0xba0c7(%rip)        # 51390 <pf_target_11_0>

000000000010b457 <pf_jump_11>:
  10b457:	e9 d4 c7 f1 ff       	jmp    27c30 <pf_callee_11>
  10b45c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b460 <pf_call_12>:
  10b460:	0f 18 15 e9 ce f1 ff 	prefetcht1 -0xe3117(%rip)        # 28350 <pf_target_12_0>

000000000010b467 <pf_jump_12>:
  10b467:	e9 e4 64 f4 ff       	jmp    51950 <pf_callee_12>
  10b46c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b470 <pf_call_13>:
  10b470:	0f 18 15 c9 c4 f5 ff 	prefetcht1 -0xa3b37(%rip)        # 67940 <pf_target_13_0>
  10b477:	0f 18 15 a2 c4 f5 ff 	prefetcht1 -0xa3b5e(%rip)        # 67920 <pf_target_13_1>
  10b47e:	0f 18 15 bb b9 f5 ff 	prefetcht1 -0xa4645(%rip)        # 66e40 <pf_target_13_2>
  10b485:	0f 18 15 a4 0e f6 ff 	prefetcht1 -0x9f15c(%rip)        # 6c330 <pf_target_13_3>
  10b48c:	0f 18 15 2d 5c f6 ff 	prefetcht1 -0x9a3d3(%rip)        # 710c0 <pf_callee_19>

000000000010b493 <pf_jump_13>:
  10b493:	e9 18 bd f1 ff       	jmp    271b0 <pf_callee_13>
  10b498:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  10b49f:	00 

000000000010b4a0 <pf_call_14>:
  10b4a0:	0f 18 15 29 c2 f5 ff 	prefetcht1 -0xa3dd7(%rip)        # 676d0 <pf_target_14_0>

000000000010b4a7 <pf_jump_14>:
  10b4a7:	e9 f4 c3 f1 ff       	jmp    278a0 <pf_callee_14>
  10b4ac:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b4b0 <pf_call_15>:
  10b4b0:	0f 18 15 e9 c3 f1 ff 	prefetcht1 -0xe3c17(%rip)        # 278a0 <pf_callee_14>
  10b4b7:	0f 18 15 ee 3a f6 ff 	prefetcht1 -0x9c512(%rip)        # 6efac <pf_target_15_1>
  10b4be:	0f 18 15 0b 05 f6 ff 	prefetcht1 -0x9faf5(%rip)        # 6b9d0 <pf_target_15_2>
  10b4c5:	0f 18 15 f4 ce f1 ff 	prefetcht1 -0xe310c(%rip)        # 283c0 <pf_callee_18>

000000000010b4cc <pf_jump_15>:
  10b4cc:	e9 1f c9 f5 ff       	jmp    67df0 <pf_callee_15>
  10b4d1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b4d8:	00 00 00 
  10b4db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000010b4e0 <pf_call_16>:
  10b4e0:	0f 18 15 b9 42 f6 ff 	prefetcht1 -0x9bd47(%rip)        # 6f7a0 <pf_callee_17>

000000000010b4e7 <pf_jump_16>:
  10b4e7:	e9 b4 c3 f1 ff       	jmp    278a0 <pf_callee_14>
  10b4ec:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b4f0 <pf_call_17>:
  10b4f0:	0f 18 15 79 61 f4 ff 	prefetcht1 -0xb9e87(%rip)        # 51670 <pf_target_17_0>

000000000010b4f7 <pf_jump_17>:
  10b4f7:	e9 a4 42 f6 ff       	jmp    6f7a0 <pf_callee_17>
  10b4fc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b500 <pf_call_18>:
  10b500:	0f 18 15 c9 bd f5 ff 	prefetcht1 -0xa4237(%rip)        # 672d0 <pf_target_18_0>
  10b507:	0f 18 15 f2 0a f6 ff 	prefetcht1 -0x9f50e(%rip)        # 6c000 <pf_target_18_1>
  10b50e:	0f 18 15 db d1 f5 ff 	prefetcht1 -0xa2e25(%rip)        # 686f0 <pf_target_18_2>

000000000010b515 <pf_jump_18>:
  10b515:	e9 a6 ce f1 ff       	jmp    283c0 <pf_callee_18>
  10b51a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000010b520 <pf_call_19>:
  10b520:	0f 18 15 b0 3a f6 ff 	prefetcht1 -0x9c550(%rip)        # 6efd7 <pf_target_19_0>
  10b527:	0f 18 15 b7 09 f6 ff 	prefetcht1 -0x9f649(%rip)        # 6bee5 <pf_target_19_1>
  10b52e:	0f 18 15 2b 3a f6 ff 	prefetcht1 -0x9c5d5(%rip)        # 6ef60 <pf_target_19_2>
  10b535:	0f 18 15 da 05 f6 ff 	prefetcht1 -0x9fa26(%rip)        # 6bb16 <pf_target_19_3>

000000000010b53c <pf_jump_19>:
  10b53c:	e9 7f 5b f6 ff       	jmp    710c0 <pf_callee_19>
