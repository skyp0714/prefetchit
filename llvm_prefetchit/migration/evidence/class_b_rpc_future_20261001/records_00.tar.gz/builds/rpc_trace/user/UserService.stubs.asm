
/storage/prefetchit/class_b_rpc_future_20261001/builds/rpc_trace/user/call-stub-b0_5rilw/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000013f340 <pf_call_0>:
  13f340:	0f 18 15 bc 68 f1 ff 	prefetcht1 -0xe9744(%rip)        # 55c03 <pf_target_0_0>
  13f347:	0f 18 15 a2 72 f1 ff 	prefetcht1 -0xe8d5e(%rip)        # 565f0 <pf_target_0_1>
  13f34e:	0f 18 15 2b 68 f1 ff 	prefetcht1 -0xe97d5(%rip)        # 55b80 <pf_target_0_2>
  13f355:	0f 18 15 a6 bf f1 ff 	prefetcht1 -0xe405a(%rip)        # 5b302 <pf_target_0_3>
  13f35c:	0f 18 15 2d bf f1 ff 	prefetcht1 -0xe40d3(%rip)        # 5b290 <pf_target_0_4>
  13f363:	0f 18 15 58 bf f1 ff 	prefetcht1 -0xe40a8(%rip)        # 5b2c2 <pf_target_0_5>

000000000013f36a <pf_jump_0>:
  13f36a:	e9 e1 a0 ee ff       	jmp    29450 <pf_callee_0>
  13f36f:	90                   	nop

000000000013f370 <pf_call_1>:
  13f370:	0f 18 15 e9 39 f0 ff 	prefetcht1 -0xfc617(%rip)        # 42d60 <pf_target_1_0>

000000000013f377 <pf_jump_1>:
  13f377:	e9 d4 a0 ee ff       	jmp    29450 <pf_callee_0>
  13f37c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f380 <pf_call_2>:
  13f380:	0f 18 15 49 ae ee ff 	prefetcht1 -0x1151b7(%rip)        # 2a1d0 <pf_target_2_0>

000000000013f387 <pf_jump_2>:
  13f387:	e9 54 9e ee ff       	jmp    291e0 <pf_callee_16>
  13f38c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f390 <pf_call_3>:
  13f390:	0f 18 15 99 3f f7 ff 	prefetcht1 -0x8c067(%rip)        # b3330 <pf_target_30_2>
  13f397:	0f 18 15 f2 ad f7 ff 	prefetcht1 -0x8520e(%rip)        # ba190 <pf_target_30_3>
  13f39e:	0f 18 15 1b 07 f7 ff 	prefetcht1 -0x8f8e5(%rip)        # afac0 <pf_target_30_7>
  13f3a5:	0f 18 15 24 da f8 ff 	prefetcht1 -0x725dc(%rip)        # ccdd0 <pf_callee_5>
  13f3ac:	0f 18 15 3d b0 ee ff 	prefetcht1 -0x114fc3(%rip)        # 2a3f0 <pf_target_3_4>
  13f3b3:	0f 18 15 0b ae f7 ff 	prefetcht1 -0x851f5(%rip)        # ba1c5 <pf_target_3_5>
  13f3ba:	0f 18 15 7f 3f f7 ff 	prefetcht1 -0x8c081(%rip)        # b3340 <pf_target_3_6>
  13f3c1:	0f 18 15 b8 d8 f8 ff 	prefetcht1 -0x72748(%rip)        # ccc80 <pf_target_3_7>

000000000013f3c8 <pf_jump_3>:
  13f3c8:	e9 43 cb f1 ff       	jmp    5bf10 <pf_callee_3>
  13f3cd:	0f 1f 00             	nopl   (%rax)

000000000013f3d0 <pf_call_4>:
  13f3d0:	0f 18 15 49 87 fa ff 	prefetcht1 -0x578b7(%rip)        # e7b20 <pf_target_4_0>
  13f3d7:	0f 18 15 22 31 fb ff 	prefetcht1 -0x4cede(%rip)        # f2500 <pf_target_4_1>
  13f3de:	0f 18 15 5b 8c fa ff 	prefetcht1 -0x573a5(%rip)        # e8040 <pf_target_4_2>

000000000013f3e5 <pf_jump_4>:
  13f3e5:	e9 86 9c ee ff       	jmp    29070 <pf_callee_4>
  13f3ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000013f3f0 <pf_call_5>:
  13f3f0:	0f 18 15 d9 9d f6 ff 	prefetcht1 -0x96227(%rip)        # a91d0 <pf_target_5_0>

000000000013f3f7 <pf_jump_5>:
  13f3f7:	e9 d4 d9 f8 ff       	jmp    ccdd0 <pf_callee_5>
  13f3fc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f400 <pf_call_6>:
  13f400:	0f 18 15 c9 3a f0 ff 	prefetcht1 -0xfc537(%rip)        # 42ed0 <pf_target_6_0>

000000000013f407 <pf_jump_6>:
  13f407:	e9 d4 9d ee ff       	jmp    291e0 <pf_callee_16>
  13f40c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f410 <pf_call_7>:
  13f410:	0f 18 15 c9 74 f3 ff 	prefetcht1 -0xc8b37(%rip)        # 768e0 <pf_target_7_0>
  13f417:	0f 18 15 32 a3 ee ff 	prefetcht1 -0x115cce(%rip)        # 29750 <pf_callee_8>

000000000013f41e <pf_jump_7>:
  13f41e:	e9 0d 46 f0 ff       	jmp    43a30 <pf_callee_7>
  13f423:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f42a:	00 00 00 
  13f42d:	0f 1f 00             	nopl   (%rax)

000000000013f430 <pf_call_8>:
  13f430:	0f 18 15 1b 8b ef ff 	prefetcht1 -0x1074e5(%rip)        # 37f52 <pf_target_8_0>

000000000013f437 <pf_jump_8>:
  13f437:	e9 14 a3 ee ff       	jmp    29750 <pf_callee_8>
  13f43c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f440 <pf_call_9>:
  13f440:	0f 18 15 06 61 f4 ff 	prefetcht1 -0xb9efa(%rip)        # 8554d <pf_target_9_0>

000000000013f447 <pf_jump_9>:
  13f447:	e9 94 cb f1 ff       	jmp    5bfe0 <pf_callee_9>
  13f44c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f450 <pf_call_10>:
  13f450:	0f 18 15 39 a2 ee ff 	prefetcht1 -0x115dc7(%rip)        # 29690 <pf_target_10_0>

000000000013f457 <pf_jump_10>:
  13f457:	e9 74 ab ee ff       	jmp    29fd0 <pf_callee_10>
  13f45c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f460 <pf_call_11>:
  13f460:	0f 18 15 e9 73 f3 ff 	prefetcht1 -0xc8c17(%rip)        # 76850 <pf_target_11_0>
  13f467:	0f 18 15 d2 81 f3 ff 	prefetcht1 -0xc7e2e(%rip)        # 77640 <pf_target_11_1>

000000000013f46e <pf_jump_11>:
  13f46e:	e9 cd 9f ee ff       	jmp    29440 <pf_callee_11>
  13f473:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f47a:	00 00 00 
  13f47d:	0f 1f 00             	nopl   (%rax)

000000000013f480 <pf_call_12>:
  13f480:	0f 18 15 39 a3 ee ff 	prefetcht1 -0x115cc7(%rip)        # 297c0 <pf_target_12_0>

000000000013f487 <pf_jump_12>:
  13f487:	e9 e4 a7 ee ff       	jmp    29c70 <pf_callee_12>
  13f48c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f490 <pf_call_13>:
  13f490:	0f 18 15 49 6d f1 ff 	prefetcht1 -0xe92b7(%rip)        # 561e0 <pf_target_13_0>
  13f497:	0f 18 15 65 6d f1 ff 	prefetcht1 -0xe929b(%rip)        # 56203 <pf_target_13_1>

000000000013f49e <pf_jump_13>:
  13f49e:	e9 cd 9c ee ff       	jmp    29170 <pf_callee_13>
  13f4a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f4aa:	00 00 00 
  13f4ad:	0f 1f 00             	nopl   (%rax)

000000000013f4b0 <pf_call_14>:
  13f4b0:	0f 18 15 5e cb f1 ff 	prefetcht1 -0xe34a2(%rip)        # 5c015 <pf_target_14_0>

000000000013f4b7 <pf_jump_14>:
  13f4b7:	e9 64 35 f1 ff       	jmp    52a20 <pf_callee_14>
  13f4bc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f4c0 <pf_call_15>:
  13f4c0:	0f 18 15 bc 6d f1 ff 	prefetcht1 -0xe9244(%rip)        # 56283 <pf_target_15_0>

000000000013f4c7 <pf_jump_15>:
  13f4c7:	e9 d4 71 f1 ff       	jmp    566a0 <pf_callee_15>
  13f4cc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f4d0 <pf_call_16>:
  13f4d0:	0f 18 15 a9 86 f1 ff 	prefetcht1 -0xe7957(%rip)        # 57b80 <pf_target_16_0>

000000000013f4d7 <pf_jump_16>:
  13f4d7:	e9 04 9d ee ff       	jmp    291e0 <pf_callee_16>
  13f4dc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f4e0 <pf_call_17>:
  13f4e0:	0f 18 15 09 ac ee ff 	prefetcht1 -0x1153f7(%rip)        # 2a0f0 <pf_target_17_0>

000000000013f4e7 <pf_jump_17>:
  13f4e7:	e9 f4 9c ee ff       	jmp    291e0 <pf_callee_16>
  13f4ec:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f4f0 <pf_call_18>:
  13f4f0:	0f 18 15 f9 7b f1 ff 	prefetcht1 -0xe8407(%rip)        # 570f0 <pf_target_18_0>
  13f4f7:	0f 18 15 92 a2 ee ff 	prefetcht1 -0x115d6e(%rip)        # 29790 <pf_target_18_1>
  13f4fe:	0f 18 15 00 7c f1 ff 	prefetcht1 -0xe8400(%rip)        # 57105 <pf_target_18_2>
  13f505:	0f 18 15 14 35 f1 ff 	prefetcht1 -0xecaec(%rip)        # 52a20 <pf_callee_14>
  13f50c:	0f 18 15 30 35 f1 ff 	prefetcht1 -0xecad0(%rip)        # 52a43 <pf_target_18_4>

000000000013f513 <pf_jump_18>:
  13f513:	e9 08 81 f1 ff       	jmp    57620 <pf_callee_18>
  13f518:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  13f51f:	00 

000000000013f520 <pf_call_19>:
  13f520:	0f 18 15 89 ad ee ff 	prefetcht1 -0x115277(%rip)        # 2a2b0 <pf_target_19_0>

000000000013f527 <pf_jump_19>:
  13f527:	e9 f4 34 f1 ff       	jmp    52a20 <pf_callee_14>
  13f52c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f530 <pf_call_20>:
  13f530:	0f 18 15 30 a0 f4 ff 	prefetcht1 -0xb5fd0(%rip)        # 89567 <pf_target_20_0>
  13f537:	0f 18 15 47 38 f4 ff 	prefetcht1 -0xbc7b9(%rip)        # 82d85 <pf_target_20_1>
  13f53e:	0f 18 15 1b 76 f3 ff 	prefetcht1 -0xc89e5(%rip)        # 76b60 <pf_target_20_2>
  13f545:	0f 18 15 6a 34 f4 ff 	prefetcht1 -0xbcb96(%rip)        # 829b6 <pf_target_20_3>
  13f54c:	0f 18 15 ed 80 f3 ff 	prefetcht1 -0xc7f13(%rip)        # 77640 <pf_target_11_1>

000000000013f553 <pf_jump_20>:
  13f553:	e9 88 9c ee ff       	jmp    291e0 <pf_callee_16>
  13f558:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  13f55f:	00 

000000000013f560 <pf_call_21>:
  13f560:	0f 18 15 19 43 f2 ff 	prefetcht1 -0xdbce7(%rip)        # 63880 <pf_target_21_0>
  13f567:	0f 18 15 82 de f8 ff 	prefetcht1 -0x7217e(%rip)        # cd3f0 <pf_target_21_1>
  13f56e:	0f 18 15 eb 42 f2 ff 	prefetcht1 -0xdbd15(%rip)        # 63860 <pf_target_21_2>

000000000013f575 <pf_jump_21>:
  13f575:	e9 b6 7d f2 ff       	jmp    67330 <pf_callee_21>
  13f57a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000013f580 <pf_call_22>:
  13f580:	0f 18 15 f9 a2 ee ff 	prefetcht1 -0x115d07(%rip)        # 29880 <pf_callee_23>

000000000013f587 <pf_jump_22>:
  13f587:	e9 84 85 f3 ff       	jmp    77b10 <pf_callee_22>
  13f58c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f590 <pf_call_23>:
  13f590:	0f 18 15 39 ab ee ff 	prefetcht1 -0x1154c7(%rip)        # 2a0d0 <pf_callee_32>
  13f597:	0f 18 15 92 a7 f4 ff 	prefetcht1 -0xb586e(%rip)        # 89d30 <pf_callee_24>
  13f59e:	0f 18 15 3a 18 f5 ff 	prefetcht1 -0xae7c6(%rip)        # 90ddf <pf_target_23_2>

000000000013f5a5 <pf_jump_23>:
  13f5a5:	e9 d6 a2 ee ff       	jmp    29880 <pf_callee_23>
  13f5aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000013f5b0 <pf_call_24>:
  13f5b0:	0f 18 15 29 ae ee ff 	prefetcht1 -0x1151d7(%rip)        # 2a3e0 <pf_target_24_0>
  13f5b7:	0f 18 15 22 c3 f1 ff 	prefetcht1 -0xe3cde(%rip)        # 5b8e0 <pf_target_24_1>

000000000013f5be <pf_jump_24>:
  13f5be:	e9 6d a7 f4 ff       	jmp    89d30 <pf_callee_24>
  13f5c3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f5ca:	00 00 00 
  13f5cd:	0f 1f 00             	nopl   (%rax)

000000000013f5d0 <pf_call_25>:
  13f5d0:	0f 18 15 e9 fa f3 ff 	prefetcht1 -0xc0517(%rip)        # 7f0c0 <pf_callee_30>
  13f5d7:	0f 18 15 12 7a f3 ff 	prefetcht1 -0xc85ee(%rip)        # 76ff0 <pf_target_25_1>
  13f5de:	0f 18 15 bb 5c f4 ff 	prefetcht1 -0xba345(%rip)        # 852a0 <pf_target_25_2>
  13f5e5:	0f 18 15 15 7a f3 ff 	prefetcht1 -0xc85eb(%rip)        # 77001 <pf_target_25_3>
  13f5ec:	0f 18 15 cf 5c f4 ff 	prefetcht1 -0xba331(%rip)        # 852c2 <pf_target_25_4>

000000000013f5f3 <pf_jump_25>:
  13f5f3:	e9 58 ae ee ff       	jmp    2a450 <pf_callee_25>
  13f5f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  13f5ff:	00 

000000000013f600 <pf_call_26>:
  13f600:	0f 18 15 c9 39 ef ff 	prefetcht1 -0x10c637(%rip)        # 32fd0 <pf_target_26_0>
  13f607:	0f 18 15 f4 39 ef ff 	prefetcht1 -0x10c60c(%rip)        # 33002 <pf_target_26_1>

000000000013f60e <pf_jump_26>:
  13f60e:	e9 3d b8 f3 ff       	jmp    7ae50 <pf_callee_26>
  13f613:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f61a:	00 00 00 
  13f61d:	0f 1f 00             	nopl   (%rax)

000000000013f620 <pf_call_27>:
  13f620:	0f 18 15 39 5e ef ff 	prefetcht1 -0x10a1c7(%rip)        # 35460 <pf_target_27_0>
  13f627:	0f 18 15 59 5e ef ff 	prefetcht1 -0x10a1a7(%rip)        # 35487 <pf_target_27_1>

000000000013f62e <pf_jump_27>:
  13f62e:	e9 8d c9 f3 ff       	jmp    7bfc0 <pf_callee_27>
  13f633:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f63a:	00 00 00 
  13f63d:	0f 1f 00             	nopl   (%rax)

000000000013f640 <pf_call_28>:
  13f640:	0f 18 15 c9 a4 ef ff 	prefetcht1 -0x105b37(%rip)        # 39b10 <pf_target_28_0>
  13f647:	0f 18 15 f4 a4 ef ff 	prefetcht1 -0x105b0c(%rip)        # 39b42 <pf_target_28_1>

000000000013f64e <pf_jump_28>:
  13f64e:	e9 bd db f3 ff       	jmp    7d210 <pf_callee_28>
  13f653:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f65a:	00 00 00 
  13f65d:	0f 1f 00             	nopl   (%rax)

000000000013f660 <pf_call_29>:
  13f660:	0f 18 15 09 9e ef ff 	prefetcht1 -0x1061f7(%rip)        # 39470 <pf_target_29_0>
  13f667:	0f 18 15 13 9e ef ff 	prefetcht1 -0x1061ed(%rip)        # 39481 <pf_target_29_1>

000000000013f66e <pf_jump_29>:
  13f66e:	e9 9d eb f3 ff       	jmp    7e210 <pf_callee_29>
  13f673:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f67a:	00 00 00 
  13f67d:	0f 1f 00             	nopl   (%rax)

000000000013f680 <pf_call_30>:
  13f680:	0f 18 15 d9 73 ef ff 	prefetcht1 -0x108c27(%rip)        # 36a60 <pf_target_30_0>
  13f687:	0f 18 15 f2 73 ef ff 	prefetcht1 -0x108c0e(%rip)        # 36a80 <pf_target_30_1>
  13f68e:	0f 18 15 9b 3c f7 ff 	prefetcht1 -0x8c365(%rip)        # b3330 <pf_target_30_2>
  13f695:	0f 18 15 f4 aa f7 ff 	prefetcht1 -0x8550c(%rip)        # ba190 <pf_target_30_3>
  13f69c:	0f 18 15 58 65 f1 ff 	prefetcht1 -0xe9aa8(%rip)        # 55bfb <pf_target_30_4>
  13f6a3:	0f 18 15 a6 71 f3 ff 	prefetcht1 -0xc8e5a(%rip)        # 76850 <pf_target_11_0>
  13f6aa:	0f 18 15 df bb f1 ff 	prefetcht1 -0xe4421(%rip)        # 5b290 <pf_target_0_4>
  13f6b1:	0f 18 15 08 04 f7 ff 	prefetcht1 -0x8fbf8(%rip)        # afac0 <pf_target_30_7>

000000000013f6b8 <pf_jump_30>:
  13f6b8:	e9 03 fa f3 ff       	jmp    7f0c0 <pf_callee_30>
  13f6bd:	0f 1f 00             	nopl   (%rax)

000000000013f6c0 <pf_call_31>:
  13f6c0:	0f 18 15 29 9e f4 ff 	prefetcht1 -0xb61d7(%rip)        # 894f0 <pf_target_31_0>

000000000013f6c7 <pf_jump_31>:
  13f6c7:	e9 14 9b ee ff       	jmp    291e0 <pf_callee_16>
  13f6cc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000013f6d0 <pf_call_32>:
  13f6d0:	0f 18 15 2b f3 f4 ff 	prefetcht1 -0xb0cd5(%rip)        # 8ea02 <pf_target_32_0>
  13f6d7:	0f 18 15 d2 f2 f4 ff 	prefetcht1 -0xb0d2e(%rip)        # 8e9b0 <pf_target_32_1>
  13f6de:	0f 18 15 1c 79 f3 ff 	prefetcht1 -0xc86e4(%rip)        # 77001 <pf_target_25_3>
  13f6e5:	0f 18 15 17 19 f5 ff 	prefetcht1 -0xae6e9(%rip)        # 91003 <pf_target_32_3>

000000000013f6ec <pf_jump_32>:
  13f6ec:	e9 df a9 ee ff       	jmp    2a0d0 <pf_callee_32>
  13f6f1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  13f6f8:	00 00 00 
  13f6fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000013f700 <pf_call_33>:
  13f700:	0f 18 15 d8 81 ef ff 	prefetcht1 -0x107e28(%rip)        # 378df <pf_target_33_0>
  13f707:	0f 18 15 32 9d ee ff 	prefetcht1 -0x1162ce(%rip)        # 29440 <pf_callee_11>
  13f70e:	0f 18 15 1b 43 f0 ff 	prefetcht1 -0xfbce5(%rip)        # 43a30 <pf_callee_7>

000000000013f715 <pf_jump_33>:
  13f715:	e9 56 f0 f5 ff       	jmp    9e770 <pf_callee_33>
  13f71a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000013f720 <pf_call_34>:
  13f720:	0f 18 15 89 7b f2 ff 	prefetcht1 -0xd8477(%rip)        # 672b0 <pf_target_34_0>

000000000013f727 <pf_jump_34>:
  13f727:	e9 94 a9 ee ff       	jmp    2a0c0 <pf_callee_34>
