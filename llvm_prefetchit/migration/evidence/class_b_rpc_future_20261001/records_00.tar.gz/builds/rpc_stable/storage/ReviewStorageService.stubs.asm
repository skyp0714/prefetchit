
/storage/prefetchit/class_b_rpc_future_20261001/builds/rpc_stable/storage/call-stub-x992oirs/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000111380 <pf_call_0>:
  111380:	0f 18 15 d9 03 f2 ff 	prefetcht1 -0xdfc27(%rip)        # 31760 <pf_target_0_0>
  111387:	0f 18 15 f2 03 f2 ff 	prefetcht1 -0xdfc0e(%rip)        # 31780 <pf_target_0_1>

000000000011138e <pf_jump_0>:
  11138e:	e9 2d 82 f5 ff       	jmp    695c0 <pf_callee_0>
  111393:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11139a:	00 00 00 
  11139d:	0f 1f 00             	nopl   (%rax)

00000000001113a0 <pf_call_1>:
  1113a0:	0f 18 15 f9 f7 f1 ff 	prefetcht1 -0xe0807(%rip)        # 30ba0 <pf_target_1_0>
  1113a7:	0f 18 15 12 f8 f1 ff 	prefetcht1 -0xe07ee(%rip)        # 30bc0 <pf_target_1_1>
  1113ae:	0f 18 15 4b fc f1 ff 	prefetcht1 -0xe03b5(%rip)        # 31000 <pf_target_1_2>

00000000001113b5 <pf_jump_1>:
  1113b5:	e9 36 73 f5 ff       	jmp    686f0 <pf_callee_1>
