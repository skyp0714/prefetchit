
/storage/prefetchit/class_b_rpc_future_20261001/builds/rpc_stable/userreview/call-stub-r0hvve68/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000001e2380 <pf_call_0>:
  1e2380:	0f 18 15 69 51 e6 ff 	prefetcht1 -0x19ae97(%rip)        # 474f0 <pf_target_0_0>
  1e2387:	0f 18 15 73 51 e6 ff 	prefetcht1 -0x19ae8d(%rip)        # 47501 <pf_target_0_1>

00000000001e238e <pf_jump_0>:
  1e238e:	e9 0d 1b ea ff       	jmp    83ea0 <pf_callee_0>
  1e2393:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1e239a:	00 00 00 
  1e239d:	0f 1f 00             	nopl   (%rax)

00000000001e23a0 <pf_call_1>:
  1e23a0:	0f 18 15 e9 2e e6 ff 	prefetcht1 -0x19d117(%rip)        # 45290 <pf_target_1_0>
  1e23a7:	0f 18 15 18 2f e6 ff 	prefetcht1 -0x19d0e8(%rip)        # 452c6 <pf_target_1_1>
  1e23ae:	0f 18 15 4e 42 e6 ff 	prefetcht1 -0x19bdb2(%rip)        # 46603 <pf_target_1_2>
  1e23b5:	0f 18 15 45 36 e6 ff 	prefetcht1 -0x19c9bb(%rip)        # 45a01 <pf_target_1_3>
  1e23bc:	0f 18 15 fd 32 e6 ff 	prefetcht1 -0x19cd03(%rip)        # 456c0 <pf_target_1_4>
  1e23c3:	0f 18 15 38 3c e6 ff 	prefetcht1 -0x19c3c8(%rip)        # 46002 <pf_target_1_5>
  1e23ca:	0f 18 15 33 3a e6 ff 	prefetcht1 -0x19c5cd(%rip)        # 45e04 <pf_target_1_6>
  1e23d1:	0f 18 15 a8 32 e6 ff 	prefetcht1 -0x19cd58(%rip)        # 45680 <pf_target_1_7>

00000000001e23d8 <pf_jump_1>:
  1e23d8:	e9 c3 0a ea ff       	jmp    82ea0 <pf_callee_1>
