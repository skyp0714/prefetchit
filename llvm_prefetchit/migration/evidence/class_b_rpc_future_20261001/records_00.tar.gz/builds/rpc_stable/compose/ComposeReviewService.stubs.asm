
/storage/prefetchit/class_b_rpc_future_20261001/builds/rpc_stable/compose/call-stub-hg4uxmsc/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000356380 <pf_call_0>:
  356380:	0f 18 15 79 e6 d4 ff 	prefetcht1 -0x2b1987(%rip)        # a4a00 <pf_target_0_0>
  356387:	0f 18 15 b5 e6 d4 ff 	prefetcht1 -0x2b194b(%rip)        # a4a43 <pf_target_0_1>
  35638e:	0f 18 15 ed f0 d4 ff 	prefetcht1 -0x2b0f13(%rip)        # a5482 <pf_target_0_2>
  356395:	0f 18 15 25 eb d4 ff 	prefetcht1 -0x2b14db(%rip)        # a4ec1 <pf_target_0_3>
  35639c:	0f 18 15 1e ef d4 ff 	prefetcht1 -0x2b10e2(%rip)        # a52c1 <pf_target_0_4>
  3563a3:	0f 18 15 17 ed d4 ff 	prefetcht1 -0x2b12e9(%rip)        # a50c1 <pf_target_0_5>
  3563aa:	0f 18 15 4f ea d4 ff 	prefetcht1 -0x2b15b1(%rip)        # a4e00 <pf_target_0_6>

00000000003563b1 <pf_jump_0>:
  3563b1:	e9 fa ca fe ff       	jmp    342eb0 <pf_callee_0>
  3563b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  3563bd:	00 00 00 

00000000003563c0 <pf_call_1>:
  3563c0:	0f 18 15 39 fe d4 ff 	prefetcht1 -0x2b01c7(%rip)        # a6200 <pf_target_1_0>
  3563c7:	0f 18 15 75 fe d4 ff 	prefetcht1 -0x2b018b(%rip)        # a6243 <pf_target_1_1>
  3563ce:	0f 18 15 71 0b d5 ff 	prefetcht1 -0x2af48f(%rip)        # a6f46 <pf_target_1_2>
  3563d5:	0f 18 15 e5 09 d5 ff 	prefetcht1 -0x2af61b(%rip)        # a6dc1 <pf_target_1_3>
  3563dc:	0f 18 15 de 02 d5 ff 	prefetcht1 -0x2afd22(%rip)        # a66c1 <pf_target_1_4>
  3563e3:	0f 18 15 dc 05 d5 ff 	prefetcht1 -0x2afa24(%rip)        # a69c6 <pf_target_1_5>
  3563ea:	0f 18 15 12 0b d5 ff 	prefetcht1 -0x2af4ee(%rip)        # a6f03 <pf_target_1_6>

00000000003563f1 <pf_jump_1>:
  3563f1:	e9 1a cb fe ff       	jmp    342f10 <pf_callee_1>
  3563f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  3563fd:	00 00 00 

0000000000356400 <pf_call_2>:
  356400:	0f 18 15 79 b2 d4 ff 	prefetcht1 -0x2b4d87(%rip)        # a1680 <pf_target_2_0>
  356407:	0f 18 15 b5 b2 d4 ff 	prefetcht1 -0x2b4d4b(%rip)        # a16c3 <pf_target_2_1>
  35640e:	0f 18 15 eb b6 d4 ff 	prefetcht1 -0x2b4915(%rip)        # a1b00 <pf_target_2_2>
  356415:	0f 18 15 64 bc d4 ff 	prefetcht1 -0x2b439c(%rip)        # a2080 <pf_target_2_3>
  35641c:	0f 18 15 1d bc d4 ff 	prefetcht1 -0x2b43e3(%rip)        # a2040 <pf_target_2_4>
  356423:	0f 18 15 19 ba d4 ff 	prefetcht1 -0x2b45e7(%rip)        # a1e43 <pf_target_2_5>
  35642a:	0f 18 15 cf b7 d4 ff 	prefetcht1 -0x2b4831(%rip)        # a1c00 <pf_target_2_6>

0000000000356431 <pf_jump_2>:
  356431:	e9 6a cb fe ff       	jmp    342fa0 <pf_callee_2>
  356436:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  35643d:	00 00 00 

0000000000356440 <pf_call_3>:
  356440:	0f 18 15 39 9a d4 ff 	prefetcht1 -0x2b65c7(%rip)        # 9fe80 <pf_target_3_0>
  356447:	0f 18 15 75 9a d4 ff 	prefetcht1 -0x2b658b(%rip)        # 9fec3 <pf_target_3_1>
  35644e:	0f 18 15 ec a2 d4 ff 	prefetcht1 -0x2b5d14(%rip)        # a0741 <pf_target_3_2>
  356455:	0f 18 15 e5 a0 d4 ff 	prefetcht1 -0x2b5f1b(%rip)        # a0541 <pf_target_3_3>
  35645c:	0f 18 15 20 9b d4 ff 	prefetcht1 -0x2b64e0(%rip)        # 9ff83 <pf_target_3_4>
  356463:	0f 18 15 5b 9b d4 ff 	prefetcht1 -0x2b64a5(%rip)        # 9ffc5 <pf_target_3_5>
  35646a:	0f 18 15 91 a4 d4 ff 	prefetcht1 -0x2b5b6f(%rip)        # a0902 <pf_target_3_6>

0000000000356471 <pf_jump_3>:
  356471:	e9 ca ca fe ff       	jmp    342f40 <pf_callee_3>
  356476:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  35647d:	00 00 00 

0000000000356480 <pf_call_4>:
  356480:	0f 18 15 d9 cb d4 ff 	prefetcht1 -0x2b3427(%rip)        # a3060 <pf_target_4_0>
  356487:	0f 18 15 f6 cb d4 ff 	prefetcht1 -0x2b340a(%rip)        # a3084 <pf_target_4_1>
  35648e:	0f 18 15 ab d3 d4 ff 	prefetcht1 -0x2b2c55(%rip)        # a3840 <pf_target_4_2>
  356495:	0f 18 15 a5 d5 d4 ff 	prefetcht1 -0x2b2a5b(%rip)        # a3a41 <pf_target_4_3>
  35649c:	0f 18 15 61 d0 d4 ff 	prefetcht1 -0x2b2f9f(%rip)        # a3504 <pf_target_4_4>
  3564a3:	0f 18 15 58 d7 d4 ff 	prefetcht1 -0x2b28a8(%rip)        # a3c02 <pf_target_4_5>

00000000003564aa <pf_jump_4>:
  3564aa:	e9 c1 ca fe ff       	jmp    342f70 <pf_callee_4>
