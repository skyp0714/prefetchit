
/storage/prefetchit/class_b_rpc_future_20261001/builds/rpc_stable/unique/call-stub-8i3xvhfp/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000119380 <pf_call_0>:
  119380:	0f 18 15 79 5d f1 ff 	prefetcht1 -0xea287(%rip)        # 2f100 <pf_target_0_0>
  119387:	0f 18 15 b8 5d f1 ff 	prefetcht1 -0xea248(%rip)        # 2f146 <pf_target_0_1>
  11938e:	0f 18 15 6c 68 f1 ff 	prefetcht1 -0xe9794(%rip)        # 2fc01 <pf_target_0_2>
  119395:	0f 18 15 65 65 f1 ff 	prefetcht1 -0xe9a9b(%rip)        # 2f901 <pf_target_0_3>
  11939c:	0f 18 15 1d 64 f1 ff 	prefetcht1 -0xe9be3(%rip)        # 2f7c0 <pf_target_0_4>

00000000001193a3 <pf_jump_0>:
  1193a3:	e9 18 a2 ff ff       	jmp    1135c0 <pf_callee_0>
