
/storage/prefetchit/class_b_rpc_future_20261001/builds/rpc_stable/moviereview/call-stub-zki_n9o2/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000001e2380 <pf_call_0>:
  1e2380:	0f 18 15 79 4f e6 ff 	prefetcht1 -0x19b087(%rip)        # 47300 <pf_target_0_0>
  1e2387:	0f 18 15 b9 4f e6 ff 	prefetcht1 -0x19b047(%rip)        # 47347 <pf_target_0_1>

00000000001e238e <pf_jump_0>:
  1e238e:	e9 7d 15 ea ff       	jmp    83910 <pf_callee_0>
  1e2393:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1e239a:	00 00 00 
  1e239d:	0f 1f 00             	nopl   (%rax)

00000000001e23a0 <pf_call_1>:
  1e23a0:	0f 18 15 e9 2e e6 ff 	prefetcht1 -0x19d117(%rip)        # 45290 <pf_target_1_0>
  1e23a7:	0f 18 15 15 2f e6 ff 	prefetcht1 -0x19d0eb(%rip)        # 452c3 <pf_target_1_1>
  1e23ae:	0f 18 15 8b 36 e6 ff 	prefetcht1 -0x19c975(%rip)        # 45a40 <pf_target_1_2>
  1e23b5:	0f 18 15 06 40 e6 ff 	prefetcht1 -0x19bffa(%rip)        # 463c2 <pf_target_1_3>
  1e23bc:	0f 18 15 3f 39 e6 ff 	prefetcht1 -0x19c6c1(%rip)        # 45d02 <pf_target_1_4>
  1e23c3:	0f 18 15 f7 32 e6 ff 	prefetcht1 -0x19cd09(%rip)        # 456c1 <pf_target_1_5>
  1e23ca:	0f 18 15 f1 37 e6 ff 	prefetcht1 -0x19c80f(%rip)        # 45bc2 <pf_target_1_6>
  1e23d1:	0f 18 15 29 2f e6 ff 	prefetcht1 -0x19d0d7(%rip)        # 45301 <pf_target_1_7>

00000000001e23d8 <pf_jump_1>:
  1e23d8:	e9 23 05 ea ff       	jmp    82900 <pf_callee_1>
