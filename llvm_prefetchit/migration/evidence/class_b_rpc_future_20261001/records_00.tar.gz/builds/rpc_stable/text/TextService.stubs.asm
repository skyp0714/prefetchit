
/storage/prefetchit/class_b_rpc_future_20261001/builds/rpc_stable/text/call-stub-k_tq6h4a/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000116380 <pf_call_0>:
  116380:	0f 18 15 a9 7c f1 ff 	prefetcht1 -0xe8357(%rip)        # 2e030 <pf_target_0_0>
  116387:	0f 18 15 b3 7c f1 ff 	prefetcht1 -0xe834d(%rip)        # 2e041 <pf_target_0_1>
  11638e:	0f 18 15 2b 7f f1 ff 	prefetcht1 -0xe80d5(%rip)        # 2e2c0 <pf_target_0_2>
  116395:	0f 18 15 24 7d f1 ff 	prefetcht1 -0xe82dc(%rip)        # 2e0c0 <pf_target_0_3>
  11639c:	0f 18 15 dd 7c f1 ff 	prefetcht1 -0xe8323(%rip)        # 2e080 <pf_target_0_4>
  1163a3:	0f 18 15 96 7d f1 ff 	prefetcht1 -0xe826a(%rip)        # 2e140 <pf_target_0_5>

00000000001163aa <pf_jump_0>:
  1163aa:	e9 e1 9d f4 ff       	jmp    60190 <pf_callee_0>
