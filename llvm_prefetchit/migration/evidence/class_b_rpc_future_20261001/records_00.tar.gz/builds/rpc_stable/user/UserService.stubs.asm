
/storage/prefetchit/class_b_rpc_future_20261001/builds/rpc_stable/user/call-stub-imp_0h4t/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000145380 <pf_call_0>:
  145380:	0f 18 15 89 47 ef ff 	prefetcht1 -0x10b877(%rip)        # 39b10 <pf_target_0_0>
  145387:	0f 18 15 b4 47 ef ff 	prefetcht1 -0x10b84c(%rip)        # 39b42 <pf_target_0_1>

000000000014538e <pf_jump_0>:
  14538e:	e9 7d 7e f3 ff       	jmp    7d210 <pf_callee_0>
  145393:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  14539a:	00 00 00 
  14539d:	0f 1f 00             	nopl   (%rax)

00000000001453a0 <pf_call_1>:
  1453a0:	0f 18 15 29 dc ee ff 	prefetcht1 -0x1123d7(%rip)        # 32fd0 <pf_target_1_0>
  1453a7:	0f 18 15 54 dc ee ff 	prefetcht1 -0x1123ac(%rip)        # 33002 <pf_target_1_1>

00000000001453ae <pf_jump_1>:
  1453ae:	e9 9d 5a f3 ff       	jmp    7ae50 <pf_callee_1>
  1453b3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1453ba:	00 00 00 
  1453bd:	0f 1f 00             	nopl   (%rax)

00000000001453c0 <pf_call_2>:
  1453c0:	0f 18 15 99 00 ef ff 	prefetcht1 -0x10ff67(%rip)        # 35460 <pf_target_2_0>
  1453c7:	0f 18 15 b9 00 ef ff 	prefetcht1 -0x10ff47(%rip)        # 35487 <pf_target_2_1>

00000000001453ce <pf_jump_2>:
  1453ce:	e9 ed 6b f3 ff       	jmp    7bfc0 <pf_callee_2>
  1453d3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1453da:	00 00 00 
  1453dd:	0f 1f 00             	nopl   (%rax)

00000000001453e0 <pf_call_3>:
  1453e0:	0f 18 15 89 40 ef ff 	prefetcht1 -0x10bf77(%rip)        # 39470 <pf_target_3_0>
  1453e7:	0f 18 15 93 40 ef ff 	prefetcht1 -0x10bf6d(%rip)        # 39481 <pf_target_3_1>

00000000001453ee <pf_jump_3>:
  1453ee:	e9 1d 8e f3 ff       	jmp    7e210 <pf_callee_3>
  1453f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1453fa:	00 00 00 
  1453fd:	0f 1f 00             	nopl   (%rax)

0000000000145400 <pf_call_4>:
  145400:	0f 18 15 59 16 ef ff 	prefetcht1 -0x10e9a7(%rip)        # 36a60 <pf_target_4_0>
  145407:	0f 18 15 72 16 ef ff 	prefetcht1 -0x10e98e(%rip)        # 36a80 <pf_target_4_1>
  14540e:	0f 18 15 b0 1b ef ff 	prefetcht1 -0x10e450(%rip)        # 36fc5 <pf_target_4_2>
  145415:	0f 18 15 a6 24 ef ff 	prefetcht1 -0x10db5a(%rip)        # 378c2 <pf_target_4_3>
  14541c:	0f 18 15 24 2b ef ff 	prefetcht1 -0x10d4dc(%rip)        # 37f47 <pf_target_4_4>
  145423:	0f 18 15 d6 1a ef ff 	prefetcht1 -0x10e52a(%rip)        # 36f00 <pf_target_4_5>
  14542a:	0f 18 15 92 16 ef ff 	prefetcht1 -0x10e96e(%rip)        # 36ac3 <pf_target_4_6>

0000000000145431 <pf_jump_4>:
  145431:	e9 ca a1 ff ff       	jmp    13f600 <pf_callee_4>
