
/storage/prefetchit/class_b_rpc_future_20261001/builds/rpc_stable/rating/call-stub-wr68rjkh/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000038f380 <pf_call_0>:
  38f380:	0f 18 15 89 4e cc ff 	prefetcht1 -0x33b177(%rip)        # 54210 <pf_target_0_0>
  38f387:	0f 18 15 b4 4e cc ff 	prefetcht1 -0x33b14c(%rip)        # 54242 <pf_target_0_1>
  38f38e:	0f 18 15 2d 56 cc ff 	prefetcht1 -0x33a9d3(%rip)        # 549c2 <pf_target_0_2>
  38f395:	0f 18 15 e4 51 cc ff 	prefetcht1 -0x33ae1c(%rip)        # 54580 <pf_target_0_3>
  38f39c:	0f 18 15 9f 56 cc ff 	prefetcht1 -0x33a961(%rip)        # 54a42 <pf_target_0_4>
  38f3a3:	0f 18 15 d6 57 cc ff 	prefetcht1 -0x33a82a(%rip)        # 54b80 <pf_target_0_5>

000000000038f3aa <pf_jump_0>:
  38f3aa:	e9 81 85 fe ff       	jmp    377930 <pf_callee_0>
