
/storage/prefetchit/class_b_rpc_future_20261001/builds/rpc_stable/movie/call-stub-vinv3_f9/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000003c3380 <pf_call_0>:
  3c3380:	0f 18 15 b9 de cd ff 	prefetcht1 -0x322147(%rip)        # a1240 <pf_target_0_0>
  3c3387:	0f 18 15 f8 de cd ff 	prefetcht1 -0x322108(%rip)        # a1286 <pf_target_0_1>
  3c338e:	0f 18 15 6b f8 cd ff 	prefetcht1 -0x320795(%rip)        # a2c00 <pf_target_0_2>
  3c3395:	0f 18 15 69 e2 cd ff 	prefetcht1 -0x321d97(%rip)        # a1605 <pf_target_0_3>
  3c339c:	0f 18 15 9e f4 cd ff 	prefetcht1 -0x320b62(%rip)        # a2841 <pf_target_0_4>
  3c33a3:	0f 18 15 17 f4 cd ff 	prefetcht1 -0x320be9(%rip)        # a27c1 <pf_target_0_5>
  3c33aa:	0f 18 15 4f f4 cd ff 	prefetcht1 -0x320bb1(%rip)        # a2800 <pf_target_0_6>
  3c33b1:	0f 18 15 0a ec cd ff 	prefetcht1 -0x3213f6(%rip)        # a1fc2 <pf_target_0_7>

00000000003c33b8 <pf_jump_0>:
  3c33b8:	e9 23 86 d1 ff       	jmp    db9e0 <pf_callee_0>
  3c33bd:	0f 1f 00             	nopl   (%rax)

00000000003c33c0 <pf_call_1>:
  3c33c0:	0f 18 15 c9 06 ce ff 	prefetcht1 -0x31f937(%rip)        # a3a90 <pf_target_1_0>
  3c33c7:	0f 18 15 f7 06 ce ff 	prefetcht1 -0x31f909(%rip)        # a3ac5 <pf_target_1_1>

00000000003c33ce <pf_jump_1>:
  3c33ce:	e9 8d 95 d1 ff       	jmp    dc960 <pf_callee_1>
