import json, pathlib, sys, tarfile, subprocess, collections
root=pathlib.Path('/storage/prefetchit/class_b_media_system_20260930')
repo=pathlib.Path('/home/hnpark2/prefetchit')
sys.path.insert(0,str(repo/'llvm_prefetchit/scripts/class_b'))
import dense_build as b
from e2e_lbr import remove_generated
assert (root/'complete.json').exists() and (root/'boundaries/complete.json').exists()
assert not subprocess.check_output(['docker','ps','--filter','label=com.docker.compose.project=codex-b-fullset-media','--format','{{.ID}}'],text=True).strip()
checks=[]
for before in sorted(root.rglob('*_before.json')):
 after=before.with_name(before.name.replace('_before','_restored'))
 checks.append(dict(path=str(before.relative_to(root)),restored=after.exists() and json.loads(before.read_text())==json.loads(after.read_text())))
assert checks and all(row['restored'] for row in checks)
runtime=[]
for p in sorted(root.rglob('native_runtime.json')):
 data=json.loads(p.read_text());runtime.append(dict(path=str(p.relative_to(root)),services=len(data),sha256=b.sha(p)))
assert runtime and all(row['services']==9 for row in runtime)
b.save(root/'final_runtime_audit.json',dict(platform_checks=checks,native_runtime=runtime,isolated_stack_removed=True))
trace_paths=[];edges={}
for path in sorted((root/'boundaries').glob('*/request_path_traces.json')):
 data=json.loads(path.read_text());counts=collections.Counter()
 for trace in data['traces']:
  spans={s['spanID']:s for s in trace['spans']};processes=trace['processes']
  for span in spans.values():
   for ref in span['references']:
    if ref['refType']!='CHILD_OF' or ref['traceID']!=trace['traceID'] or ref['spanID'] not in spans:continue
    parent=spans[ref['spanID']]
    counts[(processes.get(parent['processID'],'unknown'),parent['operationName'],processes.get(span['processID'],'unknown'),span['operationName'])]+=1
 edges[path.parent.name]=dict(quality=data['quality'],source_sha256=b.sha(path),
  edges=[dict(parent_service=k[0],parent_operation=k[1],child_service=k[2],child_operation=k[3],count=n) for k,n in counts.most_common()])
 trace_paths.append(path)
b.save(root/'request_path_edges.json',dict(arms=edges,limitation='Bounded late-window span parent/child associations, not exclusive critical path or latency attribution. Per-operation timing and query provenance retained separately.'))
if trace_paths:remove_generated(trace_paths,root/'request_trace_cleanup.json','Extracted parent/child counts, per-operation times, quality and source hashes; remove no-longer-needed individual decoded span copies.')
sources=[p for folder in ['llvm_prefetchit/scripts/class_b','llvm_prefetchit/tools','llvm_prefetchit/tests'] for p in (repo/folder).glob('*.py')]
sources += [repo/'AGENTS.md']
with tarfile.open(root/'final_sources.tar.gz','w:gz') as archive:
 for p in sources:archive.add(p,arcname=str(p.relative_to(repo)),recursive=False)
b.save(root/'final_source_manifest.json',{str(p.relative_to(repo)):dict(bytes=p.stat().st_size,sha256=b.sha(p)) for p in sources})
decision=json.loads((root/'decision.json').read_text())
assert decision['retain_candidate_binaries'] is False
candidates=[]
for rel in ['prepared.json','libraries/prepared.json']:
 for c in json.loads((root/rel).read_text())['candidates'].values():
  for kind,digest in [('binary','sha256'),('nop','nop_sha256')]:
   path=pathlib.Path(c[kind]);assert path.is_relative_to(root) and path.is_file() and not path.is_symlink()
   assert b.sha(path)==c[digest]
   candidates.append(path)
  binary=pathlib.Path(c['binary'])
  assert all(pathlib.Path(str(binary)+suffix).exists() for suffix in ['.json','.stubs.s','.stubs.ld','.stubs.asm'])
assert len(candidates)==len(set(candidates))==34
remove_generated(candidates,root/'candidate_cleanup.json',decision['cleanup_reason'])
patches=root/'patch_records';patches.mkdir(exist_ok=False);moves=[];directories=[]
for category,build in [('native',root/'builds'),('libraries',root/'libraries/builds')]:
 for path in sorted(build.rglob('*')):
  if path.is_file():
   assert not path.is_symlink() and path.suffix in ['.json','.s','.ld','.asm']
   dest=patches/category/path.relative_to(build)
   moves.append(dict(source=str(path),destination=str(dest),bytes=path.stat().st_size,sha256=b.sha(path)))
b.save(root/'patch_record_moves.json',dict(status='prepared',files=moves))
for row in moves:
 dest=pathlib.Path(row['destination']);dest.parent.mkdir(parents=True,exist_ok=True);pathlib.Path(row['source']).rename(dest)
 assert b.sha(dest)==row['sha256']
for build in [root/'builds',root/'libraries/builds']:
 for path in sorted([p for p in build.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):
  assert not path.is_symlink();path.rmdir();directories.append(str(path))
 build.rmdir();directories.append(str(build))
b.save(root/'patch_record_moves.json',dict(status='complete',files=moves,empty_build_directories_removed=directories))
assert not list(root.rglob('perf.data')) and not list(root.rglob('samples.txt'))
b.save(root/'artifact_retention_complete.json',dict(candidate_elfs_removed=len(candidates),build_directories_removed=directories,preserved='Measurements, negative-result decision, settings/commands, patched-byte/assembly/linker records moved to patch_records, binary hashes, original references, original shared libraries, existing MongoDB split75 reference, source archives. Benchmark inputs/images/source/shared dependencies untouched.',patch_records={str(p.relative_to(root)):p.stat().st_size for p in patches.rglob('*') if p.is_file()}))
print('Final audit and candidate cleanup complete.')
