import json, pathlib, sys, hashlib, tarfile
root=pathlib.Path('/storage/prefetchit/class_b_media_system_20260930')
repo=pathlib.Path('/home/hnpark2/prefetchit')
sys.path.insert(0,str(repo/'llvm_prefetchit/scripts/class_b'))
import dense_build as b
import media_system_study as study
import media_boundary_profile as boundary
assert (root/'screen/complete.json').exists()
invalid=root/'invalid_diagnostics';invalid.mkdir(exist_ok=False)
moved=[]
for path in sorted((root/'diagnostics').glob('00_original*')):
 target=invalid/path.name;path.rename(target);moved.append(str(target))
checks=[]
for before in (invalid/'00_original_platform').rglob('*_before.json'):
 after=before.with_name(before.name.replace('_before','_restored'))
 checks.append(dict(path=str(before),restored=after.exists() and json.loads(before.read_text())==json.loads(after.read_text())))
assert checks and all(c['restored'] for c in checks)
load=json.loads((invalid/'00_original/load/load.json').read_text())
b.save(root/'diagnostic_amendment.json',dict(reason='Original diagnostic exceeded unchanged 100,000 HTTP requests per persistent connection; one HTTP 200 closed its connection after 399,440 completions. Reject the entire diagnostic and retain all compact raw counters/logs. No completed clean endpoint trial changed or retried.',load=load,moved=moved,platform_restoration=checks,change='Dedicated diagnostic-only ROI reduced from 60 to 5 seconds; 50-second warmup and all 3-second PMU windows unchanged. Six diagnostics restarted with unchanged arm order/seeds. End-to-end results from diagnostic runs are not used.',bulk_status='Finally blocks removed Docker stack/data volumes and compacted HTTP request traces before controller returned. No candidate binary was rejected; all remain active for the corrected diagnostics.'))
files=[repo/'llvm_prefetchit/scripts/class_b'/name for name in ['split_hybrid_study.py','media_system_study.py','media_boundary_profile.py','media_system_report.py']]
with tarfile.open(root/'diagnostic_sources.tar.gz','w:gz') as ar:
 for p in files:ar.add(p,arcname=str(p.relative_to(repo)))
b.save(root/'diagnostic_source_manifest.json',{str(p.relative_to(repo)):b.sha(p) for p in files})
study.diagnostics(root)
b.save(root/'complete.json',dict(valid=True,clean_trials=16,diagnostic_runs=6,invalid_diagnostics=1))
boundary.run(root)
