import pathlib,json,sys,collections
sys.path.insert(0,'/home/hnpark2/prefetchit/llvm_prefetchit/scripts/class_b')
import dense_build as b
from e2e_lbr import remove_generated
root=pathlib.Path('/storage/prefetchit/class_b_media_system_20260930')
path=root/'invalid_boundaries/original/request_path_traces.json'
data=json.loads(path.read_text());edges=collections.Counter()
for trace in data['traces']:
 spans={s['spanID']:s for s in trace['spans']}
 for span in spans.values():
  for ref in span['references']:
   if ref['refType']=='CHILD_OF' and ref['traceID']==trace['traceID'] and ref['spanID'] in spans:
    parent=spans[ref['spanID']];edges[(trace['processes'][parent['processID']],parent['operationName'],trace['processes'][span['processID']],span['operationName'])]+=1
b.save(path.parent/'request_path_edges.json',dict(quality=data['quality'],source_sha256=b.sha(path),edges=[dict(parent_service=k[0],parent_operation=k[1],child_service=k[2],child_operation=k[3],count=v) for k,v in edges.most_common()],limitation='Invalid boundary sample run. Trace API has missing parent spans; do not treat it as a complete call graph or latency attribution. Keep observed operations and existing parent/child associations only.'))
remove_generated([path],path.parent/'request_trace_cleanup.json','Rejected boundary run; operation timings, parent-child counts, query and sample-quality summaries, source hashes retained.')
