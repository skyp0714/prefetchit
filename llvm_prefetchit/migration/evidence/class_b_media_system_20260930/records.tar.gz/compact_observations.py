import pathlib,json,sys,gzip,collections
root=pathlib.Path('/storage/prefetchit/class_b_media_system_20260930')
sys.path.insert(0,'/home/hnpark2/prefetchit/llvm_prefetchit/scripts/class_b')
import dense_build as b
from e2e_lbr import remove_generated
assert (root/'artifact_retention_complete.json').exists()
paths=sorted([*root.glob('observations/*/*.json.gz'),*root.glob('libraries/observations/*/*.json.gz')]);assert len(paths)==34
manifest=[]
for path in paths:
 with gzip.open(path,'rt') as stream:rows=json.load(stream)
 targets=collections.Counter();sites=collections.Counter();classes=collections.Counter();nearest_sources=collections.Counter();line_counts=collections.Counter();eligible=0;mispred=0;weights=0.;eligible_weights=0.
 for row in rows:
  targets[str(row['target'])]+=1;line_counts[str(row['line'])]+=1;sites.update(map(str,set(row['sites'])))
  eligible+=bool(row['sites']);weights+=row['miss_weight'];eligible_weights+=row['miss_weight']*bool(row['sites'])
  nearest=row.get('nearest')
  if nearest:
   classes[nearest['branch_class']]+=1;nearest_sources[str(nearest['source'])]+=1;mispred+=bool(nearest['mispredicted'])
 relative=path.relative_to(root);dest=root/'observation_statistics'/relative.with_suffix('')
 b.save(dest,dict(source=str(relative),source_sha256=b.sha(path),source_bytes=path.stat().st_size,rows=len(rows),eligible_rows=eligible,miss_weight_sum=weights,eligible_miss_weight_sum=eligible_weights,targets=dict(targets),sampled_ip_lines=dict(line_counts),site_presence=dict(sites),nearest_branch_classes=dict(classes),nearest_branch_sources=dict(nearest_sources),nearest_mispredicted_rows=mispred,limitation='Post-campaign aggregates. Per-sample LBR path/age copies removed after placement, heldout coverage and final diagnostics. Exact measured policy is preserved in selected plans and assembly/linker/byte-patch records; these aggregates do not reconstruct each original path.'))
 manifest.append(dict(source=str(relative),summary=str(dest.relative_to(root)),summary_sha256=b.sha(dest)))
b.save(root/'observation_summary_manifest.json',manifest)
remove_generated(paths,root/'observation_cleanup.json','Completed non-promoted policy: preserve target/site/branch distributions, heldout coverage, exact policy plans/patches, source/commands/hashes and all PMU/E2E measurements; remove no-longer-needed per-sample decoded LBR observation copies.')
for folder in [root/'observations',root/'libraries/observations']:
 for path in sorted([p for p in folder.rglob('*') if p.is_dir()],key=lambda p:len(p.parts),reverse=True):path.rmdir()
 folder.rmdir()
print('Aggregated and removed 34 decoded observation copies.')
