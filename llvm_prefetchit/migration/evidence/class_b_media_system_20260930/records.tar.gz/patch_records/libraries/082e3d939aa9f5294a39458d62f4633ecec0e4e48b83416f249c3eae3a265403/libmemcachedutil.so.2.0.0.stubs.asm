
/storage/prefetchit/class_b_media_system_20260930/libraries/builds/082e3d939aa9f5294a39458d62f4633ecec0e4e48b83416f249c3eae3a265403/call-stub-xi_805ux/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000000072c0 <pf_call_0>:
    72c0:	0f 18 15 f9 af ff ff 	prefetcht1 -0x5007(%rip)        # 22c0 <pf_target_0_0>
    72c7:	e9 d4 b0 ff ff       	jmp    23a0 <pf_callee_0>
    72cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000072d0 <pf_call_1>:
    72d0:	0f 18 15 c9 b0 ff ff 	prefetcht1 -0x4f37(%rip)        # 23a0 <pf_callee_0>
    72d7:	e9 64 b2 ff ff       	jmp    2540 <pf_callee_1>
