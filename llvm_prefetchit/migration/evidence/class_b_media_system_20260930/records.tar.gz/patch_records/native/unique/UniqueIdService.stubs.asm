
/storage/prefetchit/class_b_media_system_20260930/builds/unique/call-stub-d5iy29r_/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000113340 <pf_call_0>:
  113340:	0f 18 15 b9 2e f3 ff 	prefetcht1 -0xcd147(%rip)        # 46200 <pf_target_0_0>
  113347:	0f 18 15 52 2e f3 ff 	prefetcht1 -0xcd1ae(%rip)        # 461a0 <pf_target_0_1>
  11334e:	e9 fd 3f f1 ff       	jmp    27350 <pf_callee_0>
  113353:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11335a:	00 00 00 
  11335d:	0f 1f 00             	nopl   (%rax)

0000000000113360 <pf_call_1>:
  113360:	0f 18 15 d9 02 f2 ff 	prefetcht1 -0xdfd27(%rip)        # 33640 <pf_target_1_0>
  113367:	e9 e4 3f f1 ff       	jmp    27350 <pf_callee_0>
  11336c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113370 <pf_call_2>:
  113370:	0f 18 15 b9 17 fb ff 	prefetcht1 -0x4e847(%rip)        # c4b30 <pf_target_2_0>
  113377:	0f 18 15 22 3e f8 ff 	prefetcht1 -0x7c1de(%rip)        # 971a0 <pf_target_2_1>
  11337e:	0f 18 15 7b 3e f8 ff 	prefetcht1 -0x7c185(%rip)        # 97200 <pf_target_2_2>
  113385:	0f 18 15 04 69 f9 ff 	prefetcht1 -0x696fc(%rip)        # a9c90 <pf_target_2_3>
  11338c:	e9 4f 6a f9 ff       	jmp    a9de0 <pf_callee_2>
  113391:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  113398:	00 00 00 
  11339b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000001133a0 <pf_call_3>:
  1133a0:	0f 18 15 cf 0a f2 ff 	prefetcht1 -0xdf531(%rip)        # 33e76 <pf_target_3_0>
  1133a7:	0f 18 15 12 bb f4 ff 	prefetcht1 -0xb44ee(%rip)        # 5eec0 <pf_target_3_1>
  1133ae:	0f 18 15 7b 9f f5 ff 	prefetcht1 -0xa6085(%rip)        # 6d330 <pf_target_3_2>
  1133b5:	e9 b6 03 f2 ff       	jmp    33770 <pf_callee_3>
  1133ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000001133c0 <pf_call_4>:
  1133c0:	0f 18 15 89 bb f4 ff 	prefetcht1 -0xb4477(%rip)        # 5ef50 <pf_target_4_0>
  1133c7:	e9 04 0f f2 ff       	jmp    342d0 <pf_callee_4>
  1133cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001133d0 <pf_call_5>:
  1133d0:	0f 18 15 09 2e f7 ff 	prefetcht1 -0x8d1f7(%rip)        # 861e0 <pf_target_5_0>
  1133d7:	0f 18 15 f2 96 f7 ff 	prefetcht1 -0x8690e(%rip)        # 8cad0 <pf_callee_7>
  1133de:	0f 18 15 2b c1 fb ff 	prefetcht1 -0x43ed5(%rip)        # cf510 <pf_target_5_2>
  1133e5:	0f 18 15 54 cf f7 ff 	prefetcht1 -0x830ac(%rip)        # 90340 <pf_target_5_3>
  1133ec:	e9 3f 8d f7 ff       	jmp    8c130 <pf_callee_5>
  1133f1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1133f8:	00 00 00 
  1133fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000113400 <pf_call_6>:
  113400:	0f 18 15 49 1c fb ff 	prefetcht1 -0x4e3b7(%rip)        # c5050 <pf_target_6_0>
  113407:	0f 18 15 f2 96 f7 ff 	prefetcht1 -0x8690e(%rip)        # 8cb00 <pf_target_6_1>
  11340e:	e9 9d 43 f1 ff       	jmp    277b0 <pf_callee_6>
  113413:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11341a:	00 00 00 
  11341d:	0f 1f 00             	nopl   (%rax)

0000000000113420 <pf_call_7>:
  113420:	0f 18 15 d9 d4 f3 ff 	prefetcht1 -0xc2b27(%rip)        # 50900 <pf_target_7_0>
  113427:	e9 a4 96 f7 ff       	jmp    8cad0 <pf_callee_7>
  11342c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113430 <pf_call_8>:
  113430:	0f 18 15 e9 84 f3 ff 	prefetcht1 -0xc7b17(%rip)        # 4b920 <pf_target_8_0>
  113437:	0f 18 15 42 85 f3 ff 	prefetcht1 -0xc7abe(%rip)        # 4b980 <pf_target_8_1>
  11343e:	0f 18 15 cb 37 f3 ff 	prefetcht1 -0xcc835(%rip)        # 46c10 <pf_target_8_2>
  113445:	e9 86 3d f1 ff       	jmp    271d0 <pf_callee_8>
  11344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000113450 <pf_call_9>:
  113450:	0f 18 15 a9 33 f3 ff 	prefetcht1 -0xccc57(%rip)        # 46800 <pf_target_9_0>
  113457:	e9 94 3c f1 ff       	jmp    270f0 <pf_callee_9>
  11345c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113460 <pf_call_10>:
  113460:	0f 18 15 19 34 f3 ff 	prefetcht1 -0xccbe7(%rip)        # 46880 <pf_target_10_0>
  113467:	e9 54 38 f3 ff       	jmp    46cc0 <pf_callee_10>
  11346c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113470 <pf_call_11>:
  113470:	0f 18 15 29 4d f3 ff 	prefetcht1 -0xcb2d7(%rip)        # 481a0 <pf_target_11_0>
  113477:	e9 c4 3c f1 ff       	jmp    27140 <pf_callee_11>
  11347c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113480 <pf_call_12>:
  113480:	0f 18 15 d9 49 f1 ff 	prefetcht1 -0xeb627(%rip)        # 27e60 <pf_target_12_0>
  113487:	e9 b4 3c f1 ff       	jmp    27140 <pf_callee_11>
  11348c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113490 <pf_call_13>:
  113490:	0f 18 15 a9 fb f2 ff 	prefetcht1 -0xd0457(%rip)        # 43040 <pf_callee_14>
  113497:	0f 18 15 72 42 f3 ff 	prefetcht1 -0xcbd8e(%rip)        # 47710 <pf_target_13_1>
  11349e:	e9 9d 47 f3 ff       	jmp    47c40 <pf_callee_13>
  1134a3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1134aa:	00 00 00 
  1134ad:	0f 1f 00             	nopl   (%rax)

00000000001134b0 <pf_call_14>:
  1134b0:	0f 18 15 09 4b f1 ff 	prefetcht1 -0xeb4f7(%rip)        # 27fc0 <pf_target_14_0>
  1134b7:	e9 84 fb f2 ff       	jmp    43040 <pf_callee_14>
  1134bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001134c0 <pf_call_15>:
  1134c0:	0f 18 15 9e 13 f5 ff 	prefetcht1 -0xaec62(%rip)        # 64865 <pf_target_15_0>
  1134c7:	0f 18 15 33 17 f5 ff 	prefetcht1 -0xae8cd(%rip)        # 64c01 <pf_target_15_1>
  1134ce:	e9 6d 3c f1 ff       	jmp    27140 <pf_callee_11>
  1134d3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1134da:	00 00 00 
  1134dd:	0f 1f 00             	nopl   (%rax)

00000000001134e0 <pf_call_16>:
  1134e0:	0f 18 15 59 38 f5 ff 	prefetcht1 -0xac7a7(%rip)        # 66d40 <pf_callee_18>
  1134e7:	e9 94 cc f4 ff       	jmp    60180 <pf_callee_16>
  1134ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001134f0 <pf_call_17>:
  1134f0:	0f 18 15 39 42 f1 ff 	prefetcht1 -0xebdc7(%rip)        # 27730 <pf_target_17_0>
  1134f7:	0f 18 15 52 0e f5 ff 	prefetcht1 -0xaf1ae(%rip)        # 64350 <pf_target_17_1>
  1134fe:	0f 18 15 fb 4b f1 ff 	prefetcht1 -0xeb405(%rip)        # 28100 <pf_callee_19>
  113505:	0f 18 15 40 30 f5 ff 	prefetcht1 -0xacfc0(%rip)        # 6654c <pf_target_17_3>
  11350c:	e9 6f cc f4 ff       	jmp    60180 <pf_callee_16>
  113511:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  113518:	00 00 00 
  11351b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000113520 <pf_call_18>:
  113520:	0f 18 15 69 4b f1 ff 	prefetcht1 -0xeb497(%rip)        # 28090 <pf_target_18_0>
  113527:	0f 18 15 42 8a f3 ff 	prefetcht1 -0xc75be(%rip)        # 4bf70 <pf_target_18_1>
  11352e:	e9 0d 38 f5 ff       	jmp    66d40 <pf_callee_18>
  113533:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11353a:	00 00 00 
  11353d:	0f 1f 00             	nopl   (%rax)

0000000000113540 <pf_call_19>:
  113540:	0f 18 15 29 f9 f4 ff 	prefetcht1 -0xb06d7(%rip)        # 62e70 <pf_callee_20>
  113547:	0f 18 15 6f f9 f4 ff 	prefetcht1 -0xb0691(%rip)        # 62ebd <pf_target_19_1>
  11354e:	0f 18 15 0b c1 f4 ff 	prefetcht1 -0xb3ef5(%rip)        # 5f660 <pf_target_19_2>
  113555:	0f 18 15 24 14 f5 ff 	prefetcht1 -0xaebdc(%rip)        # 64980 <pf_target_19_3>
  11355c:	e9 9f 4b f1 ff       	jmp    28100 <pf_callee_19>
  113561:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  113568:	00 00 00 
  11356b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000113570 <pf_call_20>:
  113570:	0f 18 15 e9 c4 f4 ff 	prefetcht1 -0xb3b17(%rip)        # 5fa60 <pf_target_20_0>
  113577:	e9 f4 f8 f4 ff       	jmp    62e70 <pf_callee_20>
  11357c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113580 <pf_call_21>:
  113580:	0f 18 15 f5 75 f5 ff 	prefetcht1 -0xa8a0b(%rip)        # 6ab7c <pf_target_21_0>
  113587:	e9 b4 48 f1 ff       	jmp    27e40 <pf_callee_21>
  11358c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000113590 <pf_call_22>:
  113590:	0f 18 15 c9 c0 f4 ff 	prefetcht1 -0xb3f37(%rip)        # 5f660 <pf_target_19_2>
  113597:	e9 94 75 f5 ff       	jmp    6ab30 <pf_callee_22>
  11359c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001135a0 <pf_call_23>:
  1135a0:	0f 18 15 09 99 f3 ff 	prefetcht1 -0xc66f7(%rip)        # 4ceb0 <pf_target_23_0>
  1135a7:	0f 18 15 52 6e f9 ff 	prefetcht1 -0x691ae(%rip)        # aa400 <pf_target_23_1>
  1135ae:	0f 18 15 0b 99 f3 ff 	prefetcht1 -0xc66f5(%rip)        # 4cec0 <pf_target_23_2>
  1135b5:	e9 76 48 f1 ff       	jmp    27e30 <pf_callee_23>
