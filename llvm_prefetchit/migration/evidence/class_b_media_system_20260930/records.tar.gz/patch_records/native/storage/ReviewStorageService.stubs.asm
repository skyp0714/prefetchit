
/storage/prefetchit/class_b_media_system_20260930/builds/storage/call-stub-7rn27ezz/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000010b340 <pf_call_0>:
  10b340:	0f 18 15 b4 06 f4 ff 	prefetcht1 -0xbf94c(%rip)        # 4b9fb <pf_target_0_0>
  10b347:	0f 18 15 f2 05 f4 ff 	prefetcht1 -0xbfa0e(%rip)        # 4b940 <pf_target_0_1>
  10b34e:	0f 18 15 e9 06 f4 ff 	prefetcht1 -0xbf917(%rip)        # 4ba3e <pf_target_0_2>
  10b355:	e9 e6 c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b35a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000010b360 <pf_call_1>:
  10b360:	0f 18 15 a9 e2 f2 ff 	prefetcht1 -0xd1d57(%rip)        # 39610 <pf_target_1_0>
  10b367:	e9 d4 c0 f1 ff       	jmp    27440 <pf_callee_0>
  10b36c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b370 <pf_call_2>:
  10b370:	0f 18 15 79 c2 f1 ff 	prefetcht1 -0xe3d87(%rip)        # 275f0 <pf_target_2_0>
  10b377:	e9 24 69 f4 ff       	jmp    51ca0 <pf_callee_2>
  10b37c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b380 <pf_call_3>:
  10b380:	0f 18 15 a9 0f f6 ff 	prefetcht1 -0x9f057(%rip)        # 6c330 <pf_target_3_0>
  10b387:	e9 e4 69 f4 ff       	jmp    51d70 <pf_callee_20>
  10b38c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b390 <pf_call_4>:
  10b390:	0f 18 15 19 10 f4 ff 	prefetcht1 -0xbefe7(%rip)        # 4c3b0 <pf_target_4_0>
  10b397:	0f 18 15 82 5c f4 ff 	prefetcht1 -0xba37e(%rip)        # 51020 <pf_target_4_1>
  10b39e:	0f 18 15 db 5c f4 ff 	prefetcht1 -0xba325(%rip)        # 51080 <pf_target_4_2>
  10b3a5:	e9 b6 be f1 ff       	jmp    27260 <pf_callee_4>
  10b3aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000010b3b0 <pf_call_5>:
  10b3b0:	0f 18 15 29 c4 f1 ff 	prefetcht1 -0xe3bd7(%rip)        # 277e0 <pf_target_5_0>
  10b3b7:	e9 74 c8 f1 ff       	jmp    27c30 <pf_callee_5>
  10b3bc:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b3c0 <pf_call_6>:
  10b3c0:	0f 18 15 29 c1 f1 ff 	prefetcht1 -0xe3ed7(%rip)        # 274f0 <pf_target_6_0>
  10b3c7:	0f 18 15 b2 69 f4 ff 	prefetcht1 -0xb964e(%rip)        # 51d80 <pf_target_6_1>
  10b3ce:	0f 18 15 b5 d4 f3 ff 	prefetcht1 -0xc2b4b(%rip)        # 4888a <pf_target_6_2>
  10b3d5:	e9 06 d4 f3 ff       	jmp    487e0 <pf_callee_11>
  10b3da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000010b3e0 <pf_call_7>:
  10b3e0:	0f 18 15 39 0c f4 ff 	prefetcht1 -0xbf3c7(%rip)        # 4c020 <pf_target_7_0>
  10b3e7:	0f 18 15 55 0c f4 ff 	prefetcht1 -0xbf3ab(%rip)        # 4c043 <pf_target_7_1>
  10b3ee:	e9 6d 10 f4 ff       	jmp    4c460 <pf_callee_7>
  10b3f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b3fa:	00 00 00 
  10b3fd:	0f 1f 00             	nopl   (%rax)

000000000010b400 <pf_call_8>:
  10b400:	0f 18 15 09 25 f4 ff 	prefetcht1 -0xbdaf7(%rip)        # 4d910 <pf_target_8_0>
  10b407:	e9 a4 bd f1 ff       	jmp    271b0 <pf_callee_13>
  10b40c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b410 <pf_call_9>:
  10b410:	0f 18 15 89 0b f4 ff 	prefetcht1 -0xbf477(%rip)        # 4bfa0 <pf_target_9_0>
  10b417:	e9 24 bd f1 ff       	jmp    27140 <pf_callee_9>
  10b41c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b420 <pf_call_10>:
  10b420:	0f 18 15 b9 d3 f3 ff 	prefetcht1 -0xc2c47(%rip)        # 487e0 <pf_callee_11>
  10b427:	e9 b4 1f f4 ff       	jmp    4d3e0 <pf_callee_10>
  10b42c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b430 <pf_call_11>:
  10b430:	0f 18 15 79 1a f4 ff 	prefetcht1 -0xbe587(%rip)        # 4ceb0 <pf_target_11_0>
  10b437:	e9 a4 d3 f3 ff       	jmp    487e0 <pf_callee_11>
  10b43c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b440 <pf_call_12>:
  10b440:	0f 18 15 e9 cd f1 ff 	prefetcht1 -0xe3217(%rip)        # 28230 <pf_target_12_0>
  10b447:	e9 94 d3 f3 ff       	jmp    487e0 <pf_callee_11>
  10b44c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b450 <pf_call_13>:
  10b450:	0f 18 15 49 cc f1 ff 	prefetcht1 -0xe33b7(%rip)        # 280a0 <pf_target_13_0>
  10b457:	e9 54 bd f1 ff       	jmp    271b0 <pf_callee_13>
  10b45c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b460 <pf_call_14>:
  10b460:	0f 18 15 b9 c4 f5 ff 	prefetcht1 -0xa3b47(%rip)        # 67920 <pf_target_14_0>
  10b467:	0f 18 15 d2 b9 f5 ff 	prefetcht1 -0xa462e(%rip)        # 66e40 <pf_target_14_1>
  10b46e:	0f 18 15 cb c4 f5 ff 	prefetcht1 -0xa3b35(%rip)        # 67940 <pf_target_14_2>
  10b475:	e9 36 bd f1 ff       	jmp    271b0 <pf_callee_13>
  10b47a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000010b480 <pf_call_15>:
  10b480:	0f 18 15 19 43 f6 ff 	prefetcht1 -0x9bce7(%rip)        # 6f7a0 <pf_callee_17>
  10b487:	e9 64 c9 f5 ff       	jmp    67df0 <pf_callee_15>
  10b48c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b490 <pf_call_16>:
  10b490:	0f 18 15 15 3b f6 ff 	prefetcht1 -0x9c4eb(%rip)        # 6efac <pf_target_16_0>
  10b497:	0f 18 15 22 cf f1 ff 	prefetcht1 -0xe30de(%rip)        # 283c0 <pf_callee_18>
  10b49e:	0f 18 15 fb c3 f1 ff 	prefetcht1 -0xe3c05(%rip)        # 278a0 <pf_target_16_2>
  10b4a5:	0f 18 15 24 05 f6 ff 	prefetcht1 -0x9fadc(%rip)        # 6b9d0 <pf_target_16_3>
  10b4ac:	e9 3f c9 f5 ff       	jmp    67df0 <pf_callee_15>
  10b4b1:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b4b8:	00 00 00 
  10b4bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

000000000010b4c0 <pf_call_17>:
  10b4c0:	0f 18 15 89 ce f1 ff 	prefetcht1 -0xe3177(%rip)        # 28350 <pf_target_17_0>
  10b4c7:	0f 18 15 a2 61 f4 ff 	prefetcht1 -0xb9e5e(%rip)        # 51670 <pf_target_17_1>
  10b4ce:	e9 cd 42 f6 ff       	jmp    6f7a0 <pf_callee_17>
  10b4d3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b4da:	00 00 00 
  10b4dd:	0f 1f 00             	nopl   (%rax)

000000000010b4e0 <pf_call_18>:
  10b4e0:	0f 18 15 19 0b f6 ff 	prefetcht1 -0x9f4e7(%rip)        # 6c000 <pf_target_18_0>
  10b4e7:	0f 18 15 02 d2 f5 ff 	prefetcht1 -0xa2dfe(%rip)        # 686f0 <pf_callee_19>
  10b4ee:	e9 cd ce f1 ff       	jmp    283c0 <pf_callee_18>
  10b4f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b4fa:	00 00 00 
  10b4fd:	0f 1f 00             	nopl   (%rax)

000000000010b500 <pf_call_19>:
  10b500:	0f 18 15 c9 c1 f5 ff 	prefetcht1 -0xa3e37(%rip)        # 676d0 <pf_target_19_0>
  10b507:	0f 18 15 c2 bd f5 ff 	prefetcht1 -0xa423e(%rip)        # 672d0 <pf_target_19_1>
  10b50e:	e9 dd d1 f5 ff       	jmp    686f0 <pf_callee_19>
  10b513:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  10b51a:	00 00 00 
  10b51d:	0f 1f 00             	nopl   (%rax)

000000000010b520 <pf_call_20>:
  10b520:	0f 18 15 99 5b f6 ff 	prefetcht1 -0x9a467(%rip)        # 710c0 <pf_callee_21>
  10b527:	e9 44 68 f4 ff       	jmp    51d70 <pf_callee_20>
  10b52c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000010b530 <pf_call_21>:
  10b530:	0f 18 15 ae 09 f6 ff 	prefetcht1 -0x9f652(%rip)        # 6bee5 <pf_target_21_0>
  10b537:	0f 18 15 99 3a f6 ff 	prefetcht1 -0x9c567(%rip)        # 6efd7 <pf_target_21_1>
  10b53e:	0f 18 15 d1 05 f6 ff 	prefetcht1 -0x9fa2f(%rip)        # 6bb16 <pf_target_21_2>
  10b545:	e9 76 5b f6 ff       	jmp    710c0 <pf_callee_21>
