
/storage/prefetchit/class_b_media_system_20260930/builds/text/call-stub-jhii3avo/stubs.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000110340 <pf_call_0>:
  110340:	0f 18 15 e9 88 f3 ff 	prefetcht1 -0xc7717(%rip)        # 48c30 <pf_target_0_0>
  110347:	0f 18 15 ae 31 f3 ff 	prefetcht1 -0xcce52(%rip)        # 434fc <pf_target_0_1>
  11034e:	0f 18 15 5b 31 f3 ff 	prefetcht1 -0xccea5(%rip)        # 434b0 <pf_target_0_2>
  110355:	0f 18 15 21 89 f3 ff 	prefetcht1 -0xc76df(%rip)        # 48c7d <pf_target_0_3>
  11035c:	e9 bf 5f f1 ff       	jmp    26320 <pf_callee_0>
  110361:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  110368:	00 00 00 
  11036b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000110370 <pf_call_1>:
  110370:	0f 18 15 29 06 f2 ff 	prefetcht1 -0xdf9d7(%rip)        # 309a0 <pf_target_1_0>
  110377:	e9 a4 5f f1 ff       	jmp    26320 <pf_callee_0>
  11037c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110380 <pf_call_2>:
  110380:	0f 18 15 d6 1c f5 ff 	prefetcht1 -0xae32a(%rip)        # 6205d <pf_target_2_0>
  110387:	e9 f4 95 f3 ff       	jmp    49980 <pf_callee_2>
  11038c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110390 <pf_call_3>:
  110390:	0f 18 15 39 be f4 ff 	prefetcht1 -0xb41c7(%rip)        # 5c1d0 <pf_target_3_0>
  110397:	0f 18 15 62 8c f5 ff 	prefetcht1 -0xa739e(%rip)        # 69000 <pf_target_3_1>
  11039e:	0f 18 15 31 0e f2 ff 	prefetcht1 -0xdf1cf(%rip)        # 311d6 <pf_target_3_2>
  1103a5:	e9 66 5f f1 ff       	jmp    26310 <pf_callee_3>
  1103aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000001103b0 <pf_call_4>:
  1103b0:	0f 18 15 a9 be f4 ff 	prefetcht1 -0xb4157(%rip)        # 5c260 <pf_target_4_0>
  1103b7:	e9 54 5f f1 ff       	jmp    26310 <pf_callee_3>
  1103bc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001103c0 <pf_call_5>:
  1103c0:	0f 18 15 59 3b f3 ff 	prefetcht1 -0xcc4a7(%rip)        # 43f20 <pf_target_5_0>
  1103c7:	0f 18 15 36 3c f3 ff 	prefetcht1 -0xcc3ca(%rip)        # 44004 <pf_target_5_1>
  1103ce:	e9 ed 5d f1 ff       	jmp    261c0 <pf_callee_5>
  1103d3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1103da:	00 00 00 
  1103dd:	0f 1f 00             	nopl   (%rax)

00000000001103e0 <pf_call_6>:
  1103e0:	0f 18 15 49 62 f1 ff 	prefetcht1 -0xe9db7(%rip)        # 26630 <pf_target_6_0>
  1103e7:	e9 f4 65 f1 ff       	jmp    269e0 <pf_callee_6>
  1103ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001103f0 <pf_call_7>:
  1103f0:	0f 18 15 19 37 f3 ff 	prefetcht1 -0xcc8e7(%rip)        # 43b10 <pf_target_7_0>
  1103f7:	e9 f4 5c f1 ff       	jmp    260f0 <pf_callee_14>
  1103fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110400 <pf_call_8>:
  110400:	0f 18 15 89 37 f3 ff 	prefetcht1 -0xcc877(%rip)        # 43b90 <pf_target_8_0>
  110407:	e9 c4 3b f3 ff       	jmp    43fd0 <pf_callee_8>
  11040c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110410 <pf_call_9>:
  110410:	0f 18 15 99 50 f3 ff 	prefetcht1 -0xcaf67(%rip)        # 454b0 <pf_target_9_0>
  110417:	0f 18 15 a4 50 f3 ff 	prefetcht1 -0xcaf5c(%rip)        # 454c2 <pf_target_9_1>
  11041e:	e9 1d 5d f1 ff       	jmp    26140 <pf_callee_13>
  110423:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11042a:	00 00 00 
  11042d:	0f 1f 00             	nopl   (%rax)

0000000000110430 <pf_call_10>:
  110430:	0f 18 15 19 ff f2 ff 	prefetcht1 -0xd00e7(%rip)        # 40350 <pf_callee_11>
  110437:	e9 14 4b f3 ff       	jmp    44f50 <pf_callee_10>
  11043c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110440 <pf_call_11>:
  110440:	0f 18 15 d9 45 f3 ff 	prefetcht1 -0xcba27(%rip)        # 44a20 <pf_target_11_0>
  110447:	e9 04 ff f2 ff       	jmp    40350 <pf_callee_11>
  11044c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110450 <pf_call_12>:
  110450:	0f 18 15 f9 6a f1 ff 	prefetcht1 -0xe9507(%rip)        # 26f50 <pf_target_12_0>
  110457:	e9 f4 fe f2 ff       	jmp    40350 <pf_callee_11>
  11045c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110460 <pf_call_13>:
  110460:	0f 18 15 89 69 f1 ff 	prefetcht1 -0xe9677(%rip)        # 26df0 <pf_target_13_0>
  110467:	e9 d4 5c f1 ff       	jmp    26140 <pf_callee_13>
  11046c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110470 <pf_call_14>:
  110470:	0f 18 15 2c 8c f3 ff 	prefetcht1 -0xc73d4(%rip)        # 490a3 <pf_target_14_0>
  110477:	e9 74 5c f1 ff       	jmp    260f0 <pf_callee_14>
  11047c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000110480 <pf_call_15>:
  110480:	0f 18 15 3f 14 f5 ff 	prefetcht1 -0xaebc1(%rip)        # 618c6 <pf_target_15_0>
  110487:	0f 18 15 32 cb f4 ff 	prefetcht1 -0xb34ce(%rip)        # 5cfc0 <pf_target_15_1>
  11048e:	e9 ad 5c f1 ff       	jmp    26140 <pf_callee_13>
  110493:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11049a:	00 00 00 
  11049d:	0f 1f 00             	nopl   (%rax)

00000000001104a0 <pf_call_16>:
  1104a0:	0f 18 15 19 3d f5 ff 	prefetcht1 -0xac2e7(%rip)        # 641c0 <pf_callee_18>
  1104a7:	e9 e4 cf f4 ff       	jmp    5d490 <pf_callee_16>
  1104ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000001104b0 <pf_call_17>:
  1104b0:	0f 18 15 c9 12 f5 ff 	prefetcht1 -0xaed37(%rip)        # 61780 <pf_target_17_0>
  1104b7:	0f 18 15 d2 6b f1 ff 	prefetcht1 -0xe942e(%rip)        # 27090 <pf_callee_19>
  1104be:	0f 18 15 1b 62 f1 ff 	prefetcht1 -0xe9de5(%rip)        # 266e0 <pf_target_17_2>
  1104c5:	e9 c6 cf f4 ff       	jmp    5d490 <pf_callee_16>
  1104ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000001104d0 <pf_call_18>:
  1104d0:	0f 18 15 49 6b f1 ff 	prefetcht1 -0xe94b7(%rip)        # 27020 <pf_target_18_0>
  1104d7:	0f 18 15 a2 8d f3 ff 	prefetcht1 -0xc725e(%rip)        # 49280 <pf_target_18_1>
  1104de:	0f 18 15 fd 8f f3 ff 	prefetcht1 -0xc7003(%rip)        # 494e2 <pf_target_18_2>
  1104e5:	e9 d6 3c f5 ff       	jmp    641c0 <pf_callee_18>
  1104ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000001104f0 <pf_call_19>:
  1104f0:	0f 18 15 99 fc f4 ff 	prefetcht1 -0xb0367(%rip)        # 60190 <pf_callee_20>
  1104f7:	0f 18 15 b2 18 f5 ff 	prefetcht1 -0xae74e(%rip)        # 61db0 <pf_target_19_1>
  1104fe:	e9 8d 6b f1 ff       	jmp    27090 <pf_callee_19>
  110503:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11050a:	00 00 00 
  11050d:	0f 1f 00             	nopl   (%rax)

0000000000110510 <pf_call_20>:
  110510:	0f 18 15 59 c8 f4 ff 	prefetcht1 -0xb37a7(%rip)        # 5cd70 <pf_target_20_0>
  110517:	0f 18 15 52 c4 f4 ff 	prefetcht1 -0xb3bae(%rip)        # 5c970 <pf_target_20_1>
  11051e:	e9 6d fc f4 ff       	jmp    60190 <pf_callee_20>
  110523:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11052a:	00 00 00 
  11052d:	0f 1f 00             	nopl   (%rax)

0000000000110530 <pf_call_21>:
  110530:	0f 18 15 49 34 f5 ff 	prefetcht1 -0xacbb7(%rip)        # 63980 <pf_target_21_0>
  110537:	0f 18 15 57 17 f5 ff 	prefetcht1 -0xae8a9(%rip)        # 61c95 <pf_target_21_1>
  11053e:	0f 18 15 87 34 f5 ff 	prefetcht1 -0xacb79(%rip)        # 639cc <pf_target_21_2>
  110545:	e9 f6 5b f1 ff       	jmp    26140 <pf_callee_13>
  11054a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000110550 <pf_call_22>:
  110550:	0f 18 15 19 c4 f4 ff 	prefetcht1 -0xb3be7(%rip)        # 5c970 <pf_target_20_1>
  110557:	0f 18 15 92 4e f5 ff 	prefetcht1 -0xab16e(%rip)        # 653f0 <pf_target_22_1>
  11055e:	e9 6d 68 f1 ff       	jmp    26dd0 <pf_callee_22>
  110563:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  11056a:	00 00 00 
  11056d:	0f 1f 00             	nopl   (%rax)

0000000000110570 <pf_call_23>:
  110570:	0f 18 15 6a dd f1 ff 	prefetcht1 -0xe2296(%rip)        # 2e2e1 <pf_target_23_0>
  110577:	e9 84 86 f6 ff       	jmp    78c00 <pf_callee_23>
