import json,pathlib,sys
root=pathlib.Path('/storage/prefetchit/class_b_media_system_20260930')
sys.path.insert(0,'/home/hnpark2/prefetchit/llvm_prefetchit/scripts/class_b')
import dense_build as b
import media_system_study as study
import media_boundary_profile as boundary
b.save(root/'pmu_retry_amendment.json',dict(reason='Nginx topdown closure exceeded the unchanged 2% validity limit (2.3531%). Reject and retain the whole diagnostic. Resume completed valid diagnostics; repeat only invalid diagnostics at identical seed/order, at most two fresh retries. No endpoint result rerun or filtering.',sources={p:b.sha(pathlib.Path(study.__file__).with_name(p)) for p in ['media_system_study.py','split_hybrid_study.py','media_boundary_profile.py']}))
study.diagnostics(root)
b.save(root/'complete.json',dict(valid=True,clean_trials=16,diagnostic_runs=6,invalid_diagnostics=len(list((root/'invalid_diagnostics').rglob('failure.json')))))
boundary.run(root)
