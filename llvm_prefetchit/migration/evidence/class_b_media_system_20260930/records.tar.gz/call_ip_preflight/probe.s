.text
.global _start, call_a, call_b, leaf
_start:
 mov $5000000, %edx
again:
call_a: call leaf
call_b: call leaf
 dec %edx
 jnz again
 xor %edi, %edi
 mov $60, %eax
 syscall
leaf: ret
.section .note.GNU-stack,"",@progbits
