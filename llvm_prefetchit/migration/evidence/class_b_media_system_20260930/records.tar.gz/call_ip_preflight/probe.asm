
/storage/prefetchit/class_b_media_system_20260930/call_ip_preflight/probe:     file format elf64-x86-64


Disassembly of section .text:

0000000000401000 <_start>:
  401000:	ba 40 4b 4c 00       	mov    $0x4c4b40,%edx

0000000000401005 <call_a>:
  401005:	e8 12 00 00 00       	call   40101c <leaf>

000000000040100a <call_b>:
  40100a:	e8 0d 00 00 00       	call   40101c <leaf>
  40100f:	ff ca                	dec    %edx
  401011:	75 f2                	jne    401005 <call_a>
  401013:	31 ff                	xor    %edi,%edi
  401015:	b8 3c 00 00 00       	mov    $0x3c,%eax
  40101a:	0f 05                	syscall

000000000040101c <leaf>:
  40101c:	c3                   	ret
