import pathlib,json,sys
root=pathlib.Path('/storage/prefetchit/class_b_media_system_20260930')
sys.path.insert(0,'/home/hnpark2/prefetchit/llvm_prefetchit/scripts/class_b')
import dense_build as b
import media_boundary_profile as boundary
rejected=root/'invalid_boundaries';rejected.mkdir(exist_ok=False)
paths=[]
for p in sorted((root/'boundaries').glob('original*')):
 dest=rejected/p.name;p.rename(dest);paths.append(str(dest))
checks=[]
for p in rejected.rglob('*_before.json'):
 after=p.with_name(p.name.replace('_before','_restored'));checks.append(after.exists() and json.loads(p.read_text())==json.loads(after.read_text()))
assert checks and all(checks)
assert not list(rejected.rglob('perf.data'))
b.save(root/'boundary_sampling_amendment.json',dict(reason='Kernel cycles sampling period 100,003 exceeded the unchanged hardware sampling-rate gate in bursts: THROTTLE 10,594 / UNTHROTTLE 10,593. Reject this boundary diagnostic; all clean E2E and six service PMU diagnostics remain unchanged.',periods={'cycles':1000003,'l2':1021},perf_max_sample_rate=pathlib.Path('/proc/sys/kernel/perf_event_max_sample_rate').read_text().strip(),moved=paths,platform_restored=True,cleanup='Rejected raw cycles and L2 captures (61,295,676 bytes) already removed after source hashes/quality/settings/counters/error were saved.',source_sha256=b.sha(boundary.__file__)))
(root/'boundary_profile_final_source.py').write_bytes(pathlib.Path(boundary.__file__).read_bytes())
boundary.run(root)
